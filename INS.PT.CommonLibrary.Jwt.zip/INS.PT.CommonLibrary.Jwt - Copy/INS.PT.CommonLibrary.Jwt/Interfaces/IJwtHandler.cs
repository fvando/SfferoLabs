using INS.PT.CommonLibrary.Jwt.Models;
using Microsoft.IdentityModel.Tokens;

namespace INS.PT.CommonLibrary.Jwt.Interfaces
{
    public interface IJwtHandler
    {
        JwtElement Create(string userId);
        TokenValidationParameters Parameters { get;}    
    }
}
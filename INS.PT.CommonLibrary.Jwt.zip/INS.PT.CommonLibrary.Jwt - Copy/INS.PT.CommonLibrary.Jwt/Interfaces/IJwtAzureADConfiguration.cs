﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using System;
using System.Collections.Generic;
using System.Text;

namespace INS.PT.CommonLibrary.Jwt.Interfaces
{
    public interface IJwtAzureADConfiguration
    {
        /// <summary>
        /// Authentications the specified options.
        /// </summary>
        /// <param name="options">The options.</param>
        void Authentication(AuthenticationOptions options);
        /// <summary>
        /// JWTs the bearer.
        /// </summary>
        /// <param name="bearer">The bearer.</param>
        void JwtBearer(JwtBearerOptions bearer);
        /// <summary>
        /// Sets the configuration renewal.
        /// </summary>
        /// <param name="options">The options.</param>
        void SetConfigurationRenewal(JwtBearerOptions options);
    }
}

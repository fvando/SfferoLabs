﻿================================================================================================================
=================                         Version: 16.12.2019							   =====================
================= Configuration When Using a Collection of dynamic (renewable) Public Keys =====================
=================     (!!! Version to be Used. Not dependent on local public Keys !!!)     =====================
================================================================================================================

1. Add the following code to "ConfigureServices" method of the StartUp Class
	(this will load the public key upon aplication start and add the 'Authorize' button for the swager definition)

	 // Instantion of the configuration class
	 JwtAzureADConfiguration jwtConfiguration = new JwtAzureADConfiguration(Options.Create(Configuration.GetSection("JwtSettings").Get<JwtSettings>()));            
 
	 services.AddAuthentication(jwtConfiguration.Authentication)
	   // Jwt Configuration based on appSettings
	   .AddJwtBearer(jwtConfiguration.JwtBearer);
	   //Set Key Renewal
	   services.PostConfigure<JwtBearerOptions>(jwtConfiguration.SetConfigurationRenewal);

    // Add Swagger Authentication       
    services.AddSwaggerGen(SwaggerJwtHelper.ConfigureSwaggerJwtToken);

2. Add the "UseAuthentication" to the "Configure" method of the StartUp class

		    // Force Authentication
            app.UseAuthentication();

3. Add to the "appSettings.json" the following structure (in the Root)

	"JwtSettings": {
		"StsDiscoveryEndpoint": "https://login.microsoftonline.com/common/v2.0/.well-known/openid-configuration",
		"ValidateLifetime": false,
		"ValidateAudience": true,
		"ValidateIssuer": true,
		"ValidAudiences": [ "Token(s) Audience" ],
		"ValidIssuers": [ "Issuer(s) URL" ],
		"ValidateIssuerSigningKey": true,
		"PublicKeysRenewalInterval": 4,
	  * "ProxySettings": {
		  "Address": "proxy.corp.ageas.pt", 
		  "Port": "8080"
		}
	}

3.1 * In situations where the connection is possible directly, it is not necessary to configure a proxy value.

4. Add Authorize to the Controller(s) that need authentication verification

================================================================================================================
=================                         Version: 12.07.2019							   =====================
============================= Configuration When Using Public Key Configured ===================================
================================================================================================================
	
Actions Needed:

1. Add the following code to "ConfigureServices" method of the StartUp Class
	(this will load the public key upon aplication start and add the 'Authorize' button for the swager definition)

		#region Region Authentication

            services.AddSingleton<IJwtHandler, JwtHandler>();

            // Add Swagger Authentication
            services.AddSwaggerGen(c =>
            {
                c.AddSecurityDefinition("Bearer", new ApiKeyScheme
                {
                    Description = "JWT Authorization header using the Bearer scheme. Example: \"Bearer {token}\"",
                    Name = "Authorization",
                    In = "header",
                    Type = "apiKey"
                });
                // Force Bearer token to be passed on the Header
                c.AddSecurityRequirement(new Dictionary<string, IEnumerable<string>>
                {
                    { "Bearer", new string[0] { } }
                });
            });

            // JWT
            IOptions<JwtSettings> jwSettings = Options.Create(applicationSettings.JwtSettings);
            var token = new JwtHandler(jwSettings);

            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(x =>
            {
                x.RequireHttpsMetadata = false;
                x.SaveToken = false;
                x.TokenValidationParameters = token.Parameters;
            });

		#endregion

2. Add the "UseAuthentication" to the "Configure" method of the StartUp class

		    // Force Authentication
            app.UseAuthentication();

3. Add to the "appSettings.json" the following structure

	"JwtSettings": {
      "audience": "audience value",
      "issuer": "issuer value",
      "ValidateLifetime": false,
      "useRsa": true,
      "usePemFormat": true,
      "hmacSecretKey": "Secret Key...",
      "pemPrivateKey": "Public Key if present",
      "pemPublicKey": "-----BEGIN PUBLIC KEY-----\r\nXXXXXXXXXXX\r\n-----END PUBLIC KEY",
      "rsaPrivateKeyXml": "rsa-private-key.xml",
      "rsaPublicKeyXml": "rsa-public-key.xml"
    },

	* pemPublicKey: format for the public key to be added in order to be read successfully
	* useRsa: boolean that indicates the Rsa format to be used (Public/Private Key) instead of HMAC (secret key)
	* usePemFormat: boolean that indicates the format of the public key. Either in PEM or XML

4. Add the reference to the JwtSetting to the class "ApplicationSettings" 

        public JwtSettings JwtSettings { get; set; }

5. Add Authorize to the Controller(s) that need authentication verification


======================================================================================
=============================== Policies Configuration ===============================
======================================================================================

To add policies for further token validation or costumization please read the following article:
	
	https://docs.microsoft.com/en-us/aspnet/core/security/authorization/policies?view=aspnetcore-2.2


======================================================================================
=============================== Token Utilities ======================================
======================================================================================

Allows to retreive a claim value or the CLaim object 

	- TokenUtils.GetClaim(EnumClaims.EnumClaim.UserPrincipalName, _token); // Get the claim value (example for the UserPrincipalName (UPN))
	- TokenUtils.GetPayload(_token); // Gets the claim structure
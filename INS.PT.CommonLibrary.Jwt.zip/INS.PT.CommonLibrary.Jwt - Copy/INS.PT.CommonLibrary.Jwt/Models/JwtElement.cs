namespace INS.PT.CommonLibrary.Jwt.Models
{
    public class JwtElement
    {
        public string Token { get; set; }
        public long Expires { get; set; }          
    }
}
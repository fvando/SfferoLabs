﻿using System;
using System.Collections.Generic;
using System.Text;

namespace INS.PT.CommonLibrary.Jwt.Models
{
    public class ProxySettings
    {
        public string Address { get; set; }
        public string Port { get; set; }
    }
}

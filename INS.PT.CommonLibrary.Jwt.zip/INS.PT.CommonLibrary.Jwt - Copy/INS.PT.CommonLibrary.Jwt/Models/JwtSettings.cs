using System.Collections;
using System.Collections.Generic;

namespace INS.PT.CommonLibrary.Jwt.Models
{
    /// <summary>
    /// Jwt Settings 
    /// Support for HMAC, RSA, PEM or Dynamic key retreivel
    /// </summary>
    public class JwtSettings
    {
        /// <summary>
        /// Validation Using a HMAC format key (also know as 'Secret Key')
        /// </summary>
        public string HmacSecretKey { get; set; }
        public bool ValidateLifetime { get; set; }
        /// <summary>
        /// Single Issuer value
        /// </summary>
        public string Issuer { get; set; }
        public bool ValidateIssuer { get; set; }
        /// <summary>
        /// Single Audience value
        /// </summary>
        public string Audience { get; set; }
        public bool ValidateAudience { get; set; }
        public bool ValidateIssuerSigningKey { get; set; }
        /// <summary>
        /// Flag to indicate the use of RSA format
        /// In this case the XML Key(s) will have to be used
        /// <see cref="https://www.cryptosys.net/pki/rsakeyformats.html"/>
        /// </summary>
        public bool UseRsa { get; set; }
        /// <summary>
        /// Flag to indicate the use of PEM format
        /// In this case a single line will represent the key {"-----BEGIN PUBLIC KEY-----\r\nXXXXXXXXXXX\r\n-----END PUBLIC KEY"}
        /// <see cref=""/>
        /// </summary>
        public bool UsePemFormat { get; set; }
        /// <summary>
        /// Private Key (PEM format)
        /// </summary>
        public string PemPrivateKey { get; set; }
        /// <summary>
        /// Public Key (PEM format)
        /// </summary>
        public string PemPublicKey { get; set; }
        /// <summary>
        /// Private Key in the XML format
        /// (Only used if local public key is to be used)
        /// </summary>
        public string RsaPrivateKeyXML { get; set; }
        /// <summary>
        /// Public Key in the XML format
        /// (Only used if local public key is to be used)
        /// </summary>
        public string RsaPublicKeyXML { get; set; }
        /// <summary>
        /// URL for the retreivel of Public Keys Collection 
        /// (Needed if no key is to be configured locally!)        
        /// </summary>
        public string StsDiscoveryEndpoint { get; set; }
        public object IssuerSigningKeys { get; set; }
        /// <summary>
        /// Collections of Audiences
        /// </summary>
        public IEnumerable<string> ValidAudiences { get; set; }
        public object ValidIssuer { get; set; }
        /// <summary>
        /// Collection of Issuers
        /// </summary>
        public IEnumerable<string> ValidIssuers { get; set; }
        /// <summary>
        /// Proxy Settings (needed if a proxy is necessary to make call outside the DMZ)
        /// </summary>
        public ProxySettings ProxySettings { get; set; }
        /// <summary>
        /// The time in Hours for wich the Public Keys will be renewed
        /// </summary>
        public int PublicKeysRenewalInterval { get; set; }
    }
}
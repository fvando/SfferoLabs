using System;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using INS.PT.CommonLibrary.Jwt.Interfaces;
using INS.PT.CommonLibrary.Jwt.Models;
using INS.PT.CommonLibrary.Jwt.RsaUtils;
using log4net;
using System.Reflection;

namespace INS.PT.CommonLibrary.Jwt.Handlers
{
    /// <summary>
    /// Class that handles the following possible validation formats:
    /// RSA  - (Rivest-Shamir-Adleman) A highly secure cryptography method by RSA Security
    /// PEM  - Privacy Enhanced Mail (PEM)
    /// HMAC - Secret Key based algorithm
    /// </summary>
    /// <remarks>
    /// See the ReadMe (Jwt Configuration) notes installed with the Nugget, for configuration!
    /// https://www.thedigitalcatonline.com/blog/2018/04/25/rsa-keys/
    /// </remarks>
    /// <seealso cref="INS.PT.CommonLibrary.Jwt.Interfaces.IJwtHandler" />
    public class JwtHandler : IJwtHandler
    {
        private readonly JwtSettings _settings;
        private readonly JwtSecurityTokenHandler _jwtSecurityTokenHandler = new JwtSecurityTokenHandler();
        private SecurityKey _issuerSigningKey;
        private SigningCredentials _signingCredentials;
        private JwtHeader _jwtHeader;
        public TokenValidationParameters Parameters { get; private set; }

        // Log 4 Net
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        /// <summary>
        /// Initializes a new instance of the <see cref="JwtHandler"/> class.
        /// </summary>
        /// <param name="settings">The settings.</param>
        public JwtHandler(IOptions<JwtSettings> settings)
        {
            
            log.Debug($"{MethodBase.GetCurrentMethod()} Jwt initialization...");
            _settings = settings.Value;
            if(_settings.UseRsa)
            {
                if(_settings.UsePemFormat)
                    InitializeRsaUsingPem();
                else
                    InitializeRsaUsingXml();
            }
            else
            {
                InitializeHmac();
            }
            InitializeJwtParameters();
            log.Debug($"{MethodBase.GetCurrentMethod()} Jwt finalization!");
        }

        /// <summary>
        /// Initializes the RSA using XML.
        /// </summary>
        private void InitializeRsaUsingXml()
        {
            log.Debug($"{MethodBase.GetCurrentMethod()} Obtaining RSA configuration from XML. Start...");
            using (RSA publicRsa = RSA.Create())
            {
                var publicKeyXml = File.ReadAllText(_settings.RsaPublicKeyXML);
                publicRsa.RsaFromXmlString(publicKeyXml);
                _issuerSigningKey = new RsaSecurityKey(publicRsa);
            }
            if(string.IsNullOrWhiteSpace(_settings.RsaPrivateKeyXML))
            {
                return;
            }
            using(RSA privateRsa = RSA.Create())
            {
                var privateKeyXml = File.ReadAllText(_settings.RsaPrivateKeyXML);
                privateRsa.RsaFromXmlString(privateKeyXml);
                var privateKey = new RsaSecurityKey(privateRsa);
                _signingCredentials = new SigningCredentials(privateKey, SecurityAlgorithms.RsaSha256);
            }

            RSACryptoServiceProvider parm = new RSACryptoServiceProvider();
            parm.ExportParameters(true);
            log.Debug($"{MethodBase.GetCurrentMethod()} Obtaining RSA configuration from XML. End!");
        }

        /// <summary>
        /// Initializes the RSA using pem.
        /// </summary>
        private void InitializeRsaUsingPem()
        {
            log.Debug($"{MethodBase.GetCurrentMethod()} Obtaining RSA configuration from PEM. Start...");
            using (RSA publicRsa = RSA.Create())
            {
                var publicKey = RSAKeys.ImportPublicKey(_settings.PemPublicKey);                
                _issuerSigningKey = new RsaSecurityKey(publicKey);
            }
            if (string.IsNullOrWhiteSpace(_settings.PemPrivateKey))
            {
                return;
            }
            using (RSA privateRsa = RSA.Create())
            {
                var privateKey = RSAKeys.ImportPublicKey(_settings.PemPublicKey);
                var privateKeyRsa = new RsaSecurityKey(privateKey.ExportParameters(true));
                _signingCredentials = new SigningCredentials(privateKeyRsa, SecurityAlgorithms.RsaSha256);
            }

            RSACryptoServiceProvider parm = new RSACryptoServiceProvider();
            parm.ExportParameters(true);
            log.Debug($"{MethodBase.GetCurrentMethod()} Obtaining RSA configuration from PEM. End!");
        }

        /// <summary>
        /// Initializes the hmac.
        /// </summary>
        private void InitializeHmac()
        {
            _issuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_settings.HmacSecretKey));
            _signingCredentials = new SigningCredentials(_issuerSigningKey, SecurityAlgorithms.HmacSha256); 
        }

        /// <summary>
        /// Initializes the JWT parameters.
        /// </summary>
        private void InitializeJwtParameters()
        {
            log.Debug($"{MethodBase.GetCurrentMethod()} Start...");
            _jwtHeader = new JwtHeader(_signingCredentials);
            Parameters = new TokenValidationParameters
            {
                ValidateAudience = _settings.ValidateAudience,
                ValidateLifetime = _settings.ValidateLifetime,
                ValidIssuer = _settings.Issuer,
                ValidAudience = _settings.Audience,
                IssuerSigningKey = _issuerSigningKey,    
                ValidateIssuerSigningKey = _settings.ValidateIssuerSigningKey,
                ValidateIssuer = _settings.ValidateIssuer                
            };

            log.Debug($"{MethodBase.GetCurrentMethod()} End!");
        }

        /// <summary>
        /// Creates the specified user identifier.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns></returns>
        public JwtElement Create(string userId)
        {
            var nowUtc = DateTime.UtcNow;
            var expires = nowUtc.AddDays(3);
            var centuryBegin = new DateTime(1970, 1, 1);
            var exp = (long)(new TimeSpan(expires.Ticks - centuryBegin.Ticks).TotalSeconds);
            var now = (long)(new TimeSpan(nowUtc.Ticks - centuryBegin.Ticks).TotalSeconds);
            var issuer = _settings.Issuer ?? string.Empty;
            var payload = new JwtPayload
            {
                {"sub", userId},
                {"unique_name", userId},
                {"iss", issuer},
                {"iat", now},
                {"nbf", now},
                {"exp", exp},
                {"jti", Guid.NewGuid().ToString("N")}
            };
            var jwt = new JwtSecurityToken(_jwtHeader, payload);
            var token = _jwtSecurityTokenHandler.WriteToken(jwt);

            return new JwtElement
            {
                Token = token,
                Expires = exp
            };
        }
    }
}
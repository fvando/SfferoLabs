﻿using INS.PT.CommonLibrary.Jwt.Interfaces;
using INS.PT.CommonLibrary.Jwt.Models;
using log4net;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;

namespace INS.PT.CommonLibrary.Jwt
{
    /// <summary>
    /// Initializes the Jwt Configuration for Azure Tokens.
    /// Based on an endpoint retreives all the public keys (HMAC, RSA) for token validation.
    /// </summary>
    /// <remarks>
    /// No need to store public Keys locally
    /// See the ReadMe (Jwt Configuration) notes installed with the Nugget, for configuration!
    /// </remarks>
    /// <seealso cref="INS.PT.CommonLibrary.Jwt.Interfaces.IJwtAzureADConfiguration" />
    public class JwtAzureADConfiguration : IJwtAzureADConfiguration
    {
        private readonly JwtSettings settings;
        private ILog log = LogManager.GetLogger(typeof(BaseCore));

        public JwtAzureADConfiguration(IOptions<JwtSettings> _settings)
        {
            settings = _settings.Value;
        }

        /// <summary>
        /// Authentications the specified options.
        /// </summary>
        /// <param name="options">The options.</param>
        public void Authentication(AuthenticationOptions options)
        {
            try
            {
                log.Debug($"{MethodBase.GetCurrentMethod()} Begin Options : {JsonConvert.SerializeObject(options)}");
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                log.Debug($"{MethodBase.GetCurrentMethod()} End Options: {JsonConvert.SerializeObject(options)}");
            }
            catch (Exception exc)
            {
                log.Error(exc);
                log.Debug($"{MethodBase.GetCurrentMethod()} AuthenticationOptions CONFIGURATION ERROR { exc.Message} Settings Value: {JsonConvert.SerializeObject(settings)}");
                throw;
            }
        }

        /// <summary>
        /// JWTs the bearer.
        /// </summary>
        /// <param name="bearer">The bearer.</param>
        public void JwtBearer(JwtBearerOptions bearer)
        {
            try
            {
                log.Debug($"{MethodBase.GetCurrentMethod()} Begin JwtBearerOptions : {JsonConvert.SerializeObject(bearer)}");
                // OpenIdConnectConfiguration set Up
                string stsDiscoveryEndpoint = settings.StsDiscoveryEndpoint;
                var proxyAvailable = !string.IsNullOrEmpty(settings?.ProxySettings?.Address) && !string.IsNullOrEmpty(settings?.ProxySettings?.Port);

                HttpClient httpClient = null;
                if (proxyAvailable)
                {
                    HttpClientHandler httpClientHandler = new HttpClientHandler();
                    httpClientHandler.Proxy = new WebProxy(string.Format("{0}:{1}", settings.ProxySettings.Address, settings.ProxySettings.Port));
                    httpClient = new HttpClient(handler: httpClientHandler, disposeHandler: true);
                }

                log.Debug($"{MethodBase.GetCurrentMethod()} HTTP CLIENT : {JsonConvert.SerializeObject(httpClient)}");

                var configManager = proxyAvailable ? new ConfigurationManager<OpenIdConnectConfiguration>(stsDiscoveryEndpoint, new OpenIdConnectConfigurationRetriever(), httpClient) :
                    new ConfigurationManager<OpenIdConnectConfiguration>(stsDiscoveryEndpoint, new OpenIdConnectConfigurationRetriever()); 

                OpenIdConnectConfiguration config = configManager.GetConfigurationAsync().Result;

                var json = JsonConvert.SerializeObject(config);
                log.Debug($"Azure Public Keys: {json}");

                bearer.RequireHttpsMetadata = false;
                bearer.SaveToken = false;
                bearer.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters()
                {
                    IssuerSigningKeys = config.SigningKeys,
                    ValidateLifetime = settings.ValidateLifetime,
                    ValidateAudience = settings.ValidateAudience,
                    ValidateIssuer = settings.ValidateIssuer,
                    ValidAudiences = settings.ValidAudiences,
                    ValidIssuers = settings.ValidIssuers,
                    ValidateIssuerSigningKey = settings.ValidateIssuerSigningKey
                };

                log.Debug($"{MethodBase.GetCurrentMethod()} End JwtBearerOptions : {JsonConvert.SerializeObject(bearer)}");
            }
            catch (Exception exc)
            {
                log.Debug($"{MethodBase.GetCurrentMethod()} JwtBearerOptions CONFIGURATION ERROR Settings Value: {JsonConvert.SerializeObject(settings)}");
                log.Error(exc);
                throw;
            }
        }

        /// <summary>
        /// Sets the configuration renewal.
        /// </summary>
        /// <param name="options">The options.</param>
        public void SetConfigurationRenewal(JwtBearerOptions bearer)
        {
            try
            {
                log.Debug($"{MethodBase.GetCurrentMethod()} Begin JwtBearerOptions(Renewal): {JsonConvert.SerializeObject(bearer)}");
                var interval = (settings.PublicKeysRenewalInterval != 0 && settings.PublicKeysRenewalInterval > 0) ? settings.PublicKeysRenewalInterval : 2;

                log.Debug($"{MethodBase.GetCurrentMethod()} PublicKeysRenewalInterval - Configured Value {interval} hours!");
                log.Debug($"{MethodBase.GetCurrentMethod()} PublicKeysRenewalInterval - Value applied {interval} hours!");

                if (bearer.ConfigurationManager is ConfigurationManager<OpenIdConnectConfiguration> manager)
                {
                    manager.AutomaticRefreshInterval = TimeSpan.FromHours(interval);
                }

                log.Debug($"{MethodBase.GetCurrentMethod()} End JwtBearerOptions(Renewal): {JsonConvert.SerializeObject(bearer)}");
            }
            catch (Exception exc)
            {
                log.Error(exc);
                log.Debug($"{MethodBase.GetCurrentMethod()} JwtBearerOptions CONFIGURATION ERROR { exc.Message} Settings Value: {JsonConvert.SerializeObject(settings)}");
                throw;
            }
        }
    }
}
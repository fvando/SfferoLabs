﻿using Swashbuckle.AspNetCore.Swagger;
using System.Collections.Generic;
using Swashbuckle.AspNetCore.SwaggerGen;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;

namespace INS.PT.CommonLibrary.Jwt
{
    public class SwaggerJwtHelper
    {
        /// <summary>
        /// Configures the swagger JWT token.
        /// </summary>
        /// <param name="options">The options.</param>
        public static void ConfigureSwaggerJwtToken(SwaggerGenOptions options)
        {
            //Add Swagger Authentication            
            options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
            {
                Description = "JWT Authorization header using the Bearer scheme. Example: \"Bearer {token}\"",
                Name = "Authorization",
                In = ParameterLocation.Header,
                Type = SecuritySchemeType.ApiKey,
                Scheme = "oauth2"
            });

            options.AddSecurityRequirement(new OpenApiSecurityRequirement()
                  {
                    {
                      new OpenApiSecurityScheme
                      {
                        Reference = new OpenApiReference
                          {
                            Type = ReferenceType.SecurityScheme,
                            Id = "Bearer"
                          },
                          Scheme = "oauth2",
                          Name = "Bearer",
                          In = ParameterLocation.Header,
                        },
                        new List<string>()
                      }
                    });
        }
    }
}

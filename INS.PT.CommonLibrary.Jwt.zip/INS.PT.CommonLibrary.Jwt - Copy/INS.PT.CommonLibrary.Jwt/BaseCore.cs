﻿namespace INS.PT.CommonLibrary.Jwt
{
    internal class BaseCore
    {
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using System.Text;

namespace INS.PT.CommonLibrary.Jwt.Utils
{
    public static class EnumsUtils
    {
        public static string ToDescription(this Enum value)
        {
            var atts = value.GetType().GetField(value + "").GetCustomAttributes(typeof(DescriptionAttribute), false);
            return atts != null && atts.Length > 0 ? (atts[0] as DescriptionAttribute).Description : value + "";
        }

        public static string ToAmbientValue(this Enum value)
        {
            var atts = value.GetType().GetField(value + "").GetCustomAttributes(typeof(AmbientValueAttribute), false);
            return atts != null && atts.Length > 0 && (atts[0] as AmbientValueAttribute).Value is string ? (string)(atts[0] as AmbientValueAttribute).Value : value + "";
        }

        /// <summary>
        ///  Get Enum from Description Attribute.
        /// </summary>
        /// <typeparam name="T">Type of Enum</typeparam>
        /// <param name="description">Description from DescriptiponAttribute</param>
        /// <param name="throwException">Flag to indicate if throw exception in case of description not found, 
        /// if false and description not found returns default enum</param>
        /// <returns>Type T Enum</returns>
        public static T GetEnumValueFromDescription<T>(string description, bool throwException)
        {
            foreach (FieldInfo fi in typeof(T).GetFields())
            {
                var atts = fi.GetCustomAttributes(typeof(DescriptionAttribute), false);
                if (atts != null && atts.Length > 0 && ((DescriptionAttribute)atts[0]).Description == description)
                    return (T)fi.GetRawConstantValue();
            }

            if (throwException)
                throw new ArgumentException(string.Format("'{0}' Not Found for Enum {1}", description, typeof(T).Name));
            else
                return default(T);
        }

        /// <summary>
        ///  Get Enum from AmbientValue Attribute.
        /// </summary>
        /// <typeparam name="T">Type of Enum</typeparam>
        /// <param name="ambientValue">Ambiente Value from AmbientValue</param>
        /// <param name="throwException">Flag to indicate if throw exception in case of description not found, 
        /// if false and description not found returns default enum</param>
        /// <returns>Type T Enum</returns>
        public static T GetEnumValueFromAmbientValue<T>(string ambientValue, bool throwException)
        {
            foreach (FieldInfo fi in typeof(T).GetFields())
            {
                var atts = fi.GetCustomAttributes(typeof(AmbientValueAttribute), false);
                if (atts != null && atts.Length > 0 && ((AmbientValueAttribute)atts[0]).Value.ToString() == ambientValue)
                    return (T)fi.GetRawConstantValue();
            }

            if (throwException)
                throw new ArgumentException(string.Format("'{0}' Not Found for Enum {1}", ambientValue, typeof(T).Name));
            else
                return default(T);
        }

        public static T GetEnumFromValue<T>(string enumValue, bool throwException)
        {
            try
            {
                T value = (T)Enum.Parse(typeof(T), enumValue, true);
                return value;
            }
            catch
            {
                if (throwException)
                    throw new Exception(string.Format("'{0}' Not Found for Enum {1}", enumValue, typeof(T).Name));

                return default(T);
            }
        }
    }
}

﻿using INS.PT.CommonLibrary.Jwt.Enums;
using INS.PT.CommonLibrary.Jwt.Interfaces;
using log4net;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Reflection;
using System.Security.Claims;
using System.Text;
using static INS.PT.CommonLibrary.Jwt.Enums.EnumClaims;

namespace INS.PT.CommonLibrary.Jwt.Utils
{
    public static class TokenUtils
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        #region Public Methods

        /// <summary>
        /// Gets the claim.
        /// </summary>
        /// <param name="claimType">Type of the claim.</param>
        /// <param name="_token">The token.</param>
        /// <returns></returns>
        /// <exception cref="Exception">Unreadble Token</exception>
        public static string GetClaim(EnumClaim claim, string _token)
        {
            return GetClaimValue(claim.ToAmbientValue(), _token);
        }

        /// <summary>
        /// Gets the claim.
        /// </summary>
        /// <param name="claim">The claim.</param>
        /// <param name="_token">The token.</param>
        /// <returns></returns>
        public static string GetClaim(string claim, string _token)
        {
            return GetClaimValue(claim, _token);
        }

        /// <summary>
        /// Gets the token claims (payload).
        /// </summary>
        /// <param name="_token">The token.</param>
        /// <returns></returns>
        /// <exception cref="System.Exception">Unreadble Token</exception>
        public static IEnumerable<Claim> GetPayload(string _token)
        {
            try
            {
                log.Debug($"{MethodBase.GetCurrentMethod()} Token: {_token}");
                var jwtHandler = new JwtSecurityTokenHandler();
                var jwtInput = _token;

                jwtInput = jwtInput.Replace("Bearer", string.Empty).Trim();
                log.Debug($"{MethodBase.GetCurrentMethod()} Token with no 'Bearer': {jwtInput}");

                //Check if readable token (string is in a JWT format)
                var readableToken = jwtHandler.CanReadToken(jwtInput);
                if (readableToken)
                {
                    var token = jwtHandler.ReadJwtToken(jwtInput);

                    //Extract the headers of the JWT
                    var headers = token.Header;

                    //Extract the payload of the JWT
                    IEnumerable<Claim> claims = token.Claims;

                    return claims;
                }
                else
                {
                    log.Debug($"Unreadble Token: {_token}");
                    throw new Exception("Unreadble Token");
                }
            }
            catch (Exception exc)
            {
                log.Debug(exc);
                throw;
            }
        }

        #endregion

        #region Private Methods

        private static string GetClaimValue(string claim, string _token)
        {
            var claimValue = string.Empty;
            try
            {
                log.Debug($"{MethodBase.GetCurrentMethod()} Token: {_token}");
                var jwtHandler = new JwtSecurityTokenHandler();
                var jwtInput = _token;
                jwtInput = jwtInput.Replace("Bearer", string.Empty).Trim();
                log.Debug($"{MethodBase.GetCurrentMethod()} Token with no 'Bearer': {jwtInput}");

                //Check if readable token (string is in a JWT format)
                var readableToken = jwtHandler.CanReadToken(jwtInput);
                if (readableToken)
                {
                    var token = jwtHandler.ReadJwtToken(jwtInput);

                    //Extract the headers of the JWT
                    var headers = token.Header;

                    //Extract the payload of the JWT
                    IEnumerable<Claim> claims = token.Claims;
                    claimValue = claims.FirstOrDefault(c => c.Type == claim)?.Value;
                }
                else
                {
                    log.Debug($"Unreadble Token: {_token}");
                    return string.Empty;
                }
            }
            catch (Exception exc)
            {
                log.Debug(exc);
                claimValue = string.Empty;
            }

            return claimValue;
        }
        #endregion
    }
}

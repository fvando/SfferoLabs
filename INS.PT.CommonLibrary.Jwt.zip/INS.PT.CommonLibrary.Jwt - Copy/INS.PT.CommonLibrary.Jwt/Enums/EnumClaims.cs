﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace INS.PT.CommonLibrary.Jwt.Enums
{
    public class EnumClaims
    {
        public enum EnumClaim
        {
            /// <summary>
            /// Issuer of the JWT (iss)
            /// </summary>         
            [AmbientValue("iss")]
            Issuer,
            /// <summary>
            /// Subject of the JWT(the user) (sub)
            /// </summary>         
            [AmbientValue("sub")]
            Subject,
            /// <summary>
            /// Recipient for which the JWT is intended (aud)
            /// </summary>         
            [AmbientValue("aud")]
            Audience,
            /// <summary>
            /// Time after which the JWT expires (exp)
            /// </summary>         
            [AmbientValue("exp")]
            ExpirationTime,
            /// <summary>
            /// Time before which the JWT must not be accepted for processing (nbf)
            /// </summary>         
            [AmbientValue("nbf")]
            NotBeforeTime,
            /// <summary>
            /// Time at which the JWT was issued; can be used to determine age of the JWT (iat)
            /// </summary>
            [AmbientValue("iat")]
            IssuedAtTime,
            /// <summary>
            /// Unique identifier; can be used to prevent the JWT from being replayed(allows a token to be used only once) (jti)
            /// </summary>
            [AmbientValue("jti")]
            JWTID,
            /// <summary>
            /// User's Full Name (name)
            /// </summary>
            [AmbientValue("name")]
            FullName,
            /// <summary>
            /// User's Given name(s) or first name(s) (given_name)
            /// </summary>
            [AmbientValue("given_name")]
            GivenName,
            /// <summary>
            /// IP Address (ipaddr)
            /// </summary>
            [AmbientValue("ipaddr")]
            IpAddress,
            /// <summary>
            /// User's username (upn). Microsoft private claim that is of the form user@domain
            /// </summary>
            [AmbientValue("upn")]
            UserPrincipalName,
            /// <summary>
            /// Value for the user that may not be unique within the tenant (unique_name)
            /// </summary>
            [AmbientValue("unique_name")]
            UniqueName,
            /// <summary>
            ///  Email from guests / Ageas company users - Authentication with guest / upn email
            /// </summary>         
            [AmbientValue("email")]
            Email,
            /// <summary>
            /// PreferredUserName
            /// </summary>
            [AmbientValue("preferred_username")]
            PreferredUserName
        }
    }
}
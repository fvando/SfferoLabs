using INS.PT.CommonLibrary.Jwt;
using INS.PT.CommonLibrary.Jwt.Enums;
using INS.PT.CommonLibrary.Jwt.Handlers;
using INS.PT.CommonLibrary.Jwt.Models;
using INS.PT.CommonLibrary.Jwt.Utils;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Text;
using Xunit;

namespace INS.PT.XUnitTest
{
    public class TokenJwtTest
    {        
        string _token = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6ImtnMkxZczJUMENUaklmajRydDZKSXluZW4zOCJ9.eyJhdWQiOiJlNTFlODEzNC05NmU5LTQ5YTktYmRlMy1hZjJhMzYwYTY1YTkiLCJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vZTdmOWQ2OWMtMTNmMy00NTdjLWEwNGMtZjU1NWMxMTM0ZmE0L3YyLjAiLCJpYXQiOjE2MDQzMDk1NjcsIm5iZiI6MTYwNDMwOTU2NywiZXhwIjoxNjA0MzEzNDY3LCJhaW8iOiJBVFFBeS84UkFBQUE4UDZXejdEZmZhRE1TdHJ2OEJ1RThIWWlIL1RBWVRSSTM4M2hQdG43MUxqeWhSUld4RjA3R1dHZ3N3ZjdCc3VkIiwiZW1haWwiOiJ2YW5kby5tb3JlaXJhLkV4dGVybm9AYWdlYXMucHQiLCJuYW1lIjoiVmFuZG8gTW9yZWlyYSAoRXh0ZXJubykiLCJvaWQiOiIxMmJhMDVmNS02YzJjLTQ4YmQtOTA5MS1iMDk3NDQ3NzY5NGQiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJ2YW5kby5tb3JlaXJhLkV4dGVybm9AYWdlYXMucHQiLCJyaCI6IjAuQVI4QW5OYjU1X01UZkVXZ1RQVlZ3Uk5QcERTQkh1WHBscWxKdmVPdktqWUtaYWtmQURnLiIsInN1YiI6ImJoTldhc1V0SFRjNDFPSGwxXzNmeS1vbGpId25oa2N3bUtpYjVzZERWU3ciLCJ0aWQiOiJlN2Y5ZDY5Yy0xM2YzLTQ1N2MtYTA0Yy1mNTU1YzExMzRmYTQiLCJ1dGkiOiJyUjJmMjRCY3hrcUpvRzB0eVc0RUFBIiwidmVyIjoiMi4wIn0.OAiPZtoE37LFwPiuWSU6wHv-AhzEhyFHgclVQqV6ZkE_XkMhhUypMBLgYbnC29TITWSculT1xoLk13EG6ZVWPg5ISrkMAruVLUmhqV0hyPNJ86YRN5lmuqQSNCsWB1hGzidCPUSa3S-clk_j9kQdXgM67S76pDQGzo3QgBzW0fijtTHF3jZvT6sH-6RcWUKU_x30kDe9taIQf2MbpT2k0m7UQZ7Y42vpwVSYCmJIQpkn4sVRWEv8Q6bol4cv77xvI6ddJaDN57P-GJ83MaU8ar__9tfwUbExs2uc5YlOcvetCqf4VIAQVs90nj45U_LJPfLIgMW6IRHvaeN18nNLFA";

        [Fact]
        public void JwtContextLoad()
        {
            JwtSettings jwSettings = new JwtSettings();
            jwSettings.PemPublicKey = "-----BEGIN PUBLIC KEY-----\r\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAoRRQG+ib30x09eWtDpL0wWahA+hgjc0lWoQU4lwBFjXV2PfPImiAvwxOxNG34Mgnw3K9huBYLsrvOQAbMdBmE8lwz8DFKMWqHqoH3xSqDGhIYFobQDiVRkkecpberH5hqJauSD7PiwDBSQ/RCDIjb0SOmSTpZR97Ws4k1z9158VRf4BUbGjzVt4tUAz/y2cI5JsXQfcgAPB3voP8eunxGwZ/iM8evw3hUOw7+nuiPyts7HSkvV6GMwrXfOymY/w07mYxw/2LnKInfsWBtcRIDG+Nrsj237LgtBhK7TkzuVrguq//+bkDwwF3qTRXGAX9KrwY4huRxDRslMIg30HqgwIDAQAB\r\n-----END PUBLIC KEY-----";
            jwSettings.PemPrivateKey = "";
            jwSettings.UsePemFormat = true;
            jwSettings.UseRsa = true;            
            jwSettings.ValidateLifetime = false;

            // JWT
            IOptions<JwtSettings> settings = Options.Create(jwSettings);
            var token = new JwtHandler(settings);

            Assert.NotNull(token);
        }

        [Fact]
        public void GetTokenClaimPreferredUserName()
        {
            var result = TokenUtils.GetClaim(EnumClaims.EnumClaim.PreferredUserName, _token);
            Assert.NotNull(result);
        }

        [Fact]
        public void GetTokenClaimUserPrincipalName()
        {
            var result = TokenUtils.GetClaim(EnumClaims.EnumClaim.UserPrincipalName, _token);
            Assert.NotNull(result);
        }

        [Fact]
        public void GetTokenClaimEmail()
        {
            var result = TokenUtils.GetClaim(EnumClaims.EnumClaim.Email, _token);
            Assert.NotNull(result);
        }


        [Fact]
        public void ReadToken()
        {
            var result = TokenUtils.GetPayload(_token);
            Assert.NotNull(result);
        }

        [Fact]
        public void JwtContextUsingKeyCollection()
        {            
            JwtSettings jwSettings = new JwtSettings();
            jwSettings.StsDiscoveryEndpoint = "https://login.microsoftonline.com/common/v2.0/.well-known/openid-configuration";
            jwSettings.ValidateLifetime = false;
            jwSettings.ProxySettings = new ProxySettings { Address = "", Port = "" };
            jwSettings.ValidateLifetime = false;
            jwSettings.ValidateAudience = true;
            jwSettings.ValidateIssuer = true;            
            jwSettings.ValidAudiences = new [] { "9ae0049c-60d1-493d-8432-ee0b93c077f2", "e51e8134-96e9-49a9-bde3-af2a360a65a9", "36aed229-6567-4473-ad40-408305e25eec" };
            jwSettings.ValidIssuers = new[] { "https://sts.windows.net/e7f9d69c-13f3-457c-a04c-f555c1134fa4/" };

            IOptions<JwtSettings> settings = Options.Create(jwSettings);
            JwtAzureADConfiguration jwt = new JwtAzureADConfiguration(settings);
            JwtBearerOptions bearer = new JwtBearerOptions();
            AuthenticationOptions option = new AuthenticationOptions();
            jwt.Authentication(option);
            jwt.JwtBearer(bearer);
            jwt.SetConfigurationRenewal(bearer);

            Assert.NotNull(option.DefaultAuthenticateScheme);
            Assert.NotNull(bearer.TokenValidationParameters);            
        }
    }
}


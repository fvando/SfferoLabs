﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace XUnitTestINS.PT.WebAPI.TestValues
{
    public class TestInvalidNameDataGenerator : IEnumerable<object[]>
    {
        private readonly List<object[]> _data = new List<object[]>
            {
                new object[] { "Manuel Santos", null, null },
                new object[] { "Manuel Santos", "H", null },
                new object[] { "Manuel Santos", null, new DateTime(1975, 05, 03) },
                new object[] { null, "H", null },
                new object[] { null, "H", new DateTime(1975, 05, 03) },
                new object[] { null, null, new DateTime(1975, 05, 03) },
            };

        public IEnumerator<object[]> GetEnumerator() => _data.GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();        
    }
}

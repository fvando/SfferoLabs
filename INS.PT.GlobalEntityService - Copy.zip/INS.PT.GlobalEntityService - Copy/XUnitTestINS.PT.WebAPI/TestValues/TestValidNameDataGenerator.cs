﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace XUnitTestINS.PT.WebAPI.TestValues
{
    public class TestValidNameDataGenerator : IEnumerable<object[]>
    {
        private readonly List<object[]> _data = new List<object[]>
            {
                new object[] { "Manuel Santos", "H", new DateTime(1975, 05, 03) },
            };

        public IEnumerator<object[]> GetEnumerator() => _data.GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}

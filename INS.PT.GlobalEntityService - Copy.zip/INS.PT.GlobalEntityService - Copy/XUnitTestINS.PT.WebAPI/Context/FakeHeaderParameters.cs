﻿using INS.PT.WebAPI.Models;
using Microsoft.AspNetCore.Http;
using System;

namespace XUnitTestINS.PT.WebAPI.Context
{
    internal class FakeHeaderParameters : IHttpContextAccessor
    {
        private static readonly INS.PT.WebAPI.IdTranslates.CodesMapping _codesMapping = new FakeCodesMapping();

        private static readonly HeaderParameters defaultHeaderParameters = new HeaderParameters(_codesMapping)
        {
            IdCompany = "AGEAS",
            IdNetwork = "AGEAS",
            BsSolution = "DUCKCREEK",
            BsUser = "TESTE"
        };

        internal HeaderParameters headerParameters { get; set; }

        public FakeHeaderParameters(HeaderParameters headerParameters)
        {
            this.headerParameters = headerParameters ?? defaultHeaderParameters;
        }

        public HttpContext HttpContext
        {
            get
            {
                var context = new DefaultHttpContext();

                context.Request.Headers[nameof(headerParameters.IdCompany)] = headerParameters.IdCompany;
                context.Request.Headers[nameof(headerParameters.IdNetwork)] = headerParameters.IdNetwork;
                context.Request.Headers[nameof(headerParameters.BsSolution)] = headerParameters.BsSolution;
                context.Request.Headers[nameof(headerParameters.BsUser)] = headerParameters.BsUser;

                return context;
            }

            set => throw new NotImplementedException();
        }
    }
}
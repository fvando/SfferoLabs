﻿using INS.PT.WebAPI.BrokerCalls;
using INS.PT.WebAPI.IdTranslates;
using INS.PT.WebAPI.Models;
using Microsoft.Extensions.Configuration;
using Moq;

namespace XUnitTestINS.PT.WebAPI.Context
{
    public class FakeCodesMapping : CodesMapping
    {
        private static Mock<IBrokerClient> _mockBrokerCalls = new Mock<IBrokerClient>();
        private static IConfiguration _fakeSettings = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();
        private static Mock<IRdmHelper> _mockRdmHelper = new Mock<IRdmHelper>();

        public FakeCodesMapping() : base(_mockBrokerCalls.Object, _fakeSettings, _mockRdmHelper.Object)
        {
        }

        protected override bool IsMappingsLoaded(string idList)
        {
            return true;
        }

        public override bool TryGetElementFromIdElement(string idList, string value, out CodeMapping element)
        {
            // for header validation return always ok for element in list
            if (string.Compare(idList, HeaderParameters.ListIdForCompanies, System.StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                element = new CodeMapping();
                return true;
            }

            return base.TryGetElementFromIdElement(idList, value, out element);
        }
    }
}

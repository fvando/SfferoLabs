﻿using INS.PT.WebAPI;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Interface.Service;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Elements;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;
using Moq;
using System.Collections.Generic;
using Xunit;
using XUnitTestINS.PT.WebAPI.Context;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class SearchEntityRepositoryTests
    {
        private readonly Mock<ISourceAndResultsMapping> _mockMapping;
        private readonly Mock<IMasterService> _mockmasterService;
        private readonly Mock<ICogenEntities> _mockcogenEntitiesService;

        private readonly SearchEntityInput _validParameters;
        private readonly SearchEntityInput _invalidParameters;

        public SearchEntityRepositoryTests()
        {
            _validParameters = new SearchEntityInput { IdEntity = "validTestId" };
            _invalidParameters = new SearchEntityInput { IdEntity = "invalidId" };


            _mockmasterService = new Mock<IMasterService>();

            _mockmasterService.Setup(x => x.SearchEntityAsync(It.IsAny<HeaderParameters>(), "DUCKCREEK", _validParameters
                )).ReturnsAsync(new SearchEntityOutput
                {
                    MatchedEntities = new List<SimpleEntity>
                    {
                        new SimpleEntity
                        {
                            IdEntity = "testEntity"
                        }
                    }
                });
            _mockmasterService.Setup(x => x.SearchEntityAsync(It.IsAny<HeaderParameters>(), "DUCKCREEK", _invalidParameters
                )).ReturnsAsync(() => { throw new CanonicalException(); });


            _mockcogenEntitiesService = new Mock<ICogenEntities>();


            _mockMapping = new Mock<ISourceAndResultsMapping>();
            _mockMapping.SetupGet(x => x.IdSource).Returns("DUCKCREEK");
            _mockMapping.SetupGet(x => x.IdSystem).Returns("MASTERENTITY");
        }


        [Fact]
        public void SearchEntity_InvalidParameters()
        {
            // Arrange
            var repository = new SearchEntityRepository(_mockmasterService.Object, _mockMapping.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new HeaderParameters(new FakeCodesMapping())
            {
                IdCompany = "AGEAS",
                IdNetwork = "AGEAS",
                BsSolution = "DUCKCREEK",
                BsUser = "TESTE"
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(() => repository.SearchEntityAsync(headerParameters, _invalidParameters));
        }



        [Fact]
        public async System.Threading.Tasks.Task SearchEntity_ValidParametersAsync()
        {
            // Arrange
            var repository = new SearchEntityRepository(_mockmasterService.Object, _mockMapping.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new HeaderParameters(new FakeCodesMapping())
            {
                IdCompany = "AGEAS",
                IdNetwork = "AGEAS",
                BsSolution = "DUCKCREEK",
                BsUser = "TESTE"
            };


            // Act
            var result = await repository.SearchEntityAsync(headerParameters, _validParameters);


            //  Assert
            Assert.NotNull(result);
            Assert.True(result.MatchedEntities.Count > 0);
        }
    }
}

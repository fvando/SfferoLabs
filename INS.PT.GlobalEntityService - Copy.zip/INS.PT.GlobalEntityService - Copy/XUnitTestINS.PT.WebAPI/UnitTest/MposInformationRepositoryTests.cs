﻿using AutoMapper;
using INS.PT.WebAPI;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Repository;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Tecnisys;
using Xunit;
using XUnitTestINS.PT.WebAPI.Context;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class MposInformationRepositoryTests
    {
        private readonly Mock<IMasterEntity> _mockmasterEntityService;
        private readonly Mock<ISourceAndResultsMapping> _mockMapping;
        private readonly IMapper _mapper;

        public MposInformationRepositoryTests()
        {
            _mockmasterEntityService = new Mock<IMasterEntity>();

            _mockmasterEntityService.Setup(x => x.GetMposDataAsync(
                It.IsAny<GetMposDataRequest>()
                ))
                .Returns(ValidGetMposDataAsync());


            _mockMapping = new Mock<ISourceAndResultsMapping>();
            _mockMapping.SetupGet(x => x.IdSource).Returns("DUCKCREEK");
            _mockMapping.SetupGet(x => x.IdSystem).Returns("MASTERENTITY");


            _mapper = null;
            var serviceCollection = new Microsoft.Extensions.DependencyInjection.ServiceCollection();
            Startup.Setups.SetupMappings(serviceCollection);

            foreach (var service in serviceCollection)
            {
                if (service.ImplementationInstance is IMapper mapper)
                {
                    _mapper = mapper;
                    break;
                }
            }
        }



        private async Task<GetMposDataResponse> ValidGetMposDataAsync()
        {
            return await Task.Run(() => new GetMposDataResponse { GetMposDataResult = Fake_ValidResponse() });
        }

        private async Task<GetMposDataResponse> InvalidGetMposDataAsync()
        {
            return await Task.Run(() => new GetMposDataResponse { GetMposDataResult = Fake_InvalidResponse() });
        }

        private async Task<GetMposDataResponse> EmptyGetMposDataAsync()
        {
            return await Task.Run(() => new GetMposDataResponse { GetMposDataResult = Fake_EmptyResponse() });
        }

        private ResponseMposData Fake_ValidResponse()
        {
            var result = new ResponseMposData
            {
                EntitiesInformation = new []
                {
                    new MposData
                    {
                        dni = "testDni",
                        vatNumber = "testVat",
                        phone = ""
                    },
                    new MposData
                    {
                        dni = "testDni2",
                        vatNumber = "testVat",
                        phone = "+351912912912"
                    },
                    new MposData
                    {
                        dni = "testDni3",
                        vatNumber = "testVat",
                        phone = "00351912912912"
                    },
                    new MposData
                    {
                        dni = "testDni4",
                        vatNumber = "testVat",
                        phone = "00351212912912"
                    },
                    new MposData
                    {
                        dni = "testDni5",
                        vatNumber = "testVat",
                        phone = "+351212912912"
                    },
                    new MposData
                    {
                        dni = "testDni6",
                        vatNumber = "testVat",
                        phone = "+18855212912912"
                    },
                    new MposData
                    {
                        dni = "testDni10",
                        vatNumber = "testVat",
                        phone = "912912912"
                    }
                },

                Errors = new ServiceError[] { }
            };

            return result;
        }

        private ResponseMposData Fake_InvalidResponse()
        {
            var result = new ResponseMposData
            {
                EntitiesInformation = new[]
                {
                    new MposData
                    {
                        dni = "testDni",
                        vatNumber= "testVat",
                    }
                },

                Errors = new ServiceError[]
                {
                    new ServiceError
                    {
                        Code = "testError",
                        Message = "The operation has an error.",
                        Type = "APPLICATION"
                    }
                }
            };

            return result;
        }

        private ResponseMposData Fake_EmptyResponse()
        {
            var result = new ResponseMposData
            {
                EntitiesInformation = new MposData[] { },

                Errors = new ServiceError[] { }
            };

            return result;
        }



        [Fact]
        public void GetMposInformationAsync_Parameters_Null()
        {
            // Arrange
            var repository = new MposInformationRepository(_mockmasterEntityService.Object, _mockMapping.Object, _mapper);

            // Act and Assert
            Assert.ThrowsAsync<ArgumentNullException>(() => repository.GetMposInformationAsync(null, It.IsAny<MposInformationInput>()));
        }

        [Fact]
        public void GetMposInformationAsync_Error()
        {
            // Arrange
            _mockmasterEntityService.Setup(x => x.GetMposDataAsync(
                It.IsAny<GetMposDataRequest>()
                ))
                .Returns(InvalidGetMposDataAsync());
            var repository = new MposInformationRepository(_mockmasterEntityService.Object, _mockMapping.Object, _mapper);
            var headerParameters = new HeaderParameters(new FakeCodesMapping())
            {
                BsSolution = "duck",
                BsUser = "\\bs\\duckd",
                IdCompany = "AGEAS",
                IdNetwork = "AGEAS"
            };

            // Act and Assert
            Assert.ThrowsAsync<CanonicalException>(() => repository.GetMposInformationAsync(headerParameters, It.IsAny<MposInformationInput>()));
        }


        [Fact]
        public async Task GetMposInformationAsync_EmptyAsync()
        {
            // Arrange
            _mockmasterEntityService.Setup(x => x.GetMposDataAsync(
                It.IsAny<GetMposDataRequest>()
                ))
                .Returns(EmptyGetMposDataAsync());
            var repository = new MposInformationRepository(_mockmasterEntityService.Object, _mockMapping.Object, _mapper);
            var headerParameters = new HeaderParameters(new FakeCodesMapping())
            {
                BsSolution = "duck",
                BsUser = "\\bs\\duckd",
                IdCompany = "AGEAS",
                IdNetwork = "AGEAS"
            };
            var parameters = new MposInformationInput
            {
                EntitiesIds = new List<string>
                { "testId", "oneMoreId" }
            };

            // Act
            var result = await repository.GetMposInformationAsync(headerParameters, parameters);

            // Assert
            Assert.Empty(result);
        }

        [Fact]
        public async Task GetMposInformationAsync_ValidAsync()
        {
            // Arrange
            var repository = new MposInformationRepository(_mockmasterEntityService.Object, _mockMapping.Object, _mapper);
            var headerParameters = new HeaderParameters(new FakeCodesMapping())
            {
                BsSolution = "duck",
                BsUser = "\\bs\\duckd",
                IdCompany = "AGEAS",
                IdNetwork = "AGEAS"
            };
            var parameters = new MposInformationInput
            {
                EntitiesIds = new List<string>
                { "testId", "oneMoreId" }
            };

            // Act
            var result = await repository.GetMposInformationAsync(headerParameters, parameters);

            // Assert
            Assert.NotEmpty(result);
        }

        [Fact]
        public async Task MposInformationAsync_ValidPhonesAsync()
        {
            // Arrange
            var repository = new MposInformationRepository(_mockmasterEntityService.Object, _mockMapping.Object, _mapper);
            var headerParameters = new HeaderParameters(new FakeCodesMapping())
            {
                BsSolution = "duck",
                BsUser = "\\bs\\duckd",
                IdCompany = "AGEAS",
                IdNetwork = "AGEAS"
            };
            var parameters = new MposInformationInput
            {
                EntitiesIds = new List<string>
                { "testId", "oneMoreId" }
            };

            // Act
            var result = await repository.GetMposInformationAsync(headerParameters, parameters);

            // Assert
            Assert.NotEmpty(result);
            Assert.All(result, r => Assert.True(string.IsNullOrEmpty(r.PhoneNumber) || r.PhoneNumber.StartsWith('9')));
        }
    }
}

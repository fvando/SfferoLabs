﻿using AutoMapper;
using INS.PT.WebAPI;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Repository;
using Moq;
using System;
using System.Threading.Tasks;
using Tecnisys;
using Xunit;
using XUnitTestINS.PT.WebAPI.Context;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class LendersRepositoryTests
    {
        private readonly Mock<IMasterEntity> _mockmasterEntityService;
        private readonly Mock<ISourceAndResultsMapping> _mockMapping;
        private readonly IMapper _mapper;

        public LendersRepositoryTests()
        {
            _mockmasterEntityService = new Mock<IMasterEntity>();

            _mockmasterEntityService.Setup(x => x.GetCretidorEntitiesAsync(
                It.IsAny<GetCretidorEntitiesRequest>()
                ))
                .Returns(CretidorEntitiesAsync());


            _mockMapping = new Mock<ISourceAndResultsMapping>();
            _mockMapping.SetupGet(x => x.IdSource).Returns("DUCKCREEK");
            _mockMapping.SetupGet(x => x.IdSystem).Returns("MASTERENTITY");


            _mapper = null;
            var serviceCollection = new Microsoft.Extensions.DependencyInjection.ServiceCollection();
            Startup.Setups.SetupMappings(serviceCollection);

            foreach (var service in serviceCollection)
            {
                if (service.ImplementationInstance is IMapper mapper)
                {
                    _mapper = mapper;
                    break;
                }
            }
        }


        private async Task<GetCretidorEntitiesResponse> CretidorEntitiesAsync()
        {
            return await Task.Run(() => new GetCretidorEntitiesResponse
            {
                GetCretidorEntitiesResult = new ResponseCreditorEntities
                {
                    Entities = new CreditorEntity[]
                    {
                        new CreditorEntity
                        {
                            dni="idTest",
                            name="test name",
                            vatNumber="999111999"
                        }
                    },
                    Errors = new ServiceError[] { }
                }
            });
        }

        private async Task<GetCretidorEntitiesResponse> InvalidCretidorEntitiesAsync()
        {
            return await Task.Run(() => new GetCretidorEntitiesResponse
            {
                GetCretidorEntitiesResult = new ResponseCreditorEntities
                {
                    Entities = new CreditorEntity[] { },
                    Errors = new ServiceError[]
                    {
                        new ServiceError
                        {
                            Code ="testCode",
                            Message="test error message",
                            Type= "testErrorType"
                        }
                    }
                }
            });
        }

        private async Task<GetCretidorEntitiesResponse> EmptyCreditorEntitiesAsync()
        {
            return await Task.Run(() => new GetCretidorEntitiesResponse
            {
                GetCretidorEntitiesResult = new ResponseCreditorEntities
                {
                    Entities = new CreditorEntity[] { },
                    Errors = new ServiceError[] { }
                }
            });
        }





        [Fact]
        public void GetLendersAsync_Parameters_Null()
        {
            // Arrange
            var repository = new LendersRepository(_mockmasterEntityService.Object, _mockMapping.Object, _mapper);

            // Act and Assert
            Assert.ThrowsAsync<ArgumentNullException>(() => repository.GetLendersAsync(null));
        }

        [Fact]
        public void GetLendersAsync_Error()
        {
            // Arrange
            _mockmasterEntityService.Setup(x => x.GetCretidorEntitiesAsync(
                It.IsAny<GetCretidorEntitiesRequest>()
                ))
                .Returns(InvalidCretidorEntitiesAsync());
            var repository = new LendersRepository(_mockmasterEntityService.Object, _mockMapping.Object, _mapper);
            var headerParameters = new HeaderParameters(new FakeCodesMapping())
            {
                BsSolution = "duck",
                BsUser = "\\bs\\duckd",
                IdCompany = "AGEAS",
                IdNetwork = "AGEAS"
            };

            // Act and Assert
            Assert.ThrowsAsync<CanonicalException>(() => repository.GetLendersAsync(headerParameters));
        }

        [Fact]
        public async Task GetLendersAsync_EmptyAsync()
        {
            // Arrange
            _mockmasterEntityService.Setup(x => x.GetCretidorEntitiesAsync(
                It.IsAny<GetCretidorEntitiesRequest>()
                ))
                .Returns(EmptyCreditorEntitiesAsync());
            var repository = new LendersRepository(_mockmasterEntityService.Object, _mockMapping.Object, _mapper);
            var headerParameters = new HeaderParameters(new FakeCodesMapping())
            {
                BsSolution = "duck",
                BsUser = "\\bs\\duckd",
                IdCompany = "AGEAS",
                IdNetwork = "AGEAS"
            };

            // Act
            var result = await repository.GetLendersAsync(headerParameters);

            // Assert
            Assert.Empty(result);
        }

        [Fact]
        public async Task GetLendersAsync_ValidAsync()
        {
            // Arrange
            var repository = new LendersRepository(_mockmasterEntityService.Object, _mockMapping.Object, _mapper);
            var headerParameters = new HeaderParameters(new FakeCodesMapping())
            {
                BsSolution = "duck",
                BsUser = "\\bs\\duckd",
                IdCompany = "AGEAS",
                IdNetwork = "AGEAS"
            };

            // Act
            var result = await repository.GetLendersAsync(headerParameters);

            // Assert
            Assert.NotEmpty(result);
        }
    }
}

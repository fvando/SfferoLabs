﻿using INS.PT.WebAPI.Models;
using Moq;
using Xunit;
using System.Threading.Tasks;
using models = INS.PT.WebAPI.Models.Elements;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Repository;
using XUnitTestINS.PT.WebAPI.Context;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class GetEntityRepositoryTests
    {
        private readonly Mock<IMasterService> _mockmasterService;
        private readonly Mock<ISourceAndResultsMapping> _mockMapping;

        private const string _ValidVatNumber = "500123055";
        private const string _InvalidVatNumber = "222333999";


        public GetEntityRepositoryTests()
        {
            _mockmasterService = new Mock<IMasterService>();

            _mockmasterService.Setup(x => x.GetEntityAsync(It.IsAny<HeaderParameters>(), "duckTest", _ValidVatNumber
                )).ReturnsAsync(new models.Entity
                {
                    IdEntity = "10592272",
                    VatNumber = _ValidVatNumber,
                    Type = new models.Entity.EntityType
                    {
                        Company = new models.Organization
                        {
                            CompanyName = "test name",
                        }
                    }
                });
            _mockmasterService.Setup(x => x.GetEntityAsync(It.IsAny<HeaderParameters>(), "duckTest", _InvalidVatNumber
                )).ReturnsAsync(() => {throw new CanonicalException(); });


            _mockMapping = new Mock<ISourceAndResultsMapping>();
            _mockMapping.SetupGet(x => x.IdSource).Returns("duckTest");
            _mockMapping.SetupGet(x => x.IdSystem).Returns("MASTERENTITY");
        }




        [Fact]
        public async Task EntityType_Get_ValidAsync()
        {
            // Arrange
            var repository = new GetEntityRepository(_mockMapping.Object, _mockmasterService.Object);
            var headerParameters = new HeaderParameters (new FakeCodesMapping()) { BsSolution = "TEST" };

            // Act
            var result = await repository.EntityByVatNumberAsync(headerParameters, _ValidVatNumber);


            // Assert
            Assert.NotNull(result);
            var entity = Assert.IsType<models.Entity>(result);
            Assert.Equal(_ValidVatNumber, entity.VatNumber);
        }

        [Fact]
        public async Task EntityType_Get_InvalidAsync()
        {
            // Arrange
            var repository = new GetEntityRepository(_mockMapping.Object, _mockmasterService.Object);
            var headerParameters = new HeaderParameters (new FakeCodesMapping()) { BsSolution = "TEST" };

            // Act and Assert
            await Assert.ThrowsAsync<CanonicalException>(
                () => repository.EntityByVatNumberAsync(headerParameters, _InvalidVatNumber));
        }

    }
}

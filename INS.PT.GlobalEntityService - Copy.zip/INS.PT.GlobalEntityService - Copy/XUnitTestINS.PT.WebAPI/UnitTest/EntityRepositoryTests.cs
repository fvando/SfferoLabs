﻿using INS.PT.WebAPI;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Input;
using Moq;
using Xunit;
using System.Threading.Tasks;
using models = INS.PT.WebAPI.Models.Elements;
using System.Collections.Generic;
using System;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Interface;
using XUnitTestINS.PT.WebAPI.Context;
using INS.PT.WebAPI.Interface.Service;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class EntityRepositoryTests
    {
        private readonly Mock<IMasterService> _mockmasterService;
        private readonly Mock<ICogenEntities> _mockcogenEntitiesService;
        private readonly Mock<IAmlService> _mockAmlService;
        private readonly Mock<ISourceAndResultsMapping> _mockMapping;

        public EntityRepositoryTests()
        {
            _invalidEntitiesInput = new EntitiesInput
            {
                IdEntity = "rui"
            };

            _validEntitiesInput = new EntitiesInput
            {
                IdEntity = "10592272"
            };

            _deleteValidEntitiesInput = new EntitiesInput
            {
                IdEntity = "2233"
            };


            _mockmasterService = new Mock<IMasterService>();

            _mockmasterService.Setup(x => x.GetEntityAsync(It.IsAny<HeaderParameters>(), "duckTest",
                _validEntitiesInput
                )).Returns(ValidGetEntityAsync());
            _mockmasterService.Setup(x => x.GetEntityAsync(It.IsAny<HeaderParameters>(), "duckTest",
                _invalidEntitiesInput
                )).Throws(new CanonicalException());

            _mockmasterService.Setup(x => x.CreateUpdateEntityAsync(It.IsAny<HeaderParameters>(), "duckTest",
                It.IsAny<INS.PT.WebAPI.Helpers.MdmOperation>(), It.IsAny<models.Entity>()
                )).Returns(ValidCreateUpdateEntityAsync());


            _mockAmlService = new Mock<IAmlService>();

            _mockcogenEntitiesService = new Mock<ICogenEntities>();

            _mockMapping = new Mock<ISourceAndResultsMapping>();
            _mockMapping.SetupGet(x => x.IdSource).Returns("duckTest");
            _mockMapping.SetupGet(x => x.IdSystem).Returns("MASTERENTITY");
        }

        private async Task<models.Entity> ValidGetEntityAsync()
        {
            return await Task.Run(() => new models.Entity
            {
                IdEntity = "10592272",
                Type = new models.Entity.EntityType
                {
                    Individual = new models.Person
                    {
                        Name = "test name",
                    }
                }
            });
        }


        private async Task<models.Entity> ValidCreateUpdateEntityAsync()
        {
            return await Task.Run(() => new models.Entity ());
        }

        private readonly EntitiesInput _invalidEntitiesInput;
        private readonly EntitiesInput _validEntitiesInput;
        private readonly EntitiesInput _deleteValidEntitiesInput;


        #region Type
        [Fact]
        public async Task EntityType_Get_ValidAsync()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);

            // Act
            var result = await repository.GetEntityTypeAsync(headerParameters.headerParameters, _validEntitiesInput);


            // Assert
            Assert.NotNull(result);
            Assert.IsType<models.Entity.EntityType>(result);
        }

        [Fact]
        public async Task EntityType_Get_InvalidAsync()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);

            // Act and Assert
            await Assert.ThrowsAsync<CanonicalException>(
                () => repository.GetEntityTypeAsync(headerParameters.headerParameters, _invalidEntitiesInput));
        }
        #endregion

        #region Addresses
        [Fact]
        public void EntityAddresses_Get_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.GetEntityAddressesAsync(headerParameters.headerParameters, _validEntitiesInput);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<IEnumerable<models.Address>>(result.Result);
        }

        [Fact]
        public async Task EntityAddresses_Get_InvalidAsync()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            await Assert.ThrowsAsync<CanonicalException>(
                () => repository.GetEntityAddressesAsync(headerParameters.headerParameters, _invalidEntitiesInput));
        }

        [Fact]
        public void EntityAddress_Get_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.GetEntityAddressAsync(headerParameters.headerParameters, _validEntitiesInput, "1");


            // Assert
            Assert.NotNull(result);
            Assert.IsType<Task<models.Address>>(result);
        }

        [Fact]
        public async Task EntityAddress_Get_InvalidAsync()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            await Assert.ThrowsAsync<CanonicalException>(
                () => repository.GetEntityAddressAsync(headerParameters.headerParameters, _invalidEntitiesInput, "1"));
        }

        [Fact]
        public void EntityAddress_Get_InvalidIdAsync()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.GetEntityAddressAsync(headerParameters.headerParameters, _validEntitiesInput, "r");


            // Assert
            Assert.NotNull(result);
            Assert.IsType<Task<models.Address>>(result);
            Assert.Null(result.Result);
        }

        [Fact]
        public void EntityAddresses_Update_ValidAsync()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var updateObject = new List<models.Address>
            {
                new models.Address { Sequence = "2", PostalCode = "2675-100" }
            };


            // Act
            var result = repository.UpdateEntityAddressesAsync(headerParameters.headerParameters, _validEntitiesInput, updateObject);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<IEnumerable<models.Address>>(result.Result);
        }

        [Fact]
        public void EntityAddresses_Update_InvalidAsync()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var updateObject = new List<models.Address>
            {
                new models.Address { Sequence = "2", PostalCode = "2675-100" }
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityAddressesAsync(headerParameters.headerParameters, _invalidEntitiesInput, updateObject));
        }

        [Fact]
        public void EntityAddress_Update_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var updateObject = new models.Address
            {
                Sequence = "1"
            };


            // Act
            var result = repository.UpdateEntityAddressAsync(headerParameters.headerParameters, _validEntitiesInput, updateObject);


            // Assert
            Assert.NotNull(result);
            Assert.IsType<Task<models.Address>>(result);
        }

        [Fact]
        public void EntityAddress_Update_Invalid()
        {            
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var updateObject = new models.Address
            {
                Sequence = "R"
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityAddressAsync(headerParameters.headerParameters, _invalidEntitiesInput, updateObject));
        }

        [Fact]
        public void EntityAddresses_Delete_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.DeleteEntityAddresses(headerParameters.headerParameters, _deleteValidEntitiesInput, null);


            // Assert
            Assert.True(result);            
        }

        [Fact]
        public void EntityAddresses_Delete_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.Throws<NotSupportedException>(
                () => repository.DeleteEntityAddresses(headerParameters.headerParameters, _validEntitiesInput, null));
        }

        [Fact]
        public void EntityAddress_Delete_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.DeleteEntityAddresses(headerParameters.headerParameters, _deleteValidEntitiesInput, "1");


            // Assert
            Assert.True(result);            
        }

        [Fact]
        public void EntityAddress_Delete_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.Throws<NotSupportedException>(
                () => repository.DeleteEntityAddresses(headerParameters.headerParameters, _validEntitiesInput, "1"));
        }
        #endregion

        #region ContactLists
        [Fact]
        public void EntityContactLists_Get_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.GetEntityContactListsAsync(headerParameters.headerParameters, _validEntitiesInput);


            // Assert
            Assert.NotNull(result);
            Assert.IsType<Task<models.ContactLists>>(result);
        }

        [Fact]
        public void EntityContactLists_Get_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.GetEntityContactListsAsync(headerParameters.headerParameters, _invalidEntitiesInput));
        }

        [Fact]
        public void EntityContactLists_Update_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.ContactLists
            {
                Emails = new List<models.Email> { new models.Email { EmailIdentifier = 2 } },
                Phones = new List<models.Phone> { new models.Phone { PhoneIdentifier = "2" } }
            };


            // Act
            var result = repository.UpdateEntityContactListsAsync(headerParameters.headerParameters, _validEntitiesInput, objectUpdated);


            // Assert
            Assert.NotNull(result);
            Assert.IsType<Task<models.ContactLists>>(result);
        }

        [Fact]
        public void EntityContactLists_Update_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.ContactLists
            {
                Emails = new List<models.Email> { new models.Email { EmailIdentifier = 2 } },
                Phones = new List<models.Phone> { new models.Phone { PhoneIdentifier = "2" } }
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityContactListsAsync(headerParameters.headerParameters, _invalidEntitiesInput, objectUpdated));
        }

        [Fact]
        public void EntityContactLists_Delete_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.DeleteContactLists(headerParameters.headerParameters, _deleteValidEntitiesInput);


            // Assert
            Assert.True(result);
        }

        [Fact]
        public void EntityContactLists_Delete_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.Throws<NotSupportedException>(
                () => repository.DeleteContactLists(headerParameters.headerParameters, _invalidEntitiesInput));
        }
        #endregion

        #region Phones
        [Fact]
        public void EntityPhones_Get_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.GetEntityPhonesAsync(headerParameters.headerParameters, _validEntitiesInput);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<IEnumerable<models.Phone>>>(result);
        }

        [Fact]
        public void EntityPhones_Get_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.GetEntityPhonesAsync(headerParameters.headerParameters, _invalidEntitiesInput));
        }

        [Fact]
        public void EntityPhone_Get_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.GetEntityPhoneAsync(headerParameters.headerParameters, _validEntitiesInput, "1");


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<models.Phone>>(result);
        }

        [Fact]
        public void EntityPhone_Get_InvalidEntity()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.GetEntityPhoneAsync(headerParameters.headerParameters, _invalidEntitiesInput, "1"));
        }

        [Fact]
        public void EntityPhone_Get_InvalidId()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.GetEntityPhoneAsync(headerParameters.headerParameters, _validEntitiesInput, "3"));
        }

        [Fact]
        public void EntityPhones_Update_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new List<models.Phone>
            {
                new models.Phone
                {
                    PhoneIdentifier = "1"
                }
            };


            // Act
            var result = repository.UpdateEntityPhonesAsync(headerParameters.headerParameters, _validEntitiesInput, objectUpdated);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<IEnumerable<models.Phone>>>(result);
        }

        [Fact]
        public void EntityPhones_Update_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new List<models.Phone>
            {
                new models.Phone
                {
                    PhoneIdentifier = "1"
                }
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityPhonesAsync(headerParameters.headerParameters, _invalidEntitiesInput, objectUpdated));
        }

        [Fact]
        public void EntityPhone_Update_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.Phone
            {
                PhoneIdentifier = "1"
            };


            // Act
            var result = repository.UpdateEntityPhoneAsync(headerParameters.headerParameters, _validEntitiesInput, objectUpdated);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<models.Phone>>(result);
        }

        [Fact]
        public void EntityPhone_Update_InvalidEntity()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.Phone
            {
                PhoneIdentifier = "1"
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityPhoneAsync(headerParameters.headerParameters, _invalidEntitiesInput, objectUpdated));
        }

        [Fact]
        public void EntityPhone_Update_InvalidId()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.Phone
            {
                PhoneIdentifier = "3"
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityPhoneAsync(headerParameters.headerParameters, _invalidEntitiesInput, objectUpdated));
        }

        [Fact]
        public void EntityPhones_Delete_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.DeleteEntityPhones(headerParameters.headerParameters, _deleteValidEntitiesInput, It.IsAny<string>());


            // Assert
            Assert.True(result);
        }

        [Fact]
        public void EntityPhones_Delete_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.Throws<NotSupportedException>(
                () => repository.DeleteEntityPhones(headerParameters.headerParameters, _invalidEntitiesInput, It.IsAny<string>()));
        }
        #endregion

        #region Emails
        [Fact]
        public void EntityEmails_Get_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.GetEntityEmailsAsync(headerParameters.headerParameters, _validEntitiesInput);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<IEnumerable<models.Email>>>(result);
        }

        [Fact]
        public void EntityEmails_Get_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.GetEntityEmailsAsync(headerParameters.headerParameters, _invalidEntitiesInput));
        }

        [Fact]
        public void EntityEmail_Get_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.GetEntityEmailAsync(headerParameters.headerParameters, _validEntitiesInput, 1);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<models.Email>>(result);
        }

        [Fact]
        public void EntityEmail_Get_InvalidEntity()
        {
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.GetEntityEmailAsync(headerParameters.headerParameters, _invalidEntitiesInput, 1));
        }

        [Fact]
        public void EntityEmail_Get_InvalidId()
        {
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.GetEntityEmailAsync(headerParameters.headerParameters, _invalidEntitiesInput, 4));
        }

        [Fact]
        public void EntityEmails_Update_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new List<models.Email>
            {
                new models.Email
                {
                    EmailIdentifier = 1
                }
            };


            // Act
            var result = repository.UpdateEntityEmailsAsync(headerParameters.headerParameters, _validEntitiesInput, objectUpdated);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<IEnumerable<models.Email>>>(result);
        }

        [Fact]
        public void EntityEmails_Update_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new List<models.Email>
            {
                new models.Email
                {
                    EmailIdentifier = 1
                }
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityEmailsAsync(headerParameters.headerParameters, _invalidEntitiesInput, objectUpdated));
        }

        [Fact]
        public void EntityEmail_Update_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.Email
            {
                EmailIdentifier = 1
            };


            // Act
            var result = repository.UpdateEntityEmailAsync(headerParameters.headerParameters, _validEntitiesInput, objectUpdated);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<models.Email>>(result);
        }

        [Fact]
        public void EntityEmail_Update_InvalidEntity()
        {
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.Email
            {
                EmailIdentifier = 1
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityEmailAsync(headerParameters.headerParameters, _invalidEntitiesInput, objectUpdated));
        }

        [Fact]
        public void EntityEmail_Update_InvalidId()
        {
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.Email
            {
                EmailIdentifier = 13
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityEmailAsync(headerParameters.headerParameters, _invalidEntitiesInput, objectUpdated));
        }

        [Fact]
        public void EntityEmail_Delete_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.DeleteEntityEmails(headerParameters.headerParameters, _deleteValidEntitiesInput, It.IsAny<int>());


            // Assert
            Assert.True(result);
        }

        [Fact]
        public void EntityEmail_Delete_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.Throws<NotSupportedException>(
                () => repository.DeleteEntityEmails(headerParameters.headerParameters, _validEntitiesInput, It.IsAny<int>()));
        }
        #endregion

        #region BankAccounts
        [Fact]
        public void EntityBankAccounts_Get_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.GetEntityBankAccountsAsync(headerParameters.headerParameters, _validEntitiesInput);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<IEnumerable<models.BankAccount>>>(result);
        }

        [Fact]
        public void EntityBankAccounts_Get_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.GetEntityBankAccountsAsync(headerParameters.headerParameters, _invalidEntitiesInput));
        }

        [Fact]
        public void EntityBankAccount_Get_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.GetEntityBankAccountAsync(headerParameters.headerParameters, _validEntitiesInput, 1);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<models.BankAccount>>(result);
        }

        [Fact]
        public void EntityBankAccount_Get_InvalidEntity()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.GetEntityBankAccountAsync(headerParameters.headerParameters, _invalidEntitiesInput, 1));
        }

        [Fact]
        public void EntityBankAccount_Get_InvalidId()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.GetEntityBankAccountAsync(headerParameters.headerParameters, _invalidEntitiesInput, 5));
        }

        [Fact]
        public void EntityBankAccounts_Update_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new List<models.BankAccount>
            {
                new models.BankAccount
                {
                    SequenceBankAccountNumber = 1
                }
            };


            // Act
            var result = repository.UpdateEntityBankAccountsAsync(headerParameters.headerParameters, _validEntitiesInput, objectUpdated);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<IEnumerable<models.BankAccount>>>(result);
        }

        [Fact]
        public void EntityBankAccounts_Update_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new List<models.BankAccount>
            {
                new models.BankAccount
                {
                    SequenceBankAccountNumber = 1
                }
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityBankAccountsAsync(headerParameters.headerParameters, _invalidEntitiesInput, objectUpdated));
        }

        [Fact]
        public void EntityBankAccount_Update_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.BankAccount
            {
                SequenceBankAccountNumber = 1
            };


            // Act
            var result = repository.UpdateEntityBankAccountAsync(headerParameters.headerParameters, _validEntitiesInput, objectUpdated);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<models.BankAccount>>(result);
        }

        [Fact]
        public void EntityBankAccount_Update_InvalidEntity()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.BankAccount
            {
                SequenceBankAccountNumber = 1
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityBankAccountAsync(headerParameters.headerParameters, _invalidEntitiesInput, objectUpdated));
        }

        [Fact]
        public void EntityBankAccount_Update_InvalidId()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.BankAccount
            {
                SequenceBankAccountNumber = 5
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityBankAccountAsync(headerParameters.headerParameters, _invalidEntitiesInput, objectUpdated));
        }

        [Fact]
        public void EntityBankAccount_Delete_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.DeleteEntityBankAccounts(headerParameters.headerParameters, _deleteValidEntitiesInput, It.IsAny<int>());


            // Assert
            Assert.True(result);
        }

        [Fact]
        public void EntityBankAccount_Delete_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.Throws<NotSupportedException>(
                () => repository.DeleteEntityBankAccounts(headerParameters.headerParameters, _invalidEntitiesInput, It.IsAny<int>()));
        }
        #endregion

        #region Document
        [Fact]
        public void EntityDocuments_Get_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.GetEntityDocumentsAsync(headerParameters.headerParameters, _validEntitiesInput);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<IEnumerable<models.Document>>>(result);
        }

        [Fact]
        public void EntityDocuments_Get_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.GetEntityDocumentsAsync(headerParameters.headerParameters, _invalidEntitiesInput));
        }

        [Fact]
        public void EntityDocument_Get_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.GetEntityDocumentAsync(headerParameters.headerParameters, _validEntitiesInput, "CC", "1");


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<models.Document>>(result);
        }

        [Fact]
        public void EntityDocument_Get_InvalidEntity()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.GetEntityDocumentAsync(headerParameters.headerParameters, _invalidEntitiesInput, "CC", "1"));
        }

        [Theory]
        [InlineData("", "")]
        [InlineData("zz", "1")]
        [InlineData("CC", "3")]
        [InlineData("xx", "5")]
        public void EntityDocument_Get_InvalidId(string documentCode, string documentId)
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.GetEntityDocumentAsync(headerParameters.headerParameters, _invalidEntitiesInput, documentCode, documentId));
        }

        [Fact]
        public void EntityDocuments_Update_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new List<models.Document>
            {
                new models.Document
                {
                    DocumentTypeCode = "CC",
                    DocumentNumber = "1"
                }
            };


            // Act
            var result = repository.UpdateEntityDocumentsAsync(headerParameters.headerParameters, _validEntitiesInput, objectUpdated);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<IEnumerable<models.Document>>>(result);
        }

        [Fact]
        public void EntityDocuments_Update_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new List<models.Document>
            {
                new models.Document
                {
                    DocumentTypeCode="CC",
                    DocumentNumber="1"
                }
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityDocumentsAsync(headerParameters.headerParameters, _invalidEntitiesInput, objectUpdated));
        }

        [Fact]
        public void EntityDocument_Update_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.Document
            {
                DocumentTypeCode = "CC",
                DocumentNumber = "1"
            };


            // Act
            var result = repository.UpdateEntityDocumentAsync(headerParameters.headerParameters, _validEntitiesInput, objectUpdated);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<models.Document>>(result);
        }

        [Fact]
        public void EntityDocument_Update_InvalidEntity()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.Document
            {
                DocumentTypeCode = "CC",
                DocumentNumber = "1"
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityDocumentAsync(headerParameters.headerParameters, _invalidEntitiesInput, objectUpdated));
        }

        [Theory]
        [InlineData("", "")]
        [InlineData("zz", "1")]
        [InlineData("CC", "3")]
        [InlineData("xx", "5")]
        public void EntityDocument_Update_InvalidId(string documentCode, string documentId)
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.Document
            {
                DocumentTypeCode = documentCode,
                DocumentNumber = documentId
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityDocumentAsync(headerParameters.headerParameters, _invalidEntitiesInput, objectUpdated));
        }

        [Fact]
        public void EntityDocument_Delete_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.DeleteEntityDocuments(headerParameters.headerParameters, _deleteValidEntitiesInput, "CC", "1");


            // Assert
            Assert.True(result);
        }

        [Fact]
        public void EntityDocument_Delete_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.Throws<NotSupportedException>(
                () => repository.DeleteEntityDocuments(headerParameters.headerParameters, _invalidEntitiesInput, It.IsAny<string>(), It.IsAny<string>()));
        }
        #endregion

        #region Cae
        [Fact]
        public void EntityCaes_Get_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.GetEntityCaesAsync(headerParameters.headerParameters, _validEntitiesInput);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<IEnumerable<models.Cae>>>(result);
        }

        [Fact]
        public void EntityCaes_Get_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.GetEntityCaesAsync(headerParameters.headerParameters, _invalidEntitiesInput));
        }

        [Fact]
        public void EntityCae_Get_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.GetEntityCaeAsync(headerParameters.headerParameters, _validEntitiesInput, 1);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<models.Cae>>(result);
        }

        [Fact]
        public void EntityCae_Get_InvalidEntity()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.GetEntityCaeAsync(headerParameters.headerParameters, _invalidEntitiesInput, 1));
        }

        [Fact]
        public void EntityCae_Get_InvalidId()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.GetEntityCaeAsync(headerParameters.headerParameters, _invalidEntitiesInput, 6));
        }

        [Fact]
        public void EntityCaes_Update_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new List<models.Cae>
            {
                new models.Cae
                {
                    CaeOrderNumber=1
                }
            };


            // Act
            var result = repository.UpdateEntityCaesAsync(headerParameters.headerParameters, _validEntitiesInput, objectUpdated);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<IEnumerable<models.Cae>>>(result);
        }

        [Fact]
        public void EntityCaes_Update_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new List<models.Cae>
            {
                new models.Cae
                {
                    CaeOrderNumber=1
                }
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityCaesAsync(headerParameters.headerParameters, _invalidEntitiesInput, objectUpdated));
        }

        [Fact]
        public void EntityCae_Update_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.Cae
            {
                CaeOrderNumber = 1
            };


            // Act
            var result = repository.UpdateEntityCaeAsync(headerParameters.headerParameters, _validEntitiesInput, objectUpdated);


            // Assert
            Assert.NotNull(result);
            Assert.IsAssignableFrom<Task<models.Cae>>(result);
        }

        [Fact]
        public void EntityCae_Update_InvalidEntity()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.Cae
            {
                CaeOrderNumber = 1
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityCaeAsync(headerParameters.headerParameters, _invalidEntitiesInput, objectUpdated));
        }

        [Fact]
        public void EntityCae_Update_InvalidId()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);
            var objectUpdated = new models.Cae
            {
                CaeOrderNumber = 6
            };


            // Act and Assert
            Assert.ThrowsAsync<BaseException>(
                () => repository.UpdateEntityCaeAsync(headerParameters.headerParameters, _invalidEntitiesInput, objectUpdated));
        }

        [Fact]
        public void EntityCae_Delete_Valid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act
            var result = repository.DeleteEntityCaes(headerParameters.headerParameters, _deleteValidEntitiesInput, It.IsAny<int>());


            // Assert
            Assert.True(result);
        }

        [Fact]
        public void EntityCae_Delete_Invalid()
        {
            // Arrange
            var repository = new EntityRepository(_mockMapping.Object, _mockAmlService.Object, _mockmasterService.Object, _mockcogenEntitiesService.Object);
            var headerParameters = new FakeHeaderParameters(null);


            // Act and Assert
            Assert.Throws<NotSupportedException>(
                () => repository.DeleteEntityCaes(headerParameters.headerParameters, _invalidEntitiesInput, It.IsAny<int>()));
        }
        #endregion

        #region Affinities
        #endregion
    }
}

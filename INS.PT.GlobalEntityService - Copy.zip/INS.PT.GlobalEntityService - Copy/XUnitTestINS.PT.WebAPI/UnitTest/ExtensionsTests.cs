﻿using INS.PT.WebAPI;
using INS.PT.WebAPI.Models.Elements;
using System;
using Xunit;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class ExtensionsTests
    {
        [Fact]
        public void SerializeObjectToXml_Invalid_Parameter()
        {
            // Arrange
            var testObject = new SimpleEntity();
            testObject = null;

            // Act and Assert
            Assert.Throws<ArgumentNullException>(() => Extensions.SerializeObjectToXml(testObject));
        }

        [Fact]
        public void SerializeObjectToXml_Default_Parameter()
        {
            // Arrange
            var testObject = new SimpleEntity();

            // Act
            var result = Extensions.SerializeObjectToXml(testObject);

            // Assert
            Assert.NotNull(result);
        }
    }
}

﻿using Xunit;
using INS.PT.WebAPI;
using Moq;
using System;
using INS.PT.WebAPI.Models.Input;
using System.Data;
using INS.PT.WebAPI.Models.Output;
using System.Linq;
using XUnitTestINS.PT.WebAPI.TestValues;
using INS.PT.WebAPI.Exceptions;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class NormalizedRepositoryTests
    {
        private readonly Mock<IDbconnectioncs> _mockConnections;
        private readonly Mock<IDbConnection> _mockConnection;

        public NormalizedRepositoryTests()
        {
            _mockConnection = new Mock<IDbConnection>();
            _mockConnection.Setup(x => x.ConnectionString).Returns("test connecting string");
            _mockConnections = new Mock<IDbconnectioncs>();
            _mockConnections.Setup(x => x.Connection).Returns(_mockConnection.Object);
        }

        [Theory]
        [ClassData(typeof(TestInvalidNameDataGenerator))]
        public void GetNormalizedName_InvalidParameters(string name, string gender, DateTime? birhdate)
        {
            // Arrange
            var repository = new NormalizedRepository(_mockConnections.Object, (conn, command, dyParam) => Fake_NormalizedName_FailResult(dyParam), null);
            var parameters = new NormalizedNameInput
            {
                Name = name,
                Birthdate = birhdate,
                Gender = gender
            };

            // Act
            var result = repository.GetNormalizedName(parameters);

            // Assert
            Assert.NotNull(result);
            Assert.NotEqual(0, result.ErrorCode);
            Assert.False(string.IsNullOrEmpty(result.ErrorMessage));
        }

        [Theory]
        [ClassData(typeof(TestValidNameDataGenerator))]
        public void GetNormalizedName_ValidParameters(string name, string gender, DateTime? birhdate)
        {
            // Arrange
            var parameters = new NormalizedNameInput
            {
                Name = name,
                Birthdate = birhdate,
                Gender = gender
            };
            var repository = new NormalizedRepository(_mockConnections.Object, (conn, command, dyParam) => Fake_NormalizedName_SuccessResult(dyParam, parameters), null);

            // Act
            var result = repository.GetNormalizedName(parameters);

            //  Assert
            Assert.NotNull(result);
            Assert.Equal(0, result.ErrorCode);
            Assert.True(string.IsNullOrEmpty(result.ErrorMessage));
            Assert.False(string.IsNullOrEmpty(result.FirstName));
        }

        private NormalizedNameOutput Fake_NormalizedName_FailResult(OracleDynamicParameters dyParam)
        {
            // add some fake to output parameters
            dyParam.Parameters.First(p => p.ParameterName == "p_result").Value = null; // method result fakes this
            dyParam.Parameters.First(p => p.ParameterName == "p_isnorm").Value = new Oracle.ManagedDataAccess.Types.OracleDecimal(0);
            dyParam.Parameters.First(p => p.ParameterName == "p_cderro").Value = new Oracle.ManagedDataAccess.Types.OracleDecimal(-14);
            dyParam.Parameters.First(p => p.ParameterName == "p_dserro").Value = new Oracle.ManagedDataAccess.Types.OracleString("test error");

            return new NormalizedNameOutput
            {
                ErrorCode = -14,
                ErrorMessage = "invalid parameters",
                IsNormalized = false,
                FirstName = null,
                LastName = null,
                MiddleName = null
            };
        }

        private NormalizedNameOutput Fake_NormalizedName_SuccessResult(OracleDynamicParameters dyParam, NormalizedNameInput parameters)
        {
            // add some fake to output parameters
            dyParam.Parameters.First(p => p.ParameterName == "p_result").Value = null; // method result fakes this
            dyParam.Parameters.First(p => p.ParameterName == "p_isnorm").Value = new Oracle.ManagedDataAccess.Types.OracleDecimal(1);
            dyParam.Parameters.First(p => p.ParameterName == "p_cderro").Value = new Oracle.ManagedDataAccess.Types.OracleDecimal(0);
            dyParam.Parameters.First(p => p.ParameterName == "p_dserro").Value = new Oracle.ManagedDataAccess.Types.OracleString("");

            return new NormalizedNameOutput
            {
                ErrorCode = -14,
                ErrorMessage = "invalid parameters",
                IsNormalized = false,
                FirstName = parameters.Name,
                LastName = parameters.Name,
                MiddleName = parameters.Name
            };
        }


        [Theory]
        [InlineData(null, null, null, null, null, null, null, null, null)]
        [InlineData("", "", "", "", "", "", "", "", "")]
        public void GetNormalizedAddress_InvalidParameters(string roadType, string roadName, string houseNumber, string floorNumber,
            string doorNumber, string addToAddress, string locality, string postalCode, string postalCodeDescription)
        {
            // Arrange
            var parameters = new NormalizedAddressInput
            {
                RoadType = roadType,
                RoadName = roadName,
                HouseNumber = houseNumber,
                FloorNumber = floorNumber,
                DoorNumber = doorNumber,
                AddToAddress = addToAddress,
                Locality = locality,
                PostalCode = postalCode,
                PostalCodeDescription = postalCodeDescription
            };
            var repository = new NormalizedRepository(_mockConnections.Object, null, (conn, command, dyParam) => Fake_NormalizedAddress_FailResult(dyParam, parameters));


            // Act and Assert
            Assert.Throws<BaseException>(() => repository.GetNormalizedAddress(parameters));
        }


        [Theory]
        [InlineData("rua", "ricardo reis", "3", "4", "e", "loja", "famoes", "1700-122", "lisboa")]
        public void GetNormalizedAddress_ValidParameters(string roadType, string roadName, string houseNumber, string floorNumber,
            string doorNumber, string addToAddress, string locality, string postalCode, string postalCodeDescription)
        {
            // Arrange
            var parameters = new NormalizedAddressInput
            {
                RoadType = roadType,
                RoadName = roadName,
                HouseNumber = houseNumber,
                FloorNumber = floorNumber,
                DoorNumber = doorNumber,
                AddToAddress = addToAddress,
                Locality = locality,
                PostalCode = postalCode,
                PostalCodeDescription = postalCodeDescription
            };
            var repository = new NormalizedRepository(_mockConnections.Object, null, (conn, command, dyParam) => Fake_NormalizedAddress_SuccessResult(dyParam, parameters));


            // Act
            var result = repository.GetNormalizedAddress(parameters);


            //  Assert
            Assert.NotNull(result);
            Assert.True(result.IsNormalized);
        }

        private int Fake_NormalizedAddress_FailResult(OracleDynamicParameters dyParam, NormalizedAddressInput parameters)
        {
            dyParam.Parameters.First(p => p.ParameterName == "p_tipo_via").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.RoadType);
            dyParam.Parameters.First(p => p.ParameterName == "p_nome_via").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.RoadName);
            dyParam.Parameters.First(p => p.ParameterName == "p_num_policia").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.HouseNumber);
            dyParam.Parameters.First(p => p.ParameterName == "p_andar").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.FloorNumber);
            dyParam.Parameters.First(p => p.ParameterName == "p_porta").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.DoorNumber);
            dyParam.Parameters.First(p => p.ParameterName == "p_complemento").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.AddToAddress);
            dyParam.Parameters.First(p => p.ParameterName == "p_dslocalidad").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.Locality);
            dyParam.Parameters.First(p => p.ParameterName == "p_cdpostal").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.PostalCode);
            dyParam.Parameters.First(p => p.ParameterName == "p_dspostal").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.PostalCodeDescription);
            dyParam.Parameters.First(p => p.ParameterName == "p_isnorm").Value = new Oracle.ManagedDataAccess.Types.OracleDecimal(1);
            dyParam.Parameters.First(p => p.ParameterName == "p_cderro").Value = new Oracle.ManagedDataAccess.Types.OracleDecimal(-14);
            dyParam.Parameters.First(p => p.ParameterName == "p_dserro").Value = new Oracle.ManagedDataAccess.Types.OracleString("test error");

            return -1;
        }

        private int Fake_NormalizedAddress_SuccessResult(OracleDynamicParameters dyParam, NormalizedAddressInput parameters)
        {
            dyParam.Parameters.First(p => p.ParameterName == "p_tipo_via").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.RoadType.ToUpper());
            dyParam.Parameters.First(p => p.ParameterName == "p_nome_via").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.RoadName.ToUpper());
            dyParam.Parameters.First(p => p.ParameterName == "p_num_policia").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.HouseNumber.ToUpper());
            dyParam.Parameters.First(p => p.ParameterName == "p_andar").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.FloorNumber.ToUpper());
            dyParam.Parameters.First(p => p.ParameterName == "p_porta").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.DoorNumber.ToUpper());
            dyParam.Parameters.First(p => p.ParameterName == "p_complemento").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.AddToAddress.ToUpper());
            dyParam.Parameters.First(p => p.ParameterName == "p_dslocalidad").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.Locality.ToUpper());
            dyParam.Parameters.First(p => p.ParameterName == "p_cdpostal").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.PostalCode.ToUpper());
            dyParam.Parameters.First(p => p.ParameterName == "p_dspostal").Value = new Oracle.ManagedDataAccess.Types.OracleString(parameters.PostalCodeDescription.ToUpper());
            dyParam.Parameters.First(p => p.ParameterName == "p_isnorm").Value = new Oracle.ManagedDataAccess.Types.OracleDecimal(0);
            dyParam.Parameters.First(p => p.ParameterName == "p_cderro").Value = new Oracle.ManagedDataAccess.Types.OracleDecimal(0);
            dyParam.Parameters.First(p => p.ParameterName == "p_dserro").Value = new Oracle.ManagedDataAccess.Types.OracleString("");

            return -1;
        }
    }
}

﻿using INS.PT.WebAPI.Models;
using Moq;
using Xunit;
using System;
using INS.PT.WebAPI.Interface;
using System.Threading.Tasks;
using INS.PT.WebAPI.Models.Input;
using System.Collections.Generic;
using INS.PT.WebAPI.Models.Elements.Crm;
using INS.PT.WebAPI;
using INS.PT.WebAPI.Models.Elements;
using INS.PT.WebAPI.Repository;
using System.Data;
using System.Linq;
using XUnitTestINS.PT.WebAPI.Context;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class CrmInformationRepositoryTests
    {
        private readonly Mock<IEntity> _mockmasterEntityRepository;
        private readonly Mock<ISourceAndResultsMapping> _mockSourceAndResults;
        private readonly Mock<IDbconnectioncs> _mockConnections;


        public CrmInformationRepositoryTests()
        {
            var mockConnection = new Mock<IDbConnection>();
            mockConnection.Setup(x => x.ConnectionString).Returns("test connecting string");
           _mockConnections = new Mock<IDbconnectioncs>();
            _mockConnections.Setup(x => x.Connection).Returns(mockConnection.Object);

            _mockmasterEntityRepository = new Mock<IEntity>();

            _mockmasterEntityRepository.Setup(x => x.GetEntityAsync(
                It.IsAny<HeaderParameters>()
                , _validEntity
                ))
                .ReturnsAsync(_validEntityResponse);
            _mockmasterEntityRepository.Setup(x => x.GetEntityAsync(
                It.IsAny<HeaderParameters>()
                , _errorEntity
                ))
                .ReturnsAsync(_errorEntityResponse);


            _mockSourceAndResults = new Mock<ISourceAndResultsMapping>();
            _mockSourceAndResults.SetupGet(x => x.IdSource).Returns("DUCKCREEK");
            _mockSourceAndResults.SetupGet(x => x.IdSystem).Returns("MASTERENTITY");
        }

        private readonly HeaderParameters _headerParameters = new HeaderParameters (new FakeCodesMapping()) { BsSolution = "TEST" };

        private Task GetCrmExternalInformationMockAsync(ExternalInfo crmExternalInformation)
        {
            crmExternalInformation.Semaphore = "test Semaphore";
            crmExternalInformation.Campaigns = new List<Campaign> { new Campaign { Name = "test Campaign" } };
            crmExternalInformation.CompetionProducts = new List<CompetionProduct> { new CompetionProduct { Product = "test product" } };
            crmExternalInformation.LastContacts = new List<LastContact> { new LastContact { IdCompany = "AGEAS", ContactedBy = "unit test" } };
            crmExternalInformation.Proposals = new List<Proposal> { new Proposal { Description = "test Proposal" } };

            return Task.Run(() => { } );
        }

        private Task<int> SetCrmExternalInformationAsync(OracleDynamicParameters dyParam, int errorValue)
        {
            dyParam.Parameters.First(p => p.ParameterName == CrmInformationRepository.OutputParameterForErrorCode).Value = new Oracle.ManagedDataAccess.Types.OracleDecimal(errorValue);
            dyParam.Parameters.First(p => p.ParameterName == CrmInformationRepository.OutputParameterForErrorDescription).Value = new Oracle.ManagedDataAccess.Types.OracleString("test error");

            return Task.Run(() => 1);
        }


        private readonly CrmExternalInfoInput _validInput = new CrmExternalInfoInput
        {
            IdEntity = "2233",
            ProductDescription = "Test product"
        };


        private readonly EntitiesInput _validEntity = new EntitiesInput { IdEntity = "2233" };
        private readonly Entity _validEntityResponse = new Entity
            {
                IdEntity = "2233",
                VatNumber = "123456789"
            };

        private readonly EntitiesInput _errorEntity = new EntitiesInput { IdEntity = "WW2233" };
        private readonly Entity _errorEntityResponse = null;

        [Fact]
        public async Task GetExternalInformationAsync_InvalidHeaders()
        {
            // Arrange
            var testObject = new CrmInformationRepository(_mockConnections.Object, _mockmasterEntityRepository.Object, _mockSourceAndResults.Object
                , (crmExternalInformation, dyParam, conn, command) => GetCrmExternalInformationMockAsync(crmExternalInformation), null);

            // Act and  Assert
            await Assert.ThrowsAsync<ArgumentNullException>(() => testObject.GetExternalInformationAsync(null, _validEntity));
        }

        [Fact]
        public async Task GetExternalInformationAsync_InvalidParameters()
        {
            // Arrange
            var testObject = new CrmInformationRepository(_mockConnections.Object, _mockmasterEntityRepository.Object, _mockSourceAndResults.Object
                , (crmExternalInformation, dyParam, conn, command) => GetCrmExternalInformationMockAsync(crmExternalInformation), null);

            // Act and  Assert
            await Assert.ThrowsAsync<ArgumentNullException>(() => testObject.GetExternalInformationAsync(_headerParameters, null));
        }

        [Fact]
        public async Task GetExternalInformationAsync_NullEntity()
        {
            // Arrange
            var testObject = new CrmInformationRepository(_mockConnections.Object, _mockmasterEntityRepository.Object, _mockSourceAndResults.Object
                , (crmExternalInformation, dyParam, conn, command) => GetCrmExternalInformationMockAsync(crmExternalInformation), null);

            // Act
            var result = await testObject.GetExternalInformationAsync(_headerParameters, _errorEntity);

            // Assert
            Assert.NotNull(result);
            Assert.NotNull(result.CrmExternalInformation);
            Assert.Null(result.Entity);
        }

        [Fact]
        public async Task GetExternalInformationAsync_Valid()
        {
            // Arrange
            var testObject = new CrmInformationRepository(_mockConnections.Object, _mockmasterEntityRepository.Object, _mockSourceAndResults.Object
                , (crmExternalInformation, dyParam, conn, command) => GetCrmExternalInformationMockAsync(crmExternalInformation), null);

            // Act
            var result = await testObject.GetExternalInformationAsync(_headerParameters, _validEntity);

            // Assert
            Assert.NotNull(result);
            Assert.NotNull(result.CrmExternalInformation);
            Assert.NotNull(result.Entity);
        }


        [Fact]
        public async Task SetInformationAsync_InvalidHeaders()
        {
            // Arrange
            var testObject = new CrmInformationRepository(_mockConnections.Object, _mockmasterEntityRepository.Object, _mockSourceAndResults.Object
                , null, (conn, command, dyParam) => SetCrmExternalInformationAsync(dyParam, 0));

            // Act and  Assert
            await Assert.ThrowsAsync<ArgumentNullException>(() => testObject.SetInformationAsync(null, _validInput));
        }

        [Fact]
        public async Task SetInformationAsync_InvalidParameters()
        {
            // Arrange
            var testObject = new CrmInformationRepository(_mockConnections.Object, _mockmasterEntityRepository.Object, _mockSourceAndResults.Object
                , null, (conn, command, dyParam) => SetCrmExternalInformationAsync(dyParam, 0));

            // Act and  Assert
            await Assert.ThrowsAsync<ArgumentNullException>(() => testObject.SetInformationAsync(_headerParameters, null));
        }

        [Fact]
        public async Task SetInformationAsync_ErrorInDB()
        {
            // Arrange
            const int ErrorCode = 123;
            var testObject = new CrmInformationRepository(_mockConnections.Object, _mockmasterEntityRepository.Object, _mockSourceAndResults.Object
                , null, (conn, command, dyParam) => SetCrmExternalInformationAsync(dyParam, ErrorCode));

            // Act
            var result = await testObject.SetInformationAsync(_headerParameters, _validInput);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task SetInformationAsync_Valid()
        {
            // Arrange
            var testObject = new CrmInformationRepository(_mockConnections.Object, _mockmasterEntityRepository.Object, _mockSourceAndResults.Object
                , null, (conn, command, dyParam) => SetCrmExternalInformationAsync(dyParam, 0));

            // Act
            var result = await testObject.SetInformationAsync(_headerParameters, _validInput);

            // Assert
            Assert.True(result);
        }
    }
}

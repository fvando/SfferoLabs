﻿using INS.PT.WebAPI.Models;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Xunit;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class HeaderParametersTests
    {
        [Fact(Skip = "Validation is going to be changed")]
        public void Validate_InvalidCompany()
        {
            // Arrange
            var objectToTest = new HeaderParameters(null)
                {
                    IdCompany = "TESTE_TESTE_TESTE_TESTE",
                    IdNetwork = "AGEAS_AGEAS_AGEAS_AGEAS",
                    BsSolution = "DUCKCREEK_DUCKCREEK_DUCKCREEK",
                    BsUser = "TESTE_TESTE_TESTE_TESTE"
                };
            var validationContext = new ValidationContext(objectToTest);

            // Act
            var result = objectToTest.Validate(validationContext);

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Any());
        }

        [Fact]
        public void Validate_ValidObject()
        {
            // Arrange
            var objectToTest = new Context.FakeHeaderParameters(null).headerParameters;
            var validationContext = new ValidationContext(objectToTest);

            // Act
            var result = objectToTest.Validate(validationContext);

            // Assert
            Assert.NotNull(result);
            Assert.False(result.Any());
        }
    }
}

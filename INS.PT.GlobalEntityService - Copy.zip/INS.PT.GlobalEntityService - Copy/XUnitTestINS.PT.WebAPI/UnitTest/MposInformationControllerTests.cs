﻿using INS.PT.WebAPI.Controllers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestINS.PT.WebAPI.Context;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class MposInformationControllerTests
    {
        private readonly Mock<IMposInformation> _mockRepository;

        private readonly MposInformationInput _validParameters;
        private readonly MposInformationInput _invalidParameters;

        public MposInformationControllerTests()
        {
            _validParameters = new MposInformationInput
            {
                EntitiesIds = new List<string> { "2233" }
            };

            _invalidParameters = new MposInformationInput
            {
                EntitiesIds = new List<string> { "invalidDni" }
            };

            _mockRepository = new Mock<IMposInformation>();

            _mockRepository.Setup(x => x.GetMposInformationAsync(It.IsAny<HeaderParameters>(), _validParameters))
                .Returns(ValidGetEntitiesInformationAsync);
            _mockRepository.Setup(x => x.GetMposInformationAsync(It.IsAny<HeaderParameters>(), _invalidParameters))
                .Returns(InvalidGetEntitiesInformationAsync);

        }

        private async Task<IEnumerable<MposInformationOutput>> ValidGetEntitiesInformationAsync()
        {
            return await Task.Run(() => new List<MposInformationOutput>
                {
                    new MposInformationOutput
                    {
                        IdEntity = "2233"
                    }
                });
        }

        private async Task<IEnumerable<MposInformationOutput>> InvalidGetEntitiesInformationAsync()
        {
            return await Task.Run(() => new List<MposInformationOutput>());
        }



        [Fact]
        public void GetEntitiesInformationAsync_NoHeaders()
        {
            // Arrange
            var controller = new MposInformationController(_mockRepository.Object, null, new FakeCodesMapping());

            // Act
            var result = controller.GetEntitiesInformationAsync(_validParameters).Result;

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<MposInformationOutput>>>(result);
            var badRequest = Assert.IsType<BadRequestObjectResult>(taskResult.Result);
            var objectResult = Assert.IsType<AggregateException>(badRequest.Value);
            Assert.NotNull(objectResult);
        }

        [Fact]
        public void GetEntitiesInformationAsync_InvalidHeaders()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(
                    new HeaderParameters(new FakeCodesMapping())
                    {
                        IdCompany = "",
                        IdNetwork = "AGEAS",
                        BsSolution = "DUCKCREEK",
                        BsUser = "TESTE"
                    }
                );
            var controller = new MposInformationController(_mockRepository.Object, httpContext, new FakeCodesMapping());

            // Act
            var result = controller.GetEntitiesInformationAsync(_validParameters).Result;

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<MposInformationOutput>>>(result);
            var badRequest = Assert.IsType<BadRequestObjectResult>(taskResult.Result);
            var objectResult = Assert.IsType<AggregateException>(badRequest.Value);
            Assert.NotNull(objectResult);
        }

        [Fact]
        public void GetEntitiesInformationAsync_NotFound()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(
                    new HeaderParameters(new FakeCodesMapping())
                    {
                        IdCompany = "AGEAS",
                        IdNetwork = "AGEAS",
                        BsSolution = "DUCKCREEK",
                        BsUser = "TESTE"
                    }
                );
            var controller = new MposInformationController(_mockRepository.Object, httpContext, new FakeCodesMapping());

            // Act
            var result = controller.GetEntitiesInformationAsync(_invalidParameters).Result;

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<MposInformationOutput>>>(result);
            var notFoundRequest = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundRequest);
        }

        [Fact]
        public void GetEntitiesInformationAsync_Valid()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(
                    new HeaderParameters(new FakeCodesMapping())
                    {
                        IdCompany = "AGEAS",
                        IdNetwork = "AGEAS",
                        BsSolution = "DUCKCREEK",
                        BsUser = "TESTE"
                    }
                );
            var controller = new MposInformationController(_mockRepository.Object, httpContext, new FakeCodesMapping());

            // Act
            var result = controller.GetEntitiesInformationAsync(_validParameters).Result;

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<MposInformationOutput>>>(result);
            var okRequest = Assert.IsType<OkObjectResult>(taskResult.Result);
            var listResult = Assert.IsAssignableFrom<IEnumerable<MposInformationOutput>>(okRequest.Value);
            Assert.NotEmpty(listResult);
        }

    }
}

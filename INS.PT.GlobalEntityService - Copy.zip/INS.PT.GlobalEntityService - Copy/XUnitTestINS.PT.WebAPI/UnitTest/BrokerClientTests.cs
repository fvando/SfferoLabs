﻿using Flurl.Http.Testing;
using INS.PT.WebAPI.BrokerCalls;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using Xunit;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class BrokerClientTests
    {
        private readonly Mock<IConfiguration> _mockConfig;

        public BrokerClientTests()
        {
            _mockConfig = new Mock<IConfiguration>();

            _mockConfig.Setup(x => x[$"Broker:{nameof(BrokerClient.BrokerEndpoint)}"]).Returns($"test{nameof(BrokerClient.BrokerEndpoint)}");
            _mockConfig.Setup(x => x[$"Broker:{nameof(BrokerClient.BsSolution)}"]).Returns($"test{nameof(BrokerClient.BsSolution)}");
            _mockConfig.Setup(x => x[$"Broker:{nameof(BrokerClient.BsUser)}"]).Returns($"test{nameof(BrokerClient.BsUser)}");
            _mockConfig.Setup(x => x[$"Broker:{nameof(BrokerClient.BsWebService)}"]).Returns($"test{nameof(BrokerClient.BsWebService)}");
            _mockConfig.Setup(x => x[$"Broker:{nameof(BrokerClient.BsWebmethod)}"]).Returns($"test{nameof(BrokerClient.BsWebmethod)}");

            _mockConfig.Setup(x => x[$"TestSection:{nameof(BrokerClient.BrokerEndpoint)}"]).Returns($"test{nameof(BrokerClient.BrokerEndpoint)}");
            _mockConfig.Setup(x => x[$"TestSection:{nameof(BrokerClient.BsSolution)}"]).Returns($"test{nameof(BrokerClient.BsSolution)}");
            _mockConfig.Setup(x => x[$"TestSection:{nameof(BrokerClient.BsUser)}"]).Returns($"test{nameof(BrokerClient.BsUser)}");
            _mockConfig.Setup(x => x[$"TestSection:{nameof(BrokerClient.BsWebService)}"]).Returns($"test{nameof(BrokerClient.BsWebService)}");
            _mockConfig.Setup(x => x[$"TestSection:{nameof(BrokerClient.BsWebmethod)}"]).Returns($"test{nameof(BrokerClient.BsWebmethod)}");
        }

        [Theory]
        [InlineData(null)]
        [InlineData("empty")]
        public void LoadConfigSettings_EmptySettings(string sectionName)
        {
            // Arrange
            var testObject = new BrokerClient(_mockConfig.Object)
            {
                BrokerEndpoint = "someValue",
                BsSolution = "someValue",
                BsUser = "someValue",
                BsWebmethod = "someValue",
                BsWebService = "someValue"
            };

            // Act
            testObject.LoadConfigSettings(sectionName);

            // Assert
            Assert.Null(testObject.BrokerEndpoint);
            Assert.Null(testObject.BsSolution);
            Assert.Null(testObject.BsUser);
            Assert.Null(testObject.BsWebmethod);
            Assert.Null(testObject.BsWebService);
        }

        [Theory]
        [InlineData(null)]
        [InlineData("TestSection")]
        public void LoadConfigSettings_ValidSettings(string sectionName)
        {
            // Arrange
            var testObject = new BrokerClient(_mockConfig.Object);

            // Act
            if (sectionName != null)
            {
                testObject.LoadConfigSettings(sectionName);
            }

            // Assert
            Assert.Equal($"test{nameof(BrokerClient.BrokerEndpoint)}", testObject.BrokerEndpoint);
            Assert.Equal($"test{nameof(BrokerClient.BsSolution)}", testObject.BsSolution);
            Assert.Equal($"test{nameof(BrokerClient.BsUser)}", testObject.BsUser);
            Assert.Equal($"test{nameof(BrokerClient.BsWebService)}", testObject.BsWebService);
            Assert.Equal($"test{nameof(BrokerClient.BsWebmethod)}", testObject.BsWebmethod);
        }

        [Fact]
        public void OkToMakeCall_True()
        {
            // Arrange
            var testObject = new BrokerClient(_mockConfig.Object);

            // Act
            var result = testObject.OkToMakeCall();

            // Assert
            Assert.True(result);
        }

        [Theory]
        [InlineData("", "", "")]
        [InlineData("", "testUser", "testMethod")]
        [InlineData("testSolution", "", "testMethod")]
        [InlineData("testSolution", "testUser", "")]
        public void OkToMakeCall_False(string solution, string user, string method)
        {
            // Arrange
            var testObject = new BrokerClient(_mockConfig.Object)
            {
                BsSolution = solution,
                BsUser = user,
                BsWebmethod = method
            };

            // Act
            var result = testObject.OkToMakeCall();

            // Assert
            Assert.False(result);
        }


        [Fact]
        public void RequestAsync_NotOkToCall()
        {
            // Arrange
            var testObject = new BrokerClient(_mockConfig.Object)
            {
                BsWebmethod = ""
            };

            // Act
            var result = testObject.RequestAsync("", null, null, new DateTime()).Result;

            // Assert
            Assert.Equal(default(DateTime), result);
        }

        [Fact]
        public void RequestAsync_WithException()
        {
            // Arrange
            var testObject = new BrokerClient(_mockConfig.Object)
            {
                BrokerEndpoint = "https://bs-ts.ageas.intra/n1/handler.ashx"
            };

            // Act
            var result = testObject.RequestAsync("", null, null, new DateTime()).Result;

            // Assert
            Assert.Equal(default(DateTime), result);
        }

        [Theory]
        [InlineData(0)]
        [InlineData(3)]
        public void RequestAsync_InvalidRetries(uint retries)
        {
            // Arrange
            var testObject = new BrokerClient(_mockConfig.Object)
            {
                BrokerEndpoint = "https://bs-ts.ageas.intra/n1/handler.ashx"
            };

            // Flurl is now in test mode
            using (var httpTest = new HttpTest())
            {
                httpTest.RespondWithJson(new { message = "Not found!" }, 404);

                //Act
                var result = testObject.RequestAsync("", null, null, retries, new DateTime()).Result;

                // Assert
                Assert.Equal(default(DateTime), result);
            }
        }

        [Fact]
        public void RequestAsync_Valid()
        {
            // Arrange
            var testObject = new BrokerClient(_mockConfig.Object)
            {
                BrokerEndpoint = "https://bs-ts.ageas.intra/n1/handler.ashx"
            };
            var responseObject = new DateTime(2019, 12, 4, 10, 34, 20);

            // Flurl is now in test mode
            using (var httpTest = new HttpTest())
            {
                httpTest.RespondWithJson(responseObject);

                //Act
                var result = testObject.RequestAsync("", null, null, new DateTime()).Result;

                // Assert
                Assert.Equal(responseObject, result);
            }
        }
    }
}

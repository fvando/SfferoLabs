﻿using INS.PT.WebAPI;
using INS.PT.WebAPI.Controllers;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Output;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Xunit;
using XUnitTestINS.PT.WebAPI.Context;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class SearchEntitiesControllerTests
    {
        private readonly Mock<ISearchEntity> _mockRepository;

        public SearchEntitiesControllerTests()
        {
            _mockRepository = new Mock<ISearchEntity>();
        }

        [Fact]
        public void GetSearchEntities_NoHeaders()
        {
            // Arrange
            var controller = new SearchEntitiesController(_mockRepository.Object, null, new FakeCodesMapping());
            var parameters = new INS.PT.WebAPI.Models.Input.SearchEntityInput();

            // Act
            var result = controller.GetSearchEntitiesAsync(parameters).Result;

            // Assert
            Assert.IsType<ActionResult<SearchEntityOutput>>(result);
            Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Null(result.Value);
        }

        [Fact]
        public void GetSearchEntities_InvalidHeaders()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(
                    new HeaderParameters(new FakeCodesMapping())
                    {
                        IdCompany = "",
                        IdNetwork = "AGEAS",
                        BsSolution = "DUCKCREEK",
                        BsUser = "TESTE"
                    }
                );
            var controller = new SearchEntitiesController(_mockRepository.Object, httpContext, new FakeCodesMapping());
            var parameters = new INS.PT.WebAPI.Models.Input.SearchEntityInput();

            // Act
            var result = controller.GetSearchEntitiesAsync(parameters).Result;

            // Assert
            Assert.IsType<ActionResult<SearchEntityOutput>>(result);
            Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Null(result.Value);
        }

        [Theory]
        [InlineData("", "", "", "", "", "")]
        [InlineData("pt1234567890es", null, null, null, null, null)]
        [InlineData("pt1234567890es", null, null, null, null, "nameverylongnameverylongnameverylongnameverylongnameverylongnameverylong")]
        [InlineData(null, "123456789A123456789B123456789Cx", null, null, null, null)]
        [InlineData(null, null, "nameverylongnameverylongnameverylongnameverylongnameverylongnameverylong", null, null, null)]
        [InlineData(null, null, null, "PPPP-CCCC", null, null)]
        [InlineData(null, null, null, null, "0003511234567890", null)]
        [InlineData("pt1234567890es", "123456789A123456789B123456789Cx", "nameverylongnameverylongnameverylongnameverylongnameverylongnameverylong", "PPPP-CCCC", "0003511234567890",
            "nameverylongnameverylongnameverylongnameverylongnameverylongnameverylong")]
        public void GetSearchEntities_InvalidParameters(string vatNumber, string idEntity, string name, string postalCode, string phoneNumber, string email)
        {
            // Arrange
            var parameters = new INS.PT.WebAPI.Models.Input.SearchEntityInput()
            {
                IdEntity = idEntity,
                PostalCode = postalCode,
                Name = name,
                PhoneNumber = phoneNumber,
                VatNumber = vatNumber,
                Email = email
            };
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(parameters);


            // Act
            var isValid = Validator.TryValidateObject(parameters, validationContext, validationResults, true);


            // Assert
            Assert.False(isValid);
            Assert.True(validationResults.Any());
        }

        [Theory]
        [InlineData("", "", "", "", "")]
        [InlineData(null, null, null, null, null)]
        public void GetSearchEntities_ParametersValidator(string vatNumber, string bankAccount, string name, string gender, string phoneNumber)
        {
            // Arrange
            var parameters = new INS.PT.WebAPI.Models.Input.SearchEntityInput()
            {
                IdEntity = bankAccount,
                PostalCode = gender,
                Name = name,
                PhoneNumber = phoneNumber,
                VatNumber = vatNumber
            };
            var validationContext = new ValidationContext(parameters);


            // Act
            var isValid = parameters.Validate(validationContext);


            // Assert
            Assert.True(isValid.Any());
        }


        [Theory]
        [InlineData(null, null, "Antonio Santos", null, null)]
        [InlineData(null, null, null, "H", null)]
        [InlineData(null, "12387653", null, null, null)]
        public void GetSearchEntities_NoResults(string vatNumber, string bankAccount, string name, string gender, string phoneNumber)
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestSearchEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = new INS.PT.WebAPI.Models.Input.SearchEntityInput()
            {
                IdEntity = bankAccount,
                PostalCode = gender,
                Name = name,
                PhoneNumber = phoneNumber,
                VatNumber = vatNumber
            };

            var output = new SearchEntityOutput()
            {};

            _mockRepository.Setup(x => x.SearchEntityAsync(It.IsAny<HeaderParameters>(), parameters)).ReturnsAsync(output);

            // Act
            var result = controller.GetSearchEntitiesAsync(parameters).Result;


            // Assert
            Assert.IsType<ActionResult<SearchEntityOutput>>(result);
            Assert.IsType<NotFoundObjectResult>(result.Result);

            var outputObject = result.Result as NotFoundObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status404NotFound, outputObject.StatusCode.Value);
        }

        [Theory]
        [InlineData(null, null, "Antonio Santos", "H", null)]
        public void GetSearchEntities_NoResultsException(string vatNumber, string bankAccount, string name, string gender, string phoneNumber)
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestSearchEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = new INS.PT.WebAPI.Models.Input.SearchEntityInput()
            {
                IdEntity = bankAccount,
                PostalCode = gender,
                Name = name,
                PhoneNumber = phoneNumber,
                VatNumber = vatNumber
            };

            _mockRepository.Setup(x => x.SearchEntityAsync(httpContext.headerParameters, parameters)
                ).ReturnsAsync(
                ()=> { throw new BaseException("test error code", "test error message"); });


            // Act
            var result = controller.GetSearchEntitiesAsync(parameters).Result;


            // Assert
            Assert.IsType<ActionResult<SearchEntityOutput>>(result);
            Assert.IsType<NotFoundObjectResult>(result.Result);

            var outputObject = result.Result as NotFoundObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status404NotFound, outputObject.StatusCode.Value);
            Assert.IsType<BaseException>(outputObject.Value);
        }


        [Theory]
        [InlineData("213200104", null, "Antonio Santos", "H", null)]
        [InlineData("213200104", null, null, null, null)]
        public void GetSearchEntities_ValidParameters(string vatNumber, string bankAccount, string name, string gender, string phoneNumber)
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestSearchEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = new INS.PT.WebAPI.Models.Input.SearchEntityInput()
            {
                IdEntity = bankAccount,
                PostalCode = gender,
                Name = name,
                PhoneNumber = phoneNumber,
                VatNumber = vatNumber
            };

            var output = new SearchEntityOutput();
            output.MatchedEntities.Add(
                new INS.PT.WebAPI.Models.Elements.SimpleEntity()
                {
                    Name = "Test name"
                });

            _mockRepository.Setup(x => x.SearchEntityAsync(httpContext.headerParameters, parameters)).ReturnsAsync(output);


            // Act
            var result = controller.GetSearchEntitiesAsync(parameters).Result;


            // Assert
            Assert.IsType<ActionResult<SearchEntityOutput>>(result);
            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);


            var returnObject = outputObject.Value as SearchEntityOutput;
            Assert.NotNull(returnObject);
            Assert.True(returnObject.MatchedEntities.Any());
        }


        public class TestSearchEntitiesController : SearchEntitiesController
        {
            public TestSearchEntitiesController(HeaderParameters headerParameters, ISearchEntity repository, IHttpContextAccessor httpContext) : base(repository, httpContext, null)
            {
                HeaderParameters = headerParameters ?? throw new ArgumentNullException(nameof(headerParameters));
            }

            public HeaderParameters HeaderParameters { get; set; }

            protected override HeaderParameters ValidateHeader()
            {
                return HeaderParameters;
            }
        }
    }

}

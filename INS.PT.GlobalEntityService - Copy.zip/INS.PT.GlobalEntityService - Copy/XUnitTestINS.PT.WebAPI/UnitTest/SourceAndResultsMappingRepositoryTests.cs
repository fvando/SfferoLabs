﻿using INS.PT.WebAPI;
using INS.PT.WebAPI.Models;
using Moq;
using Xunit;
using System;
using System.Data;
using INS.PT.WebAPI.Repository;
using INS.PT.WebAPI.Helpers;
using System.Collections.Generic;
using System.Linq;
using INS.PT.WebAPI.Models.Elements;
using INS.PT.WebAPI.Exceptions;
using XUnitTestINS.PT.WebAPI.Context;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class SourceAndResultsMappingRepositoryTests
    {
        private readonly Mock<IDbconnectioncs> _mockConnections;
        private readonly Mock<IDbConnection> _mockConnection;

        public SourceAndResultsMappingRepositoryTests()
        {
            _mockConnection = new Mock<IDbConnection>();
            _mockConnection.Setup(x => x.ConnectionString).Returns("test connecting string");
            _mockConnections = new Mock<IDbconnectioncs>();
            _mockConnections.Setup(x => x.Connection).Returns(_mockConnection.Object);
        }

        private const string TestSource = "duck";
        private const string TestSystem = "master";

        private IEnumerable<StructureAccess> FakeGoodResult(OracleDynamicParameters dyParam, bool withEntity = true)
        {
            dyParam.Parameters.First(p => p.ParameterName == "p_dest_src").Value =
               new Oracle.ManagedDataAccess.Types.OracleString(TestSource);
            dyParam.Parameters.First(p => p.ParameterName == "p_dest_sys").Value =
               new Oracle.ManagedDataAccess.Types.OracleString(TestSystem);
            dyParam.Parameters.First(p => p.ParameterName == "p_cderror").Value =
               new Oracle.ManagedDataAccess.Types.OracleDecimal(0);
            dyParam.Parameters.First(p => p.ParameterName == "p_dserror").Value =
               new Oracle.ManagedDataAccess.Types.OracleString("");

            var result = new List<StructureAccess>
            {
                new StructureAccess
                {
                    Level = "1",
                    Name ="Test",
                    Order = 2
                },
                new StructureAccess
                {
                    Level = "1.1",
                    Name ="Addresses",
                    Order = 1
                }
            };

            if (withEntity)
            {
                result.Add(new StructureAccess
                {
                    Level = "1",
                    Name = "entity",
                    Order = 0
                });
            }

            return result;
        }

        private IEnumerable<StructureAccess> FakeBadResult(OracleDynamicParameters dyParam)
        {
            dyParam.Parameters.First(p => p.ParameterName == "p_dest_src").Value =
               new Oracle.ManagedDataAccess.Types.OracleString(TestSource);
            dyParam.Parameters.First(p => p.ParameterName == "p_dest_sys").Value =
               new Oracle.ManagedDataAccess.Types.OracleString(TestSystem);
            dyParam.Parameters.First(p => p.ParameterName == "p_cderror").Value =
               new Oracle.ManagedDataAccess.Types.OracleDecimal(1231);
            dyParam.Parameters.First(p => p.ParameterName == "p_dserror").Value =
               new Oracle.ManagedDataAccess.Types.OracleString("erro de teste");


            return Enumerable.Empty<StructureAccess>();
        }

        [Fact]
        public void ReadSourceAndSctructure_No_HeaderParameters()
        {
            // Arrange
            var repository = new SourceAndResultsMappingRepository(_mockConnections.Object, null);

            // Act and Assert
            Assert.Throws<ArgumentNullException>(() => repository.ReadSourceAndSctructure(null, It.IsAny<MdmOperation>()));
        }

        [Fact]
        public void ReadSourceAndSctructure_ValidParameters()
        {
            // Arrange
            var headerParameters = new HeaderParameters(new FakeCodesMapping())
            {
                BsSolution = "xpto",
                BsUser = "\\bs\\xpto",
                IdCompany = "testCompany",
                IdNetwork = "testNet"
            };
            var repository = new SourceAndResultsMappingRepository(_mockConnections.Object, 
                (conn, dyParam, command) => FakeGoodResult(dyParam));

            // Act
            repository.ReadSourceAndSctructure(headerParameters, It.IsAny<MdmOperation>());

            // Assert
            Assert.Equal(TestSource, repository.IdSource);
            Assert.Equal(TestSystem, repository.IdSystem);
        }

        [Fact]
        public void ReadSourceAndSctructure_ErrorInPackage()
        {
            // Arrange
            var headerParameters = new HeaderParameters(new FakeCodesMapping())
            {
                BsSolution = "xpto",
                BsUser = "\\bs\\xpto",
                IdCompany = "testCompany",
                IdNetwork = "testNet"
            };
            var repository = new SourceAndResultsMappingRepository(_mockConnections.Object, 
                (conn, dyParam, command) => FakeBadResult(dyParam));

            // Act and Assert
            Assert.Throws<BusinessException>(() => repository.ReadSourceAndSctructure(headerParameters, It.IsAny<MdmOperation>()));
        }

        [Fact]
        public void RemoveUnauthorizedData_ValidParameters()
        {
            // Arrange
            var headerParameters = new HeaderParameters(new FakeCodesMapping())
            {
                BsSolution = "xpto",
                BsUser = "\\bs\\xpto",
                IdCompany = "testCompany",
                IdNetwork = "testNet"
            };
            var repository = new SourceAndResultsMappingRepository(_mockConnections.Object, 
                (conn, dyParam, command) => FakeGoodResult(dyParam));
            repository.ReadSourceAndSctructure(headerParameters, MdmOperation.Get);
            var entity = new Entity
            {
                IdEntity = "teste",
                Addresses = new List<Address>
                {
                    new Address
                    {
                        Sequence = "1"
                    }
                },
                BankAccounts = new List<BankAccount>
                {
                    new BankAccount
                    {
                        BankAccountNumber ="123",
                        SequenceBankAccountNumber=12
                    }
                },
                VatNumber = "987123654"
            };


            // Act
            repository.RemoveUnauthorizedData(entity);

            // Assert
            Assert.True(entity.BankAccounts == null);
            Assert.True(entity.Addresses.Any());
            Assert.Equal("1", entity.Addresses.First().Sequence);
        }

        [Fact]
        public void RemoveUnauthorizedData_NoAuthorization()
        {
            // Arrange
            var headerParameters = new HeaderParameters(new FakeCodesMapping())
            {
                BsSolution = "xpto",
                BsUser = "\\bs\\xpto",
                IdCompany = "testCompany",
                IdNetwork = "testNet"
            };
            var repository = new SourceAndResultsMappingRepository(_mockConnections.Object, 
                (conn, dyParam, command) => FakeGoodResult(dyParam, false));
            var entity = new Entity
            {
                IdEntity = "teste",
                Addresses = new List<Address>
                {
                    new Address
                    {
                        Sequence = "1"
                    }
                },
                BankAccounts = new List<BankAccount>
                {
                    new BankAccount
                    {
                        BankAccountNumber ="123",
                        SequenceBankAccountNumber=12
                    }
                },
                VatNumber = "987123654"
            };

            repository.ReadSourceAndSctructure(headerParameters, MdmOperation.Get);

            // Act
            repository.RemoveUnauthorizedData(entity);

            // Assert
            Assert.True(entity.BankAccounts == null);
            Assert.True(string.IsNullOrEmpty(entity.IdEntity));
            Assert.True(string.IsNullOrEmpty(entity.VatNumber));
            Assert.True(entity.Addresses == null);
        }
    }
}

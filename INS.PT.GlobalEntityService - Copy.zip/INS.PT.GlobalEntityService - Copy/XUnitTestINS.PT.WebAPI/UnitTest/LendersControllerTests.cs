﻿using INS.PT.WebAPI.Controllers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Output;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestINS.PT.WebAPI.Context;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class LendersControllerTests
    {
        private readonly Mock<ILenders> _mockRepository;

        public LendersControllerTests()
        {
            _mockRepository = new Mock<ILenders>();

            _mockRepository.Setup(x => x.GetLendersAsync(It.IsAny<HeaderParameters>())).Returns(ValidLendersAsync());
        }


        private async Task<IEnumerable<LendersOutput>> ValidLendersAsync()
        {
            return await Task.Run(() => new List<LendersOutput>
                {
                    new LendersOutput
                    {
                        IdEntity="testEntity",
                         Name="test name"
                    }
                });
        }


        [Fact]
        public void GetLendersAsync_NoHeaders()
        {
            // Arrange
            var controller = new LendersController(_mockRepository.Object, null, new FakeCodesMapping());

            // Act
            var result = controller.GetLendersAsync().Result;

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<LendersOutput>>>(result);
            var badRequest = Assert.IsType<BadRequestObjectResult>(taskResult.Result);
            var objectResult = Assert.IsType<AggregateException>(badRequest.Value);
            Assert.NotNull(objectResult);
        }

        [Fact]
        public void GetLendersAsync_InvalidHeaders()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(
                    new HeaderParameters(new FakeCodesMapping())
                    {
                        IdCompany = "",
                        IdNetwork = "AGEAS",
                        BsSolution = "DUCKCREEK",
                        BsUser = "TESTE"
                    }
                );
            var controller = new LendersController(_mockRepository.Object, httpContext, new FakeCodesMapping());

            // Act
            var result = controller.GetLendersAsync().Result;

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<LendersOutput>>>(result);
            var badRequest = Assert.IsType<BadRequestObjectResult>(taskResult.Result);
            var objectResult = Assert.IsType<AggregateException>(badRequest.Value);
            Assert.NotNull(objectResult);
        }

        [Fact]
        public void GetLendersAsync_NotFound()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(
                    new HeaderParameters(new FakeCodesMapping())
                    {
                        IdCompany = "AGEAS",
                        IdNetwork = "AGEAS",
                        BsSolution = "DUCKCREEK",
                        BsUser = "TESTE"
                    }
                );
            var controller = new LendersController(_mockRepository.Object, httpContext, new FakeCodesMapping());
            _mockRepository.Reset();

            // Act
            var result = controller.GetLendersAsync().Result;

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<LendersOutput>>>(result);
            var notFoundRequest = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundRequest);
        }

        [Fact]
        public void GetLendersAsync_Valid()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(
                    new HeaderParameters(new FakeCodesMapping())
                    {
                        IdCompany = "AGEAS",
                        IdNetwork = "AGEAS",
                        BsSolution = "DUCKCREEK",
                        BsUser = "TESTE"
                    }
                );
            var controller = new LendersController(_mockRepository.Object, httpContext, new FakeCodesMapping());

            // Act
            var result = controller.GetLendersAsync().Result;

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<LendersOutput>>>(result);
            var okRequest = Assert.IsType<OkObjectResult>(taskResult.Result);
            var listResult = Assert.IsAssignableFrom<IEnumerable<LendersOutput>>(okRequest.Value);
            Assert.NotEmpty(listResult);
        }
    }
}

﻿using INS.PT.WebAPI;
using INS.PT.WebAPI.Models;
using Moq;
using Xunit;
using System.Threading.Tasks;
using System;
using INS.PT.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using XUnitTestINS.PT.WebAPI.Context;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class NotificationsControllerTests
    {
        private readonly Mock<INotifications> _mockRepository;

        public NotificationsControllerTests()
        {
            _mockRepository = new Mock<INotifications>();
            _mockRepository.Setup(x => x.SetNotificationDoneAsync(It.IsAny<HeaderParameters>(), "2233", "aiaTest"))
                .Returns(Task.Run(() => true));
            _mockRepository.Setup(x => x.SetNotificationDoneAsync(It.IsAny<HeaderParameters>(), "invalidDni", "aiaTest"))
                .Returns(Task.Run(() => false));

        }

        [Fact]
        public void PostNormalizedNameAsync_NoHeaders()
        {
            // Arrange
            var controller = new NotificationsController(_mockRepository.Object, null, new FakeCodesMapping());
            var parameters = new INS.PT.WebAPI.Models.Input.EntityNotificationInput();

            // Act
            var result = controller.PutSetNotificationAsync(parameters).Result;

            // Assert
            var taskResult = Assert.IsType<ActionResult<bool>>(result);
            var badRequest = Assert.IsType<BadRequestObjectResult>(taskResult.Result);
            var objectResult = Assert.IsType<AggregateException>(badRequest.Value);
            Assert.NotNull(objectResult);
        }

        [Fact]
        public void PostNormalizedNameAsync_InvalidHeaders()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(
                    new HeaderParameters(new FakeCodesMapping())
                    {
                        IdCompany = "",
                        IdNetwork = "AGEAS",
                        BsSolution = "DUCKCREEK",
                        BsUser = "TESTE"
                    }
                );
            var controller = new NotificationsController(_mockRepository.Object, httpContext, new FakeCodesMapping());
            var parameters = new INS.PT.WebAPI.Models.Input.EntityNotificationInput();

            // Act
            var result = controller.PutSetNotificationAsync(parameters).Result;

            // Assert
            var taskResult = Assert.IsType<ActionResult<bool>>(result);
            var badRequest = Assert.IsType<BadRequestObjectResult>(taskResult.Result);
            var objectResult = Assert.IsType<AggregateException>(badRequest.Value);
            Assert.NotNull(objectResult);
        }

        [Theory]
        [InlineData("2233")]
        [InlineData("invalidDni")]
        public void PostNormalizedNameAsync_ValidResponse(string idEntity)
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(
                    new HeaderParameters(new FakeCodesMapping())
                    {
                        IdCompany = "AGEAS",
                        IdNetwork = "AGEAS",
                        BsSolution = "DUCKCREEK",
                        BsUser = "TESTE"
                    }
                );
            var controller = new NotificationsController(_mockRepository.Object, httpContext, new FakeCodesMapping());
            var parameters = new INS.PT.WebAPI.Models.Input.EntityNotificationInput
            {
                IdEntity = idEntity
            };

            // Act
            var result = controller.PutSetNotificationAsync(parameters).Result;

            // Assert
            var taskResult = Assert.IsType<ActionResult<bool>>(result);
            var badRequest = Assert.IsType<OkObjectResult>(taskResult.Result);
            Assert.NotNull(badRequest.Value);
        }


    }
}

﻿using INS.PT.WebAPI.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using Xunit;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class ExceptionsTests
    {
        #region BaseException
        [Fact]
        public void BaseException_GetObjectData_Invalid()
        {
            // Arrange
            var baseException = new BaseException();
            System.Runtime.Serialization.SerializationInfo serializeInfo = null;
            var streamContext = new System.Runtime.Serialization.StreamingContext(System.Runtime.Serialization.StreamingContextStates.File);

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => baseException.GetObjectData(serializeInfo, streamContext));
        }

        [Fact]
        public void BaseException_GetObjectData_Valid()
        {
            // Arrange
            const string TestMessage = "test message";
            var baseException = new BaseException(TestMessage);
            var serializeInfo = new System.Runtime.Serialization.SerializationInfo(typeof(ExceptionsTests), new System.Runtime.Serialization.FormatterConverter());
            var streamContext = new System.Runtime.Serialization.StreamingContext(System.Runtime.Serialization.StreamingContextStates.File);

            // Act
            baseException.GetObjectData(serializeInfo, streamContext);

            // Assert
            var testValue = serializeInfo.GetValue(nameof(baseException.ErrorMessage), baseException.ErrorMessage.GetType());
            var value = Assert.IsType<string>(testValue);
            Assert.Equal(TestMessage, value);
        }

        [Fact]
        public void BaseException_ToString_Valid()
        {
            // Arrange
            const string TestMessage = "test message";
            const string TestCode = "errorCode";
            var baseException = new BaseException(TestMessage, TestCode);

            // Act
            var message = baseException.ToString();

            // Assert
            Assert.Contains(TestMessage, message);
            Assert.Contains(TestCode, message);
        }

        [Fact]
        public void BaseException_Message_Valid()
        {
            // Arrange
            const string TestMessage = "test message";
            var baseException = new BaseException(TestMessage, HttpStatusCode.BadRequest);

            // Act
            var message = baseException.Message;

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, baseException.StatusCode);
            Assert.Contains(TestMessage, message);
            Assert.Contains(((int)HttpStatusCode.BadRequest).ToString(System.Globalization.CultureInfo.InvariantCulture), message);
        }

        [Fact]
        public void BaseException_Message_ValidDescription()
        {
            // Arrange
            const string TestDescription = "test message";
            var baseException = new BaseException(TestDescription, new Exception(TestDescription));

            // Act
            var message = baseException.Message;

            // Assert
            Assert.NotNull(baseException.InnerException);
            Assert.Contains(baseException.InnerException.Message, message);
            Assert.Contains(TestDescription, message);
        }

        [Fact]
        public void BaseException_Message_ValidCodeAndDescription()
        {
            // Arrange
            const string TestDescription = "test message";
            const string TestCode = "test code";
            var baseException = new BaseException(TestCode, TestDescription, HttpStatusCode.BadRequest);

            // Act
            var message = baseException.Message;

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, baseException.StatusCode);
            Assert.Contains(TestDescription, message);
            Assert.Contains(TestCode, message);
        }

        [Fact]
        public void BaseException_Message_ValidCodeDescriptionInnerErrors()
        {
            // Arrange
            const string TestDescription = "test message";
            const string TestCode = "test code";
            var baseException = new BaseException(TestCode, TestDescription,
                new List<BaseException.InnerError>
                {
                    new BaseException.InnerError
                    {
                        ErrorCode = TestCode,
                        ErrorMessage = TestDescription
                    }
                });

            // Act
            var message = baseException.Message;

            // Assert
            Assert.Contains(TestDescription, message);
            Assert.Contains(TestCode, message);
            Assert.NotEmpty(baseException.InnerErrors);
            var innerError = baseException.InnerErrors.First();
            Assert.Contains(TestDescription, innerError.ErrorMessage);
            Assert.Contains(TestCode, innerError.ErrorCode);
        }
        #endregion

        #region BusinessException
        [Fact]
        public void BusinessException_GetObjectData_Invalid()
        {
            // Arrange
            var baseException = new BusinessException();
            System.Runtime.Serialization.SerializationInfo serializeInfo = null;
            var streamContext = new System.Runtime.Serialization.StreamingContext(System.Runtime.Serialization.StreamingContextStates.File);

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => baseException.GetObjectData(serializeInfo, streamContext));
        }

        [Fact]
        public void BusinessException_GetObjectData_Valid()
        {
            // Arrange
            const string TestMessage = "test message";
            var baseException = new BusinessException(TestMessage);
            var serializeInfo = new System.Runtime.Serialization.SerializationInfo(typeof(ExceptionsTests), new System.Runtime.Serialization.FormatterConverter());
            var streamContext = new System.Runtime.Serialization.StreamingContext(System.Runtime.Serialization.StreamingContextStates.File);

            // Act
            baseException.GetObjectData(serializeInfo, streamContext);

            // Assert
            var testValue = serializeInfo.GetValue(nameof(baseException.ErrorMessage), baseException.ErrorMessage.GetType());
            var value = Assert.IsType<string>(testValue);
            Assert.Equal(TestMessage, value);
        }

        [Fact]
        public void BusinessException_ToString_Valid()
        {
            // Arrange
            const string TestMessage = "test message";
            const string TestCode = "errorCode";
            var baseException = new BusinessException(TestMessage, TestCode);

            // Act
            var message = baseException.ToString();

            // Assert
            Assert.Contains(TestMessage, message);
            Assert.Contains(TestCode, message);
        }

        [Fact]
        public void BusinessException_Message_Valid()
        {
            // Arrange
            const string TestMessage = "test message";
            var baseException = new BusinessException(TestMessage, HttpStatusCode.BadRequest);

            // Act
            var message = baseException.Message;

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, baseException.StatusCode);
            Assert.Contains(TestMessage, message);
            Assert.Contains(((int)HttpStatusCode.BadRequest).ToString(System.Globalization.CultureInfo.InvariantCulture), message);
        }

        [Fact]
        public void BusinessException_Message_ValidDescription()
        {
            // Arrange
            const string TestDescription = "test message";
            var baseException = new BusinessException(TestDescription, new Exception(TestDescription));

            // Act
            var message = baseException.Message;

            // Assert
            Assert.NotNull(baseException.InnerException);
            Assert.Contains(baseException.InnerException.Message, message);
            Assert.Contains(TestDescription, message);
        }

        [Fact]
        public void BusinessException_Message_ValidCodeAndDescription()
        {
            // Arrange
            const string TestDescription = "test message";
            const string TestCode = "test code";
            var baseException = new BusinessException(TestCode, TestDescription, HttpStatusCode.BadRequest);

            // Act
            var message = baseException.Message;

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, baseException.StatusCode);
            Assert.Contains(TestDescription, message);
            Assert.Contains(TestCode, message);
        }

        [Fact]
        public void BusinessException_Message_ValidCodeDescriptionInnerErrors()
        {
            // Arrange
            const string TestDescription = "test message";
            const string TestCode = "test code";
            var baseException = new BusinessException(TestCode, TestDescription,
                new List<BaseException.InnerError>
                {
                    new BaseException.InnerError
                    {
                        ErrorCode = TestCode,
                        ErrorMessage = TestDescription
                    }
                });

            // Act
            var message = baseException.Message;

            // Assert
            Assert.Contains(TestDescription, message);
            Assert.Contains(TestCode, message);
            Assert.NotEmpty(baseException.InnerErrors);
            var innerError = baseException.InnerErrors.First();
            Assert.Contains(TestDescription, innerError.ErrorMessage);
            Assert.Contains(TestCode, innerError.ErrorCode);
        }
        #endregion

        #region CanonicalException
        [Fact]
        public void CanonicalException_GetObjectData_Invalid()
        {
            // Arrange
            var baseException = new CanonicalException();
            System.Runtime.Serialization.SerializationInfo serializeInfo = null;
            var streamContext = new System.Runtime.Serialization.StreamingContext(System.Runtime.Serialization.StreamingContextStates.File);

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => baseException.GetObjectData(serializeInfo, streamContext));
        }

        [Fact]
        public void CanonicalException_GetObjectData_Valid()
        {
            // Arrange
            const string TestMessage = "test message";
            var baseException = new CanonicalException(TestMessage);
            var serializeInfo = new System.Runtime.Serialization.SerializationInfo(typeof(ExceptionsTests), new System.Runtime.Serialization.FormatterConverter());
            var streamContext = new System.Runtime.Serialization.StreamingContext(System.Runtime.Serialization.StreamingContextStates.File);

            // Act
            baseException.GetObjectData(serializeInfo, streamContext);

            // Assert
            var testValue = serializeInfo.GetValue(nameof(baseException.ErrorMessage), baseException.ErrorMessage.GetType());
            var value = Assert.IsType<string>(testValue);
            Assert.Equal(TestMessage, value);
        }

        [Fact]
        public void CanonicalException_ToString_Valid()
        {
            // Arrange
            const string TestMessage = "test message";
            const string TestCode = "errorCode";
            var baseException = new CanonicalException(TestMessage, TestCode);

            // Act
            var message = baseException.ToString();

            // Assert
            Assert.Contains(TestMessage, message);
            Assert.Contains(TestCode, message);
        }

        [Fact]
        public void CanonicalException_Message_Valid()
        {
            // Arrange
            const string TestMessage = "test message";
            var baseException = new CanonicalException(TestMessage, HttpStatusCode.BadRequest);

            // Act
            var message = baseException.Message;

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, baseException.StatusCode);
            Assert.Contains(TestMessage, message);
            Assert.Contains(((int)HttpStatusCode.BadRequest).ToString(System.Globalization.CultureInfo.InvariantCulture), message);
        }

        [Fact]
        public void CanonicalException_Message_ValidDescription()
        {
            // Arrange
            const string TestDescription = "test message";
            var baseException = new CanonicalException(HttpStatusCode.BadRequest, TestDescription);

            // Act
            var message = baseException.Message;

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, baseException.StatusCode);
            Assert.Contains(TestDescription, message);
            Assert.Contains(((int)HttpStatusCode.BadRequest).ToString(System.Globalization.CultureInfo.InvariantCulture), message);
        }

        [Fact]
        public void CanonicalException_Message_ValidCodeAndDescription()
        {
            // Arrange
            const string TestDescription = "test message";
            const string TestCode = "test code";
            var baseException = new CanonicalException(TestCode, TestDescription, HttpStatusCode.BadRequest);

            // Act
            var message = baseException.Message;

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, baseException.StatusCode);
            Assert.Contains(TestDescription, message);
            Assert.Contains(TestCode, message);
        }

        [Fact]
        public void CanonicalException_Message_ValidCodeDescriptionInnerErrors()
        {
            // Arrange
            const string TestDescription = "test message";
            const string TestCode = "test code";
            var baseException = new CanonicalException(TestCode, TestDescription,
                new List<BaseException.InnerError>
                {
                    new BaseException.InnerError
                    {
                        ErrorCode = TestCode,
                        ErrorMessage = TestDescription
                    }
                });

            // Act
            var message = baseException.Message;

            // Assert
            Assert.Contains(TestDescription, message);
            Assert.Contains(TestCode, message);
            Assert.NotEmpty(baseException.InnerErrors);
            var innerError = baseException.InnerErrors.First();
            Assert.Contains(TestDescription, innerError.ErrorMessage);
            Assert.Contains(TestCode, innerError.ErrorCode);
        }
        #endregion

        #region AuthorizationException
        [Fact]
        public void AuthorizationException_GetObjectData_Invalid()
        {
            // Arrange
            var baseException = new AuthorizationException();
            System.Runtime.Serialization.SerializationInfo serializeInfo = null;
            var streamContext = new System.Runtime.Serialization.StreamingContext(System.Runtime.Serialization.StreamingContextStates.File);

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => baseException.GetObjectData(serializeInfo, streamContext));
        }

        [Fact]
        public void AuthorizationException_GetObjectData_Valid()
        {
            // Arrange
            const string TestMessage = "test message";
            var baseException = new AuthorizationException(TestMessage);
            var serializeInfo = new System.Runtime.Serialization.SerializationInfo(typeof(ExceptionsTests), new System.Runtime.Serialization.FormatterConverter());
            var streamContext = new System.Runtime.Serialization.StreamingContext(System.Runtime.Serialization.StreamingContextStates.File);

            // Act
            baseException.GetObjectData(serializeInfo, streamContext);

            // Assert
            var testValue = serializeInfo.GetValue(nameof(baseException.ErrorMessage), baseException.ErrorMessage.GetType());
            var value = Assert.IsType<string>(testValue);
            Assert.Equal(TestMessage, value);
        }

        [Fact]
        public void AuthorizationException_ToString_Valid()
        {
            // Arrange
            const string TestMessage = "test message";
            const string TestCode = "errorCode";
            var baseException = new AuthorizationException(TestMessage, TestCode);

            // Act
            var message = baseException.ToString();

            // Assert
            Assert.Contains(TestMessage, message);
            Assert.Contains(TestCode, message);
        }

        [Fact]
        public void AuthorizationException_Message_Valid()
        {
            // Arrange
            const string TestMessage = "test message";
            var baseException = new AuthorizationException(TestMessage, HttpStatusCode.BadRequest);

            // Act
            var message = baseException.Message;

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, baseException.StatusCode);
            Assert.Contains(TestMessage, message);
            Assert.Contains(((int)HttpStatusCode.BadRequest).ToString(System.Globalization.CultureInfo.InvariantCulture), message);
        }

        [Fact]
        public void AuthorizationException_Message_ValidDescription()
        {
            // Arrange
            const string TestDescription = "test message";
            var baseException = new AuthorizationException(HttpStatusCode.BadRequest, TestDescription);

            // Act
            var message = baseException.Message;

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, baseException.StatusCode);
            Assert.Contains(TestDescription, message);
            Assert.Contains(((int)HttpStatusCode.BadRequest).ToString(System.Globalization.CultureInfo.InvariantCulture), message);
        }

        [Fact]
        public void AuthorizationException_Message_ValidCodeAndDescription()
        {
            // Arrange
            const string TestDescription = "test message";
            const string TestCode = "test code";
            var baseException = new AuthorizationException(TestCode, TestDescription, HttpStatusCode.BadRequest);

            // Act
            var message = baseException.Message;

            // Assert
            Assert.Equal(HttpStatusCode.BadRequest, baseException.StatusCode);
            Assert.Contains(TestDescription, message);
            Assert.Contains(TestCode, message);
        }

        [Fact]
        public void AuthorizationException_Message_ValidCodeDescriptionInnerErrors()
        {
            // Arrange
            const string TestDescription = "test message";
            const string TestCode = "test code";
            var baseException = new AuthorizationException(TestCode, TestDescription, 
                new List<BaseException.InnerError>
                {
                    new BaseException.InnerError
                    {
                        ErrorCode = TestCode,
                        ErrorMessage = TestDescription
                    }
                });

            // Act
            var message = baseException.Message;

            // Assert
            Assert.Contains(TestDescription, message);
            Assert.Contains(TestCode, message);
            Assert.NotEmpty(baseException.InnerErrors);
            var innerError = baseException.InnerErrors.First();
            Assert.Contains(TestDescription, innerError.ErrorMessage);
            Assert.Contains(TestCode, innerError.ErrorCode);
        }
        #endregion
    }
}

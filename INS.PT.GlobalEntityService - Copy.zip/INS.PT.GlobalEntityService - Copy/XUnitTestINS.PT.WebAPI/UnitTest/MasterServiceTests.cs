﻿using AutoMapper;
using INS.PT.WebAPI;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Input;
using models = INS.PT.WebAPI.Models.Elements;
using INS.PT.WebAPI.Repository;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using System.Threading.Tasks;
using Tecnisys;
using Xunit;
using INS.PT.WebAPI.Exceptions;
using XUnitTestINS.PT.WebAPI.Context;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class MasterServiceTests
    {
        private readonly Mock<IMasterEntity> _mockmasterEntityService;
        private readonly IMapper _mapper;

        public MasterServiceTests()
        {
            _mockmasterEntityService = new Mock<IMasterEntity>();
            _mockmasterEntityService.Setup(x => x.GetEntityAsync(
                It.IsAny<GetEntityRequest>()
                ))
                .Returns(ValidGetEntityAsync());

            _mockmasterEntityService.Setup(x => x.MergeEntityAsync(
                It.IsAny<MergeEntityRequest>()
                )).Returns(ValidMergeEntityAsync());

            _mapper = null;
            var serviceCollection = new ServiceCollection();
            Startup.Setups.SetupMappings(serviceCollection);

            foreach (var service in serviceCollection)
            {
                if (service.ImplementationInstance is IMapper mapper)
                {
                    _mapper = mapper;
                    break;
                }
            }
        }


        private async Task<GetEntityResponse> ValidGetEntityAsync()
        {
            return await Task.Run(() => new GetEntityResponse { GetEntityResult = Fake_ValidResponse() });
        }

        private async Task<GetEntityResponse> InvalidGetEntityAsync()
        {
            return await Task.Run(() => new GetEntityResponse { GetEntityResult = Fake_InvalidResponse() });
        }

        private async Task<MergeEntityResponse> ValidMergeEntityAsync()
        {
            return await Task.Run(() => new MergeEntityResponse { MergeEntityResult = Fake_ValidResponse() });
        }

        private async Task<MergeEntityResponse> InvalidMergeEntityAsync()
        {
            return await Task.Run(() => new MergeEntityResponse { MergeEntityResult = Fake_InvalidResponse() });
        }

        private ResponseEntity Fake_ValidResponse()
        {
            var result = new ResponseEntity
            {
                Entity = new Entity()
                {
                    dni = "10592272",
                    firstName = "PAULO",
                    middleName = "DUMMY",
                    lastName = "SOUSA",
                    nationalityCode = 1,
                    nationalityDescription = "Portuguesa",
                    vatNumber = "213200104",
                    person = new Person
                    {
                        genderCode = "H",
                        genderDescription = "Homem",
                        birthDate = new System.DateTime(1989, 01, 01),
                        maritalStatusCode = "C",
                        maritalStatusDescription = "Casado(a)",
                        driverLicenses = new DriverLicense[] { },
                        honoraryTitles = new HonoraryTitle[] { },
                        jobs = new Job[] { },
                        internalEmployee = null
                    },
                    organization = new Organization
                    {
                        caes = new CAE[] { new CAE { caeOrderNumber = "1" } },
                        organizationalContacts = new OrganizationContactPoint[] { },
                    },
                    addresses = new Address[]
                    {
                        new Address()
                        {
                            sequenceNumber= 1,
                            addressTypeCode= "1",
                            addressTypeDescription= "Principal",
                            roadType= "TRAVESSA",
                            roadName= "DA BOAVISTA",
                            houseNumber= "15",
                            floorNumber= "RC",
                            doorNumber= "DTO",
                            addToAddress= "MOSCAVIDE",
                            fullAddress= "TRAVESSA DA BOAVISTA 15 RC DTO MOSCAVIDE",
                            postalCountry= new Country
                            {
                                countryCode= 620,
                                countryDescription= "Portugal"
                            },
                            postalCode= "2490-100",
                            postalCodeDescription= "ATOUGUIA"
                        }
                    },
                    entityContactPoints = new EntityContactPoints
                    {
                        emails = new Email[] { new Email { emailIdentifier = 1 } },
                        phones = new Phone[] { new Phone { phoneIdentifier = "1" } },
                    },
                    bankAccounts = new BankAccount[] { new BankAccount { orderNumber = 1 } },
                    entityCards = new EntityCards
                    {
                        axaClubCards = new AxaClubCard[] { },
                        repsolCards = new RepsolCard[] { }
                    },
                    entityTaxes = new EntityTaxes
                    {
                        irc = null,
                        irs = null,
                        taxRegime = null
                    },
                    entityDocuments = new EntityDocuments
                    {
                        identityDocument = null,
                        documents = new Document[] { },
                        foreignDocuments = new ForeignDocument[] { new ForeignDocument { documentTypeCode = "CC", documentNumber = "1" } }
                    },
                    marketing = null,
                    crm = null,
                    merges = new Merge[] { }
                },
                Errors = new ServiceError[]
                {
                    new ServiceError
                    {
                        Code = "APP-MRG-OPR-00000",
                        Message = "The operation completed successfully.",
                        Type = "APPLICATION"
                    }
                }
            };

            return result;
        }

        private ResponseEntity Fake_InvalidResponse()
        {
            var result = new ResponseEntity
            {
                Entity = null,
                Errors = new ServiceError[]
                {
                        new ServiceError
                        {
                            Code = "APP-INS-ENT-100252",
                            Message = "Test error.",
                            Type = "CUSTOM"
                        }
                }
            };

            return result;
        }


        [Fact]
        public async Task GetEntityAsync_Read_ValidAsync()
        {
            // Arrange
            var service = new MasterService(_mapper, _mockmasterEntityService.Object);
            var headerParameters = new HeaderParameters (new FakeCodesMapping()) { BsUser = @"\bs\testUser" };
            var parameters = new EntitiesInput { IdEntity = "validId" };

            // Act
            var taskResult = await service.GetEntityAsync(headerParameters, "validSOurce", parameters);

            // Assert
            var result = Assert.IsAssignableFrom<models.Entity>(taskResult);
            Assert.Equal("10592272", result.IdEntity);
        }

        [Fact]
        public void GetEntityAsync_Read_Invalid()
        {
            // Arrange
            var service = new MasterService(_mapper, _mockmasterEntityService.Object);
            var headerParameters = new HeaderParameters (new FakeCodesMapping()) { BsUser = @"\bs\testUser" };
            var parameters = new EntitiesInput { IdEntity = "invalidId" };
            _mockmasterEntityService.Setup(x => x.GetEntityAsync(
                It.IsAny<GetEntityRequest>()
                ))
                .Returns(InvalidGetEntityAsync());

            // Act and Assert
            Assert.ThrowsAsync<CanonicalException>(() => service.GetEntityAsync(headerParameters, "validSOurce", parameters));
        }

        [Fact]
        public async Task CreateUpdateEntityAsync_Insert_ValidAsync()
        {
            // Arrange
            var service = new MasterService(_mapper, _mockmasterEntityService.Object);
            var headerParameters = new HeaderParameters (new FakeCodesMapping()) { BsUser = @"\bs\testUser" };
            var parameters = new models.Entity { IdEntity = "validId" };

            // Act
            var taskResult = await service.CreateUpdateEntityAsync(headerParameters, "validSOurce", 
                INS.PT.WebAPI.Helpers.MdmOperation.Insert, parameters);

            // Assert
            var result = Assert.IsAssignableFrom<models.Entity>(taskResult);
            Assert.Equal("10592272", result.IdEntity);
        }

        [Fact]
        public async Task CreateUpdateEntityAsync_Update_ValidAsync()
        {
            // Arrange
            var service = new MasterService(_mapper, _mockmasterEntityService.Object);
            var headerParameters = new HeaderParameters (new FakeCodesMapping()) { BsUser = @"\bs\testUser" };
            var newEntity = new models.Entity { IdEntity = "validId" };
            var parameters = new EntitiesInput { IdEntity = "validId" };
            // call get to read information
            await service.GetEntityAsync(headerParameters, "validSOurce", parameters);

            // Act
            var taskResult = await service.CreateUpdateEntityAsync(headerParameters, "validSOurce", 
                INS.PT.WebAPI.Helpers.MdmOperation.Update, newEntity);

            // Assert
            var result = Assert.IsAssignableFrom<models.Entity>(taskResult);
            Assert.Equal("10592272", result.IdEntity);
        }

        [Fact]
        public void CreateUpdateEntityAsync_Insert_Invalid()
        {
            // Arrange
            var service = new MasterService(_mapper, _mockmasterEntityService.Object);
            var headerParameters = new HeaderParameters (new FakeCodesMapping()) { BsUser = @"\bs\testUser" };
            var parameters = new models.Entity { IdEntity = "validId" };
            _mockmasterEntityService.Setup(x => x.GetEntityAsync(
                It.IsAny<GetEntityRequest>()
                ))
                .Returns(InvalidGetEntityAsync());

            // Act and Assert
            Assert.ThrowsAsync<CanonicalException>(() => service.CreateUpdateEntityAsync(headerParameters, "validSOurce", 
                INS.PT.WebAPI.Helpers.MdmOperation.Insert, parameters));
        }
    }
}

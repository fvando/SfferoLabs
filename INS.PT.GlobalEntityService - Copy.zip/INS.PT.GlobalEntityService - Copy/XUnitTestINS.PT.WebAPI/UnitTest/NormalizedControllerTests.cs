﻿using Xunit;
using INS.PT.WebAPI;
using Moq;
using Microsoft.AspNetCore.Mvc;
using INS.PT.WebAPI.Models.Output;
using XUnitTestINS.PT.WebAPI.Context;
using System;
using INS.PT.WebAPI.Models;
using XUnitTestINS.PT.WebAPI.TestValues;
using INS.PT.WebAPI.Exceptions;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class NormalizedControllerTests
    {
        private readonly Mock<INormalized> _mockRepository;
        private readonly INS.PT.WebAPI.IdTranslates.CodesMapping _codesMapping;

        public NormalizedControllerTests()
        {
            _mockRepository = new Mock<INormalized>();

            _codesMapping = new FakeCodesMapping();
        }

        #region Normalize name
        [Fact]
        public void Post_NormalizeName_NoHeaders()
        {
            // Arrange
            var controller = new INS.PT.WebAPI.Controllers.NormalizedController(_mockRepository.Object, null, _codesMapping);
            var parameters = new INS.PT.WebAPI.Models.Input.NormalizedNameInput();

            // Act
            var result = controller.PostNormalizedNameAsync(parameters).Result;

            // Assert
            Assert.IsType<ActionResult<NormalizedNameOutput>>(result);
            Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Null(result.Value);
        }

        [Fact]
        public void Post_NormalizeName_InvalidHeaders()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(
                    new HeaderParameters(_codesMapping)
                    {
                        IdCompany = "",
                        IdNetwork = "AGEAS",
                        BsSolution = "DUCKCREEK",
                        BsUser = "TESTE"
                    }
                );
            var controller = new INS.PT.WebAPI.Controllers.NormalizedController(_mockRepository.Object, httpContext, _codesMapping);
            var parameters = new INS.PT.WebAPI.Models.Input.NormalizedNameInput();

            // Act
            var result = controller.PostNormalizedNameAsync(parameters).Result;

            // Assert
            Assert.IsType<ActionResult<NormalizedNameOutput>>(result);
            Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Null(result.Value);
        }

        [Theory]
        [ClassData(typeof(TestInvalidNameDataGenerator))]
        public void Post_NormalizeName_InvalidParameters(string name, string gender, DateTime? birthdate)
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new INS.PT.WebAPI.Controllers.NormalizedController(_mockRepository.Object, httpContext, _codesMapping);
            var parameters = new INS.PT.WebAPI.Models.Input.NormalizedNameInput()
            {
                Name = name,
                Gender = gender,
                Birthdate = birthdate
            };

            var output = new NormalizedNameOutput()
            {
                IsNormalized = false,
                ErrorCode = 123,
                ErrorMessage = "Invalid parameters.",
            };

            _mockRepository.Setup(x => x.GetNormalizedName(parameters)).Returns(output);

            // Act
            var result = controller.PostNormalizedNameAsync(parameters).Result;

            // Assert
            Assert.IsType<ActionResult<NormalizedNameOutput>>(result);
            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            var returnObject = outputObject.Value as NormalizedNameOutput;
            Assert.NotNull(returnObject);
            Assert.NotEqual(0, returnObject.ErrorCode);
            Assert.False(string.IsNullOrEmpty(returnObject.ErrorMessage));
        }

        [Theory]
        [ClassData(typeof(TestValidNameDataGenerator))]
        public void Post_NormalizeName_ValidParameters(string name, string gender, DateTime? birthdate)
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new INS.PT.WebAPI.Controllers.NormalizedController(_mockRepository.Object, httpContext, _codesMapping);
            var parameters = new INS.PT.WebAPI.Models.Input.NormalizedNameInput()
            {
                Name = name,
                Gender = gender,
                Birthdate = birthdate
            };

            var output = new NormalizedNameOutput()
            {
                IsNormalized = false,
                ErrorCode = 0,
                ErrorMessage = null,
                FirstName = "Test"
            };

            _mockRepository.Setup(x => x.GetNormalizedName(parameters)).Returns(output);

            // Act
            var result = controller.PostNormalizedNameAsync(parameters).Result;

            // Assert
            Assert.IsType<ActionResult<NormalizedNameOutput>>(result);
            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            var returnObject = outputObject.Value as NormalizedNameOutput;
            Assert.NotNull(returnObject);
            Assert.Equal(0, returnObject.ErrorCode);
            Assert.True(string.IsNullOrEmpty(returnObject.ErrorMessage));
            Assert.False(string.IsNullOrEmpty(returnObject.FirstName));
        }

        #endregion


        #region Normalize address

        [Fact]
        public void Post_NormalizeAddress_NoHeaders()
        {
            // Arrange
            var controller = new INS.PT.WebAPI.Controllers.NormalizedController(_mockRepository.Object, null, _codesMapping);
            var parameters = new INS.PT.WebAPI.Models.Input.NormalizedAddressInput();

            // Act
            var result = controller.PostNormalizedAddressAsync(parameters).Result;

            // Assert
            Assert.IsType<ActionResult<NormalizedAddressOutput>>(result);
            Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Null(result.Value);
        }

        [Fact]
        public void Post_NormalizeAddress_InvalidHeaders()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(
                    new HeaderParameters(_codesMapping)
                    {
                        IdCompany = "",
                        IdNetwork = "AGEAS",
                        BsSolution = "DUCKCREEK",
                        BsUser = "TESTE"
                    }
                );
            var controller = new INS.PT.WebAPI.Controllers.NormalizedController(_mockRepository.Object, httpContext, _codesMapping);
            var parameters = new INS.PT.WebAPI.Models.Input.NormalizedAddressInput();

            // Act
            var result = controller.PostNormalizedAddressAsync(parameters).Result;

            // Assert
            Assert.IsType<ActionResult<NormalizedAddressOutput>>(result);
            Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Null(result.Value);
        }

        [Theory]
        [InlineData("", "", "", "", "", "", "", "", "")]
        public void Post_NormalizeAddress_InvalidParameters(string roadType, string roadName, string houseNumber
            , string floorNumber, string doorNumber, string addToAddress, string locality, string postalCode, string postalCodeDescription)
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new INS.PT.WebAPI.Controllers.NormalizedController(_mockRepository.Object, httpContext, _codesMapping);
            var parameters = new INS.PT.WebAPI.Models.Input.NormalizedAddressInput
            {
                RoadType = roadType,
                RoadName = roadName,
                HouseNumber = houseNumber,
                FloorNumber = floorNumber,
                DoorNumber = doorNumber,
                AddToAddress = addToAddress,
                Locality = locality,
                PostalCode = postalCode,
                PostalCodeDescription = postalCodeDescription
            };

            _mockRepository.Setup(x => x.GetNormalizedAddress(parameters)).Returns(
                () => { throw new BaseException("test error code", "test error message"); });

            // Act
            var result = controller.PostNormalizedAddressAsync(parameters).Result;

            // Assert
            Assert.IsType<ActionResult<NormalizedAddressOutput>>(result);
            Assert.IsType<BadRequestObjectResult>(result.Result);

            var outputObject = result.Result as BadRequestObjectResult;
            Assert.NotNull(outputObject);

            var returnObject = outputObject.Value as BaseException;
            Assert.NotNull(returnObject);
        }

        [Theory]
        [InlineData("rua", "ricardo reis", "3", "4", "e", "bairro", "famoes", "1700-122", "lisboa")]
        public void Post_NormalizeAddress_ValidParameters(string roadType, string roadName, string houseNumber
            , string floorNumber, string doorNumber, string addToAddress, string locality, string postalCode, string postalCodeDescription)
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new INS.PT.WebAPI.Controllers.NormalizedController(_mockRepository.Object, httpContext, _codesMapping);
            var parameters = new INS.PT.WebAPI.Models.Input.NormalizedAddressInput
            {
                RoadType = roadType,
                RoadName = roadName,
                HouseNumber = houseNumber,
                FloorNumber = floorNumber,
                DoorNumber = doorNumber,
                AddToAddress = addToAddress,
                Locality = locality,
                PostalCode = postalCode,
                PostalCodeDescription = postalCodeDescription
            };

            var output = new NormalizedAddressOutput()
            {
                RoadType = roadType,
                RoadName = roadName,
                HouseNumber = houseNumber,
                FloorNumber = floorNumber,
                DoorNumber = doorNumber,
                AddToAddress = addToAddress,
                Locality = locality,
                PostalCode = postalCode,
                PostalCodeDescription = postalCodeDescription,
                IsNormalized = true               
            };

            _mockRepository.Setup(x => x.GetNormalizedAddress(parameters)).Returns(output);

            // Act
            var result = controller.PostNormalizedAddressAsync(parameters).Result;

            // Assert
            Assert.IsType<ActionResult<NormalizedAddressOutput>>(result);
            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            var returnObject = outputObject.Value as NormalizedAddressOutput;
            Assert.NotNull(returnObject);
            Assert.True(returnObject.IsNormalized);
        }
        #endregion
    }
}

﻿using INS.PT.WebAPI.Models;
using Moq;
using Xunit;
using System;
using INS.PT.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using XUnitTestINS.PT.WebAPI.Context;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models.Elements;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class GetEntityControllerTests
    {
        private readonly Mock<IGetEntity> _mockRepository;

        public GetEntityControllerTests()
        {
            _mockRepository = new Mock<IGetEntity>();
            _mockRepository.Setup(x => x.EntityByVatNumberAsync(It.IsAny<HeaderParameters>(), "500123055"))
                .ReturnsAsync(new Entity
                {
                    IdEntity = "testEntity",
                    VatNumber = "500123055"
                });
        }


        [Fact]
        public void GetEntityAsync_NoHeaders()
        {
            // Arrange
            var controller = new GetEntityController(_mockRepository.Object, null, new FakeCodesMapping());

            // Act
            var result = controller.GetEntityByVatNumberAsync(It.IsAny<string>()).Result;

            // Assert
            var taskResult = Assert.IsType<ActionResult<Entity>>(result);
            var badRequest = Assert.IsType<BadRequestObjectResult>(taskResult.Result);
            var objectResult = Assert.IsType<AggregateException>(badRequest.Value);
            Assert.NotNull(objectResult);
        }

        [Fact]
        public void GetEntityAsync_InvalidHeaders()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(
                    new HeaderParameters(new FakeCodesMapping())
                    {
                        IdCompany = "",
                        IdNetwork = "AGEAS",
                        BsSolution = "DUCKCREEK",
                        BsUser = "TESTE"
                    }
                );
            var controller = new GetEntityController(_mockRepository.Object, httpContext, new FakeCodesMapping());

            // Act
            var result = controller.GetEntityByVatNumberAsync(It.IsAny<string>()).Result;

            // Assert
            var taskResult = Assert.IsType<ActionResult<Entity>>(result);
            var badRequest = Assert.IsType<BadRequestObjectResult>(taskResult.Result);
            var objectResult = Assert.IsType<AggregateException>(badRequest.Value);
            Assert.NotNull(objectResult);
        }

        [Fact]
        public void GetEntityAsync_ValidResponse()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(
                    new HeaderParameters(new FakeCodesMapping())
                    {
                        IdCompany = "AGEAS",
                        IdNetwork = "AGEAS",
                        BsSolution = "DUCKCREEK",
                        BsUser = "TESTE"
                    }
                );
            var controller = new GetEntityController(_mockRepository.Object, httpContext, new FakeCodesMapping());

            // Act
            var result = controller.GetEntityByVatNumberAsync("500123055").Result;

            // Assert
            var taskResult = Assert.IsType<ActionResult<Entity>>(result);
            var badRequest = Assert.IsType<OkObjectResult>(taskResult.Result);
            Assert.NotNull(badRequest.Value);
        }
    }
}

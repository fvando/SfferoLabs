﻿using INS.PT.WebAPI;
using INS.PT.WebAPI.Controllers;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Elements;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using XUnitTestINS.PT.WebAPI.Context;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class EntitiesControllerTests
    {
        private readonly Mock<IEntity> _mockRepository;
        private readonly INS.PT.WebAPI.IdTranslates.CodesMapping _codesMapping;

        public EntitiesControllerTests()
        {
            _mockRepository = new Mock<IEntity>();

            _codesMapping = new FakeCodesMapping();
        }

        public class TestEntitiesController : EntitiesController
        {
            public TestEntitiesController(HeaderParameters headerParameters, IEntity repository, IHttpContextAccessor httpContext) : base(repository, httpContext, new FakeCodesMapping())
            {
                HeaderParameters = headerParameters ?? throw new ArgumentNullException(nameof(headerParameters));
            }

            public HeaderParameters HeaderParameters { get; set; }

            protected override HeaderParameters ValidateHeader()
            {
                return HeaderParameters;
            }
        }

        private static INS.PT.WebAPI.Models.Input.EntitiesInput FakeEntitiesInput()
        {
            return new INS.PT.WebAPI.Models.Input.EntitiesInput()
            {
                IdEntity = "10603154"
            };
        }

        private static FakeHeaderParameters InvalidHeaderValues()
        {
            return new FakeHeaderParameters(
                    new HeaderParameters(new FakeCodesMapping())
                    {
                        IdCompany = "",
                        IdNetwork = "AGEAS",
                        BsSolution = "DUCKCREEK",
                        BsUser = "TESTE"
                    }
                );
        }

        private static void AssertPersonEntity(string id, Entity outEntity)
        {
            Assert.NotNull(outEntity);
            Assert.Equal(id, outEntity.IdEntity);
            Assert.Equal("500123123", outEntity.VatNumber);
            Assert.False(outEntity.IsForeignVat);
            Assert.Equal("1", outEntity.CountryCode);
            Assert.Equal("Portugal", outEntity.CountryDescription);
        }

        private static Entity FakePersonEntity(string id)
        {
            return new Entity
            {
                IdEntity = id,
                VatNumber = "500123123",
                IsForeignVat = false,
                CountryCode = "1",
                CountryDescription = "Portugal",
            };
        }

        private static void AssertPerson(Person person)
        {
            Assert.NotNull(person);
            Assert.Equal("Joana Gomes", person.Name);
            Assert.Equal(new DateTime(2019, 06, 14), person.Birthdate);
            Assert.Equal("M", person.Gender);
            Assert.Equal("V", person.MaritalStatus);
            Assert.False(person.IsDeceased);
            Assert.Null(person.DeceasedDate);
            Assert.False(person.IsSelfEmployee);
            Assert.Equal("Lisboa", person.PlaceOfBirth);

            Assert.True(person.Nationalities.Any());
            var nat = person.Nationalities.First();
            Assert.Equal("1", nat.NationalityCode);
            Assert.Equal("Portuguesa", nat.NationalityDescription);
            Assert.True(nat.IsPrincipal);

            Assert.True(person.HonoraryTitles.Any());
            var title = person.HonoraryTitles.First();
            Assert.Equal("Sr.", title.TitleCode);
            Assert.Equal("Senhor", title.TitleDescription);
            Assert.Equal(new DateTime(2019, 06, 14), title.StartDate);
            Assert.Null(title.EndDate);

            Assert.True(person.Jobs.Any());
            var job = person.Jobs.First();
            Assert.Equal("1", job.ProfessionalCode);
            Assert.Equal("Dummy work", job.ProfessionalDescription);
            Assert.True(job.IsPrincipal);
            Assert.Equal("ACT", job.LaborStatusCode);
            Assert.Equal("Work example only", job.LaborStatusDescription);
            Assert.Equal("Big company", job.EmployerEntity);
            Assert.Equal(new DateTime(2018, 02, 14), job.StartDate);
            Assert.Null(job.EndDate);

            Assert.True(person.DriverLicences.Any());
            Assert.Equal("L-12345", person.DriverLicences.First().DriverLicenceNumber);
            Assert.Equal("1", person.DriverLicences.First().CountryCode);
            Assert.Equal("Portugal", person.DriverLicences.First().CountryDescription);
        }

        private static Entity.EntityType FakePerson()
        {
            return new Entity.EntityType
            {
                Individual = new Person
                {
                    Name = "Joana Gomes",
                    Birthdate = new DateTime(2019, 06, 14),
                    Gender = "M",
                    MaritalStatus = "V",
                    IsDeceased = false,
                    DeceasedDate = null,
                    IsSelfEmployee = false,
                    PlaceOfBirth = "Lisboa",
                    Nationalities = new List<Nationality>
                    {
                        new Nationality
                        {
                            NationalityCode = "1",
                            NationalityDescription = "Portuguesa",
                            IsPrincipal = true
                        }
                    },
                    HonoraryTitles = new List<HonoraryTitle>
                    {
                        new HonoraryTitle
                        {
                            TitleCode = "Sr.",
                            TitleDescription = "Senhor",
                            StartDate = new DateTime(2019, 06, 14),
                            EndDate = null
                        }
                    },
                    Jobs = new List<Job>
                    {
                        new Job
                        {
                            ProfessionalCode = "1",
                            ProfessionalDescription = "Dummy work",
                            IsPrincipal = true,
                            LaborStatusCode = "ACT",
                            LaborStatusDescription = "Work example only",
                            EmployerEntity = "Big company",
                            StartDate = new DateTime(2018, 02, 14),
                            EndDate = null
                        }
                    },
                    DriverLicences = new List<DriverLicence>
                    {
                        new DriverLicence
                        {
                            DriverLicenceNumber = "L-12345",
                            CountryCode = "1",
                            CountryDescription = "Portugal",
                            Categories = new List<Category>
                            {
                                new Category
                                {
                                    Code = "A",
                                    StartDate = new DateTime(2019, 05, 02),
                                    EndDate = new DateTime(2019, 06, 14)
                                }
                            }
                        }
                    }
                }
            };
        }

        private static void AssertAddress(string id, Address address)
        {
            Assert.NotNull(address);

            Assert.Equal(id, address.Sequence);
            Assert.Equal("S", address.AddressType);
            Assert.Equal("Principal", address.AddressTypeDescription);
            Assert.True(address.IsFiscalAddress);
            Assert.Equal("L", address.FormatType);
            Assert.NotNull(address.Tipology);
            Assert.NotNull(address.Tipology.PostalAddress);
            Assert.Equal("RUA", address.Tipology.PostalAddress.RoadType);
            Assert.Equal("25 de Abril", address.Tipology.PostalAddress.RoadName);
            Assert.Equal("13", address.Tipology.PostalAddress.HouseNumber);
            Assert.Equal("5", address.Tipology.PostalAddress.FloorNumber);
            Assert.Equal("F", address.Tipology.PostalAddress.DoorNumber);
            Assert.Equal("Bairro de Abril", address.Tipology.PostalAddress.AddToAddress);
            Assert.Equal("Rua 25 de Abril, 13 5F - Bairro de Abril", address.Tipology.PostalAddress.FullAddress);
            Assert.Equal("Manteigas", address.Tipology.PostalAddress.Locality);
            Assert.Null(address.Tipology.PostalBox);
            Assert.True(address.IsReturnedForCorrection);
            Assert.Equal("2690-022", address.PostalCode);
            Assert.Equal("Torres Vedras", address.PostalCodeDescription);
            Assert.Equal("1", address.CountryCode);
            Assert.Equal("Portugal", address.CountryDescription);
            Assert.Equal("123.22;43.21", address.Georeference);
        }

        private static Address FakeAddress(string id)
        {
            return new Address
            {
                Sequence = id,
                AddressType = "S",
                AddressTypeDescription = "Principal",
                IsFiscalAddress = true,
                FormatType = "L",
                Tipology = new AddressTipology
                {
                    PostalAddress = new PoAddress()
                    {
                        RoadType = "RUA",
                        RoadName = "25 de Abril",
                        HouseNumber = "13",
                        FloorNumber = "5",
                        DoorNumber = "F",
                        AddToAddress = "Bairro de Abril",
                        FullAddress = "Rua 25 de Abril, 13 5F - Bairro de Abril",
                        Locality = "Manteigas"
                    },
                    PostalBox = null
                },
                IsReturnedForCorrection = true,
                PostalCode = "2690-022",
                PostalCodeDescription = "Torres Vedras",
                CountryCode = "1",
                CountryDescription = "Portugal",
                Georeference = "123.22;43.21"
            };
        }

        private static Phone FakePhone()
        {
            return new Phone
            {
                PhoneIdentifier = "234",
                IsPreferred = true,
                PhoneTypeCode = "MOB",
                PhoneTypeDescription = "Telemovel",
                PhoneNumber = "921345890"
            };
        }
        private static void AssertPhone(Phone phone)
        {
            Assert.NotNull(phone);

            Assert.Equal("234", phone.PhoneIdentifier);
            Assert.True(phone.IsPreferred);
            Assert.Equal("MOB", phone.PhoneTypeCode);
            Assert.Equal("Telemovel", phone.PhoneTypeDescription);
            Assert.Equal("921345890", phone.PhoneNumber);
        }

        private static Email FakeEmail()
        {
            return new Email
            {
                EmailIdentifier = 1,
                IsPreferred = true,
                EmailTypeCode = "PO",
                EmailTypeDescription = "E-Mail profissional",
                EmailAddress = "rsilva@ageas.pt"
            };
        }

        private static void AssertEmail(Email email)
        {
            Assert.NotNull(email);

            Assert.Equal(1, email.EmailIdentifier);
            Assert.True(email.IsPreferred);
            Assert.Equal("PO", email.EmailTypeCode);
            Assert.Equal("E-Mail profissional", email.EmailTypeDescription);
            Assert.Equal("rsilva@ageas.pt", email.EmailAddress);
        }

        private static BankAccount FakeBankAccount()
        {
            return new BankAccount
            {
                SequenceBankAccountNumber = 1,
                BankAccountNumber = "3635364445",
                Iban = "004593737492772848947"
            };
        }
        private static void AssertBankAccount(BankAccount bankAccount)
        {
            Assert.NotNull(bankAccount);

            Assert.Equal(1, bankAccount.SequenceBankAccountNumber);
            Assert.Equal("3635364445", bankAccount.BankAccountNumber);
            Assert.Equal("004593737492772848947", bankAccount.Iban);
        }

        private static Document FakeDocument()
        {
            return new Document
            {
                DocumentTypeCode = "CC",
                DocumentTypeDescription = "Cartão Cidadão",
                DocumentNumber = "122334411",
                DocumentCountryCode = "1",
                DocumentCountryDescription = "Portugal",
                IssueDate = new DateTime(2018, 7, 3),
                ExpirationDate = new DateTime(2018 + 5, 7, 2)
            };
        }

        private static void AssertDocument(Document document)
        {
            Assert.NotNull(document);

            Assert.Equal("CC", document.DocumentTypeCode);
            Assert.Equal("Cartão Cidadão", document.DocumentTypeDescription);
            Assert.Equal("122334411", document.DocumentNumber);
            Assert.Equal("1", document.DocumentCountryCode);
            Assert.Equal("Portugal", document.DocumentCountryDescription);
            Assert.Equal(new DateTime(2018, 7, 3), document.IssueDate);
            Assert.Equal(new DateTime(2018 + 5, 7, 2), document.ExpirationDate);
        }

        private static Cae FakeCae()
        {
            return new Cae
            {
                CaeOrderNumber = 1,
                IsPrincipal = true,
                CaeNumber = "47845",
                CaeDescription = "Dummy work",
                CountryCode = "1",
                CountryDescription = "Portugal",
                SectorOfActivity = "nearshore",
                StartDate = new DateTime(2018, 4, 22),
                EndDate = null
            };
        }

        private static void AssertCae(Cae cae)
        {
            Assert.NotNull(cae);

            Assert.Equal(1, cae.CaeOrderNumber);
            Assert.True(cae.IsPrincipal);
            Assert.Equal("47845", cae.CaeNumber);
            Assert.Equal("Dummy work", cae.CaeDescription);
            Assert.Equal("1", cae.CountryCode);
            Assert.Equal("Portugal", cae.CountryDescription);
            Assert.Equal("nearshore", cae.SectorOfActivity);
            Assert.Equal(new DateTime(2018, 4, 22), cae.StartDate);
            Assert.Null(cae.EndDate);
        }

        private static AffinityRelation FakeAffinity()
        {
            return new AffinityRelation
            {
                RelatedEntityIdentifier = "2233",
                RelationCode = "PAI",
                RelationDescription = "Pai",
                RelationIdentifier = 1
            };
        }
        private static void AssertAffinity(AffinityRelation affinity)
        {
            Assert.NotNull(affinity);

            Assert.Equal("2233", affinity.RelatedEntityIdentifier);
            Assert.Equal("PAI", affinity.RelationCode);
            Assert.Equal("Pai", affinity.RelationDescription);
            Assert.Equal(1, affinity.RelationIdentifier);
        }


        [Fact]
        public void GetEntity_NoHeaders()
        {
            // Arrange
            var controller = new EntitiesController(_mockRepository.Object, null, _codesMapping);
            var parameters = new INS.PT.WebAPI.Models.Input.EntitiesInput();

            // Act
            var result = controller.GetEntityAsync(parameters).Result;

            // Assert
            Assert.IsType<ActionResult<Entity>>(result);
            Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Null(result.Value);
        }

        [Fact]
        public void GetEntity_InvalidHeaders()
        {
            // Arrange
            var httpContext = InvalidHeaderValues();
            var controller = new EntitiesController(_mockRepository.Object, httpContext, _codesMapping);
            var parameters = new INS.PT.WebAPI.Models.Input.EntitiesInput();

            // Act
            var result = controller.GetEntityAsync(parameters).Result;

            // Assert
            Assert.IsType<ActionResult<Entity>>(result);
            Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.Null(result.Value);
        }

        [Theory]
        [InlineData("")]
        [InlineData("qwe123098o123098qaz01")]
        [InlineData("     ")]
        public void GetEntity_InvalidParameters(string idEntity)
        {
            // Arrange
            var parameters = new INS.PT.WebAPI.Models.Input.EntitiesInput()
            {
                IdEntity = idEntity
            };
            var validationResults = new List<ValidationResult>();
            var validationContext = new ValidationContext(parameters);


            // Act
            var isValid = Validator.TryValidateObject(parameters, validationContext, validationResults, true);


            // Assert
            Assert.False(isValid);
            Assert.True(validationResults.Any());
        }

        [Theory]
        [InlineData("ruieueiru")]
        [InlineData("lloooa")]
        [InlineData("10.10")]
        public void GetEntity_NoResults(string idEntity)
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = new INS.PT.WebAPI.Models.Input.EntitiesInput()
            {
                IdEntity = idEntity
            };

            _mockRepository.Setup(x => x.GetEntityAsync(httpContext.headerParameters, parameters)).Returns(
                Task.Run(() => { return (Entity)null; }));


            // Act
            var result = controller.GetEntityAsync(parameters).Result;


            // Assert
            Assert.IsType<ActionResult<Entity>>(result);
            Assert.IsType<NotFoundObjectResult>(result.Result);

            var outputObject = result.Result as NotFoundObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status404NotFound, outputObject.StatusCode.Value);
        }

        [Fact]
        public void GetEntity_NoResultsException()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = new INS.PT.WebAPI.Models.Input.EntitiesInput()
            {
                IdEntity = null
            };

            _mockRepository.Setup(x => x.GetEntityAsync(httpContext.headerParameters, parameters)).Returns(
                () => { throw new BaseException("test error code", "test error message"); });


            // Act
            var result = controller.GetEntityAsync(parameters).Result;


            // Assert
            Assert.IsType<ActionResult<Entity>>(result);
            Assert.IsType<NotFoundObjectResult>(result.Result);

            var outputObject = result.Result as NotFoundObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status404NotFound, outputObject.StatusCode.Value);
            Assert.IsType<BaseException>(outputObject.Value);
        }

        [Fact]
        public void GetEntity_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakePersonEntity(parameters.IdEntity);

            _mockRepository.Setup(x => x.GetEntityAsync(httpContext.headerParameters, parameters)).Returns(
                Task.Run(() => { return output; }));


            // Act
            var result = controller.GetEntityAsync(parameters).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var outEntity = outputObject.Value as Entity;
            AssertPersonEntity(parameters.IdEntity, outEntity);
        }

        [Fact]
        public void GetType_ValidParameters ()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakePerson();

            _mockRepository.Setup(x => x.GetEntityTypeAsync(httpContext.headerParameters, parameters)).Returns(
                Task.Run(() => { return output; }));


            // Act
            var result = controller.GetTypeAsync(parameters).Result;


            // Assert
            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var outEntityType = outputObject.Value as Entity.EntityType;
            Assert.NotNull(outEntityType);
            var person = outEntityType.Individual;

            AssertPerson(person);
        }

        [Fact]
        public void GetAddresses_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = new List<Address>
            {
                FakeAddress("1")
            };

            _mockRepository.Setup(x => x.GetEntityAddressesAsync(httpContext.headerParameters, parameters)).Returns(
                Task.Run<IEnumerable<Address>>(() => { return output; }));


            // Act
            var result = controller.GetAddressesAsync(parameters).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var outEntityAddresses = outputObject.Value as IEnumerable<Address>;
            Assert.NotNull(outEntityAddresses);
            Assert.True(outEntityAddresses.Any());

            var address = outEntityAddresses.First();
            AssertAddress("1", address);
        }

        [Fact]
        public void GetAddress_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var id = "1";
            var output = FakeAddress(id);

            _mockRepository.Setup(x => x.GetEntityAddressAsync(httpContext.headerParameters, parameters, id)).Returns(
                Task.Run(() => { return output; }));


            // Act
            var result = controller.GetAddressAsync(parameters, id).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var address = outputObject.Value as Address;
            AssertAddress(id, address);
        }

        [Fact]
        public void GetContacts_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output =
                new ContactLists
                {
                    Emails = new List<Email>
                    {
                        FakeEmail()
                    },
                    Phones = new List<Phone>
                    {
                        FakePhone()
                    }
                };

            _mockRepository.Setup(x => x.GetEntityContactListsAsync(httpContext.headerParameters, parameters)).Returns(
                Task.Run(() => { return output; }));


            // Act
            var result = controller.GetContactsAsync(parameters).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var contacts = outputObject.Value as ContactLists;
            Assert.NotNull(contacts);

            var email = contacts.Emails.FirstOrDefault();
            AssertEmail(email);

            var phone = contacts.Phones.FirstOrDefault();
            AssertPhone(phone);
        }

        [Fact]
        public void GetPhones_ValidParameters ()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = new List<Phone>
                    {
                        FakePhone()
                    };

            _mockRepository.Setup(x => x.GetEntityPhonesAsync(httpContext.headerParameters, parameters)).Returns(
                Task.Run<IEnumerable<Phone>>(() => { return output; }));


            // Act
            var result = controller.GetPhonesAsync(parameters).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var phones = outputObject.Value as IEnumerable<Phone>;
            Assert.NotNull(phones);

            var phone = phones.FirstOrDefault();
            AssertPhone(phone);
        }

        [Fact]
        public void GetPhone_ValidParameters ()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakePhone();

            _mockRepository.Setup(x => x.GetEntityPhoneAsync(httpContext.headerParameters, parameters, output.PhoneIdentifier)).Returns(
                Task.Run(() => { return output; }));


            // Act
            var result = controller.GetPhoneAsync(parameters, output.PhoneIdentifier).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var phone = outputObject.Value as Phone;
            AssertPhone(phone);
        }

        [Fact]
        public void GetEmails_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = new List<Email>
            {
                FakeEmail()
            };

            _mockRepository.Setup(x => x.GetEntityEmailsAsync(httpContext.headerParameters, parameters)).Returns(
                Task.Run<IEnumerable<Email>>(() => { return output; }));


            // Act
            var result = controller.GetEmailsAsync(parameters).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var emails = outputObject.Value as IEnumerable<Email>;
            Assert.NotNull(emails);

            var email = emails.FirstOrDefault();
            AssertEmail(email);
        }

        [Fact]
        public void GetEmail_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakeEmail();

            _mockRepository.Setup(x => x.GetEntityEmailAsync(httpContext.headerParameters, parameters, output.EmailIdentifier.Value)).Returns(
                Task.Run(() => { return output; }));


            // Act
            var result = controller.GetEmailAsync(parameters, output.EmailIdentifier.Value).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var email = outputObject.Value as Email;
            AssertEmail(email);
        }

        [Fact]
        public void GetBankAccounts_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = new List<BankAccount>
            {
                FakeBankAccount()
            };

            _mockRepository.Setup(x => x.GetEntityBankAccountsAsync(httpContext.headerParameters, parameters)).Returns(
                Task.Run<IEnumerable<BankAccount>>(() => { return output; }));


            // Act
            var result = controller.GetBankAccountsAsync(parameters).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var bankAccounts = outputObject.Value as IEnumerable<BankAccount>;
            Assert.NotNull(bankAccounts);

            var bankAccount = bankAccounts.FirstOrDefault();
            AssertBankAccount(bankAccount);
        }

        [Fact]
        public void GetBankAccount_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakeBankAccount();

            _mockRepository.Setup(x => x.GetEntityBankAccountAsync(httpContext.headerParameters, 
                parameters, output.SequenceBankAccountNumber.Value)).Returns(
                    Task.Run(() => { return output; }));


            // Act
            var result = controller.GetBankAccountAsync(parameters, output.SequenceBankAccountNumber.Value).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var bankAccount = outputObject.Value as BankAccount;
            AssertBankAccount(bankAccount);
        }

        [Fact]
        public void GetDocuments_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = new List<Document>
            {
                FakeDocument()
            };

            _mockRepository.Setup(x => x.GetEntityDocumentsAsync(httpContext.headerParameters, parameters)).Returns(
                Task.Run<IEnumerable<Document>>(() => { return output; }));


            // Act
            var result = controller.GetDocumentsAsync(parameters).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var documents = outputObject.Value as IEnumerable<Document>;
            Assert.NotNull(documents);

            var document = documents.FirstOrDefault();
            AssertDocument(document);
        }

        [Fact]
        public void GetDocument_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakeDocument();

            _mockRepository.Setup(x => x.GetEntityDocumentAsync(httpContext.headerParameters, parameters
                , output.DocumentTypeCode, output.DocumentNumber)).Returns(
                    Task.Run(() => { return output; }));


            // Act
            var result = controller.GetDocumentAsync(parameters, output.DocumentTypeCode, output.DocumentNumber).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var document = outputObject.Value as Document;
            AssertDocument(document);
        }

        [Fact]
        public void GetCaes_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = new List<Cae>
            {
                FakeCae()
            };

            _mockRepository.Setup(x => x.GetEntityCaesAsync(httpContext.headerParameters, parameters)).Returns(
                Task.Run<IEnumerable<Cae>>(() => { return output; }));


            // Act
            var result = controller.GetCaesAsync(parameters).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var caes = outputObject.Value as IEnumerable<Cae>;
            Assert.NotNull(caes);

            var cae = caes.FirstOrDefault();
            AssertCae(cae);
        }

        [Fact]
        public void GetCae_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakeCae();

            _mockRepository.Setup(x => x.GetEntityCaeAsync(httpContext.headerParameters, parameters, output.CaeOrderNumber)).Returns(
                Task.Run<Cae>(() => { return output; }));


            // Act
            var result = controller.GetCaeAsync(parameters, output.CaeOrderNumber).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var cae = outputObject.Value as Cae;
            AssertCae(cae);
        }

        [Fact]
        public void  GetAffinities_ValidParameters ()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = new List<AffinityRelation>
            {
                FakeAffinity()
            };

            _mockRepository.Setup(x => x.GetEntityAffinitiesAsync(httpContext.headerParameters, parameters)).Returns(
                Task.Run<IEnumerable<AffinityRelation>>(() => { return output; }));


            // Act
            var result = controller.GetAffinitiesAsync(parameters).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var affinities = outputObject.Value as IEnumerable<AffinityRelation>;
            Assert.NotNull(affinities);

            var affinity = affinities.FirstOrDefault();
            AssertAffinity(affinity);

        }

        [Fact]
        public void GetAffinity_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakeAffinity();

            _mockRepository.Setup(x => x.GetEntityAffinityAsync(httpContext.headerParameters, parameters, output.RelationIdentifier)).Returns(
                Task.Run<AffinityRelation>(() => { return output; }));


            // Act
            var result = controller.GetAffinityAsync(parameters, output.RelationIdentifier).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var affinity = outputObject.Value as AffinityRelation;
            AssertAffinity(affinity);
        }

        [Theory]
        [InlineData("ruieueiru")]
        [InlineData("lloooa")]
        [InlineData("10.10")]
        public void PutEntity_NoResults(string idEntity)
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = new INS.PT.WebAPI.Models.Input.EntitiesInput()
            {
                IdEntity = idEntity
            };
            var output = FakePersonEntity(parameters.IdEntity);

            _mockRepository.Setup(x => x.UpdateEntityAsync(httpContext.headerParameters, output)).Returns(
                Task.Run(() => { return (Entity)null; }));


            // Act
            var result = controller.PutEntityAsync(output).Result;


            // Assert
            Assert.IsType<ActionResult<Entity>>(result);
            Assert.IsType<NotFoundObjectResult>(result.Result);

            var outputObject = result.Result as NotFoundObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status404NotFound, outputObject.StatusCode.Value);
        }

        [Fact]
        public void PutEntity_NoResultsException()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakePersonEntity(parameters.IdEntity);

            _mockRepository.Setup(x => x.UpdateEntityAsync(httpContext.headerParameters, output)).Returns(
                () => { throw new BaseException("test error code", "test error message"); });


            // Act
            var result = controller.PutEntityAsync(output).Result;


            // Assert
            Assert.IsType<ActionResult<Entity>>(result);
            Assert.IsType<NotFoundObjectResult>(result.Result);

            var outputObject = result.Result as NotFoundObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status404NotFound, outputObject.StatusCode.Value);
        }


        [Fact]
        public void PutEntity_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakePersonEntity(parameters.IdEntity);

            _mockRepository.Setup(x => x.UpdateEntityAsync(httpContext.headerParameters, output)).Returns(
                Task.Run<Entity>(() => { return output; }));


            // Act
            var result = controller.PutEntityAsync(output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var outEntity = outputObject.Value as Entity;
            AssertPersonEntity(parameters.IdEntity, outEntity);
        }

        [Fact]
        public void PutType_ValidParameters ()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakePerson();

            _mockRepository.Setup(x => x.UpdateEntityTypeAsync(httpContext.headerParameters, parameters, output)).Returns(
                Task.Run<Entity.EntityType>(() => { return output; }));


            // Act
            var result = controller.PutTypeAsync(parameters, output).Result;


            // Assert
            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var outEntityType = outputObject.Value as Entity.EntityType;
            Assert.NotNull(outEntityType);
            var person = outEntityType.Individual;

            AssertPerson(person);
        }


        [Fact]
        public void PutAddresses_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = new List<Address>
            {
                FakeAddress("1")
            };

            _mockRepository.Setup(x => x.UpdateEntityAddressesAsync(httpContext.headerParameters, parameters, output)).Returns(
                Task.Run<IEnumerable<Address>>(() => { return output; }));


            // Act
            var result = controller.PutAddressesAsync(parameters, output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var outEntityAddresses = outputObject.Value as IEnumerable<Address>;
            Assert.NotNull(outEntityAddresses);
            Assert.True(outEntityAddresses.Any());

            var address = outEntityAddresses.First();
            AssertAddress("1", address);
        }

        [Fact]
        public void PutAddress_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var id = "1";
            var output = FakeAddress(id);

            _mockRepository.Setup(x => x.UpdateEntityAddressAsync(httpContext.headerParameters, parameters, output)).Returns(
                Task.Run<Address>(() => { return output; }));


            // Act
            var result = controller.PutAddressAsync(parameters, id, output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var address = outputObject.Value as Address;
            AssertAddress(id, address);
        }


        [Fact]
        public void PutContacts_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output =
                new ContactLists
                {
                    Emails = new List<Email>
                    {
                        FakeEmail()
                    },
                    Phones = new List<Phone>
                    {
                        FakePhone()
                    }
                };

            _mockRepository.Setup(x => x.UpdateEntityContactListsAsync(httpContext.headerParameters, parameters, output)).Returns(
                Task.Run<ContactLists>(() => { return output; }));


            // Act
            var result = controller.PutContactsAsync(parameters, output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var contacts = outputObject.Value as ContactLists;
            Assert.NotNull(contacts);

            var email = contacts.Emails.FirstOrDefault();
            AssertEmail(email);

            var phone = contacts.Phones.FirstOrDefault();
            AssertPhone(phone);
        }


        [Fact]
        public void PutPhones_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = new List<Phone>
                    {
                        FakePhone()
                    };

            _mockRepository.Setup(x => x.UpdateEntityPhonesAsync(httpContext.headerParameters, parameters, output)).Returns(
                Task.Run<IEnumerable<Phone>>(() => { return output; }));


            // Act
            var result = controller.PutPhonesAsync(parameters, output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var phones = outputObject.Value as IEnumerable<Phone>;
            Assert.NotNull(phones);

            var phone = phones.FirstOrDefault();
            AssertPhone(phone);
        }

        [Fact]
        public void PutPhone_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakePhone();

            _mockRepository.Setup(x => x.UpdateEntityPhoneAsync(httpContext.headerParameters, parameters, output)).Returns(
                Task.Run<Phone>(() => { return output; }));


            // Act
            var result = controller.PutPhoneAsync(parameters, output.PhoneIdentifier, output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var phone = outputObject.Value as Phone;
            AssertPhone(phone);
        }


        [Fact]
        public void PutEmails_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = new List<Email>
            {
                FakeEmail()
            };

            _mockRepository.Setup(x => x.UpdateEntityEmailsAsync(httpContext.headerParameters, parameters, output)).Returns(
                Task.Run<IEnumerable<Email>>(() => { return output; }));


            // Act
            var result = controller.PutEmailsAsync(parameters, output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var emails = outputObject.Value as IEnumerable<Email>;
            Assert.NotNull(emails);

            var email = emails.FirstOrDefault();
            AssertEmail(email);
        }

        [Fact]
        public void PutEmail_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakeEmail();

            _mockRepository.Setup(x => x.UpdateEntityEmailAsync(httpContext.headerParameters, parameters, output)).Returns(
                Task.Run<Email>(() => { return output; }));


            // Act
            var result = controller.PutEmailAsync(parameters, output.EmailIdentifier.Value, output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var email = outputObject.Value as Email;
            AssertEmail(email);
        }

        [Fact]
        public void PutBankAccounts_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = new List<BankAccount>
            {
                FakeBankAccount()
            };

            _mockRepository.Setup(x => x.UpdateEntityBankAccountsAsync(httpContext.headerParameters, parameters, output)).Returns(
                Task.Run<IEnumerable<BankAccount>>(() => { return output; }));


            // Act
            var result = controller.PutBankAccountsAsync(parameters, output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var bankAccounts = outputObject.Value as IEnumerable<BankAccount>;
            Assert.NotNull(bankAccounts);

            var bankAccount = bankAccounts.FirstOrDefault();
            AssertBankAccount(bankAccount);
        }

        [Fact]
        public void PutBankAccount_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakeBankAccount();

            _mockRepository.Setup(x => x.UpdateEntityBankAccountAsync(httpContext.headerParameters, parameters, output)).Returns(
                Task.Run<BankAccount>(() => { return output; }));


            // Act
            var result = controller.PutBankAccountAsync(parameters, output.SequenceBankAccountNumber.Value, output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var bankAccount = outputObject.Value as BankAccount;
            AssertBankAccount(bankAccount);
        }

        [Fact]
        public void PutDocuments_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = new List<Document>
            {
                FakeDocument()
            };

            _mockRepository.Setup(x => x.UpdateEntityDocumentsAsync(httpContext.headerParameters, parameters, output)).Returns(
                Task.Run<IEnumerable<Document>>(() => { return output; }));


            // Act
            var result = controller.PutDocumentsAsync(parameters, output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var documents = outputObject.Value as IEnumerable<Document>;
            Assert.NotNull(documents);

            var document = documents.FirstOrDefault();
            AssertDocument(document);
        }

        [Fact]
        public void PutDocument_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakeDocument();

            _mockRepository.Setup(x => x.UpdateEntityDocumentAsync(httpContext.headerParameters, parameters, output)).Returns(
                Task.Run<Document>(() => { return output; }));


            // Act
            var result = controller.PutDocumentAsync(parameters, output.DocumentTypeCode, output.DocumentNumber, output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var document = outputObject.Value as Document;
            AssertDocument(document);
        }

        [Fact]
        public void PutCaes_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = new List<Cae>
            {
                FakeCae()
            };

            _mockRepository.Setup(x => x.UpdateEntityCaesAsync(httpContext.headerParameters, parameters, output)).Returns(
                Task.Run<IEnumerable<Cae>>(() => { return output; }));


            // Act
            var result = controller.PutCaesAsync(parameters, output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var caes = outputObject.Value as IEnumerable<Cae>;
            Assert.NotNull(caes);

            var cae = caes.FirstOrDefault();
            AssertCae(cae);
        }

        [Fact]
        public void PutCae_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakeCae();

            _mockRepository.Setup(x => x.UpdateEntityCaeAsync(httpContext.headerParameters, parameters, output)).Returns(
                Task.Run<Cae>(() => { return output; }));


            // Act
            var result = controller.PutCaeAsync(parameters, output.CaeOrderNumber, output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var cae = outputObject.Value as Cae;
            AssertCae(cae);
        }

        [Fact]
        public void PutAffinities_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = new List<AffinityRelation>
            {
                FakeAffinity()
            };

            _mockRepository.Setup(x => x.UpdateEntityAffinitiesAsync(httpContext.headerParameters, parameters, output)).Returns(
                Task.Run<IEnumerable<AffinityRelation>>(() => { return output; }));


            // Act
            var result = controller.PutAffinitiesAsync(parameters, output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var affinities = outputObject.Value as IEnumerable<AffinityRelation>;
            Assert.NotNull(affinities);

            var affinity = affinities.FirstOrDefault();
            AssertAffinity(affinity);

        }

        [Fact]
        public void PutAffinity_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakeAffinity();

            _mockRepository.Setup(x => x.UpdateEntityAffinityAsync(httpContext.headerParameters, parameters, output)).Returns(
                Task.Run(() => { return output; }));


            // Act
            var result = controller.PutAffinityAsync(parameters, output.RelationIdentifier, output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<OkObjectResult>(result.Result);

            var outputObject = result.Result as OkObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status200OK, outputObject.StatusCode.Value);

            var affinity = outputObject.Value as AffinityRelation;
            AssertAffinity(affinity);
        }

        [Fact]
        public void PostEntity_NoResults()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakePersonEntity(parameters.IdEntity);

            _mockRepository.Setup(x => x.UpdateEntityAsync(httpContext.headerParameters, output)).Returns(
                Task.Run(() => { return (Entity)null; }));


            // Act
            var result = controller.PostEntityAsync(output).Result;


            // Assert
            Assert.IsType<ActionResult<Entity>>(result);
            Assert.IsType<BadRequestResult>(result.Result);
        }

        [Fact]
        public void PostEntity_NoResultsException()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakePersonEntity(parameters.IdEntity);

            _mockRepository.Setup(x => x.UpdateEntityAsync(httpContext.headerParameters, output)).Returns(
                () => { throw new BaseException("test error code", "test error message"); });


            // Act
            var result = controller.PostEntityAsync(output).Result;


            // Assert
            Assert.IsType<ActionResult<Entity>>(result);
            Assert.IsType<BadRequestObjectResult>(result.Result);

            var outputObject = result.Result as BadRequestObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status400BadRequest, outputObject.StatusCode.Value);
        }

        [Fact]
        public void PostEntity_ValidParameters()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new TestEntitiesController(httpContext.headerParameters, _mockRepository.Object, httpContext);
            var parameters = FakeEntitiesInput();
            var output = FakePersonEntity(parameters.IdEntity);

            _mockRepository.Setup(x => x.UpdateEntityAsync(httpContext.headerParameters, output)).Returns(
                Task.Run<Entity>(() => { return output; }));


            // Act
            var result = controller.PostEntityAsync(output).Result;


            // Assert
            _mockRepository.Verify();

            Assert.IsType<CreatedResult>(result.Result);

            var outputObject = result.Result as CreatedResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status201Created, outputObject.StatusCode.Value);

            var outEntity = outputObject.Value as Entity;
            AssertPersonEntity(parameters.IdEntity, outEntity);
        }
    }
}

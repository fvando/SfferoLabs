﻿using INS.PT.WebAPI;
using INS.PT.WebAPI.Models;
using Moq;
using Tecnisys;
using Xunit;
using System.Threading.Tasks;
using System;
using INS.PT.WebAPI.Exceptions;
using XUnitTestINS.PT.WebAPI.Context;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class NotificationsRepositoryTests
    {
        private readonly Mock<IMasterEntity> _mockmasterEntityService;

        public NotificationsRepositoryTests()
        {
            _mockmasterEntityService = new Mock<IMasterEntity>();

            _mockmasterEntityService.Setup(x => x.SetNotificationDoneAsync(
                It.IsAny<SetNotificationDoneRequest>()
                ))
                .Returns(ValidGetEntityAsync());

        }

        private async Task<SetNotificationDoneResponse> ValidGetEntityAsync()
        {
            return await Task.Run(() => new SetNotificationDoneResponse { SetNotificationDoneResult = Fake_ValidResponse() });
        }

        private async Task<SetNotificationDoneResponse> InvalidGetEntityAsync()
        {
            return await Task.Run(() => new SetNotificationDoneResponse { SetNotificationDoneResult = Fake_InvalidResponse() });
        }

        private ResponseOfboolean Fake_ValidResponse()
        {
            var result = new ResponseOfboolean
            {
                Results = true,
                ResultsSpecified = true,
                Errors = new ServiceError[]
                {
                    new ServiceError
                    {
                        Code = "APP-MRG-OPR-00000",
                        Message = "The operation completed successfully.",
                        Type = "APPLICATION"
                    }
                }
            };

            return result;
        }

        private ResponseOfboolean Fake_InvalidResponse()
        {
            var result = new ResponseOfboolean
            {
                Results = false,
                ResultsSpecified = false,
                Errors = new ServiceError[]
                {
                    new ServiceError
                    {
                        Code = "testError",
                        Message = "The operation has an error.",
                        Type = "APPLICATION"
                    }
                }
            };

            return result;
        }


        [Fact]
        public void SetNotificationDoneAsync_Parameters_Null()
        {
            // Arrange
            var repository = new NotificationsRepository(_mockmasterEntityService.Object);

            // Act and Assert
            Assert.ThrowsAsync<ArgumentNullException>(() => repository.SetNotificationDoneAsync(null, It.IsAny<string>(), It.IsAny<string>()));
        }

        [Fact]
        public void SetNotificationDoneAsync_Error()
        {
            // Arrange
            _mockmasterEntityService.Setup(x => x.SetNotificationDoneAsync(
                It.IsAny<SetNotificationDoneRequest>()
                ))
                .Returns(InvalidGetEntityAsync());
            var repository = new NotificationsRepository(_mockmasterEntityService.Object);
            var headerParameters = new HeaderParameters(new FakeCodesMapping())
            {
                BsSolution = "duck",
                BsUser = "\\bs\\duckd",
                IdCompany = "AGEAS",
                IdNetwork = "AGEAS"
            };

            // Act and Assert
            Assert.ThrowsAsync<CanonicalException>(() => repository.SetNotificationDoneAsync(headerParameters, It.IsAny<string>(), It.IsAny<string>()));
        }

        [Fact]
        public void SetNotificationDoneAsync_Valid()
        {
            // Arrange
            var repository = new NotificationsRepository(_mockmasterEntityService.Object);
            var headerParameters = new HeaderParameters(new FakeCodesMapping())
            {
                BsSolution = "duck",
                BsUser = "\\bs\\duckd",
                IdCompany = "AGEAS",
                IdNetwork = "AGEAS"
            };

            // Act
            var result = repository.SetNotificationDoneAsync(headerParameters, It.IsAny<string>(), It.IsAny<string>());

            // Assert
            Assert.NotNull(result);
            Assert.True(result.Result);
        }
    }
}

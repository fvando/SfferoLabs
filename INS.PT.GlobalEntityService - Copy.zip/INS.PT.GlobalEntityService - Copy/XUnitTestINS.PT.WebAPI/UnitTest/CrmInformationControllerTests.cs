﻿using INS.PT.WebAPI.Models;
using Moq;
using Xunit;
using System;
using INS.PT.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using XUnitTestINS.PT.WebAPI.Context;
using INS.PT.WebAPI.Interface;
using System.Threading.Tasks;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;
using System.Collections.Generic;
using INS.PT.WebAPI.Models.Elements.Crm;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class CrmInformationControllerTests
    {
        private readonly Mock<ICrmInformation> _mockRepository;
        private readonly INS.PT.WebAPI.IdTranslates.CodesMapping _codesMapping;

        public CrmInformationControllerTests()
        {
            _codesMapping = new FakeCodesMapping();

            _mockRepository = new Mock<ICrmInformation>();
            _mockRepository.Setup(x => x.SetInformationAsync(It.IsAny<HeaderParameters>(), _validInput)).ReturnsAsync(true);
            _mockRepository.Setup(x => x.SetInformationAsync(It.IsAny<HeaderParameters>(), _errorInput)).ReturnsAsync(false);

            _mockRepository.Setup(x => x.GetExternalInformationAsync(It.IsAny<HeaderParameters>(), _validEntity)).ReturnsAsync(_validEntityResponse);
            _mockRepository.Setup(x => x.GetExternalInformationAsync(It.IsAny<HeaderParameters>(), _errorEntity)).ReturnsAsync(_errorEntityResponse);
            _mockRepository.Setup(x => x.GetExternalInformationAsync(It.IsAny<HeaderParameters>(), _errorNullEntity)).ReturnsAsync(_errorNullEntityResponse);
        }

        private readonly CrmExternalInfoInput _validInput = new CrmExternalInfoInput
        {
            IdEntity = "2233",
            ProductDescription = "Test product"
        };

        private readonly CrmExternalInfoInput _errorInput = new CrmExternalInfoInput
        {
            IdEntity = "WW2233",
            ProductDescription = "Test product",
            Order = 334
        };

        private readonly EntitiesInput _validEntity = new EntitiesInput { IdEntity = "2233" };
        private readonly CrmExternalInfoOutput _validEntityResponse = new CrmExternalInfoOutput
        {
            Entity = new INS.PT.WebAPI.Models.Elements.Entity
            {
                IdEntity = "2233",
                VatNumber = "123456789"
            },
            CrmExternalInformation = new ExternalInfo
            {
                LastContacts = new List<LastContact>
                {
                    new LastContact
                    {
                        IdEntity = "2233",
                        IdCompany = "AGEAS"
                    }
                }
            }
        };

        private readonly EntitiesInput _errorEntity = new EntitiesInput { IdEntity = "WW2233" };
        private readonly CrmExternalInfoOutput _errorEntityResponse = new CrmExternalInfoOutput
        {
            Entity = null,
            CrmExternalInformation = new ExternalInfo
            {
                LastContacts = new List<LastContact>
                {
                    new LastContact
                    {
                        IdEntity = "2233",
                        IdCompany = "AGEAS"
                    }
                }
            }

        };

        private readonly EntitiesInput _errorNullEntity = new EntitiesInput { IdEntity = "NN2233" };
        private readonly CrmExternalInfoOutput _errorNullEntityResponse = null;


        [Fact]
        public async Task SetCrmInformation_NoHeadersAsync()
        {
            // Arrange
            var controller = new CrmInformationController(_mockRepository.Object, null, _codesMapping);
            var requestParameters = new CrmExternalInfoInput();

            // Act
            var result = await controller.SetCrmInformation(requestParameters);

            // Assert
            var taskResult = Assert.IsType<ActionResult<bool>>(result);
            var badRequest = Assert.IsType<BadRequestObjectResult>(taskResult.Result);
            var objectResult = Assert.IsType<AggregateException>(badRequest.Value);
            Assert.NotNull(objectResult);
        }

        [Fact]
        public async Task SetCrmInformation_InvalidHeaders()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(
                    new HeaderParameters(_codesMapping)
                    {
                        IdCompany = "",
                        IdNetwork = "AGEAS",
                        BsSolution = "DUCKCREEK",
                        BsUser = "TESTE"
                    }
                );
            var controller = new CrmInformationController(_mockRepository.Object, httpContext, _codesMapping);
            var requestParameters = new CrmExternalInfoInput();

            // Act
            var result = await controller.SetCrmInformation(requestParameters);

            // Assert
            var taskResult = Assert.IsType<ActionResult<bool>>(result);
            var badRequest = Assert.IsType<BadRequestObjectResult>(taskResult.Result);
            var objectResult = Assert.IsType<AggregateException>(badRequest.Value);
            Assert.NotNull(objectResult);
        }

        [Fact]
        public async Task SetCrmInformation_Valid()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new CrmInformationController(_mockRepository.Object, httpContext, _codesMapping);

            // Act
            var result = await controller.SetCrmInformation(_validInput);

            // Assert
            var taskResult = Assert.IsType<ActionResult<bool>>(result);
            var okRequest = Assert.IsType<OkObjectResult>(taskResult.Result);
            var objectResult = Assert.IsType<bool>(okRequest.Value);
            Assert.True(objectResult);
        }

        [Fact]
        public async Task SetCrmInformation_Error()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new CrmInformationController(_mockRepository.Object, httpContext, _codesMapping);

            // Act
            var result = await controller.SetCrmInformation(_errorInput);

            // Assert
            var taskResult = Assert.IsType<ActionResult<bool>>(result);
            var notFoundRequest = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            var objectResult = Assert.IsType<bool>(notFoundRequest.Value);
            Assert.False(objectResult);
        }

        //GetCrmInformation
        [Fact]
        public async Task GetCrmInformation_NoHeadersAsync()
        {
            // Arrange
            var controller = new CrmInformationController(_mockRepository.Object, null, _codesMapping);
            var requestParameters = new EntitiesInput();

            // Act
            var result = await controller.GetCrmInformation(requestParameters);

            // Assert
            var taskResult = Assert.IsType<ActionResult<CrmExternalInfoOutput>>(result);
            var badRequest = Assert.IsType<BadRequestObjectResult>(taskResult.Result);
            var objectResult = Assert.IsType<AggregateException>(badRequest.Value);
            Assert.NotNull(objectResult);
        }

        [Fact]
        public async Task GetCrmInformation_InvalidHeaders()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(
                    new HeaderParameters(_codesMapping)
                    {
                        IdCompany = "",
                        IdNetwork = "AGEAS",
                        BsSolution = "DUCKCREEK",
                        BsUser = "TESTE"
                    }
                );
            var controller = new CrmInformationController(_mockRepository.Object, httpContext, _codesMapping);
            var requestParameters = new EntitiesInput();

            // Act
            var result = await controller.GetCrmInformation(requestParameters);

            // Assert
            var taskResult = Assert.IsType<ActionResult<CrmExternalInfoOutput>>(result);
            var badRequest = Assert.IsType<BadRequestObjectResult>(taskResult.Result);
            var objectResult = Assert.IsType<AggregateException>(badRequest.Value);
            Assert.NotNull(objectResult);
        }

        [Fact]
        public async Task GetCrmInformation_Valid()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new CrmInformationController(_mockRepository.Object, httpContext, _codesMapping);

            // Act
            var result = await controller.GetCrmInformation(_validEntity);

            // Assert
            var taskResult = Assert.IsType<ActionResult<CrmExternalInfoOutput>>(result);
            var okRequest = Assert.IsType<OkObjectResult>(taskResult.Result);
            var objectResult = Assert.IsType<CrmExternalInfoOutput>(okRequest.Value);
            Assert.Equal(_validEntityResponse, objectResult);
        }

        [Fact]
        public async Task GetCrmInformation_Error()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new CrmInformationController(_mockRepository.Object, httpContext, _codesMapping);

            // Act
            var result = await controller.GetCrmInformation(_errorEntity);

            // Assert
            var taskResult = Assert.IsType<ActionResult<CrmExternalInfoOutput>>(result);
            var notFoundRequest = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.Null(notFoundRequest.Value);
        }

        [Fact]
        public async Task GetCrmInformation_NullError()
        {
            // Arrange
            var httpContext = new FakeHeaderParameters(null);
            var controller = new CrmInformationController(_mockRepository.Object, httpContext, _codesMapping);

            // Act
            var result = await controller.GetCrmInformation(_errorNullEntity);

            // Assert
            var taskResult = Assert.IsType<ActionResult<CrmExternalInfoOutput>>(result);
            var notFoundRequest = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.Null(notFoundRequest.Value);
        }
    }
}

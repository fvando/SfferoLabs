﻿using AutoMapper;
using INS.PT.WebAPI;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Repository.Service;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using System.Threading.Tasks;
using Xunit;
using AmlGet;
using AmlSet;
using INS.PT.WebAPI.Models.Elements;
using System;
using System.Linq;
using System.Collections.Generic;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class AmlServiceTests
    {
        private readonly Mock<IEntitiesInquiriesService> _mockAmlGetService;
        private readonly Mock<IEntitiesMaintainService> _mockAmlSetService;
        private readonly IMapper _mapper;
        private readonly HeaderParameters _headerParameters;


        public AmlServiceTests()
        {
            _mockAmlGetService = new Mock<IEntitiesInquiriesService>();
            _mockAmlGetService.Setup(x =>
                x.getAMLDataWASPAsync(It.IsAny<getAMLDataWASPRequest>()))
                .Returns(ValidGetResponseAsync());


            _mockAmlSetService = new Mock<IEntitiesMaintainService>();
            _mockAmlSetService.Setup(x =>
                x.maintainAMLDataWASPAsync(It.IsAny<maintainAMLDataWASPRequest>()))
                .Returns(ValidSetResponseAsync());

            _headerParameters = new HeaderParameters(new Context.FakeCodesMapping())
            {
                BsSolution = "testSolution",
                BsUser = @"\bs\testUser",
                IdCompany = "AGEAS",
                IdNetwork = "AGEAS"
            };

            _mapper = null;
            var serviceCollection = new ServiceCollection();
            Startup.Setups.SetupMappings(serviceCollection);

            foreach (var service in serviceCollection)
            {
                if (service.ImplementationInstance is IMapper mapper)
                {
                    _mapper = mapper;
                    break;
                }
            }
        }

        private async Task<getAMLDataWASPResponse> ValidGetResponseAsync()
        {
            return await Task.Run(() => new getAMLDataWASPResponse
            {
                getAMLDataWASPResult = new GetAMLDataWASPOutputData
                {
                    outputMessage = "OK",
                    alert = null,
                    status = "0",
                    statusElement = null,
                    ARGUSLst = new AMLOutputElement[] {
                        new AMLOutputElement
                        {
                            pep = "9",
                            pepConditionEndDate = DateTime.Now,
                            pepConditionEndDateSpecified = true,
                            pepConditionStartDate = DateTime.Now,
                            pepConditionStartDateSpecified = true,

                            countryRegisteredOffice = "24",

                            placeOfBirth = "TALBA",
                            otherNationalities = "CHI",

                            identityDocDateSpecified = true,
                            identityDocDate = new DateTime(2027, 10, 20)
                        }
                    }
                },
                AxisValues = new AmlGet.AxisValues
                {
                    User = "testUser",
                    Solution = "testSolution"
                }
            });
        }

        private async Task<getAMLDataWASPResponse> ValidEmptyGetResponseAsync()
        {
            return await Task.Run(() => new getAMLDataWASPResponse
            {
                getAMLDataWASPResult = new GetAMLDataWASPOutputData
                {
                    outputMessage = "OK",
                    alert = null,
                    status = "0",
                    statusElement = null,
                    ARGUSLst = new AMLOutputElement[] { }
                },
                AxisValues = new AmlGet.AxisValues
                {
                    User = "testUser",
                    Solution = "testSolution"
                }
            });
        }

        private async Task<getAMLDataWASPResponse> InvalidGetResponseAsync()
        {
            return await Task.Run(() => new getAMLDataWASPResponse
            {
                getAMLDataWASPResult = new GetAMLDataWASPOutputData
                {
                    outputMessage = "ERROR",
                    alert = "Invalid test",
                    status = "12",
                    statusElement = null
                },
                AxisValues = new AmlGet.AxisValues
                {
                    User = "testUser",
                    Solution = "testSolution"
                }
            });
        }

        private async Task<maintainAMLDataWASPResponse> ValidSetResponseAsync()
        {
            return await Task.Run(() => new maintainAMLDataWASPResponse
            {
                maintainAMLDataWASPResult = new MaintainAMLDataWASPOutputData
                {
                    outputMessage = "OK",
                    alert = null,
                    status = "0",
                    statusElement = null
                },
                AxisValues = new AmlSet.AxisValues
                {
                    User = "testUser",
                    Solution = "testSolution"
                }
            });
        }

        private async Task<maintainAMLDataWASPResponse> InvalidSetResponseAsync()
        {
            return await Task.Run(() => new maintainAMLDataWASPResponse
            {
                maintainAMLDataWASPResult = new MaintainAMLDataWASPOutputData
                {
                    outputMessage = "ERROR",
                    alert = "Invalid test",
                    status = "12",
                    statusElement = null
                },
                AxisValues = new AmlSet.AxisValues
                {
                    User = "testUser",
                    Solution = "testSolution"
                }
            });
        }

        private Entity TestEntity => new Entity
        {
            IdEntity = "validId",
            Type = new Entity.EntityType
            {
                Company = new Organization
                {
                    CompanyName = "testCompany"
                },
                Individual = new Person
                {
                    Name = "testPerson",
                    Nationalities = new List<Nationality>()
                }
            },
            Documents = new List<Document>
            {
                new Document
                {
                    DocumentTypeCode = "ID",
                    DocumentTypeDescription = nameof(Tecnisys.IdentityDocument)
                }
            },
            Amls = new List<Aml>
            {
                new Aml
                {
                    ConditionType="9",
                    ConditionDescription="testDescription",
                    StartDate=DateTime.Now,
                    EndDate=null,
                }
            }
        };


        [Fact]
        public async Task SetAmlAsync_Entity_NullAsync()
        {
            // Arrange
            var service = new AmlService(_mapper, _mockAmlGetService.Object, _mockAmlSetService.Object);

            // Act
            var result = await service.SetAmlAsync(_headerParameters, null);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task SetAmlAsync_Entity_NotOkAsync()
        {
            // Arrange
            var service = new AmlService(_mapper, _mockAmlGetService.Object, _mockAmlSetService.Object);
            _mockAmlSetService.Setup(x =>
                x.maintainAMLDataWASPAsync(It.IsAny<maintainAMLDataWASPRequest>()))
                .Returns(InvalidSetResponseAsync());

            // Act
            var result = await service.SetAmlAsync(_headerParameters, TestEntity);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task SetAmlAsync_NewEntity_ValidAsync()
        {
            // Arrange
            var service = new AmlService(_mapper, _mockAmlGetService.Object, _mockAmlSetService.Object);

            // Act
            var result = await service.SetAmlAsync(_headerParameters, TestEntity);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public async Task SetAmlAsync_UpdateEntity_ValidAsync()
        {
            // Arrange
            var service = new AmlService(_mapper, _mockAmlGetService.Object, _mockAmlSetService.Object);
            await service.GetAmlAsync(_headerParameters, TestEntity.IdEntity);

            // Act
            var result = await service.SetAmlAsync(_headerParameters, TestEntity);

            // Assert
            Assert.True(result);
        }


        [Fact]
        public async Task GetAmlAsync_Entity_NullAsync()
        {
            // Arrange
            var service = new AmlService(_mapper, _mockAmlGetService.Object, _mockAmlSetService.Object);

            // Act
            await service.GetAmlAsync(_headerParameters, null);

            // Assert
            _mockAmlGetService.Verify(x => x.getAMLDataWASPAsync(It.IsAny<getAMLDataWASPRequest>()), Times.Never);
        }

        [Fact]
        public async Task GetAmlAsync_Entity_NotOkAsync()
        {
            // Arrange
            var service = new AmlService(_mapper, _mockAmlGetService.Object, _mockAmlSetService.Object);
            _mockAmlGetService.Setup(x =>
                x.getAMLDataWASPAsync(It.IsAny<getAMLDataWASPRequest>()))
                .Returns(InvalidGetResponseAsync());
            var entity = TestEntity;
            entity.Amls.Clear();

            // Act
            await service.GetAmlAsync(_headerParameters, entity.IdEntity);

            // Assert
            _mockAmlGetService.Verify(x => x.getAMLDataWASPAsync(It.IsAny<getAMLDataWASPRequest>()), Times.Once);
            Assert.False(entity.Amls.Any());
        }
        
        [Fact]
        public async Task GetAmlAsync_Entity_EmptyResultAsync()
        {
            // Arrange
            var service = new AmlService(_mapper, _mockAmlGetService.Object, _mockAmlSetService.Object);
            _mockAmlGetService.Setup(x =>
                x.getAMLDataWASPAsync(It.IsAny<getAMLDataWASPRequest>()))
                .Returns(ValidEmptyGetResponseAsync());
            var entity = TestEntity;
            entity.Amls.Clear();

            // Act
            await service.GetAmlAsync(_headerParameters, entity.IdEntity);

            // Assert
            _mockAmlGetService.Verify(x => x.getAMLDataWASPAsync(It.IsAny<getAMLDataWASPRequest>()), Times.Once);
            Assert.False(entity.Amls.Any());
        }
        
        [Fact]
        public async Task GetAmlAsync_Entity_ValidReturnDataAsync()
        {
            // Arrange
            var service = new AmlService(_mapper, _mockAmlGetService.Object, _mockAmlSetService.Object);
            var entity = TestEntity;

            // Act
            await service.GetAmlAsync(_headerParameters, entity.IdEntity);

            // Assert
            _mockAmlGetService.Verify(x => x.getAMLDataWASPAsync(It.IsAny<getAMLDataWASPRequest>()), Times.Once);
            Assert.True(entity.Amls.Any());
        }
        
        [Fact]
        public async Task GetAmlAsync_Entity_ValidNoReturnAsync()
        {
            // Arrange
            var service = new AmlService(_mapper, _mockAmlGetService.Object, _mockAmlSetService.Object);
            var entity = TestEntity;
            entity.Amls.Clear();

            // Act
            await service.GetAmlAsync(_headerParameters, entity.IdEntity);

            // Assert
            _mockAmlGetService.Verify(x => x.getAMLDataWASPAsync(It.IsAny<getAMLDataWASPRequest>()), Times.Once);
            Assert.False(entity.Amls.Any());
        }
    }
}

﻿using log4net;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Threading.Tasks;

namespace INS.PT.BrokerCalls
{
    public class BrokerClient : IBrokerClient
    {
        private readonly ILog log;
        private readonly HttpClient httpClient;
        private readonly IConfiguration configurations;

        private string _httpVerb;

        public BrokerClient(HttpClient httpClient, IConfiguration configurations)
        {
            const string BrokerSettingsSection = "Broker";

            log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            AdicionalHeaders = new Dictionary<string, string>();
            ContentType = "application/json";
            HttpVerb = "GET";

            this.httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
            this.configurations = configurations ?? throw new ArgumentNullException(nameof(configurations));

            LoadConfigSettings(BrokerSettingsSection);
        }



        public void LoadConfigSettings(string brokerSettingsSection)
        {
            BrokerEndpoint = configurations[$"{brokerSettingsSection}:{nameof(BrokerEndpoint)}"];
            BsSolution = configurations[$"{brokerSettingsSection}:{nameof(BsSolution)}"];
            BsUser = configurations[$"{brokerSettingsSection}:{nameof(BsUser)}"];
            BsWebService = configurations[$"{brokerSettingsSection}:{nameof(BsWebService)}"];
            BsWebmethod = configurations[$"{brokerSettingsSection}:{nameof(BsWebmethod)}"];
        }

        /// <summary>
        /// Broker endpoint to be used for the request.
        /// </summary>
        public string BrokerEndpoint { get; set; }

        /// <summary>
        /// Http verb to be used.
        /// </summary>
        /// <example>GET</example>
        public string HttpVerb { get => _httpVerb.ToUpper(); set => _httpVerb = value; }


        #region Headers
        /// <summary>
        /// Content type header. Defauls to "application/json".
        /// </summary>
        /// <example>application/json</example>
        public string ContentType { get; set; }

        /// <summary>
        /// Solution header to be used.
        /// </summary>
        /// <example>DUCKCREEK</example>
        public string BsSolution { get; set; }

        /// <summary>
        /// User header to be used.
        /// </summary>
        /// <example>\BS\DUCKCREEKD</example>
        public string BsUser { get; set; }

        /// <summary>
        /// Web service header to be used.
        /// </summary>
        /// <example>ageas-api-ReferenceData</example>
        public string BsWebService { get; set; }

        /// <summary>
        /// Web method header to be used.
        /// </summary>
        /// <example>v1/ReferenceData/Mappings</example>
        public string BsWebmethod { get; set; }

        /// <summary>
        /// Property to define aditional headers to be added to the request.
        /// </summary>
        public Dictionary<string, string> AdicionalHeaders { get; set; }
        #endregion


        //todo metodo para fazer pedido sem body
        public async Task<HttpResponseMessage> MakeRequestAsync(string additionalRoute, string additionalQuery, object requestObject)
        {
            log.Info($"Call thru broker {JsonConvert.SerializeObject(this, Formatting.Indented)}");
            log.Info($"route = {additionalRoute}; query = {additionalQuery}; body = {requestObject};");


            HttpResponseMessage responseMessage = null;

            // load all headers
            httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", ContentType);
            httpClient.DefaultRequestHeaders.TryAddWithoutValidation(nameof(BsSolution), BsSolution);
            httpClient.DefaultRequestHeaders.TryAddWithoutValidation(nameof(BsUser), BsUser);
            httpClient.DefaultRequestHeaders.TryAddWithoutValidation(nameof(BsWebService), BsWebService);
            httpClient.DefaultRequestHeaders.TryAddWithoutValidation(nameof(BsWebmethod), BsWebmethod);

            foreach (var addHeader in AdicionalHeaders)
            {
                httpClient.DefaultRequestHeaders.TryAddWithoutValidation(addHeader.Key, addHeader.Value);
            }

            // prepare uri to be called
            var initialUri = new Uri(BrokerEndpoint);

            if (!string.IsNullOrEmpty(additionalRoute))
            {
                initialUri = new Uri(System.IO.Path.Combine(BrokerEndpoint, additionalRoute));
            }

            var builder = new UriBuilder(initialUri)
            {
                Scheme = "https",      // broker calls should be in this schema
                Query = additionalQuery
            };

            //httpClient.BaseAddress = builder.Uri;
            // make call for different verbs
            switch (HttpVerb)
            {
                case "GET":
                    rClient.ExecuteAsyncGet()
                    responseMessage = await httpClient.GetAsync(builder.Uri);
                    break;
                case "POST":
                    responseMessage = await httpClient.PostAsync(builder.Uri, requestObject, new JsonMediaTypeFormatter());
                    break;
                case "PUT":
                    responseMessage = await httpClient.PutAsync(builder.Uri, requestObject, new JsonMediaTypeFormatter());
                    break;
                case "DELETE":
                    responseMessage = await httpClient.DeleteAsync(builder.Uri);
                    break;

                default:
                    var request = new HttpRequestMessage(new HttpMethod(HttpVerb), builder.Uri)
                    {
                        Content = new StringContent(JsonConvert.SerializeObject(requestObject), System.Text.Encoding.UTF8)
                    };

                    responseMessage = await httpClient.SendAsync(request);
                    break;
            }

            // return response
            return responseMessage;
        }

        public async Task<T> RequestOkAsync<T>(string additionalRoute, string additionalQuery, object requestObject)
        {
            var responseMessage = await MakeRequestAsync(additionalRoute, additionalQuery, requestObject);

            if (responseMessage.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var response = await responseMessage.Content.ReadAsAsync<T>();
                return response;
            }
            else
            {
                log.Debug($"Response not OK: {responseMessage}");
                //throw new CanonicalException(responseMessage);
            }

            return default(T);
        }

        public bool RequestAsync<T>(string additionalRoute, string additionalQuery, object requestObject, out T result)
        {
            var client = new RestSharp.RestClient(BrokerEndpoint);
            var request = new RestSharp.RestRequest(additionalRoute, RestSharp.Method.GET);

            request.AddParameter("Content-Type", ContentType);
            request.AddParameter(nameof(BsSolution), BsSolution);
            request.AddParameter(nameof(BsUser), BsUser);
            request.AddParameter(nameof(BsWebService), BsWebService);
            request.AddParameter(nameof(BsWebmethod), BsWebmethod);

            foreach (var addHeader in AdicionalHeaders)
            {
                request.AddParameter(addHeader.Key, addHeader.Value);
            }

            if (requestObject != null)
            {
                request.AddJsonBody(requestObject);
            }

            client.ExecuteAsync<T>(request, (response, re) =>
            {
                log.Info($"Response: {response}");
            });
        }


        //todo metodo para validar se tem dados para fazer chamada
    }
}

﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace INS.PT.BrokerCalls
{
    public interface IBrokerClient
    {
        string BrokerEndpoint { get; set; }

        string HttpVerb { get; set; }

        string ContentType { get; set; }

        string BsSolution { get; set; }

        string BsUser { get; set; }

        string BsWebService { get; set; }

        string BsWebmethod { get; set; }

        Dictionary<string, string> AdicionalHeaders { get; set; }



        void LoadConfigSettings(string brokerSettingsSection);

        Task<HttpResponseMessage> MakeRequestAsync(string additionalRoute, string additionalQuery, object requestObject);

        Task<T> RequestOkAsync<T>(string additionalRoute, string additionalQuery, object requestObject);

        bool RequestAsync<T>(string additionalRoute, string additionalQuery, object requestObject, out T result);
    }
}

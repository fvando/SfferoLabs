﻿using Cogen_EntitiesService;
using System.Collections.Generic;
using System.Linq;
using System;
using INS.PT.WebAPI.Models.Elements;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Class where mappings are defined for the Cogen service
    /// </summary>
    public class CogenMappingProfile : AutoMapper.Profile
    {
        internal const int CaeOrderNumberForCompany = 1;
        internal const int CaeOrderNumberForCommom = 2;

        private const int PostalCodeLength = 9;

        /// <summary>
        /// Constructor
        /// </summary>
        public CogenMappingProfile()
        {
            // cogen => global mapping
            CreateMap<GetOrMaintainEntityCogenWASPOutputData, Entity>()
                .ForMember(dest => dest.IdEntity, opts => opts.MapFrom(src => src.ClientReferenceCGN))
                .ForMember(dest => dest.VatNumber, opts => opts.MapFrom(src => src.CommonClientElement.FiscalNumber))
                .ForMember(dest => dest.CountryCode, opts => opts.MapFrom(src => src.PersonalClientElement.Nationality))

                // Person object
                .ForPath(dest => dest.Type.Individual, opts => opts.MapFrom(src => string.IsNullOrEmpty(src.PersonalClientElement.Sex) ? null : src))

                // Organization object
                .ForPath(dest => dest.Type.Company, opts => opts.MapFrom(src => src.CompanyClientElement.CompanyConstitutionDate != DateTime.MinValue ? src : null))

                // Address object
                .ForMember(dest => dest.Addresses, opts => opts.MapFrom(src => src.AddressElement))

                // Contact object
                .ForPath(dest => dest.Contacts, opts => opts.MapFrom(src => src.ContactElement))

                // Cae object
                .ForMember(dest => dest.Caes, opts => opts.MapFrom(src => CaesMapping(src)))
                ;          

            PersonMapping();

            OrganizationMapping();

            AddressesMapping();

            SearchEntityMappings();
        }

        /// <summary>
        /// Mappings for request and response mappings of a search entity.
        /// </summary>
        private void SearchEntityMappings()
        {
            // global => cogen mapping
            CreateMap<SearchEntityInput, SearchEntityCogenWASPInputData>()
                .ForMember(dest => dest.AgentNumber, opts => opts.MapFrom(src => src.AgentNumber))
                .ForMember(dest => dest.Birthdate, opts => opts.MapFrom(src => src.Birthdate.HasValue ?
                    src.Birthdate.Value.ToString("yyyyMMdd", System.Globalization.DateTimeFormatInfo.InvariantInfo) : null))
                .ForMember(dest => dest.ClientReferenceCGN, opts => opts.MapFrom(src => src.IdEntity))
                .ForMember(dest => dest.Email, opts => opts.MapFrom(src => src.Email))
                .ForMember(dest => dest.FiscalNumber, opts => opts.MapFrom(src => src.VatNumber))
                .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.Name))
                .ForMember(dest => dest.PhoneNumber, opts => opts.MapFrom(src => src.PhoneNumber))
                .ForMember(dest => dest.PostalCode, opts => opts.MapFrom(src => src.PostalCode))
                ;



            // cogen => global mapping
            CreateMap<SearchEntityCogenWASPOutputData, SearchEntityOutput>()
                .ForMember(dest => dest.MatchedEntities, opts => opts.MapFrom(src => src.matchedEntitiesArray))
                ;

            SearchEntity_SimpleEntityMapping();
        }

        private void SearchEntity_SimpleEntityMapping()
        {
            // cogen => global mapping
            CreateMap<SearchEntityElement, SimpleEntity>()
                .ForMember(dest => dest.IdCompany, opts => opts.MapFrom(src => src.CompanyCode))
                .ForMember(dest => dest.IdNetwork, opts => opts.MapFrom(src => src.NetworkCode))
                .ForMember(dest => dest.IdEntity, opts => opts.MapFrom(src => src.ClientReferenceCGN))
                .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.Name))
                .ForMember(dest => dest.VatNumber, opts => opts.MapFrom(src => src.FiscalNumber))
                .ForMember(dest => dest.Birthdate, opts => opts.MapFrom(src => src.BirthdateSpecified ? src.Birthdate : (DateTime?)null))
                .ForMember(dest => dest.Addresses, opts => opts.MapFrom(src => src.AddressElement))
                .ForMember(dest => dest.EntityType, opts => opts.MapFrom(src => src.EntityType))
                .ForMember(dest => dest.EntityPhone, opts => opts.MapFrom(src => src.EntityPhone))
                .ForMember(dest => dest.Caes, opts => opts.MapFrom(src => string.IsNullOrEmpty(src.Cae) ? null :
                    new List<SimpleCae> {
                        new SimpleCae
                        {
                            OrderNumber = 0,
                            IsPrincipal = true,
                            CaeNumber = src.Cae
                        }
                    }))
                ;
        }


        /// <summary>
        /// Person object.
        /// </summary>
        private void PersonMapping()
        {
            // cogen => global mapping
            CreateMap<GetOrMaintainEntityCogenWASPOutputData, Person>()
                .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.CommonClientElement.ClientName))
                .ForMember(dest => dest.Birthdate, opts => opts.MapFrom(src => src.PersonalClientElement.BirthDate))
                .ForMember(dest => dest.Gender, opts => opts.MapFrom(src => src.PersonalClientElement.Sex))
                .ForMember(dest => dest.MaritalStatus, opts => opts.MapFrom(src => src.PersonalClientElement.MaritalStatus))
                .ForMember(dest => dest.DeceasedDate, opts => opts.MapFrom(src => src.PersonalClientElement.DieDate))

                // Nationality object
                .ForMember(dest => dest.Nationalities, opts => opts.MapFrom(src => NationalitiesMapping(src.PersonalClientElement)))

                // HonoraryTitle object
                .ForMember(dest => dest.HonoraryTitles, opts => opts.MapFrom(src => HonoraryTitlesMapping(src.PersonalClientElement)))

                // Job object
                .ForMember(dest => dest.Jobs, opts => opts.MapFrom(src => JobsMapping(src.PersonalClientElement)))
                ;
        }

        /// <summary>
        /// Organization object.
        /// </summary>
        private void OrganizationMapping()
        {
            // cogen => global mapping
            CreateMap<GetOrMaintainEntityCogenWASPOutputData, Organization>()
                .ForMember(dest => dest.CompanyName, opts => opts.MapFrom(src => src.CommonClientElement.ClientName))
                .ForMember(dest => dest.FoundingDate, opts => opts.MapFrom(src => src.CompanyClientElement.CompanyConstitutionDate))
                ;
        }

        /// <summary>
        /// Method to make mappings for Addresses information.
        /// </summary>
        private void AddressesMapping()
        {
            // cogen => global mapping
            CreateMap<AddressElementGlobal, Address>()
                .ForMember(dest => dest.AddressType, opts => opts.MapFrom(src => "Y"))
                .ForMember(dest => dest.Sequence, opts => opts.MapFrom(src => src.AddressReference))
                .ForMember(dest => dest.FormatType, opts => opts.MapFrom(src => src.AddressShape))

                .ForPath(dest => dest.Tipology.PostalAddress, opts => opts.MapFrom(src => src.StandardFormatAddress))
                .ForPath(dest => dest.Tipology.PostalAddress.FullAddress, opts =>
                    opts.MapFrom(src => $"{src.FreeFormatAddress.AddressLine1} {src.FreeFormatAddress.AddressLine2}"))
                .ForPath(dest => dest.Tipology.PostalBox, opts => opts.MapFrom(src => src.BoxFormatAddress))

                .ForMember(dest => dest.PostalCode, opts => opts.MapFrom(src => PostalCodeDivide(src.PostalCode)))
                .ForMember(dest => dest.PostalCodeDescription, opts => opts.MapFrom(src => src.PostalCodeDescription))
                .ForMember(dest => dest.CountryCode, opts => opts.MapFrom(src => src.Country))

            // global => cogen mapping
                .ReverseMap()
                .ForMember(dest => dest.AddressAssociationEffectiveDate, opts => opts.MapFrom(src => DateTime.Now))
                .ForMember(dest => dest.PostalCode, opts => opts.MapFrom(src =>
                        src.PostalCode.Replace("-", "", StringComparison.InvariantCultureIgnoreCase).PadRight(PostalCodeLength, '0')))
                .ForPath(dest => dest.FreeFormatAddress.AddressLine1, opts => opts.MapFrom(src => src.Tipology.PostalAddress.FullAddress))


                // flags for optional fields
                .ForMember(dest => dest.AddressAssociationEffectiveDateSpecified, opts => opts.MapFrom(src => true))
                ;


            // cogen => global mapping
            CreateMap<StandardFormatAddressElementGlobal, PoAddress>()
                .ForMember(dest => dest.RoadType, opts => opts.MapFrom(src => src.StreetType))
                .ForMember(dest => dest.RoadName, opts => opts.MapFrom(src => src.AddressName))
                .ForMember(dest => dest.HouseNumber, opts => opts.MapFrom(src => src.StreetNumber))
                .ForMember(dest => dest.FloorNumber, opts => opts.MapFrom(src => src.FloorNumber))
                .ForMember(dest => dest.AddToAddress, opts => opts.MapFrom(src => src.AdditionalAddressText))

            // global => cogen mapping
                .ReverseMap()
                ;


            // cogen => global mapping
            CreateMap<BoxFormatAddressElementGlobal, PoBox>()
                .ForMember(dest => dest.Number, opts => opts.MapFrom(src => src.PostOfficeBox))
                .ForMember(dest => dest.PostOfficeName, opts => opts.MapFrom(src => src.PostOffice))

            // global => cogen mapping
                .ReverseMap()
                ;
        }

        private static IEnumerable<Job> JobsMapping(PersonalClientElement source)
        {
            if (source == null || string.IsNullOrEmpty(source.ProfessionCode))
            {
                return Enumerable.Empty<Job>();
            }

            // build list with one element
            return new List<Job>
                {
                    new Job
                    {
                        IsPrincipal = true,
                        ProfessionalCode = source.ProfessionCode
                    }
                };
        }

        private static IEnumerable<HonoraryTitle> HonoraryTitlesMapping(PersonalClientElement source)
        {
            if (source == null || string.IsNullOrEmpty(source.Title))
            {
                return Enumerable.Empty<HonoraryTitle>();
            }

            // build list with one element
            return new List<HonoraryTitle>
                {
                    new HonoraryTitle
                    {
                        TitleCode = source.Title
                    }
                };
        }

        private static IEnumerable<Nationality> NationalitiesMapping(PersonalClientElement source)
        {
            if (source == null || string.IsNullOrEmpty(source.Nationality))
            {
                return Enumerable.Empty<Nationality>();
            }

            // build list with one element
            return new List<Nationality>
                {
                    new Nationality
                    {
                        IsPrincipal = true,
                        NationalityCode = source.Nationality
                    }
                };
        }


        private static IEnumerable<Cae> CaesMapping(GetOrMaintainEntityCogenWASPOutputData source)
        {
            if (source == null ||
                    (string.IsNullOrEmpty(source.CompanyClientElement?.EconomicActivityCode)
                    && string.IsNullOrEmpty(source.CommonClientElement?.EconomicActivityCode)
                ))
            {
                return Enumerable.Empty<Cae>();
            }

            // build list with one element
            var caes = new List<Cae>();
            BuildCae(source, caes, source.CompanyClientElement?.EconomicActivityCode, CaeOrderNumberForCompany);
            BuildCae(source, caes, source.CommonClientElement?.EconomicActivityCode, CaeOrderNumberForCommom);

            return caes;
        }

        private static void BuildCae(GetOrMaintainEntityCogenWASPOutputData source, ICollection<Cae> caes, string caeCode, int order)
        {
            if (!string.IsNullOrEmpty(caeCode))
            {
                caes.Add(
                    new Cae
                    {
                        CaeOrderNumber = order,
                        IsPrincipal = true,
                        CaeNumber = source.CompanyClientElement.EconomicActivityCode
                    });
            }
        }

        private static string PostalCodeDivide(string postalCodeValue)
        {
            const int PostalCodeMinLength = 7;
            const int PostalCodeFirstHalfLength = 4;
            const int PostalCodeSecondHalfLength = 3;

            // check for postal code transformation
            if (postalCodeValue != null && !postalCodeValue.Contains('-') && postalCodeValue.Length >= PostalCodeMinLength)
            {
                postalCodeValue = postalCodeValue.Substring(0, PostalCodeFirstHalfLength) + "-"
                    + postalCodeValue.Substring(PostalCodeFirstHalfLength, PostalCodeSecondHalfLength);
            }

            return postalCodeValue;
        }
    }
}

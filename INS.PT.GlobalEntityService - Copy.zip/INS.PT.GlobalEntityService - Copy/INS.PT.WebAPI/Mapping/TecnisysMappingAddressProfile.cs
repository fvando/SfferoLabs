﻿using AutoMapper;
using Tecnisys;
using models = INS.PT.WebAPI.Models.Elements;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Auto mapper profile for addresses information
    /// </summary>
    public class TecnisysMappingAddressProfile : Profile
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public TecnisysMappingAddressProfile()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<Address, models.Address>()
                // Sequence
                .ForMember(dest => dest.Sequence,
                        opts => opts.MapFrom(src => src.sequenceNumber))
                // AddressType
                .ForMember(dest => dest.AddressType,
                        opts => opts.MapFrom(src => src.addressTypeCode))
                // AddressTypeDescription
                .ForMember(dest => dest.AddressTypeDescription,
                        opts => opts.MapFrom(src => src.addressTypeDescription))
                //no mapping for IsFiscalAddress
                .ForMember(dest => dest.FormatType,
                                            // hardcoded mapping
                        opts => opts.MapFrom(src => "L"))
                .ForPath(dest => dest.Tipology.PostalAddress,
                        opts => opts.MapFrom(src => src))
                .ForMember(dest => dest.IsReturnedForCorrection,
                                                    // add default value
                        opts => opts.MapFrom(src => src.isReturnedForCorrection ?? false))
                // PostalCode
                .ForMember(dest => dest.PostalCode,
                        opts => opts.MapFrom(src => src.postalCode))
                // PostalCodeDescription
                .ForMember(dest => dest.PostalCodeDescription,
                        opts => opts.MapFrom(src => src.postalCodeDescription))
                // CountryCode
                .ForMember(dest => dest.CountryCode,
                        opts => opts.MapFrom(src => src.postalCountry.countryCode))
                // CountryDescription
                .ForMember(dest => dest.CountryDescription,
                        opts => opts.MapFrom(src => src.postalCountry.countryDescription))
                //no mapping for Georeference


            // mapping from GLOBAL => MASTER
                .ReverseMap()
                // members that need special mapping in reverse order
                .ForMember(dest => dest.sequenceNumber, 
                        opts => opts.MapFrom(src => ReadSequence(src)))

                // isReturnedForCorrection
                .ForMember(dest => dest.isReturnedForCorrection,
                        opts => opts.MapFrom(src => src.IsReturnedForCorrection))
                // addToAddress
                .ForMember(dest => dest.addToAddress,
                        opts => opts.MapFrom(src => src.Tipology.PostalAddress.AddToAddress))
                // doorNumber
                .ForMember(dest => dest.doorNumber,
                        opts => opts.MapFrom(src => src.Tipology.PostalAddress.DoorNumber))
                // floorNumber
                .ForMember(dest => dest.floorNumber,
                        opts => opts.MapFrom(src => src.Tipology.PostalAddress.FloorNumber))
                // fullAddress
                .ForMember(dest => dest.fullAddress,
                        opts => opts.MapFrom(src => src.Tipology.PostalAddress.FullAddress))
                // houseNumber
                .ForMember(dest => dest.houseNumber,
                        opts => opts.MapFrom(src => src.Tipology.PostalAddress.HouseNumber))
                // locality
                .ForMember(dest => dest.locality,
                        opts => opts.MapFrom(src => src.Tipology.PostalAddress.Locality))
                // roadName
                .ForMember(dest => dest.roadName,
                        opts => opts.MapFrom(src => src.Tipology.PostalAddress.RoadName))
                // roadType
                .ForMember(dest => dest.roadType,
                        opts => opts.MapFrom(src => src.Tipology.PostalAddress.RoadType))

                //only send flags if codes are filled
                .ForMember(dest => dest.isReturnedForCorrectionSpecified,
                        opts => opts.MapFrom(src => true))
                .ForMember(dest => dest.sequenceNumberSpecified,
                        opts => opts.MapFrom(src => !string.IsNullOrEmpty(src.Sequence)))
                .ForPath(dest => dest.postalCountry.countryCodeSpecified,
                        opts => opts.MapFrom(src => !string.IsNullOrEmpty(src.CountryCode)))
                ;

            CreatePoAddressMapping();
        }

        /// <summary>
        /// PoAddress mappings
        /// </summary>
        public void CreatePoAddressMapping()
        {
            // mapping for PoAddress
            // mapping from MASTER => GLOBAL
            CreateMap<Address, models.PoAddress>()
                .ForMember(dest => dest.RoadType,
                            opts => opts.MapFrom(src => src.roadType))
                .ForMember(dest => dest.RoadName,
                            opts => opts.MapFrom(src => src.roadName))
                .ForMember(dest => dest.HouseNumber,
                            opts => opts.MapFrom(src => src.houseNumber))
                .ForMember(dest => dest.FloorNumber,
                            opts => opts.MapFrom(src => src.floorNumber))
                .ForMember(dest => dest.DoorNumber,
                            opts => opts.MapFrom(src => src.doorNumber))
                .ForMember(dest => dest.AddToAddress,
                            opts => opts.MapFrom(src => src.addToAddress))
                .ForMember(dest => dest.FullAddress,
                            opts => opts.MapFrom(src => src.fullAddress))
                .ForMember(dest => dest.Locality,
                            opts => opts.MapFrom(src => src.locality))

            // mapping from GLOBAL => MASTER
                .ReverseMap()
                ;
        }

        private static int? ReadSequence(models.Address source)
        {
            if (string.IsNullOrEmpty(source.Sequence))
            {
                return null;
            }

            if (int.TryParse(source.Sequence, System.Globalization.NumberStyles.Integer,
                System.Globalization.CultureInfo.InvariantCulture, out var v))
            {
                return v;
            }
            else
            {
                return null;
            }
        }
    }
}

﻿using AutoMapper;
using Tecnisys;
using models = INS.PT.WebAPI.Models.Elements;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Auto mapper profile for merge information
    /// </summary>
    public class TecnisysMappingMergeProfile : Profile
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public TecnisysMappingMergeProfile()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<Merge, models.Merge>()
                // Sequence
                .ForMember(dest => dest.Sequence,
                            opts => opts.MapFrom(src => src.sequenceNumber))
                // FinalIdEntity
                .ForMember(dest => dest.FinalIdEntity,
                            opts => opts.MapFrom(src => src.finalDNI))
                // FinalValue
                .ForMember(dest => dest.FinalValue,
                            opts => opts.MapFrom(src => src.finalValue))
                // MergedIdEntity
                .ForMember(dest => dest.MergedIdEntity,
                            opts => opts.MapFrom(src => src.mergedDNI))
                // MergedValue
                .ForMember(dest => dest.MergedValue,
                            opts => opts.MapFrom(src => src.mergedValue))
                // Date
                .ForMember(dest => dest.Date,
                            opts => opts.MapFrom(src => src.mergeDate))
                // Value
                .ForMember(dest => dest.Value,
                            opts => opts.MapFrom(src => src.mergeValue))
                // MergeType
                .ForMember(dest => dest.MergeType,
                            opts => opts.MapFrom(src => src.mergeType))
                // TypeDescription
                .ForMember(dest => dest.TypeDescription,
                            opts => opts.MapFrom(src => src.mergeTypeDescription))
                // RequestId
                .ForMember(dest => dest.RequestId,
                            opts => opts.MapFrom(src => src.requestId))
                // fieldTodo
                .ForMember(dest => dest.Todo,
                            opts => opts.MapFrom(src => src.todo))

            // mapping from GLOBAL => MASTER
                .ReverseMap()
                //only send flags if codes are filled
                .ForMember(dest => dest.sequenceNumberSpecified,
                            opts => opts.MapFrom(src => src.Sequence.HasValue))
                .ForMember(dest => dest.mergeDateSpecified,
                            opts => opts.MapFrom(src => src.Date.HasValue))
                ;
        }
    }
}

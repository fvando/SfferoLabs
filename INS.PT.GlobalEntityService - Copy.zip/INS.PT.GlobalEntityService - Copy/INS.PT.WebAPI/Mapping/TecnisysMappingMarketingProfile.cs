﻿using AutoMapper;
using Tecnisys;
using models = INS.PT.WebAPI.Models.Elements;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Auto mapper profile for marketing information
    /// </summary>
    public class TecnisysMappingMarketingProfile : Profile
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public TecnisysMappingMarketingProfile()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<Marketing, models.Marketing>()
                // explicit mapping
                .ForMember(dest => dest.IsPaperlessAgeas,
                            opts => opts.MapFrom(src => src.isPaperlessAxa))
                // OccupationalSituation
                .ForMember(dest => dest.OccupationalSituationCode,
                            opts => opts.MapFrom(src => src.occupationalSituationCode))
                .ForMember(dest => dest.OccupationalSituationDescription,
                            opts => opts.MapFrom(src => src.occupationalSituationDescription))
                // LevelOfEducation
                .ForMember(dest => dest.LevelOfEducationCode,
                            opts => opts.MapFrom(src => src.levelOfEducationCode))
                .ForMember(dest => dest.LevelOfEducationDescription,
                            opts => opts.MapFrom(src => src.levelOfEducationDescription))
                // OccupationalGroup
                .ForMember(dest => dest.OccupationalGroupCode,
                            opts => opts.MapFrom(src => src.occupationalGroupCode))
                .ForMember(dest => dest.OccupationalGroupDescription,
                            opts => opts.MapFrom(src => src.occupationalGroupDescription))
                // source
                .ForMember(dest => dest.Source,
                            opts => opts.MapFrom(src => src.source))
                // MaximumCustomerAutoDiscountPercentage
                .ForMember(dest => dest.MaximumCustomerAutoDiscountPercentage,
                            opts => opts.MapFrom(src => src.maximumCustomerAutoDiscountPercentage))
                // SmsSent
                .ForMember(dest => dest.SmsSent,
                            opts => opts.MapFrom(src => src.smsSent))
                // HasClientArea
                .ForMember(dest => dest.HasClientArea,
                            opts => opts.MapFrom(src => src.IsWebClient))


                // mapping from GLOBAL => MASTER
                .ReverseMap()

                // fields that need flags for posting values
                .ForMember(dest => dest.isPaperlessAxaSpecified,
                            opts => opts.MapFrom(src => src.IsPaperlessAgeas.HasValue))
                .ForMember(dest => dest.maximumCustomerAutoDiscountPercentageSpecified,
                            opts => opts.MapFrom(src => src.MaximumCustomerAutoDiscountPercentage.HasValue))
                .ForMember(dest => dest.smsSentSpecified,
                            opts => opts.MapFrom(src => src.SmsSent.HasValue))
                ;
        }

    }
}

﻿using AutoMapper;
using System.Collections.Generic;
using System.Linq;
using Tecnisys;
using models = INS.PT.WebAPI.Models.Elements;


namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Class where mappings are defined for taxes in entity.
    /// </summary>
    public class TecnisysMappingTaxesProfile : Profile
    {
        private const string vatSource = nameof(TaxRegime.hasVat);
        private const string stampDutySource = nameof(TaxRegime.hasStampDuty);
        private const string ircSource = nameof(EntityTaxes.irc);
        private const string irsSource = nameof(EntityTaxes.irs);

        /// <summary>
        /// Method to build the mapping from aml to the models in this service.
        /// </summary>
        public TecnisysMappingTaxesProfile()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<Irc, models.Tax>()

                // mapping from GLOBAL => MASTER
                .ReverseMap()
                ;

            // mapping from MASTER => GLOBAL
            CreateMap<Irs, models.Tax>()

                // mapping from GLOBAL => MASTER
                .ReverseMap()
                ;
        }

        /// <summary>
        /// Build list of taxes coming from MAsterEntity.
        /// </summary>
        /// <param name="entityTaxes">master entity object.</param>
        /// <returns>IEnumerable of taxes</returns>
        public static IEnumerable<models.Tax> GetTaxesList(EntityTaxes entityTaxes)
        {
            var result = new List<models.Tax>();

            if (entityTaxes != null)
            {
                BuildIrcTax(entityTaxes, result);

                BuildIrsTax(entityTaxes, result);

                BuildVatTax(entityTaxes, result);

                BuildStampDutyTax(entityTaxes, result);
            }

            return result;
        }

        private static void BuildStampDutyTax(EntityTaxes entityTaxes, ICollection<models.Tax> result)
        {
            // check for existance of stamp duty
            if (entityTaxes.taxRegime?.hasStampDuty != null)
            {
                result.Add(new models.Tax
                {
                    // constant for Stamp Duty source
                    Source = stampDutySource,
                    Code = null,
                    Description = null,
                    Value = null,
                    // map start date field
                    StartDate = entityTaxes.taxRegime.startDate,
                    // map end date field
                    EndDate = entityTaxes.taxRegime.endDate,
                    // tax is active by the value of tax
                    Active = entityTaxes.taxRegime.hasStampDuty.Value
                });
            }
        }

        private static void BuildVatTax(EntityTaxes entityTaxes, ICollection<models.Tax> result)
        {
            // check for existance of vat
            if (entityTaxes.taxRegime?.hasVat != null)
            {
                result.Add(new models.Tax
                {
                    // constant for VAT source
                    Source = vatSource,
                    Code = null,
                    Description = null,
                    Value = null,
                    // map start date field
                    StartDate = entityTaxes.taxRegime.startDate,
                    // map end date field
                    EndDate = entityTaxes.taxRegime.endDate,
                    // tax is active by the value of tax
                    Active = entityTaxes.taxRegime.hasVat.Value
                });
            }
        }

        private static void BuildIrcTax(EntityTaxes entityTaxes, ICollection<models.Tax> result)
        {
            // check for existance of irc
            if (entityTaxes.irc?.code != null)
            {
                result.Add(new models.Tax
                {
                    // constant for IRC source
                    Source = ircSource,
                    // map code field
                    Code = entityTaxes.irc.code,
                    // map description field
                    Description = entityTaxes.irc.description,
                    // map value field
                    Value = entityTaxes.irc.value,
                    // map start date field
                    StartDate = entityTaxes.irc.startDate,
                    // map end date field
                    EndDate = entityTaxes.irc.endDate,
                    // tax is active when has start date and no end date
                    Active = entityTaxes.irc.startDateSpecified && !entityTaxes.irc.endDateSpecified
                });
            }
        }

        private static void BuildIrsTax(EntityTaxes entityTaxes, ICollection<models.Tax> result)
        {
            // check for existance of irs
            if (entityTaxes.irs?.code != null)
            {
                result.Add(new models.Tax
                {
                    // constant for IRS source
                    Source = irsSource,
                    // map code field
                    Code = entityTaxes.irs.code,
                    // map description field
                    Description = entityTaxes.irs.description,
                    // map value field
                    Value = entityTaxes.irs.value,
                    // map start date field
                    StartDate = entityTaxes.irs.startDate,
                    // map end date field
                    EndDate = entityTaxes.irs.endDate,
                    // tax is active when has start date and no end date
                    Active = entityTaxes.irs.startDateSpecified && !entityTaxes.irs.endDateSpecified
                });
            }
        }

        public static EntityTaxes SplitTaxesList(models.Entity entity)
        {
            if ((entity?.Taxes == null || !entity.Taxes.Any())
                && entity?.Type?.Individual?.Deficiency == null)
            {
                // no taxes to return
                return null;
            }

            // prepare taxes for split
            var vatTax = entity.Taxes?.FirstOrDefault(t => t.Source == vatSource);
            var stampDutyTax = entity.Taxes?.FirstOrDefault(t => t.Source == stampDutySource);

            var taxRegime = new TaxRegime
            {
                legalAct = null
            };

            ReadTaxRegime(entity, vatTax, stampDutyTax, taxRegime);

            return new EntityTaxes
            {
                // build TaxRegime object
                taxRegime = taxRegime,

                // irc struture with values or null values
                irc = ReadIrc(entity.Taxes),

                // irs struture with values or null values
                irs = ReadIrs(entity.Taxes)
            };
        }

        private static void ReadTaxRegime(models.Entity entity, models.Tax vatTax, models.Tax stampDutyTax, TaxRegime taxRegime)
        {
            if (entity.Type?.Individual != null)
            {
                // disability fileds
                taxRegime.disability = entity.Type.Individual.Deficiency;
                taxRegime.disabilitySpecified = entity.Type.Individual.Deficiency != null;
            }

            // vat fields
            if (vatTax != null)
            {
                taxRegime.hasVat = vatTax.Active;
                taxRegime.hasVatSpecified = true;
                taxRegime.startDate = vatTax.StartDate;
                taxRegime.startDateSpecified = vatTax.StartDate.HasValue;
                taxRegime.endDate = vatTax.EndDate;
                taxRegime.endDateSpecified = vatTax.EndDate.HasValue;
            }
            else
            {
                taxRegime.hasVat = taxRegime.disabilitySpecified ? false : (bool?)null;
                taxRegime.hasVatSpecified = taxRegime.disabilitySpecified;
            }

            // stamp duty fields
            if (stampDutyTax != null)
            {
                taxRegime.hasStampDuty = stampDutyTax.Active;
                taxRegime.hasStampDutySpecified = true;
                taxRegime.startDate = stampDutyTax.StartDate;
                taxRegime.startDateSpecified = stampDutyTax.StartDate.HasValue;
                taxRegime.endDate = stampDutyTax.EndDate;
                taxRegime.endDateSpecified = stampDutyTax.EndDate.HasValue;
            }
            else
            {
                taxRegime.hasStampDuty = taxRegime.disabilitySpecified ? false : (bool?)null;
                taxRegime.hasStampDutySpecified = taxRegime.disabilitySpecified;
            }

            // start date not defined, define one to prevent any erros
            if(!taxRegime.startDate.HasValue)
            {
                taxRegime.startDate = System.DateTime.Now;
                taxRegime.startDateSpecified = true;
            }
        }

        private static Irs ReadIrs(IEnumerable<models.Tax> taxes)
        {
            // read tax from collection
            var irsTax = taxes?.FirstOrDefault(t => t.Source == irsSource);

            return new Irs
            {
                // map code field
                code = irsTax?.Code,
                // map description field
                description = irsTax?.Description,
                // map value field
                value = irsTax?.Value,
                // map start date field
                startDate = irsTax?.StartDate,
                // map end date field
                endDate = irsTax?.EndDate,
                // flags for proxy object
                valueSpecified = irsTax?.Value != null,
                startDateSpecified = irsTax?.StartDate != null,
                endDateSpecified = irsTax?.EndDate != null
            };
        }

        private static Irc ReadIrc(IEnumerable<models.Tax> taxes)
        {
            // read tax from collection
            var ircTax = taxes?.FirstOrDefault(t => t.Source == ircSource);

            return new Irc
            {
                // map code field
                code = ircTax?.Code,
                // map description field
                description = ircTax?.Description,
                // map value field
                value = ircTax?.Value,
                // map start date field
                startDate = ircTax?.StartDate,
                // map end date field
                endDate = ircTax?.EndDate,
                // flags for proxy object
                valueSpecified = ircTax?.Value != null,
                startDateSpecified = ircTax?.StartDate != null,
                endDateSpecified = ircTax?.EndDate != null
            };
        }
    }
}

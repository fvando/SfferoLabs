﻿using AutoMapper;
using Tecnisys;
using models = INS.PT.WebAPI.Models.Elements;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Auto mapper profile for CAE information
    /// </summary>
    public class TecnisysMappingCaeProfile : Profile
    {
        /// <summary>
        /// constructor
        /// </summary>
        public TecnisysMappingCaeProfile()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<CAE, models.Cae>()
                // tecnisys => global mapping
                .ForMember(dest => dest.CaeOrderNumber,
                            opts => opts.MapFrom(src => GetCaeOrder(src.caeOrderNumber)))
                .ForMember(dest => dest.IsPrincipal,
                            opts => opts.MapFrom(src => src.isPrincipal ?? false))
                .ForMember(dest => dest.CaeNumber,
                            opts => opts.MapFrom(src => src.cae))
                //no mapping for CaeDescription
                .ForMember(dest => dest.StartDate,
                            opts => opts.MapFrom(src => src.startDate))
                .ForMember(dest => dest.EndDate,
                            opts => opts.MapFrom(src => src.endDate))
                //no mapping for SectorOfActivity

            // mapping from GLOBAL => MASTER
                .ReverseMap()
                .ForMember(dest => dest.caeOrderNumber,
                            opts => opts.MapFrom(src => src.CaeOrderNumber > 0 
                                    ? src.CaeOrderNumber.ToString(System.Globalization.CultureInfo.InvariantCulture) : ""))
                .ForMember(dest => dest.isPrincipal,
                            opts => opts.MapFrom(src => src.IsPrincipal))
                //only send flags if codes are filled
                .ForMember(dest => dest.startDateSpecified,
                            opts => opts.MapFrom(src => src.StartDate.HasValue))
                .ForMember(dest => dest.endDateSpecified,
                            opts => opts.MapFrom(src => src.EndDate.HasValue))
                .ForMember(dest => dest.isPrincipalSpecified,
                            opts => opts.MapFrom(src => true))
                ;
        }

        /// <summary>
        /// Transforms cae order string to int.
        /// </summary>
        /// <param name="caeOrderNumber">source string</param>
        /// <returns>int with value</returns>
        private static int GetCaeOrder(string caeOrderNumber)
        {
            // tecnisys => global mapping
            return int.TryParse(caeOrderNumber, System.Globalization.NumberStyles.Integer,
                System.Globalization.CultureInfo.InvariantCulture, out var number) ? number : 0;
        }

    }
}

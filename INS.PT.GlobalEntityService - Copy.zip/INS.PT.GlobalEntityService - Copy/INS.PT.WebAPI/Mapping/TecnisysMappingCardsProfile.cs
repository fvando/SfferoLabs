﻿using AutoMapper;
using Tecnisys;
using models = INS.PT.WebAPI.Models.Elements;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Auto mapper profile for cards information.
    /// </summary>
    public class TecnisysMappingCardsProfile : Profile
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public TecnisysMappingCardsProfile()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<EntityCards, models.Cards>()
                .ForMember(dest => dest.ClubCards, opts => opts.MapFrom(src => src.axaClubCards))

            // mapping from GLOBAL => MASTER
                .ReverseMap()
                ;


            // mapping from MASTER => GLOBAL
            CreateMap<AxaClubCard, models.ClubCards>()
                .ForMember(dest => dest.IssuedDate, opts => opts.MapFrom(src => src.issueDate))
                .ForMember(dest => dest.StatusCode, opts => opts.MapFrom(src => src.statusCode))
                .ForMember(dest => dest.StatusDescription, opts => opts.MapFrom(src => src.statusDescription))
                .ForMember(dest => dest.StatusDate, opts => opts.MapFrom(src => src.statusDate))
                .ForMember(dest => dest.AccumulatedDiscount, opts => opts.MapFrom(src => src.accumulatedDiscountAmount))
                .ForMember(dest => dest.IsBlocked, opts => opts.MapFrom(src => src.isBlocked ?? false))
                .ForMember(dest => dest.Number, opts => opts.MapFrom(src => src.cardNumber))

            // mapping from GLOBAL => MASTER
                .ReverseMap()

                // fileds that need flags for posting values
                .ForMember(dest => dest.issueDateSpecified, opts => opts.MapFrom(src => src.IssuedDate.HasValue))
                .ForMember(dest => dest.statusDateSpecified, opts => opts.MapFrom(src => src.StatusDate.HasValue))
                .ForMember(dest => dest.accumulatedDiscountAmountSpecified, opts => opts.MapFrom(src => src.AccumulatedDiscount.HasValue))
                .ForMember(dest => dest.isBlockedSpecified, opts => opts.MapFrom(src => true))
                ;
        }
    }
}

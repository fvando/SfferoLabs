﻿using Cogen_EntitiesService;
using System.Collections.Generic;
using System.Linq;
using System;
using INS.PT.WebAPI.Models.Elements;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Class where mappings are defined for the Cogen updates and inserts
    /// </summary>
    public class CogenMappingUpsertsProfile : AutoMapper.Profile
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public CogenMappingUpsertsProfile()
        {
            // global => cogen mapping
            CreateMap<Entity, GetOrMaintainEntityCogenWASPInputData>()
                .ForMember(dest => dest.ClientReferenceCGN, opts => opts.MapFrom(src => src.IdEntity))
                .ForMember(dest => dest.CommonClientElement, opts => opts.MapFrom(src => src))
                .ForMember(dest => dest.PersonalClientElement, opts => opts.MapFrom(src => src.Type != null ? src.Type.Individual : null))
                .ForPath(dest => dest.PersonalClientElement.Nationality, opts => opts.MapFrom(src => src.CountryCode))
                .ForMember(dest => dest.CompanyClientElement, opts => opts.MapFrom(src => src.Type != null ? src.Type.Company : null))
                .ForPath(dest => dest.CompanyClientElement.EconomicActivityCode, opts => opts.MapFrom(src => ReadCae(src.Caes, CogenMappingProfile.CaeOrderNumberForCompany)))


                // Address object
                .ForMember(dest => dest.AddressElement, opts => opts.MapFrom(src => src.Addresses.FirstOrDefault()))

                // Contact object
                .ForPath(dest => dest.ContactElement, opts => opts.MapFrom(src => src.Contacts))
                ;

            UpsertCommonElement();

            UpsertPersonalClientElement();

            UpsertCompanyClientElement();
        }

        private void UpsertCommonElement()
        {
            // CommonElement object
            // global => cogen mapping
            CreateMap<Entity, CommonElement>()
                .ForMember(dest => dest.ClientType, opts => opts.MapFrom(src => src.Type.Individual != null ? "P" : "C"))
                .ForMember(dest => dest.ClientName, opts => opts.MapFrom(src => src.Type.Individual != null ? src.Type.Individual.Name : src.Type.Company.CompanyName))
                .ForMember(dest => dest.FiscalNumber, opts => opts.MapFrom(src => src.VatNumber))
                .ForMember(dest => dest.EconomicActivityCode, opts => opts.MapFrom(src => ReadCae(src.Caes, CogenMappingProfile.CaeOrderNumberForCommom)))
                ;
        }

        private void UpsertCompanyClientElement()
        {
            // CompanyClientElement object
            // global => cogen mapping
            CreateMap<Organization, CompanyClientElement>()
                .ForMember(dest => dest.CompanyConstitutionDate, opts => opts.MapFrom(src => src.FoundingDate ?? DateTime.MinValue))

                // flags for optional fields
                .ForMember(dest => dest.CompanyConstitutionDateSpecified, opts => opts.MapFrom(src => src.FoundingDate.HasValue))
                ;
        }

        private void UpsertPersonalClientElement()
        {
            // PersonalClientElement object
            // global => cogen mapping
            CreateMap<Person, PersonalClientElement>()
                .ForMember(dest => dest.Sex, opts => opts.MapFrom(src => src.Gender))
                .ForMember(dest => dest.MaritalStatus, opts => opts.MapFrom(src => src.MaritalStatus))
                .ForMember(dest => dest.BirthDate, opts => opts.MapFrom(src => src.Birthdate ?? DateTime.MinValue))
                .ForMember(dest => dest.DieDate, opts => opts.MapFrom(src => src.DeceasedDate ?? DateTime.MinValue))

                // flags for optional fields
                .ForMember(dest => dest.BirthDateSpecified, opts => opts.MapFrom(src => src.Birthdate.HasValue))
                .ForMember(dest => dest.DieDateSpecified, opts => opts.MapFrom(src => src.DeceasedDate.HasValue))
                ;
        }


        private static string ReadCae(IEnumerable<Cae> caes, int order)
        {
            return caes?.FirstOrDefault(cae => cae.IsPrincipal && cae.CaeOrderNumber == order)?.CaeNumber;
        }
    }
}

﻿using Tecnisys;
using AutoMapper;
using models = INS.PT.WebAPI.Models.Elements;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Class where mappings are defined for the external References
    /// </summary>
    public class TecnisysMappingExternalRefProfile : Profile
    {
        public TecnisysMappingExternalRefProfile()
        {
            // tecnisys => global mapping
            CreateMap<EntityExternalReference, models.ExternalReference>()
                .ForMember(dest => dest.ExternalReferenceCode, opts => opts.MapFrom(src => src.slaveSystem))
                .ForMember(dest => dest.ExternalReferenceDescription, opts => opts.MapFrom(src => src.slaveSystem))

            // global => tecnisys mapping 
                .ReverseMap()

                // fields with reverse mapping
                .ForMember(dest => dest.slaveSystem, opts => opts.MapFrom(src => src.ExternalReferenceCode))
                ;
        }
    }
}

﻿using AutoMapper;
using System.Collections.Generic;
using System.Linq;
using Tecnisys;
using models = INS.PT.WebAPI.Models.Elements;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Auto mapper profile for Organization information
    /// </summary>
    public class TecnisysMappingOrganizationMapping : Profile
    {
        /// <summary>
        /// Contructor
        /// </summary>
        public TecnisysMappingOrganizationMapping()
        {
            // Create Organization properties Mapping
            CreateOrganizationMapping();

            // Create Organization Contact properties Mapping
            CreateOrganizationContactMapping();
        }

        #region Organization mapping
        /// <summary>
        /// Create Organization properties Mapping
        /// </summary>
        private void CreateOrganizationMapping()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<Organization, models.Organization>()
                // explicit mapping
                .ForMember(dest => dest.FoundingDate,
                            opts => opts.MapFrom(src => src.foundingDate))
                .ForMember(dest => dest.TotalEmployees,
                            opts => opts.MapFrom(src => src.totalEmployees))
                .ForMember(dest => dest.GrossAnnualRevenue,
                            opts => opts.MapFrom(src => src.grossAnnualRevenue))
                .ForMember(dest => dest.WagesAmount,
                            opts => opts.MapFrom(src => src.wagesAmount))
                .ForMember(dest => dest.EquityCapital,
                            opts => opts.MapFrom(src => src.equityCapital))
                .ForMember(dest => dest.CompanyTypeCode,
                            opts => opts.MapFrom(src => src.organizationTypeCode))
                .ForMember(dest => dest.CompanyTypeDescription,
                            opts => opts.MapFrom(src => src.organizationTypeDescription))
                .ForMember(dest => dest.LegalForm,
                            opts => opts.MapFrom(src => src.legalForm))
                .ForMember(dest => dest.Website,
                            opts => opts.MapFrom(src => src.website))
                // inner structure mapping
                .ForMember(dest => dest.OrganizationContactPoints,
                            opts => opts.MapFrom(src => src.organizationalContacts))

            // mapping from GLOBAL => MASTER
                .ReverseMap()
                //only send flags if codes are filled
                .ForMember(dest => dest.equityCapitalSpecified,
                            opts => opts.MapFrom(src => src.EquityCapital.HasValue))
                .ForMember(dest => dest.foundingDateSpecified,
                            opts => opts.MapFrom(src => src.FoundingDate.HasValue))
                .ForMember(dest => dest.grossAnnualRevenueSpecified,
                            opts => opts.MapFrom(src => src.GrossAnnualRevenue.HasValue))
                .ForMember(dest => dest.totalEmployeesSpecified,
                            opts => opts.MapFrom(src => src.TotalEmployees.HasValue))
                .ForMember(dest => dest.wagesAmountSpecified,
                            opts => opts.MapFrom(src => src.WagesAmount.HasValue))
                .ForMember(dest => dest.PublicEntitySpecified,
                            opts => opts.MapFrom(src => src.PublicEntity.HasValue))
                ;
        }
        #endregion

        #region OrganizationContact mapping
        /// <summary>
        /// Create Organization Contact properties Mapping
        /// </summary>
        private void CreateOrganizationContactMapping()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<OrganizationContactPoint, models.OrganizationContact>()
                .ForMember(dest => dest.Position,
                            opts => opts.MapFrom(src => src.sequenceNumber))
                .ForMember(dest => dest.ContactName,
                            opts => opts.MapFrom(src => src.contactName))
                // reads all the contacts from master into global
                .ForMember(dest => dest.Contacts,
                            opts => opts.MapFrom(src => ReadOrganizationContacts(src)))


            // mapping from GLOBAL => MASTER
                .ReverseMap()

                // members that need special mapping in reverse order
                .ForMember(dest => dest.office,
                            // find contact for office
                            opts => opts.MapFrom(src => GetContactValue(src.Contacts, nameof(OrganizationContactPoint.office))))
                .ForMember(dest => dest.phone,
                            // find contact for phone
                            opts => opts.MapFrom(src => GetContactValue(src.Contacts, nameof(OrganizationContactPoint.phone))))
                .ForMember(dest => dest.fax,
                            // find contact for fax
                            opts => opts.MapFrom(src => GetContactValue(src.Contacts, nameof(OrganizationContactPoint.fax))))
                .ForMember(dest => dest.email,
                            // find contact for email
                            opts => opts.MapFrom(src => GetContactValue(src.Contacts, nameof(OrganizationContactPoint.email))))
                //only send flag if code is filled
                .ForMember(dest => dest.sequenceNumberSpecified,
                            opts => opts.MapFrom(src => !string.IsNullOrEmpty(src.Position)))
                ;
        }

        /// <summary>
        /// Transforms the contact value to the Tecnisys object.
        /// </summary>
        /// <param name="contacts">list of contacts</param>
        /// <param name="name">contact to read</param>
        /// <returns>contact value if found</returns>
        private static string GetContactValue(IEnumerable<models.Contact> contacts, string name)
        {
            // mapping from GLOBAL => MASTER
            var contact = contacts.FirstOrDefault(c => c.ContactTypeDescription == name);

            return contact?.Value;
        }

        /// <summary>
        /// Method to read the contacts from MASTER results to Global entities.
        /// </summary>
        /// <param name="source">Maater structure where to read the information.</param>
        /// <returns>List of contacts</returns>
        private static List<models.Contact> ReadOrganizationContacts(OrganizationContactPoint source)
        {
            // mapping from MASTER => GLOBAL
            var result = new List<models.Contact>();

            // transform the office contact to the collection
            if (!string.IsNullOrEmpty(source.office))
            {
                result.Add(ReadContact(nameof(OrganizationContactPoint.office), source.office));
            }

            // transform the phone contact to the collection
            if (!string.IsNullOrEmpty(source.phone))
            {
                result.Add(ReadContact(nameof(OrganizationContactPoint.phone), source.phone));
            }

            // transform the fax contact to the collection
            if (!string.IsNullOrEmpty(source.fax))
            {
                result.Add(ReadContact(nameof(OrganizationContactPoint.fax), source.fax));
            }

            // transform the email contact to the collection
            if (!string.IsNullOrEmpty(source.email))
            {
                result.Add(ReadContact(nameof(OrganizationContactPoint.email), source.email));
            }

            return result;
        }

        /// <summary>
        /// Creates a contact for the Global Entity model.
        /// </summary>
        /// <param name="name">name of the contact to be created.</param>
        /// <param name="value">value of the contact.</param>
        /// <returns>Contact object for the Global Entity</returns>
        private static models.Contact ReadContact(string name, string value)
        {
            // build object
            return new models.Contact
            {
                ContactTypeCode = name.Substring(0, 1),
                ContactTypeDescription = name,
                Value = value
            };
        }
        #endregion
    }
}

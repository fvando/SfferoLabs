﻿using AutoMapper;
using INS.PT.WebAPI.Models.Output;
using Tecnisys;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Mapping for MPOS information.
    /// </summary>
    public class TecnisysMappingMposInformation : Profile
    {
        public TecnisysMappingMposInformation()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<MposData, MposInformationOutput>()
                // dni property for IdEntity
                .ForMember(dest => dest.IdEntity, opts => opts.MapFrom(src => src.dni))
                // email field mapping
                .ForMember(dest => dest.EmailAddress, opts => opts.MapFrom(src => src.email))
                // Georeference field mapping
                .ForMember(dest => dest.Georeference, opts => opts.MapFrom(src => src.location))
                // phone field mapping
                .ForMember(dest => dest.PhoneNumber, opts => opts.MapFrom(src => src.phone))

            // mapping from GLOBAL => MASTER
                .ReverseMap()
                ;
        }
    }
}

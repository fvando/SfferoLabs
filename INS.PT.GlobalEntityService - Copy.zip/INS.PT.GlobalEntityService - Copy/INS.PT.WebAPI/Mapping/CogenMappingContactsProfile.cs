﻿using Cogen_EntitiesService;
using INS.PT.WebAPI.Models.Elements;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Class where mappings are defined for the Cogen service
    /// </summary>
    public class CogenMappingContactsProfile : AutoMapper.Profile
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public CogenMappingContactsProfile()
        {
            // cogen => global mapping
            CreateMap<ContactElement, ContactLists>()
                .ForMember(dest => dest.Phones, opts => opts.MapFrom(src => src.Phones))
                .ForMember(dest => dest.Emails, opts => opts.MapFrom(src => src.Emails))

            // global => cogen mapping
                .ReverseMap()
                ;


            // cogen => global mapping
            CreateMap<PhoneElement, Phone>()
                .ForMember(dest => dest.PhoneTypeCode, opts => opts.MapFrom(src => src.ContactTypeCode))
                .ForMember(dest => dest.PhoneTypeDescription, opts => opts.MapFrom(src => src.ContactTypeDesc))
                .ForMember(dest => dest.PhoneNumber, opts => opts.MapFrom(src => $"{src.ContactPrefix} {src.ContactNumber}"))

            // global => cogen mapping
                .ReverseMap()
                ;


            // cogen => global mapping
            CreateMap<EmailElement, Email>()
                .ForMember(dest => dest.IsPreferred, opts => opts.MapFrom(src => src.MailPreferred))
                .ForMember(dest => dest.EmailTypeCode, opts => opts.MapFrom(src => src.MailType))
                .ForMember(dest => dest.EmailTypeDescription, opts => opts.MapFrom(src => src.MailDesc))
                .ForMember(dest => dest.EmailAddress, opts => opts.MapFrom(src => src.Mail))

            // global => cogen mapping
                .ReverseMap()

                // flags for optional fields
                .ForMember(dest => dest.MailPreferredSpecified, opts => opts.MapFrom(src => true))
                ;
        }
    }
}

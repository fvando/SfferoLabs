﻿using AutoMapper;
using Tecnisys;
using models = INS.PT.WebAPI.Models.Elements;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Auto mapper profile for profiles information
    /// </summary>
    public class TecnisysMappingProfileProfile : Profile
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public TecnisysMappingProfileProfile()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<EntityProfile, models.Profile>()

            // mapping from GLOBAL => MASTER
                .ReverseMap()
                ;
        }
    }
}

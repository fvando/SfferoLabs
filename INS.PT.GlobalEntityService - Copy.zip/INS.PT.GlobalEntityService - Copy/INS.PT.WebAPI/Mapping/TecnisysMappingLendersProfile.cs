﻿using AutoMapper;
using INS.PT.WebAPI.Models.Output;
using Tecnisys;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Auto mapper profile for creditor entities.
    /// </summary>
    public class TecnisysMappingLendersProfile : Profile
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public TecnisysMappingLendersProfile()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<CreditorEntity, LendersOutput>()
                // dni property for IdEntity
                .ForMember(dest => dest.IdEntity, opts => opts.MapFrom(src => src.dni))

            // mapping from GLOBAL => MASTER
                .ReverseMap()
                ;
        }
    }
}

﻿using AmlGet;
using AutoMapper;
using System;
using models = INS.PT.WebAPI.Models.Elements;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Class where mappings are defined for the AML service
    /// </summary>
    public class AmlMappingProfile : Profile
    {
        /// <summary>
        /// Method to build the mapping from aml to the models in this service.
        /// </summary>
        public AmlMappingProfile()
        {
            // aml => global mapping
            CreateMap<AMLOutputElement, models.Aml>()
                .ForMember(dest => dest.ConditionType, opts => opts.MapFrom(src => src.pep))
                //undone: no RDM list to describe ConditionType
                //.ForMember(dest => dest.ConditionDescription)  
                .ForMember(dest => dest.StartDate, opts => opts.MapFrom(src =>
                    src.pepConditionStartDateSpecified && src.pepConditionStartDate != DateTime.MinValue ? src.pepConditionStartDate : (DateTime?)null))
                .ForMember(dest => dest.EndDate, opts => opts.MapFrom(src =>
                    src.pepConditionEndDateSpecified && src.pepConditionStartDate != DateTime.MinValue ? src.pepConditionEndDate : (DateTime?)null))

                // global mapping => aml
                .ReverseMap()
                    .ForMember(dest => dest.pepConditionStartDate, opts => opts.MapFrom(src => src.StartDate ?? DateTime.MinValue))
                    .ForMember(dest => dest.pepConditionEndDate, opts => opts.MapFrom(src => src.EndDate ?? DateTime.MinValue))
                    .ForMember(dest => dest.pepConditionStartDateSpecified, opts => opts.MapFrom(src => src.StartDate.HasValue))
                    .ForMember(dest => dest.pepConditionEndDateSpecified, opts => opts.MapFrom(src => src.EndDate.HasValue))
                ;

        }
    }
}

﻿using AutoMapper;
using Tecnisys;
using System.Collections.Generic;
using System.Linq;
using models = INS.PT.WebAPI.Models.Elements;
using System.Text;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Class where mappings are defined for the Tecnisys service
    /// </summary>
    public class TecnisysMappingProfile : Profile
    {
        /// <summary>
        /// Method to build the mapping from tecnisys to the models in this service.
        /// </summary>
        public TecnisysMappingProfile()
        {
            // Create Entity properties Mapping
            CreateEntityMapping();

            // Create Bank Account properties Mapping
            CreateBankAccountMapping();
        }

        #region BankAccount mapping
        /// <summary>
        /// Create Bank Account properties Mapping
        /// </summary>
        private void CreateBankAccountMapping()
        {
            // tecnisys => global mapping
            CreateMap<BankAccount, models.BankAccount>()
                // explicit mapping
                .ForMember(dest => dest.SequenceBankAccountNumber,
                            opts => opts.MapFrom(src => src.orderNumber))
                .ForMember(dest => dest.BankAccountNumber,
                            opts => opts.MapFrom(src => src.bankNumber))
                .ForMember(dest => dest.Iban,
                            opts => opts.MapFrom(src => src.iban))

                // reuse mapping for reverse mapping
                .ReverseMap()
                //only send flag if code is filled
                .ForMember(dest => dest.orderNumberSpecified,
                            opts => opts.MapFrom(src => src.SequenceBankAccountNumber.HasValue))
                ;
        }
        #endregion

        #region Document mapping
        private const string PassportTypeCode = "PAS";

        /// <summary>
        /// Transforms Tecnisys documents and creates a GlobalEntity object with all documents.
        /// </summary>
        /// <param name="documents">list of documents</param>
        /// <param name="foreignDocuments">list of foreign documents</param>
        /// <param name="identityDocument">identity document</param>
        /// <returns></returns>
        private static List<models.Document> JoinDocs(IEnumerable<Document> documents, IEnumerable<ForeignDocument> foreignDocuments, IdentityDocument identityDocument, Passport passport)
        {
            // tecnisys => global mapping
            var result = new List<models.Document>();

            // read entity documents to collection
            foreach (var doc in documents)
            {
                var document = new models.Document
                {
                    DocumentTypeCode = doc.documentTypeCode,
                    DocumentTypeDescription = doc.documentTypeDescription,
                    DocumentNumber = doc.documentNumber,
                    //no mapping for IssueDate
                    //no mapping for ExpirationDate
                    //no mapping for DocumentCountryCode
                    //no mapping for DocumentCountryDescription
                };

                // if current document is passport and there's new structure filled
                if (string.Compare(document.DocumentTypeCode, PassportTypeCode, System.StringComparison.InvariantCultureIgnoreCase) == 0
                    && passport != null)
                {
                    document.DocumentNumber = passport.number;
                    // add date from new structure
                    document.IssueDate = passport.documentDate;
                }

                result.Add(document);
            }

            // read entity foreign documents to collection
            foreach (var doc in foreignDocuments)
            {
                result.Add(new models.Document
                {
                    DocumentTypeCode = doc.documentTypeCode,
                    DocumentTypeDescription = doc.documentTypeDescription,
                    DocumentNumber = doc.documentNumber,
                    IssueDate = doc.issueDate,
                    IssuingAuthority = doc.issuingAuthority,
                    DocumentCountryCode = doc.country.countryCode?.ToString(System.Globalization.CultureInfo.InvariantCulture),
                    DocumentCountryDescription = doc.country.countryDescription
                });
            }

            // if identity document is found add to collection also
            if (identityDocument != null
                && !string.IsNullOrEmpty(identityDocument.documentNumber))
            {
                result.Add(new models.Document
                {
                    DocumentTypeCode = "ID",
                    DocumentTypeDescription = nameof(IdentityDocument),
                    DocumentNumber = identityDocument.documentNumber,
                    IssueDate = identityDocument.documentDate,
                    //no mapping for DocumentCountryCode
                    //no mapping for DocumentCountryDescription
                });
            }

            return result;
        }

        /// <summary>
        /// Reads the identity document.
        /// </summary>
        /// <param name="documents">list of documents to read.</param>
        /// <returns>identity document</returns>
        private static IdentityDocument ReadIdentityDocument(IEnumerable<models.Document> documents)
        {
            var idDocument = models.Document.GetIdentityDocument(documents);

            if (idDocument != null)
            {
                return new IdentityDocument
                {
                    documentNumber = idDocument.DocumentNumber,
                    documentDate = idDocument.IssueDate,
                    //only send flag if code is filled
                    documentDateSpecified = idDocument.IssueDate.HasValue
                };
            }

            return null;
        }

        /// <summary>
        /// build Tecnisys foreign documents.
        /// </summary>
        /// <param name="documents">list of documents to read.</param>
        /// <returns>foreign documents</returns>
        private static List<ForeignDocument> ReadForeignDocuments(IEnumerable<models.Document> documents)
        {
            // global => tecnisys mapping
            var foreignDocuments = new List<ForeignDocument>();

            // only map the documents that contain the country code
            foreach (var doc in documents.Where(d => d.IsForeign && !d.IsIdentityCard && !d.IsIdentityDocument))
            {
                // try to read country code
                var countryCode = (int.TryParse(doc.DocumentCountryCode, System.Globalization.NumberStyles.Integer,
                                            System.Globalization.CultureInfo.InvariantCulture, out var number)
                                            ? number : (int?)null);

                foreignDocuments.Add(new ForeignDocument
                {
                    documentTypeCode = doc.DocumentTypeCode,
                    documentTypeDescription = doc.DocumentTypeDescription,
                    documentNumber = doc.DocumentNumber,
                    issueDate = doc.IssueDate,
                    issueDateSpecified = doc.IssueDate.HasValue,
                    issuingAuthority = doc.IssuingAuthority,
                    country = new Country
                    {
                        // use code from above
                        countryCode = countryCode,
                        countryDescription = doc.DocumentCountryDescription,
                        //only send flag if code is filled
                        countryCodeSpecified = countryCode.HasValue
                    }
                });
            }

            return foreignDocuments;
        }

        /// <summary>
        /// build Tecnisys documents
        /// </summary>
        /// <param name="documents">list of documents to read.</param>
        /// <returns>documents</returns>
        private static List<Document> ReadDocuments(IEnumerable<models.Document> documents)
        {
            // global => tecnisys mapping
            var result = new List<Document>();

            // only map the documents that do not contain the country code
            foreach (var doc in documents.Where(d => !d.IsForeign && !d.IsIdentityCard && !d.IsIdentityDocument))
            {
                result.Add(new Document
                {
                    documentTypeCode = doc.DocumentTypeCode,
                    documentTypeDescription = doc.DocumentTypeDescription,
                    documentNumber = doc.DocumentNumber
                });
            }

            return result;
        }

        /// <summary>
        /// search if the documents list contains a passport to map to the matching 
        /// </summary>
        /// <param name="documents">list of documents to read.</param>
        /// <returns>Passport object if document is found in list.</returns>
        private static Passport ReadPassport(IEnumerable<models.Document> documents)
        {
            // read passport document
            var passportDocument = documents.FirstOrDefault(d =>
                string.Compare(d.DocumentTypeCode, PassportTypeCode, System.StringComparison.InvariantCultureIgnoreCase) == 0);

            if (passportDocument != null)
            {
                // build object to return
                return new Passport
                {
                    number = passportDocument.DocumentNumber,
                    documentDate = passportDocument.IssueDate,
                    documentDateSpecified = passportDocument.IssueDate.HasValue
                };
            }

            // no passport
            return null;
        }
        #endregion

        #region CrsFatca mapping
        // no match type in Tecnisys
        #endregion

        #region AffinityRelation mapping
        // no match type in Tecnisys
        #endregion

        /// <summary>
        /// Create Entity properties Mapping
        /// </summary>
        private void CreateEntityMapping()
        {
            // tecnisys => global mapping
            CreateMap<Entity, models.Entity>()
                // explicit mapping
                .ForMember(dest => dest.IdEntity,
                            opts => opts.MapFrom(src => src.dni))
                .ForMember(dest => dest.VatNumber,
                            opts => opts.MapFrom(src => src.vatNumber))
                .ForMember(dest => dest.IsForeignVat,
                            opts => opts.MapFrom(src => src.isForeignVat ?? false))
                .ForMember(dest => dest.CountryCode,
                            opts => opts.MapFrom(src => src.nationalityCode))
                .ForMember(dest => dest.CountryDescription,
                            opts => opts.MapFrom(src => src.nationalityDescription))
                .ForMember(dest => dest.Type,
                            opts => opts.Ignore())


                // mappings for person that come from root in master
                .ForPath(dest => dest.Type.Individual,
                            opts => opts.MapFrom(src => src.person))
                .ForPath(dest => dest.Type.Individual.Deficiency,
                            opts => opts.MapFrom(src => src.entityTaxes.taxRegime.disability))

                // taxes mapping
                .ForMember(dest => dest.Taxes,
                            opts => opts.MapFrom(src => TecnisysMappingTaxesProfile.GetTaxesList(src.entityTaxes)))



                .ForPath(dest => dest.Type.Individual.Nationalities,
                            opts => opts.MapFrom(src => GetNationalities(src)))
                .ForPath(dest => dest.Type.Company,
                            opts => opts.MapFrom(src => src.organization))
                .ForMember(dest => dest.Addresses,
                            opts => opts.MapFrom(src => src.addresses))
                .ForMember(dest => dest.Contacts,
                            opts => opts.MapFrom(src => src.entityContactPoints))
                .ForMember(dest => dest.BankAccounts,
                            opts => opts.MapFrom(src => src.bankAccounts))
                .ForMember(dest => dest.Documents,
                            opts => opts.MapFrom(src =>
                                JoinDocs(src.entityDocuments.documents,
                                    src.entityDocuments.foreignDocuments,
                                    src.entityDocuments.identityDocument,
                                    src.entityDocuments.passportDocument)
                                ))

                .ForMember(dest => dest.Caes,
                            opts => opts.MapFrom(src => src.organization.caes))

                .ForMember(dest => dest.MarketingInformation,
                            opts => opts.MapFrom(src => src.marketing))

                .ForMember(dest => dest.Merges,
                            opts => opts.MapFrom(src => src.merges))

                .ForMember(dest => dest.Profiles,
                            opts => opts.MapFrom(src => src.profiles))

                .ForMember(dest => dest.Cards,
                            opts => opts.MapFrom(src => src.entityCards))
                .ForMember(dest => dest.CrmInformation,
                            opts => opts.MapFrom(src => src.crm))



                // actions to take after mapping to finish transformation
                .AfterMap((dest, src) => AfterMapping(dest, src))


                // reuse mapping for reverse mapping
                .ReverseMap()

                // members that need special mapping in reverse order
                .ForPath(dest => dest.entityDocuments.documents,
                            opts => opts.MapFrom(src => ReadDocuments(src.Documents)))
                .ForPath(dest => dest.entityDocuments.foreignDocuments,
                            opts => opts.MapFrom(src => ReadForeignDocuments(src.Documents)))
                .ForPath(dest => dest.entityDocuments.identityDocument,
                            opts => opts.MapFrom(src => ReadIdentityDocument(src.Documents)))
                .ForPath(dest => dest.entityDocuments.passportDocument,
                            opts => opts.MapFrom(src => ReadPassport(src.Documents)))


                // taxes mapping
                .ForMember(dest => dest.entityTaxes,
                            opts => opts.MapFrom(src => TecnisysMappingTaxesProfile.SplitTaxesList(src)))

                // actions to take after mapping to finish transformation
                .AfterMap((dest, src) => AfterMapping(dest, src))
                ;
        }

        /// <summary>
        /// Buils the Nationalities list based on the MasterEntity response
        /// </summary>
        /// <param name="source">MasterEntity object with information.</param>
        /// <returns>A new list of nationalities</returns>
        private static List<models.Nationality> GetNationalities(Entity source)
        {
            // tecnisys => global mapping
            // build list with one element
            return new List<models.Nationality>
                {
                    new models.Nationality
                    {
                        IsPrincipal = true,
                        NationalityCode = source.nationalityCode.HasValue ?
                                            source.nationalityCode.Value.ToString(System.Globalization.CultureInfo.InvariantCulture) : "",
                        NationalityDescription = source.nationalityDescription
                    }
                };
        }

        private static void AfterMapping(Entity source, models.Entity destination)
        {
            // tecnisys => global mapping

            // if entity is a person
            if (source.person?.genderCode != null)
            {
                // build the entity name
                destination.Type.Individual.Name = source.firstName +
                    (string.IsNullOrEmpty(source.middleName) ? "" : " " + source.middleName) +
                    (string.IsNullOrEmpty(source.lastName) ? "" : " " + source.lastName);
                // clear company object
                destination.Type.Company = null;
                //prevent filling the company name since it's identified as person
                return;
            }

            // clear individual object
            destination.Type.Individual = null;
            // build the company name
            destination.Type.Company.CompanyName = source.firstName +
                    (string.IsNullOrEmpty(source.middleName) ? "" : " " + source.middleName) +
                    (string.IsNullOrEmpty(source.lastName) ? "" : " " + source.lastName);
        }

        private static void AfterMapping (models.Entity source, Entity destination)
        {
            // global => tecnisys mapping
            BuildNationalities(source, destination);

            BuildNameForTecnisys(source, destination);

            OrderCaes(destination);

            // clear entity taxes fi no fields are set
            if ((source.Taxes == null || !source.Taxes.Any())
                && source.Type?.Individual?.Deficiency == null)
            {
                destination.entityTaxes = null;
            }
        }

        // custom mapping order for CAES in MasterEntity
        private static void OrderCaes(Entity destination)
        {
            if (destination.organization?.caes != null &&
                destination.organization.caes.Any())
            {
                var orderCaes = new List<CAE>(destination.organization.caes.Where(c => c.isPrincipal ?? false));

                orderCaes.AddRange(destination.organization.caes.Where(c => !(c.isPrincipal ?? false)));

                destination.organization.caes = orderCaes.ToArray();
            }
        }

        private static void BuildNationalities(models.Entity source, Entity destination)
        {
            // reverse mapping for nationalities
            var nationality = source.Type.Individual?.Nationalities?.FirstOrDefault(n => n.IsPrincipal);
            if (nationality == null)
            {
                destination.nationalityCode = null;
                destination.nationalityDescription = null;
            }
            else
            {
                // try to transform the nationality code
                if (int.TryParse(nationality.NationalityCode, System.Globalization.NumberStyles.Integer,
                    System.Globalization.CultureInfo.InvariantCulture, out var code))
                {
                    destination.nationalityCode = code;
                    destination.nationalityCodeSpecified = true;
                }
                destination.nationalityDescription = nationality.NationalityDescription;
            }
        }

        private static void BuildNameForTecnisys(models.Entity source, Entity destination)
        {
            // set name for entity
            if (!string.IsNullOrEmpty(source.Type.Individual?.Name))
            {
                SplitName(destination, source.Type.Individual.Name);
            }
            else if (!string.IsNullOrEmpty(source.Type.Company?.CompanyName))
            {
                SplitName(destination, source.Type.Company.CompanyName);
            }
            else
            {
                // no name to transform => initialize members
                SplitName(destination, string.Empty);
            }
        }

        private static void SplitName(Entity destiny, string fullname)
        {
            // clear destination fields
            destiny.firstName = string.Empty;
            destiny.middleName = string.Empty;
            destiny.lastName = string.Empty;

            // validate if any split is possible
            if (string.IsNullOrEmpty(fullname))
            {
                return;
            }

            // split name to distribute thru the fields
            var names = fullname.Split(' ');

            // first name get's the first
            destiny.firstName = names[0];
            if (names.Length > 1)
            {
                // last name get's the last
                destiny.lastName = names[names.Length - 1];

                // joing the others names for the middle name
                var middleNames = new StringBuilder();
                for (var i = 1; i < names.Length - 1; ++i)
                {
                    if (i > 1)
                    {
                        middleNames.Append(" ");
                    }

                    middleNames.Append(names[i]);
                }

                // fill middle name with calculation result
                destiny.middleName = middleNames.ToString();
            }
        }
    }
}

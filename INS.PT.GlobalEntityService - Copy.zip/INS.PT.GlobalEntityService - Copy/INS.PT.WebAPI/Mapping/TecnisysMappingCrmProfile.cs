﻿using AutoMapper;
using Tecnisys;
using models = INS.PT.WebAPI.Models.Elements;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Auto mapper profile for crm information.
    /// </summary>
    public class TecnisysMappingCrmProfile : Profile
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public TecnisysMappingCrmProfile()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<CRM, models.CrmInformation>()
                // explicit mapping
                .ForMember(dest => dest.Segmentation, opts => opts.MapFrom(src => src.segmentation))
                .ForMember(dest => dest.QualitativeValue, opts => opts.MapFrom(src => src.qualitativeValue))
                .ForMember(dest => dest.PropensityForAcquiringAuto, opts => opts.MapFrom(src => src.propensityForAcquiringAuto))
                .ForMember(dest => dest.PropensityForAcquiringMrh, opts => opts.MapFrom(src => src.propensityForAcquiringMRH))
                .ForMember(dest => dest.PropensityForAcquiringTvi, opts => opts.MapFrom(src => src.propensityForAcquiringTVI))
                .ForMember(dest => dest.PropensityForAcquiringUnl, opts => opts.MapFrom(src => src.propensityForAcquiringUNL))
                .ForMember(dest => dest.SigSegmentation1, opts => opts.MapFrom(src => src.sigSegmentation1))
                .ForMember(dest => dest.SigSegmentation2, opts => opts.MapFrom(src => src.sigSegmentation2))
                .ForMember(dest => dest.IsSmoker, opts => opts.MapFrom(src => src.isSmoker))
                .ForMember(dest => dest.PreferentialContactCode, opts => opts.MapFrom(src => src.preferentialContactCode))
                .ForMember(dest => dest.PreferentialContactDescription, opts => opts.MapFrom(src => src.preferentialContactDescription))
                .ForMember(dest => dest.ProtocolCode, opts => opts.MapFrom(src => src.protocolCode))
                .ForMember(dest => dest.ProtocolDescription, opts => opts.MapFrom(src => src.protocolDescription))

            // mapping from GLOBAL => MASTER
                .ReverseMap()

                // fields that need flags for posting values
                .ForMember(dest => dest.isSmokerSpecified, opts => opts.MapFrom(src => src.IsSmoker.HasValue))
                ;
        }
    }
}

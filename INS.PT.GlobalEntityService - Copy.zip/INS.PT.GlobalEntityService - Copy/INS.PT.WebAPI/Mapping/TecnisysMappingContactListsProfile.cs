﻿using AutoMapper;
using Tecnisys;
using models = INS.PT.WebAPI.Models.Elements;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Auto mapper profile for contacts lists information
    /// </summary>
    public class TecnisysMappingContactListsProfile : Profile
    {
        /// <summary>
        /// Contructor
        /// </summary>
        public TecnisysMappingContactListsProfile()
        {
            // Create Contact Lists properties Mapping
            CreateContactListsMapping();

            // Create Email properties Mapping
            CreateEmailMapping();

            // Create Phone properties Mapping
            CreatePhoneMapping();
        }

        #region Phone mapping
        /// <summary>
        /// Create Phone properties Mapping
        /// </summary>
        private void CreatePhoneMapping()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<Phone, models.Phone>()
                .ForMember(dest => dest.PhoneIdentifier,
                            opts => opts.MapFrom(src => src.phoneIdentifier))
                .ForMember(dest => dest.PhoneTypeCode,
                            opts => opts.MapFrom(src => src.phoneTypeCode))
                .ForMember(dest => dest.PhoneTypeDescription,
                            opts => opts.MapFrom(src => src.phoneTypeDescription))
                .ForMember(dest => dest.PhoneNumber,
                            opts => opts.MapFrom(src => src.phoneNumber))
                .ForMember(dest => dest.IsPreferred,
                            opts => opts.MapFrom(src => src.isPreferred ?? false))


            // mapping from GLOBAL => MASTER
                .ReverseMap()

                // members that need special mapping in reverse order
                .ForMember(dest => dest.isPreferred,
                            opts => opts.MapFrom(src => src.IsPreferred))
                //only send flag if code is filled
                .ForMember(dest => dest.isPreferredSpecified,
                            opts => opts.MapFrom(src => true))
                ;
        }
        #endregion

        #region Email mapping
        /// <summary>
        /// Create Email properties Mapping
        /// </summary>
        private void CreateEmailMapping()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<Email, models.Email>()
                .ForMember(dest => dest.EmailIdentifier,
                            opts => opts.MapFrom(src => src.emailIdentifier))
                .ForMember(dest => dest.EmailTypeCode,
                            opts => opts.MapFrom(src => src.emailTypeCode))
                .ForMember(dest => dest.EmailTypeDescription,
                            opts => opts.MapFrom(src => src.emailTypeDescription))
                .ForMember(dest => dest.EmailAddress,
                            opts => opts.MapFrom(src => src.email))
                .ForMember(dest => dest.IsPreferred,
                            opts => opts.MapFrom(src => src.emailTypeCode == "1"))


            // mapping from GLOBAL => MASTER
                .ReverseMap()
                //only send flag if code is filled
                .ForMember(dest => dest.emailIdentifierSpecified,
                            opts => opts.MapFrom(src => src.EmailIdentifier.HasValue))
                ;
        }
        #endregion

        #region ContactLists mapping
        /// <summary>
        /// Create Contact Lists properties Mapping
        /// </summary>
        private void CreateContactListsMapping()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<EntityContactPoints, models.ContactLists>()
                .ForMember(dest => dest.Emails,
                            opts => opts.MapFrom(src => src.emails))
                .ForMember(dest => dest.Phones,
                            opts => opts.MapFrom(src => src.phones))

            // mapping from GLOBAL => MASTER
                .ReverseMap();
        }
        #endregion
    }
}

﻿using AutoMapper;
using models = INS.PT.WebAPI.Models.Elements;
using System.Xml.Linq;
using System.Xml.XPath;
using System;
using System.Globalization;
using Tecnisys;


namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Class with mapping from Xml to SimpleEntity object
    /// </summary>
    /// <seealso cref="AutoMapper.Profile" />
    public class SimpleEntityProfile : Profile
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SimpleEntityProfile"/> class.
        /// </summary>
        public SimpleEntityProfile()
        {
            CreateMap<ShortList, Models.Output.SearchEntityOutput>()
                .ForMember(dest => dest.MatchedEntities, opts => opts.MapFrom(src => src.ShortLines))
                ;

            CreateMap<ShortLine, models.SimpleEntity>()               
                // no mapping for these fields
                //.ForMember(dest => dest.EntityType, opts => opts.MapFrom(src => src.))
                //.ForMember(dest => dest.EntityPhone, opts => opts.MapFrom(src => src.))


                .ForMember(dest => dest.IdEntity, opts => opts.MapFrom(src => src.Dni))
                .ForMember(dest => dest.Name, opts => opts.MapFrom(src => src.Name))
                .ForMember(dest => dest.VatNumber, opts => opts.MapFrom(src => src.VatNumber))
                .ForMember(dest => dest.Addresses, opts => opts.MapFrom(src => src.Address))
                .ForMember(dest => dest.Birthdate, opts => opts.MapFrom(src => src.Birthdate))
                .ForMember(dest => dest.Caes, opts => opts.MapFrom(src => src.Caes))
                ;

            // mapping for SimpleEntity
            CreateMap<XElement, models.SimpleEntity>()
                // mapping for IdEntity
                .ForMember(dest => dest.IdEntity,
                            opts => opts.MapFrom(src => src.XPathSelectElement("DNI").Value))
                // mapping for Name
                .ForMember(dest => dest.Name,
                            opts => opts.MapFrom(src => src.XPathSelectElement("NAME").Value))
                // mapping for VatNumber
                .ForMember(dest => dest.VatNumber,
                            opts => opts.MapFrom(src => src.XPathSelectElement("VAT_NUMBER").Value))
                // mapping for Birthdate
                .ForMember(dest => dest.Birthdate,
                            opts => opts.MapFrom(src => ParseDate(src.XPathSelectElement("BIRTHDATE").Value)))
                // mapping for Addresses
                .ForMember(dest => dest.Addresses,
                            opts => opts.MapFrom(src => src.XPathSelectElements("ADDRESS/TYP_PES_ADDRESS")))
                // mapping for Caes
                .ForMember(dest => dest.Caes,
                            opts => opts.MapFrom(src => src.XPathSelectElements("CAE/TYP_PES_CAE")))
                ;

            //no mapping missing EntityType
            //no mapping missing EntityPhone

            // create mapping for Address
            MappingAddress();

            // create mapping for PoAddress
            MappingPoAddress();

            // create mapping for simple cae
            MappingCae();
        }

        private void MappingAddress()
        {
            // mapping for Address
            CreateMap<XElement, models.Address>()
                .ForMember(dest => dest.Sequence,
                            opts => opts.MapFrom(src => src.XPathSelectElement("SEQUENCE").Value))
                .ForMember(dest => dest.AddressType,
                            opts => opts.MapFrom(src => src.XPathSelectElement("ADDRESS_TYPE_CODE").Value))
                .ForMember(dest => dest.AddressTypeDescription,
                            opts => opts.MapFrom(src => src.XPathSelectElement("ADDRESS_TYPE_DESCRIPTION").Value))
                //.ForMember(dest => dest.IsFiscalAddress,
                //            opts => opts.MapFrom(src => src.XPathSelectElement("").Value))
                .ForMember(dest => dest.FormatType,
                            opts => opts.MapFrom(src => "L"))
                .ForPath(dest => dest.Tipology.PostalAddress,
                            opts => opts.MapFrom(src => src))
                //.ForPath(dest => dest.Tipology.PostalBox,
                //            opts => opts.MapFrom(src => src.XPathSelectElement("").Value))
                //.ForMember(dest => dest.IsReturnedForCorrection,
                //            opts => opts.MapFrom(src => src.XPathSelectElement("").Value))
                .ForMember(dest => dest.PostalCode,
                            opts => opts.MapFrom(src => src.XPathSelectElement("POSTAL_CODE").Value))
                .ForMember(dest => dest.PostalCodeDescription,
                            opts => opts.MapFrom(src => src.XPathSelectElement("POSTAL_CODE_DESCRIPTION").Value))
                .ForMember(dest => dest.CountryCode,
                            opts => opts.MapFrom(src => src.XPathSelectElement("POSTAL_COUNTRY/COUNTRY_CODE").Value))
                .ForMember(dest => dest.CountryDescription,
                            opts => opts.MapFrom(src => src.XPathSelectElement("POSTAL_COUNTRY/COUNTRY_DESCRIPTION").Value))
                //.ForMember(dest => dest.Georeference,
                //            opts => opts.MapFrom(src => src.XPathSelectElement("").Value))
                ;
        }

        private void MappingPoAddress()
        {
            // mapping for PoAddress
            CreateMap<XElement, models.PoAddress>()
                .ForMember(dest => dest.RoadType,
                            opts => opts.MapFrom(src => src.XPathSelectElement("ROAD_TYPE").Value))
                .ForMember(dest => dest.RoadName,
                            opts => opts.MapFrom(src => src.XPathSelectElement("ROAD_NAME").Value))
                .ForMember(dest => dest.HouseNumber,
                            opts => opts.MapFrom(src => src.XPathSelectElement("HOUSE_NUMBER").Value))
                .ForMember(dest => dest.FloorNumber,
                            opts => opts.MapFrom(src => src.XPathSelectElement("FLOOR_NUMBER").Value))
                .ForMember(dest => dest.DoorNumber,
                            opts => opts.MapFrom(src => src.XPathSelectElement("DOOR_NUMBER").Value))
                .ForMember(dest => dest.AddToAddress,
                            opts => opts.MapFrom(src => src.XPathSelectElement("ADD_TO_ADDRESS").Value))
                .ForMember(dest => dest.FullAddress,
                            opts => opts.MapFrom(src => src.XPathSelectElement("FULL_ADDRESS").Value))
                .ForMember(dest => dest.Locality,
                            opts => opts.MapFrom(src => src.XPathSelectElement("LOCALITY").Value))
                ;
        }

        private void MappingCae()
        {
            // mapping for PoAddress
            CreateMap<CAE, models.SimpleCae>()
                // OrderNumber
                .ForMember(dest => dest.OrderNumber,
                            opts => opts.MapFrom(src => src.caeOrderNumber))
                // CAE
                .ForMember(dest => dest.CaeNumber,
                            opts => opts.MapFrom(src => src.cae))
                // StartDate
                .ForMember(dest => dest.StartDate,
                            opts => opts.MapFrom(src => src.startDate))
                // EndDate
                .ForMember(dest => dest.EndDate,
                            opts => opts.MapFrom(src => src.endDate))
                // IsPrincipal
                .ForMember(dest => dest.IsPrincipal,
                            opts => opts.MapFrom(src => src.isPrincipal))
                ;

            // mapping for PoAddress
            CreateMap<XElement, models.SimpleCae>()
                // OrderNumber
                .ForMember(dest => dest.OrderNumber,
                            opts => opts.MapFrom(src => src.XPathSelectElement("CAE_ORDER_NUMBER").Value))
                // CAE
                .ForMember(dest => dest.CaeNumber,
                            opts => opts.MapFrom(src => src.XPathSelectElement("CAE").Value))
                // StartDate
                .ForMember(dest => dest.StartDate,
                            opts => opts.MapFrom(src => ParseDate(src.XPathSelectElement("START_DATE").Value)))
                // EndDate
                .ForMember(dest => dest.EndDate,
                            opts => opts.MapFrom(src => ParseDate(src.XPathSelectElement("END_DATE").Value)))
                // IsPrincipal
                .ForMember(dest => dest.IsPrincipal,
                            opts => opts.MapFrom(src => string.Compare(src.XPathSelectElement("IS_PRINCIPAL").Value,
                                "T", StringComparison.InvariantCultureIgnoreCase) == 0))
                ;
        }

        private static DateTime? ParseDate(string value)
        {
            // accetped date formats
            var dateFormats = new [] { "yy/MM/dd", "yy.MM.dd", "yy-MM-dd" };

            // try to build a date based on the Tecnisys date
            if (DateTime.TryParseExact(value, dateFormats,
                CultureInfo.InvariantCulture, DateTimeStyles.None, out var date))
            {
                return date;
            }

            return null;
        }
    }
}

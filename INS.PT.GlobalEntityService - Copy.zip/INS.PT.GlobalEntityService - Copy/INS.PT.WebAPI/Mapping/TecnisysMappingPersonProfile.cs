﻿using AutoMapper;
using System.Collections.Generic;
using Tecnisys;
using models = INS.PT.WebAPI.Models.Elements;

namespace INS.PT.WebAPI.Mapping
{
    /// <summary>
    /// Auto mapper profile for person information
    /// </summary>
    public class TecnisysMappingPersonProfile : Profile
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public TecnisysMappingPersonProfile()
        {
            // Create Person properties Mapping
            CreatePersonMapping();

            // Create Honorary Title properties Mapping
            CreateHonoraryTitleMapping();

            // Create Job properties Mapping
            CreateJobMapping();

            // Create Driver Licence properties Mapping
            CreateDriverLicenceMapping();
        }

        #region DriverLicence mapping
        /// <summary>
        /// Create Driver Licence properties Mapping
        /// </summary>
        private void CreateDriverLicenceMapping()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<DriverLicense, models.DriverLicence>()
                .ForMember(dest => dest.DriverLicenceNumber,
                            opts => opts.MapFrom(src => src.documentNumber))
                .ForMember(dest => dest.CountryCode,
                            opts => opts.MapFrom(src => src.country.countryCode))
                .ForMember(dest => dest.CountryDescription,
                            opts => opts.MapFrom(src => src.country.countryDescription))
                .ForMember(dest => dest.Categories,
                            opts => opts.MapFrom(src => new List<models.Category>
                            {
                                // build a category for the driver licence
                                new models.Category
                                {
                                    Code = src.categoryTypeCode,
                                    StartDate = src.startDate,
                                    EndDate = src.endDate
                                }
                            }))
                ;
        }

        /// <summary>
        /// Mapping for the reverse mapping of the driver licences.
        /// </summary>
        /// <param name="person"></param>
        /// <returns></returns>
        private IEnumerable<DriverLicense> DriverLicenseReverseMap(models.Person person)
        {
            var result = new List<DriverLicense>();

            // nothing to map
            if (person?.DriverLicences == null)
            {
                return result;
            }

            // loop in every driver licence and for each category
            foreach (var licence in person.DriverLicences)
            {
                // try to convert country code
                var countryCode = int.TryParse(licence.CountryCode, System.Globalization.NumberStyles.Integer,
                    System.Globalization.CultureInfo.InvariantCulture, out var number) ? number : (int?)null;

                // build all driver licences to MasterEntity
                foreach (var category in licence.Categories)
                {
                    result.Add(new DriverLicense
                    {
                        categoryTypeCode = category.Code,
                        country = new Country
                        {
                            countryCode = countryCode,
                            countryDescription = licence.CountryDescription,
                            // only send flag if code is filled
                            countryCodeSpecified = countryCode.HasValue
                        },
                        documentNumber = licence.DriverLicenceNumber,
                        startDate = category.StartDate,
                        endDate = category.EndDate,
                        // only send flags if codes are filled
                        startDateSpecified = category.StartDate.HasValue,
                        endDateSpecified = category.EndDate.HasValue
                    });
                }
            }

            return result;
        }
        #endregion

        #region Job mapping
        /// <summary>
        /// Create Job properties Mapping
        /// </summary>
        private void CreateJobMapping()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<Job, models.Job>()
                .ForMember(dest => dest.ProfessionalCode,
                            opts => opts.MapFrom(src => src.professionalCode))
                .ForMember(dest => dest.ProfessionalDescription,
                            opts => opts.MapFrom(src => src.professionalDescription))
                //no mapping for IsPrincipal
                .ForMember(dest => dest.LaborStatusCode,
                            opts => opts.MapFrom(src => src.laborStatusCode))
                .ForMember(dest => dest.LaborStatusDescription,
                            opts => opts.MapFrom(src => src.laborStatusDescription))
                .ForMember(dest => dest.EmployerEntity,
                            opts => opts.MapFrom(src => src.employer))
                .ForMember(dest => dest.StartDate,
                            opts => opts.MapFrom(src => src.startDate))
                .ForMember(dest => dest.EndDate,
                            opts => opts.MapFrom(src => src.endDate))
                .ForMember(dest => dest.ProfessionalLicense,
                            opts => opts.MapFrom(src => src.professionalLicense))

            // mapping from GLOBAL => MASTER
                .ReverseMap()
                // custom reverse mapping
                .ForMember(dest => dest.professionalCode,
                            opts => opts.MapFrom(src => ProfessionalCodeReverseMap(src.ProfessionalCode)))
                // only send flags if codes are filled
                .ForMember(dest => dest.professionalCodeSpecified,
                            opts => opts.MapFrom(src => !string.IsNullOrEmpty(src.ProfessionalCode)))
                .ForMember(dest => dest.startDateSpecified,
                            opts => opts.MapFrom(src => src.StartDate.HasValue))
                .ForMember(dest => dest.endDateSpecified,
                            opts => opts.MapFrom(src => src.EndDate.HasValue))
                ;
        }

        /// <summary>
        /// Transforms the professional code string to numeric
        /// </summary>
        /// <param name="professionalCode">source professional code.</param>
        /// <returns>decimal value if cast possible, otherwise null</returns>
        private static decimal? ProfessionalCodeReverseMap(string professionalCode)
        {
            // try to convert professional code to decimal so it can be sent for MasterEntity
            if (decimal.TryParse(professionalCode, System.Globalization.NumberStyles.Integer,
                System.Globalization.CultureInfo.InvariantCulture, out var profCode))
            {
                return profCode;
            }

            // can't convert to decimal
            return null;
        }
        #endregion

        #region HonoraryTitle mapping
        /// <summary>
        /// Create Honorary Title properties Mapping
        /// </summary>
        private void CreateHonoraryTitleMapping()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<HonoraryTitle, models.HonoraryTitle>()
                .ForMember(dest => dest.TitleCode,
                            opts => opts.MapFrom(src => src.titleCode))
                .ForMember(dest => dest.TitleDescription,
                            opts => opts.MapFrom(src => src.titleDescription))
                .ForMember(dest => dest.StartDate,
                            opts => opts.MapFrom(src => src.startDate))
                .ForMember(dest => dest.EndDate,
                            opts => opts.MapFrom(src => src.endDate))

            // mapping from GLOBAL => MASTER
                .ReverseMap()
                // only send flags if codes are filled
                .ForMember(dest => dest.startDateSpecified,
                            opts => opts.MapFrom(src => src.StartDate.HasValue))
                .ForMember(dest => dest.endDateSpecified,
                            opts => opts.MapFrom(src => src.EndDate.HasValue))
                ;
        }
        #endregion

        #region Person mapping
        /// <summary>
        /// Create Person properties Mapping
        /// </summary>
        private void CreatePersonMapping()
        {
            // mapping from MASTER => GLOBAL
            CreateMap<Person, models.Person>()
                .ForMember(dest => dest.Birthdate,
                            opts => opts.MapFrom(src => src.birthDate))
                .ForMember(dest => dest.Gender,
                            opts => opts.MapFrom(src => src.genderCode))
                .ForMember(dest => dest.MaritalStatus,
                            opts => opts.MapFrom(src => src.maritalStatusCode))
                .ForMember(dest => dest.IsDeceased,
                            opts => opts.MapFrom(src => src.isDeceased ?? false))
                .ForMember(dest => dest.DeceasedDate,
                            opts => opts.MapFrom(src => src.deceasedDate))
                .ForMember(dest => dest.IsSelfEmployee,
                            opts => opts.MapFrom(src => src.isSelfEmployee ?? false))
                .ForMember(dest => dest.HonoraryTitles,
                            opts => opts.MapFrom(src => src.honoraryTitles))
                .ForMember(dest => dest.Jobs,
                            opts => opts.MapFrom(src => src.jobs))
                .ForMember(dest => dest.DriverLicences,
                            opts => opts.MapFrom(src => src.driverLicenses))
                .ForMember(dest => dest.IsEmancipated, opts => opts.MapFrom(src => src.isEmancipated))


            // mapping from GLOBAL => MASTER
                .ReverseMap()

                // custom reverse mapping
                .ForMember(dest => dest.driverLicenses,
                            opts => opts.MapFrom(src => DriverLicenseReverseMap(src)))

                // members that need special mapping in reverse order
                .ForMember(dest => dest.isDeceased,
                            opts => opts.MapFrom(src => src.IsDeceased))
                .ForMember(dest => dest.deceasedDate,
                            opts => opts.MapFrom(src => src.DeceasedDate))
                .ForMember(dest => dest.isSelfEmployee,
                            opts => opts.MapFrom(src => src.IsSelfEmployee))
                // only send flags if codes are filled
                .ForMember(dest => dest.birthDateSpecified,
                            opts => opts.MapFrom(src => src.Birthdate.HasValue))
                .ForMember(dest => dest.isDeceasedSpecified,
                            opts => opts.MapFrom(src => true))
                .ForMember(dest => dest.deceasedDateSpecified,
                            opts => opts.MapFrom(src => src.DeceasedDate.HasValue))
                .ForMember(dest => dest.isSelfEmployeeSpecified,
                            opts => opts.MapFrom(src => true))
                .ForMember(dest => dest.isEmancipatedSpecified,
                            opts => opts.MapFrom(src => src.IsEmancipated.HasValue))
                ;
        }
        #endregion
    }
}

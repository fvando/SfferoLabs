﻿using INS.PT.WebAPI.Models;
using System.Threading.Tasks;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// repository interface for notifications
    /// </summary>
    public interface INotifications : IScopedRepository
    {
        /// <summary>
        /// Method to set notification done in Entity
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="idEntity">entity identifier</param>
        /// <param name="source">source registing notification</param>
        /// <returns></returns>
        Task<bool> SetNotificationDoneAsync(HeaderParameters headerParameters, string idEntity, string source);
    }
}

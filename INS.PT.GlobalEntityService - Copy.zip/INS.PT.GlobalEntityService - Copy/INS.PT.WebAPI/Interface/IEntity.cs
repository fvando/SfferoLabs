﻿using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Elements;
using INS.PT.WebAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// Get entity repository interface.
    /// </summary>
    public interface IEntity : IScopedRepository
    {
        /// <summary>
        /// property to load response headers associated with Entity
        /// </summary>
        IDictionary<string, string> EntityResponseHeaders { get; }

        #region Get methods
        /// <summary>
        /// Method to read information of an entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>null if entity not found. Entity with all information to the entity.</returns>
        Task<Entity> GetEntityAsync(HeaderParameters headerParameters, EntitiesInput parameters);

        /// <summary>
        /// Method to read entity type information.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>null if entity not found. Entity with all information to the entity.</returns>
        Task<Entity.EntityType> GetEntityTypeAsync(HeaderParameters headerParameters, EntitiesInput parameters);

        /// <summary>
        /// Method to read entity list of addresses.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>Empty list if entity not found or address list in Entity.</returns>
        Task<IEnumerable<Address>> GetEntityAddressesAsync(HeaderParameters headerParameters, EntitiesInput parameters);

        /// <summary>
        /// Method to read entity address.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idAddress">parameter to filter the addresses to return.</param>
        /// <returns>null if not found or address in Entity.</returns>
        Task<Address> GetEntityAddressAsync(HeaderParameters headerParameters, EntitiesInput parameters, string idAddress);

        /// <summary>
        /// Method to read entity type information.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>null if entity not found. Entity with all information to the entity.</returns>
        Task<ContactLists> GetEntityContactListsAsync(HeaderParameters headerParameters, EntitiesInput parameters);

        /// <summary>
        /// Method to read entity list of phones.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>Empty list if entity not found or phones list in Entity.</returns>
        Task<IEnumerable<Phone>> GetEntityPhonesAsync(HeaderParameters headerParameters, EntitiesInput parameters);

        /// <summary>
        /// Method to read phone identified.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idPhone">parameter to filter the phones to return.</param>
        /// <returns>null if entity not found or phone in Entity.</returns>
        Task<Phone> GetEntityPhoneAsync(HeaderParameters headerParameters, EntitiesInput parameters, string idPhone);

        /// <summary>
        /// Method to read entity list of emails.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>Empty list if entity not found or email list in Entity.</returns>
        Task<IEnumerable<Email>> GetEntityEmailsAsync(HeaderParameters headerParameters, EntitiesInput parameters);

        /// <summary>
        /// Method to read the email identified.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idEmail">parameter to filter the email to return.</param>
        /// <returns>null if entity not found or email in Entity.</returns>
        Task<Email> GetEntityEmailAsync(HeaderParameters headerParameters, EntitiesInput parameters, int idEmail);

        /// <summary>
        /// Method to read entity list of bank accounts.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>Empty list if entity not found or bank account list in Entity.</returns>
        Task<IEnumerable<BankAccount>> GetEntityBankAccountsAsync(HeaderParameters headerParameters, EntitiesInput parameters);

        /// <summary>
        /// Method to read entity bank account identified.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idBankAccount">parameter to filter the bank account to return.</param>
        /// <returns>null if entity not found or bank account in Entity.</returns>
        Task<BankAccount> GetEntityBankAccountAsync(HeaderParameters headerParameters, EntitiesInput parameters, int idBankAccount);

        /// <summary>
        /// Method to read entity list of documents.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>Empty list if entity not found or documents list in Entity.</returns>
        Task<IEnumerable<Document>> GetEntityDocumentsAsync(HeaderParameters headerParameters, EntitiesInput parameters);

        /// <summary>
        /// Method to read entity document identified.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="documentCode">parameter to filter the document to return.</param>
        /// <param name="idDocument">parameter to filter the documents to return.</param>
        /// <returns>null if entity not found or document in Entity.</returns>
        Task<Document> GetEntityDocumentAsync(HeaderParameters headerParameters, EntitiesInput parameters, string documentCode, string idDocument);

        /// <summary>
        /// Method to read entity list of CAEs.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>Empty list if entity not found or CAE list in Entity.</returns>
        Task<IEnumerable<Cae>> GetEntityCaesAsync(HeaderParameters headerParameters, EntitiesInput parameters);

        /// <summary>
        /// Method to read entity CAE identified.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idCae">parameter to filter the CAEs to return.</param>
        /// <returns>null if entity not found or CAE in Entity.</returns>
        Task<Cae> GetEntityCaeAsync(HeaderParameters headerParameters, EntitiesInput parameters, int idCae);

        /// <summary>
        /// Method to read entity list of affinities.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>Empty list if entity not found or affinities list in Entity.</returns>
        Task<IEnumerable<AffinityRelation>> GetEntityAffinitiesAsync(HeaderParameters headerParameters, EntitiesInput parameters);

        /// <summary>
        /// Method to read entity affinityl.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idAffinity">parameter to filter the affinities to return.</param>
        /// <returns>null if entity not found or affinity in Entity.</returns>
        Task<AffinityRelation> GetEntityAffinityAsync(HeaderParameters headerParameters, EntitiesInput parameters, int idAffinity);

        /// <summary>
        /// Method to read entity marketing information.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>null if entity not found or no information for marketing in Entity.</returns>
        Task<Marketing> GetEntityMarketingAsync(HeaderParameters headerParameters, EntitiesInput parameters);

        #endregion

        #region Update methods
        /// <summary>
        /// Method to create a new entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="newEntity">Data for the creation of a new entity.</param>
        /// <returns>null if entity not created. The data stored for the created entity.</returns>
        Task<Entity> UpdateEntityAsync(HeaderParameters headerParameters, Entity newEntity);

        /// <summary>
        /// Method to update entity type information.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="type">entity type information to update</param>
        /// <returns>null if entity not found. Entity with all information to the entity.</returns>
        Task<Entity.EntityType> UpdateEntityTypeAsync(HeaderParameters headerParameters, EntitiesInput parameters, Entity.EntityType type);

        /// <summary>
        /// Method to update the list of addresses of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="addresses">Addresses that need to be updated.</param>
        /// <returns>Empty list if entity not found or address not found in Entity.</returns>
        Task<IEnumerable<Address>> UpdateEntityAddressesAsync(HeaderParameters headerParameters, EntitiesInput parameters, IEnumerable<Address> addresses);

        /// <summary>
        /// Method to update the list of addresses of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="address">Address that need to be updated.</param>
        /// <returns>null if not found in Entity.</returns>
        Task<Address> UpdateEntityAddressAsync(HeaderParameters headerParameters, EntitiesInput parameters, Address address);

        /// <summary>
        /// Method to update entity contact lists.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="contacts">contact lists to be updated</param>
        /// <returns>null if entity not found. Entity with all information to the entity.</returns>
        Task<ContactLists> UpdateEntityContactListsAsync(HeaderParameters headerParameters, EntitiesInput parameters, ContactLists contacts);

        /// <summary>
        /// Method to update the list of phones of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="phones">Phones that need to be updated.</param>
        /// <returns>Empty list if entity not found or phones list in Entity.</returns>
        Task<IEnumerable<Phone>> UpdateEntityPhonesAsync(HeaderParameters headerParameters, EntitiesInput parameters, IEnumerable<Phone> phones);

        /// <summary>
        /// Method to update the list of phones of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="phone">Phone that need to be updated.</param>
        /// <returns>null if not found in Entity.</returns>
        Task<Phone> UpdateEntityPhoneAsync(HeaderParameters headerParameters, EntitiesInput parameters, Phone phone);

        /// <summary>
        /// Method to update the list of emails of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="emails">Emails that need to be updated.</param>
        /// <returns>Empty list if entity not found or email list in Entity.</returns>
        Task<IEnumerable<Email>> UpdateEntityEmailsAsync(HeaderParameters headerParameters, EntitiesInput parameters, IEnumerable<Email> emails);

        /// <summary>
        /// Method to update the list of emails of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="email">Emails that need to be updated.</param>
        /// <returns>null if not found in Entity.</returns>
        Task<Email> UpdateEntityEmailAsync(HeaderParameters headerParameters, EntitiesInput parameters, Email email);

        /// <summary>
        /// Method to update the list of bank accounts of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="bankAccounts">Bank accounts that need to be updated.</param>
        /// <returns>Empty list if entity not found or bank account list in Entity.</returns>
        Task<IEnumerable<BankAccount>> UpdateEntityBankAccountsAsync(HeaderParameters headerParameters, EntitiesInput parameters, IEnumerable<BankAccount> bankAccounts);

        /// <summary>
        /// Method to update the list of bank accounts of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="bankAccount">Bank account that need to be updated.</param>
        /// <returns>null if not found in Entity.</returns>
        Task<BankAccount> UpdateEntityBankAccountAsync(HeaderParameters headerParameters, EntitiesInput parameters, BankAccount bankAccount);

        /// <summary>
        /// Method to update the list of documents of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="documents">Documents that need to be updated.</param>
        /// <returns>Empty list if entity not found or documents list in Entity.</returns>
        Task<IEnumerable<Document>> UpdateEntityDocumentsAsync(HeaderParameters headerParameters, EntitiesInput parameters, ICollection<Document> documents);

        /// <summary>
        /// Method to update the list of documents of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="document">Document that need to be updated.</param>
        /// <returns>null if not found in Entity.</returns>
        Task<Document> UpdateEntityDocumentAsync(HeaderParameters headerParameters, EntitiesInput parameters, Document document);

        /// <summary>
        /// Method to update the list of CAEs of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="caes">CAEs that need to be updated.</param>
        /// <returns>Empty list if entity not found or CAEs list in Entity.</returns>
        Task<IEnumerable<Cae>> UpdateEntityCaesAsync(HeaderParameters headerParameters, EntitiesInput parameters, IEnumerable<Cae> caes);

        /// <summary>
        /// Method to update the list of CAEs of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="cae">CAE that needs to be updated.</param>
        /// <returns>null if not found in Entity.</returns>
        Task<Cae> UpdateEntityCaeAsync(HeaderParameters headerParameters, EntitiesInput parameters, Cae cae);

        /// <summary>
        /// Method to update the list of affinities of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="affinities">Affinities that need to be updated.</param>
        /// <returns>Empty list if entity not found or affinities list in Entity.</returns>
        Task<IEnumerable<AffinityRelation>> UpdateEntityAffinitiesAsync(HeaderParameters headerParameters, EntitiesInput parameters, IEnumerable<AffinityRelation> affinities);

        /// <summary>
        /// Method to update the list of affinities of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="affinity">Affinities that need to be updated.</param>
        /// <returns>null if not found in Entity.</returns>
        Task<AffinityRelation> UpdateEntityAffinityAsync(HeaderParameters headerParameters, EntitiesInput parameters, AffinityRelation affinity);

        /// <summary>
        /// Updates the entity marketing asynchronous.
        /// </summary>
        /// <param name="headerParameters">The header parameters.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="marketing">The marketing information to update.</param>
        /// <returns>Updated information after update.</returns>
        Task<Marketing> UpdateEntityMarketingAsync(HeaderParameters headerParameters, EntitiesInput parameters, Marketing marketing);

        #endregion

        #region Delete methods
        /// <summary>
        /// Method to delete an entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to define entity to be deleted.</param>
        /// <returns>true if entity deleted.</returns>
        bool DeleteEntity(HeaderParameters headerParameters, EntitiesInput parameters);

        /// <summary>
        /// Method to delete one or more addresses from the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idAddress">parameter to filter the addresses to delete.</param>
        /// <returns>true if address(es) are deleted.</returns>
        bool DeleteEntityAddresses(HeaderParameters headerParameters, EntitiesInput parameters, string idAddress);

        /// <summary>
        /// Method to delete contact lists.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to define entity to be deleted.</param>
        /// <returns>true if entity contact lists are deleted.</returns>
        bool DeleteContactLists(HeaderParameters headerParameters, EntitiesInput parameters);

        /// <summary>
        /// Method to delete one or more phones from the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idPhone">parameter to filter the phone to delete.</param>
        /// <returns>true if phone(s) are deleted.</returns>
        bool DeleteEntityPhones(HeaderParameters headerParameters, EntitiesInput parameters, string idPhone);

        /// <summary>
        /// Method to delete one or more emails from the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idEmail">parameter to filter the addresses to delete.</param>
        /// <returns>true if email(s) are deleted.</returns>
        bool DeleteEntityEmails(HeaderParameters headerParameters, EntitiesInput parameters, int? idEmail);

        /// <summary>
        /// Method to delete one or more bank accounts from the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idBankAccount">parameter to filter the bank account to delete.</param>
        /// <returns>true if account(s) are deleted.</returns>
        bool DeleteEntityBankAccounts(HeaderParameters headerParameters, EntitiesInput parameters, int? idBankAccount);

        /// <summary>
        /// Method to delete one or more documents from the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="documentCode">parameter to filter the document to delete.</param>
        /// <param name="idDocument">parameter to filter the document to delete.</param>
        /// <returns>true if phone(s) are deleted.</returns>
        bool DeleteEntityDocuments(HeaderParameters headerParameters, EntitiesInput parameters, string documentCode, string idDocument);

        /// <summary>
        /// Method to delete one or more CAEs from the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idCae">parameter to filter the CAEs to delete.</param>
        /// <returns>true if CAE(s) are deleted.</returns>
        bool DeleteEntityCaes(HeaderParameters headerParameters, EntitiesInput parameters, int? idCae);

        /// <summary>
        /// Method to delete one or more affinities from the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idAffinity">parameter to filter the affinities to delete.</param>
        /// <returns>true if Affinity(ies) are deleted.</returns>
        bool DeleteEntityAffinities(HeaderParameters headerParameters, EntitiesInput parameters, int? idAffinity);
        #endregion
    }
}

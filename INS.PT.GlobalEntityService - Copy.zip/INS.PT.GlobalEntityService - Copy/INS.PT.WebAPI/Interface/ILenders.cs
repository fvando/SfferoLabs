﻿using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Output;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// Repository interface for creditor entities.
    /// </summary>
    public interface ILenders : IScopedRepository
    {
        /// <summary>
        /// Method to read creditor entities from MasterEntity service.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <returns>list of information found in master entity</returns>
        Task<IEnumerable<LendersOutput>> GetLendersAsync(HeaderParameters headerParameters);
    }
}

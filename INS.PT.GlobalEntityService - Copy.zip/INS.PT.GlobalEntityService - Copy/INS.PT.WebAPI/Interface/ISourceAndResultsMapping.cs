﻿using INS.PT.WebAPI.Helpers;
using INS.PT.WebAPI.Models;

namespace INS.PT.WebAPI.Interface
{
    public interface ISourceAndResultsMapping : IScopedRepository
    {
        /// <summary>
        /// Reads the mappings for the parameters of the request.
        /// </summary>
        /// <param name="headerParameters">validation parameters to define source and system</param>
        /// <param name="operationId">operation being executed</param>
        void ReadSourceAndSctructure(HeaderParameters headerParameters, MdmOperation operationId);

        /// <summary>
        /// Check if the entity struture can be retrived and all their sub strutures.
        /// </summary>
        /// <param name="entityStructure">entity struture to check</param>
        void RemoveUnauthorizedData(IMasterOutputMapping entityStructure);

        /// <summary>
        /// Property with the mapped source.
        /// </summary>
        string IdSource { get; }

        /// <summary>
        /// Property with the mapped system.
        /// </summary>
        string IdSystem { get; }

        /// <summary>
        /// Property with the master to be used.
        /// </summary>
        MdmMasterSource NativeMaster { get; }

        /// <summary>
        /// Property that defines if Aml service needs to be called.
        /// </summary>
        bool NeedsAmlInformation { get; }
    }
}

﻿using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// Crm information repository interface.
    /// </summary>
    public interface ICrmInformation : IScopedRepository
    {
        /// <summary>
        /// Method to read entity and CRM information.
        /// </summary>
        /// <param name="headerParameters">Header parameters.</param>
        /// <param name="parameters">Parameters to get an entity.</param>
        /// <returns>Object with entity information and CRM external information</returns>
        Task<CrmExternalInfoOutput> GetExternalInformationAsync(HeaderParameters headerParameters, EntitiesInput parameters);

        /// <summary>
        /// Method to save information to the Entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters.</param>
        /// <param name="parameters">Entity key and information to save.</param>
        /// <returns>true if information is saved successfully.</returns>
        Task<bool> SetInformationAsync(HeaderParameters headerParameters, CrmExternalInfoInput parameters);
    }
}

﻿using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Elements;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    public interface IGetEntity : IScopedRepository
    {
        /// <summary>
        /// Method to read information of an entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="vatNumber">Input parameters to read the entity.</param>
        /// <returns>null if entity not found. Entity with all information to the entity.</returns>
        Task<Entity> EntityByVatNumberAsync(HeaderParameters headerParameters, string vatNumber);
    }
}

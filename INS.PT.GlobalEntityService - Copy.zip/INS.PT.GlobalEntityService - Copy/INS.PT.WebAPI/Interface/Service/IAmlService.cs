﻿using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Elements;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface.Service
{
    public interface IAmlService : IScopedRepository
    {
        /// <summary>
        /// Method to read the Aml data into the Entity.
        /// </summary>
        /// <param name="headerParameters">header parameters that will be needed to call Aml service.</param>
        /// <param name="idEntity">Entity identifier</param>
        /// <returns>Task object</returns>
        Task GetAmlAsync(HeaderParameters headerParameters, string idEntity);

        /// <summary>
        /// Method to update the Aml data from the entity into the service.
        /// </summary>
        /// <param name="headerParameters">header parameters that will be needed to call Aml service.</param>
        /// <param name="entity">Entity object where to append the information</param>
        /// <returns>true if update runs successfully.</returns>
        Task<bool> SetAmlAsync(HeaderParameters headerParameters, Entity entity);

        /// <summary>
        /// Property to get nationality before update.
        /// </summary>
        Nationality GetPreviousNationality { get; }

        /// <summary>
        /// Mehtod to merge information from an Entity read from AML into a Entity object from a master.
        /// </summary>
        /// <param name="masterEntity">master Entity object</param>
        void MergeAmlToEntity(Entity masterEntity);
    }
}

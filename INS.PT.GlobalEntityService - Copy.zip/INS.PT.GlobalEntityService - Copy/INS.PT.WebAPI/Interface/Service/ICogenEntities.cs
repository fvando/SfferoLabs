﻿using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Elements;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface.Service
{
    public interface ICogenEntities : IScopedRepository
    {
        /// <summary>
        /// Method to read a Entity from Cogen.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>Entity object with information.</returns>
        Task<Entity> GetEntityAsync(HeaderParameters headerParameters, EntitiesInput parameters);

        /// <summary>
        /// Method to search an entity based on the search filters given in the parameters.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Search filters to make the search.</param>
        /// <returns>Matched results.</returns>
        Task<SearchEntityOutput> SearchEntityAsync(HeaderParameters headerParameters, SearchEntityInput parameters);

        /// <summary>
        /// Method to create/update an entity into Cogen service.
        /// </summary>
        /// <param name="headerParameters">header parameters that will be needed to call MasterEntity service.</param>
        /// <param name="actionOnEntity">Planned action to take in entity.</param>
        /// <param name="newEntity">data to be updated into entity.</param>
        /// <returns>Entity object that conatins data after updated.</returns>
        Task<Entity> CreateUpdateEntityAsync(HeaderParameters headerParameters, Helpers.MdmOperation actionOnEntity, Entity newEntity);
    }
}

﻿namespace INS.PT.WebAPI
{
    /// <summary>
    /// Interface to be implemented by the interfaces that need to be loaded in startup
    /// </summary>
    public interface IScopedRepository
    {
        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        bool CallsExternalService { get; }
    }
}

﻿using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// Repository interface for MPOS information.
    /// </summary>
    public interface IMposInformation : IScopedRepository
    {
        /// <summary>
        /// Method to read Mpos information from MasterEntity service.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="idEntityList">list of entiy ids.</param>
        /// <returns>list of information found in master entity</returns>
        Task<IEnumerable<MposInformationOutput>> GetMposInformationAsync(HeaderParameters headerParameters, MposInformationInput idEntityList);
    }
}

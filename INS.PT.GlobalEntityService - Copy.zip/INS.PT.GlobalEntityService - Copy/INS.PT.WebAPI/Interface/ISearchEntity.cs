﻿using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;
using System.Threading.Tasks;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// Search entity repository interface.
    /// </summary>
    public interface ISearchEntity : IScopedRepository
    {
        /// <summary>
        /// Method to search an entity based on the search filters given in the parameters.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Search filters to make the search.</param>
        /// <returns>Matched results.</returns>
        Task<SearchEntityOutput> SearchEntityAsync(HeaderParameters headerParameters, SearchEntityInput parameters);
    }
}

﻿using System.Threading.Tasks;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Elements;

namespace INS.PT.WebAPI.Interface
{
    public interface IMasterService : IScopedRepository
    {
        /// <summary>
        /// Method to read an entity from MasterEntity service.
        /// </summary>
        /// <param name="headerParameters">header parameters that will be needed to call MasterEntity service.</param>
        /// <param name="source">The mapped source to be used to call MasterEntity service.</param>
        /// <param name="parameters">input parameters.</param>
        /// <returns>Entity object that conatins data.</returns>
        Task<Entity> GetEntityAsync(HeaderParameters headerParameters, string source, EntitiesInput parameters);

        /// <summary>
        /// Method to read an entity from MasterEntity service.
        /// </summary>
        /// <param name="headerParameters">header parameters that will be needed to call MasterEntity service.</param>
        /// <param name="source">The mapped source to be used to call MasterEntity service.</param>
        /// <param name="vatNumber">vat number to search.</param>
        /// <returns>Entity object that conatins data.</returns>
        Task<Entity> GetEntityAsync(HeaderParameters headerParameters, string source, string vatNumber);

        /// <summary>
        /// Method to create/update an entity into MasterEntity service.
        /// </summary>
        /// <param name="headerParameters">header parameters that will be needed to call MasterEntity service.</param>
        /// <param name="source">The mapped source to be used to call MasterEntity service.</param>
        /// <param name="actionOnEntity">Planned action to take in entity.</param>
        /// <param name="newEntity">data to be updated into entity.</param>
        /// <returns>Entity object that conatins data after updated.</returns>
        Task<Entity> CreateUpdateEntityAsync(HeaderParameters headerParameters, string source, Helpers.MdmOperation actionOnEntity, Entity newEntity);

        /// <summary>
        /// Method to search an entity into MasterEntity service.
        /// </summary>
        /// <param name="headerParameters">header parameters that will be needed to call MasterEntity service.</param>
        /// <param name="source">The mapped source to be used to call MasterEntity service.</param>
        /// <param name="searchParameters">Search parameters.</param>
        /// <returns>Search results object.</returns>
        Task<Models.Output.SearchEntityOutput> SearchEntityAsync(HeaderParameters headerParameters, string source, SearchEntityInput searchParameters);

        /// <summary>
        /// Property to get nationality before update.
        /// </summary>
        Nationality GetPreviousNationality { get; }
    }
}

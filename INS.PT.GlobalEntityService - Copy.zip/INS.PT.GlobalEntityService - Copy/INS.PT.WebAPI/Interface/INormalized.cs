﻿using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// Normalized re
    /// </summary>
    public interface INormalized : IScopedRepository
    {
        /// <summary>
        /// Gets the a name normalized.
        /// </summary>
        /// <param name="parameters">The name compoments.</param>
        /// <returns>result of the normalization of the name.</returns>
        NormalizedNameOutput GetNormalizedName(NormalizedNameInput parameters);

        /// <summary>
        /// Gets the an address normalized.
        /// </summary>
        /// <param name="parameters">The address compoments.</param>
        /// <returns>result of the normalization of the address</returns>
        NormalizedAddressOutput GetNormalizedAddress(NormalizedAddressInput parameters);
    }
}

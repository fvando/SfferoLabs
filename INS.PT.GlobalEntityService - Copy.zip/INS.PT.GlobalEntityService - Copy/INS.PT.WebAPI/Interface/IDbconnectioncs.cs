﻿// Copyright Ageas 2019 © - Integration Team

using System.Data;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// Interface of a database connection.
    /// </summary>
    public interface IDbconnectioncs
    {
        /// <summary>
        /// Property to retrive a db connection.
        /// </summary>
        IDbConnection Connection { get; }

        /// <summary>
        /// Property to retrive dv connection to LOCAL database.
        /// </summary>
        IDbConnection LocalConnection { get; }
    }
}

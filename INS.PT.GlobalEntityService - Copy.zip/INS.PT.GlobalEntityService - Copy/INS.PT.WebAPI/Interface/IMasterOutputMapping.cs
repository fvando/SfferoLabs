﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// Interface to allow mapping of object with authorization values.
    /// </summary>
    public interface IMasterOutputMapping
    {
        /// <summary>
        /// Structure name to be mapped.
        /// </summary>
        [JsonIgnore]
        [IgnoreDataMember]
        internal string StructureName { get; }

        /// <summary>
        /// Method to clear data from object.
        /// </summary>
        void Clear();

        /// <summary>
        /// Child objects that may also be mapped to authorizations.
        /// </summary>
        [JsonIgnore]
        [IgnoreDataMember]
        internal IEnumerable<IMasterOutputMapping> ChildStrutures { get; }
    }
}

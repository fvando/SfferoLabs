﻿// Copyright Ageas 2019 © - Integration Team

using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using log4net;
using System.Diagnostics;
using System.IO;
using System;

/// <summary>
/// Ins.PT.WebAPI.Middleware
/// </summary>
namespace INS.PT.WebAPI.Middleware
{
    /// <summary>
    /// RequestResponseLoggingMiddleware
    /// </summary>
    public class RequestResponseLoggingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILog _log;

        /// <summary>
        /// RequestResponseLoggingMiddleware
        /// </summary>
        /// <param name="next"></param>
        public RequestResponseLoggingMiddleware(RequestDelegate next) : this(next, LogManager.GetLogger(typeof(LogResponseTimeMiddleWare)))
        { }

        public RequestResponseLoggingMiddleware(RequestDelegate next, ILog log)
        {
            _next = next;
            _log = log ?? throw new ArgumentNullException(nameof(log));
        }

        /// <summary>
        /// Invoke
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InvokeAsync(HttpContext context)
        {
            if (context == null)
            {
                return;
            }

            //Start 
            var stopwatch = new Stopwatch();
            stopwatch.Start();

            //Headers
            var requestHeaders = string.Join("|", context.Request.Headers.Select(x => $"{x.Key}:{x.Value}").OrderBy(x => x));

            //Method
            var Method = $"{context.Request.Method}";
            // Add Method to HttpContext
            context.Items.Add("XMethod", $"{Method}");
            LogicalThreadContext.Properties["XMethod"] = $"{Method}";

            //controller
            var controller = $"{context.Request.Path}";
            // Add Method to HttpContext
            context.Items.Add("XController", $"{controller}");
            LogicalThreadContext.Properties["XController"] = $"{controller}";

            _log.Info($"Begin request");
            _log.Info($"Headers Request: {requestHeaders} ");

            //write body request
            using (var requestBodyStream = new MemoryStream())
            {
                var originalRequestBody = context.Request.Body;

                await context.Request.Body.CopyToAsync(requestBodyStream);
                requestBodyStream.Seek(0, SeekOrigin.Begin);

                var bodyRequest = new StreamReader(requestBodyStream).ReadToEnd();

                // write log 
                _log.Info($"Request Body: {bodyRequest} ");

                requestBodyStream.Seek(0, SeekOrigin.Begin);
                context.Request.Body = requestBodyStream;

                //Continue down the Middleware pipeline, eventually returning to this class
                await _next(context);
                context.Request.Body = originalRequestBody;
            }

            stopwatch.Stop(); //stop measuring
            var result = stopwatch.ElapsedMilliseconds;

            //Headers Response
            var responseHeaders = string.Join("|", context.Response.Headers.Select(x => $"{x.Key}:{x.Value}").OrderBy(x => x));
            _log.Info($"Headers Response: {responseHeaders} ");

            var UrlInvoque = $"{context.Request.Scheme} {context.Request.Host}{controller}{context.Request.QueryString}";
            // write log 
            _log.Info($"Url: {UrlInvoque} ");

            // write log 
            _log.Info($"Response Status: {context.Response.StatusCode} ");

            // write log 
            _log.Info($"Response time: {result}ms");
        }
    }
}

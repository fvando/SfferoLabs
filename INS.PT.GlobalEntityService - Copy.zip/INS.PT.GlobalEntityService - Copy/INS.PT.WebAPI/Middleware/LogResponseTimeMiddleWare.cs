﻿// Copyright Ageas 2019 © - Integration Team

using Microsoft.AspNetCore.Http;
using System.Diagnostics;
using System.Threading.Tasks;
using log4net;
using System;

/// <summary>
/// Ins.PT.WebAPI.Middleware
/// </summary>
namespace INS.PT.WebAPI.Middleware
{
    /// <summary>
    /// LogResponseTimeMiddleWare
    /// </summary>
    public class LogResponseTimeMiddleWare
    {
        private readonly RequestDelegate _next;
        private readonly ILog _log;

        /// <summary>
        /// LogResponseTimeMiddleWare
        /// </summary>
        /// <param name="next"></param>
        public LogResponseTimeMiddleWare(RequestDelegate next) : this(next, LogManager.GetLogger(typeof(LogResponseTimeMiddleWare)))
        { }

        public LogResponseTimeMiddleWare(RequestDelegate next, ILog log)
        {
            _next = next;
            _log = log ?? throw new ArgumentNullException(nameof(log));
        }

        /// <summary>
        /// Invoke
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InvokeAsync(HttpContext context)
        {
            _log.Info($"Begin request");

            var stopwatch = new Stopwatch();
            stopwatch.Start();

            // execute the rest of the pipeline
            await _next(context);

            stopwatch.Stop(); //stop measuring
            var result = stopwatch.ElapsedMilliseconds;

            // write log 
            _log.Info($"Response time: {result} ms");
        }
    }
}

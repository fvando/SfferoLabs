﻿// Copyright Ageas 2019 © - Integration Team

using System;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using log4net;
using System.Linq;

/// <summary>
/// Ins.PT.WebAPI.Middleware
/// </summary>
namespace INS.PT.WebAPI.Middleware
{
    /// <summary>
    /// LogXCorrelationIdMiddleWare
    /// </summary>
    public class LogXCorrelationIdMiddleWare
    {
        private readonly RequestDelegate _next;

        /// <summary>
        /// LogXCorrelationIdMiddleWare
        /// </summary>
        /// <param name="next"></param>
        public LogXCorrelationIdMiddleWare(RequestDelegate next)
        {
            _next = next;
            LogManager.GetLogger(typeof(LogResponseTimeMiddleWare));
        }

        /// <summary>
        /// Invoke
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InvokeAsync (HttpContext context)
        {
            context.Request.Headers.TryGetValue("XCorrelationId", out var correlationIds);

            var correlationId = correlationIds.FirstOrDefault() ?? Guid.NewGuid().ToString("D", System.Globalization.CultureInfo.InvariantCulture);

            CorrelationContext.SetCorrelationId(correlationId);

            // Add XCorrelationId to HttpContext
            context.Items.Add("XCorrelationId", correlationId);
            LogicalThreadContext.Properties["XCorrelationId"] = correlationId;

            // execute the rest of the pipeline
            await _next.Invoke(context);
        }
    }
}

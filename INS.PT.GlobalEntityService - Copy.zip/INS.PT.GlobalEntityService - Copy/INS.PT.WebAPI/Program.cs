﻿// Copyright Ageas 2019 © - Integration Team

using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;

/// <summary>
/// 
/// </summary>
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.CLSCompliant(false)]
namespace INS.PT.WebAPI
{
    /// <summary>
    /// WebAPI
    /// </summary>
    public static class Program
    {
        /// <summary>
        /// Code execution start.
        /// </summary>
        /// <param name="args">arguments to inicialize application.</param>
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args)
                .UseIISIntegration() //IIS Proxy
                .Build()
                .Run();
        }

        /// <summary>
        /// Creates a web host to run the application.
        /// </summary>
        /// <param name="args">arguments to inicialize application.</param>
        /// <returns>web host builder object.</returns>
        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>();
    }
}

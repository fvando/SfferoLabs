﻿using INS.PT.WebAPI.Models.Elements;
using System;
using System.Collections.Generic;
using System.Linq;

namespace INS.PT.WebAPI.Models.Extensions
{
    /// <summary>
    /// EntityExtensions
    /// </summary>
    public static class EntityExtensions
    {
        /// <summary>
        /// search object in entity.
        /// </summary>
        /// <param name="entity">entity to be searched</param>
        /// <param name="idAddress">id to search</param>
        /// <returns>object found or null</returns>
        internal static Address GetAddress(this Entity entity, string idAddress)
        {
            return entity.GetAddresses(idAddress).FirstOrDefault();
        }

        /// <summary>
        /// search object in entity.
        /// </summary>
        /// <param name="entity">entity to be searched</param>
        /// <param name="idAddress">id to search</param>
        /// <returns>list of matches</returns>
        internal static IEnumerable<Address> GetAddresses(this Entity entity, string idAddress)
        {
            return entity.Addresses.Where(a => 
                string.Compare(a.Sequence, idAddress, StringComparison.InvariantCultureIgnoreCase) == 0);
        }

        /// <summary>
        /// search object in entity.
        /// </summary>
        /// <param name="entity">entity to be searched</param>
        /// <param name="idPhone">id to search</param>
        /// <returns>object found or null</returns>
        internal static Phone GetPhone(this Entity entity, string idPhone)
        {
            return entity.GetPhones(idPhone).FirstOrDefault();
        }

        /// <summary>
        /// search object in entity.
        /// </summary>
        /// <param name="entity">entity to be searched</param>
        /// <param name="idPhone">id to search</param>
        /// <returns>list of matches</returns>
        internal static IEnumerable<Phone> GetPhones(this Entity entity, string idPhone)
        {
            return entity.Contacts.Phones.Where(p =>
                string.Compare(p.PhoneIdentifier, idPhone, StringComparison.InvariantCultureIgnoreCase) == 0);
        }

        /// <summary>
        /// search object in entity.
        /// </summary>
        /// <param name="entity">entity to be searched</param>
        /// <param name="idEmail">id to search</param>
        /// <returns>object found or null</returns>
        internal static Email GetEmail(this Entity entity, int idEmail)
        {
            return entity.GetEmails(idEmail).FirstOrDefault();
        }

        /// <summary>
        /// search object in entity.
        /// </summary>
        /// <param name="entity">entity to be searched</param>
        /// <param name="idEmail">id to search</param>
        /// <returns>list of matches</returns>
        internal static IEnumerable<Email> GetEmails(this Entity entity, int idEmail)
        {
            return entity.Contacts.Emails.Where(e => e.EmailIdentifier.HasValue &&
                e.EmailIdentifier == idEmail);
        }

        /// <summary>
        /// search object in entity.
        /// </summary>
        /// <param name="entity">entity to be searched</param>
        /// <param name="idBankAccount">id to search</param>
        /// <returns>object found or null</returns>
        internal static BankAccount GetBankAccount(this Entity entity, int idBankAccount)
        {
            return entity.GetBankAccounts(idBankAccount).FirstOrDefault();
        }

        /// <summary>
        /// search object in entity.
        /// </summary>
        /// <param name="entity">entity to be searched</param>
        /// <param name="idBankAccount">id to search</param>
        /// <returns>list of matches</returns>
        internal static IEnumerable<BankAccount> GetBankAccounts(this Entity entity, int idBankAccount)
        {
            return entity.BankAccounts.Where(b => b.SequenceBankAccountNumber.HasValue &&
                b.SequenceBankAccountNumber == idBankAccount);
        }

        /// <summary>
        /// search object in entity.
        /// </summary>
        /// <param name="entity">entity to be searched</param>
        /// <param name="documentCode">id to search</param>
        /// <param name="idDocument">id to search</param>
        /// <returns>object found or null</returns>
        internal static Document GetDocument(this Entity entity, string documentCode, string idDocument)
        {
            return entity.GetDocuments(documentCode, idDocument).FirstOrDefault();
        }

        /// <summary>
        /// search object in entity.
        /// </summary>
        /// <param name="entity">entity to be searched</param>
        /// <param name="documentCode">id to search</param>
        /// <param name="idDocument">id to search</param>
        /// <returns>list of matches</returns>
        internal static IEnumerable<Document> GetDocuments(this Entity entity, string documentCode, string idDocument)
        {
            return entity.Documents.Where(d =>
                string.Compare(d.DocumentTypeCode, documentCode, StringComparison.InvariantCultureIgnoreCase) == 0
                && string.Compare(d.DocumentNumber, idDocument, StringComparison.InvariantCultureIgnoreCase) == 0);
        }

        /// <summary>
        /// search object in entity.
        /// </summary>
        /// <param name="entity">entity to be searched</param>
        /// <param name="idCae">id to search</param>
        /// <returns>object found or null</returns>
        internal static Cae GetCae(this Entity entity, int idCae)
        {
            return entity.GetCaes(idCae).FirstOrDefault();
        }

        /// <summary>
        /// search object in entity.
        /// </summary>
        /// <param name="entity">entity to be searched</param>
        /// <param name="idCae">id to search</param>
        /// <returns>list of matches</returns>
        internal static IEnumerable<Cae> GetCaes(this Entity entity, int idCae)
        {
            return entity.Caes.Where(c => c.CaeOrderNumber == idCae);
        }

        /// <summary>
        /// search object in entity.
        /// </summary>
        /// <param name="entity">entity to be searched</param>
        /// <param name="idAffinity">id to search</param>
        /// <returns>object found or null</returns>
        internal static AffinityRelation GetAffinity(this Entity entity, int idAffinity)
        {
            return entity.GetAffinities(idAffinity).FirstOrDefault();
        }

        /// <summary>
        /// search object in entity.
        /// </summary>
        /// <param name="entity">entity to be searched</param>
        /// <param name="idAffinity">id to search</param>
        /// <returns>list of matches</returns>
        internal static IEnumerable<AffinityRelation>GetAffinities(this Entity entity, int idAffinity)
        {
            return entity.AffinityRelations.Where(a => a.RelationIdentifier == idAffinity);
        }
    }
}

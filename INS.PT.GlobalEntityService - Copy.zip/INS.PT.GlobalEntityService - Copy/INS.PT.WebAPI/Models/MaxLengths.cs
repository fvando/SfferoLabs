﻿namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// constants with mas lengths
    /// </summary>
    internal static class MaxLengths
    {
        // generic headers
        public const int IdCompanyMaxLength = 20;
        public const int IdNetworkMaxLength = 20;

        // entity object lengths
        public const int VatMaxLength = 12;
        public const int NameMaxLength = 70;
        public const int GenderMaxLength = 1;
        public const int IdEntityMaxLength = 20;

        // profiles
        public const int ProfileIdentifierMaxLength = 20;
        public const int ProfileCodeMaxLength = 8;
        public const int ProfileDescriptionMaxLength = 50;

        // phone object lengths
        public const int PhoneIdentifierMaxLength = 35;
        public const int PhoneTypeMaxLength = 5;
        public const int PhoneTypeDescriptionMaxLength = 50;
        public const int PhoneNumberMaxLength = 15;

        // person object lengths
        public const int MaritalStatusMaxLength = 1;
        public const int PlaceOfBirthMaxLength = 50;

        // organization object lengths
        public const int CompanyNameMaxLength = 50;
        public const int CompanyTypeCodeMaxLength = 1;
        public const int CompanyTypeDescriptionMaxLength = 20;
        public const int CompanyLegalFormMaxLength = 50;
        public const int CompanyWebsiteMaxLength = 80;

        // labor lengths
        public const int LaborStatusCodeMaxLength = 3;
        public const int LaborStatusDescriptionMaxLength = 30;
        // professional lengths
        public const int ProfessionalCodeMaxLength = 5;
        public const int ProfessionalDescriptionMaxLength = 80;
        // employer lengths
        public const int EmployerEntityMaxLength = 19;


        // country lengths
        public const int CountryCodeMaxLength = 3;
        public const int CountryDescriptionMaxLength = 30;
        // Nationality lengths
        public const int NationalityCodeMaxLength = 5;
        public const int NationalityDescriptionMaxLength = 120;

        // title object lengths
        public const int TitleCodeMaxLength = 15;
        public const int TitleDescriptionMaxLength = 80;

        // ExternalReference object lengths
        public const int ExternalReferenceCodeMaxLength = 20;
        public const int ExternalReferenceDescriptionMaxLength = 100;

        // email object lengths
        public const int EmailTypeCodeMaxLength = 5;
        public const int EmailTypeDescriptionMaxLength = 50;
        public const int EmailAddressMaxLength = 50;


        // document object lengths
        public const int DocumentTypeCodeMaxLength = 3;
        public const int DocumentTypeDescriptionMaxLength = 50;
        public const int DocumentNumberMaxLength = 16;


        // crs object lengths
        public const int CrsStatusMaxLength = 15;
        public const int CrsReporterBankMaxLength = 1;
        public const int CrsReporterAgeasMaxLength = 1;
        public const int CrsReportYearMaxLength = 4;
        public const int CrsFiscalAddressMaxLength = 120;
        public const int CrsForeignVatMaxLength = 15;
        public const int CrsVatMotiveMaxLength = 200;
        public const int CrsDataSourceMaxLength = 20;

        // Contact type object lengths
        public const int ContactTypeCodeMaxLength = 5;
        public const int ContactTypeDescriptionMaxLength = 25;
        public const int ContactValueMaxLength = 60;
        public const int ContactPositionMaxLength = 20;
        public const int ContactNameMaxLength = 60;

        // DriverLicense object lengths
        public const int DriverLicenseCategoryCodeMaxLength = 3;
        public const int DriverLicenceNumberMaxLength = 20;

        // cae object lengths
        public const int CaeSectorOfActivityMaxLength = 30;
        public const int CaeDescriptionMaxLength = 160;
        public const int CaeNumberMaxLength = 5;

        // bankaccount object lengths
        public const int BankAccountNumberMaxLength = 30;
        public const int IbanMaxLength = 30;

        // aml object lengths
        public const int AmlConditionTypeMaxLength = 10;
        public const int AmlConditionDescriptionMaxLength = 100;

        // Affinity object lengths
        public const int AffinityIdentifierMaxLength = 20;
        public const int AffinityRelationCodeMaxLength = 2;
        public const int AffinityRelationDescriptionMaxLength = 30;

        // address object lengths
        public const int AddressFormatTypeMaxLength = 1;
        public const int AddressTypeDescriptionMaxLength = 50;
        public const int AddressTypeMaxLength = 2;
        public const int AddressSequenceMaxLength = 10;
        public const int AddressMaxLength = 50;

        // georeference lengths
        public const int GeoreferenceMaxLength = 80;

        // postal code lengths
        public const int PostalCodeMaxLength = 8;
        public const int PostalCodeDescriptionMaxLength = 30;

        // poaddress object lengths
        public const int HouseNumberMaxLength = 7;
        public const int FloorNumberMaxLength = 9;
        public const int DoorNumberMaxLength = 10;
        public const int AddToAddressMaxLength = 50;
        public const int LocalityMaxLength = 50;
        // road lengths
        public const int RoadTypeMaxLength = 25;
        public const int RoadNameMaxLength = 50;

        // pobox object lengths
        public const int PoBoxNumberMaxLength = 5;
        public const int PoBoxOfficeNameMaxLength = 30;
    }
}

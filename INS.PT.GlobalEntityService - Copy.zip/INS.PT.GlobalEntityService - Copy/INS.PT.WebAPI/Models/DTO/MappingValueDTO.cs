﻿using System;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Models.DTO
{
    /// <summary>
    /// MappingValueDTO
    /// </summary>
    [DataContract]
    public class MappingValueDto
    {
        /// <summary>
        /// Source value.
        /// </summary>
        /// <example>Alpha</example>
        [DataMember(Name = "SourceValue", EmitDefaultValue = false)]
        public string SourceValue { get; set; }

        /// <summary>
        /// Destination value.
        /// </summary>
        /// <example>A1000</example>
        [DataMember(Name = "DestinationValue", EmitDefaultValue = false)]
        public string DestinationValue { get; set; }

        /// <summary>
        /// List identifier if associated to one.
        /// </summary>
        /// <example></example>
        [DataMember(Name = "IdDomain", EmitDefaultValue = false)]
        public string IdDomain { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        [DataMember(Name = "StartDate", EmitDefaultValue = false)]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        /// <example></example>
        [DataMember(Name = "EndDate", EmitDefaultValue = false)]
        public DateTime? EndDate { get; set; }
    }
}

﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Input
{
    /// <summary>
    /// Input object to read information to MPOS.
    /// </summary>
    public class MposInformationInput : IValidatableObject
    {
        /// <summary>
        /// List of entity id to get information.
        /// </summary>
        [Required]
        public IEnumerable<string> EntitiesIds { get; set; }

        /// <summary>
        /// Method to implement <seealso cref="IValidatableObject"/> interface.
        /// </summary>
        /// <param name="validationContext">Validation context.</param>
        /// <returns>List of errors found.</returns>
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var errors = new List<ValidationResult>();

            foreach(var idEntity in EntitiesIds)
            {
                // validate if id is null or empty
                if(string.IsNullOrEmpty(idEntity))
                {
                    errors.Add(new ValidationResult($"{nameof(EntitiesIds)} contains at least one null or empty element."));
                    return errors;
                }
                // validate max length of id
                if(idEntity.Length > MaxLengths.IdEntityMaxLength)
                {
                    errors.Add(new ValidationResult($"{nameof(EntitiesIds)} contains element '{idEntity}' with more than max lenght."));
                }
            }

            return errors;
        }
    }
}

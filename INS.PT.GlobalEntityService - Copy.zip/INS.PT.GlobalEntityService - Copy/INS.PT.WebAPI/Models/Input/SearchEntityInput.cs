﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Input
{
    ///<inheritdoc /> 
    /// <summary>
    /// Search entity parameters object.
    /// </summary>
    public class SearchEntityInput : IValidatableObject
    {

        /// <summary>
        /// Vat number to be searched.
        /// </summary>
        /// <example></example>
        [MaxLength(MaxLengths.VatMaxLength)]
        [FromBody]
        public string VatNumber { get; set; }

        /// <summary>
        /// Entity identifier.
        /// </summary>
        /// <example></example>
        [MaxLength(MaxLengths.IdEntityMaxLength)]
        [FromBody]
        public string IdEntity { get; set; }

        /// <summary>
        /// Person name.
        /// </summary>
        /// <example>manuel</example>
        [MaxLength(MaxLengths.NameMaxLength)]
        [FromBody]
        public string Name { get; set; }

        /// <summary>
        /// Phone number.
        /// </summary>
        /// <example></example>
        [MaxLength(MaxLengths.PhoneNumberMaxLength)]
        [FromBody]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Postal Code.
        /// </summary>
        /// <example></example>
        [MaxLength(MaxLengths.PostalCodeMaxLength)]
        [FromBody]
        public string PostalCode { get; set; }

        /// <summary>
        /// Email address to search.
        /// </summary>
        /// <example></example>
        [MaxLength(MaxLengths.EmailAddressMaxLength)]
        [FromBody]
        public string Email { get; set; }

        /// <summary>
        /// Agent number.
        /// </summary>
        /// <example></example>
        [FromBody]
        public string AgentNumber { get; set; }

        /// <summary>
        /// Birthdate.
        /// </summary>
        /// <example></example>
        public DateTime? Birthdate { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var errors = new List<ValidationResult>();

            // at least one search filter must be filled
            if (string.IsNullOrEmpty(VatNumber + IdEntity + Name + PostalCode + PhoneNumber
                + Email + AgentNumber) && !Birthdate.HasValue)
            {
                errors.Add(new ValidationResult("All filters are empty."));
            }

            return errors;
        }
    }
}

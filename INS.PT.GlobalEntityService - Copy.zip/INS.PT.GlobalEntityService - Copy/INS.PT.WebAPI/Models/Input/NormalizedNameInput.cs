﻿using INS.PT.WebAPI.IdTranslates;
using System;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Input
{
    /// <summary>
    /// Input parameters to normalize a name.
    /// </summary>
    public class NormalizedNameInput
    {
        /// <summary>
        /// Name.
        /// </summary>
        /// <example>anTÓnIo MaNUel santos</example>
        [MaxLength(MaxLengths.NameMaxLength)]
        [Required]
        public string Name { get; set; }

        /// <summary>
        /// Birthdate.
        /// </summary>
        /// <example>2019-06-14T10:13:27.475Z</example>
        public DateTime? Birthdate { get; set; }

        /// <summary>
        /// Gender.
        /// </summary>
        /// <example>H</example>
        [MaxLength(1)]
        [TranslateCode(IdList = "RDM001", ToNative = true)]
        public string Gender { get; set; }
    }
}

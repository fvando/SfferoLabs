﻿using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Input
{
    /// <summary>
    /// Parameters to retrive a entity.
    /// </summary>
    public class EntitiesInput
    {
        /// <summary>
        /// Entity identity.
        /// </summary>
        /// <example>10592272</example>
        [Required]
        [MaxLength(MaxLengths.IdEntityMaxLength)]
        public string IdEntity { get; set; }
    }
}

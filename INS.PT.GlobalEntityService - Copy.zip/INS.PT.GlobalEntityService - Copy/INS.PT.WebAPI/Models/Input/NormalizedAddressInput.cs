﻿using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Input
{
    public class NormalizedAddressInput
    {
        /// <summary>
        /// Road type.
        /// </summary>
        /// <example>rua</example>
        [Required]
        [MaxLength(MaxLengths.RoadTypeMaxLength)]
        public string RoadType { get; set; }

        /// <summary>
        /// Road name.
        /// </summary>
        /// <example>25 de Abril</example>
        [Required]
        [MaxLength(MaxLengths.RoadNameMaxLength)]
        public string RoadName { get; set; }

        /// <summary>
        /// House number.
        /// </summary>
        /// <example>3</example>
        [MaxLength(MaxLengths.HouseNumberMaxLength)]
        public string HouseNumber { get; set; }

        /// <summary>
        /// Floor number.
        /// </summary>
        /// <example>F</example>
        [MaxLength(MaxLengths.FloorNumberMaxLength)]
        public string FloorNumber { get; set; }

        /// <summary>
        /// Door number.
        /// </summary>
        /// <example>23</example>
        [MaxLength(MaxLengths.DoorNumberMaxLength)]
        public string DoorNumber { get; set; }

        /// <summary>
        /// Add to address.
        /// </summary>
        /// <example>Bairro de Abril</example>
        [MaxLength(MaxLengths.AddToAddressMaxLength)]
        public string AddToAddress { get; set; }

        /// <summary>
        /// Locality.
        /// </summary>
        /// <example>torres vedras</example>
        [MaxLength(MaxLengths.LocalityMaxLength)]
        public string Locality { get; set; }

        /// <summary>
        /// Postal code.
        /// </summary>
        /// <example>2560-253</example>
        [Required]
        [MaxLength(MaxLengths.PostalCodeMaxLength)]
        public string PostalCode { get; set; }

        /// <summary>
        /// Postal code description.
        /// </summary>
        /// <example>Torres vedras</example>
        [MaxLength(MaxLengths.PostalCodeDescriptionMaxLength)]
        public string PostalCodeDescription { get; set; }
    }
}

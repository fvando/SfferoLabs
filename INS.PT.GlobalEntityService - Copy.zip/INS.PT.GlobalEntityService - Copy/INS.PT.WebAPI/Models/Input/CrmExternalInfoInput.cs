﻿using System;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Input
{
    public class CrmExternalInfoInput
    {
        /// <summary>
        /// Entity identity.
        /// </summary>
        /// <example>12889884</example>
        [Required]
        [MaxLength(MaxLengths.IdEntityMaxLength)]
        public string IdEntity { get; set; }

        /// <summary>
        /// Order
        /// </summary>
        /// <example>4</example>
        public int? Order { get; set; }

        /// <summary>
        /// Product description.
        /// </summary>
        /// <example>Logo Carro</example>
        [Required]
        public string ProductDescription { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        /// <example>2019-11-24</example>
        public DateTime? EndDate { get; set; }
    }
}

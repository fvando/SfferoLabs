﻿namespace INS.PT.WebAPI.Models.Input
{
    public class EntityNotificationInput : EntitiesInput
    {
        /// <summary>
        /// Source that is confirming notification.
        /// </summary>
        /// <example>AIA</example>
        public string Source { get; set; }
    }
}

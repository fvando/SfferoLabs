﻿using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// Base class to use in all input parameter objects.
    /// </summary>
    public sealed class HeaderParameters : IValidatableObject
    {
        public static readonly string ListIdForCompanies = "RDM002";
        private const int HeaderParametersLength = 20;

        private readonly IdTranslates.CodesMapping codesMapping;

        public HeaderParameters(IdTranslates.CodesMapping codesMapping)
        {
            this.codesMapping = codesMapping
                ?? throw new ArgumentNullException(nameof(codesMapping));
        }


        /// <summary>
        /// Company id.
        /// </summary>
        [Required]
        [MaxLength(HeaderParametersLength)]
        [FromHeader]
        public string IdCompany { get; set; }

        /// <summary>
        /// Network id.
        /// </summary>
        [Required]
        [MaxLength(HeaderParametersLength)]
        [FromHeader]
        public string IdNetwork { get; set; }

        /// <summary>
        /// bsSolution.
        /// </summary>
        [Required]
        [FromHeader]
        public string BsSolution { get; set; }

        /// <summary>
        /// bsUser.
        /// </summary>
        [Required]
        [FromHeader]
        public string BsUser { get; set; }

        /// <summary>
        /// Method to execute custom validations on object.
        /// </summary>
        /// <param name="validationContext">validation context</param>
        /// <returns>enumerable with errors found.</returns>
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var errors = new List<ValidationResult>();
            if (!codesMapping.TryGetElementFromIdElement(ListIdForCompanies, IdCompany, out _))
            {
                errors.Add(new ValidationResult($"'{IdCompany}' is not a valid value for {nameof(IdCompany)}."));
                errors.Add(new ValidationResult($"For valid IdDompany values please refer to RDM list => {ListIdForCompanies}!"));
            }

            return errors;
        }

        /// <summary>
        /// Method to add default header parameters to oracle package.
        /// </summary>
        /// <param name="oracleDynamicParameters">collection of oracle parameters to add</param>
        internal void AddToParameters(OracleDynamicParameters oracleDynamicParameters)
        {
            oracleDynamicParameters.Add("p_idcompany", OracleDbType.Varchar2, direction: ParameterDirection.Input, value: IdCompany);
            oracleDynamicParameters.Add("p_idnetwork", OracleDbType.Varchar2, direction: ParameterDirection.Input, value: IdNetwork);
            oracleDynamicParameters.Add("p_axisvalue", OracleDbType.Varchar2, direction: ParameterDirection.Input, value: BsSolution);
            oracleDynamicParameters.Add("p_axisuser", OracleDbType.Varchar2, direction: ParameterDirection.Input, value:
                string.Compare(BsSolution, "dummy", System.StringComparison.InvariantCultureIgnoreCase) == 0
                    ? BsSolution.ToUpperInvariant()
                    : BsUser
                );
        }
    }
}

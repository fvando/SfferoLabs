﻿using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Output
{
    public class LendersOutput
    {
        /// <summary>
        /// Entity identifier.
        /// </summary>
        /// <example>10468475</example>
        [MaxLength(MaxLengths.IdEntityMaxLength)]
        public string IdEntity { get; set; }

        /// <summary>
        /// Vat number.
        /// </summary>
        /// <example>176123123</example>
        [MaxLength(MaxLengths.VatMaxLength)]
        public string VatNumber { get; set; }

        /// <summary>
        /// Name.
        /// </summary>
        /// <example>Joana Gomes</example>
        [MaxLength(MaxLengths.NameMaxLength)]
        public string Name { get; set; }

        /// <summary>
        /// Address.
        /// </summary>
        /// <example>Rua 25 de Abril, 23-3 5ºF</example>
        [MaxLength(MaxLengths.AddressMaxLength)]
        public string Address { get; set; }
    }
}

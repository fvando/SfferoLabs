﻿using INS.PT.WebAPI.IdTranslates;
using INS.PT.WebAPI.Models.Elements;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.Output
{
    /// <summary>
    /// Result object with entities found.
    /// </summary>
    public class SearchEntityOutput : ITranslateCodes
    {
        /// <summary>
        /// List of entities found.
        /// </summary>
        public ICollection<SimpleEntity> MatchedEntities { get; set; } = new List<SimpleEntity>();

        /// <summary>
        /// method that executes custom translation on object
        /// </summary>
        /// <param name="codesMapping">object with codes mapping</param>
        /// <param name="idCompany">company identifier</param>
        /// <param name="overrideToNativeAttribute">translation direction to use, or null to assume property default</param>
        public void Translate(CodesMapping codesMapping, string idCompany, bool? overrideToNativeAttribute)
        {
            // no translation to execute
            if (codesMapping == null)
            {
                return;
            }

            foreach (var entity in MatchedEntities)
            {

                // translate addresses collection
                if (entity.Addresses != null)
                {
                    foreach (var address in entity.Addresses)
                    {
                        codesMapping.Translate(address, idCompany, overrideToNativeAttribute);
                    }
                }

                // translate caes collection
                if (entity.Caes != null)
                {
                    foreach (var cae in entity.Caes)
                    {
                        codesMapping.Translate(cae, idCompany, overrideToNativeAttribute);
                    }
                }
            }
        }
    }
}

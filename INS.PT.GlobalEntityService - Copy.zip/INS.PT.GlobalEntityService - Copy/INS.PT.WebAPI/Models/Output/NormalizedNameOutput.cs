﻿using Ins.PT.WebAPI;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models.Output
{
    /// <summary>
    /// Normalized result.
    /// </summary>
    public class NormalizedNameOutput : IMapped
    {
        public void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(NormalizedNameOutput));
        }

        /// <summary>
        /// Normalized first name.
        /// </summary>
        /// <example>António</example>
        [Column(":NOME")]
        public string FirstName { get; set; }

        /// <summary>
        /// Normalized middle name.
        /// </summary>
        /// <example>Manuel</example>
        [Column(":AP1")]
        public string MiddleName { get; set; }

        /// <summary>
        /// Normalized last name.
        /// </summary>
        /// <example>Santos</example>
        [Column(":AP2")]
        public string LastName { get; set; }

        /// <summary>
        /// Normalized full name.
        /// </summary>
        /// <example>António Manuel Santos</example>
        public string FullName
        {
            get
            {
                return FirstName
                    + (string.IsNullOrEmpty(MiddleName) ? "" : $" {MiddleName}")
                    + (string.IsNullOrEmpty(LastName) ? "" : $" {LastName}");
            }
        }

        /// <summary>
        /// Flag indicating if input got normalized.
        /// </summary>
        /// <example>true</example>
        public bool IsNormalized { get; set; }

        /// <summary>
        /// Error code if any is returned.
        /// </summary>
        /// <example>0</example>
        public int ErrorCode { get; set; }

        /// <summary>
        /// Error message of normalization process.
        /// </summary>
        /// <example></example>
        public string ErrorMessage { get; set; }
    }
}

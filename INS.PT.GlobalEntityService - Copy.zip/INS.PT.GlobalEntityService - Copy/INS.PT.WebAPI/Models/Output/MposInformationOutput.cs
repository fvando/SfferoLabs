﻿using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Output
{
    public class MposInformationOutput
    {
        /// <summary>
        /// Entity id.
        /// </summary>
        /// <example>10468475</example>
        [MaxLength(MaxLengths.IdEntityMaxLength)]
        public string IdEntity { get; set; }

        /// <summary>
        /// Name.
        /// </summary>
        /// <example>Joana Gomes</example>
        [MaxLength(MaxLengths.NameMaxLength)]
        public string Name { get; set; }

        /// <summary>
        /// Vat number.
        /// </summary>
        /// <example>176123123</example>
        [MaxLength(MaxLengths.VatMaxLength)]
        public string VatNumber { get; set; }

        /// <summary>
        /// Address.
        /// </summary>
        /// <example>Rua 25 de Abril, 23-3 5ºF</example>
        [MaxLength(MaxLengths.AddressMaxLength)]
        public string Address { get; set; }

        /// <summary>
        /// Postal code.
        /// </summary>
        /// <example>2590-100</example>
        [MaxLength(MaxLengths.PostalCodeMaxLength)]
        public string PostalCode { get; set; }

        /// <summary>
        /// Georeference.
        /// </summary>
        /// <example>123.22;43.21</example>
        [MaxLength(MaxLengths.GeoreferenceMaxLength)]
        public string Georeference { get; set; }

        /// <summary>
        /// Phone number.
        /// </summary>
        /// <example>921345890</example>
        [MaxLength(MaxLengths.PhoneNumberMaxLength)]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Email address.
        /// </summary>
        /// <example>ruijorge.silva.externo@ageas.pt</example>
        [MaxLength(MaxLengths.EmailAddressMaxLength)]
        [EmailAddress]
        public string EmailAddress { get; set; }
    }
}

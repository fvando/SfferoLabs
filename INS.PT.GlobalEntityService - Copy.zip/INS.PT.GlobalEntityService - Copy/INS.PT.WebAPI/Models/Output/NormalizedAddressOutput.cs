﻿namespace INS.PT.WebAPI.Models.Output
{
    public class NormalizedAddressOutput
    {
        /// <summary>
        /// Road type.
        /// </summary>
        /// <example>RUA</example>
        public string RoadType { get; set; }

        /// <summary>
        /// Road name.
        /// </summary>
        /// <example>25 de Abril</example>
        public string RoadName { get; set; }

        /// <summary>
        /// House number.
        /// </summary>
        /// <example>3</example>
        public string HouseNumber { get; set; }

        /// <summary>
        /// Floor number.
        /// </summary>
        /// <example>5ºF</example>
        public string FloorNumber { get; set; }

        /// <summary>
        /// Door number.
        /// </summary>
        /// <example>23</example>
        public string DoorNumber { get; set; }

        /// <summary>
        /// Add to address.
        /// </summary>
        /// <example>Bairro de Abril</example>
        public string AddToAddress { get; set; }

        /// <summary>
        /// Locality.
        /// </summary>
        /// <example>Manteigas</example>
        public string Locality { get; set; }

        /// <summary>
        /// Postal code.
        /// </summary>
        /// <example>2590</example>
        public string PostalCode { get; set; }

        /// <summary>
        /// Postal code description.
        /// </summary>
        /// <example>Torres Vedras</example>
        public string PostalCodeDescription { get; set; }

        /// <summary>
        /// Flag indicating if input got normalized.
        /// </summary>
        /// <example>true</example>
        public bool IsNormalized { get; set; }

    }
}

﻿using INS.PT.WebAPI.IdTranslates;
using INS.PT.WebAPI.Models.Elements;
using INS.PT.WebAPI.Models.Elements.Crm;

namespace INS.PT.WebAPI.Models.Output
{
    public class CrmExternalInfoOutput : ITranslateCodes
    {
        /// <summary>
        /// Entity information.
        /// </summary>
        public Entity Entity { get; set; }

        /// <summary>
        /// External information in CRM.
        /// </summary>
        public ExternalInfo CrmExternalInformation { get; set; }


        /// <summary>
        /// method that executes custom translation on object
        /// </summary>
        /// <param name="codesMapping">object with codes mapping</param>
        /// <param name="idCompany">company identifier</param>
        /// <param name="overrideToNativeAttribute">translation direction to use, or null to assume property default</param>
        public void Translate(CodesMapping codesMapping, string idCompany, bool? overrideToNativeAttribute)
        {
            // no translation to execute
            if (codesMapping == null)
            {
                return;
            }

            // translate simple properties
            codesMapping.Translate(this, idCompany, overrideToNativeAttribute);
        }
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    public class Contact
    {
        /// <summary>
        /// Contact type code.
        /// </summary>
        /// <example>2</example>
        [MaxLength(MaxLengths.ContactTypeCodeMaxLength)]
        public string ContactTypeCode { get; set; }

        /// <summary>
        /// Contact type description.
        /// </summary>
        /// <example>Email Profissional</example>
        [MaxLength(MaxLengths.ContactTypeDescriptionMaxLength)]
        public string ContactTypeDescription { get; set; }

        /// <summary>
        /// Contact value.
        /// </summary>
        /// <example>ruijorge.silva.externo@ageas.pt</example>
        [MaxLength(MaxLengths.ContactValueMaxLength)]
        public string Value { get; set; }
    }
}

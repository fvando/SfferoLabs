﻿using INS.PT.WebAPI.IdTranslates;
using System;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    public class Category
    {
        /// <summary>
        /// Category code.
        /// </summary>
        /// <example>A</example>
        [MaxLength(MaxLengths.DriverLicenseCategoryCodeMaxLength)]
        [TranslateCode(IdList = "DC012", DescriptionField = "Description")]
        public string Code { get; set; }

        /// <summary>
        /// Description.
        /// </summary>
        /// <example>Motociclos </example>
        public string Description { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        /// <example>2019-05-02T14:13:27.475Z</example>
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        /// <example>2019-06-14T10:13:27.475Z</example>
        public DateTime? EndDate { get; set; }
    }
}

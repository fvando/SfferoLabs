﻿using INS.PT.WebAPI.Helpers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.IdTranslates;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// Person object.
    /// </summary>
    public class Person : IMasterOutputMapping, ITranslateCodes, IValidatableObject
    {
        /// <summary>
        /// Name.
        /// </summary>
        /// <example>Joana Gomes</example>
        [MaxLength(MaxLengths.NameMaxLength)]
        public string Name { get; set; }

        /// <summary>
        /// Birthdate.
        /// </summary>
        /// <example>2019-06-14T10:13:27.475Z</example>
        public DateTime? Birthdate { get; set; }

        /// <summary>
        /// Gender.
        /// </summary>
        /// <example>M</example>
        [MaxLength(MaxLengths.GenderMaxLength)]
        [TranslateCode(IdList = "RDM001", DescriptionField = "GenderDescription")]
        public string Gender { get; set; }

        /// <summary>
        /// Gender description.
        /// </summary>
        /// <example>Male</example>
        public string GenderDescription { get; set; }

        /// <summary>
        /// Marital status.
        /// </summary>
        /// <example>V</example>
        [MaxLength(MaxLengths.MaritalStatusMaxLength)]
        [TranslateCode(IdList = "DC008", DescriptionField = "MaritalStatusDescription")]
        public string MaritalStatus { get; set; }

        /// <summary>
        /// Marital status description.
        /// </summary>
        /// <example>Viúvo/a</example>
        public string MaritalStatusDescription { get; set; }

        /// <summary>
        /// Flag indicating if is deceased.
        /// </summary>
        /// <example>false</example>
        public bool IsDeceased { get; set; }

        /// <summary>
        /// Date of death.
        /// </summary>
        public DateTime? DeceasedDate { get; set; }

        /// <summary>
        /// Flag if person is self employed.
        /// </summary>
        /// <example>false</example>
        public bool IsSelfEmployee { get; set; }

        /// <summary>
        /// Place of birth.
        /// </summary>
        /// <example>Lisboa</example>
        [MaxLength(MaxLengths.PlaceOfBirthMaxLength)]
        public string PlaceOfBirth { get; set; }

        /// <summary>
        /// List of nationalities.
        /// </summary>
        public ICollection<Nationality> Nationalities { get; set; }

        /// <summary>
        /// List of titles.
        /// </summary>
        public IEnumerable<HonoraryTitle> HonoraryTitles { get; set; }

        /// <summary>
        /// List of jobs.
        /// </summary>
        public IEnumerable<Job> Jobs { get; set; }

        /// <summary>
        /// List of driver licences.
        /// </summary>
        public IEnumerable<DriverLicence> DriverLicences { get; set; }

        /// <summary>
        /// Gets or sets the deficiency level of the person.
        /// </summary>
        /// <example>60</example>
        public int? Deficiency { get; set; }

        /// <summary>
        /// Flag the indicates that person is emancipated.
        /// </summary>
        public bool? IsEmancipated { get; set; }

        #region IMasterOutputMapping implementation
        /// <summary>
        /// mapped name in MDM configuration
        /// </summary>
        [IgnoreDataMember]
        [JsonIgnore]
        string IMasterOutputMapping.StructureName => StructureName;

        /// <summary>
        /// mapped name in MDM configuration
        /// </summary>
        protected static string StructureName => "PERSON";

        /// <summary>
        /// child structures
        /// </summary>
        [IgnoreDataMember]
        [JsonIgnore]
        IEnumerable<IMasterOutputMapping> IMasterOutputMapping.ChildStrutures => ChildStrutures;

        /// <summary>
        /// child structures
        /// </summary>
        protected IEnumerable<IMasterOutputMapping> ChildStrutures =>
            new List<IMasterOutputMapping>
            {
                new MasterOutputCollectionMap("NATIONALITIES", () => { Nationalities = null; }),
                new MasterOutputCollectionMap("HONORARYTITLES", () => { HonoraryTitles = null; }),
                new MasterOutputCollectionMap("JOBS", () => { Jobs = null; }),
                new MasterOutputCollectionMap("DRIVERLICENCES", () => { DriverLicences = null; })
            };

        /// <summary>
        /// Method to clear information of this structure
        /// </summary>
        public void Clear()
        {
            Name = null;
            Birthdate = null;
            Gender = null;
            MaritalStatus = null;
            IsDeceased = false;
            DeceasedDate = null;
            IsSelfEmployee = false;
            PlaceOfBirth = null;
            Nationalities = null;
            HonoraryTitles = null;
            Jobs = null;
            DriverLicences = null;
        }
        #endregion

        /// <summary>
        /// method that executes custom translation on object
        /// </summary>
        /// <param name="codesMapping">object with codes mapping</param>
        /// <param name="idCompany">company identifier</param>
        /// <param name="overrideToNativeAttribute">translation direction to use, or null to assume property default</param>
        public void Translate(CodesMapping codesMapping, string idCompany, bool? overrideToNativeAttribute)
        {
            // no translation to execute
            if (codesMapping == null)
            {
                return;
            }

            // translate simple properties
            codesMapping.Translate(this, idCompany, overrideToNativeAttribute);

            // translate honorary titles collection
            if (HonoraryTitles != null)
            {
                foreach (var title in HonoraryTitles)
                {
                    codesMapping.Translate(title, idCompany, overrideToNativeAttribute);
                }
            }

            // transform nationalities collection
            if (Nationalities != null)
            {
                foreach (var nationality in Nationalities)
                {
                    codesMapping.Translate(nationality, idCompany, overrideToNativeAttribute);
                }
            }

            // transform driver licences collection
            if (DriverLicences != null)
            {
                foreach (var licence in DriverLicences)
                {
                    codesMapping.Translate(licence, idCompany, overrideToNativeAttribute);
                }
            }

            // transform jobs collection
            if (Jobs != null)
            {
                foreach (var job in Jobs)
                {
                    codesMapping.Translate(job, idCompany, overrideToNativeAttribute);
                }
            }
        }


        /// <summary>
        /// Method to execute custom validations on object.
        /// </summary>
        /// <param name="validationContext">validation context</param>
        /// <returns>enumerable with errors found.</returns>
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var errors = new List<ValidationResult>();

            ValidateNationalities(Nationalities, errors);

            return errors;
        }

        public static void ValidateNationalities(IEnumerable<Nationality> nationalities, ICollection<ValidationResult> errors)
        {
            // if nationalities are present, validate them
            if (nationalities != null)
            {
                // check for duplicates values
                foreach (var duplicatedNationality in nationalities.GroupBy(n => n.NationalityCode).Where(g => g.Count() > 1))
                {
                    errors?.Add(new ValidationResult($"The {nameof(Nationality)} '{duplicatedNationality.Key}' is duplicated!"));
                }
            }
        }
    }
}

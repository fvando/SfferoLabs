﻿using INS.PT.WebAPI.Helpers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.IdTranslates;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// Organization object.
    /// </summary>
    public class Organization : IMasterOutputMapping, ITranslateCodes
    {
        /// <summary>
        /// Name.
        /// </summary>
        /// <example>Empresa de teste</example>
        [MaxLength(MaxLengths.CompanyNameMaxLength)]
        public string CompanyName { get; set; }

        /// <summary>
        /// Date company has founded.
        /// </summary>
        /// <example>2019-06-14T10:13:27.475Z</example>
        public DateTime? FoundingDate { get; set; }

        /// <summary>
        /// Constitution country code.
        /// </summary>
        /// <example>1</example>
        [MaxLength(MaxLengths.CountryCodeMaxLength)]
        [TranslateCode(IdList = "DC004", DescriptionField = "ConstitutionCountryDescription")]
        public string ConstitutionCountryCode { get; set; }

        /// <summary>
        /// Constitution country.
        /// </summary>
        /// <example>Portugal</example>
        [MaxLength(MaxLengths.CountryDescriptionMaxLength)]
        public string ConstitutionCountryDescription { get; set; }

        /// <summary>
        /// Total employees.
        /// </summary>
        /// <example>1234</example>
        public decimal? TotalEmployees { get; set; }

        /// <summary>
        /// Gross annual revenue.
        /// </summary>
        /// <example>123123123</example>
        public decimal? GrossAnnualRevenue { get; set; }

        /// <summary>
        /// Wages amount.
        /// </summary>
        /// <example>2000000</example>
        public decimal? WagesAmount { get; set; }

        /// <summary>
        /// Equity capital.
        /// </summary>
        /// <example>5000000</example>
        public decimal? EquityCapital { get; set; }

        /// <summary>
        /// Company type code.
        /// </summary>
        /// <example>G</example>
        [MaxLength(MaxLengths.CompanyTypeCodeMaxLength)]
        [TranslateCode(IdList = "DC005", DescriptionField = "CompanyTypeDescription")]
        public string CompanyTypeCode { get; set; }

        /// <summary>
        /// Company type.
        /// </summary>
        /// <example>European group</example>
        [MaxLength(MaxLengths.CompanyTypeDescriptionMaxLength)]
        public string CompanyTypeDescription { get; set; }

        /// <summary>
        /// Legal form.
        /// </summary>
        /// <example>Lda.</example>
        [MaxLength(MaxLengths.CompanyLegalFormMaxLength)]
        public string LegalForm { get; set; }

        /// <summary>
        /// Website.
        /// </summary>
        /// <example>http://www.ageas.com</example>
        [MaxLength(MaxLengths.CompanyWebsiteMaxLength)]
        public string Website { get; set; }

        /// <summary>
        /// List of contact for the entity.
        /// </summary>
        public IEnumerable<OrganizationContact> OrganizationContactPoints { get; set; }

        /// <summary>
        /// Flag to indicate if organization is a public entity.
        /// </summary>
        /// <example>true</example>
        public bool? PublicEntity { get; set; }

        #region IMasterOutputMapping implementation
        /// <summary>
        /// mapped name in MDM configuration
        /// </summary>
        [IgnoreDataMember]
        [JsonIgnore]
        string IMasterOutputMapping.StructureName => StructureName;

        /// <summary>
        /// mapped name in MDM configuration
        /// </summary>
        protected static string StructureName => "ORGANIZATION";

        /// <summary>
        /// child structures
        /// </summary>
        [IgnoreDataMember]
        [JsonIgnore]
        IEnumerable<IMasterOutputMapping> IMasterOutputMapping.ChildStrutures => ChildStrutures;

        /// <summary>
        /// child structures
        /// </summary>
        protected IEnumerable<IMasterOutputMapping> ChildStrutures =>
            new List<IMasterOutputMapping>
            {
                new MasterOutputCollectionMap("ORGANIZATIONCONTACTPOINTS", () => { OrganizationContactPoints = null; })
            };

        /// <summary>
        /// Method to clear information of this structure
        /// </summary>
        public void Clear()
        {
            CompanyName = null;
            FoundingDate = null;
            ConstitutionCountryCode = null;
            ConstitutionCountryDescription = null;
            TotalEmployees = null;
            GrossAnnualRevenue = null;
            WagesAmount = null;
            EquityCapital = null;
            CompanyTypeCode = null;
            CompanyTypeDescription = null;
            LegalForm = null;
            Website = null;
            OrganizationContactPoints = null;
        }
        #endregion

        /// <summary>
        /// method that executes custom translation on object
        /// </summary>
        /// <param name="codesMapping">object with codes mapping</param>
        /// <param name="idCompany">company identifier</param>
        /// <param name="overrideToNativeAttribute">translation direction to use, or null to assume property default</param>
        public void Translate(CodesMapping codesMapping, string idCompany, bool? overrideToNativeAttribute)
        {
            // no translation to execute
            if (codesMapping == null)
            {
                return;
            }

            // translate simple properties
            codesMapping.Translate(this, idCompany, overrideToNativeAttribute);
        }
    }
}

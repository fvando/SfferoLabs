﻿using INS.PT.WebAPI.IdTranslates;
using System;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// Honorary title object.
    /// </summary>
    public class HonoraryTitle
    {

        /// <summary>
        /// Code.
        /// </summary>
        /// <example>DR.</example>
        [MaxLength(MaxLengths.TitleCodeMaxLength)]
        [TranslateCode(IdList = "DC002", DescriptionField = "TitleDescription")]
        public string TitleCode { get; set; }

        /// <summary>
        /// Description.
        /// </summary>
        /// <example>Senhor</example>
        [MaxLength(MaxLengths.TitleDescriptionMaxLength)]
        public string TitleDescription { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        /// <example>2019-06-14T10:13:27.475Z</example>
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        public DateTime? EndDate { get; set; }
    }
}

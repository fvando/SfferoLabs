﻿using INS.PT.WebAPI.IdTranslates;
using System;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// Job object.
    /// </summary>
    public class Job
    {
        /// <summary>
        /// Code.
        /// </summary>
        /// <example>1</example>
        [MaxLength(MaxLengths.ProfessionalCodeMaxLength)]
        [TranslateCode(IdList = "DC006", DescriptionField = "ProfessionalDescription")]
        public string ProfessionalCode { get; set; }

        /// <summary>
        /// Description.
        /// </summary>
        /// <example>Dummy work</example>
        [MaxLength(MaxLengths.ProfessionalDescriptionMaxLength)]
        public string ProfessionalDescription { get; set; }

        /// <summary>
        /// Flag to identify the main job.
        /// </summary>
        /// <example>true</example>
        public bool IsPrincipal { get; set; }

        /// <summary>
        /// Status code.
        /// </summary>
        /// <example>1</example>
        [MaxLength(MaxLengths.LaborStatusCodeMaxLength)]
        public string LaborStatusCode { get; set; }

        /// <summary>
        /// Status.
        /// </summary>
        /// <example>Work example only.</example>
        [MaxLength(MaxLengths.LaborStatusDescriptionMaxLength)]
        public string LaborStatusDescription { get; set; }

        /// <summary>
        /// Employer.
        /// </summary>
        /// <example>Big company</example>
        [MaxLength(MaxLengths.EmployerEntityMaxLength)]
        public string EmployerEntity { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        /// <example>2018-02-14T00:00:00.000Z</example>
        [DataType(DataType.Date)]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Professional license.
        /// </summary>
        public string ProfessionalLicense { get; set; }
    }
}

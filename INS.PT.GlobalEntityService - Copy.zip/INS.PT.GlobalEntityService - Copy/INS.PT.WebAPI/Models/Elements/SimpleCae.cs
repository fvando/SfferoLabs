﻿using INS.PT.WebAPI.IdTranslates;
using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    public class SimpleCae
    {
        /// <summary>
        /// Cae order.
        /// </summary>
        /// <example>1</example>
        public int OrderNumber { get; set; }

        /// <summary>
        /// CAE.
        /// </summary>
        /// <example>47845</example>
        [MaxLength(MaxLengths.CaeNumberMaxLength)]
        [TranslateCode(IdList = "DC007", DescriptionField = "CaeDescription", ToNative = false)]
        [JsonProperty("cae")]
        public string CaeNumber { get; set; }

        /// <summary>
        /// Description.
        /// </summary>
        /// <example>Dummy work</example>
        [MaxLength(MaxLengths.CaeDescriptionMaxLength)]
        public string CaeDescription { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        /// <example>2019-05-02T14:13:27.475Z</example>
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Flag for the principal CAE.
        /// </summary>
        /// <example>true</example>
        public bool IsPrincipal { get; set; }
    }
}

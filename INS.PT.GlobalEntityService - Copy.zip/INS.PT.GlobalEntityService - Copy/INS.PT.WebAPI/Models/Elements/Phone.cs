﻿using INS.PT.WebAPI.IdTranslates;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// Phone object.
    /// </summary>
    public class Phone
    {
        /// <summary>
        /// Identifier.
        /// </summary>
        /// <example>Permanente</example>
        [MaxLength(MaxLengths.PhoneIdentifierMaxLength)]
        public string PhoneIdentifier { get; set; }

        /// <summary>
        /// Phone type code.
        /// </summary>
        /// <example>MOB</example>
        [MaxLength(MaxLengths.PhoneTypeMaxLength)]
        [TranslateCode(IdList = "RDM005", DescriptionField = "PhoneTypeDescription")]
        public string PhoneTypeCode { get; set; }

        /// <summary>
        /// Phone type description.
        /// </summary>
        /// <example>Telemovel</example>
        [MaxLength(MaxLengths.PhoneTypeDescriptionMaxLength)]
        public string PhoneTypeDescription { get; set; }

        /// <summary>
        /// Number.
        /// </summary>
        /// <example>921345890</example>
        [MaxLength(MaxLengths.PhoneNumberMaxLength)]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Flag to the preferred phone.
        /// </summary>
        /// <example>true</example>
        public bool IsPreferred { get; set; }
    }
}

﻿using INS.PT.WebAPI.Interface;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// Object with CRM information stored within MasterEntity.
    /// </summary>
    public class CrmInformation : IMasterOutputMapping
    {

        /// <summary>
        /// Segmentation.
        /// </summary>
        /// <example>Mass Affluent</example>
        public string Segmentation { get; set; }

        /// <summary>
        /// Qualitative value.
        /// </summary>
        public string QualitativeValue { get; set; }

        /// <summary>
        /// Propensity for acquiring TVI.
        /// </summary>
        public string PropensityForAcquiringTvi { get; set; }

        /// <summary>
        /// Propensity for acquiring Auto.
        /// </summary>
        public string PropensityForAcquiringAuto { get; set; }

        /// <summary>
        /// Propensity for acquiring UNL.
        /// </summary>
        public string PropensityForAcquiringUnl { get; set; }

        /// <summary>
        /// Propensity for acquiring MRH.
        /// </summary>
        public string PropensityForAcquiringMrh { get; set; }

        /// <summary>
        /// Sig segmentation 1.
        /// </summary>
        /// <example>Mass Affluent</example>
        public string SigSegmentation1 { get; set; }

        /// <summary>
        /// Sig segmentation 2.
        /// </summary>
        public string SigSegmentation2 { get; set; }

        /// <summary>
        /// Is smoker.
        /// </summary>
        public bool? IsSmoker { get; set; }

        /// <summary>
        /// Preferential contact code.
        /// </summary>
        public string PreferentialContactCode { get; set; }

        /// <summary>
        /// Preferential contact description.
        /// </summary>
        public string PreferentialContactDescription { get; set; }

        /// <summary>
        /// Protocol code.
        /// </summary>
        public string ProtocolCode { get; set; }

        /// <summary>
        /// Protocol description.
        /// </summary>
        public string ProtocolDescription { get; set; }


        #region IMasterOutputMapping implementation
        /// <summary>
        /// mapped name in MDM configuration
        /// </summary>
        [IgnoreDataMember]
        [JsonIgnore]
        string IMasterOutputMapping.StructureName => StructureName;

        /// <summary>
        /// mapped name in MDM configuration
        /// </summary>
        protected static string StructureName => "CRM";

        /// <summary>
        /// child structures
        /// </summary>
        [IgnoreDataMember]
        [JsonIgnore]
        IEnumerable<IMasterOutputMapping> IMasterOutputMapping.ChildStrutures => ChildStrutures;

        /// <summary>
        /// child structures
        /// </summary>
        protected static IEnumerable<IMasterOutputMapping> ChildStrutures => System.Linq.Enumerable.Empty<IMasterOutputMapping>();

        /// <summary>
        /// Method to clear information of this structure
        /// </summary>
        public void Clear()
        {
            Segmentation = null;
            QualitativeValue = null;
            PropensityForAcquiringAuto = null;
            PropensityForAcquiringMrh = null;
            PropensityForAcquiringTvi = null;
            PropensityForAcquiringUnl = null;
            SigSegmentation1 = null;
            SigSegmentation2 = null;
            IsSmoker = null;
            PreferentialContactCode = null;
            PreferentialContactDescription = null;
            ProtocolCode = null;
            ProtocolDescription = null;
        }
        #endregion
    }
}

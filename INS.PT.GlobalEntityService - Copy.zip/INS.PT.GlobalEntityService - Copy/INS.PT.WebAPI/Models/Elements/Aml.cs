﻿using System;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    public class Aml
    {
        /// <summary>
        /// Condition type.
        /// </summary>
        /// <example>2</example>
        [MaxLength(MaxLengths.AmlConditionTypeMaxLength)]
        public string ConditionType { get; set; }

        /// <summary>
        /// Condition description.
        /// </summary>
        /// <example>Relacionado com PEP</example>
        [MaxLength(MaxLengths.AmlConditionDescriptionMaxLength)]
        public string ConditionDescription { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        /// <example>2019-06-14T10:13:27.475Z</example>
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        public DateTime? EndDate { get; set; }
    }
}

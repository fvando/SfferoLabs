﻿using INS.PT.WebAPI.Helpers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.IdTranslates;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// Object with contacts lists.
    /// </summary>
    public class ContactLists : IMasterOutputMapping, ITranslateCodes
    {
        /// <summary>
        /// List of phones.
        /// </summary>
        public IEnumerable<Phone> Phones { get; set; }

        /// <summary>
        /// List of emails.
        /// </summary>
        public IEnumerable<Email>Emails{ get; set; }

        #region IMasterOutputMapping implementation
        /// <summary>
        /// mapped name in MDM configuration
        /// </summary>
        [IgnoreDataMember]
        [JsonIgnore]
        string IMasterOutputMapping.StructureName => StructureName;

        /// <summary>
        /// mapped name in MDM configuration
        /// </summary>
        protected static string StructureName => "CONTACTS";

        /// <summary>
        /// child structures
        /// </summary>
        [IgnoreDataMember]
        [JsonIgnore]
        IEnumerable<IMasterOutputMapping> IMasterOutputMapping.ChildStrutures => ChildStrutures;

        /// <summary>
        /// child structures
        /// </summary>
        protected IEnumerable<IMasterOutputMapping> ChildStrutures =>
            new List<IMasterOutputMapping>
            {
                new MasterOutputCollectionMap("PHONES", () => { Phones = null; }),
                new MasterOutputCollectionMap("EMAILS", () => { Emails = null; })
            };

        /// <summary>
        /// Method to clear information of this structure
        /// </summary>
        public void Clear()
        {
            Phones = null;
            Emails = null;
        }
        #endregion

        /// <summary>
        /// method that executes custom translation on object
        /// </summary>
        /// <param name="codesMapping">object with codes mapping</param>
        /// <param name="idCompany">company identifier</param>
        /// <param name="overrideToNativeAttribute">translation direction to use, or null to assume property default</param>
        public void Translate(CodesMapping codesMapping, string idCompany, bool? overrideToNativeAttribute)
        {
            // no translation to execute
            if (codesMapping == null)
            {
                return;
            }

            // translate emails collection
            if (Emails != null)
            {
                foreach (var email in Emails)
                {
                    codesMapping.Translate(email, idCompany, overrideToNativeAttribute);
                }
            }

            // translate phones collection
            if (Phones != null)
            {
                foreach (var phone in Phones)
                {
                    codesMapping.Translate(phone, idCompany, overrideToNativeAttribute);
                }
            }
        }
    }
}

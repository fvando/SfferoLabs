﻿using INS.PT.WebAPI.IdTranslates;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// Driver's licence object.
    /// </summary>
    public class DriverLicence : ITranslateCodes
    {
        /// <summary>
        /// Licence number.
        /// </summary>
        /// <example>L-12345</example>
        [MaxLength(MaxLengths.DriverLicenceNumberMaxLength)]
        public string DriverLicenceNumber { get; set; }

        /// <summary>
        /// Country code.
        /// </summary>
        /// <example>PRT</example>
        [MaxLength(MaxLengths.CountryCodeMaxLength)]
        [TranslateCode(IdList = "DC004", DescriptionField = "CountryDescription")]
        public string CountryCode { get; set; }

        /// <summary>
        /// Country description.
        /// </summary>
        /// <example>Portugal</example>
        [MaxLength(MaxLengths.CountryDescriptionMaxLength)]
        public string CountryDescription { get; set; }

        /// <summary>
        /// List of driver licence categories.
        /// </summary>
        public IEnumerable<Category> Categories { get; set; }

        /// <summary>
        /// method that executes custom translation on object
        /// </summary>
        /// <param name="codesMapping">object with codes mapping</param>
        /// <param name="idCompany">company identifier</param>
        /// <param name="overrideToNativeAttribute">translation direction to use, or null to assume property default</param>
        public void Translate(CodesMapping codesMapping, string idCompany, bool? overrideToNativeAttribute)
        {
            // no translation to execute
            if (codesMapping == null)
            {
                return;
            }

            // translate simple properties
            codesMapping.Translate(this, idCompany, overrideToNativeAttribute);

            // translate honorary titles collection
            if (Categories != null)
            {
                foreach (var category in Categories)
                {
                    codesMapping.Translate(category, idCompany, overrideToNativeAttribute);
                }
            }

        }
    }
}

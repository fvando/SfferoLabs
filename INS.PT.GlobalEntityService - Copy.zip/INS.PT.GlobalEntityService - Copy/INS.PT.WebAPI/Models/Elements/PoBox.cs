﻿using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// PoBox object.
    /// </summary>
    public class PoBox
    {
        /// <summary>
        /// Po box number.
        /// </summary>
        /// <example>43234</example>
        [MaxLength(MaxLengths.PoBoxNumberMaxLength)]
        public string Number { get; set; }

        /// <summary>
        /// Post office name.
        /// </summary>
        /// <example>Torres Vedras</example>
        [MaxLength(MaxLengths.PoBoxOfficeNameMaxLength)]
        public string PostOfficeName { get; set; }
    }
}

﻿using INS.PT.WebAPI.IdTranslates;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// Email object.
    /// </summary>
    public class Email
    {
        /// <summary>
        /// Identifier.
        /// </summary>
        /// <example>1</example>
        public int? EmailIdentifier { get; set; }

        /// <summary>
        /// Email type code.
        /// </summary>
        /// <example>PO</example>
        [MaxLength(MaxLengths.EmailTypeCodeMaxLength)]        
        [TranslateCode(IdList = "RDM007", DescriptionField = "EmailTypeDescription")]
        public string EmailTypeCode { get; set; }

        /// <summary>
        /// Email type description.
        /// </summary>
        /// <example>E-Mail profissional</example>
        [MaxLength(MaxLengths.EmailTypeDescriptionMaxLength)]
        public string EmailTypeDescription { get; set; }

        /// <summary>
        /// Address.
        /// </summary>
        /// <example>ruijorge.silva.externo@ageas.pt</example>
        [MaxLength(MaxLengths.EmailAddressMaxLength)]
        [EmailAddress]
        public string EmailAddress { get; set; }

        /// <summary>
        /// Flag to the preferred email.
        /// </summary>
        /// <example>true</example>
        public bool IsPreferred { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    public class ExternalReference
    {
        /// <summary>
        /// External reference code.
        /// </summary>
        /// <example>ABR</example>
        [MaxLength(MaxLengths.ExternalReferenceCodeMaxLength)]
        public string ExternalReferenceCode { get; set; }

        /// <summary>
        /// External reference description.
        /// </summary>
        /// <example>inicials</example>
        [MaxLength(MaxLengths.ExternalReferenceDescriptionMaxLength)]
        public string ExternalReferenceDescription { get; set; }
    }
}

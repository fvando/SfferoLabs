﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// 
    /// </summary>
    public class OrganizationContact
    {

        /// <summary>
        /// Position.
        /// </summary>
        /// <example>12</example>
        [MaxLength(MaxLengths.ContactPositionMaxLength)]
        public string Position { get; set; }

        /// <summary>
        /// Contact name.
        /// </summary>
        /// <example>Manuel Patrão</example>
        [MaxLength(MaxLengths.ContactNameMaxLength)]
        public string ContactName { get; set; }

        /// <summary>
        /// List of contects.
        /// </summary>
        public IEnumerable<Contact> Contacts{ get; set; }
    }
}

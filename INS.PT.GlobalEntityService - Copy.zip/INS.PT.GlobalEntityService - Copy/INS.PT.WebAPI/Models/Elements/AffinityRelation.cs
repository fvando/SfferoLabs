﻿using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    public class AffinityRelation
    {
        /// <summary>
        /// Relation id.
        /// </summary>
        /// <example>2233</example>
        public int RelationIdentifier { get; set; }

        /// <summary>
        /// Related entity id.
        /// </summary>
        /// <example>PAI</example>
        [MaxLength(MaxLengths.AffinityIdentifierMaxLength)]
        public string RelatedEntityIdentifier { get; set; }

        /// <summary>
        /// Relation code.
        /// </summary>
        /// <example>PA</example>
        [MaxLength(MaxLengths.AffinityRelationCodeMaxLength)]
        public string RelationCode { get; set; }

        /// <summary>
        /// Relation description.
        /// </summary>
        /// <example>Fundador</example>
        [MaxLength(MaxLengths.AffinityRelationDescriptionMaxLength)]
        public string RelationDescription { get; set; }
    }
}

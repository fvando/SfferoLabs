﻿using INS.PT.WebAPI.Interface;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// Marketing information.
    /// </summary>
    public class Marketing : IMasterOutputMapping
    {
        /// <summary>
        /// Gets or sets the occupational situation code.
        /// </summary>
        /// <example>NA</example>
        public string OccupationalSituationCode { get; set; }

        /// <summary>
        /// Gets or sets the occupational situation description.
        /// </summary>
        /// <example>Não Aplicável</example>
        public string OccupationalSituationDescription { get; set; }

        /// <summary>
        /// Gets or sets the level of education code.
        /// </summary>
        /// <example>NA</example>
        public string LevelOfEducationCode { get; set; }

        /// <summary>
        /// Gets or sets the level of education description.
        /// </summary>
        /// <example>Não Aplicável</example>
        public string LevelOfEducationDescription { get; set; }

        /// <summary>
        /// Gets or sets the occupational group code.
        /// </summary>
        /// <example>NA</example>
        public string OccupationalGroupCode { get; set; }

        /// <summary>
        /// Gets or sets the occupational group description.
        /// </summary>
        /// <example>Não Aplicável</example>
        public string OccupationalGroupDescription { get; set; }

        /// <summary>
        /// Gets or sets the source.
        /// </summary>
        /// <example>449534668</example>
        public string Source { get; set; }

        /// <summary>
        /// Gets or sets the maximum customer automatic discount percentage.
        /// </summary>
        /// <example>0</example>
        public decimal? MaximumCustomerAutoDiscountPercentage { get; set; }

        /// <summary>
        /// Gets or sets the SMS sent.
        /// </summary>
        /// <example>false</example>
        public bool? SmsSent { get; set; }

        /// <summary>
        /// IsPaperlessAgeas
        /// </summary>
        /// <example>false</example>
        public bool? IsPaperlessAgeas { get; set; }

        /// <summary>
        /// HasClientArea.
        /// </summary>
        /// <example>false</example>
        public bool? HasClientArea { get; set; }

        #region IMasterOutputMapping implementation
        /// <summary>
        /// mapped name in MDM configuration
        /// </summary>
        [IgnoreDataMember]
        [JsonIgnore]
        string IMasterOutputMapping.StructureName => StructureName;

        /// <summary>
        /// mapped name in MDM configuration
        /// </summary>
        protected static string StructureName => "MARKETING";

        /// <summary>
        /// child structures
        /// </summary>
        [IgnoreDataMember]
        [JsonIgnore]
        IEnumerable<IMasterOutputMapping> IMasterOutputMapping.ChildStrutures => ChildStrutures;

        /// <summary>
        /// child structures
        /// </summary>
        protected static IEnumerable<IMasterOutputMapping> ChildStrutures => Enumerable.Empty<IMasterOutputMapping>();


        /// <summary>
        /// Method to clear information of this structure
        /// </summary>
        public void Clear()
        {
            IsPaperlessAgeas = null;
        }
        #endregion
    }
}

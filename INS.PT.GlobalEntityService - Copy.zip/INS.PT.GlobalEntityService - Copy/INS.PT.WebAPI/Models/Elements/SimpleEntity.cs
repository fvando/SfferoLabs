﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// Class that represents a entity on is simpler form.
    /// </summary>
    public class SimpleEntity
    {

        /// <summary>
        /// Company id.
        /// </summary>
        /// <example>AGEAS</example>
        [MaxLength(MaxLengths.IdCompanyMaxLength)]
        public string IdCompany { get; set; }

        /// <summary>
        /// Network id.
        /// </summary>
        /// <example>AGEAS</example>
        [MaxLength(MaxLengths.IdNetworkMaxLength)]
        public string IdNetwork { get; set; }

        /// <summary>
        /// Entity id.
        /// </summary>
        /// <example>2233</example>
        [MaxLength(MaxLengths.IdEntityMaxLength)]
        public string IdEntity { get; set; }

        /// <summary>
        /// Name.
        /// </summary>
        /// <example>Test entity</example>
        [MaxLength(MaxLengths.NameMaxLength)]
        public string Name { get; set; }

        /// <summary>
        /// Vat number.
        /// </summary>
        /// <example>500123123</example>
        [MaxLength(MaxLengths.VatMaxLength)]
        public string VatNumber { get; set; }

        /// <summary>
        /// Birthdate.
        /// </summary>
        /// <example>2019-06-14T10:13:27.475Z</example>
        public DateTime? Birthdate { get; set; }

        /// <summary>
        /// Gets or sets the addresses.
        /// </summary>
        /// <value>
        /// The addresses.
        /// </value>
        public IEnumerable<Address> Addresses { get; set; }

        /// <summary>
        /// Entity type.
        /// </summary>
        /// <example>P</example>
        public string EntityType { get; set; }

        /// <summary>
        /// Entity phone.
        /// </summary>
        /// <example>212321321</example>
        [MaxLength(MaxLengths.PhoneNumberMaxLength)]
        public string EntityPhone { get; set; }

        /// <summary>
        /// Entity Caes.
        /// </summary>
        public IEnumerable<SimpleCae> Caes { get; set; }
    }
}

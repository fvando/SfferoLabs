﻿using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    public class Profile
    {
        /// <summary>
        /// Identifier.
        /// </summary>
        /// <example>2668772</example>
        [MaxLength(MaxLengths.ProfileIdentifierMaxLength)]
        public string Identifier { get; set; }

        /// <summary>
        /// Profile code.
        /// </summary>
        /// <example>116</example>
        [MaxLength(MaxLengths.ProfileCodeMaxLength)]
        public string Code { get; set; }


        /// <summary>
        /// Profile description.
        /// </summary>
        /// <example>Locadoras/credores hipotec.</example>
        [MaxLength(MaxLengths.ProfileDescriptionMaxLength)]
        public string Description { get; set; }
    }
}

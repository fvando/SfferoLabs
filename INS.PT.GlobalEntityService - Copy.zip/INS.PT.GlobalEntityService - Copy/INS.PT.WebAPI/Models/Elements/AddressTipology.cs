﻿namespace INS.PT.WebAPI.Models.Elements
{
    public class AddressTipology
    {
        /// <summary>
        /// Postal address.
        /// </summary>
        public PoAddress PostalAddress { get; set; }

        /// <summary>
        /// Postal Box.
        /// </summary>
        public PoBox PostalBox { get; set; }
    }
}

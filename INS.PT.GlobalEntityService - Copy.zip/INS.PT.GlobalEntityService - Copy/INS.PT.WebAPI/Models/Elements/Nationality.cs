﻿using INS.PT.WebAPI.IdTranslates;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// Nationality object.
    /// </summary>
    public class Nationality
    {
        /// <summary>
        /// Code.
        /// </summary>
        /// <example>1</example>
        [MaxLength(MaxLengths.NationalityCodeMaxLength)]
        [TranslateCode(IdList = "DC003", DescriptionField = "NationalityDescription")]
        public string NationalityCode { get; set; }

        /// <summary>
        /// Description.
        /// </summary>
        /// <example>Portuguesa</example>
        [MaxLength(MaxLengths.NationalityDescriptionMaxLength)]
        public string NationalityDescription { get; set; }

        /// <summary>
        /// Flag for the main nationality.
        /// </summary>
        /// <example>true</example>
        public bool IsPrincipal { get; set; }
    }
}

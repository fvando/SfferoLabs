﻿using System;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// Club cards information.
    /// </summary>
    public class ClubCards
    {
        /// <summary>
        /// Card issued date.
        /// </summary>
        public DateTime? IssuedDate { get; set; }

        /// <summary>
        /// Card status code.
        /// </summary>
        public string StatusCode { get; set; }

        /// <summary>
        /// Card status description.
        /// </summary>
        public string StatusDescription { get; set; }

        /// <summary>
        /// Card status date.
        /// </summary>
        public DateTime? StatusDate { get; set; }

        /// <summary>
        /// Accumulated discount amount.
        /// </summary>
        public decimal? AccumulatedDiscount { get; set; }

        /// <summary>
        /// Flag indicating if card is blocked.
        /// </summary>
        public bool IsBlocked { get; set; }

        /// <summary>
        /// Card number.
        /// </summary>
        public string Number { get; set; }
    }
}

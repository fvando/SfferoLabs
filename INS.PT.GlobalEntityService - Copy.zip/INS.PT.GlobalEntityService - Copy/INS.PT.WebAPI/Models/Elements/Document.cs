﻿using INS.PT.WebAPI.IdTranslates;
using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.Elements
{
    public class Document
    {
        /// <summary>
        /// Document type code.
        /// </summary>
        /// <example>CC</example>
        [MaxLength(MaxLengths.DocumentTypeCodeMaxLength)]
        [TranslateCode(IdList = "DC009", DescriptionField = "DocumentTypeDescription")]
        public string DocumentTypeCode { get; set; }

        /// <summary>
        /// Document type description.
        /// </summary>
        /// <example>Cartão Cidadão</example>
        [MaxLength(MaxLengths.DocumentTypeDescriptionMaxLength)]
        public string DocumentTypeDescription { get; set; }

        /// <summary>
        /// Document number.
        /// </summary>
        /// <example>122334411</example>
        [MaxLength(MaxLengths.DocumentNumberMaxLength)]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Issue date.
        /// </summary>
        /// <example>2015-06-01T00:00:00.000Z</example>
        public DateTime? IssueDate { get; set; }

        /// <summary>
        /// Expiration date.
        /// </summary>
        /// <example>2020-06-30T00:00:00.000Z</example>
        public DateTime? ExpirationDate { get; set; }

        /// <summary>
        /// Name of authority that issued the foreign document.
        /// </summary>
        /// <example>EU parlement</example>
        public string IssuingAuthority { get; set; }

        /// <summary>
        /// Document country code.
        /// </summary>
        /// <example>1</example>
        [MaxLength(MaxLengths.CountryCodeMaxLength)]
        [TranslateCode(IdList = "DC004", DescriptionField = "DocumentCountryDescription")]
        public string DocumentCountryCode { get; set; }

        /// <summary>
        /// Document country description.
        /// </summary>
        /// <example>Portugal</example>
        [MaxLength(MaxLengths.CountryDescriptionMaxLength)]
        public string DocumentCountryDescription { get; set; }

        /// <summary>
        /// Flag to indicate that document is an identity document.
        /// </summary>
        [JsonIgnore]
        [IgnoreDataMember]
        public bool IsIdentityDocument 
        {
            get => DocumentTypeCode == "ID";
        }

        /// <summary>
        /// Flag to indicate that document is an identity card.
        /// </summary>
        [JsonIgnore]
        [IgnoreDataMember]
        public bool IsIdentityCard 
        {
            get => DocumentTypeCode == "U";
        }

        /// <summary>
        /// Flag to indicate that document is an foreign document.
        /// </summary>
        [JsonIgnore]
        [IgnoreDataMember]
        public bool IsForeign
        {
            get => string.Compare(DocumentTypeCode, "RCE", StringComparison.InvariantCultureIgnoreCase) == 0
                 || string.Compare(DocumentTypeCode, "BIE", StringComparison.InvariantCultureIgnoreCase) == 0;
        }

        /// <summary>
        /// Method to get the identity document of Tecnisys.
        /// </summary>
        /// <param name="documentList">Enumerable of documents to search.</param>
        /// <returns>null if not found or the Document that is the mapped identity document.</returns>
        public static Document GetIdentityDocument(IEnumerable<Document> documentList)
        {
            return documentList?.FirstOrDefault(d =>d.IsIdentityDocument);
        }

        /// <summary>
        /// Method to get the identity card.
        /// </summary>
        /// <param name="documentList">Enumerable of documents to search.</param>
        /// <returns>null if not found or the Document that is the mapped identity card.</returns>
        public static Document GetIdentityCard(IEnumerable<Document> documentList)
        {
            return documentList?.FirstOrDefault(d =>d.IsIdentityCard);
        }

        /// <summary>
        /// Method to create the identity card.
        /// </summary>
        /// <returns>New Document that is the mapped identity card.</returns>
        public static Document CreateIdentityCard()
        {
            return new Document
            {
                DocumentTypeCode = "U"
            };
        }
    }
}

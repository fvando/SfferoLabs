﻿using INS.PT.WebAPI.IdTranslates;
using System;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    public class CrsFatca
    {
        /// <summary>
        /// Flag indicating if is a fatca.
        /// </summary>
        /// <example>true</example>
        public bool IsFatca { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        /// <example>2019-06-14T10:13:27.475Z</example>
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Crs status.
        /// </summary>
        /// <example>CLI</example>
        [MaxLength(MaxLengths.CrsStatusMaxLength)]
        public string CrsStatus { get; set; }

        /// <summary>
        /// Reporter bank.
        /// </summary>
        /// <example>S</example>
        [MaxLength(MaxLengths.CrsReporterBankMaxLength)]
        public string ReporterBank { get; set; }

        /// <summary>
        /// Reporter AGEAS.
        /// </summary>
        /// <example>S</example>
        [MaxLength(MaxLengths.CrsReporterAgeasMaxLength)]
        public string ReporterAgeas { get; set; }

        /// <summary>
        /// Report year.
        /// </summary>
        /// <example>2019</example>
        [MaxLength(MaxLengths.CrsReportYearMaxLength)]
        public string ReportYear { get; set; }

        /// <summary>
        /// Fiscal address.
        /// </summary>
        /// <example>Rua Barros Leal, 2 - loja 3</example>
        [MaxLength(MaxLengths.CrsFiscalAddressMaxLength)]
        public string FiscalAddress { get; set; }

        /// <summary>
        /// Fiscal country.
        /// </summary>
        /// <example>1</example>
        [MaxLength(MaxLengths.CountryCodeMaxLength)]
        [TranslateCode(IdList = "DC004")]
        public string FiscalCountry { get; set; }

        /// <summary>
        /// Foreign vat.
        /// </summary>
        /// <example></example>
        [MaxLength(MaxLengths.CrsForeignVatMaxLength)]
        public string ForeignVat { get; set; }

        /// <summary>
        /// Inexistence foreign vat motive.
        /// </summary>
        /// <example>none</example>
        [MaxLength(MaxLengths.CrsVatMotiveMaxLength)]
        public string InexistenceForeignVatMotive { get; set; }

        /// <summary>
        /// Data source.
        /// </summary>
        /// <example>CTB</example>
        [MaxLength(MaxLengths.CrsDataSourceMaxLength)]
        public string DataSource { get; set; }

        /// <summary>
        /// Record timestamp.
        /// </summary>
        /// <example>2019-06-14T10:13:27.475Z</example>
        public DateTime RecordTimestamp { get; set; }
    }
}

﻿using INS.PT.WebAPI.IdTranslates;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    public class Address
    {
        /// <summary>
        /// Sequence.
        /// </summary>
        /// <example>1</example>
        [MaxLength(MaxLengths.AddressSequenceMaxLength)]
        public string Sequence { get; set; }

        /// <summary>
        /// Address type.
        /// </summary>
        /// <example>S</example>
        [MaxLength(MaxLengths.AddressTypeMaxLength)]
        public string AddressType { get; set; }

        /// <summary>
        /// Address type description.
        /// </summary>
        /// <example>Sede</example>
        [MaxLength(MaxLengths.AddressTypeDescriptionMaxLength)]
        public string AddressTypeDescription { get; set; }

        /// <summary>
        /// Flag to indicate the Fiscal address.
        /// </summary>
        /// <example>true</example>
        public bool IsFiscalAddress { get; set; }

        /// <summary>
        /// Format type.
        /// </summary>
        /// <example>L</example>
        [MaxLength(MaxLengths.AddressFormatTypeMaxLength)]
        public string FormatType { get; set; }

        /// <summary>
        /// Tipology.
        /// </summary>
        public AddressTipology Tipology { get; set; }

        /// <summary>
        /// Flag that indicates address needs correction.
        /// </summary>
        /// <example>false</example>
        public bool IsReturnedForCorrection { get; set; }

        /// <summary>
        /// Postal code.
        /// </summary>
        /// <example>2590</example>
        [MaxLength(MaxLengths.PostalCodeMaxLength)]
        public string PostalCode { get; set; }

        /// <summary>
        /// Postal code description.
        /// </summary>
        /// <example>Torres Vedras</example>
        [MaxLength(MaxLengths.PostalCodeDescriptionMaxLength)]
        public string PostalCodeDescription { get; set; }

        /// <summary>
        /// Country code.
        /// </summary>
        /// <example>1</example>
        [TranslateCode(IdList = "DC004", DescriptionField = "CountryDescription")]
        [MaxLength(MaxLengths.CountryCodeMaxLength)]
        public string CountryCode { get; set; }

        /// <summary>
        /// Country description.
        /// </summary>
        /// <example>Portugal</example>
        [MaxLength(MaxLengths.CountryDescriptionMaxLength)]        
        public string CountryDescription { get; set; }

        /// <summary>
        /// Georeference.
        /// </summary>
        /// <example>123.22;43.21</example>
        [MaxLength(MaxLengths.GeoreferenceMaxLength)]
        public string Georeference { get; set; }
    }
}

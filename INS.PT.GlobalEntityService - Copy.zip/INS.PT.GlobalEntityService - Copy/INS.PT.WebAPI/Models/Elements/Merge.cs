﻿using INS.PT.WebAPI.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Models.Elements
{
    public class Merge : IMasterOutputMapping
    {
        public static readonly string StructureMappedName = "COMBINE";

        /// <summary>
        /// Sequence
        /// </summary>
        public int? Sequence { get; set; }

        /// <summary>
        /// FinalIdEntity
        /// </summary>
        public string FinalIdEntity { get; set; }

        /// <summary>
        /// FinalValue
        /// </summary>
        public string FinalValue { get; set; }

        /// <summary>
        /// MergedIdEntity
        /// </summary>
        public string MergedIdEntity { get; set; }

        /// <summary>
        /// MergedValue
        /// </summary>
        public string MergedValue { get; set; }

        /// <summary>
        /// Date
        /// </summary>
        public DateTime? Date { get; set; }

        /// <summary>
        /// Value
        /// </summary>
        public string Value { get; set; }

        /// <summary>
        /// MergeType
        /// </summary>
        public string MergeType { get; set; }

        /// <summary>
        /// TypeDescription
        /// </summary>
        public string TypeDescription { get; set; }

        /// <summary>
        /// RequestId
        /// </summary>
        public string RequestId { get; set; }

        /// <summary>
        /// remaining merges
        /// </summary>
        public string Todo { get; set; }

        #region IMasterOutputMapping implementation
        /// <summary>
        /// mapped name in MDM configuration
        /// </summary>
        [IgnoreDataMember]
        [JsonIgnore]
        string IMasterOutputMapping.StructureName => StructureName;

        /// <summary>
        /// mapped name in MDM configuration
        /// </summary>
        protected static string StructureName => StructureMappedName;

        /// <summary>
        /// child structures
        /// </summary>
        [IgnoreDataMember]
        [JsonIgnore]
        IEnumerable<IMasterOutputMapping> IMasterOutputMapping.ChildStrutures => ChildStrutures;

        /// <summary>
        /// child structures
        /// </summary>
        protected static IEnumerable<IMasterOutputMapping> ChildStrutures => Enumerable.Empty<IMasterOutputMapping>();

        /// <summary>
        /// Method to clear information of this structure
        /// </summary>
        public void Clear()
        {
            Sequence = null;
            FinalIdEntity = null;
            FinalValue = null;
            MergedIdEntity = null;
            MergedValue = null;
            Date = null;
            Value = null;
            MergeType = null;
            TypeDescription = null;
            RequestId = null;
            Todo = null;
        }
        #endregion
    }
}

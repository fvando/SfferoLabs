﻿using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// BankAccount object.
    /// </summary>
    public class BankAccount
    {
        /// <summary>
        /// Sequence for bank account number.
        /// </summary>
        /// <example>1</example>
        public int? SequenceBankAccountNumber { get; set; }

        /// <summary>
        /// Bank account number.
        /// </summary>
        /// <example>3635364445</example>
        [MaxLength(MaxLengths.BankAccountNumberMaxLength)]
        public string BankAccountNumber { get; set; }

        /// <summary>
        /// Iban.
        /// </summary>
        /// <example>004593737492772848947</example>
        [MaxLength(MaxLengths.IbanMaxLength)]
        public string Iban { get; set; }
    }
}

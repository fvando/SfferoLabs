﻿using Ins.PT.WebAPI;
using INS.PT.WebAPI.IdTranslates;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace INS.PT.WebAPI.Models.Elements.Crm
{
    public class LastContact : IMapped
    {
        const int MaxIdContact = 15;
        const int MaxSource = 30;
        const int MaxContactChannel = 100;
        const int MaxExternalId = 30;
        const int MaxContactMethod = 100;
        const int MaxStatusDescription = 100;
        const int MaxTypology = 100;
        const int MaxContactedBy = 30;

        public void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(LastContact));
        }

        /// <summary>
        /// Contact identifier.
        /// </summary>
        /// <example>20180100077081</example>
        [Column("id_contacto")]
        [MaxLength(MaxIdContact)]
        public string IdContact { get; set; }

        /// <summary>
        /// Contact source.
        /// </summary>
        /// <example>Inbound</example>
        [Column("origem_contacto")]
        [MaxLength(MaxSource)]
        public string Source { get; set; }

        /// <summary>
        /// Entity identifier.
        /// </summary>
        /// <example>12154550</example>
        [Column("id_dni")]
        [MaxLength(MaxLengths.IdEntityMaxLength)]
        public string IdEntity { get; set; }

        /// <summary>
        /// Contact channel.
        /// </summary>
        /// <example>CC</example>
        [Column("des_canal_contacto")]
        [MaxLength(MaxContactChannel)]
        public string ContactChannel { get; set; }

        /// <summary>
        /// External identifiers.
        /// </summary>
        /// <example>20180100006205</example>
        [Column("id_contacto_cnl")]
        [MaxLength(MaxExternalId)]
        public string ExternalId { get; set; }

        /// <summary>
        /// Contact moment.
        /// </summary>
        /// <example>2019-06-14T10:13:27.475Z</example>
        [Column("dat_contacto")]
        public DateTime? ContactMoment { get; set; }

        /// <summary>
        /// Quotation identifier.
        /// </summary>
        /// <example></example>
        [Column("id_simulacao")]
        public string IdQuotation { get; set; }

        /// <summary>
        /// Contact method.
        /// </summary>
        /// <example>Telefone</example>
        [Column("des_meio_contacto")]
        [MaxLength(MaxContactMethod)]
        public string ContactMethod { get; set; }

        /// <summary>
        /// Status description.
        /// </summary>
        /// <example>Encerrado</example>
        [Column("des_situacao")]
        [MaxLength(MaxStatusDescription)]
        public string StatusDescription { get; set; }

        /// <summary>
        /// Typology description.
        /// </summary>
        /// <example>Pedido de Informação</example>
        [Column("des_tipologia")]
        [MaxLength(MaxTypology)]
        public string Typology { get; set; }

        /// <summary>
        /// Flag indicating if contact is confidential.
        /// </summary>
        /// <example>S</example>
        [Column("sn_confidencial")]
        [IgnoreDataMember]
        [JsonIgnore]
        public char Confidential { get; set; }

        /// <summary>
        /// Flag indicating if contact is confidential.
        /// </summary>
        /// <example>S</example>
        public bool IsConfidential
        {
            get
            {
                return Confidential == 'S' || Confidential == 's';
            }
            set
            {
                Confidential = value ? 'S' : 'N';
            }
        }

        /// <summary>
        /// Company identifier.
        /// </summary>
        /// <example>AXA</example>
        [Column("id_empresa")]
        [MaxLength(MaxLengths.IdCompanyMaxLength)]
        //todo build translation based on mapping TECNISYS_MAP_RDM_00001
        //[TranslateCode(IdList = "TECNISYS_MAP_RDM_00001", UseDirectMappingList = true)]
        public string IdCompany { get; set; }

        /// <summary>
        /// Company description.
        /// </summary>
        public string CompanyDescription { get; set; }

        /// <summary>
        /// Country idenfifier.
        /// </summary>
        /// <example>PRT</example>
        [Column("id_pais")]
        [MaxLength(MaxLengths.CountryCodeMaxLength)]
        [TranslateCode(IdList = "DC004", DescriptionField = "CountryDescription")]
        public string IdCountry { get; set; }

        /// <summary>
        /// Country description.
        /// </summary>
        public string CountryDescription { get; set; }

        /// <summary>
        /// User that made contact.
        /// </summary>
        /// <example>SDE45328</example>
        [Column("utilizador")]
        [MaxLength(MaxContactedBy)]
        public string ContactedBy { get; set; }

        /// <summary>
        /// Contacts count.
        /// </summary>
        /// <example>1</example>
        [Column("NRO_CONT_ULTIMO_ANO")]
        public int ContactsCount { get; set; }
    }
}

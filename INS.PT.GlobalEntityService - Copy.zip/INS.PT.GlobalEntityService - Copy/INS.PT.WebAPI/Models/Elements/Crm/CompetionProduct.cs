﻿using Ins.PT.WebAPI;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models.Elements.Crm
{
    public class CompetionProduct : IMapped
    {
        const int MaxOrder = 8;
        const int MaxProduct = 100;

        public void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(CompetionProduct));
        }

        /// <summary>
        /// Order.
        /// </summary>
        /// <example>1</example>
        [Column("nrordem")]
        [MaxLength(MaxOrder)]
        public string Order { get; set; }

        /// <summary>
        /// Product description.
        /// </summary>
        /// <example>Clientes 2020</example>
        [Column("dsproduto")]
        [MaxLength(MaxProduct)]
        public string Product { get; set; }

        /// <summary>
        /// Expiration date.
        /// </summary>
        /// <example>2020-07-17</example>
        [Column("dtfim")]
        public DateTime? ExpirationDate { get; set; }
    }
}

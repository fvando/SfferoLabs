﻿using Ins.PT.WebAPI;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models.Elements.Crm
{
    /// <summary>
    /// Object with Proposal information.
    /// </summary>
    public class Proposal : IMapped
    {
        /// <summary>
        /// Method that is going to prepare the object mappings.
        /// </summary>
        public void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(Proposal));
        }

        /// <summary>
        /// Proposal to present.
        /// </summary>
        /// <example>Apresnetar promoções de novos clientes.</example>
        [Column("soluc_prod_a_aprensent")]
        public string Description { get; set; }
    }
}

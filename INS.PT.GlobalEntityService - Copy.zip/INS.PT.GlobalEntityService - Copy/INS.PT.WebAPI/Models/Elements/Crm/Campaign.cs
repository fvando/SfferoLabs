﻿using Ins.PT.WebAPI;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models.Elements.Crm
{
    public class Campaign : IMapped
    {
        const int MaxIdCampaign = 8;
        const int MaxDescription = 100;
        const int MaxName = 100;

        public void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(Campaign));
        }

        /// <summary>
        /// Campaign identifier.
        /// </summary>
        /// <example>NC2020</example>
        [Column("cdcampanha")]
        [MaxLength(MaxIdCampaign)]
        public string IdCampaign { get; set; }

        /// <summary>
        /// Description.
        /// </summary>
        /// <example>Novos clientes.</example>
        [Column("dscampanha")]
        [MaxLength(MaxDescription)]
        public string Description { get; set; }

        /// <summary>
        /// Name
        /// </summary>
        /// <example>Clientes.</example>
        [Column("nome_campanha")]
        [MaxLength(MaxName)]
        public string Name { get; set; }

        /// <summary>
        /// Campaign end date.
        /// </summary>
        /// <example>2020-05-05</example>
        [Column("dt_fim")]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Notes.
        /// </summary>
        /// <example></example>
        [Column("dsvage")]
        public string Notes { get; set; }
    }
}

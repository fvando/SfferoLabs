﻿using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.IdTranslates;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace INS.PT.WebAPI.Models.Elements.Crm
{
    public class ExternalInfo : IMasterOutputMapping, ITranslateCodes
    {
        /// <summary>
        /// Semaphore
        /// </summary>
        public string Semaphore { get; set; }

        /// <summary>
        /// Campaigns
        /// </summary>
        public IEnumerable<Campaign> Campaigns { get; set; }

        /// <summary>
        /// Competion products.
        /// </summary>
        public IEnumerable<CompetionProduct> CompetionProducts { get; set; }

        /// <summary>
        /// Last contacts
        /// </summary>
        public IEnumerable<LastContact> LastContacts { get; set; }

        /// <summary>
        /// Proposals to present
        /// </summary>
        public IEnumerable<Proposal> Proposals { get; set; }


        #region IMasterOutputMapping implementation
        /// <summary>
        /// mapped name in MDM configuration
        /// </summary>
        [IgnoreDataMember]
        [JsonIgnore]
        string IMasterOutputMapping.StructureName => StructureName;

        /// <summary>
        /// mapped name in MDM configuration
        /// </summary>
        protected static string StructureName => "EXTERNALCRM";

        /// <summary>
        /// child structures
        /// </summary>
        [IgnoreDataMember]
        [JsonIgnore]
        IEnumerable<IMasterOutputMapping> IMasterOutputMapping.ChildStrutures => ChildStrutures;

        /// <summary>
        /// child structures
        /// </summary>
        protected static IEnumerable<IMasterOutputMapping> ChildStrutures => System.Linq.Enumerable.Empty<IMasterOutputMapping>();

        /// <summary>
        /// Method to clear information of this structure
        /// </summary>
        public void Clear()
        {
            Semaphore = null;
            Campaigns = null;
            CompetionProducts = null;
            LastContacts = null;
            Proposals = null;
        }
        #endregion


        /// <summary>
        /// method that executes custom translation on object
        /// </summary>
        /// <param name="codesMapping">object with codes mapping</param>
        /// <param name="idCompany">company identifier</param>
        /// <param name="overrideToNativeAttribute">translation direction to use, or null to assume property default</param>
        public void Translate(CodesMapping codesMapping, string idCompany, bool? overrideToNativeAttribute)
        {
            // no translation to execute
            if (codesMapping == null)
            {
                return;
            }


            // translate LastContacts collection
            if (LastContacts != null)
            {
                foreach (var contact in LastContacts)
                {
                    codesMapping.Translate(contact, idCompany, overrideToNativeAttribute);
                }
            }
        }
    }
}

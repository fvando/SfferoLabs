﻿using System;

namespace INS.PT.WebAPI.Models.Elements
{
    public class Tax
    {
        /// <summary>
        /// tax source.
        /// </summary>
        public string Source { get; set; }

        /// <summary>
        /// Tax code.
        /// </summary>
        public string Code { get; set; }

        /// <summary>
        /// Tax description.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Tax amount.
        /// </summary>
        public decimal? Value { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Flag if tax is active.
        /// </summary>
        public bool Active { get; set; }
    }
}

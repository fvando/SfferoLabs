﻿using INS.PT.WebAPI.IdTranslates;
using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Elements
{
    public class Cae
    {
        /// <summary>
        /// Cae order.
        /// </summary>
        /// <example>1</example>
        public int CaeOrderNumber { get; set; }

        /// <summary>
        /// Flag for the principal CAE.
        /// </summary>
        /// <example>true</example>
        public bool IsPrincipal { get; set; }

        /// <summary>
        /// CAE.
        /// </summary>
        /// <example>47845</example>
        [MaxLength(MaxLengths.CaeNumberMaxLength)]
        [TranslateCode(IdList = "DC007", DescriptionField = "CaeDescription")]
        [JsonProperty("cae")]
        public string CaeNumber { get; set; }

        /// <summary>
        /// Description.
        /// </summary>
        /// <example>Dummy work</example>
        [MaxLength(MaxLengths.CaeDescriptionMaxLength)]
        public string CaeDescription { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        /// <example>2019-05-02T14:13:27.475Z</example>
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Sector of activity.
        /// </summary>
        /// <example>nearshore</example>
        [MaxLength(MaxLengths.CaeSectorOfActivityMaxLength)]
        public string SectorOfActivity { get; set; }

        /// <summary>
        /// Country code.
        /// </summary>
        /// <example>1</example>
        [MaxLength(MaxLengths.CountryCodeMaxLength)]
        [TranslateCode(IdList = "DC004", DescriptionField = "CountryDescription")]
        public string CountryCode { get; set; }

        /// <summary>
        /// Country description.
        /// </summary>
        /// <example>Portugal</example>
        [MaxLength(MaxLengths.CountryDescriptionMaxLength)]
        public string CountryDescription { get; set; }
    }
}

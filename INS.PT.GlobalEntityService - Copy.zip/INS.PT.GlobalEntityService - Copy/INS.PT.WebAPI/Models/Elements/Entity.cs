﻿using INS.PT.WebAPI.Helpers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.IdTranslates;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using System.Linq;

namespace INS.PT.WebAPI.Models.Elements
{
    /// <summary>
    /// Entity object.
    /// </summary>
    public class Entity : IMasterOutputMapping, ITranslateCodes
    {
        /// <summary>
        /// Entity id.
        /// </summary>
        /// <example>2233</example>
        [MaxLength(MaxLengths.IdEntityMaxLength)]
        public string IdEntity { get; set; }

        /// <summary>
        /// Vat number.
        /// </summary>
        /// <example>500123123</example>
        [MaxLength(MaxLengths.VatMaxLength)]
        public string VatNumber { get; set; }

        /// <summary>
        /// Flag that indicates Vat is foreign.
        /// </summary>
        /// <example>false</example>
        public bool IsForeignVat { get; set; }

        /// <summary>
        /// Country code.
        /// </summary>
        /// <example>1</example>
        [MaxLength(MaxLengths.CountryCodeMaxLength)]
        [TranslateCode(IdList = "DC003", DescriptionField = "CountryDescription")]
        public string CountryCode { get; set; }

        /// <summary>
        /// Country name.
        /// </summary>
        /// <example>Portugal</example>
        [MaxLength(MaxLengths.CountryDescriptionMaxLength)]
        public string CountryDescription { get; set; }

        public class EntityType : ITranslateCodes
        {
            /// <summary>
            /// Individual person.
            /// </summary>
            public Person Individual { get; set; }

            /// <summary>
            /// Company.
            /// </summary>
            public Organization Company { get; set; }

            public void Translate(CodesMapping codesMapping, string idCompany, bool? overrideToNativeAttribute)
            {
                codesMapping?.Translate(this, idCompany, overrideToNativeAttribute);
            }
        }

        public EntityType Type { get; set; } = new EntityType();

        /// <summary>
        /// List of addresses.
        /// </summary>
        [XmlArray("Addresses")]
        public IEnumerable<Address> Addresses { get; set; } = new List<Address>();

        /// <summary>
        /// Lists of all contacts types.
        /// </summary>
        public ContactLists Contacts { get; set; } = new ContactLists();

        /// <summary>
        /// List of bank accounts.
        /// </summary>
        public IEnumerable<BankAccount> BankAccounts { get; set; } = new List<BankAccount>();

        /// <summary>
        /// List of documents.
        /// </summary>
        public ICollection<Document> Documents { get; set; } = new List<Document>();

        /// <summary>
        /// List od CAEs.
        /// </summary>
        [XmlArray("Caes")]
        public IEnumerable<Cae> Caes { get; set; } = new List<Cae>();

        /// <summary>
        /// List of External References.
        /// </summary>
        public IEnumerable<ExternalReference> ExternalReferences { get; set; } = new List<ExternalReference>();

        /// <summary>
        /// List of Crs/Fatcas
        /// </summary>
        public IEnumerable<CrsFatca> CrsFatcas { get; set; } = new List<CrsFatca>();

        /// <summary>
        /// List of affinity relations.
        /// </summary>
        public IEnumerable<AffinityRelation> AffinityRelations { get; set; } = new List<AffinityRelation>();

        /// <summary>
        /// List of AMLs.
        /// </summary>
        public ICollection<Aml> Amls { get; set; } = new List<Aml>();

        /// <summary>
        /// List of profiles.
        /// </summary>
        public IEnumerable<Profile> Profiles { get; set; } = new List<Profile>();

        /// <summary>
        /// Entity version.
        /// </summary>
        /// <example>19.10.15 17:31:18,244125</example>
        public string Version { get; set; }

        /// <summary>
        /// Entity marketing information.
        /// </summary>
        public Marketing MarketingInformation { get; set; }

        public IEnumerable<Merge> Merges { get; set; } = new List<Merge>();

        public IEnumerable<Tax> Taxes { get; set; }

        /// <summary>
        /// Entity cards.
        /// </summary>
        public Cards Cards { get; set; }

        /// <summary>
        /// CRM information.
        /// </summary>
        public CrmInformation CrmInformation { get; set; }

        #region IMasterOutputMapping implementation
        /// <summary>
        /// mapped name in MDM configuration
        /// </summary>
        [IgnoreDataMember]
        [JsonIgnore]
        string IMasterOutputMapping.StructureName => StructureName;

        /// <summary>
        /// mapped name in MDM configuration
        /// </summary>
        protected static string StructureName => "ENTITY";

        /// <summary>
        /// child structures
        /// </summary>
        [IgnoreDataMember]
        [JsonIgnore]
        IEnumerable<IMasterOutputMapping> IMasterOutputMapping.ChildStrutures => ChildStrutures;

        /// <summary>
        /// child structures
        /// </summary>
        protected IEnumerable<IMasterOutputMapping> ChildStrutures =>
            new List<IMasterOutputMapping>
            {
                Type.Individual,
                Contacts,
                new MasterOutputCollectionMap("ADDRESSES", () => { Addresses = null; }),
                new MasterOutputCollectionMap("AFFINITYRELATIONS", () => { AffinityRelations = null; }),
                new MasterOutputCollectionMap("AML", () => { Amls = null; }),
                new MasterOutputCollectionMap("PROFILES", () => { Profiles = null; }),
                new MasterOutputCollectionMap("TAXES", () => { Taxes = null; }),
                new MasterOutputCollectionMap("BANKACCOUNTS", () => { BankAccounts = null; }),
                new MasterOutputCollectionMap("DOCUMENTS", () => { Documents = null; }),
                new MasterOutputCollectionMap("CAES", () => { Caes = null; }),
                new MasterOutputCollectionMap("EXTERNALREFERENCES", () => { ExternalReferences = null; }),
                new MasterOutputCollectionMap("CRSFATCA", () => { CrsFatcas = null; }),
                MarketingInformation,
                new MasterOutputCollectionMap(Merge.StructureMappedName, () => { Merges = null; }),
                new MasterOutputCollectionMap("PROFILES", () => { Profiles = null; }),
                Cards,
                CrmInformation
            };

        /// <summary>
        /// Method to clear information of this structure
        /// </summary>
        public void Clear()
        {
            IdEntity = null;
            VatNumber = null;
            IsForeignVat = false;
            CountryCode = null;
            CountryDescription = null;
            Type = null;
            Addresses = null;
            Contacts = null;
            BankAccounts = null;
            Documents = null;
            Caes = null;
            ExternalReferences = null;
            CrsFatcas = null;
            AffinityRelations = null;
            Amls = null;
            Profiles = null;
            MarketingInformation = null;
            Merges = null;
            Profiles = null;
            Cards = null;
        }
        #endregion

        /// <summary>
        /// method that executes custom translation on object
        /// </summary>
        /// <param name="codesMapping">object with codes mapping</param>
        /// <param name="idCompany">company identifier</param>
        /// <param name="overrideToNativeAttribute">translation direction to use, or null to assume property default</param>
        public void Translate(CodesMapping codesMapping, string idCompany, bool? overrideToNativeAttribute)
        {
            // no translation to execute
            if (codesMapping == null)
            {
                return;
            }

            // translate simple properties
            codesMapping.Translate(this, idCompany, overrideToNativeAttribute);

            // translate cae collection
            if (Caes != null)
            {
                foreach (var cae in Caes)
                {
                    codesMapping.Translate(cae, idCompany, overrideToNativeAttribute);
                }
            }

            // translate documents collection
            if (Documents != null)
            {
                foreach (var document in Documents)
                {
                    codesMapping.Translate(document, idCompany, overrideToNativeAttribute);
                }
            }

            // translate addresses collection
            if (Addresses != null)
            {
                foreach (var address in Addresses)
                {
                    codesMapping.Translate(address, idCompany, overrideToNativeAttribute);
                }
            }

            // translate crs factcas collection
            if (CrsFatcas != null)
            {
                foreach (var fatca in CrsFatcas)
                {
                    codesMapping.Translate(fatca, idCompany, overrideToNativeAttribute);
                }
            }
        }

        /// <summary>
        /// Property to determine if object contains key information to perfom an insert/update of data.
        /// </summary>
        internal bool ContainsKeyInformation
        {
            get
            {
                if(IdEntity != null || VatNumber != null)
                {
                    return true;
                }

                var validNewEntity = Addresses != null && Addresses.Any()
                        && (!string.IsNullOrEmpty(Type?.Company?.CompanyName)
                            || !string.IsNullOrEmpty(Type?.Individual?.Name));

                return validNewEntity;
            }
        }
    }
}

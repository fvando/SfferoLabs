﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Exceptions
{
    [Serializable]
    public class CanonicalException : BaseException
    {
        /// <summary>
        /// contructor
        /// </summary>
        public CanonicalException()
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="statusCode">http error code</param>
        /// <param name="errorDescription">error message</param>
        public CanonicalException(HttpStatusCode statusCode, string errorDescription) : base(errorDescription, statusCode)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="responseMessage">error code and description</param>
        public CanonicalException(HttpResponseMessage responseMessage) : this(responseMessage?.StatusCode ?? HttpStatusCode.BadRequest, responseMessage?.ReasonPhrase)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="errorCode">error code</param>
        /// <param name="errorMessage">error message</param>
        public CanonicalException(string errorCode, string errorMessage) : base(errorCode, errorMessage)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="errorCode">error code</param>
        /// <param name="errorMessage">error message</param>
        /// <param name="innerErrors">internal errors</param>
        public CanonicalException(string errorCode, string errorMessage, IEnumerable<InnerError> innerErrors) : base(errorCode, errorMessage, innerErrors)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="statusCode">http error code</param>
        /// <param name="errorCode">error code</param>
        /// <param name="errorMessage">error message</param>
        /// <param name="innerErrors">internal errors</param>
        public CanonicalException(string errorCode, string errorMessage, HttpStatusCode statusCode, IEnumerable<InnerError> innerErrors) 
            : base(errorCode, errorMessage, statusCode, innerErrors)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="message">error message</param>
        public CanonicalException(string message) : base(message)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="message">error message</param>
        /// <param name="statusCode">http error code</param>
        public CanonicalException(string message, HttpStatusCode statusCode) : base(message, statusCode)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="code">error code</param>
        /// <param name="message">error message</param>
        /// <param name="statusCode">http error code</param>
        public CanonicalException(string code, string message, HttpStatusCode statusCode) : base(code, message, statusCode)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="message">error message</param>
        /// <param name="innerException">The exception that is the cause of the current exception, or a null reference</param>
        public CanonicalException(string message, Exception innerException) : base(message, innerException)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="message">error message</param>
        /// <param name="innerException"></param>
        /// <param name="statusCode">http error code</param>
        public CanonicalException(string message, Exception innerException, HttpStatusCode statusCode) : base(message, innerException, statusCode)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="info">The System.Runtime.Serialization.SerializationInfo that holds the serialized 
        /// object data about the exception being thrown.</param>
        /// <param name="context">The System.Runtime.Serialization.StreamingContext that contains contextual 
        /// information about the source or destination</param>
        protected CanonicalException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }

        /// <inheritdoc /> 
        /// <summary>
        /// Changes the values exposed for serialization.
        /// </summary>
        /// <param name="info">The System.Runtime.Serialization.SerializationInfo that holds the serialized 
        /// object data about the exception being thrown.</param>
        /// <param name="context">The System.Runtime.Serialization.StreamingContext that contains contextual 
        /// information about the source or destination.</param>
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Exceptions
{
    /// <summary>
    /// Error during process execution.
    /// </summary>
    [Serializable]
    public class BaseException : Exception
    {
        [Serializable]
        public class InnerError
        {
            /// <summary>
            /// Error code.
            /// </summary>
            /// <example>E0001</example>
            public string ErrorCode { get; set; }

            /// <summary>
            /// Error message.
            /// </summary>
            /// <example>Error on process.</example>
            public string ErrorMessage { get; set; }
        }

        /// <summary>
        /// Http status code to be generated.
        /// </summary>
        /// <example>400</example>
        public HttpStatusCode StatusCode { get; set; }

        /// <summary>
        /// Error code.
        /// </summary>
        /// <example>E0001</example>
        public string ErrorCode { get; set; }

        /// <summary>
        /// Error message.
        /// </summary>
        /// <example>Error on process.</example>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets the inner errors.
        /// </summary>
        /// <example>
        /// The inner errors.
        /// </example>
        public IEnumerable<InnerError> InnerErrors { get; set; }

        #region Contructors
        private void AddException(Exception innerException)
        {
            InnerErrors = (innerException != null) ?
                new List<InnerError>
                {
                    new InnerError
                    {
                        ErrorCode = innerException.Source,
                        ErrorMessage = innerException.Message
                    }
                }
                : new List<InnerError>();
        }

        public BaseException()
        {
        }

        public BaseException(string message) : this(message, (Exception)null)
        {
        }

        public BaseException(string message, HttpStatusCode statusCode) : this(message, (Exception)null, statusCode)
        {
        }

        public BaseException(string code, string message) : this(message, (Exception)null)
        {
            ErrorCode = code;
        }

        public BaseException(string code, string message, HttpStatusCode statusCode) : this(message, (Exception)null, statusCode)
        {
            ErrorCode = code;
        }

        public BaseException(string message, Exception innerException) : base(message, innerException)
        {
            ErrorMessage = message;
            StatusCode = HttpStatusCode.BadRequest;

            AddException(innerException);
        }

        public BaseException(string message, Exception innerException, HttpStatusCode statusCode) : base(message, innerException)
        {
            ErrorCode = ((int)statusCode).ToString(System.Globalization.CultureInfo.InvariantCulture);
            ErrorMessage = message;
            StatusCode = statusCode;

            AddException(innerException);
        }

        protected BaseException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }

        public BaseException(string errorCode, string errorMessage, IEnumerable<InnerError> innerErrors) : this(errorCode, errorMessage)
        {
            InnerErrors = innerErrors ?? throw new ArgumentNullException(nameof(innerErrors));
        }

        public BaseException(string errorCode, string errorMessage, HttpStatusCode statusCode, IEnumerable<InnerError> innerErrors) : this(errorCode, errorMessage, statusCode)
        {
            InnerErrors = innerErrors ?? throw new ArgumentNullException(nameof(innerErrors));
        }
        #endregion

        /// <summary>
        /// Gets a message that describes the current exception.
        /// </summary>
        public override string Message => ToString();

        ///<inheritdoc /> 
        /// <summary>
        /// Custom converts to string.
        /// </summary>
        /// <returns>
        /// A <see cref="System.String" /> that represents this instance.
        /// </returns>
        public override string ToString()
        {
            return $"Execution returned error {ErrorCode} with message: {ErrorMessage}";
        }

        /// <inheritdoc /> 
        /// <summary>
        /// Changes the values exposed for serialization.
        /// </summary>
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
            {
                base.GetObjectData(info, context);
                throw new ArgumentNullException(nameof(info));
            }

            info.AddValue(nameof(Source), Source);
            info.AddValue(nameof(ErrorCode), ErrorCode);
            info.AddValue(nameof(ErrorMessage), ErrorMessage);
            info.AddValue(nameof(InnerErrors), InnerErrors);
            info.AddValue(nameof(StackTrace), StackTrace);
        }
    }
}

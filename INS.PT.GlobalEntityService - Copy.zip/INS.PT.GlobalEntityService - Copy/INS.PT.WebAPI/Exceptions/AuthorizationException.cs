﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Exceptions
{
    /// <summary>
    /// AuthorizationException
    /// </summary>
    [Serializable]
    public class AuthorizationException : BaseException
    {
        /// <summary>
        /// contructor
        /// </summary>
        public AuthorizationException()
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="message">error message</param>
        public AuthorizationException(string message) : base(message)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="statusCode">http error code</param>
        /// <param name="errorDescription">error message</param>
        public AuthorizationException(HttpStatusCode statusCode, string errorDescription) : base(errorDescription, statusCode)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="message">error message</param>
        /// <param name="statusCode">http error code</param>
        public AuthorizationException(string message, HttpStatusCode statusCode) : base(message, statusCode)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="code">error code</param>
        /// <param name="message">error message</param>
        public AuthorizationException(string code, string message) : base(code, message)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="message">error message</param>
        /// <param name="innerException">The exception that is the cause of the current exception, or a null reference</param>
        public AuthorizationException(string message, Exception innerException) : base(message, innerException)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="code">error code</param>
        /// <param name="message">error message</param>
        /// <param name="statusCode">http error code</param>
        public AuthorizationException(string code, string message, HttpStatusCode statusCode) : base(code, message, statusCode)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="message">error message</param>
        /// <param name="innerException">The exception that is the cause of the current exception, or a null reference</param>
        /// <param name="statusCode">http error code</param>
        public AuthorizationException(string message, Exception innerException, HttpStatusCode statusCode) : base(message, innerException, statusCode)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="errorCode">error code</param>
        /// <param name="errorMessage">error message</param>
        /// <param name="innerErrors">internal errors</param>
        public AuthorizationException(string errorCode, string errorMessage, IEnumerable<InnerError> innerErrors) : base(errorCode, errorMessage, innerErrors)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="errorCode">error code</param>
        /// <param name="errorMessage">error message</param>
        /// <param name="statusCode">http error code</param>
        /// <param name="innerErrors">internal errors</param>
        public AuthorizationException(string errorCode, string errorMessage, HttpStatusCode statusCode, IEnumerable<InnerError> innerErrors) : base(errorCode, errorMessage, statusCode, innerErrors)
        {
        }

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="info">The System.Runtime.Serialization.SerializationInfo that holds the serialized 
        /// object data about the exception being thrown.</param>
        /// <param name="context">The System.Runtime.Serialization.StreamingContext that contains contextual 
        /// information about the source or destination.</param>
        protected AuthorizationException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }

        /// <inheritdoc /> 
        /// <summary>
        /// Changes the values exposed for serialization.
        /// </summary>
        /// <param name="info">The System.Runtime.Serialization.SerializationInfo that holds the serialized 
        /// object data about the exception being thrown.</param>
        /// <param name="context">The System.Runtime.Serialization.StreamingContext that contains contextual 
        /// information about the source or destination.</param>
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
        }
    }
}

﻿namespace INS.PT.WebAPI.IdTranslates
{
    /// <summary>
    /// Module to read a mapping from RDM and use it to change codes.
    /// </summary>
    public interface IRdmHelper
    {
        /// <summary>
        /// Method that will try to read a mapping in a mappings list.
        /// </summary>
        /// <param name="idMapping">mappings list identifier.</param>
        /// <param name="value">value in destination system to search.</param>
        /// <param name="mappedValue">output value that matches value searched.</param>
        /// <returns>true if value was found.</returns>
        bool TryReadSource(string idMapping, string value, out string mappedValue);

        /// <summary>
        /// Method that will try to read a mapping in a mappings list.
        /// </summary>
        /// <param name="idMapping">mappings list identifier.</param>
        /// <param name="value">value in source system to search.</param>
        /// <param name="mappedValue">output value that matches value searched.</param>
        /// <returns>true if value was found.</returns>
        bool TryReadDestination(string idMapping, string value, out string mappedValue);
    }
}

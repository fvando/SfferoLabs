﻿using System.Collections.Generic;

namespace INS.PT.WebAPI.IdTranslates
{
    /// <summary>
    /// object with a code mapping.
    /// </summary>
    public class CodeMapping
    {
        /// <summary>
        /// list identifier
        /// </summary>
        public string IdList { get; set; }

        /// <summary>
        /// element to be mapped
        /// </summary>
        public string IdElement { get; set; }

        /// <summary>
        /// element description.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// list of mappings for each native system
        /// </summary>
        public SynchronizedCollection<string> Mappings { get; set; }

        /// <summary>
        /// Method to check if the mapping is already loaded.
        /// </summary>
        /// <param name="code">object to compare.</param>
        /// <param name="systemIndex">systemIndex to be used.</param>
        /// <param name="nativeId">native value mapping.</param>
        /// <returns>true if mapping exists</returns>
        public bool MappingExists(CodeMapping code, int systemIndex, string nativeId)
        {
            if (code == null)
            {
                return false;
            }

            var mappingMatch = string.IsNullOrEmpty(Mappings[systemIndex])
                    || string.IsNullOrEmpty(nativeId)
                    || Mappings[systemIndex] == nativeId;

            return IdList == code.IdList
                && IdElement == code.IdElement
                && mappingMatch;
        }
    }
}

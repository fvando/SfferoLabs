﻿namespace INS.PT.WebAPI.IdTranslates
{
    /// <summary>
    /// Class that stores a RDM mapping.
    /// </summary>
    public class RdmMapping
    {
        /// <summary>
        /// Mapping list identifier.
        /// </summary>
        public string IdMapping { get; set; }

        /// <summary>
        /// Source code.
        /// </summary>
        public string SourceCode { get; set; }

        /// <summary>
        /// Destination code.
        /// </summary>
        public string DestinationCode { get; set; }
    }
}

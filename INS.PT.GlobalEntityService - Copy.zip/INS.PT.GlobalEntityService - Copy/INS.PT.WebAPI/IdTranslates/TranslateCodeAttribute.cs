﻿using System;

namespace INS.PT.WebAPI.IdTranslates
{
    /// <summary>
    /// Attribute to use for code translations.
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public sealed class TranslateCodeAttribute : Attribute
    {
        /// <summary>
        /// List identifier to use to translate the code
        /// </summary>
        public string IdList { get; set; }

        /// <summary>
        /// Translation direction.
        /// </summary>
        public bool ToNative { get; set; }

        /// <summary>
        /// When decoding to RDM list fill description field with this name.
        /// </summary>
        public string DescriptionField { get; set; }

        /// <summary>
        /// Flag to indicate if description should be filled.
        /// </summary>
        public bool FillDescription { get => !string.IsNullOrEmpty(DescriptionField); }

        /// <summary>
        /// Flag to indicate if source is a mappings list. 
        /// False means that it's a RDM list with mappings for all systems.
        /// </summary>
        public bool UseDirectMappingList { get; set; }
    }
}

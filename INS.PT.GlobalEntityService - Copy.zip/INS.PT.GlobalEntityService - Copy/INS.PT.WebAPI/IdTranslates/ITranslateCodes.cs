﻿namespace INS.PT.WebAPI.IdTranslates
{
    /// <summary>
    /// interface to identify that objects needing translation
    /// </summary>
    interface ITranslateCodes
    {
        /// <summary>
        /// method that executes custom translation on object
        /// </summary>
        /// <param name="codesMapping">object with codes mapping</param>
        /// <param name="idCompany">company identifier</param>
        /// <param name="overrideToNativeAttribute">translation direction to use, or null to assume property default</param>
        void Translate(CodesMapping codesMapping, string idCompany, bool? overrideToNativeAttribute);
    }
}

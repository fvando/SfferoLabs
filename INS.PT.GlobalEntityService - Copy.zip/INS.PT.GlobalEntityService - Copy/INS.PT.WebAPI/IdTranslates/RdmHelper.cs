﻿using INS.PT.WebAPI.BrokerCalls;
using INS.PT.WebAPI.Models.DTO;
using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.IdTranslates
{
    public class RdmHelper : IRdmHelper
    {
        // RDM broker settings
        private const string BrokerWebService = "ageas-api-ReferenceData";
        private const string BrokerMappingsWebMethod = "v1/Mappings";

        private const uint MaxRetries = 3;

        // private properties
        private readonly IBrokerClient _brokerClient;
        private readonly ILog _log;
        private readonly SynchronizedCollection<RdmMapping> _mappings;
        private readonly SynchronizedCollection<ListLoad> _loadedLists;

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="brokerClient">Client to make calls to rest API thru broker.</param>
        public RdmHelper(IBrokerClient brokerClient)
        {
            _log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            _brokerClient = brokerClient;

            _mappings = new SynchronizedCollection<RdmMapping>();
            _loadedLists = new SynchronizedCollection<ListLoad>();
        }


        /// <summary>
        /// Method that will try to read a mapping in a mappings list.
        /// </summary>
        /// <param name="idMapping">mappings list identifier.</param>
        /// <param name="value">value in source system to search.</param>
        /// <param name="mappedValue">output value that matches value searched.</param>
        /// <returns>true if value was found.</returns>
        public bool TryReadDestination(string idMapping, string value, out string mappedValue)
        {
            if (!IsMappingsLoaded(idMapping))
            {
                mappedValue = null;
                return false;
            }

            var mapping = _mappings.FirstOrDefault(m => string.Compare(m.SourceCode, value, StringComparison.InvariantCultureIgnoreCase) == 0);

            mappedValue = mapping?.DestinationCode;

            return mapping != null;
        }

        /// <summary>
        /// Method that will try to read a mapping in a mappings list.
        /// </summary>
        /// <param name="idMapping">mappings list identifier.</param>
        /// <param name="value">value in destination system to search.</param>
        /// <param name="mappedValue">output value that matches value searched.</param>
        /// <returns>true if value was found.</returns>
        public bool TryReadSource(string idMapping, string value, out string mappedValue)
        {
            if (!IsMappingsLoaded(idMapping))
            {
                mappedValue = null;
                return false;
            }

            var mapping = _mappings.FirstOrDefault(m => string.Compare(m.DestinationCode, value, StringComparison.InvariantCultureIgnoreCase) == 0);

            mappedValue = mapping?.SourceCode;

            return mapping != null;
        }


        /// <summary>
        /// Method to try to check if mappings are loaded for the list.
        /// </summary>
        /// <param name="idMapping">list identifier</param>
        /// <returns>true is list is loaded.</returns>
        protected virtual bool IsMappingsLoaded(string idMapping)
        {
            var listMappings = _loadedLists.FirstOrDefault(ll => string.Compare(ll.IdList, idMapping, StringComparison.InvariantCultureIgnoreCase) == 0);

            if (listMappings == null || !listMappings.IsValid)
            {
                // only one request can execute the update of mapping in memory
                    Task.Run(() => LoadListMappingsAsync(idMapping, listMappings))
                        .Wait();
            }

            return _loadedLists.Any(ll => string.Compare(ll.IdList, idMapping, StringComparison.InvariantCultureIgnoreCase) == 0);
        }


        private async Task<bool> LoadListMappingsAsync(string idMapping, ListLoad existingMapping)
        {
            // read mappings for system
            var broker = _brokerClient;
            // method to read list values
            broker.BsWebService = BrokerWebService;
            broker.BsWebmethod = BrokerMappingsWebMethod;


            // read mappings frpom RDM
            var mapping = await broker.RequestAsync<List<MappingValueDto>>(idMapping, null, null, MaxRetries, null);

            if (mapping == null || !mapping.Any())
            {
                _log.Error($"Fail to load mappings for list {idMapping}!");
                return false;
            }

            _log.Debug($"List {idMapping} mapped {mapping.Count}!");

            RemoveOldMappings(existingMapping);
            foreach (var map in mapping)
            {
                _mappings.Add(new RdmMapping
                {
                    IdMapping = idMapping,
                    SourceCode = map.SourceValue,
                    DestinationCode = map.DestinationValue
                });
            }
            _loadedLists.Add(new ListLoad(idMapping));

            return true;
        }

        private void RemoveOldMappings(ListLoad existingMapping)
        {
            // if is an update remove exiting mappings
            if (existingMapping != null)
            {
                var outdatedMappings = _mappings.Where(cm => string.Compare(cm.IdMapping, existingMapping.IdList
                    , StringComparison.InvariantCultureIgnoreCase) == 0).ToList();

                foreach (var mapping in outdatedMappings)
                {
                    _mappings.Remove(mapping);
                }
                _loadedLists.Remove(existingMapping);
            }
        }
    }
}

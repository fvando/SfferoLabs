﻿using INS.PT.WebAPI.BrokerCalls;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.DTO;
using log4net;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.IdTranslates
{
    /// <summary>
    /// Code to load and make translations in entities in model.
    /// </summary>
    public class CodesMapping
    {
        // RDM broker settings
        private const string BrokerWebService = "ageas-api-ReferenceData";
        private const string BrokerReferenceWebMethod = "v1/ReferenceData";
        private const string BrokerMappingWebMethod = "v1/ReferenceData/Mappings";

        private const uint MaxRetries = 3;

        // private properties
        private readonly object codesLock = new object();
        private readonly IBrokerClient _brokerClient;
        private readonly IRdmHelper _rdmHelper;
        private readonly ILog _log;
        private readonly SynchronizedCollection<CodeMapping> _mappings;
        private readonly SynchronizedCollection<ListLoad> _loadedLists;

        /// <summary>
        /// contructor
        /// </summary>
        /// <param name="brokerClient">Client to make calls to rest API thru broker.</param>
        /// <param name="configuration">application configurations.</param>
        /// <param name="rdmHelper">Class to make mappings of codes.</param>
        public CodesMapping(IBrokerClient brokerClient, IConfiguration configuration, IRdmHelper rdmHelper)
        {
            _log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

            // required members to build object
            _brokerClient = brokerClient;
            _rdmHelper = rdmHelper ?? throw new ArgumentNullException(nameof(rdmHelper));

            _mappings = new SynchronizedCollection<CodeMapping>();
            _loadedLists = new SynchronizedCollection<ListLoad>();
            _mappings.Clear();
            _loadedLists.Clear();

            CompanyToSystem.LoadConfiguration(configuration);
        }

        /// <summary>
        /// Method to load all lists to use in translations in parallel.
        /// </summary>
        internal async Task LoadListsAsync()
        {
            var tasks = new List<Task>();

            // define all lists used in application so it can try parallel load
            var listsToLoad = new[]
                { "RDM001", "DC002", "DC003", "DC004", "DC005", "DC007", "DC008", "DC009",
            "RDM007", "RDM005", "DC012", "DC006" };

            // prepare tasks for parallel load
            foreach (var listId in listsToLoad)
            {
                tasks.Add(LoadListMappingsAsync(listId));
            }

            tasks.Add(LoadListMappingsAsync(HeaderParameters.ListIdForCompanies, loadMappings: false));

            await Task.WhenAll(tasks);
        }

        /// <summary>
        /// Method to try to check if mappings are loaded for the list.
        /// </summary>
        /// <param name="idList">list identifier</param>
        /// <returns>true is list is loaded.</returns>
        protected virtual bool IsMappingsLoaded(string idList)
        {
            // if id is empty or no loaded lists execute old parallel load
            if (!_loadedLists.Any() || string.IsNullOrEmpty(idList))
            {
                // only one request can execute the update of mapping in memory
                lock (codesLock)
                {
                    // this will load every list if code runs ok
                    Task.Run(() => LoadListsAsync()).Wait();
                }
            }

            var listMappings = _loadedLists.FirstOrDefault(ll => string.Compare(ll.IdList, idList, StringComparison.InvariantCultureIgnoreCase) == 0);

            if (listMappings == null || !listMappings.IsValid)
            {
                // only one request can execute the update of mapping in memory
                lock (codesLock)
                {
                    Task.Run(() => LoadListMappingsAsync(idList, listMappings,
                        // for RDM002 no need for mappings
                        string.Compare(idList, HeaderParameters.ListIdForCompanies, StringComparison.InvariantCultureIgnoreCase) != 0))
                        .Wait();
                }
            }

            return _loadedLists.Any(ll => string.Compare(ll.IdList, idList, StringComparison.InvariantCultureIgnoreCase) == 0);
        }

        #region Methods for loading codes lists
        /// <summary>
        /// method to load a list mapping into memory
        /// </summary>
        /// <param name="idList">list identifier</param>
        /// <param name="existingMapping">parameter with list loaded with existing mapping.</param>
        private async Task LoadListMappingsAsync(string idList, ListLoad existingMapping = null, bool loadMappings = true)
        {
            var broker = _brokerClient;
            uint retries = MaxRetries;

            // method to read list values
            broker.BsWebService = BrokerWebService;
            broker.BsWebmethod = BrokerReferenceWebMethod;

            broker.AdicionalHeaders.TryAdd("IdCompany", "AGEAS");
            broker.AdicionalHeaders.TryAdd("IdNetwork", "AGEAS");

            var aditionalParameters = new ConcurrentDictionary<string, string>();
            aditionalParameters.TryAdd("pagesize", "1000");

            // try to read list values
            var result = await broker.RequestAsync<ReferenceDataOutputDTO>(idList, aditionalParameters, null, MaxRetries, null);

            while (result == null && retries > 0)
            {
                // fail to load list, execute retry
                _log.Error($"Fail to load list {idList}! Retry: {MaxRetries - retries}");

                --retries;
                result = await broker.RequestAsync<ReferenceDataOutputDTO>(idList, aditionalParameters, null, null);
            }
            if (result == null)
            {
                return;
            }

            _log.Debug($"List {idList} loaded {result.ResultList.Count}!");

            var listElements = new SynchronizedCollection<CodeMapping>();
            foreach (var element in result.ResultList)
            {
                listElements.Add(CreateListCodeElement(idList, element.IdElement, element.Description));
            }

            if (await LoadListMappingsAsync(idList, existingMapping, loadMappings, broker, listElements))
            {
                // load list elements into memory
                foreach (var element in listElements)
                {
                    _mappings.Add(element);
                }

                // add reference that list is loaded
                _loadedLists.Add(new ListLoad(idList));
            }
        }

        private async Task<bool> LoadListMappingsAsync(string idList, ListLoad existingMapping, bool loadMappings, IBrokerClient broker, ICollection<CodeMapping> listElements)
        {
            var mappingsLodaded = false;

            if (loadMappings)
            {
                // change broker settings to load mapping for each system
                broker.BsWebmethod = BrokerMappingWebMethod;

                for (var systemIndex = 0; systemIndex < CompanyToSystem.SystemIds.Length; ++systemIndex)
                {
                    // read mappings for system
                    mappingsLodaded = await ReadMappingAsync(idList, systemIndex, CompanyToSystem.SystemIds[systemIndex], broker, listElements)
                                    || mappingsLodaded;
                    // for lists that have mappings just need one system with mappings to assume all mappings are loaded
                }
            }
            else
            {
                // no mapping to load just clear old data
                mappingsLodaded = true;
            }

            // only clear old data if mappings are load ok or no mappings to load
            if (mappingsLodaded)
            {
                RemoveOldMappings(existingMapping);
            }
            else
            {
                return false;
            }
            return true;
        }

        private void RemoveOldMappings(ListLoad existingMapping)
        {
            // if is an update remove exiting mappings
            if (existingMapping != null)
            {
                var outdatedMappings = _mappings.Where(cm => string.Compare(cm.IdList, existingMapping.IdList
                    , StringComparison.InvariantCultureIgnoreCase) == 0).ToList();

                foreach (var mapping in outdatedMappings)
                {
                    _mappings.Remove(mapping);
                }
                _loadedLists.Remove(existingMapping);
            }
        }

        private async Task<bool> ReadMappingAsync(string idList, int systemIndex, string idSystem, IBrokerClient broker, ICollection<CodeMapping> listElements)
        {
            // read mappings frpom RDM
            var mapping = await broker.RequestAsync<DataMappingOutputDTO>($"{idList}/{idSystem}", null, null, MaxRetries, null);

            if (mapping?.Mappings == null)
            {
                _log.Error($"Fail to load mappings for list {idList} in system {idSystem}!");
                return false;
            }

            _log.Debug($"List {idList} in system {idSystem} mapped {mapping.Mappings.Count}!");

            // run mappings to map to the elements in memory
            foreach (var map in mapping.Mappings)
            {
                // create element
                var mappedElement = CreateListCodeElement(idList, map.IdElement, map.NativeId);

                var existingElement = listElements.FirstOrDefault(element => element.MappingExists(mappedElement, systemIndex, map.NativeId));

                if(existingElement == null)
                {
                    listElements.Add(mappedElement);
                }
                else
                {
                    mappedElement = existingElement;
                }

                mappedElement.Mappings[systemIndex] = map.NativeId;
            }

            return true;
        }

        private CodeMapping CreateListCodeElement(string idList, string idElement, string description)
        {
            var result = new CodeMapping
            {
                IdElement = idElement,
                Description = description,
                IdList = idList,
                Mappings = new SynchronizedCollection<string>()
            };

            // create null value mapping for each system
            for (var a = 0; a < CompanyToSystem.SystemIds.Length; ++a)
            {
                result.Mappings.Add(null);
            }

            return result;
        }
        #endregion

        /// <summary>
        /// Method to read an code list element for the given value.
        /// </summary>
        /// <param name="idList">list identifier where the element should be located.</param>
        /// <param name="value">the value to search for.</param>
        /// <param name="element">for successful match the CodeMapping element.</param>
        /// <returns>true if element if found.</returns>
        public virtual bool TryGetElementFromIdElement(string idList, string value, out CodeMapping element)
        {
            element = null;
            
            // check if mappings are loaded
            if (string.IsNullOrEmpty(idList) || !IsMappingsLoaded(idList))
            {
                return false;
            }

            // find direct element
            var elementMapping = _mappings.FirstOrDefault(m =>
                string.Compare(m.IdList, idList, StringComparison.InvariantCultureIgnoreCase) == 0
                && string.Compare(m.IdElement, value, StringComparison.InvariantCultureIgnoreCase) == 0);
            if (elementMapping != null)
            {
                // element found
                element = elementMapping;
                return true;
            }

            return false;
        }

        /// <summary>
        /// method to execute translation on a object and is properties that implement <seealso cref="ITranslateCodes"/>
        /// </summary>
        /// <param name="modelEntity">entity from model to find properties to translate</param>
        /// <param name="idCompany">company identifier to determine the system</param>
        /// <param name="overrideToNativeAttribute">translation direction to use, or null to assume property default</param>
        public void Translate(object modelEntity, string idCompany, bool? overrideToNativeAttribute)
        {
            if (modelEntity == null)
            {
                return;
            }

            // read type properties
            var typeAttributes = modelEntity.GetType().GetProperties();

            // translate properties that have custom attribute
            foreach (var attrib in typeAttributes.Where(prop => prop.GetCustomAttributes(false).OfType<TranslateCodeAttribute>().Any()))
            {
                // read property value
                var attribValue = attrib.GetValue(modelEntity);

                if (attribValue == null)
                {
                    // skip translation if null
                    continue;
                }

                // get custom attribute value
                var translateAttribute = attrib.GetCustomAttributes(false).OfType<TranslateCodeAttribute>().First();

                if (overrideToNativeAttribute.HasValue)
                {
                    // override attribute setting for direction
                    translateAttribute.ToNative = overrideToNativeAttribute.Value;
                }

                if (translateAttribute.UseDirectMappingList)
                {
                    TranslationForDirectMapping(modelEntity, attrib, attribValue, translateAttribute);
                }
                else
                {
                    TranslationForRdmListWithMappings(modelEntity, idCompany, typeAttributes, attrib, attribValue, translateAttribute);
                }
            }

            // check attributes that implement translation
            foreach (var attrib in typeAttributes)
            {
                if (attrib.PropertyType.GetInterfaces().Contains(typeof(ITranslateCodes)))
                {
                    var translateObject = attrib.GetValue(modelEntity) as ITranslateCodes;

                    translateObject?.Translate(this, idCompany, overrideToNativeAttribute);
                }
            }
        }

        private void TranslationForDirectMapping(object modelEntity, PropertyInfo attrib, object attribValue, TranslateCodeAttribute translateAttribute)
        {
            var foundValue =
                translateAttribute.ToNative
                ? _rdmHelper.TryReadDestination(translateAttribute.IdList, attribValue.ToString(), out var outputValue)
                : _rdmHelper.TryReadSource(translateAttribute.IdList, attribValue.ToString(), out outputValue);

            if (foundValue)
            {
                // set new value for property
                attrib.SetValue(modelEntity, outputValue);
            }
        }

        private void TranslationForRdmListWithMappings(object modelEntity, string idCompany, PropertyInfo[] typeAttributes, PropertyInfo attrib
            , object attribValue, TranslateCodeAttribute translateAttribute)
        {
            // try to read code translation
            if (TryGetMapping(idCompany, translateAttribute, attribValue.ToString(), out var rdmMappedValue, out var outputElement))
            {
                // set new value for property
                attrib.SetValue(modelEntity, rdmMappedValue);

                // check description of code
                TryAddDescription(translateAttribute, outputElement, modelEntity, typeAttributes);
            }
        }


        #region helper methods for translations of codes
        /// <summary>
        /// method to try to map a code to the native system
        /// </summary>
        /// <param name="idCompany">company identifier to determine the native system</param>
        /// <param name="translation">translate parameters</param>
        /// <param name="value">code element to translate</param>
        /// <param name="outputValue">translated value</param>
        /// <returns></returns>
        private bool TryGetMapping(string idCompany, TranslateCodeAttribute translation, string value, out string outputValue, out CodeMapping outputElement)
        {
            // default output value
            outputValue = null;
            outputElement = null;

            // check if mappings are loaded
            if (translation == null || !IsMappingsLoaded(translation.IdList))
            {
                return false;
            }

            // determine the native system
            var systemIndex = CompanyToSystem.GetSystemIndex(idCompany);

            // direction of translation
            if (translation.ToNative)
            {
                // find element
                if (TryGetElementFromIdElement(translation.IdList, value, out outputElement)
                    && outputElement?.Mappings[systemIndex] != null)
                {
                    // translation found
                    outputValue = outputElement.Mappings[systemIndex];
                    return true;
                }
            }
            else
            {
                // find native value
                outputElement = _mappings.FirstOrDefault(m => m.IdList == translation.IdList &&
                    m.Mappings[systemIndex] == value);
                if (outputElement != null)
                {
                    // translation found
                    outputValue = outputElement.IdElement;
                    return true;
                }
            }

            // translation not found
            return false;
        }
        
        /// <summary>
        /// Method to add description to associated field in model entity.
        /// </summary>
        /// <param name="translation">translation configuration.</param>
        /// <param name="outputElement">RDM code element matched.</param>
        /// <param name="modelEntity">entity model object.</param>
        /// <param name="typeAttributes">attributes from model.</param>
        private static void TryAddDescription(TranslateCodeAttribute translation, CodeMapping outputElement,
            object modelEntity, System.Reflection.PropertyInfo[] typeAttributes)
        {
            // check if it can do anything
            if (translation == null || !translation.FillDescription
                || outputElement == null)
            {
                return;
            }

            // get description attribute
            var descriptionAttribute = typeAttributes.FirstOrDefault(a => 
                string.Compare(a.Name, translation.DescriptionField, StringComparison.InvariantCultureIgnoreCase) == 0);

            // update value from RDM list
            descriptionAttribute.SetValue(modelEntity, outputElement.Description);
        }
        #endregion
    }
}

﻿using System;

namespace INS.PT.WebAPI.IdTranslates
{
    /// <summary>
    /// Class to keep track the 
    /// </summary>
    internal class ListLoad
    {
        private const uint CacheLifetimeInHours = 12;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="idList"></param>
        public ListLoad(string idList)
        {
            LoadedAt = DateTime.Now;
            IdList = idList;
        }

        /// <summary>
        /// List identifier.
        /// </summary>
        public string IdList { get; set; }

        /// <summary>
        /// Moment when the list was loaded into memory.
        /// </summary>
        public DateTime LoadedAt { get; private set; }

        /// <summary>
        /// Is the value still valid to be used.
        /// </summary>
        public bool IsValid
        {
            get
            {
                return (DateTime.Now - LoadedAt).TotalHours <= CacheLifetimeInHours;
            }
        }
    }
}

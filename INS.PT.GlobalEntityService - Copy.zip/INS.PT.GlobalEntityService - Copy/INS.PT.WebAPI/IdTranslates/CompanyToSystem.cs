﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;

namespace INS.PT.WebAPI.IdTranslates
{
    /// <summary>
    /// object to store native systems mapped
    /// </summary>
    internal class CompanyToSystem
    {
        private static List<CompanyToSystem> _companyToSystems = new List<CompanyToSystem>();

        /// <summary>
        /// Array of all system id's present in configuration.
        /// </summary>
        public static string[] SystemIds { get; private set; }

        /// <summary>
        /// company identifier
        /// </summary>
        public string IdCompany { get; set; }

        /// <summary>
        /// system identifier
        /// </summary>
        public string IdSystem { get; set; }

        private int MappingIndex { get; set; }

        private bool IsValid => !string.IsNullOrEmpty(IdCompany) && !string.IsNullOrEmpty(IdSystem);

        /// <summary>
        /// Loads from settings all the companies/systems pairs to read source values.
        /// </summary>
        /// <param name="configuration">application configuration</param>
        public static void LoadConfiguration(IConfiguration configuration)
        {
            _companyToSystems.Clear();
            var systemIds = new List<string>();
            var section = configuration?.GetSection("Companies2Systems");

            if (section != null)
            {
                foreach (var item in section.GetChildren())
                {
                    var config = new CompanyToSystem
                    {
                        IdCompany = item.GetValue<string>("IdCompany"),
                        IdSystem = item.GetValue<string>("IdSystem")
                    };

                    if (config.IsValid)
                    {
                        LoadConfig(config, systemIds);
                    }
                }
            }

            SystemIds = systemIds.ToArray();
        }

        private static void LoadConfig(CompanyToSystem config, List<string> systemIds)
        {
            _companyToSystems.Add(config);

            if (!systemIds.Contains(config.IdSystem, StringComparer.InvariantCultureIgnoreCase))
            {
                systemIds.Add(config.IdSystem);
            }

            config.MappingIndex = systemIds.IndexOf(config.IdSystem);
        }

        /// <summary>
        /// Method to determine the idSystem index in the array of mappings.
        /// </summary>
        /// <param name="idCompanyHeader">idCompany header value.</param>
        /// <returns>int value of index</returns>
        public static int GetSystemIndex(string idCompanyHeader)
        {
            var systemPair = _companyToSystems.FirstOrDefault(c =>
                string.Compare(c.IdCompany, idCompanyHeader, StringComparison.InvariantCultureIgnoreCase) == 0)
                
                // if header does not match and is valid pick the first config
                ?? _companyToSystems.First();

            return systemPair.MappingIndex;
        }
    }
}

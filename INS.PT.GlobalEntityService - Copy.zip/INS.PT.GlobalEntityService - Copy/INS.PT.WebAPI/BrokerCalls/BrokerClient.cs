﻿using Flurl;
using Flurl.Http;
using log4net;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.BrokerCalls
{
    public class BrokerClient : IBrokerClient
    {
        private const int MillisecondsDelay = 100;

        private readonly ILog log;
        private readonly IConfiguration configurations;

        private string _httpVerb;

        /// <summary>
        /// Contructor.
        /// </summary>
        /// <param name="configurations">Configurations to try to load settings.</param>
        public BrokerClient(IConfiguration configurations)
        {
            const string BrokerSettingsSection = "Broker";

            log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            AdicionalHeaders = new Dictionary<string, string>();
            ContentType = "application/json";
            HttpVerb = "GET";

            this.configurations = configurations ?? throw new ArgumentNullException(nameof(configurations));

            LoadConfigSettings(BrokerSettingsSection);
        }

        /// <summary>
        /// Reads the broker endpoint and mandatory headers from the configuration section specified.
        /// </summary>
        /// <param name="brokerSettingsSection">section name to read</param>
        public void LoadConfigSettings(string brokerSettingsSection)
        {
            BrokerEndpoint = configurations[$"{brokerSettingsSection}:{nameof(BrokerEndpoint)}"];
            BsSolution = configurations[$"{brokerSettingsSection}:{nameof(BsSolution)}"];
            BsUser = configurations[$"{brokerSettingsSection}:{nameof(BsUser)}"];
            BsWebService = configurations[$"{brokerSettingsSection}:{nameof(BsWebService)}"];
            BsWebmethod = configurations[$"{brokerSettingsSection}:{nameof(BsWebmethod)}"];
        }

        /// <summary>
        /// Broker endpoint to be used for the request.
        /// </summary>
        public string BrokerEndpoint { get; set; }

        /// <summary>
        /// Http verb to be used.
        /// </summary>
        /// <example>GET</example>
        public string HttpVerb { get => _httpVerb.ToUpper(System.Globalization.CultureInfo.InvariantCulture); set => _httpVerb = value; }

        private HttpMethod Verb
        {
            get
            {
                return new HttpMethod(HttpVerb);
            }
        }

        #region Headers
        /// <summary>
        /// Content type header. Defauls to "application/json".
        /// </summary>
        /// <example>application/json</example>
        public string ContentType { get; set; }

        /// <summary>
        /// Solution header to be used.
        /// </summary>
        /// <example>DUCKCREEK</example>
        public string BsSolution { get; set; }

        /// <summary>
        /// User header to be used.
        /// </summary>
        /// <example>\BS\DUCKCREEKD</example>
        public string BsUser { get; set; }

        /// <summary>
        /// Web service header to be used.
        /// </summary>
        /// <example>ageas-api-ReferenceData</example>
        public string BsWebService { get; set; }

        /// <summary>
        /// Web method header to be used.
        /// </summary>
        /// <example>v1/ReferenceData/Mappings</example>
        public string BsWebmethod { get; set; }

        /// <summary>
        /// Property to define aditional headers to be added to the request.
        /// </summary>
        public Dictionary<string, string> AdicionalHeaders { get; set; }
        #endregion


        /// <summary>
        /// Makes a request and read is response.
        /// </summary>
        /// <typeparam name="T">result type of the call to ba made</typeparam>
        /// <param name="additionalRoute">route to add to the broker endpoint</param>
        /// <param name="additionalParameters">aditional query parameters to be added</param>
        /// <param name="requestObject">request body if nedded.</param>
        /// <returns>result object that comes from response body</returns>
        public async Task<T> RequestAsync<T>(string additionalRoute, IDictionary<string, string> additionalParameters, object requestObject, T defaultOutput) where T : new()
        {
            return await RequestAsync(additionalRoute, additionalParameters, requestObject, 0, defaultOutput);
        }

        /// <summary>
        /// Makes a request and read is response.
        /// </summary>
        /// <typeparam name="T">result type of the call to ba made</typeparam>
        /// <param name="additionalRoute">route to add to the broker endpoint</param>
        /// <param name="additionalParameters">aditional query parameters to be added</param>
        /// <param name="requestObject">request body if nedded.</param>
        /// <param name="retries">number of retries to execute.</param>
        /// <returns>result object that comes from response body</returns>
        public async Task<T> RequestAsync<T>(string additionalRoute, IDictionary<string, string> additionalParameters, object requestObject, 
            uint retries, T defaultOutput) where T : new()
        {
            // default result
            var result = defaultOutput;

            // check if can make the call
            if (!OkToMakeCall())
            {
                return result;
            }

            // prepare call
            var guid = Guid.NewGuid();
            var stopwatch = new System.Diagnostics.Stopwatch();

            // build complete url
            var requestUrl = BuildUrl(additionalRoute, additionalParameters);

            // create request object with headers
            var request = CreateRequest(requestUrl);

            // log call to be made
            log.Info($"Request broker client ({guid}) = {JsonConvert.SerializeObject(request)}");


            try
            {
                // make the request to broker
                stopwatch.Start();
                var response = await MakeRequestAsync(requestObject, request);
                stopwatch.Stop();
                log.Info($"Broker request ({guid}) took {stopwatch.ElapsedMilliseconds}ms with IsSuccessStatusCode=" +
                    $"{response.IsSuccessStatusCode}; StatusCode={response.StatusCode}; ReasonPhrase={response.ReasonPhrase}");

                // check response and take actions
                if (response.IsSuccessStatusCode)
                {
                    stopwatch.Restart();
                    var resultString = await response.Content.ReadAsStringAsync();
                    result = JsonConvert.DeserializeObject<T>(resultString);
                    stopwatch.Stop();
                    log.Info($"Broker call ({guid}) took {stopwatch.ElapsedMilliseconds}ms with response: {JsonConvert.SerializeObject(result)}");
                }
                else
                {
                    log.Info($"Broker call ({guid}) result = {result}");
                }
            }
            catch (FlurlHttpException httpError)
            {
                log.Info($"Broker call ({guid}) returned {httpError} => will retry more {retries} times");

                // if there's retries to make
                if (retries > 0)
                {
                    // make a delay for each retry
                    await Task.Delay(MillisecondsDelay);

                    // make a recursive call
                    return await RequestAsync(additionalRoute, additionalParameters, requestObject, --retries, defaultOutput);
                }
            }
            catch (Exception e)
            {
                log.Error($"Unsuccessful call! Status ({guid}) with exception:{e}");
                result = defaultOutput;
            }

            return result;
        }

        private async Task<HttpResponseMessage> MakeRequestAsync(object requestObject, IFlurlRequest request)
        {
            HttpResponseMessage response;

            if (Verb == HttpMethod.Get)
            {
                response = await request.GetAsync();
            }
            else if (Verb == HttpMethod.Put)
            {
                response = await request.PutJsonAsync(requestObject);
            }
            else if (Verb == HttpMethod.Post)
            {
                response = await request.PostJsonAsync(requestObject);
            }
            else if (Verb == HttpMethod.Delete)
            {
                response = await request.DeleteAsync();
            }
            else
            {
                response = await request.SendJsonAsync(Verb, requestObject);
            }

            return response;
        }

        private Url BuildUrl(string additionalRoute, IDictionary<string, string> additionalParameters)
        {
            var requestUrl = BrokerEndpoint
                .AppendPathSegment(additionalRoute);


            // add any query parameters to the request
            if (additionalParameters != null)
            {
                foreach (var param in additionalParameters.Keys)
                {
                    requestUrl.SetQueryParam(param, additionalParameters[param]);
                }
            }

            return requestUrl;
        }

        private IFlurlRequest CreateRequest(Url requestUrl)
        {
            // add commom headers
            var request = requestUrl.WithHeader("Content-Type", ContentType)
                .WithHeader(nameof(BsSolution), BsSolution)
                .WithHeader(nameof(BsUser), BsUser)
                .WithHeader(nameof(BsWebService), BsWebService)
                .WithHeader(nameof(BsWebmethod), BsWebmethod);

            // add aditional headers
            foreach (var addHeader in AdicionalHeaders)
            {
                request = request.WithHeader(addHeader.Key, addHeader.Value);
            }

            return request;
        }

        /// <summary>
        /// validates if broker client is ready to make call.
        /// </summary>
        /// <returns>true if all mandatory headers and configurations are set</returns>
        public bool OkToMakeCall()
        {
            var result = !string.IsNullOrEmpty(BrokerEndpoint)
                && !string.IsNullOrEmpty(HttpVerb)
                && !string.IsNullOrEmpty(BsSolution);

            result = result
                && !string.IsNullOrEmpty(BsUser)
                && !string.IsNullOrEmpty(BsWebService);

            return result
                && !string.IsNullOrEmpty(BsWebmethod);
        }


    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Models;
using log4net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// Base class for the controllers.
    /// </summary>
    public class BaseCore : ControllerBase
    {
        protected const string GenericError = "An Error as occurred. Please try again.";
        protected const string LogReturn = "Return";
        protected const string LogReturnOk = LogReturn + ": OK";
        protected const string LogFinishCall = "Finish Call";

        protected ILog Log;
        protected readonly IHttpContextAccessor httpContext;
        protected readonly IdTranslates.CodesMapping codesMapping;

        /// <summary>
        /// Contructor of the BaseCore.
        /// </summary>
        /// <param name="httpContext">execution context being used.</param>
        public BaseCore(IHttpContextAccessor httpContext, IdTranslates.CodesMapping codesMapping)
        {
            Log = LogManager.GetLogger(typeof(BaseCore));
            this.httpContext = httpContext;
            this.codesMapping = codesMapping;
        }


        #region tipical verb actions
        /// <summary>
        /// Commom call to a repository to take an action.
        /// </summary>
        /// <typeparam name="T">return type</typeparam>
        /// <param name="method">repository method</param>
        /// <param name="notFound">logic to determine not found.</param>
        /// <param name="notFoundReturnObject">not found object to be returned.</param>
        /// <returns>Return of action</returns>
        protected async Task<ActionResult<T>> RepositoryInvokerAsync<T>(Func<Task<T>> method, Func<T, bool> notFound, object notFoundReturnObject)
        {
            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();
                stopwatch.Start();

                // get result from method
                var result = await method?.Invoke();

                stopwatch.Stop();
                Log.Info($"Repository call took {stopwatch.ElapsedMilliseconds}ms");

                // check logic for no results
                var notFoundResult = notFound?.Invoke(result);

                if (!notFoundResult.HasValue || notFoundResult.Value)
                {
                    // no results return path
                    Log.Debug($"Return NotFound {notFoundReturnObject}");
                    return NotFound(notFoundReturnObject);
                }

                Log.Debug($"Return OK {JsonConvert.SerializeObject(result)}");
                return Ok(result);
            }
            catch (BaseException exception)
            {
                // exceptions generated from repositories
                Log.Error(exception);
                return StatusCode((int)exception.StatusCode, exception);
            }
            catch (AggregateException validateErrors)
            {
                // validation error return BadRequest
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception exc)
            {
                // Unexpected exception
                Log.Error(exc);

                return NotFound(
                    new BaseException
                    {
                        ErrorCode = HttpStatusCode.NotFound.ToString(),
                        ErrorMessage = $"{GenericError}"
                    });
            }
        }

        /// <summary>
        /// Method with tipical actions on a GET verb.
        /// </summary>
        /// <typeparam name="T">return type of the GET verb</typeparam>
        /// <param name="method">service method with logic to execute</param>
        /// <returns>result action of the controller with enumerable of T type</returns>
        protected async Task<ActionResult<T>> GetActionAsync<T>(Func<HeaderParameters, Task<T>> method, Func<T, bool> notFound, object notFoundReturnObject,
            IDictionary<string, string> responseHeaders)
        {
            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();
                stopwatch.Start();

                // get header parameters
                var headerParameters = ValidateHeader();

                // get result from method
                var result = await method?.Invoke(headerParameters);

                stopwatch.Stop();
                Log.Info($"Repository call took {stopwatch.ElapsedMilliseconds}ms");

                // check logic for no results
                var notFoundResult = notFound?.Invoke(result);
                if (!notFoundResult.HasValue || notFoundResult.Value)
                {
                    // no results return path
                    Log.Debug($"{LogReturn} GET: NotFound {notFoundReturnObject}");
                    return NotFound(notFoundReturnObject);
                }

                AddResponseHeaders(responseHeaders);

                // Ok result
                Log.Debug($"{LogReturnOk} {JsonConvert.SerializeObject(result)}");

                return Ok(result);
            }
            catch (BaseException processError)
            {
                // error in logic layer return NotFound with Error
                return NotFound(processError);
            }
            catch (AggregateException validateErrors)
            {
                // validation error return BadRequest
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception e)
            {
                // unexpected exception
                Log.Error(e);
                throw;
            }
            finally
            {
                // log exit from method
                Log.Info($"{LogFinishCall} GET");
            }
        }

        /// <summary>
        /// Method with tipical actions on a PUT verb.
        /// </summary>
        /// <typeparam name="T">return type of the PUT verb</typeparam>
        /// <param name="method">service method with logic to execute</param>
        /// <param name="notFound">logic to determine if controller should response a NotFound error.</param>
        /// <param name="notFoundReturnObject">object to return if response is NotFound.</param>
        /// <returns>result action of the controller with object of T type</returns>
        protected async Task<ActionResult<T>> PutActionAsync<T>(Func<HeaderParameters, Task<T>> method, Func<T, bool> notFound, object notFoundReturnObject,
            IDictionary<string, string> responseHeaders)
        {
            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();
                stopwatch.Start();

                // get header parameters
                var headerParameters = ValidateHeader();

                // execute update and get result from method
                var updatedObject = await method?.Invoke(headerParameters);

                stopwatch.Stop();
                Log.Info($"Repository update took {stopwatch.ElapsedMilliseconds}ms");

                // check logic for no results
                var notFoundResult = notFound?.Invoke(updatedObject);
                if (!notFoundResult.HasValue || notFoundResult.Value)
                {
                    // no results return path
                    Log.Debug($"{LogReturn} PUT: NotFound {notFoundReturnObject}");
                    return NotFound(notFoundReturnObject);
                }

                AddResponseHeaders(responseHeaders);

                // Ok result
                Log.Debug($"{LogReturnOk} {JsonConvert.SerializeObject(updatedObject)}");

                return Ok(updatedObject);
            }
            catch (BaseException processError)
            {
                // error in logic layer return NotFound with Error
                return NotFound(processError);
            }
            catch (AggregateException validateErrors)
            {
                // validation error return BadRequest
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception e)
            {
                // unexpected exception
                Log.Error(e);
                throw;
            }
            finally
            {
               // log exit from method
               Log.Info($"{LogFinishCall} PUT");
            }
        }

        /// <summary>
        /// Method with tipical actions on a DELETE verb.
        /// </summary>
        /// <param name="method">service method with logic to execute</param>
        /// <returns>result action of the controller</returns>
        protected async Task<ActionResult> DeleteActionAsync(Func<HeaderParameters, Task<bool>> method)
        {
            try
            {
                // get header parameters
                var headerParameters = ValidateHeader();

                // execute method to delete information
                var result = await method?.Invoke(headerParameters);
                if (result)
                {
                    // information deleted return NoContent
                    Log.Debug($"{LogReturn} DELETE: NoContent");
                    return NoContent();
                }
                else
                {
                    // can't delete return NotFound
                    Log.Debug($"{LogReturn} DELETE: NotFound");
                    return NotFound();
                }
            }
            catch (BaseException processError)
            {
                // error in logic layer return NotFound with Error
                return NotFound(processError);
            }
            catch (AggregateException validateErrors)
            {
                // validation error return BadRequest
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception e)
            {
                // unexpected exception
                Log.Error(e);
                throw;
            }
            finally
            {
                // log exit from method
                Log.Info($"{LogFinishCall} DELETE");
            }
        }
        #endregion


        /// <summary>
        /// Method to get the current URI of execution.
        /// </summary>
        /// <param name="appendPath">Parameter to appended to the result path.</param>
        /// <returns>Uri object with the current URI with the appendPath concatenated.</returns>
        protected Uri GetUri(string appendPath)
        {
            // check current context
            var request = httpContext?.HttpContext?.Request;

            if(request == null)
            {
                return null;
            }

            var path = request.Path;

            // if no local path go to route
            if(string.IsNullOrEmpty(path.Value))
            {
                path = new PathString("/");
            }

            if (appendPath != null)
            {
                path += appendPath.StartsWith('/') ? appendPath : $"/{appendPath}";
            }

            // prepare builder for Uri
            var builder = new UriBuilder
                {
                    Scheme = request.Scheme,
                    Host = request.Host.Host,
                    Path = path,
                    Query = request.QueryString.ToUriComponent()
                };

            if (request.Host.Port.HasValue)
            {
                builder.Port = request.Host.Port.Value;
            }

            return builder.Uri;
        }

        /// <summary>
        /// Method to read header parameters and validate their value.
        /// </summary>
        /// <returns>HeaderParameers object with values.</returns>
        protected virtual HeaderParameters ValidateHeader()
        {
            var headerParameters = new HeaderParameters(codesMapping);
            var errors = new List<ValidationResult>();

            // read header parameters
            headerParameters.IdCompany = ReadHeaderParameter(nameof(headerParameters.IdCompany));
            headerParameters.IdNetwork = ReadHeaderParameter(nameof(headerParameters.IdNetwork));
            headerParameters.BsSolution = ReadHeaderParameter(nameof(headerParameters.BsSolution));
            headerParameters.BsUser = ReadHeaderParameter(nameof(headerParameters.BsUser));

            // execute validation
            Validator.TryValidateObject(headerParameters, new ValidationContext(headerParameters), errors, true);

            if (errors.Any())
            {
                throw new AggregateException(
                       errors.Select((e) => new ValidationException(e.ErrorMessage)));
            }

            return headerParameters;
        }

        /// <summary>
        /// Add/updates headers in response with values
        /// </summary>
        /// <param name="responseHeaders">headers to be added/updated</param>
        protected void AddResponseHeaders(IDictionary<string, string> responseHeaders)
        {
            if (responseHeaders == null)
            {
                return;
            }

            // add response headers
            foreach (var header in responseHeaders)
            {
                if (!Response.Headers.TryAdd(header.Key, header.Value))
                {
                    Response.Headers[header.Key] = header.Value;
                }
            }
        }

        private string ReadHeaderParameter(string parameterName)
        {
            // try to read header value
            if (!string.IsNullOrEmpty(parameterName) && httpContext != null
                && httpContext.HttpContext.Request.Headers.TryGetValue(parameterName, out var headerValues))
            {
                return headerValues.First();
            }

            return null;
        }
    }
}

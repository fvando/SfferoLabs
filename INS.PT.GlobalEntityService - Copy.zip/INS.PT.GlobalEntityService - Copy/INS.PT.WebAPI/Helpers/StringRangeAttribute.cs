﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace INS.PT.WebAPI.Helpers
{
    /// <summary>
    /// Attribute to make string validations.
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public sealed class StringRangeAttribute : ValidationAttribute
    {
        /// <summary>
        /// container of permited values
        /// </summary>
        public string[] AllowableValues { get; set; } = { "No allowable values found" };

        /// <summary>
        /// Method to validate the data.
        /// </summary>
        /// <param name="value">data to validate.</param>
        /// <param name="validationContext">validation context.</param>
        /// <returns>ValidationResult object with result.</returns>
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (AllowableValues?.Contains(value?.ToString()) == true)
            {
                return ValidationResult.Success;
            }

            var msg = string.Join(", ", AllowableValues);
            return new ValidationResult($"Please enter one of the allowable values: {msg}.");
        }
    }
}

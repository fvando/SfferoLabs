﻿using INS.PT.WebAPI.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Helpers
{
    /// <summary>
    /// Internal class to map collections to authorization objects.
    /// </summary>
    internal sealed class MasterOutputCollectionMap : IMasterOutputMapping
    {
        // action to execute to clear collection
        private readonly Action clearMethod;
        // structure name
        private readonly string structureName;

        /// <summary>
        /// Contrutor
        /// </summary>
        /// <param name="structureName">name to map</param>
        /// <param name="action">action to clear</param>
        public MasterOutputCollectionMap(string structureName, Action action)
        {
            this.structureName = structureName;
            clearMethod = action;
        }

        #region IMasterOutputMapping implementation
        [IgnoreDataMember]
        [JsonIgnore]
        string IMasterOutputMapping.StructureName => structureName;

        [IgnoreDataMember]
        [JsonIgnore]
        IEnumerable<IMasterOutputMapping> IMasterOutputMapping.ChildStrutures => Enumerable.Empty<IMasterOutputMapping>();

        public void Clear()
        {
            clearMethod.Invoke();
        }
        #endregion
    }
}

﻿using Ins.PT.WebAPI;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Helpers
{
    public class StructureAccess : IMapped
    {
        public void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(StructureAccess));
        }

        /// <summary>
        /// Name
        /// </summary>
        [Column("STRUCTURE_NAME")]
        public string Name { get; set; }

        /// <summary>
        /// Level
        /// </summary>
        [Column("STRUCTURE_LEVEL")]
        public string Level { get; set; }

        /// <summary>
        /// Order
        /// </summary>
        [Column("STRUCTURE_ORDER")]
        public int Order { get; set; }
    }
}

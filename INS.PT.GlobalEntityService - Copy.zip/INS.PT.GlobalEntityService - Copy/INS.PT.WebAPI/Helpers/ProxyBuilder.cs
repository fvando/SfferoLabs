﻿using System;
using Tecnisys;

namespace INS.PT.WebAPI.Helpers
{
    public static class ProxyBuilder
    {
        private const string Https = "https";

        /// <summary>
        /// Method to create a client proxy object.
        /// </summary>
        /// <returns>MasterEntity proxy client</returns>
        public static MasterEntityClient CreateMasterClient()
        {
            // read enpoint address
            var address = new System.ServiceModel.EndpointAddress(ApplicationSettings.TecnisysServiceEndpoint);

            // commom binding
            var binding = new System.ServiceModel.BasicHttpBinding
            {
                MaxBufferSize = int.MaxValue,
                ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max,
                MaxReceivedMessageSize = int.MaxValue,
                AllowCookies = true
            };

            // check if it is http or https
            if (string.Compare(address.Uri.Scheme, Https, StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = System.ServiceModel.BasicHttpSecurityMode.Transport;
            }

            // return proxy
            return new MasterEntityClient(binding, address);
        }

        /// <summary>
        /// Method to create a client proxy object for AML service.
        /// </summary>
        /// <returns>EntitiesInquiriesServiceClient proxy client</returns>
        public static AmlGet.EntitiesInquiriesServiceClient CreateAmlGetClient()
        {
            GetAmlBindding(out var address, out var binding);

            // return proxy
            return new AmlGet.EntitiesInquiriesServiceClient(binding, address);
        }

        /// <summary>
        /// Method to create a client proxy object for AML service.
        /// </summary>
        /// <returns>EntitiesInquiriesServiceClient proxy client</returns>
        public static AmlSet.EntitiesMaintainServiceClient CreateAmlSetClient()
        {
            GetAmlBindding(out var address, out var binding);

            // return proxy
            return new AmlSet.EntitiesMaintainServiceClient(binding, address);
        }

        private static void GetAmlBindding(out System.ServiceModel.EndpointAddress address, out System.ServiceModel.BasicHttpBinding binding)
        {
            // read enpoint address
            address = new System.ServiceModel.EndpointAddress(ApplicationSettings.AmlServiceEndpoint);

            // commom binding
            binding = new System.ServiceModel.BasicHttpBinding
            {
                MaxBufferSize = int.MaxValue,
                ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max,
                MaxReceivedMessageSize = int.MaxValue,
                AllowCookies = true
            };

            // check if it is http or https
            if (string.Compare(address.Uri.Scheme, Https, StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = System.ServiceModel.BasicHttpSecurityMode.Transport;
            }
        }

        /// <summary>
        /// Method to create a client proxy object for Cogen Entities service.
        /// </summary>
        /// <returns>EntitiesServiceClient proxy client</returns>
        public static Cogen_EntitiesService.EntitiesServiceClient CreateCogenEntitiesClient()
        {
            // read enpoint address
            var address = new System.ServiceModel.EndpointAddress(ApplicationSettings.CogenGetServiceEndpoint);

            // commom binding
            var binding = new System.ServiceModel.BasicHttpBinding
            {
                MaxBufferSize = int.MaxValue,
                ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max,
                MaxReceivedMessageSize = int.MaxValue,
                AllowCookies = true
            };

            // check if it is http or https
            if (string.Compare(address.Uri.Scheme, Https, StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = System.ServiceModel.BasicHttpSecurityMode.Transport;
            }

            // return proxy
            return new Cogen_EntitiesService.EntitiesServiceClient(binding, address);
        }
    }
}

﻿namespace INS.PT.WebAPI.Helpers
{
    public enum MdmOperation
    {
        // insert operation for the entity source
        Insert,
        // update operation for the entity source
        Update,
        // read operation for the entity source
        Get
    }
}

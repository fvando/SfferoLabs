﻿namespace INS.PT.WebAPI.Helpers
{
    /// <summary>
    /// Master sources where entities can be stored/retrived.
    /// </summary>
    public enum MdmMasterSource
    {
        // Tecnisys
        MasterEntityAgeas,

        // Cogen
        MasterEntityOcidental
    }
}

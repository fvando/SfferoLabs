﻿using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models.Elements;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Controllers
{
    ///<inheritdoc /> 
    [Route("v1/[controller]")]
    [ApiController]
    public class GetEntityController : BaseCore
    {
        private readonly IGetEntity repository;

        /// <summary>
        /// Controller constructor.
        /// </summary>
        /// <param name="repository">Repository to use.</param>
        /// <param name="httpContext">Execution context.</param>
        /// <param name="codesMapping">Object to transform codes for different systems</param>
        public GetEntityController(IGetEntity repository, IHttpContextAccessor httpContext, IdTranslates.CodesMapping codesMapping) : base(httpContext, codesMapping)
        {
            this.repository = repository;
        }



        /// <summary>
        /// Method to read the cretidor entities.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/GetEntity/188271511
        ///     
        /// </remarks>
        /// <param name="VatNumber" in="path" required="true" example="188271511">Vat number to search.</param>
        /// <returns>list of inforation found for the entities.</returns>
        [HttpGet("{VatNumber}")]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Entity), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<Entity>> GetEntityByVatNumberAsync([FromRoute]string VatNumber)
        {
            return await GetActionAsync(
                async (headerParameters) =>
                {
                    var results = await repository.EntityByVatNumberAsync(headerParameters, VatNumber);

                    // translate codes from native system
                    results?.Translate(codesMapping, headerParameters.IdCompany, false);

                    return results;
                },
                (result) => result == null,
                new Entity(),
                null
                );
        }
    }
}

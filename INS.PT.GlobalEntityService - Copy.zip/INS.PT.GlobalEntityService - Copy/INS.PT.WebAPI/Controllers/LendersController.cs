﻿using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models.Output;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Controllers
{
    ///<inheritdoc /> 
    [Route("v1/[controller]")]
    [ApiController]
    public class LendersController : BaseCore
    {
        private readonly ILenders repository;


        /// <summary>
        /// Controller constructor.
        /// </summary>
        /// <param name="repository">Repository to use.</param>
        /// <param name="httpContext">Execution context.</param>
        /// <param name="codesMapping">Object to transform codes for different systems</param>
        public LendersController(ILenders repository, IHttpContextAccessor httpContext, IdTranslates.CodesMapping codesMapping) : base(httpContext, codesMapping)
        {
            this.repository = repository;
        }

        /// <summary>
        /// Method to read the cretidor entities.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Lenders
        ///     
        /// </remarks>
        /// <returns>list of inforation found for the entities.</returns>
        [HttpGet]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(IEnumerable<LendersOutput>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<IEnumerable<LendersOutput>>> GetLendersAsync()
        {
            return await RepositoryInvokerAsync(() =>
            {
                var headerParameters = ValidateHeader();

                return repository.GetLendersAsync(headerParameters);
            }, (result) => result == null || !result.Any(), false);
        }
    }
}

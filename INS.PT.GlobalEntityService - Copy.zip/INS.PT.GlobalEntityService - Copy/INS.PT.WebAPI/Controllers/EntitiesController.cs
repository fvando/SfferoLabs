﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Models.Elements;
using INS.PT.WebAPI.Models.Input;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Controllers
{
    [Route("v1/[controller]")]
    [ApiController]
    public class EntitiesController : BaseCore
    {
        private readonly IEntity repository;

        /// <summary>
        /// Controller constructor.
        /// </summary>
        /// <param name="repository">Repository to use.</param>
        /// <param name="httpContext">Execution context.</param>
        /// <param name="codesMapping">Object to transform codes for different systems</param>
        public EntitiesController(IEntity repository, IHttpContextAccessor httpContext, IdTranslates.CodesMapping codesMapping) : base(httpContext, codesMapping)
        {
            this.repository = repository;
        }


        #region base route
        private const string EntityRoute = "{" + nameof(Entity.IdEntity) + "}";

        /// <summary>
        /// Get method to read an entity.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     GET /v1/Entities/10592272
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity object.</returns>
        [HttpGet(EntityRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Entity), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Entity>> GetEntityAsync([FromRoute]EntitiesInput parameters)
        {
            return await GetActionAsync(
                async (headerParameters) =>
                {
                    var results = await repository.GetEntityAsync(headerParameters, parameters);

                    // translate codes from native system
                    results?.Translate(codesMapping, headerParameters.IdCompany, false);

                    return results;
                },
                (result) => result == null,
                new Entity(),
                null
                );
        }

        /// <summary>
        /// Creates a new entity.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     POST /v1/Entities
        ///     
        ///     {
        ///       "idEntity": "",
        ///       "vatNumber": "200123123",
        ///       "isForeignVat": false,
        ///       "countryCode": "1",
        ///       "countryDescription": "Portugal",
        ///         "type": {
        ///             "individual": {
        ///                   "name": "Joana Gomes",
        ///                   "birthdate": "2001-06-14T10:13:27.475Z",
        ///                   "gender": "M",
        ///                   "maritalStatus": "S",
        ///                   "isDeceased": "false",
        ///                   "isSelfEmployee": "false",
        ///                   "placeOfBirth": "Lisboa",
        ///                   "nationalities": [
        ///                     {
        ///                       "nationalityCode": "1",
        ///                       "nationalityDescription": "Portuguesa",
        ///                       "isPrincipal": "true"
        ///                     }
        ///                   ],
        ///                   "honoraryTitles": [
        ///                     {
        ///                       "titleCode": "Sr",
        ///                       "titleDescription": "Senhor",
        ///                       "startDate": "2019-06-14T10:13:27.475Z"
        ///                     }
        ///                   ],
        ///                   "jobs": [],
        ///                   "driverLicences": []
        ///             },
        ///             "company": {
        ///                  "companyName": null,
        ///                  "foundingDate": null,
        ///                  "constitutionCountryCode": null,
        ///                  "constitutionCountryDescription": null,
        ///                  "totalEmployees": null,
        ///                  "grossAnnualRevenue": null,
        ///                  "wagesAmount": null,
        ///                  "equityCapital": null,
        ///                  "companyTypeCode": null,
        ///                  "companyTypeDescription": null,
        ///                  "legalForm": null,
        ///                  "website": null,
        ///                  "organizationContactPoints": []
        ///             }
        ///       },
        ///       "addresses": [
        ///         {
        ///           "sequence": "1",
        ///           "addressType": "1",
        ///           "addressTypeDescription": "Principal",
        ///           "isFiscalAddress": true,
        ///           "formatType": "L",
        ///           "tipology": {
        ///             "postalAddress": {
        ///                 "roadType": "RUA",
        ///                 "roadName": "25 DE ABRIL",
        ///                 "houseNumber": "14",
        ///                 "floorNumber": "8",
        ///                 "doorNumber": "ESQ",
        ///                 "addToAddress": "ODIVELAS",
        ///                 "fullAddress": "Rua 25 de Abril 14 8 esq Odivelas",
        ///                 "locality": "Odivelas"
        ///             },
        ///             "postalBox": null
        ///         },
        ///           "isReturnedForCorrection": false,
        ///           "postalCode": "2590-283",
        ///           "postalCodeDescription": "Torres Vedras",
        ///           "countryCode": "620",
        ///           "countryDescription": "Portugal",
        ///           "georeference": "123.22;43.21"
        ///         }
        ///       ],
        ///       "contacts": {
        ///         "phones": [],
        ///         "emails": []
        ///         },
        ///       "bankAccounts": [],
        ///       "documents": [],
        ///       "caes": [],
        ///       "externalReferences": [],
        ///       "crsFatcas": [],
        ///       "affinityRelations": [],
        ///       "amls": [],
        ///       "profiles": []
        ///     }
        /// </remarks>
        /// <param name="entity">Entity object to be created.</param>
        /// <response code="201">if entity created.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Identifier created and location of new object.</returns>
        [HttpPost]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Entity), StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Entity>> PostEntityAsync([FromBody] Entity entity)
        {
            try
            {
                // get header parameters
                var headerParameters = ValidateHeader();

                // translate codes from native system
                entity?.Translate(codesMapping, headerParameters.IdCompany, true);

                var result = await repository.UpdateEntityAsync(headerParameters, entity);
                if (result == null)
                {
                    return BadRequest();
                }

                // translate codes from native system
                result.Translate(codesMapping, headerParameters.IdCompany, false);

                // add entity headers
                AddResponseHeaders(repository.EntityResponseHeaders);

                Log.Debug($"Return: Created {JsonConvert.SerializeObject(result)}");

                return Created(GetUri(result.IdEntity), result);
            }
            catch (BaseException processError)
            {
                return BadRequest(processError);
            }
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception e)
            {
                Log.Error(e);
                throw;
            }
            finally
            {
                Log.Info($"Finish Call POST");
            }
        }

        /// <summary>
        /// Updates an entity.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities
        ///     
        ///     {
        ///       "idEntity": "10603104",
        ///       "vatNumber": "514418788",
        ///       "isForeignVat": false,
        ///       "countryCode": null,
        ///       "countryDescription": null,
        ///       "type": {
        ///             "individual": {
        ///                   "name": null,
        ///                   "birthdate": null,
        ///                   "gender": null,
        ///                   "maritalStatus": null,
        ///                   "isDeceased": false,
        ///                   "deceasedDate": null,
        ///                   "isSelfEmployee": false,
        ///                   "placeOfBirth": null,
        ///                   "nationalities": [
        ///                     {
        ///                       "nationalityCode": "",
        ///                       "nationalityDescription": null,
        ///                       "isPrincipal": true
        ///                     }
        ///                   ],
        ///                   "honoraryTitles": [],
        ///                   "jobs": [],
        ///                   "driverLicences": []
        ///             },
        ///             "company": {
        ///                  "companyName": "DWNA",
        ///                  "foundingDate": "2017-05-17T00:00:00",
        ///                  "constitutionCountryCode": "1",
        ///                  "constitutionCountryDescription": "Portugal",
        ///                  "totalEmployees": 5,
        ///                  "grossAnnualRevenue": 250000,
        ///                  "wagesAmount": null,
        ///                  "equityCapital": 5001,
        ///                  "companyTypeCode": "1",
        ///                  "companyTypeDescription": "Pequena",
        ///                  "legalForm": null,
        ///                  "website": null,
        ///                  "organizationContactPoints": [
        ///                     {
        ///                         "position": "1",
        ///                         "contactName": "Jorgen",
        ///                         "contacts": [ {
        ///                             "contactTypeCode": "o",
        ///                             "contactTypeDescription": "office",
        ///                             "value": "CEO"
        ///                         },
        ///                         {
        ///                             "contactTypeCode": "e",
        ///                             "contactTypeDescription": "email",
        ///                             "value": "jba@dwna.pt"
        ///                         } ]
        ///                     } ]
        ///             }
        ///       },
        ///       "addresses": [
        ///         {
        ///           "sequence": "1",
        ///           "addressType": "1",
        ///           "addressTypeDescription": "Principal",
        ///           "isFiscalAddress": false,
        ///           "formatType": "L",
        ///           "tipology": {
        ///             "postalAddress": {
        ///                 "roadType": "LUGAR",
        ///                 "roadName": "PEDRINHAS",
        ///                 "houseNumber": null,
        ///                 "floorNumber": null,
        ///                 "doorNumber": null,
        ///                 "addToAddress": null,
        ///                 "fullAddress": " LUGAR  PEDRINHAS",
        ///                 "locality": "Torres Vedras"
        ///             },
        ///             "postalBox": null
        ///           },
        ///           "isReturnedForCorrection": false,
        ///           "postalCode": "2590-022",
        ///           "postalCodeDescription": "Torres Vedras",
        ///           "countryCode": "620",
        ///           "countryDescription": "Portugal",
        ///           "georeference": "123.22;43.21"
        ///         }
        ///       ],
        ///       "contacts": {
        ///         "phones": [],
        ///         "emails": []
        ///         },
        ///       "bankAccounts": [],
        ///       "documents": [],
        ///       "caes": [
        ///         {
        ///           "caeOrderNumber": 0,
        ///           "isPrincipal": true,
        ///           "cae": "45110",
        ///           "caeDescription": "Dummy work",
        ///           "startDate": "2010-01-05T00:00:00",
        ///           "endDate": null,
        ///           "sectorOfActivity": "nearshore",
        ///           "countryCode": "1",
        ///           "countryDescription": "Portugal"
        ///         }
        ///       ],
        ///       "externalReferences": [],
        ///       "crsFatcas": [],
        ///       "affinityRelations": [],
        ///       "amls": [],
        ///       "profiles": []
        ///     }
        /// </remarks>
        /// <param name="entity">Entity object to be updated.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Identifier created and location of new object.</returns>
        [HttpPut]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Entity), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Entity>> PutEntityAsync([FromBody] Entity entity)
        {
            return await PutActionAsync(
                async (headerParameters) => {
                    // translate codes to native system
                    entity.Translate(codesMapping, headerParameters.IdCompany, true);

                    var result = await repository.UpdateEntityAsync(headerParameters, entity);

                    // translate codes from native system
                    result?.Translate(codesMapping, headerParameters.IdCompany, false);

                    return result;
                    },
                (result) => result == null,
                new Entity(),
                repository.EntityResponseHeaders
                );
        }


        /// <summary>
        /// Method to delete an entity.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     DELETE /v1/Entities/2233
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="204">if entity deleted.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpDelete(EntityRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> DeleteEntityAsync([FromRoute]EntitiesInput parameters)
        {
            return await DeleteActionAsync(async (headerParameters) => await Task.Run(() => 
                { return repository.DeleteEntity(headerParameters, parameters); }));
        }
        #endregion


        #region type route
        private const string TypesRoute = EntityRoute + "/" + nameof(Entity.Type);

        /// <summary>
        /// Get method to read an entity types.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/10592272/Type
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity types.</returns>
        [HttpGet(TypesRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Entity.EntityType), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Entity.EntityType>> GetTypeAsync([FromRoute]EntitiesInput parameters)
        {
            return await GetActionAsync(
                async (headerParameters) => {
                    var result = await repository.GetEntityTypeAsync(headerParameters, parameters);

                    // translate codes from native system
                    result?.Translate(codesMapping, headerParameters.IdCompany, false);

                    return result;
                    },
                (result) => result == null || result.Individual == null && result.Company == null,
                new Entity.EntityType(),
                repository.EntityResponseHeaders
                );
        }


        /// <summary>
        /// Updates an entity type.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/10603113/Type
        ///     
        ///     {
        ///             "individual": {
        ///                  "name": "JOANA GOMES",
        ///                  "birthdate": "2001-06-14T10:13:27",
        ///                  "gender": "M",
        ///                  "maritalStatus": "S",
        ///                  "isDeceased": false,
        ///                  "deceasedDate": null,
        ///                  "isSelfEmployee": false,
        ///                  "placeOfBirth": null,
        ///                  "nationalities": [
        ///                     {
        ///                         "nationalityCode": "1",
        ///                         "nationalityDescription": "Portuguesa",
        ///                         "isPrincipal": true
        ///                     }],
        ///                  "honoraryTitles": [
        ///                     {
        ///                         "titleCode": "sr.",
        ///                         "titleDescription": "Senhora",
        ///                         "startDate": "2011-06-11T10:35:31.145Z"
        ///                     }],
        ///                  "jobs": [],
        ///                  "driverLicences": []
        ///             },
        ///             "company": {
        ///                  "companyName": null,
        ///                  "foundingDate": null,
        ///                  "constitutionCountryCode": null,
        ///                  "constitutionCountryDescription": null,
        ///                  "totalEmployees": null,
        ///                  "grossAnnualRevenue": null,
        ///                  "wagesAmount": null,
        ///                  "equityCapital": null,
        ///                  "companyTypeCode": null,
        ///                  "companyTypeDescription": null,
        ///                  "legalForm": null,
        ///                  "website": null,
        ///                  "organizationContactPoints": []
        ///             }
        ///     }
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="type">Person and Company objects to be updated.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Identifier created and location of new object.</returns>
        [HttpPut(TypesRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Entity.EntityType), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Entity.EntityType>> PutTypeAsync([FromRoute]EntitiesInput parameters, [FromBody]Entity.EntityType type)
        {
            return await PutActionAsync(
                async (headerParameters) => {
                    // translate codes to native system
                    type.Translate(codesMapping, headerParameters.IdCompany, true);

                    var result = await repository.UpdateEntityTypeAsync(headerParameters, parameters, type);

                    // translate codes from native system
                    result?.Translate(codesMapping, headerParameters.IdCompany, false);

                    return result;
                    },
                (result) => result == null || result.Individual == null && result.Company == null,
                new Entity.EntityType(),
                repository.EntityResponseHeaders
                );
        }
        #endregion


        #region addresses route
        private const string AddressesRoute = EntityRoute + "/" + nameof(Entity.Addresses);
        private const string AddressRoute = AddressesRoute + "/{idAddress}";

        /// <summary>
        /// Get method to read an entity addresses.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/10592272/Addresses
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity addresses.</returns>
        [HttpGet(AddressesRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(List<Address>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<Address>>> GetAddressesAsync([FromRoute]EntitiesInput parameters)
        {
            return await GetActionAsync(
                async (headerParameters) => {
                    var result = await repository.GetEntityAddressesAsync(headerParameters, parameters);

                    if (result != null)
                    {
                        // translate codes from native system
                        foreach (var address in result)
                        {
                            codesMapping.Translate(address, headerParameters.IdCompany, false);
                        }
                    }

                    return result;
                },
                (result) => !result.Any(),
                new List<Address>(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Get method to read an entity address.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/10592272/Addresses/1
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="idAddress">Address identifier.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity address.</returns>
        [HttpGet(AddressRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Address), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Address>> GetAddressAsync([FromRoute]EntitiesInput parameters, [MaxLength(10)]string idAddress)
        {
            return await GetActionAsync(
                async (headerParameters) => {
                    var result = await repository.GetEntityAddressAsync(headerParameters, parameters, idAddress);

                    // translate codes from native system
                    codesMapping.Translate(result, headerParameters.IdCompany, false);

                    return result;
                    },
                (result) => result == null,
                new Address(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Updates the entity addresses.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/10592272/Addresses
        ///     
        ///     [
        ///       {
        ///         "sequence": "1",
        ///         "addressType": "1",
        ///         "addressTypeDescription": "Principal",
        ///         "isFiscalAddress": true,
        ///         "formatType": "L",
        ///         "tipology": {
        ///           "postalAddress": {
        ///             "roadType": "TRAVESSA",
        ///             "roadName": "DA BOAVISTA",
        ///             "houseNumber": "15",
        ///             "floorNumber": "RC",
        ///             "doorNumber": "DTO",
        ///             "addToAddress": "MOSCAVIDE",
        ///             "fullAddress": "TRAVESSA DA BOAVISTA 15 RC DTO MOSCAVIDE"
        ///             },
        ///           "postalBox": null
        ///         },
        ///         "isReturnedForCorrection": false,
        ///         "postalCode": "2490-100",
        ///         "postalCodeDescription": "ATOUGUIA",
        ///         "countryCode": "620",
        ///         "countryDescription": "Portugal"
        ///       }
        ///     ]
        ///     
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="addresses">Addresses to be updated.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>List of addresses updated.</returns>
        [HttpPut(AddressesRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(List<Address>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<Address>>> PutAddressesAsync([FromRoute]EntitiesInput parameters, [FromBody]IEnumerable<Address> addresses)
        {
            return await PutActionAsync(
                async (headerParameters) => {
                    // translate codes to native system
                    foreach(var address in addresses)
                    {
                        codesMapping.Translate(address, headerParameters.IdCompany, true);
                    }

                    var result = await repository.UpdateEntityAddressesAsync(headerParameters, parameters, addresses);

                    if (result != null)
                    {
                        // translate codes from native system
                        foreach (var address in result)
                        {
                            codesMapping.Translate(address, headerParameters.IdCompany, true);
                        }
                    }

                    return result;
                },
                (result) => !result.Any(),
                new List<Address>(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Updates an entity address.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/10592272/Addresses/1
        ///     
        ///       {
        ///         "sequence": "1",
        ///         "addressType": "1",
        ///         "addressTypeDescription": "Principal",
        ///         "isFiscalAddress": true,
        ///         "formatType": "L",
        ///         "tipology": {
        ///           "postalAddress": {
        ///             "roadType": "TRAVESSA",
        ///             "roadName": "DA BOAVISTA",
        ///             "houseNumber": "15",
        ///             "floorNumber": "RC",
        ///             "doorNumber": "DTO",
        ///             "addToAddress": "MOSCAVIDE",
        ///             "fullAddress": "TRAVESSA DA BOAVISTA 15 RC DTO MOSCAVIDE"
        ///             },
        ///           "postalBox": null
        ///         },
        ///         "isReturnedForCorrection": false,
        ///         "postalCode": "2490-100",
        ///         "postalCodeDescription": "ATOUGUIA",
        ///         "countryCode": "620",
        ///         "countryDescription": "Portugal"
        ///       }
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="address">Address to be updated.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Identifier created and location of new object.</returns>
        [HttpPut(AddressRoute, Name = AddressRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Address), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Address>> PutAddressAsync([FromRoute]EntitiesInput parameters,
            [FromRoute][MaxLength(10)]string idAddress, [FromBody]Address address)
        {
            // confirm object key is set
            address.Sequence = idAddress;
            return await PutActionAsync(
                async (headerParameters) => {
                    // translate codes to native system
                    codesMapping.Translate(address, headerParameters.IdCompany, true);

                    var result = await repository.UpdateEntityAddressAsync(headerParameters, parameters, address);

                    // translate codes from native system
                    codesMapping.Translate(result, headerParameters.IdCompany, true);

                    return result;
                    },
                (result) => result == null,
                new Address(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Method to delete entity addresses.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     DELETE /v1/Entities/10592272/Addresses
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="204">if entity deleted.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpDelete(AddressesRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> DeleteAddressesAsync([FromRoute]EntitiesInput parameters)
        {
            return await DeleteActionAsync(async (headerParameters) => await Task.Run(() => 
                { return repository.DeleteEntityAddresses(headerParameters, parameters, null); }));
        }

        /// <summary>
        /// Method to delete an entity address.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     DELETE /v1/Entities/10592272/Addresses/1
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="idAddress">Address identifier.</param>
        /// <response code="204">if address deleted.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpDelete(AddressRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> DeleteAddressAsync([FromRoute]EntitiesInput parameters,
            [FromRoute][MaxLength(10)]string idAddress)
        {
            return await DeleteActionAsync(async (headerParameters) => await Task.Run(() => 
                { return repository.DeleteEntityAddresses(headerParameters, parameters, idAddress); }));
        }
        #endregion


        #region contacts route
        private const string ContactsRoute = EntityRoute + "/" + nameof(Entity.Contacts);

        /// <summary>
        /// Get method to read an entity contacts.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/10592272/Contacts
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity contacts.</returns>
        [HttpGet(ContactsRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(ContactLists), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<ContactLists>> GetContactsAsync([FromRoute]EntitiesInput parameters)
        {
            return await GetActionAsync(
                async (headerParameters) => {
                    var result = await repository.GetEntityContactListsAsync(headerParameters, parameters);

                    // translate codes from native system
                    result?.Translate(codesMapping, headerParameters.IdCompany, false);

                    return result;
                    },
                (result) => result == null || !result.Emails.Any() && !result.Phones.Any(),
                new ContactLists(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Updates the entity contacts.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/10592272/Contacts
        ///     
        ///     {
        ///         "phones": [
        ///           {
        ///             "phoneIdentifier": "363689",
        ///             "phoneTypeCode": "6",
        ///             "phoneTypeDescription": "Trabalho",
        ///             "phoneNumber": "217943002",
        ///             "isPreferred": false
        ///           }
        ///         ],
        ///         "emails": [
        ///           {
        ///             "emailIdentifier": 1223311,
        ///             "emailTypeCode": "2",
        ///             "emailTypeDescription": "Email Profissional",
        ///             "emailAddress": "ruijorge.silva.externo@ageas.pt",
        ///             "isPreferred": true
        ///           }
        ///         ]
        ///     }
        /// </remarks>
        /// <param name="contacts">ContactLists object to be updated.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Identifier created and location of new object.</returns>
        [HttpPut(ContactsRoute, Name = ContactsRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(ContactLists), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<ContactLists>> PutContactsAsync([FromRoute]EntitiesInput parameters, [FromBody]ContactLists contacts)
        {
            return await PutActionAsync(
                async (headerParameters) => {
                    // translate codes to native system
                    contacts.Translate(codesMapping, headerParameters.IdCompany, true);

                    var result = await repository.UpdateEntityContactListsAsync(headerParameters, parameters, contacts);

                    // translate codes from native system
                    result?.Translate(codesMapping, headerParameters.IdCompany, false);

                    return result;
                },
                (result) => result == null || !result.Emails.Any() && !result.Phones.Any(),
                new ContactLists(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Method to delete entity contacts.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     DELETE /v1/Entities/10592272/Contacts
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="204">if contacts deleted.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpDelete(ContactsRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> DeleteContactsAsync([FromRoute]EntitiesInput parameters)
        {
            return await DeleteActionAsync(async (headerParameters) => await Task.Run(() => 
                { return repository.DeleteContactLists(headerParameters, parameters); }));
        }
        #endregion


        #region phones route
        private const string PhonesRoute = EntityRoute + "/" + nameof(Entity.Contacts.Phones);
        private const string PhoneRoute = PhonesRoute + "/{idPhone}";

        /// <summary>
        /// Get method to read an entity phones.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/10592272/Phones
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity phones.</returns>
        [HttpGet(PhonesRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(List<Phone>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<Phone>>> GetPhonesAsync([FromRoute]EntitiesInput parameters)
        {
            return await GetActionAsync(
                async (headerParameters) => {
                    var result = await repository.GetEntityPhonesAsync(headerParameters, parameters);

                    if (result != null)
                    {
                        // translate codes from native system
                        foreach (var phone in result)
                        {
                            codesMapping.Translate(phone, headerParameters.IdCompany, false);
                        }
                    }

                    return result;
                },
                (result) => !result.Any(),
                new List<Phone>(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Get method to read an entity phone.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/10592272/Phones/1
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="idPhone">Phone identifier.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity phone.</returns>
        [HttpGet(PhoneRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Phone), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Phone>> GetPhoneAsync([FromRoute]EntitiesInput parameters, [MaxLength(35)]string idPhone)
        {
            return await GetActionAsync(
                async (headerParameters) => {
                    var result = await repository.GetEntityPhoneAsync(headerParameters, parameters, idPhone);

                    // translate codes from native system
                    codesMapping.Translate(result, headerParameters.IdCompany, false);

                    return result;
                },
                (result) => result == null,
                new Phone(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Updates the entity phones.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/10592272/Phones
        ///     
        ///     [
        ///         {
        ///             "phoneIdentifier": "12",
        ///             "phoneTypeCode": "6",
        ///             "phoneTypeDescription": "Trabalho",
        ///             "phoneNumber": "217943002",
        ///             "isPreferred": false
        ///         }
        ///     ]
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="phones">List od phones to be updated.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Updated object.</returns>
        [HttpPut(PhonesRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(List<Phone>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<Phone>>> PutPhonesAsync([FromRoute]EntitiesInput parameters, [FromBody]IEnumerable<Phone> phones)
        {
            return await PutActionAsync(
                async (headerParameters) => {
                    // translate codes to native system
                    foreach (var phone in phones)
                    {
                        codesMapping.Translate(phone, headerParameters.IdCompany, true);
                    }

                    var result = await repository.UpdateEntityPhonesAsync(headerParameters, parameters, phones);

                    if (result != null)
                    {
                        // translate codes from native system
                        foreach (var phone in result)
                        {
                            codesMapping.Translate(phone, headerParameters.IdCompany, false);
                        }
                    }

                    return result;
                },
                (result) => !result.Any(),
                new List<Phone>(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Updates an entity phone.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/10592272/Phones/363689
        ///     
        ///     {
        ///         "phoneIdentifier": "12",
        ///         "phoneTypeCode": "6",
        ///         "phoneTypeDescription": "Trabalho",
        ///         "phoneNumber": "217943002",
        ///         "isPreferred": false
        ///     }
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="phone">List od phones to be updated.</param>
        /// <param name="idPhone">Phone identifier.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Updated object.</returns>
        [HttpPut(PhoneRoute, Name = PhoneRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Phone), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Phone>> PutPhoneAsync([FromRoute]EntitiesInput parameters, [FromRoute][MaxLength(35)]string idPhone, [FromBody]Phone phone)
        {
            // confirm object key is set
            phone.PhoneIdentifier = idPhone;
            return await PutActionAsync(
                async (headerParameters) => {
                    // translate codes to native system
                    codesMapping.Translate(phone, headerParameters.IdCompany, true);

                    var result = await repository.UpdateEntityPhoneAsync(headerParameters, parameters, phone);

                    // translate codes from native system
                    codesMapping.Translate(result, headerParameters.IdCompany, false);

                    return result;
                },
                (result) => result == null,
                new Phone(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Method to delete entity phones.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     DELETE /v1/Entities/10592272/Phones
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="204">if phones deleted.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpDelete(PhonesRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> DeletePhonesAsync([FromRoute]EntitiesInput parameters)
        {
            return await DeleteActionAsync(async (headerParameters) => await Task.Run(() => 
                { return repository.DeleteEntityPhones(headerParameters, parameters, null); }));
        }

        /// <summary>
        /// Method to delete an entity phone.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     DELETE /v1/Entities/10592272/Phones/1
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="idPhone">Phone identifier.</param>
        /// <response code="204">if phone deleted.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpDelete(PhoneRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> DeletePhoneAsync([FromRoute]EntitiesInput parameters, [FromRoute][MaxLength(35)]string idPhone)
        {
            return await DeleteActionAsync(async (headerParameters) => await Task.Run(() =>
                { return repository.DeleteEntityPhones(headerParameters, parameters, idPhone); }));
        }
        #endregion


        #region emails route
        private const string EmailsRoute = EntityRoute + "/" + nameof(Entity.Contacts.Emails);
        private const string EmailRoute = EmailsRoute + "/{idEmail}";

        /// <summary>
        /// Get method to read an entity emails.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/10592272/Emails
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity emails.</returns>
        [HttpGet(EmailsRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(List<Email>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<Email>>> GetEmailsAsync([FromRoute]EntitiesInput parameters)
        {
            return await GetActionAsync(
                async (headerParameters) => {
                    var result = await repository.GetEntityEmailsAsync(headerParameters, parameters);

                    if (result != null)
                    {
                        // translate codes from native system
                        foreach (var email in result)
                        {
                            codesMapping.Translate(email, headerParameters.IdCompany, false);
                        }
                    }

                    return result;
                },
                (result) => !result.Any(),
                new List<Email>(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Get method to read an entity email.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/10592272/Emails/1
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="idEmail">Email identifier.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity email.</returns>
        [HttpGet(EmailRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Email), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Email>> GetEmailAsync([FromRoute]EntitiesInput parameters, int idEmail)
        {
            return await GetActionAsync(
                async (headerParameters) =>
                {
                    var result = await repository.GetEntityEmailAsync(headerParameters, parameters, idEmail);

                    // translate codes from native system
                    codesMapping.Translate(result, headerParameters.IdCompany, false);

                    return result;
                },
                (result) => result == null,
                new Email(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Updates the entity emails.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/10592272/Emails
        ///     
        ///     [
        ///         {
        ///             "emailIdentifier": 1223311,
        ///             "emailTypeCode": "2",
        ///             "emailTypeDescription": "Email Profissional",
        ///             "emailAddress": "ruijorge.silva.externo@ageas.pt",
        ///             "isPreferred": true
        ///         }
        ///     ]
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="emails">List of emails to update.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Updated object.</returns>
        [HttpPut(EmailsRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(List<Email>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<Email>>> PutEmailsAsync([FromRoute]EntitiesInput parameters, [FromBody]IEnumerable<Email> emails)
        {
            return await PutActionAsync(
                async (headerParameters) => {
                    // translate codes to native system
                    foreach (var email in emails)
                    {
                        codesMapping.Translate(email, headerParameters.IdCompany, true);
                    }

                    var result = await repository.UpdateEntityEmailsAsync(headerParameters, parameters, emails);

                    if (result != null)
                    {
                        // translate codes from native system
                        foreach (var email in result)
                        {
                            codesMapping.Translate(email, headerParameters.IdCompany, false);
                        }
                    }

                    return result;
                },
                (result) => !result.Any(),
                new List<Email>(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Updates an entity email.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/10592272/Emails/1223311
        ///     
        ///     {
        ///         "emailIdentifier": 1223311,
        ///         "emailTypeCode": "2",
        ///         "emailTypeDescription": "Email Profissional",
        ///         "emailAddress": "ruijorge.silva.externo@ageas.pt",
        ///         "isPreferred": true
        ///     }
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="idEmail">Email identifier.</param>
        /// <param name="email">Entity object to be updated.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Updated object.</returns>
        [HttpPut(EmailRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Email), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Email>> PutEmailAsync([FromRoute]EntitiesInput parameters, [FromRoute]int idEmail, [FromBody]Email email)
        {
            // confirm object key is set
            email.EmailIdentifier = idEmail;
            return await PutActionAsync(
                async (headerParameters) =>
                {
                    // translate codes to native system
                    codesMapping.Translate(email, headerParameters.IdCompany, true);

                    var result = await repository.UpdateEntityEmailAsync(headerParameters, parameters, email);

                    // translate codes from native system
                    codesMapping.Translate(result, headerParameters.IdCompany, false);

                    return result;
                },
                (result) => result == null,
                new Email(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Method to delete entity emails.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     DELETE /v1/Entities/10592272/Emails
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="204">if emails deleted.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpDelete(EmailsRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> DeleteEmailsAsync([FromRoute]EntitiesInput parameters)
        {
            return await DeleteActionAsync(async (headerParameters) => await Task.Run(() =>
                { return repository.DeleteEntityPhones(headerParameters, parameters, null); }));
        }

        /// <summary>
        /// Method to delete an entity email.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     DELETE /v1/Entities/10592272/Emails/1
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="idEmail">Email identifier.</param>
        /// <response code="204">if entity deleted.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpDelete(EmailRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> DeleteEmailAsync([FromRoute]EntitiesInput parameters, [FromRoute]int idEmail)
        {
            return await DeleteActionAsync(async (headerParameters) => await Task.Run(() =>
                { return repository.DeleteEntityEmails(headerParameters, parameters, idEmail); }));
        }
        #endregion


        #region bankAccounts route
        private const string BankAccountsRoute = EntityRoute + "/" + nameof(Entity.BankAccounts);
        private const string BankAccountRoute = BankAccountsRoute + "/{idBankAccount}";

        /// <summary>
        /// Get method to read an entity bank accounts.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/10592272/BankAccounts
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity bank accounts.</returns>
        [HttpGet(BankAccountsRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(List<BankAccount>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<BankAccount>>> GetBankAccountsAsync([FromRoute]EntitiesInput parameters)
        {
            return await GetActionAsync(
                async (headerParameters) => {
                    var result = await repository.GetEntityBankAccountsAsync(headerParameters, parameters);

                    if (result != null)
                    {
                        // translate codes from native system
                        foreach (var bankAccount in result)
                        {
                            codesMapping.Translate(bankAccount, headerParameters.IdCompany, true);
                        }
                    }

                    return result;
                    },
                (result) => !result.Any(),
                new List<BankAccount>(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Get method to read an entity bank account.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/10592272/BankAccounts/1
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="idBankAccount">Bank account identifier.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity bank account.</returns>
        [HttpGet(BankAccountRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(BankAccount), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<BankAccount>> GetBankAccountAsync([FromRoute]EntitiesInput parameters, int idBankAccount)
        {
            return await GetActionAsync(
                async (headerParameters) => {
                    var result = await repository.GetEntityBankAccountAsync(headerParameters, parameters, idBankAccount);

                    // translate codes from native system
                    codesMapping.Translate(result, headerParameters.IdCompany, true);

                    return result;
                    },
                (result) => result == null,
                new BankAccount(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Updates the entity bank accounts.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/10592272/BankAccounts
        ///     
        ///     [
        ///         {
        ///           "sequenceBankAccountNumber": 1,
        ///           "bankAccountNumber": "3635364445",
        ///           "iban": "004593737492772848947"
        ///         },
        ///         {
        ///           "sequenceBankAccountNumber": 2,
        ///           "bankAccountNumber": "345666544",
        ///           "iban": "00459389694877"
        ///         }
        ///     ]
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="bankAccounts">List of bank accounts to update.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Updated object.</returns>
        [HttpPut(BankAccountsRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(List<BankAccount>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<BankAccount>>> PutBankAccountsAsync([FromRoute]EntitiesInput parameters, [FromBody]IEnumerable<BankAccount> bankAccounts)
        {
            return await PutActionAsync(
                async (headerParameters) => {
                    // translate codes to native system
                    foreach(var bankAccount in bankAccounts)
                    {
                        codesMapping.Translate(bankAccount, headerParameters.IdCompany, true);
                    }

                    var result = await repository.UpdateEntityBankAccountsAsync(headerParameters, parameters, bankAccounts);

                    if (result != null)
                    {
                        // translate codes from native system
                        foreach (var bankAccount in result)
                        {
                            codesMapping.Translate(bankAccount, headerParameters.IdCompany, true);
                        }
                    }

                    return result;
                    },
                (result) => !result.Any(),
                new List<BankAccount>(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Updates the entity bank accounts.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/10592272/BankAccounts/1
        ///     
        ///     {
        ///       "sequenceBankAccountNumber": 1,
        ///       "bankAccountNumber": "3635364445",
        ///       "iban": "004593737492772848947"
        ///     }
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="idBankAccount">Bank account identifier.</param>
        /// <param name="bankAccount">List of bank accounts to update.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Updated object.</returns>
        [HttpPut(BankAccountRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(BankAccount), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<BankAccount>> PutBankAccountAsync([FromRoute]EntitiesInput parameters, [FromRoute]int idBankAccount, [FromBody]BankAccount bankAccount)
        {
            // confirm object key is set
            bankAccount.SequenceBankAccountNumber = idBankAccount;
            return await PutActionAsync(
                async (headerParameters) =>
                {
                    // translate codes to native system
                    codesMapping.Translate(bankAccount, headerParameters.IdCompany, true);

                    var result = await repository.UpdateEntityBankAccountAsync(headerParameters, parameters, bankAccount);

                    // translate codes from native system
                    codesMapping.Translate(result, headerParameters.IdCompany, true);

                    return result;
                },
                (result) => result == null,
                new BankAccount(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Method to delete entity bank accounts.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     DELETE /v1/Entities/10592272/BankAccounts
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="204">if bank accounts deleted.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpDelete(BankAccountsRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> DeleteBankAccountsAsync([FromRoute]EntitiesInput parameters)
        {
            return await DeleteActionAsync(async (headerParameters) => await Task.Run(() =>
                { return repository.DeleteEntityBankAccounts(headerParameters, parameters, null); }));
        }

        /// <summary>
        /// Method to delete an entity bank account.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     DELETE /v1/Entities/10592272/BankAccounts/1
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="idBankAccount">Bank account identifier.</param>
        /// <response code="204">if bank account deleted.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpDelete(BankAccountRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> DeleteBankAccountAsync([FromRoute]EntitiesInput parameters, [FromRoute]int idBankAccount)
        {
            return await DeleteActionAsync(async (headerParameters) => await Task.Run(() =>
                { return repository.DeleteEntityBankAccounts(headerParameters, parameters, idBankAccount); }));
        }
        #endregion


        #region documents route
        private const string DocumentsRoute = EntityRoute + "/" + nameof(Entity.Documents);
        private const string DocumentRoute = DocumentsRoute + "/{documentCode}/{idDocument}";

        /// <summary>
        /// Get method to read an entity documents.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/10592272/Documents
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity documents.</returns>
        [HttpGet(DocumentsRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(List<Document>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<Document>>> GetDocumentsAsync([FromRoute]EntitiesInput parameters)
        {
            return await GetActionAsync(
                async (headerParameters) =>
                {
                    var result = await repository.GetEntityDocumentsAsync(headerParameters, parameters);

                    if (result != null)
                    {
                        // translate codes from native system
                        foreach (var doc in result)
                        {
                            codesMapping.Translate(doc, headerParameters.IdCompany, false);
                        }
                    }

                    return result;
                },
                (result) => !result.Any(),
                new List<Document>(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Get method to read an entity document.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/10592272/Documents/cc/122334411
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="documentCode">Document type.</param>
        /// <param name="idDocument">Document identifier.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity document.</returns>
        [HttpGet(DocumentRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Document), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Document>> GetDocumentAsync([FromRoute]EntitiesInput parameters, [MaxLength(3)]string documentCode, [MaxLength(16)]string idDocument)
        {
            return await GetActionAsync(
                async (headerParameters) =>
                {
                    var result = await repository.GetEntityDocumentAsync(headerParameters, parameters, documentCode, idDocument);

                    // translate codes from native system
                    codesMapping.Translate(result, headerParameters.IdCompany, false);

                    return result;
                },
                (result) => result == null,
                new Document(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Updates the entity documents.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/10592272/Documents
        ///     
        ///     [
        ///         {
        ///           "documentTypeCode": "CC",
        ///           "documentTypeDescription": "Cartão Cidadão",
        ///           "documentNumber": "122334411",
        ///           "issueDate": "2017-03-26T00:00:00",
        ///           "expirationDate": "2022-03-26T00:00:00",
        ///           "documentCountryCode": "1",
        ///           "documentCountryDescription": "Portugal"
        ///         }
        ///     ]
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="documents">Document list to update.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Updated object.</returns>
        [HttpPut(DocumentsRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(List<Document>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<Document>>> PutDocumentsAsync([FromRoute]EntitiesInput parameters, [FromBody]ICollection<Document> documents)
        {
            return await PutActionAsync(
                async (headerParameters) =>
                {
                    // translate codes to native system
                    foreach (var doc in documents)
                    {
                        codesMapping.Translate(doc, headerParameters.IdCompany, true);
                    }

                    var result = await repository.UpdateEntityDocumentsAsync(headerParameters, parameters, documents);

                    if (result != null)
                    {
                        // translate codes from native system
                        foreach (var doc in result)
                        {
                            codesMapping.Translate(doc, headerParameters.IdCompany, false);
                        }
                    }

                    return result;
                },
                (result) => !result.Any(),
                new List<Document>(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Updates an entity document.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/10592272/Documents/cc/122334411
        ///     
        ///     {
        ///         "documentTypeCode": "CC",
        ///         "documentTypeDescription": "Cartão Cidadão",
        ///         "documentNumber": "122334411",
        ///         "issueDate": "2017-03-26T00:00:00",
        ///         "expirationDate": "2022-03-26T00:00:00",
        ///         "documentCountryCode": "1",
        ///         "documentCountryDescription": "Portugal"
        ///     }
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="documentCode">Document type.</param>
        /// <param name="idDocument">Document identifier.</param>
        /// <param name="document">Document to update.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Updated object.</returns>
        [HttpPut(DocumentRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Document), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Document>> PutDocumentAsync([FromRoute]EntitiesInput parameters, 
            [FromRoute][MaxLength(3)]string documentCode, [FromRoute][MaxLength(16)] string idDocument, [FromBody]Document document)
        {
            // confirm object key is set
            document.DocumentTypeCode = documentCode;
            document.DocumentNumber = idDocument;
            return await PutActionAsync(
                async (headerParameters) =>
                {
                    // translate codes to native system
                    codesMapping.Translate(document, headerParameters.IdCompany, true);

                    var result = await repository.UpdateEntityDocumentAsync(headerParameters, parameters, document);

                    // translate codes from native system
                    codesMapping.Translate(result, headerParameters.IdCompany, false);

                    return result;
                },
                (result) => result == null,
                new Document(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Method to delete entity documents.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     DELETE /v1/Entities/10592272/Documents
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="204">if documents deleted.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpDelete(DocumentsRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> DeleteDocumentsAsync([FromRoute]EntitiesInput parameters)
        {
            return await DeleteActionAsync(async (headerParameters) => await Task.Run(() =>
                { return repository.DeleteEntityDocuments(headerParameters, parameters, null, null); }));
        }

        /// <summary>
        /// Method to delete an entity document.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     DELETE /v1/Entities/10592272/Documents/cc/122334411
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="documentCode">Document type.</param>
        /// <param name="idDocument">Document identifier.</param>
        /// <response code="204">if document deleted.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpDelete(DocumentRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> DeleteDocumentAsync([FromRoute]EntitiesInput parameters, [FromRoute][MaxLength(3)]string documentCode, [FromRoute][MaxLength(16)]string idDocument)
        {
            return await DeleteActionAsync(async (headerParameters) => await Task.Run(() =>
                { return repository.DeleteEntityDocuments(headerParameters, parameters, documentCode, idDocument); }));
        }
        #endregion


        #region caes route
        private const string CaesRoute = EntityRoute + "/" + nameof(Entity.Caes);
        private const string CaeRoute = CaesRoute + "/{idCae}";

        /// <summary>
        /// Get method to read an entity CAEs.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/6515156/Caes
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity CAEs.</returns>
        [HttpGet(CaesRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(List<Cae>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<Cae>>> GetCaesAsync([FromRoute]EntitiesInput parameters)
        {
            return await GetActionAsync(
                async (headerParameters) => {
                    var result = await repository.GetEntityCaesAsync(headerParameters, parameters);

                    if (result != null)
                    {
                        // translate codes from native system
                        foreach (var cae in result)
                        {
                            codesMapping.Translate(cae, headerParameters.IdCompany, false);
                        }
                    }

                    return result;
                    },
                (result) => !result.Any(),
                new List<Cae>(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Get method to read an entity CAE.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/6515156/Caes/0
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="idCae">Cae identifier.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity CAE.</returns>
        [HttpGet(CaeRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Cae), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Cae>> GetCaeAsync([FromRoute]EntitiesInput parameters, int idCae)
        {
            return await GetActionAsync(
                async (headerParameters) =>
                {
                    var result = await repository.GetEntityCaeAsync(headerParameters, parameters, idCae);

                    // translate codes from native system
                    codesMapping.Translate(result, headerParameters.IdCompany, false);

                    return result;
                },
                (result) => result == null,
                new Cae(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Updates the entity CAEs.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/6515156/Caes
        ///     
        ///     [
        ///         {
        ///           "caeOrderNumber": 1,
        ///           "isPrincipal": true,
        ///           "cae": "47845",
        ///           "caeDescription": "Dummy work",
        ///           "startDate": "2010-01-05T00:00:00"
        ///           "sectorOfActivity": "nearshore",
        ///           "countryCode": "1",
        ///           "countryDescription": "Portugal"
        ///         }
        ///     ]
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="caes">List of CAEs to update.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Updated object.</returns>
        [HttpPut(CaesRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(List<Cae>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<Cae>>> PutCaesAsync([FromRoute]EntitiesInput parameters, [FromBody]IEnumerable<Cae> caes)
        {
            return await PutActionAsync(
                async (headerParameters) =>
                {
                    // translate codes to native system
                    foreach (var cae in caes)
                    {
                        codesMapping.Translate(cae, headerParameters.IdCompany, true);
                    }

                    var result = await repository.UpdateEntityCaesAsync(headerParameters, parameters, caes);

                    if (result != null)
                    {
                        // translate codes from native system
                        foreach (var cae in result)
                        {
                            codesMapping.Translate(cae, headerParameters.IdCompany, false);
                        }
                    }

                    return result;
                },
                (result) => !result.Any(),
                new List<Cae>(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Updates an entity CAE.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/6515156/Caes/0
        ///     
        ///     {
        ///         "caeOrderNumber": 1,
        ///         "isPrincipal": true,
        ///         "cae": "47845",
        ///         "caeDescription": "Dummy work",
        ///         "startDate": "2010-01-05T00:00:00"
        ///         "sectorOfActivity": "nearshore",
        ///         "countryCode": "1",
        ///         "countryDescription": "Portugal"
        ///     }
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="idCae">Cae identifier.</param>
        /// <param name="cae">List of CAEs to update.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Updated object.</returns>
        [HttpPut(CaeRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Cae), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Cae>> PutCaeAsync([FromRoute]EntitiesInput parameters, [FromRoute]int idCae, [FromBody]Cae cae)
        {
            // confirm object key is set
            cae.CaeOrderNumber = idCae;
            return await PutActionAsync(
                async (headerParameters) =>
                {
                    // translate codes to native system
                    codesMapping.Translate(cae, headerParameters.IdCompany, true);

                    var result = await repository.UpdateEntityCaeAsync(headerParameters, parameters, cae);

                    // translate codes from native system
                    codesMapping.Translate(result, headerParameters.IdCompany, false);

                    return result;
                },
                (result) => result == null,
                new Cae(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Method to delete entity CAEs.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     DELETE /v1/Entities/6515156/Caes
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="204">if CAEs deleted.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpDelete(CaesRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> DeleteCaesAsync([FromRoute]EntitiesInput parameters)
        {
            return await DeleteActionAsync(async (headerParameters) => await Task.Run(() =>
                { return repository.DeleteEntityCaes(headerParameters, parameters, null); }));
        }

        /// <summary>
        /// Method to delete an entity CAE.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     DELETE /v1/Entities/6515156/Caes/0
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="idCae">CAE identifier.</param>
        /// <response code="204">if CAE deleted.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpDelete(CaeRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> DeleteCaeAsync([FromRoute]EntitiesInput parameters, [FromRoute]int idCae)
        {
            return await DeleteActionAsync(async (headerParameters) => await Task.Run(() =>
                { return repository.DeleteEntityCaes(headerParameters, parameters, idCae); }));
        }
        #endregion


        #region affinities route
        private const string AffinitiesRoute = EntityRoute + "/affinities";
        private const string AffinityRoute = AffinitiesRoute + "/{idAffinity}";

        /// <summary>
        /// Get method to read an entity affinities.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/10592272/Affinities
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity affinities.</returns>
        [HttpGet(AffinitiesRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(List<AffinityRelation>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<AffinityRelation>>> GetAffinitiesAsync([FromRoute]EntitiesInput parameters)
        {
            return await GetActionAsync(
                async (headerParameters) =>
                {
                    var result = await repository.GetEntityAffinitiesAsync(headerParameters, parameters);

                    if (result != null)
                    {
                        // translate codes from native system
                        foreach (var affinity in result)
                        {
                            codesMapping.Translate(affinity, headerParameters.IdCompany, false);
                        }
                    }

                    return result;
                },
                (result) => !result.Any(),
                new List<AffinityRelation>(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Get method to read an entity affinity.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/10592272/Affinities/1
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="idAffinity">Affinitiy identifier.</param>
        /// <response code="200">if found the entity.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The entity affinity.</returns>
        [HttpGet(AffinityRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(AffinityRelation), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<AffinityRelation>> GetAffinityAsync([FromRoute]EntitiesInput parameters, int idAffinity)
        {
            return await GetActionAsync(
                async (headerParameters) =>
                {
                    var result = await repository.GetEntityAffinityAsync(headerParameters, parameters, idAffinity);

                    // translate codes from native system
                    codesMapping.Translate(result, headerParameters.IdCompany, false);

                    return result;
                },
                (result) => result == null,
                new AffinityRelation(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Updates the entity affinities.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/10592272/Affinities
        ///     
        ///     [
        ///         {
        ///           "relationIdentifier": 1,
        ///           "relatedEntityIdentifier": "2233",
        ///           "relationCode": "PA",
        ///           "relationDescription": "Pai"
        ///         }
        ///     ]
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="affinities">Affinities to update.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Updated object.</returns>
        [HttpPut(AffinitiesRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(List<AffinityRelation>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<AffinityRelation>>> PutAffinitiesAsync([FromRoute]EntitiesInput parameters, [FromBody]IEnumerable<AffinityRelation> affinities)
        {
            return await PutActionAsync(
                async (headerParameters) => {
                    // translate codes to native system
                    foreach (var affinity in affinities)
                    {
                        codesMapping.Translate(affinity, headerParameters.IdCompany, true);
                    }

                    var result = await repository.UpdateEntityAffinitiesAsync(headerParameters, parameters, affinities);

                    if (result != null)
                    {
                        // translate codes from native system
                        foreach (var affinity in result)
                        {
                            codesMapping.Translate(affinity, headerParameters.IdCompany, false);
                        }
                    }
                    
                    return result;
                },
                (result) => !result.Any(),
                new List<AffinityRelation>(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Updates an entity affinity relation.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/10592272/Affinities/1
        ///     
        ///     {
        ///         "relationIdentifier": 1,
        ///         "relatedEntityIdentifier": "2233",
        ///         "relationCode": "PA",
        ///         "relationDescription": "Pai"
        ///     }
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="idAffinity">Affinitiy identifier.</param>
        /// <param name="affinity">Affinity relation to update.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Updated object.</returns>
        [HttpPut(AffinityRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(AffinityRelation), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<AffinityRelation>> PutAffinityAsync([FromRoute]EntitiesInput parameters, [FromRoute]int idAffinity, [FromBody]AffinityRelation affinity)
        {
            // confirm object key is set
            affinity.RelationIdentifier = idAffinity;

            return await PutActionAsync(
                async (headerParameters) =>
                {
                    // translate codes to native system
                    codesMapping.Translate(affinity, headerParameters.IdCompany, true);

                    var result = await repository.UpdateEntityAffinityAsync(headerParameters, parameters, affinity);

                    // translate codes from native system
                    codesMapping.Translate(result, headerParameters.IdCompany, false);

                    return result;
                },
                (result) => result == null,
                new AffinityRelation(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Method to delete entity affinities.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     DELETE /v1/Entities/10592272/Affinities
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <response code="204">if affinities deleted.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpDelete(AffinitiesRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> DeleteAffinitiesAsync([FromRoute]EntitiesInput parameters)
        {
            return await DeleteActionAsync(async (headerParameters) => await Task.Run(() =>
                { return repository.DeleteEntityAffinities(headerParameters, parameters, null); }));
        }

        /// <summary>
        /// Method to delete an entity affinity.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     DELETE /v1/Entities/10592272/Affinities/1
        /// </remarks>
        /// <param name="parameters">Key values to get entity.</param>
        /// <param name="idAffinity">Affinity identifier.</param>
        /// <response code="204">if affinity deleted.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpDelete(AffinityRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> DeleteAffinityAsync([FromRoute]EntitiesInput parameters, [FromRoute]int idAffinity)
        {
            return await DeleteActionAsync(async (headerParameters) => await Task.Run(() =>
                { return repository.DeleteEntityAffinities(headerParameters, parameters, idAffinity); }));
        }
        #endregion


        #region marketing route
        private const string MarketingRoute = EntityRoute + "/" + nameof(Entity.MarketingInformation);

        /// <summary>
        /// Gets the marketing asynchronous.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Entities/1453711/MarketingInformation
        /// </remarks>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        [HttpGet(MarketingRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Marketing), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Marketing>> GetMarketingAsync([FromRoute]EntitiesInput parameters)
        {
            return await GetActionAsync(
                (headerParameters) => repository.GetEntityMarketingAsync(headerParameters, parameters),
                (result) => result == null,
                new Marketing(),
                repository.EntityResponseHeaders
                );
        }

        /// <summary>
        /// Puts the marketing asynchronous.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     PUT /v1/Entities/1453711/MarketingInformation
        ///     {
        ///         "occupationalSituationCode": "NA",
        ///         "occupationalSituationDescription": "Não Aplicável",
        ///         "levelOfEducationCode": "NA",
        ///         "levelOfEducationDescription": "Não Aplicável",
        ///         "occupationalGroupCode": "NA",
        ///         "occupationalGroupDescription": "Não Aplicável",
        ///         "source": "449534668",
        ///         "maximumCustomerAutoDiscountPercentage": 0,
        ///         "smsSent": false,
        ///         "isPaperlessAgeas": false
        ///     }
        ///     
        /// </remarks>
        /// <param name="parameters">The parameters.</param>
        /// <param name="marketing">The marketing.</param>
        /// <response code="200">if entity updated.</response>
        /// <response code="404">if not found.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Updated object</returns>
        [HttpPut(MarketingRoute, Name = MarketingRoute)]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(Marketing), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<Marketing>> PutMarketingAsync([FromRoute]EntitiesInput parameters, [FromBody]Marketing marketing)
        {
            return await PutActionAsync(
                (headerParameters) => repository.UpdateEntityMarketingAsync(headerParameters, parameters, marketing),
                (result) => result == null,
                new Marketing(),
                repository.EntityResponseHeaders
                );
        }
       #endregion
    }
}

﻿using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Controllers
{
    ///<inheritdoc /> 
    [Route("v1/[controller]")]
    [ApiController]
    public class CrmInformationController : BaseCore
    {
        private readonly ICrmInformation repository;

        /// <summary>
        /// Controller constructor.
        /// </summary>
        /// <param name="repository">Repository to use.</param>
        /// <param name="httpContext">Execution context.</param>
        /// <param name="codesMapping">Object to transform codes for different systems</param>
        public CrmInformationController(ICrmInformation repository, 
            IHttpContextAccessor httpContext, IdTranslates.CodesMapping codesMapping) : base(httpContext, codesMapping)
        {
            this.repository = repository ?? throw new ArgumentNullException(nameof(repository));
        }

        /// <summary>
        /// Registers a competitor product.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     POST /v1/CrmInformation
        ///     
        ///     {
        ///         "idEntity": "100063621",
        ///         "productDescription": "Logo Carro",
        ///         "endDate": "2020-11-24T00:00:00.0000000"
        ///     }
        /// </remarks>
        /// <param name="entityInformation">method parameters to add information to the entity.</param>
        /// <returns>bool value with result of </returns>
        [HttpPost]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<bool>> SetCrmInformation([FromBody] CrmExternalInfoInput entityInformation)
        {
            return await PutActionAsync(
                async (headerParameters) => 
                {
                    var result = await repository.SetInformationAsync(headerParameters, entityInformation);

                    return result;
                },
                (result) => !result,
                false,
                null
                );
        }

        /// <summary>
        /// Get entity information with CRM external information also.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/CrmInformation/9740318
        /// 
        /// </remarks>
        /// <param name="entityInformation">Parameters to read an entity.</param>
        /// <returns>Combined structure with entity information and CRM external information.</returns>
        [HttpGet("{IdEntity}")]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(CrmExternalInfoOutput), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<CrmExternalInfoOutput>> GetCrmInformation([FromRoute]EntitiesInput entityInformation)
        {
            return await GetActionAsync(
                async (headerParameters) => 
                {
                    var result = await repository.GetExternalInformationAsync(headerParameters, entityInformation);

                    // translate codes to native system
                    result?.Translate(codesMapping, headerParameters.IdCompany, false);

                    return result;
                },
                (result) => result?.Entity == null,
                null,
                null
                );
        }
    }
}

﻿using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Controllers
{
    ///<inheritdoc /> 
    [Route("v1/[controller]")]
    [ApiController]
    public class MposInformationController : BaseCore
    {
        private readonly IMposInformation repository;

        /// <summary>
        /// Controller constructor.
        /// </summary>
        /// <param name="repository">Repository to use.</param>
        /// <param name="httpContext">Execution context.</param>
        /// <param name="codesMapping">Object to transform codes for different systems</param>
        public MposInformationController(IMposInformation repository, IHttpContextAccessor httpContext, IdTranslates.CodesMapping codesMapping) : base(httpContext, codesMapping)
        {
            this.repository = repository;
        }

        /// <summary>
        /// Method to read information from a group of Entities.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     POST /v1/MposInformation
        ///     
        ///      {
        ///          "entitiesIds": [
        ///              "10468475",  
        ///              "10592272"
        ///          ]
        ///      }
        ///     
        /// </remarks>
        /// <param name="idEntityList">entity ids to read information.</param>
        /// <returns>list of inforation found for the entities.</returns>
        [HttpPost]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(IEnumerable<MposInformationOutput>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult<IEnumerable<MposInformationOutput>>> GetEntitiesInformationAsync([Required]MposInformationInput idEntityList)
        {
            return await RepositoryInvokerAsync(() =>
            {
                var headerParameters = ValidateHeader();

                return repository.GetMposInformationAsync(headerParameters, idEntityList);
            }, (result) => result == null || !result.Any(), false);
        }
    }
}

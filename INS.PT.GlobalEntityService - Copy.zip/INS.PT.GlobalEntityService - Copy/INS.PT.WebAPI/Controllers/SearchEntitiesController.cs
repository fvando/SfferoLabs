﻿using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Controllers
{
    ///<inheritdoc /> 
    [Route("v1/Entities/search")]
    [ApiController]
    public class SearchEntitiesController : BaseCore
    {
        private readonly ISearchEntity repository;

        /// <summary>
        /// Controller constructor.
        /// </summary>
        /// <param name="repository">Repository to use.</param>
        /// <param name="httpContext">Execution context.</param>
        /// <param name="codesMapping">Object to transform codes for different systems</param>
        public SearchEntitiesController(ISearchEntity repository, IHttpContextAccessor httpContext, IdTranslates.CodesMapping codesMapping) : base(httpContext, codesMapping)
        {
            this.repository = repository;
        }


        /// <summary>
        /// Get method to search an entity.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     POST /Entities/search
        ///         {
        ///           "vatNumber": "213200104"
        ///         }
        /// </remarks>
        /// <param name="parameters">Search parameters.</param>
        /// <response code="200">if found any result.</response>
        /// <response code="404">if no results found.</response>
        /// <response code="400">if any error found or invalid search parameters.</response>
        /// <returns>List of matched entities.</returns>
        [HttpPost]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(SearchEntityOutput), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<SearchEntityOutput>> GetSearchEntitiesAsync([FromBody]SearchEntityInput parameters)
        {
            try
            {
                // get header parameters
                var headerParameters = ValidateHeader();

                var result = await repository.SearchEntityAsync(headerParameters, parameters);

                if (result == null || !result.MatchedEntities.Any())
                {
                    // no results found
                    Log.Debug($"Return: NotFound {JsonConvert.SerializeObject(result)}");
                    return NotFound(result);
                }

                result.Translate(codesMapping, headerParameters.IdCompany, null);

                Log.Debug($"Return: OK {JsonConvert.SerializeObject(result)}");

                return Ok(result);
            }
            catch (BaseException processError)
            {
                // error in logic layer return NotFound with Error
                return NotFound(processError);
            }
            catch (AggregateException validateErrors)
            {
                // validation error return BadRequest
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception e)
            {
                // unexpected exception
                Log.Error(e);
                throw;
            }
            finally
            {
                Log.Info($"Finish Call GET");
            }
        }
    }
}

﻿using System;
using System.Threading.Tasks;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Controllers
{
    [Route("v1/[controller]")]
    [ApiController]
    public class NormalizedController : BaseCore
    {
        private readonly INormalized repository;

        /// <summary>
        /// Controller constructor.
        /// </summary>
        /// <param name="httpContext">Execution context.</param>
        /// <param name="repository">Repository to use to get data.</param>
        /// <param name="codesMapping">Object to transform codes for different systems</param>
        public NormalizedController(INormalized repository, IHttpContextAccessor httpContext, IdTranslates.CodesMapping codesMapping) : base(httpContext, codesMapping)
        {
            this.repository = repository;            
        }

        /// <summary>
        /// Method to normalize a name.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     POST /v1/Normalized/Name
        ///     
        ///     {
        ///         "name": "anTÓnIo MaNUel santos.",
        ///         "birthdate": "2019-06-14T10:13:27.475Z",
        ///         "gender": "M"
        ///     }
        /// </remarks>    
        /// <param name="name">Name to be normalized.</param>
        /// <response code="200">if valid request.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Name normalized object with details.</returns>
        [HttpPost("Name")]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(NormalizedNameOutput), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<NormalizedNameOutput>> PostNormalizedNameAsync([FromBody]NormalizedNameInput name)
        {
            try
            {
                // get header parameters
                var headerParameters = ValidateHeader();

                codesMapping.Translate(name, headerParameters.IdCompany, null);

                var result = await Task.Run(() => repository.GetNormalizedName(name));

                Log.Debug($"Return: OK {JsonConvert.SerializeObject(result)}");

                return Ok(result);
            }
            catch (AggregateException validateErrors)
            {
                // validation error return BadRequest
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception e)
            {
                // unexpected exception
                Log.Error(e);
                throw;
            }
            finally
            {
                Log.Info($"Finish Call POST");
            }
        }

        /// <summary>
        /// Normalizes an address.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     POST /v1/Normalized/Address
        ///     
        ///     {
        ///        "roadType": "Rua",
        ///        "roadName": "25 de Abril",
        ///        "houseNumber": "3",
        ///        "floorNumber": "3",
        ///        "doorNumber": "g",
        ///        "addToAddress": "Bairro 1974",
        ///        "locality": "torres vedras",
        ///        "postalCode": "2560-253",
        ///        "postalCodeDescription": "Torres Vedras"
        ///     }
        /// </remarks>
        /// <param name="address">The address to be normalized.</param>
        /// <response code="200">if valid request.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>Address normalized object.</returns>
        [HttpPost("Address")]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(NormalizedAddressOutput), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<NormalizedAddressOutput>> PostNormalizedAddressAsync([FromBody]NormalizedAddressInput address)
        {
            try
            {
                // get header parameters
                ValidateHeader();

                var result = await Task.Run(() => repository.GetNormalizedAddress(address));

                Log.Debug($"Return: OK {JsonConvert.SerializeObject(result)}");

                return Ok(result);
            }
            catch (BaseException processError)
            {
                // error in logic layer return BadRequest with Error
                return BadRequest(processError);
            }
            catch (AggregateException validateErrors)
            {
                // validation error return BadRequest
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception e)
            {
                // unexpected exception
                Log.Error(e);
                throw;
            }
            finally
            {
                Log.Info($"Finish Call POST");
            }
        }
    }
}

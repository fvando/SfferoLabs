﻿using System.Threading.Tasks;
using INS.PT.WebAPI.Models.Input;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace INS.PT.WebAPI.Controllers
{
    ///<inheritdoc /> 
    [Route("v1/[controller]")]
    [ApiController]
    public class NotificationsController : BaseCore
    {
        private readonly INotifications repository;

        /// <summary>
        /// Controller constructor.
        /// </summary>
        /// <param name="repository">Repository to use.</param>
        /// <param name="httpContext">Execution context.</param>
        /// <param name="codesMapping">Object to transform codes for different systems</param>
        public NotificationsController(INotifications repository, IHttpContextAccessor httpContext, IdTranslates.CodesMapping codesMapping) : base(httpContext, codesMapping)
        {
            this.repository = repository;
        }

        /// <summary>
        /// Method to notify that entity is updated in system.
        /// </summary>
        /// <param name="parameters">entity identifier.</param>
        /// <returns>true if update has been done successfully</returns>
        /// <example>1233</example>
        [HttpPut]
        [Consumes("application/json", "application/xml")]
        [Produces("application/json", "application/xml")]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<bool>> PutSetNotificationAsync([FromBody]EntityNotificationInput parameters)
        {
            return await RepositoryInvokerAsync(() =>
            {
                var headerParameters = ValidateHeader();
                return repository.SetNotificationDoneAsync(headerParameters, parameters.IdEntity, parameters.Source);
            }, (result) => false, false);
        }
    }
}

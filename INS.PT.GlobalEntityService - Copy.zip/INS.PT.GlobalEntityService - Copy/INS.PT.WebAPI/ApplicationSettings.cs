﻿using Microsoft.Extensions.Configuration;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// Application settings.
    /// </summary>
    public static class ApplicationSettings
    {
        /// <summary>
        /// Application name.
        /// </summary>
        public static string ApplicationName { get; private set; }

        /// <summary>
        /// Tecnisys web service URL.
        /// </summary>
        public static string TecnisysServiceEndpoint { get; private set; }

        /// <summary>
        /// Aml web service URL.
        /// </summary>
        public static string AmlServiceEndpoint { get; private set; }

        /// <summary>
        /// Cogen web service URL.
        /// </summary>
        public static string CogenGetServiceEndpoint { get; private set; }

        /// <summary>
        /// Axis solution value.
        /// </summary>
        public static string AxisSolution { get; private set; }

        /// <summary>
        /// Axis user value.
        /// </summary>
        public static string AxisUser { get; private set; }

        /// <summary>
        /// Method to load settings from configuration.
        /// </summary>
        /// <param name="config">Configuration where settings reside.</param>
        public static void SetSettings(IConfiguration config)
        {
            if(config == null)
            {
                return;
            }

            ApplicationName = config["ApplicationSettings:ApplicationName"];

            TecnisysServiceEndpoint = config["Services:TechnisysUrl"];
            AmlServiceEndpoint = config["Services:AmlUrl"];
            CogenGetServiceEndpoint = config["Services:CogenGetUrl"];
            AxisSolution = config["ApplicationSettings:ApplicationAxisSolution"];
            AxisUser = config["ApplicationSettings:ApplicationAxisUser"];
        }
    }
}

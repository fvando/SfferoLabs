﻿namespace INS.PT.WebAPI
{
    /// <summary>
    /// Swagger configuration
    /// </summary>
    public static class SwaggerConfiguration
    {
        /// <summary>
        /// <para>Foo API v1</para>
        /// </summary>
        public static string EndpointDescription => "GlobalEntity v1";

        /// <summary>
        /// <para>/swagger/v1/swagger.json</para>
        /// </summary>
        public static string Endpoint =>  "../swagger/v1/swagger.json";

        /// <summary>
        /// <para>v1</para>
        /// </summary>
        public static string DocNameVersion => "v1";

        /// <summary>
        /// <para>Foo API</para>
        /// </summary>
        public static string DocInfoTitle => "GlobalEntity API ";

        /// <summary>
        /// <para>v1</para>
        /// </summary>
        public static string DocInfoVersion => "v1";

        /// <summary>
        /// <para>Foo Api - Sample Web API in ASP.NET Core 3.1</para>
        /// </summary>
        public static string DocInfoDescription => "GlobalEntity Api v1";
    }
}

﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// Generic extension methods.
    /// </summary>
    public static class Extensions
    {
        /// <summary>
        /// Serializes the object to XML.
        /// </summary>
        /// <typeparam name="T">Object type to be serialized.</typeparam>
        /// <param name="toSerialize">Object to serialize.</param>
        /// <returns>xml string with object content.</returns>
        public static string SerializeObjectToXml<T>(this T toSerialize) where T : class
        {
            // validate input parameters
            if (toSerialize == null)
            {
                throw new ArgumentNullException(nameof(toSerialize));
            }

            if (IsDefault(toSerialize))
            {
                return null;
            }

            try
            {
                // prepare objects to make serialization
                var xmlSerializer = new XmlSerializer(toSerialize.GetType());

                // try to serialize using XmlSerializer
                using (StringWriter textWriter = new StringWriter())
                {
                    xmlSerializer.Serialize(textWriter, toSerialize);
                    return textWriter.ToString();
                }
            }
            catch (InvalidOperationException)
            {
                // objects with internal properties generate this exception, try convert JSON to XML
                var jsonString = JsonConvert.SerializeObject(toSerialize);
                var xDoc = JsonConvert.DeserializeXmlNode(jsonString, nameof(toSerialize));
                return XDocument.Parse(xDoc.OuterXml).ToString();
            }
        }

        // to validate input parameters
        private static bool IsDefault<T>(T value)
        {
            return object.Equals(value, default(T));
        }
    }
}

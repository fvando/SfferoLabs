﻿using INS.PT.WebAPI.Models;
using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Filters
{
    /// <summary>
    /// Class to add header parameters to the requests.
    /// </summary>
    /// <seealso cref="Swashbuckle.AspNetCore.SwaggerGen.IOperationFilter" />
    public class HeaderParametersFilter : IOperationFilter
    {
        private const string ObjectType = "string";

        /// <summary>
        /// Applies new parameters to the specified operation.
        /// </summary>
        /// <param name="operation">The operation.</param>
        /// <param name="context">The context.</param>
        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            // validate parameters
            if (operation == null)
            {
                // no operation no need to add parameters
                return;
            }

            // check if exists a collection of parameters
            operation.Parameters ??= new List<OpenApiParameter>();

            // add IdCompany
            AddParameter(operation.Parameters, nameof(HeaderParameters.IdCompany), "Company Id.", "AGEAS");
            // add IdNetwork
            AddParameter(operation.Parameters, nameof(HeaderParameters.IdNetwork), "Network id.", "AGEAS");
            // add bsSolution
            AddParameter(operation.Parameters, nameof(HeaderParameters.BsSolution), "Broker Solution", "DUCKCREEK");
            // add bsUser
            AddParameter(operation.Parameters, nameof(HeaderParameters.BsUser), "Broker User", "\\BS\\DUCKCREEKD");
        }

        private void AddParameter (ICollection<OpenApiParameter> parameters, string name, string description, string defaultValue)
        {
            parameters.Add(
                new OpenApiParameter
                {
                    Name = name,
                    In = ParameterLocation.Header,
                    Required = true,
                    Description = description,
                    Schema = new OpenApiSchema
                    {
                        Type = ObjectType,
                        Example = new OpenApiString(defaultValue)
                    }                    
                });
        }
    }
}

﻿using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using log4net;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Threading.Tasks;
using Tecnisys;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// notifications repository
    /// </summary>
    public class NotificationsRepository : INotifications
    {
        // properties
        private readonly ILog log;
        private readonly IMasterEntity masterEntityService;

        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        public bool CallsExternalService => false;

        /// <summary>
        /// constructor for unit tests
        /// </summary>
        public NotificationsRepository(IMasterEntity masterEntityService)
        {
            log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            this.masterEntityService = masterEntityService ?? Helpers.ProxyBuilder.CreateMasterClient();
        }

        /// <summary>
        /// constructor
        /// </summary>
        public NotificationsRepository() : this(null)
        { }

        /// <summary>
        /// Method to set notification done in Entity
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="idEntity">entity identifier</param>
        /// <returns></returns>
        public Task<bool> SetNotificationDoneAsync(HeaderParameters headerParameters, string idEntity, string source)
        {
            // validate parameters
            if (headerParameters == null)
            {
                throw new ArgumentNullException(nameof(headerParameters));
            }
            return NotificationsDoneAsync(headerParameters, idEntity, source);
        }

        private async Task<bool> NotificationsDoneAsync(HeaderParameters headerParameters, string idEntity, string source)
        {
            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();

                // log input
                log.Info($"Tecnisys call to SetNotificationDoneAsync: source={headerParameters.BsSolution}; dni={idEntity}");
                stopwatch.Start();

                // make call to master entity
                var tecnisysResult = await masterEntityService.SetNotificationDoneAsync(
                    new SetNotificationDoneRequest
                    {
                        // commom parameters from config
                        AxisValues = new AxisValues
                        {
                            Solution = ApplicationSettings.AxisSolution,
                            User = headerParameters.BsUser
                        },
                        source = source,
                        dni = idEntity
                    });
                stopwatch.Stop();

                // log results
                log.Info($"master execution took {stopwatch.ElapsedMilliseconds}ms to execute");
                log.Info($"Tecnisys result: {JsonConvert.SerializeObject(tecnisysResult)}");

                // prepare result
                var tecnisysValues = tecnisysResult.SetNotificationDoneResult;

                // read errors to return
                if (!tecnisysValues.Results && tecnisysValues.Errors.Length > 0)
                {
                    var error = tecnisysValues.Errors[0];
                    // if there are errors then register exception with all errors
                    throw new CanonicalException($"{error.Type}-{error.Code}", error.Message, HttpStatusCode.BadRequest,
                        from e in tecnisysValues.Errors
                        select new BaseException.InnerError
                        {
                            ErrorCode = e.Code,
                            ErrorMessage = e.Message
                        });
                }

                // return response object
                return tecnisysValues.Results;
            }
            catch (BaseException pe)
            {
                // error processing information
                log.Info(pe);
                throw;
            }
            catch (Exception e)
            {
                // unexpected error
                log.Error($"Error reading information from Tecnisys! Error: {e}");

                return false;
            }
        }
    }
}

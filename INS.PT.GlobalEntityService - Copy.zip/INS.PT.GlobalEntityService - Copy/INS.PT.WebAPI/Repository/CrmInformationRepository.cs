﻿using Dapper;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Elements.Crm;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;
using log4net;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    /// Crm information repository.
    /// </summary>
    public class CrmInformationRepository : ICrmInformation
    {
        // properties
        private readonly IEntity entityRepository;
        private readonly ISourceAndResultsMapping mappingRepository;
        private readonly IDbconnectioncs connection;
        private readonly ILog log;

        // database calls methods
        private readonly Func<ExternalInfo, OracleDynamicParameters, IDbConnection, string, Task> getExternalInformation;
        private readonly Func<IDbConnection, string, OracleDynamicParameters, Task<int>> setConcurrentProductProcedure;

        // constants
        private const string CrmDatabase = "masterentity";
        private const string CrmPackage = "pkg_pes_api";
        private const string GetExternalInformation = "pro_get_crm_external_data";
        private const string SetConcurrentProduct = "fun_set_prod_concorrencia";

        // procedure parameters constants
        private const int OutputSize = 1000;

        // output parameters
        public static readonly string OutputParameterForErrorCode = "p_cderro";
        public static readonly string OutputParameterForErrorDescription = "p_dserro";
        public static readonly string OutputParameterSemaphore = "p_semaforo";

        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        public bool CallsExternalService => false;

        /// <summary>
        /// Constructor for injection.
        /// </summary>
        /// <param name="connection">database connection</param>
        public CrmInformationRepository(IDbconnectioncs connection, IEntity entityRepository, ISourceAndResultsMapping mappingRepository)
            : this(connection, entityRepository, mappingRepository, null, null)
        { }

        /// <summary>
        /// Constructor for unit test.
        /// </summary>
        /// <param name="connection">database connection</param>
        /// <param name="getExternalInformation">function to read information from database.</param>
        /// <param name="setConcurrentProductProcedure">function to insert data into database.</param>
        public CrmInformationRepository(IDbconnectioncs connection, IEntity entityRepository, ISourceAndResultsMapping mappingRepository,
            Func<ExternalInfo, OracleDynamicParameters, IDbConnection, string, Task> getExternalInformation,
            Func<IDbConnection, string, OracleDynamicParameters, Task<int>> setConcurrentProductProcedure)
        {
            // build objects
            log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

            // injected dependencies
            this.connection = connection ?? throw new ArgumentNullException(nameof(connection));
            this.entityRepository = entityRepository ?? throw new ArgumentNullException(nameof(entityRepository));
            this.mappingRepository = mappingRepository ?? throw new ArgumentNullException(nameof(mappingRepository));

            // test dependencies
            this.getExternalInformation = getExternalInformation 
                ?? ((crmExternalInformation, dbParameters, conn, command) => ReadRecordsetsAsync(crmExternalInformation, dbParameters, conn, command));
            this.setConcurrentProductProcedure = setConcurrentProductProcedure
                ?? ((conn, command, dyParam) => SqlMapper.ExecuteAsync(conn, command, dyParam, commandType: CommandType.StoredProcedure));
        }


        /// <summary>
        /// Method to read entity and CRM information.
        /// </summary>
        /// <param name="headerParameters">Header parameters.</param>
        /// <param name="parameters">Parameters to get an entity.</param>
        /// <returns>Object with entity information and CRM external information</returns>
        public Task<CrmExternalInfoOutput> GetExternalInformationAsync(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            // validate input parameters
            if (headerParameters == null)
            {
                throw new ArgumentNullException(nameof(headerParameters));
            }

            if (parameters == null)
            {
                throw new ArgumentNullException(nameof(parameters));
            }

            return GetExternalInformationActionsAsync(headerParameters, parameters);
        }

        /// <summary>
        /// Method to save information to the Entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters.</param>
        /// <param name="parameters">Entity key and information to save.</param>
        /// <returns>true if information is saved successfully.</returns>
        public Task<bool> SetInformationAsync(HeaderParameters headerParameters, CrmExternalInfoInput parameters)
        {
            // validate input parameters
            if (headerParameters == null)
            {
                throw new ArgumentNullException(nameof(headerParameters));
            }

            if (parameters == null)
            {
                throw new ArgumentNullException(nameof(parameters));
            }

            return SetInformationActionsAsync(headerParameters, parameters);
        }


        private async Task<bool> SetInformationActionsAsync(HeaderParameters headerParameters, CrmExternalInfoInput parameters)
        {
            try
            {
                // read source and mappings
                mappingRepository.ReadSourceAndSctructure(headerParameters, Helpers.MdmOperation.Get);

                if (mappingRepository.NativeMaster != Helpers.MdmMasterSource.MasterEntityAgeas)
                {
                    throw new BusinessException("Operation not available for this Master!");
                }

                var stopwatch = new System.Diagnostics.Stopwatch();
                var dbParameters = new OracleDynamicParameters();

                // input parameters
                dbParameters.Add("p_source", OracleDbType.Varchar2, ParameterDirection.Input, mappingRepository.IdSource);
                dbParameters.Add("p_dni", OracleDbType.Varchar2, ParameterDirection.Input, parameters.IdEntity);
                dbParameters.Add("P_NORDER", OracleDbType.Int32, ParameterDirection.Input, parameters.Order);
                dbParameters.Add("P_DSPROD", OracleDbType.Varchar2, ParameterDirection.Input, parameters.ProductDescription);
                dbParameters.Add("P_DTFIM", OracleDbType.Date, ParameterDirection.Input, parameters.EndDate);

                // output parameters
                dbParameters.Add(OutputParameterForErrorCode, OracleDbType.Int32, ParameterDirection.Output);
                dbParameters.Add(OutputParameterForErrorDescription, OracleDbType.Varchar2, ParameterDirection.Output, null, OutputSize);

                var conn = connection.Connection;
                var command = $"{CrmDatabase}.{CrmPackage}.{SetConcurrentProduct}";

                // log call to database and values
                log.Info($"database call to {command}");
                dbParameters.Log(log, ParameterDirection.Input);

                stopwatch.Start();
                var recordsAffected = await setConcurrentProductProcedure.Invoke(conn, command, dbParameters);
                stopwatch.Stop();

                dbParameters.Log(log, ParameterDirection.Output);

                log.Info($"database took {stopwatch.ElapsedMilliseconds}ms to execute and affected {recordsAffected} records.");

                // read output parameters
                var errorCode = dbParameters.GetInt(OutputParameterForErrorCode, 0);
                if (errorCode != 0)
                {
                    throw new BaseException(errorCode.ToString(System.Globalization.CultureInfo.InvariantCulture),
                        dbParameters.GetString(OutputParameterForErrorDescription));
                }

                return true;
            }
            catch (BaseException pe)
            {
                // errors from DB, log and throw
                log.Info(pe);
            }

            return false;
        }

        private async Task<CrmExternalInfoOutput> GetExternalInformationActionsAsync(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            var result = new CrmExternalInfoOutput();

            try
            {
                // read source and mappings
                mappingRepository.ReadSourceAndSctructure(headerParameters, Helpers.MdmOperation.Get);

                // make task to call to entity repository
                var entityTask = entityRepository.GetEntityAsync(headerParameters, parameters);
                // make task to get information from database
                var crmTask = GetCrmInformationAsync(parameters);

                // parallel call to both sources
                await Task.WhenAll(new Task[] { entityTask, crmTask });

                // get results to output
                result.Entity = await entityTask;
                result.CrmExternalInformation = await crmTask;
            }
            catch (BaseException pe)
            {
                // errors from DB, log and throw
                log.Info(pe);
                throw;
            }

            return result;
        }

        private async Task<ExternalInfo> GetCrmInformationAsync(EntitiesInput parameters)
        {
            try
            {
                var crmExternalInformation = new ExternalInfo();
                var dbParameters = new OracleDynamicParameters();

                // input parameters
                dbParameters.Add("p_source", OracleDbType.Varchar2, ParameterDirection.Input, mappingRepository.IdSource);
                dbParameters.Add("p_dni", OracleDbType.Varchar2, ParameterDirection.Input, parameters.IdEntity);

                // output parameters
                dbParameters.Add(OutputParameterSemaphore, OracleDbType.Varchar2, ParameterDirection.Output, null, OutputSize);
                dbParameters.Add("p_campanhas", OracleDbType.RefCursor, ParameterDirection.Output);
                dbParameters.Add("p_produtos_concorrencia", OracleDbType.RefCursor, ParameterDirection.Output);
                dbParameters.Add("p_ultimo_contacto", OracleDbType.RefCursor, ParameterDirection.Output);
                dbParameters.Add("p_proposta_apresentar", OracleDbType.RefCursor, ParameterDirection.Output);
                dbParameters.Add(OutputParameterForErrorCode, OracleDbType.Int32, ParameterDirection.Output);
                dbParameters.Add(OutputParameterForErrorDescription, OracleDbType.Varchar2, ParameterDirection.Output, null, OutputSize);

                var conn = connection.Connection;
                var command = $"{CrmDatabase}.{CrmPackage}.{GetExternalInformation}";

                // log call to database and values
                log.Info($"database call to {command}");
                dbParameters.Log(log, ParameterDirection.Input);

                await getExternalInformation.Invoke(crmExternalInformation, dbParameters, conn, command);

                // log information from database
                log.Info($"CRM external information read:  {JsonConvert.SerializeObject(crmExternalInformation)}");

                // clear data not authorized
                mappingRepository.RemoveUnauthorizedData(crmExternalInformation);

                return crmExternalInformation;
            }
            catch (BaseException e)
            {
                // unexpected error
                log.Error($"Error reading crm information from package! Error: {e}");
            }

            return null;
        }
        
        private async Task ReadRecordsetsAsync(ExternalInfo crmExternalInformation, OracleDynamicParameters dbParameters, IDbConnection conn, string command)
        {
            var stopwatch = new System.Diagnostics.Stopwatch();

            stopwatch.Start();
            using (var gridResults = await SqlMapper.QueryMultipleAsync(conn, command, dbParameters, commandType: CommandType.StoredProcedure))
            {
                stopwatch.Stop();

                dbParameters.Log(log, ParameterDirection.Output);

                log.Info($"database took {stopwatch.ElapsedMilliseconds}ms to execute");

                //read output parameters
                var errorCode = dbParameters.GetInt(OutputParameterForErrorCode, 0);

                if (errorCode != 0 || gridResults == null)
                {
                    throw new BaseException(errorCode.ToString(System.Globalization.CultureInfo.InvariantCulture),
                        dbParameters.GetString(OutputParameterForErrorDescription));
                }
                
                // read output parameter
                crmExternalInformation.Semaphore = dbParameters.GetString(OutputParameterSemaphore, null);

                // read campaigns
                crmExternalInformation.Campaigns = await gridResults.ReadAsync<Campaign>();

                // read concurrent products
                crmExternalInformation.CompetionProducts = await gridResults.ReadAsync<CompetionProduct>();

                // read last contacts
                crmExternalInformation.LastContacts = await gridResults.ReadAsync<LastContact>();

                // read proposals
                crmExternalInformation.Proposals = await gridResults.ReadAsync<Proposal>();
            }
        }
    }
}

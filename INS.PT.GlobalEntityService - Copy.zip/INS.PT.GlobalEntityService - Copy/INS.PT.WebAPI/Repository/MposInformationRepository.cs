﻿using AutoMapper;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;
using log4net;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Tecnisys;

namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    ///  Mpos Information repository.
    /// </summary>
    public class MposInformationRepository : IMposInformation
    {
        private const int PortuguesePhoneNumbersLength = 9;

        // properties
        private readonly ILog log;
        private readonly IMasterEntity masterEntityService;
        private readonly IMapper mapper;
        private readonly ISourceAndResultsMapping mappingRepository;

        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        public bool CallsExternalService => false;

        /// <summary>
        /// constructor for unit tests
        /// </summary>
        public MposInformationRepository(IMasterEntity masterEntityService, ISourceAndResultsMapping mappingRepository, IMapper mapper)
        {
            log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            this.masterEntityService = masterEntityService ?? Helpers.ProxyBuilder.CreateMasterClient();
            this.mappingRepository = mappingRepository ?? throw new ArgumentNullException(nameof(mappingRepository));
            this.mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="mappingRepository"></param>
        public MposInformationRepository(ISourceAndResultsMapping mappingRepository, IMapper mapper) : this(null, mappingRepository, mapper)
        {
        }

        /// <summary>
        /// Method to read Mpos information from MasterEntity service.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="idEntityList">list of entiy ids.</param>
        /// <returns>list of information found in master entity</returns>
        public Task<IEnumerable<MposInformationOutput>> GetMposInformationAsync(HeaderParameters headerParameters, MposInformationInput idEntityList)
        {
            // validate parameters
            if (headerParameters == null)
            {
                throw new ArgumentNullException(nameof(headerParameters));
            }
            if (idEntityList?.EntitiesIds == null || !idEntityList.EntitiesIds.Any())
            {
                throw new ArgumentNullException(nameof(idEntityList));
            }

            return MposInformationAsync(headerParameters, idEntityList);
        }


        /// <summary>
        /// Method to read Mpos information from MasterEntity service.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="idEntityList">list of entiy ids.</param>
        /// <returns>list of information found in master entity</returns>
        private async Task<IEnumerable<MposInformationOutput>> MposInformationAsync(HeaderParameters headerParameters, MposInformationInput idEntityList)
        {
            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();
                // read source and mappings
                mappingRepository.ReadSourceAndSctructure(headerParameters, Helpers.MdmOperation.Get);

                if (mappingRepository.NativeMaster != Helpers.MdmMasterSource.MasterEntityAgeas)
                {
                    throw new BusinessException("Operation not available for this Master!");
                }

                // log input
                log.Info($"Tecnisys call to MposInformationAsync => {JsonConvert.SerializeObject(idEntityList)}");
                stopwatch.Start();

                // make call to master entity
                var tecnisysResult = await masterEntityService.GetMposDataAsync(
                    new GetMposDataRequest
                    {
                        // commom parameters from config
                        AxisValues = new AxisValues
                        {
                            Solution = ApplicationSettings.AxisSolution,
                            User = headerParameters.BsUser
                        },
                        source = mappingRepository.IdSource,
                        dniList = idEntityList.EntitiesIds.ToArray()
                    });
                stopwatch.Stop();

                // log results
                log.Info($"master execution took {stopwatch.ElapsedMilliseconds}ms to execute with result: {JsonConvert.SerializeObject(tecnisysResult)}");

                // prepare result
                var tecnisysValues = tecnisysResult.GetMposDataResult;

                // read errors to return
                if (tecnisysValues.EntitiesInformation == null || tecnisysValues.Errors.Length > 0)
                {
                    if (tecnisysValues.Errors.Length > 0)
                    {
                        var error = tecnisysValues.Errors[0];
                        // if there are errors then register exception with all errors
                        throw new CanonicalException($"{error.Type}-{error.Code}", error.Message, HttpStatusCode.NotFound,
                            from e in tecnisysValues.Errors
                            select new BaseException.InnerError
                            {
                                ErrorCode = e.Code,
                                ErrorMessage = e.Message
                            });
                    }

                    throw new CanonicalException("Null response", "Null response", HttpStatusCode.NotFound);
                }

                var result = mapper.Map<IEnumerable<MposInformationOutput>>(tecnisysValues.EntitiesInformation);

                ClearPhoneNumbers(result);

                // return response object
                return result;
            }
            catch (BaseException pe)
            {
                // error processing information
                log.Info(pe);
                throw;
            }
            catch (System.ServiceModel.CommunicationException e)
            {
                // unexpected error
                log.Error($"Error reading information from Tecnisys! Error: {e}");

                return null;
            }
        }

        /// <summary>
        /// Mehtod to clear the portuguese callsign from phone numbers.
        /// </summary>
        /// <param name="result">List of information to clear numbers.</param>
        private static void ClearPhoneNumbers(IEnumerable<MposInformationOutput> result)
        {
            // check for the phones that are not with 9 digits
            foreach (var mposInfo in result.Where(i => 
                                    i.PhoneNumber.Length > 0 
                                    && (i.PhoneNumber.Length != PortuguesePhoneNumbersLength || !i.PhoneNumber.StartsWith('9'))))
            {
                if (mposInfo.PhoneNumber.StartsWith("+351", StringComparison.InvariantCultureIgnoreCase)
                    || mposInfo.PhoneNumber.StartsWith("00351", StringComparison.InvariantCultureIgnoreCase))
                {
                    // PT phone number but just leave the 9 right digits
                    mposInfo.PhoneNumber = mposInfo.PhoneNumber.Substring(mposInfo.PhoneNumber.Length - PortuguesePhoneNumbersLength);
                    if(mposInfo.PhoneNumber.StartsWith('9'))
                    {
                        // valid PT number, leave with 9 digits
                        continue;
                    }
                }

                // invalid phone number, just clear
                mposInfo.PhoneNumber = string.Empty;
            }
        }
    }
}

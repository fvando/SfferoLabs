﻿using Dapper;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;
using log4net;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// NormalizedRepository
    /// </summary>
    /// <inheritdoc />
    public class NormalizedRepository : INormalized
    {
        // properties
        private readonly IDbconnectioncs connection;
        private readonly ILog log;

        // database calls methods
        private readonly Func<IDbConnection, string, OracleDynamicParameters, NormalizedNameOutput> normalizedNamePackage;
        private readonly Func<IDbConnection, string, OracleDynamicParameters, int> normalizedAddressPackage;

        // constants
        private const string NormalizeDatabase = "masterentity";
        private const string NormalizePackage = "pkg_pes_api";
        private const string NormalizeNameProcedure = "pro_name_normalization";
        private const string NormalizeAddressProcedure = "pro_address_normalization";

        // procedure parameters constants
        private const int OutputSize = 1000;

        private const string OutputParameterForIsNormalized = "p_isnorm";
        private const string OutputParameterForErrorCode = "p_cderro";
        private const string OutputParameterForErrorDescription = "p_dserro";

        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        public bool CallsExternalService => false;

        /// <summary>
        /// contrutor
        /// </summary>
        /// <param name="connection"></param>
        public NormalizedRepository(IDbconnectioncs connection) : this(connection, null, null)
        { }

        /// <summary>
        /// contrutor to allow unit test.
        /// </summary>
        /// <param name="connection"></param>
        /// <param name="normalizedNameOutputPackage"></param>
        /// <param name="normalizedAddressOutputPackage"></param>
        public NormalizedRepository(IDbconnectioncs connection
            , Func<IDbConnection, string, OracleDynamicParameters, NormalizedNameOutput> normalizedNameOutputPackage
            , Func<IDbConnection, string, OracleDynamicParameters, int> normalizedAddressOutputPackage)
        {
            log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            this.connection = connection ?? throw new ArgumentNullException(nameof(connection));

            // default calls to database
            normalizedNamePackage = normalizedNameOutputPackage 
                ?? ((conn, command, dyParam) => SqlMapper.QueryFirstOrDefault<NormalizedNameOutput>(conn, command, dyParam
                    , commandType: CommandType.StoredProcedure));
            normalizedAddressPackage = normalizedAddressOutputPackage 
                ?? ((conn, command, dyParam) => SqlMapper.Execute(conn, command, dyParam
                    , commandType: CommandType.StoredProcedure));
        }


        /// <summary>
        /// GetNormalizedName
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        ///<inheritdoc /> 
        public NormalizedNameOutput GetNormalizedName(NormalizedNameInput parameters)
        {
            // validate input parameters
            if (parameters == null)
            {
                throw new ArgumentNullException(nameof(parameters));
            }

            var result = new NormalizedNameOutput();

            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();
                var dbParameters = new OracleDynamicParameters();

                // input parameters
                dbParameters.Add("p_name", OracleDbType.Varchar2, ParameterDirection.Input, parameters.Name);
                dbParameters.Add("p_gender", OracleDbType.Varchar2, ParameterDirection.Input, parameters.Gender);
                dbParameters.Add("p_datanasc", OracleDbType.Date, ParameterDirection.Input, parameters.Birthdate);

                // output parameters
                dbParameters.Add("p_result", OracleDbType.RefCursor, ParameterDirection.Output);
                dbParameters.Add(OutputParameterForIsNormalized, OracleDbType.Int32, ParameterDirection.Output);
                dbParameters.Add(OutputParameterForErrorCode, OracleDbType.Int32, ParameterDirection.Output);
                dbParameters.Add(OutputParameterForErrorDescription, OracleDbType.Varchar2, ParameterDirection.Output, null, OutputSize);

                var conn = connection.Connection;
                var command = $"{NormalizeDatabase}.{NormalizePackage}.{NormalizeNameProcedure}";

                // log call to database and values
                log.Info($"database call to {command}");
                dbParameters.Log(log, ParameterDirection.Input);

                stopwatch.Start();
                var normalizedName = normalizedNamePackage.Invoke(conn, command, dbParameters);
                stopwatch.Stop();

                dbParameters.Log(log, ParameterDirection.Output);

                log.Info($"database took {stopwatch.ElapsedMilliseconds}ms to execute");
                if (normalizedName != null)
                {
                    // if record returned method output will be that
                    result = normalizedName;
                }

                // read output parameters
                result.IsNormalized = dbParameters.GetDecimal(OutputParameterForIsNormalized) != 0;
                result.ErrorCode = dbParameters.GetInt(OutputParameterForErrorCode, -1);
                result.ErrorMessage = dbParameters.GetString(OutputParameterForErrorDescription);
            }
            catch (Exception e)
            {
                // unexpected error
                log.Error($"Error reading normalized from package! Error: {e}");

                // reset output return values
                result.IsNormalized = false;
                result.ErrorMessage = $"Error reading normalized from package! Error: {e.Message}";
            }

            return result;
        }

        /// <summary>
        /// GetNormalizedAddress
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        ///<inheritdoc /> 
        public NormalizedAddressOutput GetNormalizedAddress(NormalizedAddressInput parameters)
        {
            // validate input parameters
            if (parameters == null)
            {
                throw new ArgumentNullException(nameof(parameters));
            }

            var result = new NormalizedAddressOutput();

            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();
                var dbParameters = new OracleDynamicParameters();

                // input/output parameters
                dbParameters.Add("p_tipo_via", OracleDbType.Varchar2, ParameterDirection.InputOutput, parameters.RoadType);
                dbParameters.Add("p_nome_via", OracleDbType.Varchar2, ParameterDirection.InputOutput,  parameters.RoadName);
                dbParameters.Add("p_num_policia", OracleDbType.Varchar2, ParameterDirection.InputOutput, parameters.HouseNumber);
                dbParameters.Add("p_andar", OracleDbType.Varchar2, ParameterDirection.InputOutput, parameters.FloorNumber);
                dbParameters.Add("p_porta", OracleDbType.Varchar2, ParameterDirection.InputOutput,  parameters.DoorNumber);
                dbParameters.Add("p_complemento", OracleDbType.Varchar2, ParameterDirection.InputOutput, parameters.AddToAddress);
                dbParameters.Add("p_dslocalidad", OracleDbType.Varchar2, ParameterDirection.InputOutput, parameters.Locality);
                dbParameters.Add("p_cdpostal", OracleDbType.Varchar2, ParameterDirection.InputOutput, parameters.PostalCode);
                dbParameters.Add("p_dspostal", OracleDbType.Varchar2, ParameterDirection.InputOutput, parameters.PostalCodeDescription);

                // output parameters
                dbParameters.Add(OutputParameterForIsNormalized, OracleDbType.Int32, ParameterDirection.Output);
                dbParameters.Add(OutputParameterForErrorCode, OracleDbType.Int32, ParameterDirection.Output);
                dbParameters.Add(OutputParameterForErrorDescription, OracleDbType.Varchar2, ParameterDirection.Output, null, OutputSize);

                var conn = connection.Connection;
                var command = $"{NormalizeDatabase}.{NormalizePackage}.{NormalizeAddressProcedure}";

                // log call to database and values
                log.Info($"database call to {command}");
                dbParameters.Log(log, ParameterDirection.InputOutput);

                stopwatch.Start();
                var recordsAffected = normalizedAddressPackage.Invoke(conn, command, dbParameters);
                stopwatch.Stop();

                log.Debug($"records affected: {recordsAffected}; database took {stopwatch.ElapsedMilliseconds}ms to execute");
                dbParameters.Log(log, ParameterDirection.InputOutput);
                dbParameters.Log(log, ParameterDirection.Output);

                // read output parameters
                var isNormalized = dbParameters.GetDecimal(OutputParameterForIsNormalized);
                var errorCode = dbParameters.GetInt(OutputParameterForErrorCode, -1);
                var errorMessage = dbParameters.GetString(OutputParameterForErrorDescription);

                if (errorCode != 0)
                {
                    // if there was an error then stop filling output object
                    throw new BaseException($"{errorCode}", errorMessage);
                }

                // read input/output parameters
                result.RoadType = dbParameters.GetString("p_tipo_via");
                result.RoadName = dbParameters.GetString("p_nome_via");
                result.HouseNumber = dbParameters.GetString("p_num_policia");
                result.FloorNumber = dbParameters.GetString("p_andar");
                result.DoorNumber = dbParameters.GetString("p_porta");
                result.AddToAddress = dbParameters.GetString("p_complemento");
                result.Locality = dbParameters.GetString("p_dslocalidad");
                result.PostalCode = dbParameters.GetString("p_cdpostal");
                result.PostalCodeDescription = dbParameters.GetString("p_dspostal");
                result.IsNormalized = isNormalized == 0; // when output 0 is normalized
            }
            catch (BaseException pe)
            {
                // error processing information
                log.Info(pe);
                throw;
            }
            catch (Exception e)
            {
                // unexpected error
                log.Error($"Error reading normalized from package! Error: {e}");

                // reset output return values
                result.IsNormalized = false;
            }

            return result;
        }
    }
}

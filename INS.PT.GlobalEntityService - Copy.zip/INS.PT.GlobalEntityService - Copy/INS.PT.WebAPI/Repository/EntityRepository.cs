﻿using System;
using System.Reflection;
using models = INS.PT.WebAPI.Models.Elements;
using INS.PT.WebAPI.Models.Input;
using log4net;
using Newtonsoft.Json;
using INS.PT.WebAPI.Models;
using System.Collections.Generic;
using System.Linq;
using INS.PT.WebAPI.Models.Extensions;
using System.Threading.Tasks;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Interface.Service;

namespace INS.PT.WebAPI
{
    ///<inheritdoc /> 
    public class EntityRepository : IEntity
    {
        private readonly ILog log;
        private readonly IMasterService masterService;
        private readonly ISourceAndResultsMapping mappingRepository;
        private readonly IAmlService amlService;
        private readonly ICogenEntities cogenEntitiesServices;

        private Helpers.MdmOperation mdmOperation;

        /// <summary>
        /// Repository constructor.
        /// </summary>
        /// <param name="mappingRepository"></param>
        /// <param name="amlService">The aml service</param>
        /// <param name="masterService">The master entity service.</param>
        /// <param name="cogenEntitiesServices">The Cogen Entities service.</param>
        public EntityRepository(ISourceAndResultsMapping mappingRepository, IAmlService amlService, IMasterService masterService, ICogenEntities cogenEntitiesServices)
        {
            log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            EntityResponseHeaders = new Dictionary<string, string>();

            this.mappingRepository = mappingRepository ?? throw new ArgumentNullException(nameof(mappingRepository));

            this.cogenEntitiesServices = cogenEntitiesServices ?? throw new ArgumentNullException(nameof(cogenEntitiesServices));
            this.amlService = amlService ?? throw new ArgumentNullException(nameof(amlService));
            this.masterService = masterService ?? throw new ArgumentNullException(nameof(masterService));
        }

        public IDictionary<string, string> EntityResponseHeaders { get; }

        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        public bool CallsExternalService => false;

        #region Entity object
        /// <summary>
        /// Method to read information of an entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>null if entity not found. Entity with all information to the entity.</returns>
        ///<inheritdoc /> 
        public async Task<models.Entity> GetEntityAsync(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            // set operation type
            SetOperation(true, parameters);

            return await GetEntityActionsAsync(headerParameters, parameters);
        }

        /// <summary>
        /// Method to create a new entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="newEntity">Data for the creation of a new entity.</param>
        /// <returns>null if entity not created. The data stored for the created entity.</returns>
        /// <inheritdoc />
        public async Task<models.Entity> UpdateEntityAsync(HeaderParameters headerParameters, models.Entity newEntity)
        {
            // set operation type
            mdmOperation = string.IsNullOrEmpty(newEntity?.IdEntity) ?
                    Helpers.MdmOperation.Insert :
                    Helpers.MdmOperation.Update;

            // validate that entity exists for updates
            if (mdmOperation == Helpers.MdmOperation.Update && 
                await GetEntityActionsAsync(headerParameters, new EntitiesInput { IdEntity = newEntity?.IdEntity }) == null)
            {
                return null;
            }

            return await CreateUpdateEntityActionsAsync(headerParameters, newEntity);
        }

        /// <summary>
        /// Method to delete an entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to define entity to be deleted.</param>
        /// <returns>true if entity deleted.</returns>
        /// <inheritdoc />
        public bool DeleteEntity(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            return DeleteMock(parameters);
        }
        #endregion

        #region Entity.EntityType object
        /// <summary>
        /// Method to read entity type information.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>null if entity not found. Entity with all information to the entity.</returns>
        /// <inheritdoc />
        public async Task<models.Entity.EntityType> GetEntityTypeAsync(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            // set operation type
            SetOperation(true, parameters);

            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            return entity?.Type;
        }

        /// <summary>
        /// Method to update entity type information.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="type">entity type information to update</param>
        /// <returns>null if entity not found. Entity with all information to the entity.</returns>
        /// <inheritdoc />
        public async Task<models.Entity.EntityType> UpdateEntityTypeAsync(HeaderParameters headerParameters, EntitiesInput parameters, models.Entity.EntityType type)
        {
            // set operation type
            SetOperation(false, parameters);

            // validate that entity exists
            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            if (entity == null)
            {
                return null;
            }

            // build new entity to update
            var newEntity = new models.Entity
            {
                IdEntity = entity.IdEntity,
                Type = type
            };
            newEntity = await CreateUpdateEntityActionsAsync(headerParameters, newEntity);

            return newEntity?.Type;
        }
        #endregion

        #region Address object
        /// <summary>
        /// Method to read entity list of addresses.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>Empty list if entity not found or address list in Entity.</returns>
        /// <inheritdoc />
        public async Task<IEnumerable<models.Address>> GetEntityAddressesAsync(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            return await GetEntityAddressesAsync(headerParameters, parameters, null);
        }

        /// <summary>
        /// Method to read entity address.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idAddress">parameter to filter the addresses to return.</param>
        /// <returns>null if not found or address in Entity.</returns>
        /// <inheritdoc />
        public async Task<models.Address> GetEntityAddressAsync(HeaderParameters headerParameters, EntitiesInput parameters, string idAddress)
        {
            var results = await GetEntityAddressesAsync(headerParameters, parameters, idAddress);
            return results.FirstOrDefault();
        }

        private async Task<IEnumerable<models.Address>> GetEntityAddressesAsync(HeaderParameters headerParameters, EntitiesInput parameters, string idAddress)
        {
            // set operation type
            SetOperation(true, parameters);

            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            if (entity == null || !entity.Addresses.Any())
            {
                return new List<models.Address>();
            }

            if (string.IsNullOrEmpty(idAddress))
            {
                return entity.Addresses;
            }

            return entity.GetAddresses(idAddress);
        }

        /// <summary>
        /// Method to update the list of addresses of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="addresses">Addresses that need to be updated.</param>
        /// <returns>Empty list if entity not found or address not found in Entity.</returns>
        /// <inheritdoc />
        public async Task<IEnumerable<models.Address>> UpdateEntityAddressesAsync(HeaderParameters headerParameters, EntitiesInput parameters
            , IEnumerable<models.Address> addresses)
        {
            return await UpdateEntityAddressesAsync(headerParameters, parameters, addresses, null);
        }

        /// <summary>
        /// Method to update the list of addresses of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="address">Address that need to be updated.</param>
        /// <returns>null if not found in Entity.</returns>
        /// <inheritdoc />
        public Task<models.Address> UpdateEntityAddressAsync(HeaderParameters headerParameters, EntitiesInput parameters
            , models.Address address)
        {
            if (parameters == null)
            {
                throw new ArgumentNullException(nameof(parameters));
            }

            return UpdateAddressAsync(headerParameters, parameters, address);
        }

        private async Task<models.Address> UpdateAddressAsync(HeaderParameters headerParameters, EntitiesInput parameters, models.Address address)
        {
            var results = await UpdateEntityAddressesAsync(headerParameters, parameters, new List<models.Address> { address }, address.Sequence);
            return results.FirstOrDefault();
        }

        private async Task<IEnumerable<models.Address>> UpdateEntityAddressesAsync(HeaderParameters headerParameters, EntitiesInput parameters
            , IEnumerable<models.Address> addresses, string idAddress)
        {
            // set operation type
            SetOperation(false, parameters);

            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            // validate that entity exists
            if (entity == null)
            {
                return new List<models.Address>();
            }

            // validate that address exists
            if (!string.IsNullOrEmpty(idAddress) && entity.GetAddress(idAddress) == null)
            {
                return new List<models.Address>();
            }

            // build new entity to update
            var newEntity = new models.Entity
            {
                IdEntity = entity.IdEntity,
                Addresses = addresses
            };

            newEntity = await CreateUpdateEntityActionsAsync(headerParameters, newEntity);

            return string.IsNullOrEmpty(idAddress) ?
                // return all addresses
                newEntity.Addresses
                // return only the address that was updated
                : newEntity.GetAddresses(idAddress);
        }

        /// <summary>
        /// Method to delete one or more addresses from the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idAddress">parameter to filter the addresses to delete.</param>
        /// <returns>true if address(es) are deleted.</returns>
        /// <inheritdoc />
        public bool DeleteEntityAddresses(HeaderParameters headerParameters, EntitiesInput parameters, string idAddress)
        {
            return DeleteMock(parameters);
        }
        #endregion

        #region ContactLists object
        /// <summary>
        /// Method to read entity type information.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>null if entity not found. Entity with all information to the entity.</returns>
        /// <inheritdoc />
        public async Task<models.ContactLists> GetEntityContactListsAsync(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            // set operation type
            SetOperation(true, parameters);

            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            return entity?.Contacts;
        }

        /// <summary>
        /// Method to update entity contact lists.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="contacts">contact lists to be updated</param>
        /// <returns>null if entity not found. Entity with all information to the entity.</returns>
        /// <inheritdoc />
        public async Task<models.ContactLists> UpdateEntityContactListsAsync(HeaderParameters headerParameters, EntitiesInput parameters, models.ContactLists contacts)
        {
            // set operation type
            SetOperation(false, parameters);

            // validate that entity exists
            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            if (entity == null)
            {
                return null;
            }

            // build new entity to update
            var newEntity = new models.Entity
            {
                IdEntity = entity.IdEntity,
                Contacts = contacts
            };
            newEntity = await CreateUpdateEntityActionsAsync(headerParameters, newEntity);

            return newEntity?.Contacts;
        }

        /// <summary>
        /// Method to delete contact lists.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to define entity to be deleted.</param>
        /// <returns>true if entity contact lists are deleted.</returns>
        /// <inheritdoc />
        public bool DeleteContactLists(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            return DeleteMock(parameters);
        }
        #endregion

        #region Phone object
        /// <summary>
        /// Method to read entity list of phones.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>Empty list if entity not found or phones list in Entity.</returns>
        /// <inheritdoc />
        public async Task<IEnumerable<models.Phone>> GetEntityPhonesAsync(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            return await GetEntityPhonesAsync(headerParameters, parameters, null);
        }

        /// <summary>
        /// Method to read phone identified.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idPhone">parameter to filter the phones to return.</param>
        /// <returns>null if entity not found or phone in Entity.</returns>
        /// <inheritdoc />
        public async Task<models.Phone> GetEntityPhoneAsync(HeaderParameters headerParameters, EntitiesInput parameters, string idPhone)
        {
            var results = await GetEntityPhonesAsync(headerParameters, parameters, idPhone);
            return results.FirstOrDefault();
        }

        private async Task<IEnumerable<models.Phone>> GetEntityPhonesAsync(HeaderParameters headerParameters, EntitiesInput parameters, string idPhone)
        {
            // set operation type
            SetOperation(true, parameters);

            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            if (entity == null || !entity.Contacts.Phones.Any())
            {
                return new List<models.Phone>();
            }

            if (string.IsNullOrEmpty(idPhone))
            {
                return entity.Contacts.Phones;
            }

            return entity.GetPhones(idPhone);
        }

        /// <summary>
        /// Method to update the list of phones of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="phones">Phones that need to be updated.</param>
        /// <returns>Empty list if entity not found or phones list in Entity.</returns>
        /// <inheritdoc />
        public async Task<IEnumerable<models.Phone>> UpdateEntityPhonesAsync(HeaderParameters headerParameters, EntitiesInput parameters, IEnumerable<models.Phone> phones)
        {
            return await UpdateEntityPhonesAsync(headerParameters, parameters, phones, null);
        }

        /// <summary>
        /// Method to update the list of phones of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="phone">Phone that need to be updated.</param>
        /// <returns>null if not found in Entity.</returns>
        /// <inheritdoc />
        public Task<models.Phone> UpdateEntityPhoneAsync(HeaderParameters headerParameters, EntitiesInput parameters, models.Phone phone)
        {
            if (headerParameters == null)
            {
                throw new ArgumentNullException(nameof(headerParameters));
            }

            return UpdatePhoneAsync(headerParameters, parameters, phone);
        }

        private async Task<models.Phone> UpdatePhoneAsync(HeaderParameters headerParameters, EntitiesInput parameters, models.Phone phone)
        {
            var results = await UpdateEntityPhonesAsync(headerParameters, parameters, new List<models.Phone> { phone }, phone.PhoneIdentifier);
            return results.FirstOrDefault();
        }

        private async Task<IEnumerable<models.Phone>> UpdateEntityPhonesAsync(HeaderParameters headerParameters, EntitiesInput parameters, IEnumerable<models.Phone> phones
            , string idPhone)
        {
            // set operation type
            SetOperation(false, parameters);

            // validate that entity exists
            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            if (entity == null)
            {
                return new List<models.Phone>();
            }

            // validate that phone exists
            if (!string.IsNullOrEmpty(idPhone) && entity.GetPhone(idPhone) == null)
            {
                return new List<models.Phone>();
            }


            // build new entity to update
            var newEntity = new models.Entity
            {
                IdEntity = entity.IdEntity,
            };
            newEntity.Contacts.Phones = phones;

            newEntity = await CreateUpdateEntityActionsAsync(headerParameters, newEntity);

            return string.IsNullOrEmpty(idPhone) ?
                // return all addresses
                newEntity.Contacts.Phones
                // return only the address that was updated
                : newEntity.GetPhones(idPhone);
        }

        /// <summary>
        /// Method to delete one or more phones from the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idPhone">parameter to filter the phone to delete.</param>
        /// <returns>true if phone(s) are deleted.</returns>
        /// <inheritdoc />
        public bool DeleteEntityPhones(HeaderParameters headerParameters, EntitiesInput parameters, string idPhone)
        {
            return DeleteMock(parameters);
        }
        #endregion

        #region Email object
        /// <summary>
        /// Method to read entity list of emails.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>Empty list if entity not found or email list in Entity.</returns>
        /// <inheritdoc />
        public async Task<IEnumerable<models.Email>> GetEntityEmailsAsync(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            return await GetEntityEmailsAsync(headerParameters, parameters, null);
        }

        /// <summary>
        /// Method to read the email identified.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idEmail">parameter to filter the email to return.</param>
        /// <returns>null if entity not found or email in Entity.</returns>
        /// <inheritdoc />
        public async Task<models.Email> GetEntityEmailAsync(HeaderParameters headerParameters, EntitiesInput parameters, int idEmail)
        {
            var results = await GetEntityEmailsAsync(headerParameters, parameters, idEmail);
            return results.FirstOrDefault();
        }

        private async Task<IEnumerable<models.Email>> GetEntityEmailsAsync(HeaderParameters headerParameters, EntitiesInput parameters, int? idEmail)
        {
            // set operation type
            SetOperation(true, parameters);

            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            if (entity == null || !entity.Contacts.Emails.Any())
            {
                return new List<models.Email>();
            }

            if (!idEmail.HasValue)
            {
                return entity.Contacts.Emails;
            }

            return entity.GetEmails(idEmail.Value);
        }

        /// <summary>
        /// Method to update the list of emails of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="emails">Emails that need to be updated.</param>
        /// <returns>Empty list if entity not found or email list in Entity.</returns>
        /// <inheritdoc />
        public async Task<IEnumerable<models.Email>> UpdateEntityEmailsAsync(HeaderParameters headerParameters, EntitiesInput parameters, IEnumerable<models.Email> emails)
        {
            return await UpdateEntityEmailsAsync(headerParameters, parameters, emails, null);
        }

        /// <summary>
        /// Method to update the list of emails of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="email">Emails that need to be updated.</param>
        /// <returns>null if not found in Entity.</returns>
        /// <inheritdoc />
        public Task<models.Email> UpdateEntityEmailAsync(HeaderParameters headerParameters, EntitiesInput parameters, models.Email email)
        {
            if (headerParameters == null)
            {
                throw new ArgumentNullException(nameof(headerParameters));
            }

            return UpdateEmailAsync(headerParameters, parameters, email);
        }

        private async Task<models.Email> UpdateEmailAsync(HeaderParameters headerParameters, EntitiesInput parameters, models.Email email)
        {
            var results = await UpdateEntityEmailsAsync(headerParameters, parameters, new List<models.Email> { email }, email.EmailIdentifier);
            return results.FirstOrDefault();
        }

        private async Task<IEnumerable<models.Email>> UpdateEntityEmailsAsync(HeaderParameters headerParameters, EntitiesInput parameters, IEnumerable<models.Email> emails
            , int? idEmail)
        {
            // set operation type
            SetOperation(false, parameters);

            // validate that entity exists
            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            if (entity == null)
            {
                return new List<models.Email>();
            }

            // validate that email exists
            if (idEmail.HasValue && entity.GetEmail(idEmail.Value) == null)
            {
                return new List<models.Email>();
            }

            // build new entity to update
            var newEntity = new models.Entity
            {
                IdEntity = entity.IdEntity,
            };
            newEntity.Contacts.Emails = emails;

            newEntity = await CreateUpdateEntityActionsAsync(headerParameters, newEntity);

            return idEmail.HasValue ?
                // return only the address that was updated
                newEntity.GetEmails(idEmail.Value)
                // return all addresses
                : newEntity.Contacts.Emails;
        }

        /// <summary>
        /// Method to delete one or more emails from the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idEmail">parameter to filter the addresses to delete.</param>
        /// <returns>true if email(s) are deleted.</returns>
        /// <inheritdoc />
        public bool DeleteEntityEmails(HeaderParameters headerParameters, EntitiesInput parameters, int? idEmail)
        {
            return DeleteMock(parameters);
        }
        #endregion

        #region BankAccount object
        /// <summary>
        /// Method to read entity list of bank accounts.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>Empty list if entity not found or bank account list in Entity.</returns>
        /// <inheritdoc />
        public async Task<IEnumerable<models.BankAccount>> GetEntityBankAccountsAsync(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            return await GetEntityBankAccountsAsync(headerParameters, parameters, null);
        }

        /// <summary>
        /// Method to read entity bank account identified.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idBankAccount">parameter to filter the bank account to return.</param>
        /// <returns>null if entity not found or bank account in Entity.</returns>
        /// <inheritdoc />
        public async Task<models.BankAccount> GetEntityBankAccountAsync(HeaderParameters headerParameters, EntitiesInput parameters, int idBankAccount)
        {
            var results = await GetEntityBankAccountsAsync(headerParameters, parameters, idBankAccount);
            return results.FirstOrDefault();
        }

        private async Task<IEnumerable<models.BankAccount>> GetEntityBankAccountsAsync(HeaderParameters headerParameters, EntitiesInput parameters, int? idBankAccount)
        {
            // set operation type
            SetOperation(true, parameters);

            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            if (entity == null || !entity.BankAccounts.Any())
            {
                return new List<models.BankAccount>();
            }

            if (!idBankAccount.HasValue)
            {
                return entity.BankAccounts;
            }

            return entity.GetBankAccounts(idBankAccount.Value);
        }

        /// <summary>
        /// Method to update the list of bank accounts of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="bankAccounts">Bank accounts that need to be updated.</param>
        /// <returns>Empty list if entity not found or bank account list in Entity.</returns>
        /// <inheritdoc />
        public async Task<IEnumerable<models.BankAccount>> UpdateEntityBankAccountsAsync(HeaderParameters headerParameters, EntitiesInput parameters
            , IEnumerable<models.BankAccount> bankAccounts)
        {
            return await UpdateEntityBankAccountsAsync(headerParameters, parameters, bankAccounts, null);
        }

        /// <summary>
        /// Method to update the list of bank accounts of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="bankAccount">Bank account that need to be updated.</param>
        /// <returns>null if not found in Entity.</returns>
        /// <inheritdoc />
        public Task<models.BankAccount> UpdateEntityBankAccountAsync(HeaderParameters headerParameters, EntitiesInput parameters
            , models.BankAccount bankAccount)
        {
            if (headerParameters == null)
            {
                throw new ArgumentNullException(nameof(headerParameters));
            }

            return UpdateBankAccountAsync(headerParameters, parameters, bankAccount);
        }

        private async Task<models.BankAccount> UpdateBankAccountAsync(HeaderParameters headerParameters, EntitiesInput parameters
            , models.BankAccount bankAccount)
        {
            var results = await UpdateEntityBankAccountsAsync(headerParameters, parameters,
                new List<models.BankAccount> { bankAccount }, bankAccount.SequenceBankAccountNumber);
            return results.FirstOrDefault();
        }

        private async Task<IEnumerable<models.BankAccount>> UpdateEntityBankAccountsAsync(HeaderParameters headerParameters, EntitiesInput parameters
            , IEnumerable<models.BankAccount> bankAccounts, int? idBankAccount)
        {
            // set operation type
            SetOperation(false, parameters);

            // validate that entity exists
            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            if (entity == null)
            {
                return new List<models.BankAccount>();
            }

            // validate that bank account exists
            if (idBankAccount.HasValue && entity.GetBankAccount(idBankAccount.Value) == null)
            {
                return new List<models.BankAccount>();
            }

            // build new entity to update
            var newEntity = new models.Entity
            {
                IdEntity = entity.IdEntity,
                BankAccounts = bankAccounts
            };

            newEntity = await CreateUpdateEntityActionsAsync(headerParameters, newEntity);

            return idBankAccount.HasValue ?
                // return only the address that was updated
                newEntity.GetBankAccounts(idBankAccount.Value)
                // return all addresses
                : newEntity.BankAccounts;
        }

        /// <summary>
        /// Method to delete one or more bank accounts from the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idBankAccount">parameter to filter the bank account to delete.</param>
        /// <returns>true if account(s) are deleted.</returns>
        /// <inheritdoc />
        public bool DeleteEntityBankAccounts(HeaderParameters headerParameters, EntitiesInput parameters, int? idBankAccount)
        {
            return DeleteMock(parameters);
        }
        #endregion

        #region Document object
        /// <summary>
        /// Method to read entity list of documents.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>Empty list if entity not found or documents list in Entity.</returns>
        /// <inheritdoc />
        public async Task<IEnumerable<models.Document>> GetEntityDocumentsAsync(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            return await GetEntityDocumentsAsync(headerParameters, parameters, null, null);
        }

        /// <summary>
        /// Method to read entity document identified.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="documentCode">parameter to filter the document to return.</param>
        /// <param name="idDocument">parameter to filter the documents to return.</param>
        /// <returns>null if entity not found or document in Entity.</returns>
        /// <inheritdoc />
        public async Task<models.Document> GetEntityDocumentAsync(HeaderParameters headerParameters, EntitiesInput parameters, string documentCode, string idDocument)
        {
            var results = await GetEntityDocumentsAsync(headerParameters, parameters, documentCode, idDocument);
            return results.FirstOrDefault();
        }

        private async Task<IEnumerable<models.Document>> GetEntityDocumentsAsync(HeaderParameters headerParameters, EntitiesInput parameters, string documentCode
            , string idDocument)
        {
            // set operation type
            SetOperation(true, parameters);

            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            if (entity == null || !entity.Documents.Any())
            {
                return new List<models.Document>();
            }

            if (string.IsNullOrEmpty(idDocument) && string.IsNullOrEmpty(documentCode))
            {
                return entity.Documents;
            }

            return entity.GetDocuments(documentCode, idDocument);
        }

        /// <summary>
        /// Method to update the list of documents of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="documents">Documents that need to be updated.</param>
        /// <returns>Empty list if entity not found or documents list in Entity.</returns>
        /// <inheritdoc />
        public async Task<IEnumerable<models.Document>> UpdateEntityDocumentsAsync(HeaderParameters headerParameters, EntitiesInput parameters
            , ICollection<models.Document> documents)
        {
            return await UpdateEntityDocumentsAsync(headerParameters, parameters, documents, null, null);
        }

        /// <summary>
        /// Method to update the list of documents of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="document">Document that need to be updated.</param>
        /// <returns>null if not found in Entity.</returns>
        /// <inheritdoc />
        public Task<models.Document> UpdateEntityDocumentAsync(HeaderParameters headerParameters, EntitiesInput parameters, models.Document document)
        {
            if (headerParameters == null)
            {
                throw new ArgumentNullException(nameof(headerParameters));
            }

            return UpdateDocumentAsync(headerParameters, parameters, document );
        }

        private async Task<models.Document> UpdateDocumentAsync(HeaderParameters headerParameters, EntitiesInput parameters
            , models.Document document)
        {
            var results = await UpdateEntityDocumentsAsync(headerParameters, parameters, new List<models.Document> { document },
                document.DocumentTypeCode, document.DocumentNumber);
            return results.FirstOrDefault();
        }

        private async Task<IEnumerable<models.Document>> UpdateEntityDocumentsAsync(HeaderParameters headerParameters, EntitiesInput parameters
            , ICollection<models.Document> documents, string documentCode, string idDocument)
        {
            // set operation type
            SetOperation(false, parameters);

            // validate that entity exists
            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            if (entity == null)
            {
                return new List<models.Document>();
            }

            // validate that document exists
            if (!string.IsNullOrEmpty(idDocument) && !string.IsNullOrEmpty(documentCode)
                 && entity.GetDocument(documentCode, idDocument) == null)
            {
                return new List<models.Document>();
            }

            // build new entity to update
            var newEntity = new models.Entity
            {
                IdEntity = entity.IdEntity,
                Documents = documents
            };

            newEntity = await CreateUpdateEntityActionsAsync(headerParameters, newEntity);

            return string.IsNullOrEmpty(idDocument) && string.IsNullOrEmpty(documentCode) ?
                // return all documents
                newEntity.Documents
                // return only the document that was updated
                : newEntity.GetDocuments(documentCode, idDocument);
        }

        /// <summary>
        /// Method to delete one or more documents from the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="documentCode">parameter to filter the document to delete.</param>
        /// <param name="idDocument">parameter to filter the document to delete.</param>
        /// <returns>true if phone(s) are deleted.</returns>
        /// <inheritdoc />
        public bool DeleteEntityDocuments(HeaderParameters headerParameters, EntitiesInput parameters, string documentCode, string idDocument)
        {
            return DeleteMock(parameters);
        }
        #endregion

        #region CAE object
        /// <summary>
        /// Method to read entity list of CAEs.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>Empty list if entity not found or CAE list in Entity.</returns>
        /// <inheritdoc />
        public async Task<IEnumerable<models.Cae>> GetEntityCaesAsync(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            return await GetEntityCaesAsync(headerParameters, parameters, null);
        }

        /// <summary>
        /// Method to read entity CAE identified.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idCae">parameter to filter the CAEs to return.</param>
        /// <returns>null if entity not found or CAE in Entity.</returns>
        /// <inheritdoc />
        public async Task<models.Cae> GetEntityCaeAsync(HeaderParameters headerParameters, EntitiesInput parameters, int idCae)
        {
            var results = await GetEntityCaesAsync(headerParameters, parameters, idCae);
            return results.FirstOrDefault();
        }

        private async Task<IEnumerable<models.Cae>> GetEntityCaesAsync(HeaderParameters headerParameters, EntitiesInput parameters, int? idCae)
        {
            // set operation type
            SetOperation(true, parameters);

            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            if (entity == null || !entity.Caes.Any())
            {
                return new List<models.Cae>();
            }

            if (!idCae.HasValue)
            {
                return entity.Caes;
            }

            return entity.GetCaes(idCae.Value);
        }

        /// <summary>
        /// Method to update the list of CAEs of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="caes">CAEs that need to be updated.</param>
        /// <returns>Empty list if entity not found or CAEs list in Entity.</returns>
        /// <inheritdoc />
        public async Task<IEnumerable<models.Cae>> UpdateEntityCaesAsync(HeaderParameters headerParameters, EntitiesInput parameters, IEnumerable<models.Cae> caes)
        {
            return await UpdateEntityCaesAsync(headerParameters, parameters, caes, null);
        }

        /// <summary>
        /// Method to update the list of CAEs of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="cae">CAE that needs to be updated.</param>
        /// <returns>null if not found in Entity.</returns>
        /// <inheritdoc />
        public Task<models.Cae> UpdateEntityCaeAsync(HeaderParameters headerParameters, EntitiesInput parameters, models.Cae cae)
        {
            if (headerParameters == null)
            {
                throw new ArgumentNullException(nameof(headerParameters));
            }

            return UpdateCaeAsync(headerParameters, parameters, cae);
        }

        private async Task<models.Cae> UpdateCaeAsync(HeaderParameters headerParameters, EntitiesInput parameters, models.Cae cae)
        {
            var results = await UpdateEntityCaesAsync(headerParameters, parameters, new List<models.Cae> { cae }, cae.CaeOrderNumber);
            return results.FirstOrDefault();
        }

        private async Task<IEnumerable<models.Cae>> UpdateEntityCaesAsync(HeaderParameters headerParameters, EntitiesInput parameters, IEnumerable<models.Cae> caes, int? idCae)
        {
            // set operation type
            SetOperation(false, parameters);

            // validate that entity exists
            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            if (entity == null)
            {
                return new List<models.Cae>();
            }

            // validate that cae exists
            if (idCae.HasValue && entity.GetCae(idCae.Value) == null)
            {
                return new List<models.Cae>();
            }

            // build new entity to update
            var newEntity = new models.Entity
            {
                IdEntity = entity.IdEntity,
                Caes = caes
            };

            newEntity = await CreateUpdateEntityActionsAsync(headerParameters, newEntity);

            return idCae.HasValue ?
                // return only the address that was updated
                newEntity.GetCaes(idCae.Value)
                // return all addresses
                : newEntity.Caes;
        }

        /// <summary>
        /// Method to delete one or more CAEs from the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idCae">parameter to filter the CAEs to delete.</param>
        /// <returns>true if CAE(s) are deleted.</returns>
        /// <inheritdoc />
        public bool DeleteEntityCaes(HeaderParameters headerParameters, EntitiesInput parameters, int? idCae)
        {
            return DeleteMock(parameters);
        }
        #endregion

        #region AffinityRelation object
        /// <summary>
        /// Method to read entity list of affinities.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>Empty list if entity not found or affinities list in Entity.</returns>
        /// <inheritdoc />
        public async Task<IEnumerable<models.AffinityRelation>> GetEntityAffinitiesAsync(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            return await GetEntityAffinitiesAsync(headerParameters, parameters, null);
        }

        /// <summary>
        /// Method to read entity affinityl.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idAffinity">parameter to filter the affinities to return.</param>
        /// <returns>null if entity not found or affinity in Entity.</returns>
        /// <inheritdoc />
        public async Task<models.AffinityRelation> GetEntityAffinityAsync(HeaderParameters headerParameters, EntitiesInput parameters, int idAffinity)
        {
            var results = await GetEntityAffinitiesAsync(headerParameters, parameters, idAffinity);
            return results.FirstOrDefault();
        }

        private async Task<IEnumerable<models.AffinityRelation>> GetEntityAffinitiesAsync(HeaderParameters headerParameters, EntitiesInput parameters, int? idAffinity)
        {
            // set operation type
            SetOperation(true, parameters);

            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            if (entity == null || !entity.AffinityRelations.Any())
            {
                return new List<models.AffinityRelation>();
            }

            if (!idAffinity.HasValue)
            {
                return entity.AffinityRelations;
            }

            return entity.GetAffinities(idAffinity.Value);
        }

        /// <summary>
        /// Method to update the list of affinities of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="affinities">Affinities that need to be updated.</param>
        /// <returns>Empty list if entity not found or affinities list in Entity.</returns>
        /// <inheritdoc />
        public async Task<IEnumerable<models.AffinityRelation>> UpdateEntityAffinitiesAsync(HeaderParameters headerParameters, EntitiesInput parameters
            , IEnumerable<models.AffinityRelation> affinities)
        {
            return await UpdateEntityAffinitiesAsync(headerParameters, parameters, affinities, null);
        }

        /// <summary>
        /// Method to update the list of affinities of the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="affinity">Affinities that need to be updated.</param>
        /// <returns>null if not found in Entity.</returns>
        /// <inheritdoc />
        public Task<models.AffinityRelation> UpdateEntityAffinityAsync(HeaderParameters headerParameters, EntitiesInput parameters
            , models.AffinityRelation affinity)
        {
            if (headerParameters == null)
            {
                throw new ArgumentNullException(nameof(headerParameters));
            }

            return UpdateAffinityAsync(headerParameters, parameters, affinity);
        }

        private async Task<models.AffinityRelation> UpdateAffinityAsync(HeaderParameters headerParameters, EntitiesInput parameters
            , models.AffinityRelation affinity)
        {
            var results = await UpdateEntityAffinitiesAsync(headerParameters, parameters, 
                new List<models.AffinityRelation> { affinity }, affinity.RelationIdentifier);

            return results.FirstOrDefault();
        }

        private async Task<IEnumerable<models.AffinityRelation>> UpdateEntityAffinitiesAsync(HeaderParameters headerParameters, EntitiesInput parameters
            , IEnumerable<models.AffinityRelation> affinities, int? idAffinity)
        {
            // set operation type
            SetOperation(false, parameters);

            // validate that entity exists
            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            if (entity == null)
            {
                return new List<models.AffinityRelation>();
            }

            // validate that affinity exists
            if (idAffinity.HasValue && entity.GetAffinity(idAffinity.Value) == null)
            {
                return new List<models.AffinityRelation>();
            }

            // build new entity to update
            var newEntity = new models.Entity
            {
                IdEntity = entity.IdEntity,
                AffinityRelations = affinities
            };

            newEntity = await CreateUpdateEntityActionsAsync(headerParameters, newEntity);

            return idAffinity.HasValue ?
                // return only the address that was updated
                newEntity.GetAffinities(idAffinity.Value)
                // return all addresses
                : newEntity.AffinityRelations;
        }

        /// <summary>
        /// Method to delete one or more affinities from the entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <param name="idAffinity">parameter to filter the affinities to delete.</param>
        /// <returns>true if Affinity(ies) are deleted.</returns>
        /// <inheritdoc />
        public bool DeleteEntityAffinities(HeaderParameters headerParameters, EntitiesInput parameters, int? idAffinity)
        {
            return DeleteMock(parameters);
        }
        #endregion

        #region MarketingBase object
        public async Task<models.Marketing> GetEntityMarketingAsync(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            // set operation type
            SetOperation(true, parameters);

            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            return entity?.MarketingInformation;
        }

        public async Task<models.Marketing> UpdateEntityMarketingAsync(HeaderParameters headerParameters, EntitiesInput parameters, models.Marketing marketing)
        {
            // set operation type
            SetOperation(false, parameters);

            // validate that entity exists
            var entity = await GetEntityActionsAsync(headerParameters, parameters);

            if (entity == null)
            {
                return null;
            }

            // build new entity to update
            var newEntity = new models.Entity
            {
                IdEntity = entity.IdEntity,
                MarketingInformation = marketing
            };
            newEntity = await CreateUpdateEntityActionsAsync(headerParameters, newEntity);

            return newEntity?.MarketingInformation;
        }
        #endregion

        #region Read and Update action methods
        private async Task<models.Entity> GetEntityActionsAsync(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            try
            {
                // read source and mappings
                mappingRepository.ReadSourceAndSctructure(headerParameters, Helpers.MdmOperation.Get);

                // build list of read information tasks
                var tasksToReadData = new List<Task>();

                if (mappingRepository.NeedsAmlInformation)
                {
                    // call AML service
                    tasksToReadData.Add(amlService.GetAmlAsync(headerParameters, parameters.IdEntity));
                }

                var entityReadTask =
                    mappingRepository.NativeMaster == Helpers.MdmMasterSource.MasterEntityOcidental
                    ? cogenEntitiesServices.GetEntityAsync(headerParameters, parameters)
                    : masterService.GetEntityAsync(headerParameters, mappingRepository.IdSource, parameters);

                // prepare to make parallel calls
                tasksToReadData.Add(entityReadTask);

                // execute calls to service
                await Task.WhenAll(tasksToReadData);

                // merge information from AML with service information
                var entity = await entityReadTask;
                amlService.MergeAmlToEntity(entity);

                // clear data not authorized
                mappingRepository.RemoveUnauthorizedData(entity);

                // load headers if this is the only operation
                if (mdmOperation == Helpers.MdmOperation.Get)
                {
                    LoadHeaders(entity);
                }


                return entity;
            }
            catch (BaseException pe)
            {
                log.Info(pe);
                throw;
            }
            catch (Exception e)
            {
                log.Error($"Error reading information from service! Error: {e}");

                return null;
            }
        }

        private async Task<models.Entity> CreateUpdateEntityActionsAsync(HeaderParameters headerParameters, models.Entity newEntity)
        {
            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();
                // read source and mappings
                mappingRepository.ReadSourceAndSctructure(headerParameters, mdmOperation);

                stopwatch.Start();
                // clear data not authorized
                mappingRepository.RemoveUnauthorizedData(newEntity);
                stopwatch.Stop();
                log.Info($"Entity to be merged: {JsonConvert.SerializeObject(newEntity)} after remove unauthorized data took {stopwatch.ElapsedMilliseconds}ms");

                // validate that newEntity conatins valid object data to use
                if (!newEntity.ContainsKeyInformation)
                {
                    throw new BusinessException("EmptyEntity", $"Input object not valid for {mdmOperation} operation!");
                }

                // validate Nationalities
                ValidateNationalities(newEntity);

                if (mappingRepository.NeedsAmlInformation && mdmOperation == Helpers.MdmOperation.Update)
                {
                    // call AML service to save changes
                    await amlService.SetAmlAsync(headerParameters, newEntity);
                }

                var result =
                    mappingRepository.NativeMaster == Helpers.MdmMasterSource.MasterEntityOcidental
                    ? await cogenEntitiesServices.CreateUpdateEntityAsync(headerParameters, mdmOperation, newEntity)
                    : await masterService.CreateUpdateEntityAsync(headerParameters, mappingRepository.IdSource, mdmOperation, newEntity);

                // save and read Aml information if needed
                if (mappingRepository.NeedsAmlInformation)
                {
                    if (mdmOperation == Helpers.MdmOperation.Insert)
                    {
                        newEntity.IdEntity = result.IdEntity;
                        // call AML service to save changes
                        await amlService.SetAmlAsync(headerParameters, newEntity);
                    }                

                    // call AML get service to read updated information
                    await amlService.GetAmlAsync(headerParameters, result.IdEntity);
                    // fill updated entity
                    amlService.MergeAmlToEntity(result);
                }

                LoadHeaders(result);

                // clear data not authorized
                mappingRepository.RemoveUnauthorizedData(result);

                return result;
            }
            catch (BaseException pe)
            {
                log.Info(pe);
                throw;
            }
            catch (Exception e)
            {
                log.Error($"Error updating information into service! Error: {e}");

                return null;
            }
        }


        private void ValidateNationalities(models.Entity newEntity)
        {
            // nothing to validate
            if (newEntity?.Type?.Individual?.Nationalities == null)
            {
                return;
            }

            // object validation works for these cases
            if(newEntity.Type.Individual.Nationalities.Any(n => n.IsPrincipal)
                && newEntity.Type.Individual.Nationalities.Any(n => !n.IsPrincipal))
            {
                return;
            }

            // build object with data to be updated and prepare objects for validation
            var natinalities = new List<models.Nationality>(newEntity.Type.Individual.Nationalities);
            var errorList = new List<System.ComponentModel.DataAnnotations.ValidationResult>();

            var otherNationality =
                natinalities.Any(n => n.IsPrincipal) ?
                    // read existing Nationality from AML and add to collection
                    amlService.GetPreviousNationality :
                    // read existing Nationality from MasterEntity and add to collection
                    masterService.GetPreviousNationality;

            if (otherNationality != null)
            {
                natinalities.Add(otherNationality);

                // execute validation on collection
                models.Person.ValidateNationalities(natinalities, errorList);

                if (errorList.Any())
                {
                    throw new BusinessException("duplicatedNationality", errorList.First().ErrorMessage);
                }
            }
        }

        private void LoadHeaders(models.Entity entity)
        {
            if (entity == null)
            {
                return;
            }

            const string VersionHeader = "Entity_Version";

            // read entity version to load in headers
            if(!EntityResponseHeaders.TryAdd(VersionHeader, entity.Version))
            {
                EntityResponseHeaders[VersionHeader] = entity.Version;
            }
        }

        private void SetOperation(bool getOperation, EntitiesInput parameters)
        {
            if (getOperation)
            {
                mdmOperation = Helpers.MdmOperation.Get;
                return;
            }

            mdmOperation = string.IsNullOrEmpty(parameters?.IdEntity) ?
                Helpers.MdmOperation.Insert :
                Helpers.MdmOperation.Update;
        }

        #endregion




        private static bool DeleteMock(EntitiesInput parameters)
        {
            if (parameters.IdEntity == "2233")
            {
                return true;
            }

            throw new NotSupportedException("Still waiting on requirements.");
        }
    }
}

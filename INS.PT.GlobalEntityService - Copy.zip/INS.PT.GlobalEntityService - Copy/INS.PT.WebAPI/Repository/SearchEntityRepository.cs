﻿using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;
using log4net;
using System;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Interface.Service;
using System.Threading.Tasks;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// SearchEntityRepository
    /// </summary>
    ///<inheritdoc /> 
    public class SearchEntityRepository : ISearchEntity
    {
        private readonly IMasterService masterService;
        private readonly ICogenEntities cogenEntitiesServices;
        private readonly ISourceAndResultsMapping mappingRepository;
        private readonly ILog log;

        /// <summary>
        /// Repository constructor.
        /// </summary>
        /// <param name="mappingRepository">source and results repository.</param>
        /// <param name="masterService">MasterEntity service.</param>
        public SearchEntityRepository(IMasterService masterService, ISourceAndResultsMapping mappingRepository, ICogenEntities cogenEntitiesServices) 
        {
            log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

            this.masterService = masterService ?? throw new ArgumentNullException(nameof(masterService));
            this.cogenEntitiesServices = cogenEntitiesServices ?? throw new ArgumentNullException(nameof(cogenEntitiesServices));

            this.mappingRepository = mappingRepository ?? throw new ArgumentNullException(nameof(mappingRepository));
        }

        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        public bool CallsExternalService => false;

        /// <summary>
        /// Method to search an entity based on the search filters given in the parameters.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Search filters to make the search.</param>
        /// <returns>Matched results.</returns>
        ///<inheritdoc /> 
        public Task<SearchEntityOutput> SearchEntityAsync(HeaderParameters headerParameters, SearchEntityInput parameters)
        {
            // validate input parameters
            if (headerParameters == null)
            {
                throw new ArgumentNullException(nameof(headerParameters));
            }

            if (parameters == null)
            {
                throw new ArgumentNullException(nameof(parameters));
            }

            return CallSearchEntityAsync(headerParameters, parameters);
        }

        /// <summary>
        /// Method to make search to the MaasterEntity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Search filters to make the search</param>
        /// <returns>Matched results.</returns>
        private async Task<SearchEntityOutput> CallSearchEntityAsync(HeaderParameters headerParameters, SearchEntityInput parameters)
        {
            try
            {
                // read source and mappings
                mappingRepository.ReadSourceAndSctructure(headerParameters, Helpers.MdmOperation.Get);

                var result = mappingRepository.NativeMaster != Helpers.MdmMasterSource.MasterEntityAgeas
                    ? await cogenEntitiesServices.SearchEntityAsync(headerParameters, parameters)
                    : await masterService.SearchEntityAsync(headerParameters, mappingRepository.IdSource, parameters);

                return result;
            }
            catch (BaseException pe)
            {
                // errors from DB, log and throw
                log.Info(pe);
                throw;
            }
        }
    }
}

﻿using AutoMapper;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using models = INS.PT.WebAPI.Models.Elements;
using INS.PT.WebAPI.Models.Input;
using log4net;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Threading.Tasks;
using Tecnisys;

namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    /// Class to make calls to external MasterEntity service
    /// </summary>
    public class MasterService : IMasterService
    {
        private readonly ILog log;
        private readonly IMasterEntity masterEntityService;
        private readonly IMapper mapper;

        // last entity read from master
        private Entity _consumedEntity;

        /// <summary>
        /// Contructor.
        /// </summary>
        /// <param name="mapper">Mapper object to build result objects.</param>
        public MasterService(IMapper mapper) : this(mapper, null)
        {
        }

        /// <summary>
        /// Contructor to be used by unit tests.
        /// </summary>
        /// <param name="mapper">Mapper object to build result objects.</param>
        /// <param name="masterService">The wcf client to be used to get information.</param>
        public MasterService(IMapper mapper, IMasterEntity masterService)
        {
            log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

            this.mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));

            masterEntityService = masterService ?? Helpers.ProxyBuilder.CreateMasterClient();
        }


        /// <summary>
        /// Property to get nationality before update.
        /// </summary>
        public models.Nationality GetPreviousNationality
        {
            get
            {
                if (_consumedEntity?.nationalityCode == null)
                {
                    return null;
                }

                return new models.Nationality
                {
                    IsPrincipal = true,
                    NationalityCode = _consumedEntity.nationalityCode.Value.ToString(System.Globalization.CultureInfo.InvariantCulture)
                };
            }
        }

        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        public bool CallsExternalService => true;


        /// <summary>
        /// Method to read an entity from MasterEntity service.
        /// </summary>
        /// <param name="headerParameters">header parameters that will be needed to call MasterEntity service.</param>
        /// <param name="source">The mapped source to be used to call MasterEntity service.</param>
        /// <param name="parameters">input parameters.</param>
        /// <returns>Entity object that conatins data.</returns>
        public Task<models.Entity> GetEntityAsync(HeaderParameters headerParameters, string source, EntitiesInput parameters)
        {
            // build request to MasterEntity
            var masterParameters =
                new GetEntityRequest
                {
                    AxisValues = ProxyHelpers.BuildAxisValues(headerParameters),
                    source = source,
                    nif = null,
                    dni = parameters?.IdEntity,
                    birthDate = null,
                    name = null
                };

            // return entity objects
            return GetEntityAsync(masterParameters);
        }

        /// <summary>
        /// Method to read an entity from MasterEntity service.
        /// </summary>
        /// <param name="headerParameters">header parameters that will be needed to call MasterEntity service.</param>
        /// <param name="source">The mapped source to be used to call MasterEntity service.</param>
        /// <param name="vatNumber">vat number to search.</param>
        /// <returns>Entity object that conatins data.</returns>
        public Task<models.Entity> GetEntityAsync(HeaderParameters headerParameters, string source, string vatNumber)
        {
            // build request to MasterEntity
            var masterParameters =
                new GetEntityRequest
                {
                    AxisValues = ProxyHelpers.BuildAxisValues(headerParameters),
                    source = source,
                    nif = vatNumber,
                    dni = null,
                    birthDate = null,
                    name = null
                };

            // return entity objects
            return GetEntityAsync(masterParameters);
        }

        /// <summary>
        /// Method to read an entity from MasterEntity service.
        /// </summary>
        /// <param name="request">Request to be sent for Master service.</param>
        /// <returns>Entity object that conatins data.</returns>
        private async Task<models.Entity> GetEntityAsync(GetEntityRequest request)
        {
            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();

                log.Info($"Tecnisys call: {request.SerializeObjectToXml()}");

                // make call
                stopwatch.Start();
                var tecnisysResult = await masterEntityService.GetEntityAsync(request);
                stopwatch.Stop();

                log.Info($"MasterEntity execution took {stopwatch.ElapsedMilliseconds}ms to execute with result {JsonConvert.SerializeObject(tecnisysResult)}");

                // validate response
                ProxyHelpers.CheckInvalidResponse(tecnisysResult.GetEntityResult.Errors);

                var result = mapper.Map<models.Entity>(tecnisysResult.GetEntityResult.Entity);

                _consumedEntity = tecnisysResult.GetEntityResult.Entity;

                // return entity objects
                return result;
            }
            catch (System.ServiceModel.CommunicationException ce)
            {
                // log exception from master call
                log.Error($"Error reading information from Tecnisys! Error: {ce}");

                return null;
            }
        }

        /// <summary>
        /// Method to create/update an entity into MasterEntity service.
        /// </summary>
        /// <param name="headerParameters">header parameters that will be needed to call MasterEntity service.</param>
        /// <param name="source">The mapped source to be used to call MasterEntity service.</param>
        /// <param name="newEntity">data to be updated into entity.</param>
        /// <returns>Entity object that conatins data after updated.</returns>
        public async Task<models.Entity> CreateUpdateEntityAsync(HeaderParameters headerParameters, string source, Helpers.MdmOperation actionOnEntity, 
            models.Entity newEntity)
        {
            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();
                stopwatch.Start();

                // map information from GlobalEntity to MasterEntity
                var tecnisysEntity = mapper.Map<Entity>(newEntity);

                if (actionOnEntity == Helpers.MdmOperation.Update)
                {
                    // on updates keep some information to prevent removes
                    HackTecnisysEntity(newEntity, tecnisysEntity);
                }

                stopwatch.Stop();
                var masterParameters = new MergeEntityRequest
                {
                    AxisValues = ProxyHelpers.BuildAxisValues(headerParameters),
                    source = source,
                    newEntity = tecnisysEntity
                };

                log.Info($"Tecnisys call: {masterParameters.SerializeObjectToXml()}\n mapping took {stopwatch.ElapsedMilliseconds}ms");

                // make call to master
                stopwatch.Restart();
                var tecnisysResult = await masterEntityService.MergeEntityAsync(masterParameters);
                stopwatch.Stop();

                log.Info($"master execution took {stopwatch.ElapsedMilliseconds}ms to execute with result: {JsonConvert.SerializeObject(tecnisysResult)}");

                // validate response
                ProxyHelpers.CheckInvalidResponse(tecnisysResult.MergeEntityResult.Errors);

                // map result from MasterEntity to GlobalEntity
                var result = mapper.Map<models.Entity>(tecnisysResult.MergeEntityResult.Entity);

                return result;
            }
            catch (System.ServiceModel.CommunicationException ce)
            {
                // log exception from master call
                log.Error($"Error updating information from Tecnisys! Error: {ce}");

                return null;
            }
        }


        /// <summary>
        /// Method to search an entity into MasterEntity service.
        /// </summary>
        /// <param name="headerParameters">header parameters that will be needed to call MasterEntity service.</param>
        /// <param name="source">The mapped source to be used to call MasterEntity service.</param>
        /// <param name="searchParameters">Search parameters.</param>
        /// <returns>Search results object.</returns>
        public async Task<Models.Output.SearchEntityOutput> SearchEntityAsync(HeaderParameters headerParameters, string source, SearchEntityInput searchParameters)
        {
            if (searchParameters == null || headerParameters == null)
            {
                return null;
            }

            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();
                stopwatch.Start();

                // build request
                var masterParameters = new GetShortListDCRequest
                {
                    AxisValues = ProxyHelpers.BuildAxisValues(headerParameters),
                    source = source,
                    agentNumber = searchParameters.AgentNumber,
                    birthdate = searchParameters.Birthdate,
                    codPostal = searchParameters.PostalCode,
                    dni = searchParameters.IdEntity,
                    email = searchParameters.Email,
                    name = searchParameters.Name,
                    nif = searchParameters.VatNumber,
                    phone = searchParameters.PhoneNumber
                };

                stopwatch.Stop();

                log.Info($"Tecnisys call: {masterParameters.SerializeObjectToXml()}\n request build took {stopwatch.ElapsedMilliseconds}ms");

                // make call to master
                stopwatch.Restart();
                var tecnisysResult = await masterEntityService.GetShortListDCAsync(masterParameters);
                stopwatch.Stop();

                log.Info($"master execution took {stopwatch.ElapsedMilliseconds}ms to execute with result: {JsonConvert.SerializeObject(tecnisysResult)}");

                // validate response
                ProxyHelpers.CheckInvalidResponse(tecnisysResult.GetShortListDCResult.Errors);

                var result = mapper.Map<Models.Output.SearchEntityOutput>(tecnisysResult.GetShortListDCResult.ShortList);

                if (result?.MatchedEntities != null)
                {
                    // fill IdCompany and IdNetwork for the entities
                    foreach (var ent in result.MatchedEntities)
                    {
                        ent.IdCompany = headerParameters.IdCompany;
                        ent.IdNetwork = headerParameters.IdNetwork;
                    }
                }

                // map result from MasterEntity to GlobalEntity
                return result;
            }
            catch (System.ServiceModel.CommunicationException ce)
            {
                // log exception from master call
                log.Error($"Error updating information from Tecnisys! Error: {ce}");

                return null;
            }
        }


        #region Hack Tecnisys Entity information
        private void HackTecnisysEntity(models.Entity newEntity, Entity tecnisysEntity)
        {            
            // when updating entity if vat is the same clear the property sending to Master
            if (string.Compare(_consumedEntity.vatNumber, tecnisysEntity.vatNumber, StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                tecnisysEntity.vatNumber = string.Empty;
            }

            // keep first level properties while field validation is not done
            FirstLevelProperties(tecnisysEntity);

            // keep marketing information
            MarketingInformation(newEntity, tecnisysEntity);
        }

        /// <summary>
        /// Method to prevent errors on maketing information updates.
        /// </summary>
        /// <param name="newEntity">The information requested to be updated.</param>
        /// <param name="tecnisysEntity">The MasterEntity object that will be sent.</param>
        private void MarketingInformation(models.Entity newEntity, Entity tecnisysEntity)
        {
            tecnisysEntity.marketing = _consumedEntity.marketing;
            if (newEntity.MarketingInformation != null)
            {
                tecnisysEntity.marketing.isPaperlessAxa = newEntity.MarketingInformation.IsPaperlessAgeas;
                tecnisysEntity.marketing.isPaperlessAxaSpecified = newEntity.MarketingInformation.IsPaperlessAgeas.HasValue;
            }
        }

        /// <summary>
        /// Method to keep first level properties good to be updated by MasterEntity.
        /// </summary>
        /// <param name="tecnisysEntity">The MasterEntity object that will be sent.</param>
        private void FirstLevelProperties(Entity tecnisysEntity)
        {
            if (tecnisysEntity.person != null)
            {
                // keep existing nationality
                if (!tecnisysEntity.nationalityCode.HasValue)
                {
                    tecnisysEntity.nationalityCode =
                        // check if entity has nationality
                        _consumedEntity.nationalityCode.HasValue
                        ? _consumedEntity.nationalityCode.Value
                        // if entity has no nationality assume 1 as default to prevent update error
                        : 1;
                    tecnisysEntity.nationalityCodeSpecified = true;
                }

                // keep existing birthdate
                if (!tecnisysEntity.person.birthDate.HasValue)
                {
                    tecnisysEntity.person.birthDate = _consumedEntity.person?.birthDate;
                    tecnisysEntity.person.birthDateSpecified = tecnisysEntity.person.birthDate.HasValue;
                }

                // keep existing gender code
                if (string.IsNullOrEmpty(tecnisysEntity.person.genderCode))
                {
                    tecnisysEntity.person.genderCode = _consumedEntity.person?.genderCode;
                }

                // keep self employee flag information
                if (!tecnisysEntity.person.isSelfEmployee.HasValue)
                {
                    tecnisysEntity.person.isSelfEmployee = _consumedEntity.person?.isSelfEmployee;
                    tecnisysEntity.person.isSelfEmployeeSpecified = tecnisysEntity.person.isSelfEmployee.HasValue;
                }
            }
        }
        #endregion

        private static class ProxyHelpers
        {
            /// <summary>
            /// Build axis values to send in call.
            /// </summary>
            /// <param name="headerParameters">source of the user to be sent.</param>
            /// <returns>AxisValues object</returns>
            public static AxisValues BuildAxisValues(HeaderParameters headerParameters)
            {
                return new AxisValues
                {
                    Solution = ApplicationSettings.AxisSolution,
                    User = headerParameters?.BsUser
                };
            }

            /// <summary>
            /// Validates response coming from MasterEntity.
            /// </summary>
            /// <param name="errors">error array.</param>
            public static void CheckInvalidResponse(ServiceError[] errors)
            {
                if (errors.Length > 0
                    // dummy error code
                    && errors[0].Code != "01"
                    // error codes OK
                    && errors[0].Code != "APP-GET-OPR-00000"
                    && errors[0].Code != "APP-MRG-OPR-00000")
                {
                    // no valid response from service
                    var error = errors[0];
                    throw new CanonicalException($"{error.Type}-{error.Code}", error.Message,
                        from e in errors
                        select new BaseException.InnerError
                        {
                            ErrorCode = e.Code,
                            ErrorMessage = e.Message
                        });
                }
            }
        }
    }
}

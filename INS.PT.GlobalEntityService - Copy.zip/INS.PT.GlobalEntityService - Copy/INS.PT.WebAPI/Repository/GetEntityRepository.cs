﻿using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using models = INS.PT.WebAPI.Models.Elements;
using log4net;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    /// Repository to read an entity by other fields instead of the key.
    /// </summary>
    public class GetEntityRepository : IGetEntity
    {
        // properties
        private readonly ILog log;
        private readonly IMasterService _masterService;
        private readonly ISourceAndResultsMapping mappingRepository;

        /// <summary>
        /// Repository constructor.
        /// </summary>
        /// <param name="mappingRepository">source and results repository.</param>
        /// <param name="masterService">MasterEntity service.</param>
        public GetEntityRepository(ISourceAndResultsMapping mappingRepository, IMasterService masterService)
        {
            log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

            _masterService = masterService ?? throw new ArgumentNullException(nameof(masterService));

            this.mappingRepository = mappingRepository ?? throw new ArgumentNullException(nameof(mappingRepository));
        }

        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        public bool CallsExternalService => false;


        /// <summary>
        /// Method to read information of an entity.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="vatNumber">Input parameters to read the entity.</param>
        /// <returns>null if entity not found. Entity with all information to the entity.</returns>
        public Task<models.Entity> EntityByVatNumberAsync(HeaderParameters headerParameters, string vatNumber)
        {
            // validate parameters
            if (headerParameters == null)
            {
                throw new ArgumentNullException(nameof(headerParameters));
            }
            if (string.IsNullOrEmpty(vatNumber))
            {
                throw new ArgumentNullException(nameof(vatNumber));
            }

            // call method to retrive result object
            return ReadEntityByVatNumberAsync(headerParameters, vatNumber);
        }

        private async Task<models.Entity> ReadEntityByVatNumberAsync(HeaderParameters headerParameters, string vatNumber)
        {
            try
            {
                // read source and mappings
                mappingRepository.ReadSourceAndSctructure(headerParameters, Helpers.MdmOperation.Get);

                var stopwatch = new System.Diagnostics.Stopwatch();

                // log input
                log.Info($"Tecnisys call to GetDNIByNIFAsync: source={headerParameters.BsSolution}; vatNumber={vatNumber}");

                if (mappingRepository.NativeMaster != Helpers.MdmMasterSource.MasterEntityAgeas)
                {
                    throw new BusinessException("Operation not available for this Master!");
                }

                // make call to master entity
                var entity = await _masterService.GetEntityAsync(headerParameters, mappingRepository.IdSource, vatNumber);

                stopwatch.Start();
                // remove data not authorized
                mappingRepository.RemoveUnauthorizedData(entity);
                stopwatch.Stop();

                // log results
                log.Info($"Remove unauthorized data took {stopwatch.ElapsedMilliseconds}ms to executewith result: {JsonConvert.SerializeObject(entity)}");

                // return response object
                return entity;
            }
            catch (BaseException pe)
            {
                // error processing information
                log.Info(pe);
                throw;
            }
            catch (System.ServiceModel.CommunicationException e)
            {
                // unexpected error
                log.Error($"Error reading information from Tecnisys! Error: {e}");

                return null;
            }
        }
    }
}

﻿using Dapper;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Helpers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using log4net;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    /// Repository that will make source making and strutures available for read/update operations
    /// </summary>
    public class SourceAndResultsMappingRepository : ISourceAndResultsMapping
    {
        // properties
        private readonly IDbconnectioncs _connections;
        private readonly ILog log;
        private readonly Func<IDbConnection, OracleDynamicParameters, string, IEnumerable<StructureAccess>> databaseProcedure;


        // constants
        private const string MdmDatabase = "masterdatamanagement";
        private const string MdmPackage = "pkg_mdm_ent_api";
        private const string ProcedureReadSourceAndStructure = "pro_get_mdm_structure_company";

        // procedure parameters constants
        private const int OutputSize = 1000;

        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        public bool CallsExternalService => false;

        #region Public properties
        public string IdSource { get; private set; }

        public string IdSystem { get; private set; }

        public MdmMasterSource NativeMaster { get; private set; }

        /// <summary>
        /// Property that defines if Aml service needs to be called.
        /// </summary>
        public bool NeedsAmlInformation
        {
            get
            {
                var stopRequestToAml = 
                    _structures.Any(s =>
                        // do not make request to Aml information
                        string.Compare(s.Name, "AML-NO-REQUEST", StringComparison.InvariantCultureIgnoreCase) == 0);

                return !stopRequestToAml;
            }
        }
        #endregion

        private IEnumerable<StructureAccess> _structures;
        private HeaderParameters _loadedHeaderParameters;
        private MdmOperation _loadedOperationId;

        /// <summary>
        /// contrutor
        /// </summary>
        /// <param name="connections">connection pool</param>
        public SourceAndResultsMappingRepository(IDbconnectioncs connections) : this(connections, null)
        { }

        /// <summary>
        /// construtor for unit testing
        /// </summary>
        /// <param name="connections">connection pool</param>
        /// <param name="databaseProcedure">parameter to fake db call</param>
        public SourceAndResultsMappingRepository(IDbconnectioncs connections, 
            Func<IDbConnection, OracleDynamicParameters, string, IEnumerable<StructureAccess>> databaseProcedure)
        {
            _loadedHeaderParameters = null;
            log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

            _connections = connections ?? throw new ArgumentNullException(nameof(connections));
            this.databaseProcedure = databaseProcedure ?? ((connection, parameters, command) => 
                SqlMapper.Query<StructureAccess>(connection, command, parameters, commandType: CommandType.StoredProcedure));
        }

        /// <summary>
        /// Reads the mappings for the parameters of the request.
        /// </summary>
        /// <param name="headerParameters">validation parameters to define source and system</param>
        /// <param name="operationId">operation being executed</param>
        public void ReadSourceAndSctructure(HeaderParameters headerParameters, MdmOperation operationId)
        {
            // validate input parameters
            if (headerParameters == null)
            {
                throw new ArgumentNullException(nameof(headerParameters));
            }

            // prevent duplicate calls to database
            if(_loadedHeaderParameters != null && _loadedHeaderParameters == headerParameters
                && _loadedOperationId == operationId)
            {
                // data already present
                return;
            }


            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();
                var parameters = new OracleDynamicParameters();

                // input parameters
                parameters.Add("p_operation", OracleDbType.Varchar2, ParameterDirection.Input, operationId.ToString());
                headerParameters.AddToParameters(parameters);

                // output parameters
                parameters.Add("p_structure", OracleDbType.RefCursor, ParameterDirection.Output);
                parameters.Add("p_dest_src", OracleDbType.Varchar2, ParameterDirection.Output, string.Empty, OutputSize);
                parameters.Add("p_dest_sys", OracleDbType.Varchar2, ParameterDirection.Output, string.Empty, OutputSize);
                parameters.Add("p_cderror", OracleDbType.Int32, ParameterDirection.Output, 0, OutputSize);
                parameters.Add("p_dserror", OracleDbType.Varchar2, ParameterDirection.Output, string.Empty, OutputSize);
                parameters.Add("p_IDSystemMaster", OracleDbType.Varchar2, ParameterDirection.Output, string.Empty, OutputSize);

                var connection = _connections.LocalConnection;
                var command = $"{MdmDatabase}.{MdmPackage}.{ProcedureReadSourceAndStructure}";

                // log call to database and values
                log.Info($"database call to {command}");
                parameters.Log(log, ParameterDirection.Input);

                stopwatch.Start();
                _structures = databaseProcedure.Invoke(connection, parameters, command);
                stopwatch.Stop();
                log.Info($"database took {stopwatch.ElapsedMilliseconds}ms to execute");

                // log results
                parameters.Log(log, ParameterDirection.Output);
                log.Info($"Structures mapped: {JsonConvert.SerializeObject(_structures)}");

                // read output parameters
                IdSource = parameters.GetString("p_dest_src");
                IdSystem = parameters.GetString("p_dest_sys");
                NativeMaster = TransformParameterResult(parameters.GetString("p_IDSystemMaster", MdmMasterSource.MasterEntityAgeas.ToString()));
                var errorCode = parameters.GetInt("p_cderror", -10);
                var errorMessage = parameters.GetString("p_dserror");

                // some error happend
                if (errorCode != 0)
                {
                    // build exception to abort result
                    throw new BusinessException(errorCode.ToString(System.Globalization.NumberFormatInfo.InvariantInfo), errorMessage);
                }

                _loadedOperationId = operationId;
                _loadedHeaderParameters = headerParameters;
            }
            catch (BusinessException)
            {
                // business erros just let then bubble up
                throw;
            }
            catch (Exception e)
            {
                // can't continue execution
                log.Error($"Error reading normalized from package! Error: ", e);
                throw new BusinessException(System.Net.HttpStatusCode.BadRequest, e.Message, e);
            }
        }

        /// <summary>
        /// Check if the entity struture can be retrived and all their sub strutures.
        /// </summary>
        /// <param name="entityStructure">entity struture to check</param>
        public void RemoveUnauthorizedData(IMasterOutputMapping entityStructure)
        {
            // check if there's something to validate
            if (entityStructure == null || _loadedHeaderParameters == null)
            {
                return;
            }

            // find authorization to entity data
            var authorization = _structures.FirstOrDefault(s =>
                string.Compare(s.Name, entityStructure.StructureName, StringComparison.InvariantCultureIgnoreCase) == 0);

            // no access to structure
            if (authorization == null)
            {
                entityStructure.Clear();
                return;
            }

            // this struture is valid, but check sub structures
            foreach (var subStruture in entityStructure.ChildStrutures)
            {
                RemoveUnauthorizedData(subStruture);
            }
        }

        private static MdmMasterSource TransformParameterResult(string outValue)
        {
            if (Enum.TryParse<MdmMasterSource>(outValue, true, out var result))
            {
                return result;
            }

            return MdmMasterSource.MasterEntityAgeas;
        }
    }
}

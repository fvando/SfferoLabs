﻿using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Elements;
using System;
using System.Threading.Tasks;
using AutoMapper;
using log4net;
using Newtonsoft.Json;
using INS.PT.WebAPI.Models.Input;
using Cogen_EntitiesService;
using INS.PT.WebAPI.Interface.Service;
using INS.PT.WebAPI.Models.Output;
using INS.PT.WebAPI.Helpers;
using INS.PT.WebAPI.IdTranslates;
using System.Linq;

namespace INS.PT.WebAPI.Repository.Service
{
    /// <summary>
    /// Class to make actions to cogen service.
    /// </summary>
    public class CogenEntitiesService : ICogenEntities
    {
        public static readonly string MappingIdForCompaniesInCogen = "RDM002_MAP_COGEN";

        private const string ReadEntityActionCode = "C";
        private const string UpsertEntityActionCode = "U";

        private readonly ILog log;
        private readonly IMapper mapper;
        private readonly IRdmHelper rdmHelper;
        // external services
        private readonly IEntitiesService cogenEntitiesService;

        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        public bool CallsExternalService => true;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="mapper">Mapper object to build result objects.</param>
        /// <param name="rdmHelper">Class to make mappings of codes.</param>
        public CogenEntitiesService(IMapper mapper, IRdmHelper rdmHelper) : this(mapper, rdmHelper, null)
        {
        }

        /// <summary>
        /// Constructor for unit tests.
        /// </summary>
        /// <param name="mapper">Mapper object to build result objects.</param>
        /// <param name="rdmHelper">Class to make mappings of codes.</param>
        /// <param name="cogenEntitiesService">The client for Cogen service to get information of entity.</param>
        public CogenEntitiesService(IMapper mapper, IRdmHelper rdmHelper, IEntitiesService cogenEntitiesService)
        {
            // internal member for object
            log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

            // required members to build object
            this.mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            this.rdmHelper = rdmHelper ?? throw new ArgumentNullException(nameof(rdmHelper));

            // proxy object to call remote service
            this.cogenEntitiesService = cogenEntitiesService ?? ProxyBuilder.CreateCogenEntitiesClient();
        }


        /// <summary>
        /// Method to read a Entity from Cogen.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Input parameters to read the entity.</param>
        /// <returns>Entity object with information.</returns>
        public Task<Entity> GetEntityAsync(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            // validate parameters
            if (parameters == null || headerParameters == null)
            {
                return Task.FromResult<Entity>(null);
            }

            return ReadEntityFromCogenAsync(headerParameters, parameters);
        }

        /// <summary>
        /// Method to search an entity based on the search filters given in the parameters.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <param name="parameters">Search filters to make the search.</param>
        /// <returns>Matched results.</returns>
        public Task<SearchEntityOutput> SearchEntityAsync(HeaderParameters headerParameters, SearchEntityInput parameters)
        {
            // validate parameters
            if (parameters == null || headerParameters == null)
            {
                return Task.FromResult<SearchEntityOutput>(null);
            }

            return SearchEntityFromCogenAsync(headerParameters, parameters);
        }

        /// <summary>
        /// Method to create/update an entity into Cogen service.
        /// </summary>
        /// <param name="headerParameters">header parameters that will be needed to call MasterEntity service.</param>
        /// <param name="actionOnEntity">Planned action to take in entity.</param>
        /// <param name="newEntity">data to be updated into entity.</param>
        /// <returns>Entity object that conatins data after updated.</returns>
        public Task<Entity> CreateUpdateEntityAsync(HeaderParameters headerParameters, MdmOperation actionOnEntity, Entity newEntity)
        {
            // validate parameters
            if (newEntity == null || headerParameters == null)
            {
                return Task.FromResult<Entity>(null);
            }

            return CreateUpdateEntityInCogenAsync(headerParameters, actionOnEntity, newEntity);
        }

        private async Task<Entity> CreateUpdateEntityInCogenAsync(HeaderParameters headerParameters, MdmOperation actionOnEntity, Entity newEntity)
        {
            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();

                log.Info($"Cogen prepare update object for request an {actionOnEntity} for entity.");
                
                stopwatch.Start();
                var objectToUpdate = mapper.Map<GetOrMaintainEntityCogenWASPInputData>(newEntity);

                // action code
                objectToUpdate.FunctionCode = UpsertEntityActionCode;

                // values from headers
                if (!rdmHelper.TryReadSource(MappingIdForCompaniesInCogen, headerParameters.IdCompany, out var cogenCompany))
                {
                    throw new Exceptions.CanonicalException("NoCompanyMapping",
                        $"Missing mapping in {MappingIdForCompaniesInCogen} for Cogen of value: {headerParameters.IdCompany}", System.Net.HttpStatusCode.BadRequest);
                }

                objectToUpdate.CompanyCode = cogenCompany;
                objectToUpdate.NetworkCode = headerParameters.IdNetwork;
                stopwatch.Stop();

                log.Info($"Cogen mapping update object => {JsonConvert.SerializeObject(objectToUpdate)} took {stopwatch.ElapsedMilliseconds}ms");

                stopwatch.Restart();
                // prepare request to make
                var request = new getOrMaintainEntityCogenWASPRequest
                {
                    AxisValues = BuildAxisValues(headerParameters),
                    inputData = objectToUpdate
                };
                stopwatch.Stop();
                log.Info($"Cogen prepare update request => {JsonConvert.SerializeObject(request)} took {stopwatch.ElapsedMilliseconds}ms");

                // make call to Cogen
                stopwatch.Restart();
                var cogenResults = await cogenEntitiesService.getOrMaintainEntityCogenWASPAsync(request);
                stopwatch.Stop();

                log.Info($"Cogen update execution took {stopwatch.ElapsedMilliseconds}ms to execute with result: {JsonConvert.SerializeObject(cogenResults)}");

                stopwatch.Restart();

                var cogenEntity = cogenResults.getOrMaintainEntityCogenWASPResult;

                // build an Entity with mapping
                var result = mapper.Map<Entity>(cogenEntity);
                stopwatch.Stop();

                log.Info($"Cogen update entity mapped to {JsonConvert.SerializeObject(result)} and mapping took {stopwatch.ElapsedMilliseconds}ms!");

                return result;
            }
            catch (System.ServiceModel.FaultException fe)
            {
                // log exception from Cogen call
                log.Error($"Fault error updating information to Cogen! Error: {fe}");
                throw new Exceptions.CanonicalException(fe.Code.Name, fe.Message, System.Net.HttpStatusCode.NotFound);
            }
            catch (System.ServiceModel.CommunicationException ce)
            {
                // log exception from Cogen call
                log.Error($"Communication error updating information to Cogen! Error: {ce}");
            }
            catch (AutoMapperMappingException mappingError)
            {
                // log exception from Mapping call
                log.Error($"Error mapping information to Cogen object!", mappingError);
            }

            return null;
        }

        private async Task<SearchEntityOutput> SearchEntityFromCogenAsync(HeaderParameters headerParameters, SearchEntityInput parameters)
        {
            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();

                stopwatch.Start();
                log.Info($"Cogen prepare search object for request.");

                stopwatch.Start();
                var searchToUpdate = mapper.Map<SearchEntityCogenWASPInputData>(parameters);

                // values from headers
                // try to map value of company to cogen values
                if (!rdmHelper.TryReadSource(MappingIdForCompaniesInCogen, headerParameters.IdCompany, out var cogenCompany))
                {
                    throw new Exceptions.CanonicalException("NoCompanyMapping",
                        $"Missing mapping in {MappingIdForCompaniesInCogen} for Cogen of value: {headerParameters.IdCompany}", System.Net.HttpStatusCode.BadRequest);
                }

                searchToUpdate.CompanyCode = cogenCompany;
                searchToUpdate.NetworkCode = headerParameters.IdNetwork;
                stopwatch.Stop();

                log.Info($"Cogen mapping seacrh object => {JsonConvert.SerializeObject(searchToUpdate)} took {stopwatch.ElapsedMilliseconds}ms");

                stopwatch.Restart();
                // prepare request to make
                var request = new searchEntityCogenWASPRequest
                {
                    AxisValues = BuildAxisValues(headerParameters),
                    inputData = searchToUpdate
                };
                stopwatch.Stop();
                log.Info($"Cogen prepare search request => {JsonConvert.SerializeObject(request)} took {stopwatch.ElapsedMilliseconds}ms");

                // make call to Cogen
                stopwatch.Restart();
                var cogenResults = await cogenEntitiesService.searchEntityCogenWASPAsync(request);
                stopwatch.Stop();

                log.Info($"Cogen search execution took {stopwatch.ElapsedMilliseconds}ms to execute with result: {JsonConvert.SerializeObject(cogenResults)}");

                stopwatch.Restart();

                var cogenEntity = cogenResults.searchEntityCogenWASPResult;

                // validate response is good
                if (cogenEntity.status != "0")
                {
                    throw new Exceptions.CanonicalException(cogenEntity.status, cogenEntity.outputMessage, System.Net.HttpStatusCode.NotFound);
                }

                // build an Entity with mapping
                var result = mapper.Map<SearchEntityOutput>(cogenEntity);

                MapCompanyValues(result);

                stopwatch.Stop();

                log.Info($"Cogen search entity mapped to {JsonConvert.SerializeObject(result)} and mapping took {stopwatch.ElapsedMilliseconds}ms!");

                return result;
            }
            catch (System.ServiceModel.FaultException fe)
            {
                // log exception from Cogen call
                log.Error($"Fault error reading information from search Cogen! Error: {fe}");
                throw new Exceptions.CanonicalException(fe.Code.Name, fe.Message, System.Net.HttpStatusCode.NotFound);
            }
            catch (System.ServiceModel.CommunicationException ce)
            {
                // log exception from Cogen call
                log.Error($"Communication error reading information from search Cogen! Error: {ce}");
            }
            catch (AutoMapperMappingException mappingError)
            {
                // log exception from Mapping call
                log.Error($"Error mapping information to Cogen object!", mappingError);
            }

            return null;
        }

        private void MapCompanyValues(SearchEntityOutput result)
        {
            if (result?.MatchedEntities != null && result.MatchedEntities.Any())
            {
                foreach (var ent in result.MatchedEntities)
                {
                    // try to map value of company to RDM values
                    if (rdmHelper.TryReadDestination(MappingIdForCompaniesInCogen, ent.IdCompany, out var rdmCompany))
                    {
                        ent.IdCompany = rdmCompany;
                    }
                }
            }
        }

        private async Task<Entity> ReadEntityFromCogenAsync(HeaderParameters headerParameters, EntitiesInput parameters)
        {
            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();

                stopwatch.Start();
                // prepare request to make
                var request = new getOrMaintainEntityCogenWASPRequest
                {
                    AxisValues = BuildAxisValues(headerParameters),
                    inputData = new GetOrMaintainEntityCogenWASPInputData
                    {
                        FunctionCode = ReadEntityActionCode,
                        ClientReferenceCGN = parameters.IdEntity
                    }
                };
                stopwatch.Stop();
                log.Info($"Cogen prepare request => {JsonConvert.SerializeObject(request)} took {stopwatch.ElapsedMilliseconds}ms");

                // make call to Cogen
                stopwatch.Restart();
                var cogenResults = await cogenEntitiesService.getOrMaintainEntityCogenWASPAsync(request);
                stopwatch.Stop();

                log.Info($"Cogen execution took {stopwatch.ElapsedMilliseconds}ms to execute with result: {JsonConvert.SerializeObject(cogenResults)}");

                stopwatch.Restart();

                var cogenEntity = cogenResults.getOrMaintainEntityCogenWASPResult;

                // build an Entity with mapping
                var result = mapper.Map<Entity>(cogenEntity);
                stopwatch.Stop();

                log.Info($"Cogen entity mapped to {JsonConvert.SerializeObject(result)} and mapping took {stopwatch.ElapsedMilliseconds}ms!");

                return result;
            }
            catch (System.ServiceModel.FaultException fe)
            {
                // log exception from Cogen call
                log.Error($"Fault error reading information from Cogen! Error: {fe}");
                throw new Exceptions.CanonicalException(fe.Code.Name, fe.Message, System.Net.HttpStatusCode.NotFound);
            }
            catch (System.ServiceModel.CommunicationException ce)
            {
                // log exception from Cogen call
                log.Error($"Communication error reading information from Cogen! Error: {ce}");
            }
            catch (AutoMapperMappingException mappingError)
            {
                // log exception from Mapping call
                log.Error($"Error mapping information to Cogen object!", mappingError);
            }

            return null;
        }


        /// <summary>
        /// Method with logic to build the AxisValues of service call.
        /// </summary>
        /// <param name="headerParameters">header parameters to determine the logic.</param>
        /// <returns>new object ready to be used in call.</returns>
        private static AxisValues BuildAxisValues(HeaderParameters headerParameters)
        {
            return new AxisValues
            {
                Solution = ApplicationSettings.AxisSolution,
                User = headerParameters.BsUser
            };
        }
    }
}

﻿using INS.PT.WebAPI.Interface.Service;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Elements;
using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using log4net;
using Newtonsoft.Json;
using AmlGet;
using AmlSet;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Repository.Service
{
    /// <summary>
    /// Aml services calls.
    /// </summary>
    /// <seealso cref="IAmlService" />
    public class AmlService : IAmlService
    {
        private readonly ILog log;
        private readonly IMapper mapper;
        // external services
        private readonly IEntitiesInquiriesService amlGetService;
        private readonly IEntitiesMaintainService amlSetService;

        // property to keep the last aml data read
        private GetAMLDataWASPOutputData previousAmlData;

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="mapper">Mapper object to build result objects.</param>
        public AmlService(IMapper mapper) : this(mapper, null, null)
        {
        }

        /// <summary>
        /// Constructor.
        /// </summary>
        /// <param name="mapper">Mapper object to build result objects.</param>
        /// <param name="amlGetService">The client for AML service to get information.</param>
        /// <param name="amlSetService">The client for AML service to update information.</param>
        public AmlService(IMapper mapper, IEntitiesInquiriesService amlGetService, IEntitiesMaintainService amlSetService)
        {
            log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            previousAmlData = null;
            this.mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            this.amlGetService = amlGetService ?? Helpers.ProxyBuilder.CreateAmlGetClient();
            this.amlSetService = amlSetService ?? Helpers.ProxyBuilder.CreateAmlSetClient();
        }


        /// <summary>
        /// Property to get nationality before update.
        /// </summary>
        public Nationality GetPreviousNationality
        {
            get
            {
                if (string.IsNullOrEmpty(previousAmlData?.ARGUSLst.First().otherNationalities))
                {
                    return null;
                }

                return new Nationality { IsPrincipal = false, NationalityCode = previousAmlData?.ARGUSLst?.First().otherNationalities };
            }
        }

        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        public bool CallsExternalService => true;


        /// <summary>
        /// Method to update the Aml data from the entity into the service.
        /// </summary>
        /// <param name="headerParameters">header parameters that will be needed to call Aml service.</param>
        /// <param name="entity">Entity object where to append the information</param>
        /// <returns>true if update runs successfully.</returns>
        public async Task<bool> SetAmlAsync(HeaderParameters headerParameters, Entity entity)
        {
            try
            {
                // validate parameters
                if (entity == null)
                {
                    return false;
                }

                var stopwatch = new System.Diagnostics.Stopwatch();
                var request = InsertUpdateAmlInformation.RequestToUpdateInformation(
                    log, mapper, previousAmlData?.ARGUSLst?.First(), headerParameters, entity);

                // make call to AML
                stopwatch.Start();
                var amlResults = await amlSetService.maintainAMLDataWASPAsync(request);
                stopwatch.Stop();

                log.Info($"Aml execution took {stopwatch.ElapsedMilliseconds}ms to execute with result: {JsonConvert.SerializeObject(amlResults)}");

                // validate response
                var amlResponse = amlResults.maintainAMLDataWASPResult;

                return string.Compare(amlResponse.outputMessage, "OK", StringComparison.InvariantCultureIgnoreCase) == 0;
            }
            catch (System.ServiceModel.CommunicationException ce)
            {
                // log exception from AML call
                log.Error($"Communication error reading information from Aml! Error: {ce}");
            }

            return false;
        }


        /// <summary>
        /// Method to read the Aml data into the Entity.
        /// </summary>
        /// <param name="headerParameters">header parameters that will be needed to call Aml service.</param>
        /// <param name="idEntity">Entity identifier</param>
        /// <returns>Task object</returns>
        public async Task GetAmlAsync(HeaderParameters headerParameters, string idEntity)
        {
            try
            {
                previousAmlData = null;

                // validate parameters
                if (idEntity == null)
                {
                    return;
                }

                var stopwatch = new System.Diagnostics.Stopwatch();
                // prepare request to make
                var request = ReadAmlInformation.PrepareRequest(log, headerParameters, idEntity);

                // make call to AML
                stopwatch.Start();
                var amlResults = await amlGetService.getAMLDataWASPAsync(request);
                stopwatch.Stop();

                log.Info($"Aml execution took {stopwatch.ElapsedMilliseconds}ms to execute with result: {JsonConvert.SerializeObject(amlResults)}");

                // validate response
                var amlResponse = amlResults.getAMLDataWASPResult;

                if (string.Compare(amlResponse.outputMessage, "OK", StringComparison.InvariantCultureIgnoreCase) != 0)
                {
                    // no data to read
                    return;
                }

                // keep information for updates
                previousAmlData = amlResponse;
            }
            catch (System.ServiceModel.CommunicationException ce)
            {
                // log exception from AML call
                log.Error($"Communication error reading information from Aml! Error: {ce}");
            }
        }

        /// <summary>
        /// Mehtod to merge information from an Entity read from AML into a Entity object from a master.
        /// </summary>
        /// <param name="masterEntity">master Entity object</param>
        public void MergeAmlToEntity(Entity masterEntity)
        {
            if (masterEntity == null || previousAmlData == null || !previousAmlData.ARGUSLst.Any())
            {
                // nothing to map
                return;
            }

            ReadAmlInformation.Read(mapper, masterEntity, previousAmlData);
        }


        static class ReadAmlInformation
        {
            /// <summary>
            /// Reads the aml information.
            /// </summary>
            /// <param name="entity">The entity.</param>
            /// <param name="amlResponse">The aml response.</param>
            internal static void Read(IMapper mapper, Entity entity, GetAMLDataWASPOutputData amlResponse)
            {
                // read all AML information returned
                foreach (var entityAmlData in amlResponse.ARGUSLst)
                {
                    // extract AMLs from response
                    if (entity.Amls != null && !string.IsNullOrEmpty(entityAmlData.pep))
                    {
                        entity.Amls.Add(mapper.Map<Aml>(entityAmlData));
                    }

                    // for company entity
                    ReadCompanyEntityInfo(entity, entityAmlData);

                    // for person entity
                    ReadIndividualEntityInfo(entity, entityAmlData);

                    // for identity document
                    FillDocumentInformation(entity.Documents, entityAmlData);

                    // for businessCountry
                    ReadCaeEntityInfo(entity, entityAmlData);
                }
            }

            /// <summary>
            /// Fills the document information.
            /// </summary>
            /// <param name="documents">The collection of documents.</param>
            /// <param name="entityAmlData">The entity aml data.</param>
            private static void FillDocumentInformation(ICollection<Document> documents, AMLOutputElement entityAmlData)
            {
                // try to get the id document of the entity
                var ccDoc = Document.GetIdentityCard(documents);

                if (ccDoc == null && !string.IsNullOrEmpty(entityAmlData.identityDoc))
                {
                    ccDoc = Document.CreateIdentityCard();
                    documents.Add(ccDoc);
                }

                // if entity has id docuemnt, fill the date from AML
                if (ccDoc != null)
                {
                    ccDoc.DocumentNumber = entityAmlData.identityDoc;
                    ccDoc.ExpirationDate = entityAmlData.identityDocDateSpecified
                        && entityAmlData.identityDocDate != DateTime.MinValue
                        ? entityAmlData.identityDocDate : (DateTime?)null;
                }
            }

            /// <summary>
            /// Reads the individual entity information.
            /// </summary>
            /// <param name="entity">The entity.</param>
            /// <param name="entityAmlData">The entity aml data.</param>
            private static void ReadIndividualEntityInfo(Entity entity, AMLOutputElement entityAmlData)
            {
                // if entity is a person fill the data coming from AML
                if (entity.Type?.Individual != null)
                {
                    entity.Type.Individual.PlaceOfBirth = entityAmlData.placeOfBirth;

                    // for nationalities
                    ReadNationalities(entity, entityAmlData);
                }
            }

            /// <summary>
            /// Reads the company entity information.
            /// </summary>
            /// <param name="entity">The entity.</param>
            /// <param name="entityAmlData">The entity aml data.</param>
            private static void ReadCompanyEntityInfo(Entity entity, AMLOutputElement entityAmlData)
            {
                // if entity is a organization fill the data coming from AML
                if (entity.Type?.Company != null && !string.IsNullOrEmpty(entityAmlData.countryRegisteredOffice))
                {
                    entity.Type.Company.ConstitutionCountryCode = entityAmlData.countryRegisteredOffice;
                }
            }

            /// <summary>
            /// Reads the businessCountry for the entity cae.
            /// </summary>
            /// <param name="entity">The entity.</param>
            /// <param name="entityAmlData">The entity aml data.</param>
            private static void ReadCaeEntityInfo(Entity entity, AMLOutputElement entityAmlData)
            {
                var entityCae = entity.Caes?.FirstOrDefault(c => string.IsNullOrEmpty(c.CountryCode));

                // if there's a Cae without country filled use that CAE for business country
                if (entityCae != null)
                {
                    entityCae.CountryCode = entityAmlData.businessCountry;
                }
            }

            /// <summary>
            /// Reads the nationalities.
            /// </summary>
            /// <param name="entity">The entity.</param>
            /// <param name="entityAmlData">The entity aml data.</param>
            private static void ReadNationalities(Entity entity, AMLOutputElement entityAmlData)
            {
                // if there's another nationality add to the list of the entity
                if (!string.IsNullOrEmpty(entityAmlData.otherNationalities))
                {
                    var otherNationality = new Nationality
                    {
                        NationalityCode = entityAmlData.otherNationalities,
                        IsPrincipal = false
                    };

                    entity.Type.Individual.Nationalities.Add(otherNationality);
                }
            }

            /// <summary>
            /// Prepares the get request.
            /// </summary>
            /// <param name="headerParameters">The header parameters.</param>
            /// <param name="idEntity">The entity identifier.</param>
            /// <returns></returns>
            internal static getAMLDataWASPRequest PrepareRequest(ILog log, HeaderParameters headerParameters, string idEntity)
            {
                // build read reqeust and log it
                var request = new getAMLDataWASPRequest
                {
                    AxisValues = new AmlGet.AxisValues
                    {
                        Solution = ApplicationSettings.AxisSolution,
                        User = headerParameters.BsUser
                    },
                    inputData = new GetAMLDataWASPInputData
                    {
                        ClearCache = false,
                        entityNumber = idEntity,
                    }
                };

                log.Info($"Aml call: {request.SerializeObjectToXml()}");
                return request;
            }
        }



        static class InsertUpdateAmlInformation
        {
            private static AMLOutputElement previousAmlData;
            private static IMapper mapper;

            /// <summary>
            /// Requests to update information.
            /// </summary>
            /// <param name="headerParameters">The header parameters.</param>
            /// <param name="entity">The entity.</param>
            /// <returns></returns>
            internal static maintainAMLDataWASPRequest RequestToUpdateInformation(
                ILog log, IMapper mappings, AMLOutputElement amlData, 
                HeaderParameters headerParameters, Entity entity)
            {
                // parent properties
                previousAmlData = amlData;
                mapper = mappings;

                // build insert/update request and log it
                var amlInformation = BuildUpdateAmlInformation(entity);

                var request = new maintainAMLDataWASPRequest
                {
                    AxisValues = new AmlSet.AxisValues
                    {
                        Solution = ApplicationSettings.AxisSolution,
                        User = headerParameters.BsUser
                    },
                    inputData = new MaintainAMLDataWASPInputData
                    {
                        // audit fields
                        networkCode = headerParameters.IdNetwork,
                        sourceSystem = headerParameters.BsSolution,
                        userId = headerParameters.BsUser,
                        companyCode = headerParameters.IdCompany,


                        // individual information
                        placeOfBirth = amlInformation.placeOfBirth,
                        otherNationalities = amlInformation.otherNationalities,

                        // information from AML structure
                        pep = amlInformation.pep,
                        pepConditionEndDate = amlInformation.pepConditionEndDate,
                        pepConditionEndDateSpecified = amlInformation.pepConditionEndDateSpecified,
                        pepConditionStartDate = amlInformation.pepConditionStartDate,
                        pepConditionStartDateSpecified = amlInformation.pepConditionStartDateSpecified,

                        // identity document
                        identityDocDate = amlInformation.identityDocDateSpecified ? amlInformation.identityDocDate : (DateTime?)null,
                        identityDocDateSpecified = amlInformation.identityDocDateSpecified,
                        identityDoc = amlInformation.identityDoc,

                        // company information
                        countryRegisteredOffice = amlInformation.countryRegisteredOffice,

                        // from cae
                        businessCountry = amlInformation.businessCountry,

                        // other fields to keep information if any
                        argusLastCheckDate = amlInformation.argusLastCheckDate,
                        argusLastCheckDateSpecified = amlInformation.argusLastCheckDateSpecified,
                        argusLevel = amlInformation.argusLevel,
                        argusNextCheckDate = amlInformation.argusNextCheckDate,
                        argusNextCheckDateSpecified = amlInformation.argusNextCheckDateSpecified,
                        argusState = amlInformation.argusState,
                        cis = amlInformation.cis,
                        corporateName = amlInformation.corporateName,
                        countryOfBirth = amlInformation.countryOfBirth,
                        employer = amlInformation.employer,
                        entityNumber = amlInformation.entityNumber,
                        entityType = amlInformation.entityType,
                        fiscalNumber = amlInformation.fiscalNumber,
                        totalEmployees = amlInformation.totalEmployees,
                        totalEmployeesSpecified = amlInformation.totalEmployeesSpecified,
                        ClearCache = false
                    }
                };

                log.Info($"Aml call: {request.SerializeObjectToXml()}");
                return request;
            }

            /// <summary>
            /// Builds the update aml information.
            /// </summary>
            /// <param name="entity">The entity.</param>
            /// <returns></returns>
            private static AMLOutputElement BuildUpdateAmlInformation(Entity entity)
            {
                // keep previous information or prepare new object
                var amlInformation = previousAmlData ?? new AMLOutputElement
                {
                    //corporateName=
                    //countryOfBirth=
                    //employer=
                    entityNumber = entity.IdEntity,
                    entityType = entity.Type.Individual != null ? "P" : "C",
                    fiscalNumber = entity.VatNumber
                };

                // to update information clear invalid dates
                ClearInvalidDates(amlInformation);

                // information from AML structure
                MapAmlStruture(entity, amlInformation);

                // individual information
                MapIndividualEntityInfo(entity, amlInformation);

                // identity document
                MapIdentityDocumentInfo(entity, amlInformation);

                // company information
                MapCompanyEntityInfo(entity, amlInformation);

                // Cae information
                MapCaeEntityInfo(entity, amlInformation);

                return amlInformation;
            }

            /// <summary>
            /// Maps the businessCountry from the first Cae.
            /// </summary>
            /// <param name="entity"></param>
            /// <param name="amlInformation"></param>
            private static void MapCaeEntityInfo(Entity entity, AMLOutputElement amlInformation)
            {
                var entityCae = entity.Caes?.FirstOrDefault(c => !string.IsNullOrEmpty(c.CountryCode));

                // if there's a Cae with country filled use that country for business country
                if(entityCae != null)
                {
                    amlInformation.businessCountry = entityCae.CountryCode;
                }
            }

            /// <summary>
            /// Maps the company entity information.
            /// </summary>
            /// <param name="entity">The entity.</param>
            /// <param name="amlInformation">The aml information.</param>
            private static void MapCompanyEntityInfo(Entity entity, AMLOutputElement amlInformation)
            {
                // if it's an organization entity update information to AML
                amlInformation.countryRegisteredOffice = entity.Type?.Company != null ?
                    entity.Type.Company.ConstitutionCountryCode
                    : previousAmlData?.countryRegisteredOffice;
            }

            /// <summary>
            /// Maps the identity document information.
            /// </summary>
            /// <param name="entity">The entity.</param>
            /// <param name="amlInformation">The aml information.</param>
            private static void MapIdentityDocumentInfo(Entity entity, AMLOutputElement amlInformation)
            {
                // search id document of entity and update information to AML
                var idDoc = Document.GetIdentityCard(entity.Documents);
                if (idDoc != null)
                {
                    // for new records add the id document number
                    if (previousAmlData == null)
                    {
                        amlInformation.identityDoc = idDoc.DocumentNumber;
                    }
                    amlInformation.identityDoc = idDoc.DocumentNumber;
                    amlInformation.identityDocDate = idDoc.ExpirationDate ?? DateTime.Now;
                    amlInformation.identityDocDateSpecified = idDoc.ExpirationDate.HasValue;
                }
                else
                {
                    amlInformation.identityDoc = previousAmlData?.identityDoc;
                    amlInformation.identityDocDate = previousAmlData?.identityDocDate ?? DateTime.Now;
                    amlInformation.identityDocDateSpecified = previousAmlData?.identityDocDateSpecified ?? false;
                }
            }

            /// <summary>
            /// Maps the individual entity information.
            /// </summary>
            /// <param name="entity">The entity.</param>
            /// <param name="amlInformation">The aml information.</param>
            private static void MapIndividualEntityInfo(Entity entity, AMLOutputElement amlInformation)
            {
                // if it's a person entity update information to AML
                if (entity.Type?.Individual != null)
                {
                    amlInformation.placeOfBirth = entity.Type.Individual.PlaceOfBirth;
                    amlInformation.otherNationalities = null;
                    if (entity.Type.Individual.Nationalities != null &&
                        entity.Type.Individual.Nationalities.Any(n => !n.IsPrincipal))
                    {
                        amlInformation.otherNationalities = entity.Type.Individual.Nationalities.First(n => !n.IsPrincipal).NationalityCode;
                    }
                }
                else
                {
                    amlInformation.placeOfBirth = previousAmlData?.placeOfBirth;
                    amlInformation.otherNationalities = previousAmlData?.otherNationalities;
                }
            }

            /// <summary>
            /// Maps the aml struture.
            /// </summary>
            /// <param name="entity">The entity.</param>
            /// <param name="amlInformation">The aml information.</param>
            private static void MapAmlStruture(Entity entity, AMLOutputElement amlInformation)
            {
                // read Aml struture and update it to AML
                if (entity.Amls != null && entity.Amls.Any())
                {
                    var entityAml = mapper.Map<AMLOutputElement>(entity.Amls.First());

                    amlInformation.pep = entityAml.pep;
                    amlInformation.pepConditionEndDate = entityAml.pepConditionEndDate;
                    amlInformation.pepConditionEndDateSpecified = entityAml.pepConditionEndDateSpecified;
                    amlInformation.pepConditionStartDate = entityAml.pepConditionStartDate;
                    amlInformation.pepConditionStartDateSpecified = entityAml.pepConditionStartDateSpecified;
                }
            }

            /// <summary>
            /// Clears the invalid dates.
            /// </summary>
            /// <param name="amlInformation">The aml information.</param>
            private static void ClearInvalidDates(AMLOutputElement amlInformation)
            {
                // if there's previous information from AML clear the invalid dates
                if (previousAmlData != null)
                {
                    // clear date fields for invalid dates
                    amlInformation.argusLastCheckDateSpecified =
                        amlInformation.argusLastCheckDate != DateTime.MinValue;
                    amlInformation.argusNextCheckDateSpecified =
                        amlInformation.argusNextCheckDate != DateTime.MinValue;
                    amlInformation.pepConditionEndDateSpecified =
                        amlInformation.pepConditionEndDate != DateTime.MinValue;
                    amlInformation.pepConditionStartDateSpecified =
                        amlInformation.pepConditionStartDate != DateTime.MinValue;
                    amlInformation.identityDocDateSpecified =
                        amlInformation.identityDocDate != DateTime.MinValue;
                }
            }

        }
    }
}

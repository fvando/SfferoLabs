﻿using AutoMapper;
using INS.PT.WebAPI.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Output;
using log4net;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Tecnisys;

namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    /// Creditor entities repository.
    /// </summary>
    public class LendersRepository : ILenders
    {
        // properties
        private readonly ILog log;
        private readonly IMasterEntity masterEntityService;
        private readonly IMapper mapper;
        private readonly ISourceAndResultsMapping mappingRepository;

        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        public bool CallsExternalService => false;


        /// <summary>
        /// constructor for unit tests
        /// </summary>
        public LendersRepository(IMasterEntity masterEntityService, ISourceAndResultsMapping mappingRepository, IMapper mapper)
        {
            log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            this.masterEntityService = masterEntityService ?? Helpers.ProxyBuilder.CreateMasterClient();
            this.mappingRepository = mappingRepository ?? throw new ArgumentNullException(nameof(mappingRepository));
            this.mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="mappingRepository"></param>
        public LendersRepository(ISourceAndResultsMapping mappingRepository, IMapper mapper) : this(null, mappingRepository, mapper)
        {
        }


        /// <summary>
        /// Method to read creditor entities from MasterEntity service.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <returns>list of information found in master entity</returns>
        public Task<IEnumerable<LendersOutput>> GetLendersAsync(HeaderParameters headerParameters)
        {
            // validate parameters
            if (headerParameters == null)
            {
                throw new ArgumentNullException(nameof(headerParameters));
            }

            return CreditorEntitiesAsync(headerParameters);
        }


        /// <summary>
        /// Method to read creditor entities from MasterEntity service.
        /// </summary>
        /// <param name="headerParameters">Header parameters, commom to all calls.</param>
        /// <returns>list of information found in master entity</returns>
        private async Task<IEnumerable<LendersOutput>> CreditorEntitiesAsync(HeaderParameters headerParameters)
        {
            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();
                // read source and mappings
                mappingRepository.ReadSourceAndSctructure(headerParameters, Helpers.MdmOperation.Get);

                if (mappingRepository.NativeMaster != Helpers.MdmMasterSource.MasterEntityAgeas)
                {
                    throw new BusinessException("Operation not available for this Master!");
                }

                // log input
                log.Info($"Tecnisys call to GetCreditorEntitiesAsync");
                stopwatch.Start();

                // make call to master entity
                var tecnisysResult = await masterEntityService.GetCretidorEntitiesAsync(
                    new GetCretidorEntitiesRequest
                    {
                        // commom parameters from config
                        AxisValues = new AxisValues
                        {
                            Solution = ApplicationSettings.AxisSolution,
                            User = headerParameters.BsUser
                        },
                        source = mappingRepository.IdSource
                    });
                stopwatch.Stop();

                // log results
                log.Info($"master execution took {stopwatch.ElapsedMilliseconds}ms to execute with result: {JsonConvert.SerializeObject(tecnisysResult)}");

                // prepare result
                var tecnisysValues = tecnisysResult.GetCretidorEntitiesResult;

                // read errors to return
                if (tecnisysValues.Entities == null || tecnisysValues.Errors.Length > 0)
                {
                    if (tecnisysValues.Errors.Length > 0)
                    {
                        var error = tecnisysValues.Errors[0];
                        // if there are errors then register exception with all errors
                        throw new CanonicalException($"{error.Type}-{error.Code}", error.Message, HttpStatusCode.NotFound,
                            from e in tecnisysValues.Errors
                            select new BaseException.InnerError
                            {
                                ErrorCode = e.Code,
                                ErrorMessage = e.Message
                            });
                    }

                    throw new CanonicalException("Null response", "Null response", HttpStatusCode.NotFound);
                }

                var result = mapper.Map<IEnumerable<LendersOutput>>(tecnisysValues.Entities);

                // return response object
                return result;
            }
            catch (BaseException pe)
            {
                // error processing information
                log.Info(pe);
                throw;
            }
            catch (System.ServiceModel.CommunicationException e)
            {
                // unexpected error
                log.Error($"Error reading information from Tecnisys! Error: {e}");

                return null;
            }

        }

    }
}

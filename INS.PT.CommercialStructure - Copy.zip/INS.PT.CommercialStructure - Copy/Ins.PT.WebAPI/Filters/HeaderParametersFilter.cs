﻿using INS.PT.WebAPI.Controllers;
using v1 =INS.PT.WebAPI.Controllers.V1;
using v2 =INS.PT.WebAPI.Controllers.V2;
using INS.PT.WebAPI.Models;
using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Collections.Generic;
using System.Linq;

namespace INS.PT.WebAPI.Filters
{
    /// <summary>
    /// Class to add header parameters to the requests.
    /// </summary>
    /// <seealso cref="IOperationFilter" />
    public class HeaderParametersFilter : IOperationFilter
    {
        /// <summary>
        /// List of operations ids that need the headers parameters
        /// </summary>
        private readonly List<string> OperationsWithHeaderParameters =
            new List<string>
            {
                // DeltasAsync
                nameof(v1.CommercialStructureController.DeltasAsync),
                nameof(v2.CommercialStructureController.DeltasAsync),

                // ClassificationsAsync
                nameof(v1.ClassificationAgentsController.ClassificationsAsync),
                nameof(v2.ClassificationAgentsController.ClassificationsAsync),

                // ClassificationsDeltaAsync
                nameof(v1.ClassificationAgentsController.ClassificationsDeltaAsync),
                nameof(v2.ClassificationAgentsController.ClassificationsDeltaAsync),

                // OperationId_DeltaForAgent
                v1.ClassificationAgentsController.OperationId_DeltaForAgent,
                v2.ClassificationAgentsController.OperationId_DeltaForAgent,

                // InspectorsAsync
                nameof(v1.ClassificationAgentsController.InspectorsAsync),
                nameof(v2.ClassificationAgentsController.InspectorsAsync),

                // BranchesAsync
                nameof(v1.ClassificationAgentsController.BranchesAsync),
                nameof(v2.ClassificationAgentsController.BranchesAsync),

                // ZonesAsync
                nameof(v1.ClassificationAgentsController.ZonesAsync),
                nameof(v2.ClassificationAgentsController.ZonesAsync),

                // NetworksAsync
                nameof(v1.ClassificationAgentsController.NetworksAsync),
                nameof(v2.ClassificationAgentsController.NetworksAsync),

                // SharedCommissionAsync
                nameof(v1.AgentsSearchController.SharedCommissionAsync),
                nameof(v2.AgentsSearchController.SharedCommissionAsync)
            };

        /// <summary>
        /// Applies new parameters to the specified operation.
        /// </summary>
        /// <param name="operation">The operation.</param>
        /// <param name="context">The context.</param>

        public void Apply(OpenApiOperation operation, OperationFilterContext context)
        {
            // validate parameters

            if (operation == null // no operation no need to add parameters
                || context == null // no context no need to add parameters
                // only for selected controllers
                || !OperationsWithHeaderParameters.Contains(context.MethodInfo.Name, System.StringComparer.InvariantCultureIgnoreCase)
                )
            {
                return;
            }

            // no operation parameters defined, create collection
            operation.Parameters ??= new List<OpenApiParameter>();

            // add IdCompany
            operation.Parameters.Add(
                new OpenApiParameter
                {
                    Name = nameof(HeaderParameters.IdCompany),
                    In = ParameterLocation.Header,
                    Schema = new OpenApiSchema
                    {
                        Type = "string",
                        // example value
                        Example = new OpenApiString("AGEAS")
                    },
                    Required = true,
                    Description = "Company Id."
                });

            // add bsSolution
            operation.Parameters.Add(
                new OpenApiParameter
                {
                    Name = nameof(HeaderParameters.IdSource),
                    In = ParameterLocation.Header,
                    Schema = new OpenApiSchema
                    {
                        Type = "string",
                        // example value
                        Example = new OpenApiString("TECH")
                    },
                    Required = true,
                    Description = nameof(HeaderParameters.IdSource)
                });
        }
    }
}

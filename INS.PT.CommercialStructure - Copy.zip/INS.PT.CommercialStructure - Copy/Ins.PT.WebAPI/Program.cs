﻿// Copyright Ageas 2019 © - Integration Team

using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;

/// <summary>
///  INS.PT.WebAPI
/// </summary>
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.CLSCompliant(false)]
namespace INS.PT.WebAPI
{
    /// <summary>
    /// Program
    /// </summary>
    public static class Program
    {
        /// <summary>
        /// Main
        /// </summary>
        /// <param name="args"></param>
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args)
                .UseIISIntegration() //IIS Proxy
                .Build()
                .Run();
        }

        /// <summary>
        /// CreateWebHostBuilder
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>();
    }
}

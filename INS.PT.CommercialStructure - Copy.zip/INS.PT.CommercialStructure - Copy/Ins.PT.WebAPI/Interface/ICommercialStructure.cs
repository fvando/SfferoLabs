﻿using INS.PT.WebAPI.Models.V2;
using INS.PT.WebAPI.Models.V2.Deltas;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// INterface for CommercialStructure repository.
    /// </summary>
    public interface ICommercialStructure : IScopedRepository
    {
        /// <summary>
        /// Method to read commercial structure fro given parameters.
        /// </summary>
        /// <param name="type">type of structure to return.</param>
        /// <param name="code">code to filter on the type.</param>
        /// <param name="hideAllChilds">parameter to hide all child structures</param>
        /// <returns>Tree sctructure with all elements that begong to the sctucture.</returns>
        Task<IEnumerable<Group>> ReadStructureAsync(CommercialStructureLevels type, string code, bool hideAllChilds);

        /// <summary>
        /// Method to update/insert element in commercial structure.
        /// </summary>
        /// <param name="levelElement">parameters</param>
        /// <returns>true if operation is sucesseful.</returns>
        Task<bool> UpsertElementInformationAsync(LevelElement levelElement);

        /// <summary>
        /// Get the changes in the structure.
        /// </summary>
        /// <param name="headerParameters">Header parameters</param>
        /// <param name="date">Date filter.</param>
        /// <param name="currentImage">flag to read only current image</param>
        /// <returns>Object with all changes in structure</returns>
        Task<StructureDeltas> ReadStructureDeltasSync(Models.HeaderParameters headerParameters, DateTime? date, bool? currentImage);
    }
}

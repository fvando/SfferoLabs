﻿using INS.PT.WebAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// Interface for AgentsSearch repository.
    /// </summary>
    public interface IAgentsSearch : IScopedRepository
    {
        /// <summary>
        /// Reads the agents from a energiser agent.
        /// </summary>
        /// <param name="agentCode">the energiser agent code.</param>
        /// <returns>list od agents found.</returns>
        Task<IEnumerable<StreamlinedAgent>> GetAgentsFromEnergiserAsync(string agentCode);

        /// <summary>
        /// Reads the agents from a class code.
        /// </summary>
        /// <param name="classCode">class code.</param>
        /// <returns>list od agents found.</returns>
        Task<IEnumerable<AgentMatch>> GetAgentsByClassAsync(string classCode);

        /// <summary>
        /// Reads the agents from a class code.
        /// </summary>
        /// <param name="classCode">class code.</param>
        /// <returns>list od agents found.</returns>
        Task<IEnumerable<Company>> GetAgentsStructureByClassAsync(string classCode);

        /// <summary>
        /// Read the shared commision agent.
        /// </summary>
        /// <param name="headerParameters">header parameters for company and source</param>
        /// <param name="zipCode">zip code to search.</param>
        /// <param name="branchCode">insurance branch code</param>
        /// <returns>agent code if found</returns>
        Task<string> GetSharedCommissionAgentAsync(HeaderParameters headerParameters, string zipCode, string branchCode);
    }
}

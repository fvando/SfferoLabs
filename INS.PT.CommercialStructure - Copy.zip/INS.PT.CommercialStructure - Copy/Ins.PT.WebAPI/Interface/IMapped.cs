﻿namespace INS.PT.WebAPI
{
    /// <summary>
    /// Interface for data models that need mapping load.
    /// </summary>
    public interface IMapped
    {
        /// <summary>
        /// Method that is going to prepare the object mappings.
        /// </summary>
        void CreateMapping();
    }
}

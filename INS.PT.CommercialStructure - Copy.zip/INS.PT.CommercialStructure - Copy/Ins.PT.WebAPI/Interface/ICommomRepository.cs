﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

/// <summary>
/// ins.pt.WebAPI.Interface
/// </summary>
namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// ICommomRepository
    /// </summary>
    public interface ICommomRepository : IScopedRepository
    {
        /// <summary>
        /// Generic method to execute package and return data.
        /// </summary>
        /// <typeparam name="T">output type to be returned.</typeparam>
        /// <typeparam name="L">list type to read from the package refcursor.</typeparam>
        /// <param name="parameters">package parameters.</param>
        /// <param name="oraclePackageWebservices">package name.</param>
        /// <param name="oracleFunction">procedure name.</param>
        /// <returns>object of the type specified.</returns>
        T Submit<T, L>(OracleDynamicParameters parameters, string oraclePackageWebservices, string oracleFunction) where T : OutputDataAndErrors<L>, new();

        /// <summary>
        /// Method to read data of deltas.
        /// </summary>
        /// <param name="parameters">package parameters.</param>
        /// <param name="oraclePackageWebservices">package name.</param>
        /// <param name="oracleFunction">procedure name.</param>
        /// <returns>StructureDeltas object or null</returns>
        Task<StructureDeltas> ReadDeltasAsync(OracleDynamicParameters parameters, string oraclePackageWebservices, string oracleFunction);

        /// <summary>
        /// Method to read the classification deltas.
        /// </summary>
        /// <param name="headerParameters">header parameters</param>
        /// <param name="idAgent">identifier to search</param>
        /// <param name="deltasDate">when supplied the date parameter</param>
        /// <param name="searchType">search by this type of identifier</param>
        /// <returns></returns>
        Task<IEnumerable<AgentClassification>> ReadClassificationDeltasAsync(HeaderParameters headerParameters, string idAgent, DateTime deltasDate,
            ClassificationSearchType searchType);

        /// <summary>
        /// Method to read the classification deltas.
        /// </summary>
        /// <param name="headerParameters">header parameters</param>
        /// <param name="idAgent">identifier to search</param>
        /// <param name="searchType">search by this type of identifier</param>
        /// <returns></returns>
        Task<AgentClassification> ReadClassificationAsync(HeaderParameters headerParameters, string idAgent, 
            ClassificationSearchType searchType);
    }
}

﻿using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.V2;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// Interface for Classifications repository.
    /// </summary>
    public interface IClassifications : IScopedRepository
    {
        /// <summary>
        /// Method to read the classifications of that attribute.
        /// </summary>
        /// <param name="attributeCode">attribute code.</param>
        /// <returns>list of classifications</returns>
        Task<IEnumerable<Classification>> ReadClassificationsByAttributeAsync(string attributeCode);

        /// <summary>
        /// Reads the classifications by protocol asynchronous.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="code">The code.</param>
        /// <param name="attributeCode">The attribute code.</param>
        /// <returns></returns>
        Task<IEnumerable<ClassificationProtocol>> ReadClassificationsByProtocolAsync(CommercialStructureLevels type, string code, string attributeCode);
    }
}

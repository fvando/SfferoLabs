﻿// Copyright Ageas 2020 © - Integration Team

using Dapper;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.V2;
using log4net;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    /// Classifications repository.
    /// </summary>
    public class ClassificationsRepository : IClassifications
    {
        // constants
        private const int SizeBuffer = 1000;
        private const string Database = "nav";
        private const string Package = "PKG_AGE_WEBSERVICES";
        private const string ClassificationsByAttribute = "AGE_CLASS_ATRIBUTOS";
        private const string ClassificationsByProtocol = "GET_CLASSIFICACOES";

        


        private readonly IDbconnectioncs connection;
        private readonly ILog log;

        private readonly Func<IDbConnection, string, OracleDynamicParameters, Task<IEnumerable<Classification>>> readClassificationsByAttribute;
        private readonly Func<IDbConnection, string, OracleDynamicParameters, Task<IEnumerable<ClassificationProtocol>>> readClassificationsByProtocol;

        /// <summary>
        /// Constructor for DI.
        /// </summary>
        /// <param name="connection">connection for database.</param>
        public ClassificationsRepository(IDbconnectioncs connection) : this(connection, null, null)
        { }

        /// <summary>
        /// Constructor for UT.
        /// </summary>
        /// <param name="connection">connection for database.</param>
        /// <param name="readClassificationsByAttribute">database call</param>
        public ClassificationsRepository(IDbconnectioncs connection,
            Func<IDbConnection, string, OracleDynamicParameters, Task<IEnumerable<Classification>>> readClassificationsByAttribute,
            Func<IDbConnection, string, OracleDynamicParameters, Task<IEnumerable<ClassificationProtocol>>> readClassificationsByProtocol)
        {
            log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

            this.connection = connection ?? throw new ArgumentNullException(nameof(connection));

            this.readClassificationsByAttribute = readClassificationsByAttribute ??
                ((conn, command, param) => SqlMapper.QueryAsync<Classification>(conn, command, param, commandType: CommandType.StoredProcedure));

            this.readClassificationsByProtocol = readClassificationsByProtocol ??
                ((conn, command, param) => SqlMapper.QueryAsync<ClassificationProtocol>(conn, command, param, commandType: CommandType.StoredProcedure));


        }


        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        public bool CallsExternalService => false;


        /// <summary>
        /// Method to read the classifications of that attribute.
        /// </summary>
        /// <param name="attributeCode">attribute code.</param>
        /// <returns>list of classifications</returns>
        public async Task<IEnumerable<Classification>> ReadClassificationsByAttributeAsync(string attributeCode)
        {
            const string ErrorCodeParameter = "P_ERRO";
            const string ErrorDescriptionParameter = "P_DSERRO";

            try
            {
                // validate parameters
                if (string.IsNullOrEmpty(attributeCode))
                {
                    return Enumerable.Empty<Classification>();
                }

                var stopwatch = new System.Diagnostics.Stopwatch();

                // prepare database call
                var conn = connection.Connection;
                var command = $"{Database}.{Package}.{ClassificationsByAttribute}";
                var parameters = new OracleDynamicParameters();

                // add input parameters
                parameters.Add("P_ATRIBUTO", Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Input, attributeCode);

                //add output parameters
                parameters.Add("P_DADOS", Oracle.ManagedDataAccess.Client.OracleDbType.RefCursor, ParameterDirection.Output);
                parameters.Add(ErrorCodeParameter, Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Output, null, SizeBuffer);
                parameters.Add(ErrorDescriptionParameter, Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Output, null, SizeBuffer);

                // log information
                log.Info($"database call to {command}");
                parameters.Log(log, ParameterDirection.Input);

                // return data
                stopwatch.Start();
                var result = await readClassificationsByAttribute.Invoke(conn, command, parameters);
                stopwatch.Stop();

                // log output parameters
                parameters.Log(log, ParameterDirection.Output);

                log.Info($"read records took {stopwatch.ElapsedMilliseconds}ms to execute");

                // validate any error
                var errorCode = parameters.GetString(ErrorCodeParameter);
                if (!string.IsNullOrEmpty(errorCode) && errorCode != "00")
                {
                    throw new ProcessErrorException(errorCode, parameters.GetString(ErrorDescriptionParameter));
                }

                return result;
            }
            catch (Exception ex)
            {
                log.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// Reads the classifications by protocol asynchronous.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="code">The code.</param>
        /// <param name="attributeCode">The attribute code.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException"></exception>
        public async Task<IEnumerable<ClassificationProtocol>> ReadClassificationsByProtocolAsync(CommercialStructureLevels type, string code, string attributeCode)
        {
            const string ErrorCodeParameter = "P_ERRO";
            const string ErrorDescriptionParameter = "P_DSERRO";

            try
            {
                // validate parameters
                if (string.IsNullOrEmpty(attributeCode))
                {
                    return Enumerable.Empty<ClassificationProtocol>();
                }

                var stopwatch = new System.Diagnostics.Stopwatch();

                // prepare database call
                var conn = connection.Connection;
                var command = $"{Database}.{Package}.{ClassificationsByProtocol}";
                var parameters = new OracleDynamicParameters();

                // add input parameters
                parameters.Add("P_TIPO", Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Input, type.GetStringValue());
                parameters.Add("P_CODIGO", Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Input, code);
                parameters.Add("P_ATRIBUTO", Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Input, attributeCode);

                //add output parameters
                parameters.Add("P_DADOS", Oracle.ManagedDataAccess.Client.OracleDbType.RefCursor, ParameterDirection.Output);
                parameters.Add(ErrorCodeParameter, Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Output, null, SizeBuffer);
                parameters.Add(ErrorDescriptionParameter, Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Output, null, SizeBuffer);

                // log information
                log.Info($"database call to {command}");
                parameters.Log(log, ParameterDirection.Input);

                // return data
                stopwatch.Start();
                var result = await readClassificationsByProtocol.Invoke(conn, command, parameters);
                stopwatch.Stop();

                // log output parameters
                parameters.Log(log, ParameterDirection.Output);

                log.Info($"read records took {stopwatch.ElapsedMilliseconds}ms to execute");

                // validate any error
                var errorCode = parameters.GetString(ErrorCodeParameter);
                if (!string.IsNullOrEmpty(errorCode) && errorCode != "00")
                {
                    throw new ProcessErrorException(errorCode, parameters.GetString(ErrorDescriptionParameter));
                }

                return result;
            }
            catch (Exception ex)
            {
                log.Error(ex);
                throw;
            }
        }
    }
}

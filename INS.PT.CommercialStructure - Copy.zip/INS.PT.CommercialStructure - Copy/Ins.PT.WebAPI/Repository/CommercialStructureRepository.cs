﻿// Copyright Ageas 2020 © - Integration Team

using Dapper;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using modV2 = INS.PT.WebAPI.Models.V2;
using modV2Delta = INS.PT.WebAPI.Models.V2.Deltas;
using log4net;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using INS.PT.WebAPI.Models.V2.Deltas;
using INS.PT.WebAPI.Repository.Builders;

namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    /// CommercialStructureRepository
    /// </summary>
    public class CommercialStructureRepository : ICommercialStructure
    {
        // constants
        private const int SizeBuffer = 1000;
        private const string ErrorCodeParameter = "P_ERRO";
        private const string ErrorDescriptionParameter = "P_DSERRO";

        // database names
        private const string Database = "nav";
        private const string Package = "PKG_AGE_WEBSERVICES";
        private const string ReadStructureProcedure = "Get_Agente_EC_v2";
        private const string UpsertElementProcedure = "PRO_INS_UPD_LEVEL";
        private const string ReadDeltasProcedure = "ESTRUTURA_COMERCIAL_v2";

        // properties
        private readonly IDbconnectioncs connection;
        private readonly ILog log;

        // logic to read data from database
        private readonly Func<IDbConnection, string, OracleDynamicParameters, Task<IDataReader>> readCommercialStucture;
        private readonly Func<IDbConnection, string, OracleDynamicParameters, Task<int>> updateInformation;

        /// <summary>
        /// Constructor for DI.
        /// </summary>
        /// <param name="connection">connection for database.</param>
        public CommercialStructureRepository(IDbconnectioncs connection) : this(connection, null, null)
        { }

        /// <summary>
        /// Constructor for UT.
        /// </summary>
        /// <param name="connection">connection for database.</param>
        /// <param name="readCommercialStucture">database call</param>
        /// <param name="updateInformation">database call</param>
        public CommercialStructureRepository(IDbconnectioncs connection,
            Func<IDbConnection, string, OracleDynamicParameters, Task<IDataReader>> readCommercialStucture,
            Func<IDbConnection, string, OracleDynamicParameters, Task<int>> updateInformation)
        {
            log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

            // mandatory parameters
            this.connection = connection ?? throw new ArgumentNullException(nameof(connection));

            // UT parameters
            this.readCommercialStucture = readCommercialStucture ??
                ((conn, command, param) => SqlMapper.ExecuteReaderAsync(conn, command, param, commandType: CommandType.StoredProcedure));
            this.updateInformation = updateInformation ??
                ((conn, command, param) => SqlMapper.ExecuteAsync(conn, command, param, commandType: CommandType.StoredProcedure));
        }


        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        public bool CallsExternalService => false;


        /// <summary>
        /// Method to read commercial structure fro given parameters.
        /// </summary>
        /// <param name="type">type of structure to return.</param>
        /// <param name="code">code to filter on the type.</param>
        /// <param name="hideAllChilds">parameter to hide all child structures</param>
        /// <returns>Tree sctructure with all elements that begong to the sctucture.</returns>
        public async Task<IEnumerable<modV2.Group>> ReadStructureAsync(modV2.CommercialStructureLevels type, string code, bool hideAllChilds)
        {
            try
            {
                // validate parameters
                if (string.IsNullOrEmpty(code))
                {
                    // no valid parameters, return empty enumerate
                    return await Task.FromResult(Enumerable.Empty<modV2.Group>());
                }

                var stopwatch = new System.Diagnostics.Stopwatch();

                // prepare database call
                var conn = connection.Connection;
                var command = $"{Database}.{Package}.{ReadStructureProcedure}";
                var parameters = new OracleDynamicParameters();

                // add input parameters
                parameters.Add("p_cdagente", OracleDbType.Varchar2, ParameterDirection.Input, code);
                parameters.Add("p_tipo", OracleDbType.Varchar2, ParameterDirection.Input, type.GetStringValue());
                parameters.Add("p_not_show_child", OracleDbType.Int16, ParameterDirection.Input, hideAllChilds ? 1 : 0);

                //add output parameters
                parameters.Add("p_dados", OracleDbType.RefCursor, ParameterDirection.Output);
                parameters.Add(ErrorCodeParameter, OracleDbType.Varchar2, ParameterDirection.Output, null, SizeBuffer);
                parameters.Add(ErrorDescriptionParameter, OracleDbType.Varchar2, ParameterDirection.Output, null, SizeBuffer);

                // log information
                log.Info($"database call to {command}");
                parameters.Log(log, ParameterDirection.Input);

                // return data
                IEnumerable<modV2.Group> result = null;
                stopwatch.Start();

                using (var recordReader = await readCommercialStucture.Invoke(conn, command, parameters))
                {
                    stopwatch.Stop();
                    log.Info($"procedure took {stopwatch.ElapsedMilliseconds}ms to execute.");

                    // log output parameters
                    parameters.Log(log, ParameterDirection.Output);

                    // validate any error
                    var errorCode = parameters.GetString(ErrorCodeParameter);
                    if (!string.IsNullOrEmpty(errorCode) && errorCode != "00")
                    {
                        throw new ProcessErrorException(errorCode, parameters.GetString(ErrorDescriptionParameter));
                    }

                    // no errors build result objects
                    stopwatch.Restart();
                    result = ReadStructureInformation(recordReader);
                    stopwatch.Stop();
                }

                log.Info($"build response took {stopwatch.ElapsedMilliseconds}ms to execute.");

                return result;
            }
            catch (Exception ex)
            {
                log.Error(ex);
                throw;
            }
        }


        /// <summary>
        /// Method to update/insert element in commercial structure.
        /// </summary>
        /// <param name="levelElement">parameters</param>
        /// <returns>true if operation is sucesseful.</returns>
        public async Task<bool> UpsertElementInformationAsync(modV2.LevelElement levelElement)
        {
            try
            {
                // validate parameters
                if (levelElement == null)
                {
                    // no valid parameters return false
                    return await Task.FromResult(false);
                }

                var stopwatch = new System.Diagnostics.Stopwatch();

                // prepare database call
                var conn = connection.Connection;
                var command = $"{Database}.{Package}.{UpsertElementProcedure}";
                var parameters = new OracleDynamicParameters();

                // add input parameters
                parameters.Add("P_TYPE", OracleDbType.Varchar2, ParameterDirection.Input, levelElement.LevelType.GetStringValue());
                parameters.Add("P_TRANSACTION_TYPE", OracleDbType.Varchar2, ParameterDirection.Input, levelElement.IsNewElement ? "I" : "U");
                parameters.Add("P_CODE", OracleDbType.Varchar2, ParameterDirection.Input, levelElement.Code);
                parameters.Add("P_FATHER_CODE", OracleDbType.Varchar2, ParameterDirection.Input, levelElement.ParentCode);
                parameters.Add("P_DESCRIPTION", OracleDbType.Varchar2, ParameterDirection.Input, levelElement.Description);
                parameters.Add("P_START_DATE", OracleDbType.Date, ParameterDirection.Input, levelElement.StartDate);
                parameters.Add("P_END_DATE", OracleDbType.Date, ParameterDirection.Input, levelElement.EndDate);
                // this parameter should be null, field was default in DB
                parameters.Add("P_COMPANY", OracleDbType.Varchar2, ParameterDirection.Input, null);

                //add output parameters
                parameters.Add("P_ERROR_CODE", OracleDbType.Int16, ParameterDirection.Output);
                parameters.Add("P_ERROR_DESC", OracleDbType.Varchar2, ParameterDirection.Output, null, SizeBuffer);

                // log information
                log.Info($"database call to {command}");
                parameters.Log(log, ParameterDirection.Input);

                // make execution
                stopwatch.Start();
                var recAffected = await updateInformation.Invoke(conn, command, parameters);
                stopwatch.Stop();

                log.Info($"execution affected {recAffected} records and took {stopwatch.ElapsedMilliseconds}ms to execute.");

                // log output parameters
                parameters.Log(log, ParameterDirection.Output);

                // validate any error
                var errorCode = parameters.GetInt("P_ERROR_CODE", 0);
                if (errorCode != 0)
                {
                    throw new ProcessErrorException(errorCode.ToString(System.Globalization.NumberFormatInfo.InvariantInfo), parameters.GetString("P_ERROR_DESC"));
                }

                return await Task.FromResult(true);
            }
            catch (Exception ex)
            {
                log.Error(ex);
                throw;
            }
        }


        /// <summary>
        /// Get the changes in the structure.
        /// </summary>
        /// <param name="headerParameters">Header parameters</param>
        /// <param name="date">Date filter.</param>
        /// <param name="currentImage">flag to read only current image</param>
        /// <returns>Object with all changes in structure</returns>
        public async Task<modV2Delta.StructureDeltas> ReadStructureDeltasSync(HeaderParameters headerParameters, DateTime? date, bool? currentImage)
        {
            try
            {
                // validate parameters
                if (headerParameters == null || !date.HasValue)
                {
                    // no valid parameters return null
                    return null;
                }

                var stopwatch = new System.Diagnostics.Stopwatch();

                // prepare database call
                var conn = connection.Connection;
                var command = $"{Database}.{Package}.{ReadDeltasProcedure}";
                var parameters = new OracleDynamicParameters();

                // add input parameters
                // add header parameters to package parameters
                headerParameters.AddToParameters(parameters);
                parameters.Add("p_data", OracleDbType.Date, ParameterDirection.Input, date.Value);
                parameters.Add("p_img_actual", OracleDbType.Int32, ParameterDirection.Input, currentImage.HasValue && currentImage.Value ? 1 : 0);


                //add output parameters
                parameters.Add("p_dados", OracleDbType.RefCursor, ParameterDirection.Output);
                parameters.Add(ErrorCodeParameter, OracleDbType.Varchar2, ParameterDirection.Output, null, SizeBuffer);
                parameters.Add(ErrorDescriptionParameter, OracleDbType.Varchar2, ParameterDirection.Output, null, SizeBuffer);

                // log information
                log.Info($"database call to {command}");
                parameters.Log(log, ParameterDirection.Input);

                var result = new modV2Delta.StructureDeltas();
                stopwatch.Start();

                using (var recordReader = await readCommercialStucture.Invoke(conn, command, parameters))
                {
                    stopwatch.Stop();
                    log.Info($"procedure took {stopwatch.ElapsedMilliseconds}ms to execute.");

                    // log output parameters
                    parameters.Log(log, ParameterDirection.Output);

                    // validate any error
                    var errorCode = parameters.GetString(ErrorCodeParameter);
                    if (!string.IsNullOrEmpty(errorCode) && errorCode != "00")
                    {
                        throw new ProcessErrorException(errorCode, parameters.GetString(ErrorDescriptionParameter));
                    }

                    // no errors build result objects
                    stopwatch.Restart();
                    ProcessDeltaRecord(result, recordReader);
                    stopwatch.Stop();
                    recordReader.Close();
                }

                log.Info($"build response took {stopwatch.ElapsedMilliseconds}ms to execute.");

                return result;
            }
            catch (OracleException ex)
            {
                log.Error(ex);
                throw;
            }
        }

        private void ProcessDeltaRecord(modV2Delta.StructureDeltas result, IDataReader recordReader)
        {
            DeltaRecordParsers parsers;
            // setup parsers to read information
            parsers.GroupParser = recordReader.GetRowParser<GroupDelta>();
            parsers.BrandParser = recordReader.GetRowParser<BrandDelta>();
            parsers.ChannelParser = recordReader.GetRowParser<ChannelDelta>();
            parsers.ManagementParser = recordReader.GetRowParser<ManagementDelta>();
            parsers.NetworkParser = recordReader.GetRowParser<modV2Delta.NetworkDelta>();
            parsers.ZoneParser = recordReader.GetRowParser<modV2Delta.ZoneDelta>();
            parsers.BranchParser = recordReader.GetRowParser<modV2Delta.BranchDelta>();
            parsers.InspectorParser = recordReader.GetRowParser<modV2Delta.InspectorDelta>();
            parsers.AgentParser = recordReader.GetRowParser<modV2Delta.AgentDelta>();

            while (recordReader.Read())
            {
                ProcessRecord(recordReader, new RecordProcess { ProcessDeltas = true, DeltaResult = result, DeltasParsers = parsers });
            }
        }

        /// <summary>
        /// row parser for delta functions
        /// </summary>
        internal struct DeltaRecordParsers : IEquatable<DeltaRecordParsers>
        {
            public Func<IDataReader, GroupDelta> GroupParser;
            public Func<IDataReader, BrandDelta> BrandParser;
            public Func<IDataReader, ChannelDelta> ChannelParser;
            public Func<IDataReader, ManagementDelta> ManagementParser;
            public Func<IDataReader, modV2Delta.NetworkDelta> NetworkParser;
            public Func<IDataReader, modV2Delta.ZoneDelta> ZoneParser;
            public Func<IDataReader, modV2Delta.BranchDelta> BranchParser;
            public Func<IDataReader, modV2Delta.InspectorDelta> InspectorParser;
            public Func<IDataReader, modV2Delta.AgentDelta> AgentParser;

            /// <summary>
            /// Method to compare objects
            /// </summary>
            /// <param name="other"></param>
            /// <returns></returns>
            public bool Equals([AllowNull] DeltaRecordParsers other)
            {
                // dummy comparation
                return GroupParser == other.GroupParser;
            }
        }

        /// <summary>
        /// row parser functions
        /// </summary>
        internal struct RecordParsers : IEquatable<RecordParsers>
        {
            public Func<IDataReader, modV2.Group> GroupParser;
            public Func<IDataReader, modV2.Brand> BrandParser;
            public Func<IDataReader, modV2.Channel> ChannelParser;
            public Func<IDataReader, modV2.Managements> ManagementParser;
            public Func<IDataReader, Network> NetworkParser;
            public Func<IDataReader, Zone> ZoneParser;
            public Func<IDataReader, Branch> BranchParser;
            public Func<IDataReader, Inspector> InspectorParser;
            public Func<IDataReader, Agent> AgentParser;

            /// <summary>
            /// Method to compare objects
            /// </summary>
            /// <param name="other"></param>
            /// <returns></returns>
            public bool Equals([AllowNull] RecordParsers other)
            {
                // dummy comparation
                return GroupParser == other.GroupParser;
            }
        }

        /// <summary>
        /// Struct with all parameters to process a record from refcursor
        /// </summary>
        internal struct RecordProcess : IEquatable<RecordProcess>
        {
            public bool ProcessDeltas;

            public ICollection<modV2.Group> StructureResult;
            public RecordParsers StructureParsers;

            public modV2Delta.StructureDeltas DeltaResult;
            public DeltaRecordParsers DeltasParsers;

            /// <summary>
            /// Method to compare objects
            /// </summary>
            /// <param name="other"></param>
            /// <returns></returns>
            public bool Equals([AllowNull] RecordProcess other)
            {
                // dummy comparation
                return ProcessDeltas == other.ProcessDeltas;
            }
        }

        private IEnumerable<modV2.Group> ReadStructureInformation(IDataReader recordReader)
        {
            var result = new List<modV2.Group>();

            // setup parsers to read information
            var parsers = new RecordParsers
            {
                GroupParser = recordReader.GetRowParser<modV2.Group>(),
                BrandParser = recordReader.GetRowParser<modV2.Brand>(),
                ChannelParser = recordReader.GetRowParser<modV2.Channel>(),
                ManagementParser = recordReader.GetRowParser<modV2.Managements>(),
                NetworkParser = recordReader.GetRowParser<Network>(),
                ZoneParser = recordReader.GetRowParser<Zone>(),
                BranchParser = recordReader.GetRowParser<Branch>(),
                InspectorParser = recordReader.GetRowParser<Inspector>(),
                AgentParser = recordReader.GetRowParser<Agent>()
            };

            // process records to result
            while (recordReader.Read())
            {
                ProcessRecord(recordReader, new RecordProcess { ProcessDeltas = false, StructureResult = result, StructureParsers = parsers });
            }

            return result;
        }

        private void ProcessRecord(IDataReader recordReader, RecordProcess processParameters)
        {
            // check record case and read information
            switch (recordReader["TIPO_ESTRUTURA"].ToString())
            {
                // Network
                case "REDE":
                    NetworkProcess(recordReader, processParameters);
                    break;

                // Zone
                case "ZONA":
                    ZoneProcess(recordReader, processParameters);
                    break;

                // Branch
                case "BALCAO":
                    BranchProcess(recordReader, processParameters);
                    break;

                // Inspector
                case "INSPECTOR":
                    InspectorProcess(recordReader, processParameters);
                    break;

                // Agent
                case "AGENTE":
                    AgentProcess(recordReader, processParameters);
                    break;

                // Group
                case "GRUPO":
                    GroupProcess(recordReader, processParameters);
                    break;

                // Brand
                case "MARCA":
                    BrandProcess(recordReader, processParameters);
                    break;

                // Channel
                case "CANAL":
                    ChannelProcess(recordReader, processParameters);
                    break;

                // Management
                case "DIRECAO":
                    ManagementProcess(recordReader, processParameters);
                    break;

                default:
                    log.Error($"Unexpected record type: {recordReader["TIPO_ESTRUTURA"]}");
                    break;
            }
        }

        private static void AgentProcess(IDataReader recordReader, RecordProcess processParameters)
        {
            if (processParameters.ProcessDeltas)
            {
                var agentDelta = processParameters.DeltasParsers.AgentParser(recordReader);
                if (agentDelta != null)
                {
                    processParameters.DeltaResult.AgentDeltas.Add(agentDelta);
                }
            }
            else
            {
                StructureBuilders.BuildAgent(processParameters.StructureResult, recordReader, processParameters.StructureParsers);
            }
        }

        private static void InspectorProcess(IDataReader recordReader, RecordProcess processParameters)
        {
            if (processParameters.ProcessDeltas)
            {
                var inspectorDelta = processParameters.DeltasParsers.InspectorParser(recordReader);
                if (inspectorDelta != null)
                {
                    processParameters.DeltaResult.InspectorDeltas.Add(inspectorDelta);
                }
            }
            else
            {
                StructureBuilders.ReadOrBuildInspector(processParameters.StructureResult, recordReader, processParameters.StructureParsers);
            }
        }

        private static void BranchProcess(IDataReader recordReader, RecordProcess processParameters)
        {
            if (processParameters.ProcessDeltas)
            {
                var branchDelta = processParameters.DeltasParsers.BranchParser(recordReader);
                if (branchDelta != null)
                {
                    processParameters.DeltaResult.BranchDeltas.Add(branchDelta);
                }
            }
            else
            {
                StructureBuilders.ReadOrBuildBranch(processParameters.StructureResult, recordReader, processParameters.StructureParsers);
            }
        }

        private static void ZoneProcess(IDataReader recordReader, RecordProcess processParameters)
        {
            if (processParameters.ProcessDeltas)
            {
                var zoneDelta = processParameters.DeltasParsers.ZoneParser(recordReader);
                if (zoneDelta != null)
                {
                    processParameters.DeltaResult.ZoneDeltas.Add(zoneDelta);
                }
            }
            else
            {
                StructureBuilders.ReadOrBuildZone(processParameters.StructureResult, recordReader, processParameters.StructureParsers);
            }
        }

        private static void NetworkProcess(IDataReader recordReader, RecordProcess processParameters)
        {
            if (processParameters.ProcessDeltas)
            {
                var networkDelta = processParameters.DeltasParsers.NetworkParser(recordReader);
                if (networkDelta != null)
                {
                    processParameters.DeltaResult.NetworkDeltas.Add(networkDelta);
                }
            }
            else
            {
                StructureBuilders.ReadOrBuildNetwork(processParameters.StructureResult, recordReader, processParameters.StructureParsers);
            }
        }

        private static void ManagementProcess(IDataReader recordReader, RecordProcess processParameters)
        {
            if (processParameters.ProcessDeltas)
            {
                var managementDelta = processParameters.DeltasParsers.ManagementParser(recordReader);
                if (managementDelta != null)
                {
                    processParameters.DeltaResult.ManagementDeltas.Add(managementDelta);
                }
            }
            else
            {
                StructureBuilders.ReadOrBuildManagement(processParameters.StructureResult, recordReader, processParameters.StructureParsers);
            }
        }

        private static void ChannelProcess(IDataReader recordReader, RecordProcess processParameters)
        {
            if (processParameters.ProcessDeltas)
            {
                var channelDelta = processParameters.DeltasParsers.ChannelParser(recordReader);
                if (channelDelta != null)
                {
                    processParameters.DeltaResult.ChannelDeltas.Add(channelDelta);
                }
            }
            else
            {
                StructureBuilders.ReadOrBuildChannel(processParameters.StructureResult, recordReader, processParameters.StructureParsers);
            }
        }

        private static void BrandProcess(IDataReader recordReader, RecordProcess processParameters)
        {
            if (processParameters.ProcessDeltas)
            {
                var brandDelta = processParameters.DeltasParsers.BrandParser(recordReader);
                if (brandDelta != null)
                {
                    processParameters.DeltaResult.BrandDeltas.Add(brandDelta);
                }
            }
            else
            {
                StructureBuilders.ReadOrBuildBrand(processParameters.StructureResult, recordReader, processParameters.StructureParsers);
            }
        }

        private static void GroupProcess(IDataReader recordReader, RecordProcess processParameters)
        {
            if (processParameters.ProcessDeltas)
            {
                var groupDelta = processParameters.DeltasParsers.GroupParser(recordReader);
                if (groupDelta != null)
                {
                    processParameters.DeltaResult.GroupDeltas.Add(groupDelta);
                }
            }
            else
            {
                StructureBuilders.ReadOrBuildGroup(processParameters.StructureResult, recordReader, processParameters.StructureParsers);
            }
        }
    }
}

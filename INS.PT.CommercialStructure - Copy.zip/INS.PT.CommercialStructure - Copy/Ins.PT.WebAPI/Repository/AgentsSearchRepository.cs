﻿// Copyright Ageas 2020 © - Integration Team

using Dapper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using log4net;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    /// AgentsSearch repository.
    /// </summary>
    public class AgentsSearchRepository : IAgentsSearch
    {
        // constants
        private const int SizeBuffer = 1000;
        private const string ErrorCodeParameter = "P_ERRO";
        private const string ErrorDescriptionParameter = "P_DSERRO";

        private const string Database = "nav";
        private const string Package = "PKG_AGE_WEBSERVICES";
        private const string SharedCommissionAgent = "Get_Comiss_Partilhado";
        private const string AgentsFromEnergiser = "GET_AGE_DINAMIZADOR";
        private const string AgentsByClass = "AGE_GET_AGENT_BY_CLASS";

        private readonly IDbconnectioncs connection;
        private readonly ILog log;

 
        private readonly Func<IDbConnection, string, OracleDynamicParameters, Task<IEnumerable<StreamlinedAgent>>> readAgents;
        private readonly Func<IDbConnection, string, OracleDynamicParameters, Task<IDataReader>> readSearchAgents;
        private readonly Func<IDbConnection, string, OracleDynamicParameters, Task<int>> readAgentSharedComission;

        /// <summary>
        /// Constructor for DI.
        /// </summary>
        /// <param name="connection">connection for database.</param>
        public AgentsSearchRepository(IDbconnectioncs connection):this (connection, null, null, null)
        { }

        /// <summary>
        /// Constructor for UT.
        /// </summary>
        /// <param name="connection">connection for database.</param>
        /// <param name="readAgents">database call</param>
        /// <param name="readSearchAgents">database call</param>
        /// <param name="readAgentSharedComission">database call</param>
        public AgentsSearchRepository(IDbconnectioncs connection, 
            Func<IDbConnection, string, OracleDynamicParameters, Task<IEnumerable<StreamlinedAgent>>> readAgents,
            Func<IDbConnection, string, OracleDynamicParameters, Task<IDataReader>> readSearchAgents,
            Func<IDbConnection, string, OracleDynamicParameters, Task<int>> readAgentSharedComission)
        {
            log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

            this.connection = connection ?? throw new ArgumentNullException(nameof(connection));
            this.readAgents = readAgents ??
                ((conn, command, param) => SqlMapper.QueryAsync<StreamlinedAgent>(conn, command, param, commandType: CommandType.StoredProcedure));
            this.readSearchAgents = readSearchAgents ??
                ((conn, command, param) => SqlMapper.ExecuteReaderAsync(conn, command, param, commandType: CommandType.StoredProcedure));
            this.readAgentSharedComission = readAgentSharedComission ??
                ((conn, command, param) => SqlMapper.ExecuteAsync(conn, command, param, commandType: CommandType.StoredProcedure));
        }


        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        public bool CallsExternalService => false;


        /// <summary>
        /// Read the shared commision agent.
        /// </summary>
        /// <param name="headerParameters">header parameters for company and source</param>
        /// <param name="zipCode">zip code to search.</param>
        /// <param name="branchCode">insurance branch code</param>
        /// <returns>agent code if found</returns>
        public async Task<string> GetSharedCommissionAgentAsync(HeaderParameters headerParameters, string zipCode, string branchCode)
        {
            const string ResultAgentCodeParameter = "p_cdagente";

            try
            {
                // validate parameters
                if (headerParameters == null ||  string.IsNullOrEmpty(zipCode) ||  string.IsNullOrEmpty(branchCode))
                {
                    return null;
                }

                var stopwatch = new System.Diagnostics.Stopwatch();

                // prepare database call
                var conn = connection.Connection;
                var command = $"{Database}.{Package}.{SharedCommissionAgent}";
                var parameters = new OracleDynamicParameters();

                // add input parameters
                headerParameters.AddToParameters(parameters, true);
                parameters.Add("p_cod_postal", Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Input, zipCode);
                parameters.Add("p_cdramo", Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Input, branchCode);

                //add output parameters
                parameters.Add(ResultAgentCodeParameter, Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Output, null, SizeBuffer);
                parameters.Add(ErrorCodeParameter, Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Output, null, SizeBuffer);
                parameters.Add(ErrorDescriptionParameter, Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Output, null, SizeBuffer);

                // log information
                log.Info($"database call to {command}");
                parameters.Log(log, ParameterDirection.Input);

                // return data
                stopwatch.Start();
                var result = await readAgentSharedComission.Invoke(conn, command, parameters);
                stopwatch.Stop();

                // log output parameters
                parameters.Log(log, ParameterDirection.Output);

                log.Info($"procedure took {stopwatch.ElapsedMilliseconds}ms to execute and affected {result} records.");

                // validate any error
                var errorCode = parameters.GetString(ErrorCodeParameter);
                if (!string.IsNullOrEmpty(errorCode) && errorCode != "00")
                {
                    throw new ProcessErrorException(errorCode, parameters.GetString(ErrorDescriptionParameter));
                }

                return parameters.GetString(ResultAgentCodeParameter, null);
            }
            catch (Exception ex)
            {
                log.Error(ex);
                throw;
            }

        }

        /// <summary>
        /// Reads the agents from a energiser agent.
        /// </summary>
        /// <param name="agentCode">the energiser agent code.</param>
        /// <returns>list od agents found.</returns>
        public async Task<IEnumerable<StreamlinedAgent>> GetAgentsFromEnergiserAsync(string agentCode)
        {
            try
            {
                // validate parameters
                if (string.IsNullOrEmpty(agentCode))
                {
                    return Enumerable.Empty<StreamlinedAgent>();
                }

                var stopwatch = new System.Diagnostics.Stopwatch();

                // prepare database call
                var conn = connection.Connection;
                var command = $"{Database}.{Package}.{AgentsFromEnergiser}";
                var parameters = new OracleDynamicParameters();

                // add input parameters
                parameters.Add("P_AGE_DINAMIZADO", Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Input, agentCode);

                //add output parameters
                parameters.Add("P_DADOS", Oracle.ManagedDataAccess.Client.OracleDbType.RefCursor, ParameterDirection.Output);
                parameters.Add(ErrorCodeParameter, Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Output, null, SizeBuffer);
                parameters.Add(ErrorDescriptionParameter, Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Output, null, SizeBuffer);

                // log information
                log.Info($"database call to {command}");
                parameters.Log(log, ParameterDirection.Input);

                // return data
                stopwatch.Start();
                var result = await readAgents.Invoke(conn, command, parameters);
                stopwatch.Stop();

                // log output parameters
                parameters.Log(log, ParameterDirection.Output);

                log.Info($"read records took {stopwatch.ElapsedMilliseconds}ms to execute");

                // validate any error
                var errorCode = parameters.GetString(ErrorCodeParameter);
                if (!string.IsNullOrEmpty(errorCode) && errorCode != "00")
                {
                    throw new ProcessErrorException(errorCode, parameters.GetString(ErrorDescriptionParameter));
                }

                return result;
            }
            catch (Exception ex)
            {
                log.Error(ex);
                throw;
            }
        }


        /// <summary>
        /// Reads the agents from a class code.
        /// </summary>
        /// <param name="classCode">class code.</param>
        /// <returns>list od agents found.</returns>
        public async Task<IEnumerable<AgentMatch>> GetAgentsByClassAsync(string classCode)
        {
            return await GetDatabaseInfoAsync(classCode, "A", Enumerable.Empty<AgentMatch>());
        }


        /// <summary>
        /// Reads the agents from a class code.
        /// </summary>
        /// <param name="classCode">class code.</param>
        /// <returns>list od agents found.</returns>
        public async Task<IEnumerable<Company>> GetAgentsStructureByClassAsync(string classCode)
        {
            var resultDataTmp = new List<Company>();
            var stopwatch = new System.Diagnostics.Stopwatch();

            var databaseResult = await GetDatabaseInfoAsync(classCode, "EC", Enumerable.Empty<TreeOutputData>());

            // Hierarchy Make
            stopwatch.Start();
            foreach (var item in databaseResult)
            {
                Helper.TransformationData.MakeHierarchyStructure(resultDataTmp, item);
            }
            stopwatch.Stop();
            log.Debug($"Generate output took: {stopwatch.ElapsedMilliseconds}ms");

            return resultDataTmp;
        }


        /// <summary>
        /// Reads the agents from a class code.
        /// </summary>
        /// <param name="classCode">class code.</param>
        /// <param name="searchType">search type</param>
        private async Task<IEnumerable<T>> GetDatabaseInfoAsync<T>(string classCode, string searchType, IEnumerable<T> defaultResponse)
        {
            try
            {
                // validate parameters
                if (string.IsNullOrEmpty(classCode) || string.IsNullOrEmpty(searchType))
                {
                    return defaultResponse;
                }

                var stopwatch = new System.Diagnostics.Stopwatch();

                // prepare database call
                var conn = connection.Connection;
                var command = $"{Database}.{Package}.{AgentsByClass}";
                var parameters = new OracleDynamicParameters();

                // add input parameters
                parameters.Add("P_CLASS", Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Input, classCode);
                parameters.Add("P_TIPO_PESQ", Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Input, searchType);

                //add output parameters
                parameters.Add("P_DADOS", Oracle.ManagedDataAccess.Client.OracleDbType.RefCursor, ParameterDirection.Output);
                parameters.Add(ErrorCodeParameter, Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Output, null, SizeBuffer);
                parameters.Add(ErrorDescriptionParameter, Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, ParameterDirection.Output, null, SizeBuffer);

                // log information
                log.Info($"database call to {command}");
                parameters.Log(log, ParameterDirection.Input);

                // return data
                stopwatch.Start();

                Func<IDataReader, T> rowTransform = null;
                var response = new List<T>();
                using (var recordReader = await readSearchAgents.Invoke(conn, command, parameters))
                {
                    while (recordReader.Read())
                    {
                        rowTransform ??= recordReader.GetRowParser<T>();

                        response.Add(rowTransform.Invoke(recordReader));
                    }
                }

                stopwatch.Stop();

                // log output parameters
                parameters.Log(log, ParameterDirection.Output);

                log.Info($"read records took {stopwatch.ElapsedMilliseconds}ms to execute");

                // validate any error
                var errorCode = parameters.GetString(ErrorCodeParameter);
                if (!string.IsNullOrEmpty(errorCode) && errorCode != "00")
                {
                    throw new ProcessErrorException(errorCode, parameters.GetString(ErrorDescriptionParameter));
                }

                return response;
            }
            catch (Exception ex)
            {
                log.Error(ex);
                throw;
            }
        }
    }
}

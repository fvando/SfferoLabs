﻿// Copyright Ageas 2020 © - Integration Team

using INS.PT.WebAPI.Models;
using modV2 = INS.PT.WebAPI.Models.V2;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using static INS.PT.WebAPI.Repository.CommercialStructureRepository;

namespace INS.PT.WebAPI.Repository.Builders
{
    internal static class StructureBuilders
    {
        public static void BuildAgent(ICollection<modV2.Group> groups, IDataReader recordReader, RecordParsers parsers)
        {
            // read or build parent object
            var inspector = ReadOrBuildInspector(groups, recordReader, parsers);
            var agentCode = recordReader["cdagente"].ToString();

            // check if object already exists
            var agent = inspector.Agents.FirstOrDefault(a => string.Compare(a.Code, agentCode, StringComparison.InvariantCultureIgnoreCase) == 0);

            if (agent == null)
            {
                // build new object to return
                agent = parsers.AgentParser(recordReader);

                // initialize main properties
                agent.Code = agentCode;

                // add to collection
                inspector.Agents.Add(agent);
            }
        }

        public static Inspector ReadOrBuildInspector(ICollection<modV2.Group> groups, IDataReader recordReader, RecordParsers parsers)
        {
            // read or build parent object
            var branch = ReadOrBuildBranch(groups, recordReader, parsers);
            var inspectorCode = recordReader["nivel8"].ToString();

            // check if object already exists
            var inspector = branch.Inspectors.FirstOrDefault(b => string.Compare(b.Code, inspectorCode, StringComparison.InvariantCultureIgnoreCase) == 0);

            if (inspector == null)
            {
                // build new object to return
                inspector = parsers.InspectorParser(recordReader);

                // initialize main properties
                inspector.Code = inspectorCode;
                inspector.Agents = new List<Agent>();

                // add to collection
                branch.Inspectors.Add(inspector);
            }

            return inspector;
        }


        public static Branch ReadOrBuildBranch(ICollection<modV2.Group> groups, IDataReader recordReader, RecordParsers parsers)
        {
            // read or build parent object
            var zone = ReadOrBuildZone(groups, recordReader, parsers);
            var branchCode = recordReader["nivel7"].ToString();

            // check if object already exists
            var branch = zone.Branches.FirstOrDefault(b => string.Compare(b.Code, branchCode, StringComparison.InvariantCultureIgnoreCase) == 0);

            if (branch == null)
            {
                // build new object to return
                branch = parsers.BranchParser(recordReader);

                // initialize main properties
                branch.Code = branchCode;
                branch.Inspectors = new List<Inspector>();

                // add to collection
                zone.Branches.Add(branch);
            }

            return branch;
        }


        public static Zone ReadOrBuildZone(ICollection<modV2.Group> groups, IDataReader recordReader, RecordParsers parsers)
        {
            // read or build parent object
            var network = ReadOrBuildNetwork(groups, recordReader, parsers);
            var zoneCode = recordReader["nivel6"].ToString();

            // check if object already exists
            var zone = network.Zones.FirstOrDefault(z => string.Compare(z.Code, zoneCode, StringComparison.InvariantCultureIgnoreCase) == 0);

            if (zone == null)
            {
                // build new object to return
                zone = parsers.ZoneParser(recordReader);

                // initialize main properties
                zone.Code = zoneCode;
                zone.Branches = new List<Branch>();

                // add to collection
                network.Zones.Add(zone);
            }

            return zone;
        }


        public static Network ReadOrBuildNetwork(ICollection<modV2.Group> groups, IDataReader recordReader, RecordParsers parsers)
        {
            // read or build parent object
            var networkCode = recordReader["nivel5"].ToString();
            var management = ReadOrBuildManagement(groups, recordReader, parsers);

            // check if object already exists
            var network = management.Networks.FirstOrDefault(n => string.Compare(n.Code, networkCode, StringComparison.InvariantCultureIgnoreCase) == 0);

            if (network == null)
            {
                // build new object to return
                network = parsers.NetworkParser(recordReader);

                // initialize main properties
                network.Code = networkCode;
                network.Zones = new List<Zone>();

                // add to collection
                management.Networks.Add(network);
            }

            return network;
        }


        public static modV2.Managements ReadOrBuildManagement(ICollection<modV2.Group> groups, IDataReader recordReader, RecordParsers parsers)
        {
            // read or build parent object
            var managementCode = recordReader["nivel4"].ToString();
            var group = ReadOrBuildChannel(groups, recordReader, parsers);

            // check if object already exists
            var management = group.Managements.FirstOrDefault(n => string.Compare(n.Code, managementCode, StringComparison.InvariantCultureIgnoreCase) == 0);

            if (management == null)
            {
                // build new object to return
                management = parsers.ManagementParser(recordReader);

                // initialize main properties
                management.Code = managementCode;
                management.Networks = new List<Network>();

                // add to collection
                group.Managements.Add(management);
            }

            return management;
        }


        public static modV2.Channel ReadOrBuildChannel(ICollection<modV2.Group> groups, IDataReader recordReader, RecordParsers parsers)
        {
            // read or build parent object
            var channelCode = recordReader["nivel3"].ToString();
            var brand = ReadOrBuildBrand(groups, recordReader, parsers);

            // check if object already exists
            var channel = brand.Channels.FirstOrDefault(n => string.Compare(n.Code, channelCode, StringComparison.InvariantCultureIgnoreCase) == 0);

            if (channel == null)
            {
                // build new object to return
                channel = parsers.ChannelParser(recordReader);

                // initialize main properties
                channel.Code = channelCode;
                channel.Managements = new List<modV2.Managements>();

                // add to collection
                brand.Channels.Add(channel);
            }

            return channel;
        }


        public static modV2.Brand ReadOrBuildBrand(ICollection<modV2.Group> groups, IDataReader recordReader, RecordParsers parsers)
        {
            // read or build parent object
            var brandCode = recordReader["nivel2"].ToString();
            var group = ReadOrBuildGroup(groups, recordReader, parsers);

            // check if object already exists
            var brand = group.Brands.FirstOrDefault(n => string.Compare(n.Code, brandCode, StringComparison.InvariantCultureIgnoreCase) == 0);

            if (brand == null)
            {
                // build new object to return
                brand = parsers.BrandParser(recordReader);

                // initialize main properties
                brand.Code = brandCode;
                brand.Channels = new List<modV2.Channel>();

                // add to collection
                group.Brands.Add(brand);
            }

            return brand;
        }


        public static modV2.Group ReadOrBuildGroup(ICollection<modV2.Group> groups, IDataReader recordReader, RecordParsers parsers)
        {
            // read or build parent object
            var groupCode = recordReader["nivel1"].ToString();

            // check if object already exists
            var group = groups.FirstOrDefault(c => string.Compare(c.Code, groupCode, StringComparison.InvariantCultureIgnoreCase) == 0);

            if (group == null)
            {
                // build new object to return
                group = parsers.GroupParser(recordReader);

                // initialize main properties
                group.Code = groupCode;
                group.Brands = new List<modV2.Brand>();

                // add to collection
                groups.Add(group);
            }

            return group;
        }
    }
}

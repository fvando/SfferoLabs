﻿// Copyright Ageas 2019 © - Integration Team

using Dapper;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Database;
using log4net;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

/// <summary>
/// Ins.pt.WebAPI.Repository
/// </summary>
namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    /// CommomRepository : ICommomRepository
    /// </summary>
    public class CommomRepository : ICommomRepository
    {
        /// <summary>
        /// The size buffer
        /// </summary>
        const int sizeBuffer = 1000;

        private readonly IDbconnectioncs _connection;
        private readonly ILog log;

        /// <summary>
        /// CommomRepository
        /// </summary>
        /// <param name="connection"></param>
        public CommomRepository(IDbconnectioncs connection)
        {
            _connection = connection;
            log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        }


        /// <summary>
        /// Determines if repository calls a service external to the project or only internal services.
        /// </summary>
        public bool CallsExternalService => false;


        /// <summary>
        /// Method to read data of deltas.
        /// </summary>
        /// <param name="parameters">package parameters.</param>
        /// <param name="oraclePackageWebservices">package name.</param>
        /// <param name="oracleFunction">procedure name.</param>
        /// <returns>StructureDeltas object or null</returns>
        public async Task<StructureDeltas> ReadDeltasAsync(OracleDynamicParameters parameters, string oraclePackageWebservices, string oracleFunction)
        {
            return await ReadDeltasAsync(parameters, oraclePackageWebservices, oracleFunction,
                (connection, command, param) => SqlMapper.ExecuteReaderAsync(connection, command, param, commandType: CommandType.StoredProcedure)
                );
        }


        /// <summary>
        /// Method to read data of deltas.
        /// </summary>
        /// <param name="parameters">package parameters.</param>
        /// <param name="oraclePackageWebservices">package name.</param>
        /// <param name="oracleFunction">procedure name.</param>
        /// <returns>StructureDeltas object or null</returns>
        public async Task<StructureDeltas> ReadDeltasAsync(OracleDynamicParameters parameters, string oraclePackageWebservices, string oracleFunction,
            Func<IDbConnection, string, OracleDynamicParameters, Task<IDataReader>> databaseCall)
        {
            try
            {
                // validate parameters
                if (parameters == null)
                {
                    return null;
                }

                var stopwatch = new System.Diagnostics.Stopwatch();
                // prepare results
                var result = new StructureDeltas();

                // prepare database call
                var connection = _connection.Connection;
                var command = $"{oraclePackageWebservices}.{oracleFunction}";

                // log information
                log.Info($"database call to {command}");
                parameters.Log(log, ParameterDirection.Input);

                stopwatch.Start();

                // return data
                using (var reader = await databaseCall(connection, command, parameters))
                {
                    stopwatch.Stop();
                    log.Info($"database took {stopwatch.ElapsedMilliseconds}ms to execute");

                    stopwatch.Restart();
                    // setup parsers to read information
                    var networkParser = reader.GetRowParser<NetworkDelta>();
                    var zoneParser = reader.GetRowParser<ZoneDelta>();
                    var branchParser = reader.GetRowParser<BranchDelta>();
                    var inspectorParser = reader.GetRowParser<InspectorDelta>();
                    var agentParser = reader.GetRowParser<AgentDelta>();

                    while (reader.Read())
                    {
                        ReadElement(result, reader, networkParser, zoneParser, branchParser, inspectorParser, agentParser);
                    }

                    reader.Close();
                }

                stopwatch.Stop();
                log.Info($"read records took {stopwatch.ElapsedMilliseconds}ms to execute");

                parameters.Log(log, ParameterDirection.Output);

                return result;
            }
            catch (Exception ex)
            {
                log.Error(ex);
                throw;
            }
        }

        private void ReadElement(StructureDeltas result, IDataReader reader
            , Func<IDataReader, NetworkDelta> networkParser, Func<IDataReader, ZoneDelta> zoneParser, Func<IDataReader, BranchDelta> branchParser
            , Func<IDataReader, InspectorDelta> inspectorParser, Func<IDataReader, AgentDelta> agentParser)
        {
            switch (reader["TIPO_ESTRUTURA"].ToString())
            {
                case "REDE":
                    result.NetworkDeltas.Add(networkParser(reader));
                    break;

                case "ZONA":
                    result.ZoneDeltas.Add(zoneParser(reader));
                    break;

                case "BALCAO":
                    result.BranchDeltas.Add(branchParser(reader));
                    break;

                case "INSPECTOR":
                    result.InspectorDeltas.Add(inspectorParser(reader));
                    break;

                case "AGENTE":
                    result.AgentDeltas.Add(agentParser(reader));
                    break;

                default:
                    log.Error($"Unexpected record type: {reader["TIPO_ESTRUTURA"]}");
                    break;
            }
        }


        /// <summary>
        /// submit
        /// </summary>
        /// <typeparam name="T">output type</typeparam>
        /// <typeparam name="L">output list type</typeparam>
        /// <param name="parameters">database procedure parameters</param>
        /// <param name="oraclePackageWebservices">package name</param>
        /// <param name="oracleFunction">procedure name</param>
        /// <returns>New object of the T type.</returns>
        public T Submit<T, L>(OracleDynamicParameters parameters, string oraclePackageWebservices, string oracleFunction) where T : OutputDataAndErrors<L>, new()
        {
            return Submit<T, L>(parameters, oraclePackageWebservices, oracleFunction,
                (command, param, connection) => SqlMapper.Query<L>(connection, command, param: param, commandType: CommandType.StoredProcedure));
        }

        /// <summary>
        /// submit
        /// </summary>
        /// <typeparam name="T">output type</typeparam>
        /// <typeparam name="L">output list type</typeparam>
        /// <param name="parameters">database procedure parameters</param>
        /// <param name="oraclePackageWebservices">package name</param>
        /// <param name="oracleFunction">procedure name</param>
        /// <param name="databaseCall">function do get data from database into memory object</param>
        /// <returns>New object of the T type.</returns>
        public T Submit<T, L>(OracleDynamicParameters parameters, string oraclePackageWebservices, string oracleFunction,
            Func<string, OracleDynamicParameters, IDbConnection, IEnumerable<L>> databaseCall) where T : OutputDataAndErrors<L>, new()
        {
            try
            {
                T results = null;

                // validate parameters
                if (parameters == null || databaseCall == null)
                {
                    return null;
                }

                var stopwatch = new System.Diagnostics.Stopwatch();
                results = new T();
                var connection = _connection.Connection;
                var command = $"{oraclePackageWebservices}.{oracleFunction}";

                log.Info($"database call to {command}");
                parameters.Log(log, ParameterDirection.Input);

                stopwatch.Start();
                results.Data = databaseCall.Invoke(command, parameters, connection);
                stopwatch.Stop();

                log.Info($"database took {stopwatch.ElapsedMilliseconds}ms to execute");
                parameters.Log(log, ParameterDirection.Output);

                // check for errors
                var errorCode = parameters.GetString(nameof(ObjectErrors.p_erro));
                if (!string.IsNullOrEmpty(errorCode)
                    // success error code
                    && errorCode != "00")
                {
                    throw new ProcessErrorException(errorCode, parameters.GetString(nameof(ObjectErrors.p_dserro)));
                }

                return results;
            }
            catch (ProcessErrorException pe)
            {
                // errors from DB thru output parameters, log and throw
                log.Info(pe);
                throw;
            }
            catch (Exception ex)
            {
                log.Error(ex);
                throw;
            }
        }

        /// <summary>
        /// Method to read the classification deltas.
        /// </summary>
        /// <param name="headerParameters">header parameters</param>
        /// <param name="idAgent">identifier to search</param>
        /// <param name="deltasDate">search deltas from this date</param>
        /// <param name="searchType">search by this type of identifier</param>
        /// <returns></returns>
        public async Task<IEnumerable<AgentClassification>> ReadClassificationDeltasAsync(HeaderParameters headerParameters, string idAgent, DateTime deltasDate,
            ClassificationSearchType searchType)
        {
            const string command = "NAV.PKG_AGE_WEBSERVICES.Age_Classificacoes_Delta";
            log.Info($"database call to {command}");        

            return await ReadClassificationAsync(headerParameters, idAgent, deltasDate, searchType,
                (connection, parameters) => SqlMapper.Query<ClassificationOutput>(
                    connection, command, parameters, commandType: CommandType.StoredProcedure));
        }

        /// <summary>
        /// Method to read the classification deltas.
        /// </summary>
        /// <param name="headerParameters">header parameters</param>
        /// <param name="idAgent">identifier to search</param>
        /// <param name="searchType">search by this type of identifier</param>
        /// <returns></returns>
        public async Task<AgentClassification> ReadClassificationAsync(HeaderParameters headerParameters, string idAgent, ClassificationSearchType searchType)
        {
            const string command = "NAV.PKG_AGE_WEBSERVICES.Age_Classificacoes";
            log.Info($"database call to {command}");        

            var results = await ReadClassificationAsync(headerParameters, idAgent, null, searchType,
                (connection, parameters) => SqlMapper.Query<ClassificationOutput>(
                    connection, command, parameters, commandType: CommandType.StoredProcedure));

            return results.FirstOrDefault();
        }

        /// <summary>
        /// Method to read the classification deltas to be used in tests.
        /// </summary>
        /// <param name="headerParameters">header parameters</param>
        /// <param name="idAgent">identifier to search</param>
        /// <param name="deltasDate">when supplied the date parameter</param>
        /// <param name="databaseCall">database logic to retrive data</param>
        /// <param name="searchType">search by this type of identifier</param>
        /// <returns></returns>
        public async Task<IEnumerable<AgentClassification>> ReadClassificationAsync(HeaderParameters headerParameters, string idAgent, DateTime? deltasDate,
            ClassificationSearchType searchType, Func<IDbConnection, OracleDynamicParameters, IEnumerable<ClassificationOutput>> databaseCall)
        {
            const string ErrorCodeParameter = "p_erro";
            const string ErrorMessageParameter = "p_dserro";

            try
            {
                // validate parameters
                if (headerParameters == null)
                {
                    return new List<AgentClassification>();
                }

                var stopwatch = new System.Diagnostics.Stopwatch();
                var connection = _connection.Connection;
                var parameters = new OracleDynamicParameters();

                // create input parameters
                headerParameters.AddToParameters(parameters);
                parameters.Add("p_cdagente", OracleDbType.Varchar2, ParameterDirection.Input, idAgent);
                if (deltasDate.HasValue)
                {
                    parameters.Add("p_data", OracleDbType.Date, ParameterDirection.Input, deltasDate);
                }
                parameters.Add("p_tipo", OracleDbType.Varchar2, ParameterDirection.Input, searchType.GetStringValue());

                // create output parameters
                parameters.Add("p_dados", OracleDbType.RefCursor, direction: ParameterDirection.Output);
                parameters.Add(ErrorCodeParameter, OracleDbType.Varchar2, direction: ParameterDirection.Output, value: null, size: sizeBuffer);
                parameters.Add(ErrorMessageParameter, OracleDbType.Varchar2, direction: ParameterDirection.Output, value: null, size: sizeBuffer);

                parameters.Log(log, ParameterDirection.Input);

                stopwatch.Start();
                var dataResults = await Task.Run(() => databaseCall.Invoke(connection, parameters));
                stopwatch.Stop();

                log.Info($"database took {stopwatch.ElapsedMilliseconds}ms to execute");
                parameters.Log(log, ParameterDirection.Output);
                log.Debug($"database results {JsonConvert.SerializeObject(dataResults)}");

                // check for errors
                var errorCode = parameters.GetString(ErrorCodeParameter);
                if (!string.IsNullOrEmpty(errorCode)
                    // success error code
                    && errorCode != "00")
                {
                    throw new ProcessErrorException(errorCode, parameters.GetString(ErrorMessageParameter));
                }

                stopwatch.Restart();
                var result = GenerateClassificationOutput(dataResults);
                stopwatch.Stop();
                log.Info($"build response took {stopwatch.ElapsedMilliseconds}ms to execute");

                return result;
            }
            catch (ProcessErrorException pe)
            {
                // errors from DB thru output parameters, log and throw
                log.Info(pe);
                throw;
            }
            catch (Exception ex)
            {
                log.Error(ex);
                throw;
            }            
        }

        private static List<AgentClassification> GenerateClassificationOutput(IEnumerable<ClassificationOutput> dataResults)
        {
            AgentClassification currentAgent = null;
            var results = new List<AgentClassification>();

            foreach (var record in dataResults.OrderBy(r => r.IdAgent).ThenBy(r => r.Order))
            {
                if (currentAgent == null || currentAgent?.AgentCode != record.IdAgent)
                {
                    currentAgent = new AgentClassification
                    {
                        AgentCode = record.IdAgent,
                        Classifications = new List<Classification>()
                    };
                    results.Add(currentAgent);
                }

                if (record.Order == 1)
                {
                    // agent type
                    currentAgent.AgentType = new AgentClassificationType(record);
                }
                else
                {
                    // classification
                    currentAgent.Classifications.Add(new Classification(record));
                }
            }

            return results;
        }
    }
}

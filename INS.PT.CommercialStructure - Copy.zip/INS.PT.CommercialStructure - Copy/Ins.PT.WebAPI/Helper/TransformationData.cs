﻿using INS.PT.WebAPI.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace INS.PT.WebAPI.Helper
{
    public static class TransformationData
    {
        /// <summary>
        /// Makes the hierarque structure.
        /// </summary>
        /// <param name="results">The input1.</param>
        /// <param name="packageDataOutput">The result data input.</param>
        /// <returns></returns>
        public static void MakeHierarchyStructure(ICollection<Company> results, TreeOutputData packageDataOutput)
        {
            if (results == null)
            {
                return;
            }

            // find company
            var company = results.FirstOrDefault(w => w.CompanyName == packageDataOutput.Companhia);

            if (company == null)
            {
                // create new company from data
                company = new Company
                {
                    CompanyName = packageDataOutput.Companhia
                };
                results.Add(company);
            }

            // add network to company
            var network = AddNetWork(company, packageDataOutput);

            // add zone to network
            var zone = AddZone(network, packageDataOutput);

            // add branch to zone
            var branch = AddBranch(zone, packageDataOutput);

            // add inspector to branch
            var inspector = AddInspector(branch, packageDataOutput);

            // adds agents
            AddAgents(inspector, packageDataOutput);
        }

        /// <summary>
        /// Adds the net work.
        /// </summary>
        /// <param name="company">The company.</param>
        /// <param name="packageDataOutput">The result data input.</param>
        /// <returns></returns>
        private static Network AddNetWork(Company company, TreeOutputData packageDataOutput)
        {
            // no company no network to create
            if (company == null)
            {
                return null;
            }

            // find if network already exists
            var network = company.Networks?.FirstOrDefault(w => w.Code == packageDataOutput.Nivel1);

            // confirm if network exists and record is good to create network
            if (network == null && !string.IsNullOrEmpty(packageDataOutput.Nivel1))
            {
                // inicialize collection if needed
                company.Networks ??= new List<Network>();

                network = new Network
                {
                    Code = packageDataOutput.Nivel1,
                    Name = packageDataOutput.Dsnombre,
                    Address = packageDataOutput.Dsdomicilio,
                    PostalCode = packageDataOutput.Cdpostal,
                    ResponsibleId = packageDataOutput.ID_IDENT_REPRESENTANTE,
                    Status = packageDataOutput.Estado,
                    StatusInitialDate = string.IsNullOrEmpty(packageDataOutput.DATA_ACTIVO) ? (DateTime?)null : DateTime.Parse(packageDataOutput.DATA_ACTIVO, CultureInfo.CurrentCulture),
                    StatusEndDate = string.IsNullOrEmpty(packageDataOutput.DATA_INACTIVO) ? (DateTime?)null : DateTime.Parse(packageDataOutput.DATA_INACTIVO, CultureInfo.CurrentCulture),
                    IsDummy = packageDataOutput.IS_DUMMY
                };

                company.Networks.Add(network);
            }
            return network;
        }

        /// <summary>
        /// Adds the zone.
        /// </summary>
        /// <param name="network">The network.</param>
        /// <param name="packageDataOutput">The result data input.</param>
        /// <returns></returns>
        private static Zone AddZone(Network network, TreeOutputData packageDataOutput)
        {
            // no network no zone to create
            if (network == null)
            {
                return null;
            }

            // find if zone already exists
            var zone = network.Zones?.FirstOrDefault(w => w.Code == packageDataOutput.Nivel2);

            // confirm if zone exists and record is good to create zone
            if (zone == null && !string.IsNullOrEmpty(packageDataOutput.Nivel2))
            {
                // inicialize collection if needed
                network.Zones ??= new List<Zone>();

                zone = new Zone
                {
                    Code = packageDataOutput.Nivel2,
                    Name = packageDataOutput.Dsnombre,
                    Address = packageDataOutput.Dsdomicilio,
                    PostalCode = packageDataOutput.Cdpostal,
                    ResponsibleId = packageDataOutput.ID_IDENT_REPRESENTANTE,
                    Status = packageDataOutput.Estado,
                    StatusInitialDate = string.IsNullOrEmpty(packageDataOutput.DATA_ACTIVO) ? (DateTime?)null : DateTime.Parse(packageDataOutput.DATA_ACTIVO, CultureInfo.CurrentCulture),
                    StatusEndDate = string.IsNullOrEmpty(packageDataOutput.DATA_INACTIVO) ? (DateTime?)null : DateTime.Parse(packageDataOutput.DATA_INACTIVO, CultureInfo.CurrentCulture),
                    IsDummy = packageDataOutput.IS_DUMMY
                };

                network.Zones.Add(zone);
            }
            return zone;
        }

        /// <summary>
        /// Adds the branch.
        /// </summary>
        /// <param name="zone">The zone.</param>
        /// <param name="packageDataOutput">The result data input.</param>
        /// <returns></returns>
        private static Branch AddBranch(Zone zone, TreeOutputData packageDataOutput)
        {
            // no zone no branch to create
            if (zone == null)
            {
                return null;
            }

            // find if branch already exists
            var branch = zone.Branches?.FirstOrDefault(w => w.Code == packageDataOutput.Nivel3);

            // confirm if branch exists and record is good to create branch
            if (branch == null && !string.IsNullOrEmpty(packageDataOutput.Nivel3))
            {
                // inicialize collection if needed
                zone.Branches ??= new List<Branch>();

                branch = new Branch
                {
                    Code = packageDataOutput.Nivel3,
                    Name = packageDataOutput.Dsnombre,
                    Address = packageDataOutput.Dsdomicilio,
                    PostalCode = packageDataOutput.Cdpostal,
                    WorkArea = packageDataOutput.ZONA_ACTUACAO,
                    Status = packageDataOutput.Estado,
                    StatusInitialDate = string.IsNullOrEmpty(packageDataOutput.DATA_ACTIVO) ? (DateTime?)null : DateTime.Parse(packageDataOutput.DATA_ACTIVO, CultureInfo.CurrentCulture),
                    StatusEndDate = string.IsNullOrEmpty(packageDataOutput.DATA_INACTIVO) ? (DateTime?)null : DateTime.Parse(packageDataOutput.DATA_INACTIVO, CultureInfo.CurrentCulture),
                    IsDummy = packageDataOutput.IS_DUMMY
                };

                zone.Branches.Add(branch);
            }
            return branch;
        }

        /// <summary>
        /// Adds the inspector.
        /// </summary>
        /// <param name="branch">The branch.</param>
        /// <param name="packageDataOutput">The result data input.</param>
        /// <returns></returns>
        private static Inspector AddInspector(Branch branch, TreeOutputData packageDataOutput)
        {
            // no branch no inspector to create
            if (branch == null)
            {
                return null;
            }
 
            // find if inspector already exists
            var inspector = branch.Inspectors?.FirstOrDefault(w => w.Code == packageDataOutput.Nivel4);

            // confirm if inspector exists and record is good to create inspector
            if (inspector == null && !string.IsNullOrEmpty(packageDataOutput.Nivel4))
            {
                // inicialize collection if needed
                branch.Inspectors ??= new List<Inspector>();

                inspector = new Inspector
                {
                    Id = packageDataOutput.ID_IDENTIDADE,
                    Code = packageDataOutput.Nivel4,
                    InspectorWorkArea = packageDataOutput.AREA_INSPECCAO,
                    Status = packageDataOutput.Estado,
                    StatusInitialDate = string.IsNullOrEmpty(packageDataOutput.DATA_ACTIVO) ? (DateTime?)null : DateTime.Parse(packageDataOutput.DATA_ACTIVO, CultureInfo.CurrentCulture),
                    StatusEndDate = string.IsNullOrEmpty(packageDataOutput.DATA_INACTIVO) ? (DateTime?)null : DateTime.Parse(packageDataOutput.DATA_INACTIVO, CultureInfo.CurrentCulture),
                    WorkArea = packageDataOutput.ZONA_ACTUACAO,
                    InspectionSpecialAc = packageDataOutput.INSP_AC_ESPECIAL,
                    IdAddress = packageDataOutput.Nmdomicilio,
                    Name = packageDataOutput.Dsnombre,
                    IsDummy = packageDataOutput.IS_DUMMY,
                    IdEmail=packageDataOutput.Id_Email,
                    Email=packageDataOutput.Email
                    //IdBankAccount=packageDataOutput.id_nib
                    //IdPhone=packageDataOutput.id_telefone
                };

                branch.Inspectors.Add(inspector);
            }
            return inspector;
        }

        /// <summary>
        /// Adds the agent to the inspector.
        /// </summary>
        /// <param name="inspector">The inspector.</param>
        /// <param name="packageDataOutput">The result data input.</param>
        /// <returns></returns>
        private static void AddAgents(Inspector inspector, TreeOutputData packageDataOutput)
        {
            // no inspector no agent to create
            if (inspector == null)
            {
                return;
            }

            // find if agent already exists
            var agent = inspector.Agents?.FirstOrDefault(w => w.Code == packageDataOutput.Cdagente);

            // confirm if agent exists and record is good to create agent
            if (agent == null && !string.IsNullOrEmpty(packageDataOutput.Cdagente) && !string.IsNullOrEmpty(packageDataOutput.Nivel4))
            {
                // inicialize collection if needed
                inspector.Agents ??= new List<Agent>();

                inspector.Agents.Add(new Agent
                {
                    Code = packageDataOutput.Cdagente,
                    Id = packageDataOutput.ID_IDENTIDADE,
                    AgentWorkArea = packageDataOutput.AREA_INSPECCAO,
                    AsfNumber = packageDataOutput.NUMERO_ISP,
                    AsfProductCode = packageDataOutput.COD_PRODUTOS_ISP,
                    AsfProductCodeDescription = packageDataOutput.PRODUTOS_ISP,
                    Status = packageDataOutput.Estado,
                    StatusInitialDate = string.IsNullOrEmpty(packageDataOutput.DATA_ACTIVO) ? (DateTime?)null : DateTime.Parse(packageDataOutput.DATA_ACTIVO, CultureInfo.CurrentCulture),
                    StatusEndDate = string.IsNullOrEmpty(packageDataOutput.DATA_INACTIVO) ? (DateTime?)null : DateTime.Parse(packageDataOutput.DATA_INACTIVO, CultureInfo.CurrentCulture),
                    WorkArea = packageDataOutput.ZONA_ACTUACAO,
                    IdAddress = packageDataOutput.Nmdomicilio,
                    Name = packageDataOutput.Dsnombre,
                    IsDummy = packageDataOutput.IS_DUMMY,
                    IdEmail = packageDataOutput.Id_Email,
                    Email = packageDataOutput.Email,
                    IdBusinessUnit = packageDataOutput.BU
                });
            }
        }
    }
}

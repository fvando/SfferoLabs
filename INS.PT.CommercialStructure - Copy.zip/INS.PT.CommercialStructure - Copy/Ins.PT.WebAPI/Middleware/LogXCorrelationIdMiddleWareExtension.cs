﻿// Copyright Ageas 2019 © - Integration Team

using Microsoft.AspNetCore.Builder;

/// <summary>
/// Ins.PT.WebAPI.Middleware
/// </summary>
namespace INS.PT.WebAPI.Middleware
{
    /// <summary>
    /// LogXCorrelationIdMiddleWareExtension
    /// </summary>
    public static class LogXCorrelationIdMiddleWareExtension
    {
        /// <summary>
        /// UseLogXCorrelationId
        /// </summary>
        /// <param name="app"></param>
        /// <returns></returns>
        public static IApplicationBuilder UseLogXCorrelationId(this IApplicationBuilder app)
        {
            app.UseMiddleware<LogXCorrelationIdMiddleWare>();
            return app;
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc.ApplicationModels;
using System.Linq;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// Class to group endpoints for each API version.
    /// </summary>
    public class ApiExplorerGroupPerVersionConvention : IControllerModelConvention
    {
        /// <summary>
        /// Logic to divide endpoints.
        /// <seealso cref="IControllerModelConvention"/>
        /// </summary>
        /// <param name="controller">The Microsoft.AspNetCore.Mvc.ApplicationModels.ControllerModel.</param>
        public void Apply(ControllerModel controller)
        {
            if (controller == null)
            {
                return;
            }

            var controllerNamespace = controller.ControllerType.Namespace;
            var apiVersion = controllerNamespace.Split('.').Last().ToLowerInvariant();

            // default version for v1
            if (!apiVersion.StartsWith('v'))
            {
                apiVersion = "v1";
            }

            controller.ApiExplorer.GroupName = apiVersion;
        }
    }
}

﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models
{
    public class NetworkDelta : Network, IMapped
    {
        /// <summary>
        /// Method that is going to prepare the object mappings.
        /// </summary>
        public override void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(NetworkDelta));
        }

        /// <summary>
        /// Hide inherit child elements that should not be exposed.
        /// </summary>
        [JsonIgnore]
        public override ICollection<Zone> Zones { get; set; }

        /// <summary>
        /// Parent element.
        /// </summary>
        [Column("COMPANHIA")]
        public string Company { get; set; }
    }
}

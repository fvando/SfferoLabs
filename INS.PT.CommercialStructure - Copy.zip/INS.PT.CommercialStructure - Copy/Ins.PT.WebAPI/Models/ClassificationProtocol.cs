﻿using INS.PT.WebAPI.Models.Database;
using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// ClassificationProtocol : IMapped
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.IMapped" />
    public class ClassificationProtocol : IMapped
    {
        /// <summary>
        /// Method that is going to prepare the object mappings.
        /// </summary>
        public void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(ClassificationProtocol));
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ClassificationProtocol"/> class.
        /// </summary>
        public ClassificationProtocol() { }

        /// <summary>
        /// Initializes a new instance of the <see cref="ClassificationProtocol"/> class.
        /// </summary>
        /// <param name="record">The record.</param>
        internal ClassificationProtocol(ClassificationProtocolOutput record)
        {
            Code = record.Code;
            Description = record.Description;
        }

        /// <summary>
        /// Code
        /// Classification code / agent characteristic
        /// </summary>
        [JsonProperty("Code")]
        [Column("cdclasificacion")]
        public virtual string Code { get; set; }

        /// <summary>
        /// ClasificacionDescription
        /// Agent Rating / Feature Description
        /// </summary>
        [JsonProperty("Description")]
        [Column("dsclasificacion")]
        public virtual string Description { get; set; }

    }
}

﻿using INS.PT.WebAPI.Models.Database;
using Newtonsoft.Json;
using System;

namespace INS.PT.WebAPI.Models
{
    public class AgentClassificationType
    {
        public AgentClassificationType() { }

        internal AgentClassificationType(ClassificationOutput record)
        {
            AgentTypeCode = record.Code;
            AgentTypeDescription = record.Description;
            StartDate = record.StartDate;
            EndDate = record.EndDate;
        }

        /// <summary>
        /// Code.
        /// </summary>
        [JsonProperty("AgentTypeCode")]
        public string AgentTypeCode { get; set; }

        /// <summary>
        /// Description.
        /// </summary>
        [JsonProperty("AgentTypeDescription")]
        public string AgentTypeDescription { get; set; }

        /// <summary>
        /// Date of the start.
        /// </summary>
        [JsonProperty("StartDate")]
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Date of end.
        /// </summary>
        [JsonProperty("EndDate")]
        public DateTime? EndDate { get; set; }
    }
}

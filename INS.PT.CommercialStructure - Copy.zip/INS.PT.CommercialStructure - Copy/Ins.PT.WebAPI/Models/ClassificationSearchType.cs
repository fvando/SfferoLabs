﻿using INS.PT.WebAPI.Helper;

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// Classification search by type.
    /// </summary>
    public enum ClassificationSearchType
    {
        // Agente
        [StringValue("A")]
        Agent,

        // Inspetor
        [StringValue("I")]
        Inspector
    }
}

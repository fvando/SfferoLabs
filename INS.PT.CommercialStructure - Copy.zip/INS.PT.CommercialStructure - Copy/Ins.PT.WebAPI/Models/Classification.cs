﻿using INS.PT.WebAPI.Models.Database;
using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models
{
    public class Classification : IMapped
    {
        public void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(Classification));
        }

        public Classification() { }

        internal Classification(ClassificationOutput record)
        {
            Code = record.Code;
            Description = record.Description;
            Tipology = record.Tipology;
            StartDate = record.StartDate;
            EndDate = record.EndDate;
            Rule = record.Rule;
        }

        /// <summary>
        /// Code
        /// Classification code / agent characteristic
        /// </summary>
        [JsonProperty("Code")]
        [Column("cdclasificacion")]
        public virtual string Code { get; set; }

        /// <summary>
        /// ClasificacionDescription
        /// Agent Rating / Feature Description
        /// </summary>
        [JsonProperty("Description")]
        [Column("dsclasificacion")]
        public virtual string Description { get; set; }

        /// <summary>
        /// Classification tipology.
        /// </summary>
        /// <example>CLASS</example>
        [JsonProperty("Tipology")]
        public string Tipology { get; set; }

        /// <summary>
        /// Date of the delta start.
        /// </summary>
        [JsonProperty("StartDate")]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// If filled date of end of classification.
        /// </summary>
        [JsonProperty("EndDate")]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Rule to be applied to the classification.
        /// </summary>
        [JsonProperty("Rule")]
        public string Rule { get; set; }
    }
}

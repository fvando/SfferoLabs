﻿// Copyright Ageas 2019 © - Integration Team
namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// DeskInspector
    /// </summary>
    public class BranchInspectors : OutputDataAndErrors<Inspector>
    { }
}

﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// Agent data found by search controller.
    /// </summary>
    public class AgentMatch : Agent, IMapped
    {
        public override void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(AgentMatch));
        }


        /// <summary>
        /// Start date.
        /// </summary>
        /// <example></example>
        [Column("fealta")]
        public DateTime? StartDate { get; set; }
    }
}

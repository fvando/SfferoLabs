﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;
using System.Xml.Serialization;

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// AgentCS
    /// </summary>
    public class Agent : BaseOutput, IMapped
    {
        public virtual void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(Agent));
        }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        [Column("ID_IDENTIDADE")]
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets the work area.
        /// </summary>
        /// <value>
        /// The work area.
        /// </value>
        [Column("ZONA_ACTUACAO")]
        public string WorkArea { get; set; }

        /// <summary>
        /// Gets or sets the agent work area.
        /// </summary>
        /// <value>
        /// The agent work area.
        /// </value>
        [Column("AREA_INSPECCAO")]
        public string AgentWorkArea { get; set; }

        /// <summary>
        /// Gets or sets the asf number.
        /// </summary>
        /// <value>
        /// The asf number.
        /// </value>
        [Column("NUMERO_ISP")]
        public string AsfNumber { get; set; }

        /// <summary>
        /// Gets or sets the asf product code.
        /// </summary>
        /// <value>
        /// The asf product code.
        /// </value>
        [Column("COD_PRODUTOS_ISP")]
        public string AsfProductCode { get; set; }

        /// <summary>
        /// Gets or sets the asf product code description.
        /// </summary>
        /// <value>
        /// The asf product code description.
        /// </value>
        [Column("PRODUTOS_ISP")]
        public string AsfProductCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets the identifier address.
        /// </summary>
        /// <value>
        /// The identifier address.
        /// </value>
        [Column("NMDOMICILIO")]
        public string IdAddress { get; set; }

        /// <summary>
        /// Id of the bank account of the entity.
        /// </summary>
        /// <example>1</example>
        [Column("id_nib")]
        public int? IdBankAccount { get; set; }

        /// <summary>
        /// Id of the phone of the entity.
        /// </summary>
        /// <example>10592272966748706</example>
        [Column("id_telefone")]
        public string IdPhone { get; set; }

        /// <summary>
        /// Id of the email of the entity.
        /// </summary>
        /// <example>1</example>
        [Column("id_email")]
        public int? IdEmail { get; set; }

        /// <summary>
        /// Email of the entity.
        /// </summary>
        /// <example>1</example>
        [Column("email")]
        public string Email { get; set; }

        /// <summary>
        /// Business unit id.
        /// </summary>
        [Column("bu")]
        public string IdBusinessUnit { get; set; }

        /// <summary>
        /// Aggregator group.
        /// </summary>
        /// <example>G027</example>
        [Column("grupo_agregador")]
        public string AggregatorGroup { get; set; }

        /// <summary>
        /// Is the master agent in aggregator group.
        /// </summary>
        public bool? IsMaster => string.IsNullOrEmpty(MasterStatus) ? (bool?)null 
            : string.Compare(MasterStatus, "MASTER", System.StringComparison.InvariantCultureIgnoreCase) == 0;

        /// <summary>
        /// Property to read value from database, should not be outputed.
        /// </summary>
        [Column("master_slave")]
        [JsonIgnore]
        [XmlIgnore]
        public string MasterStatus { get; set; }
    }
}

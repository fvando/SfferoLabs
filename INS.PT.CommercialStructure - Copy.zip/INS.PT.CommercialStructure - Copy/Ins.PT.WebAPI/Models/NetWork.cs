﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// NetWorkCS
    /// </summary>
    public class Network : BaseOutput, IMapped
    {
        public virtual void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(Network));
        }


        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <example>code123</example>>
        [Column("NIVEL1")]
        public override string Code { get => base.Code; set => base.Code = value; }

        /// <summary>
        /// Gets or sets the address.
        /// </summary>
        /// <value>
        /// The address.
        /// </value>
        [Column("DSDOMICILIO")]
        public string Address { get; set; }

        /// <summary>
        /// Gets or sets the postal code1.
        /// </summary>
        /// <value>
        /// The postal code1.
        /// </value>
        [Column("CDPOSTAL")]
        public string PostalCode { get; set; }

        /// <summary>
        /// Gets or sets the responsible identifier.
        /// </summary>
        /// <value>
        /// The responsible identifier.
        /// </value>
        [Column("ID_IDENT_REPRESENTANTE")]
        public string ResponsibleId { get; set; }

        /// <summary>
        /// Gets or sets the zones.
        /// </summary>
        /// <value>
        /// The zones.
        /// </value>
        public virtual ICollection<Zone> Zones { get; set; }
    }
}

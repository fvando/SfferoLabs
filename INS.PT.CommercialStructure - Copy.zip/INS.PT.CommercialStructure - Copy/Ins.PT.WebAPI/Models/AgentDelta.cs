﻿using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models
{
    public class AgentDelta : Agent, IMapped
    {
        /// <summary>
        /// Method that is going to prepare the object mappings.
        /// </summary>
        public override void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(AgentDelta));
        }


        /// <summary>
        /// Company parent element.
        /// </summary>
        [Column("COMPANHIA")]
        public string Company { get; set; }

        /// <summary>
        /// Parent network identifier.
        /// </summary>
        [Column("NIVEL1")]
        public string IdNetwork { get; set; }

        /// <summary>
        /// Parent inspector identifier.
        /// </summary>
        [Column("NIVEL4")]
        public string IdInspector { get; set; }

        /// <summary>
        /// Parent branch identifier.
        /// </summary>
        [Column("NIVEL3")]
        public string IdBranch { get; set; }

        /// <summary>
        /// Parent zone identifier.
        /// </summary>
        [Column("NIVEL2")]
        public string IdZone { get; set; }
    }
}

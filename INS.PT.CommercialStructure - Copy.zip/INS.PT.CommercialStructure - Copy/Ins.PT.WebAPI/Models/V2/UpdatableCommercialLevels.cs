﻿using INS.PT.WebAPI.Helper;

namespace INS.PT.WebAPI.Models.V2
{
    /// <summary>
    /// Commercial levels that can be updated.
    /// </summary>
    public enum UpdatableCommercialLevels
    {
        // Direcção
        [StringValue("D")]
        Management = CommercialStructureLevels.Management,

        // Canal
        [StringValue("N")]
        Channel = CommercialStructureLevels.Channel,

        // Marca
        [StringValue("M")]
        Brand = CommercialStructureLevels.Branch,

        // Grupo
        [StringValue("G")]
        Group = CommercialStructureLevels.Group
    }
}

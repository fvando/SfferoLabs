﻿using System;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.V2
{
    /// <summary>
    /// Object to edit/insert elements in commercial structure.
    /// </summary>
    public class LevelElement
    {
        const int MaxLength = 200;

        /// <summary>
        /// Level type to insert/edit.
        /// </summary>
        public UpdatableCommercialLevels LevelType { get; set; }

        /// <summary>
        /// Flag to define if it's a new element.
        /// </summary>
        public bool IsNewElement { get; set; }

        /// <summary>
        /// Identifier code of element.
        /// </summary>
        [MaxLength(MaxLength)]
        public string Code { get; set; }

        /// <summary>
        /// Parent identifier code.
        /// </summary>
        [MaxLength(MaxLength)]
        public string ParentCode { get; set; }

        /// <summary>
        /// Name/description od element.
        /// </summary>
        [MaxLength(MaxLength)]
        public string Description { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        public DateTime? EndDate { get; set; }
    }
}

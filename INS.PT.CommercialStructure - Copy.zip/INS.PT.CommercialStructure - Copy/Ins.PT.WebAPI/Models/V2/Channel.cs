﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models.V2
{
    public class Channel : BaseOutput, IMapped
    {
        /// <summary>
        /// IMapped interface method.
        /// </summary>
        public virtual void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(Channel));
        }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <example>CAAG1</example>>
        [Column("NIVEL3")]
        public override string Code { get => base.Code; set => base.Code = value; }

        /// <summary>
        /// Gets or sets the managements.
        /// </summary>
        public virtual ICollection<Managements> Managements { get; set; }
    }
}

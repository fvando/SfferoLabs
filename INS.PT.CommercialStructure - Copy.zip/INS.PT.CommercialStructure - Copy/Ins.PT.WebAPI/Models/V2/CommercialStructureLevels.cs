﻿using INS.PT.WebAPI.Helper;

namespace INS.PT.WebAPI.Models.V2
{
    /// <summary>
    /// Types of structures in the commercial structure V2.
    /// </summary>
    public enum CommercialStructureLevels
    {
        // Agente
        [StringValue("A")]
        Agent,

        // Inspetor
        [StringValue("I")]
        Inspector,

        // Balcão
        [StringValue("B")]
        Branch,

        // Zona
        [StringValue("Z")]
        Zone,

        // Rede
        [StringValue("R")]
        Network,

        // Direcção
        [StringValue("D")]
        Management,

        // Canal
        [StringValue("N")]
        Channel,

        // Marca
        [StringValue("M")]
        Brand,

        // Grupo
        [StringValue("G")]
        Group
    }
}

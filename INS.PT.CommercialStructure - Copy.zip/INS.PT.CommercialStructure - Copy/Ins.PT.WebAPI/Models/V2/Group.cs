﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models.V2
{
    /// <summary>
    /// Represents one Group in commercial structure.
    /// </summary>
    public class Group : BaseOutput, IMapped
    {
        /// <summary>
        /// IMapped interface method.
        /// </summary>
        public virtual void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(Group));
        }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <example>ONE</example>>
        [Column("NIVEL1")]
        public override string Code { get => base.Code; set => base.Code = value; }

        /// <summary>
        /// Gets or sets the brands.
        /// </summary>
        public virtual ICollection<Brand> Brands { get; set; }
    }
}

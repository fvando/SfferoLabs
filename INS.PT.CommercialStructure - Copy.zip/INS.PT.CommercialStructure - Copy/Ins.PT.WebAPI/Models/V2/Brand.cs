﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models.V2
{
    /// <summary>
    /// Represents one brand in commecial structure.
    /// </summary>
    public class Brand : BaseOutput, IMapped
    {
        /// <summary>
        /// IMapped interface method.
        /// </summary>
        public virtual void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(Brand));
        }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <example>MAAG</example>>
        [Column("NIVEL2")]
        public override string Code { get => base.Code; set => base.Code = value; }

        /// <summary>
        /// Gets or sets the channels.
        /// </summary>
        public virtual ICollection<Channel> Channels { get; set; }
    }
}

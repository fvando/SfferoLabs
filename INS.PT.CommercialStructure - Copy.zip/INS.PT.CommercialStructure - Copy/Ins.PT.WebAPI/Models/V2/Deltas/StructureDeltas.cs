﻿using System.Collections.Generic;
using System.Linq;

namespace INS.PT.WebAPI.Models.V2.Deltas
{
    public class StructureDeltas
    {
        /// <summary>
        /// Groups that had a change.
        /// </summary>
        public ICollection<GroupDelta> GroupDeltas { get; set; } = new List<GroupDelta>();

        /// <summary>
        /// Brands that had a change.
        /// </summary>
        public ICollection<BrandDelta> BrandDeltas { get; set; } = new List<BrandDelta>();

        /// <summary>
        /// Channels that had a change.
        /// </summary>
        public ICollection<ChannelDelta> ChannelDeltas { get; set; } = new List<ChannelDelta>();

        /// <summary>
        /// Managements that had a change.
        /// </summary>
        public ICollection<ManagementDelta> ManagementDeltas { get; set; } = new List<ManagementDelta>();

        /// <summary>
        /// Networks that had a change.
        /// </summary>
        public ICollection<NetworkDelta> NetworkDeltas { get; set; } = new List<NetworkDelta>();

        /// <summary>
        /// Zones that had a change.
        /// </summary>
        public ICollection<ZoneDelta> ZoneDeltas { get; set; } = new List<ZoneDelta>();

        /// <summary>
        /// Branches that had a change.
        /// </summary>
        public ICollection<BranchDelta> BranchDeltas { get; set; } = new List<BranchDelta>();

        /// <summary>
        /// Inspectors that had a change.
        /// </summary>
        public ICollection<InspectorDelta> InspectorDeltas { get; set; } = new List<InspectorDelta>();

        /// <summary>
        /// Agents that had a change.
        /// </summary>
        public ICollection<AgentDelta> AgentDeltas { get; set; } = new List<AgentDelta>();

        internal bool AnyData
        {
            get
            {
                var result = NetworkDeltas.Any() || ZoneDeltas.Any();

                result = result || BranchDeltas.Any() || InspectorDeltas.Any();
                result = result || GroupDeltas.Any() || BrandDeltas.Any();
                result = result || ChannelDeltas.Any() || ManagementDeltas.Any();

                return result || AgentDeltas.Any();
            }
        }
    }
}

﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models.V2.Deltas
{
    public class InspectorDelta : Inspector, IMapped
    {
        /// <summary>
        /// Method that is going to prepare the object mappings.
        /// </summary>
        public override void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(InspectorDelta));
        }

        /// <summary>
        /// Hide inherit child elements that should not be exposed.
        /// </summary>
        [JsonIgnore]
        public override ICollection<Agent> Agents { get; set; }


        /// <summary>
        /// Parent group identifier.
        /// </summary>
        [Column("NIVEL1")]
        public string IdGroup { get; set; }

        /// <summary>
        /// Parent brand identifier.
        /// </summary>
        [Column("NIVEL2")]
        public string IdBrand { get; set; }

        /// <summary>
        /// Parent channel identifier.
        /// </summary>
        [Column("NIVEL3")]
        public string IdChannel { get; set; }

        /// <summary>
        /// Parent management identifier.
        /// </summary>
        [Column("NIVEL4")]
        public string IdManagement { get; set; }

        /// <summary>
        /// Parent network identifier.
        /// </summary>
        [Column("NIVEL5")]
        public string IdNetwork { get; set; }

        /// <summary>
        /// Parent zone identifier.
        /// </summary>
        [Column("NIVEL6")]
        public string IdZone { get; set; }

        /// <summary>
        /// Parent branch identifier.
        /// </summary>
        [Column("NIVEL7")]
        public string IdBranch { get; set; }
    }
}

﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.V2.Deltas
{
    public class GroupDelta : Group, IMapped
    {
        /// <summary>
        /// Method that is going to prepare the object mappings.
        /// </summary>
        public override void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(GroupDelta));
        }

        /// <summary>
        /// Hide inherit child elements that should not be exposed.
        /// </summary>
        [JsonIgnore]
        public override ICollection<Brand> Brands { get; set; }
    }
}

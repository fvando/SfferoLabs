﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models.V2.Deltas
{
    public class NetworkDelta : Network, IMapped
    {
        /// <summary>
        /// Method that is going to prepare the object mappings.
        /// </summary>
        public override void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(NetworkDelta));
        }

        /// <summary>
        /// Hide inherit child elements that should not be exposed.
        /// </summary>
        [JsonIgnore]
        public override ICollection<Zone> Zones { get; set; }


        /// <summary>
        /// Parent group identifier.
        /// </summary>
        [Column("NIVEL1")]
        public string IdGroup { get; set; }

        /// <summary>
        /// Parent brand identifier.
        /// </summary>
        [Column("NIVEL2")]
        public string IdBrand { get; set; }

        /// <summary>
        /// Parent channel identifier.
        /// </summary>
        [Column("NIVEL3")]
        public string IdChannel { get; set; }

        /// <summary>
        /// Parent management identifier.
        /// </summary>
        [Column("NIVEL4")]
        public string IdManagement { get; set; }
    }
}

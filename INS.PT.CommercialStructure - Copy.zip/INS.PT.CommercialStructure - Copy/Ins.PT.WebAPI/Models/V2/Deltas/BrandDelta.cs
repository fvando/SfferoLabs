﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.V2.Deltas
{
    public class BrandDelta : Brand, IMapped
    {
        /// <summary>
        /// Method that is going to prepare the object mappings.
        /// </summary>
        public override void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(BrandDelta));
        }

        /// <summary>
        /// Hide inherit child elements that should not be exposed.
        /// </summary>
        [JsonIgnore]
        public override ICollection<Channel> Channels { get; set; }


        /// <summary>
        /// Parent group identifier.
        /// </summary>
        [Column("NIVEL1")]
        public string IdGroup { get; set; }
    }
}

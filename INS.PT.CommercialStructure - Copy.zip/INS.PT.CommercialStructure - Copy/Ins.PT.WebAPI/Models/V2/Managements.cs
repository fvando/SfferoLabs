﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models.V2
{
    /// <summary>
    /// Management level of commercial structure.
    /// </summary>
    public class Managements : BaseOutput, IMapped
    {
        /// <summary>
        /// IMapped interface method.
        /// </summary>
        public virtual void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(Managements));
        }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <example>DIAG2</example>>
        [Column("NIVEL4")]
        public override string Code { get => base.Code; set => base.Code = value; }

        /// <summary>
        /// Gets or sets the networks.
        /// </summary>
        public virtual ICollection<Network> Networks { get; set; }
    }
}

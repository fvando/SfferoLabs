﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models
{
    public class InspectorDelta : Inspector, IMapped
    {
        /// <summary>
        /// Method that is going to prepare the object mappings.
        /// </summary>
        public override void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(InspectorDelta));
        }


        /// <summary>
        /// Parent zone identifier.
        /// </summary>
        [Column("NIVEL2")]
        public string IdZone { get; set; }

        /// <summary>
        /// Company parent element.
        /// </summary>
        [Column("COMPANHIA")]
        public string Company { get; set; }

        /// <summary>
        /// Parent branch identifier.
        /// </summary>
        [Column("NIVEL3")]
        public string IdBranch { get; set; }

        /// <summary>
        /// Parent network identifier.
        /// </summary>
        [Column("NIVEL1")]
        public string IdNetwork { get; set; }


        /// <summary>
        /// Hide inherit child elements that should not be exposed.
        /// </summary>
        [JsonIgnore]
        public override ICollection<Agent> Agents { get; set; }
    }
}

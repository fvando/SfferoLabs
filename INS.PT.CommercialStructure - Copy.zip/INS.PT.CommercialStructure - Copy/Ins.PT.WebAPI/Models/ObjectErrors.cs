﻿using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class ObjectErrors
    {
        /// <summary>
        /// </summary>
        [JsonProperty("Code")]
        public string p_erro { get; set; }

        /// <summary>
        /// </summary>
        [JsonProperty("Description")]
        public string p_dserro { get; set; }
    }
}

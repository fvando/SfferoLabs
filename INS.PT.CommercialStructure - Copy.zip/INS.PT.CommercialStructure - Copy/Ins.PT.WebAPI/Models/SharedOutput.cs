﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models
{
    public class SharedOutput : BaseOutput
    {
        private const int BasePropertiesOrder = -8;

        /// <summary>
        /// Gets or sets the address.
        /// </summary>
        /// <value>
        /// The address.
        /// </value>
        [Column("DSDOMICILIO")]
        [JsonProperty(Order = BasePropertiesOrder)]
        public string Address { get; set; }

        /// <summary>
        /// Gets or sets the postal code.
        /// </summary>
        /// <value>
        /// The postal code.
        /// </value>
        [Column("CDPOSTAL")]
        [JsonProperty(Order = BasePropertiesOrder)]
        public string PostalCode { get; set; }

    }
}

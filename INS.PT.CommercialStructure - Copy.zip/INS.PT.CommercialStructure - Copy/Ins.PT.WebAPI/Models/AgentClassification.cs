﻿// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// Agent Classification
    /// </summary>
    public class AgentClassification
    {
        /// <summary>
        /// Agent identifier.
        /// </summary>
        /// <example></example>
        [JsonProperty("AgentCode")]
        public string AgentCode { get; set; }

        /// <summary>
        /// Agent type.
        /// </summary>
        [JsonProperty("Type")]
        public AgentClassificationType AgentType { get; set; }

        [JsonProperty("Classifications")]
        public ICollection<Classification> Classifications { get; set; }
    }
}

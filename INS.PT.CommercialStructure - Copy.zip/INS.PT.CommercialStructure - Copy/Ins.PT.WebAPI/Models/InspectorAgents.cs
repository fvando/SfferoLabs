﻿// Copyright Ageas 2019 © - Integration Team

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// AgentInspector
    /// </summary>
    public class InspectorAgents : OutputDataAndErrors<Agent>
    { }
}

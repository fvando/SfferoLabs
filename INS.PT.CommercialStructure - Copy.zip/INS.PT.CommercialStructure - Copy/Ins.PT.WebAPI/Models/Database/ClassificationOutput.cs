﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models.Database
{
    public class ClassificationOutput : IMapped
    {
        public void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(ClassificationOutput));
        }


        /// <summary>
        /// Order.
        /// </summary>
        /// <example>2</example>
        [Column("ordem")]
        public int Order { get; set; }

        /// <summary>
        /// Agent Identifier
        /// </summary>
        [Column("cdagente")]
        public string IdAgent { get; set; }

        /// <summary>
        /// Tipology.
        /// </summary>
        /// <example>CLASS</example>
        [Column("tipologia")]
        public string Tipology { get; set; }

        /// <summary>
        /// Code
        /// Classification code / agent characteristic
        /// </summary>
        [Column("cdtipo")]
        public string Code { get; set; }

        /// <summary>
        /// Description
        /// Agent Rating / Feature Description
        /// </summary>
        [Column("dstipo")]
        public string Description { get; set; }

        /// <summary>
        /// Date of start.
        /// </summary>
        [Column("data_inicio")]
        public DateTime StartDate { get; set; }

        /// <summary>
        /// If filled date of end of classification.
        /// </summary>
        [Column("data_fim")]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Rule to be applied to the classification.
        /// </summary>
        [Column("regra")]
        public string Rule { get; set; }
    }
}

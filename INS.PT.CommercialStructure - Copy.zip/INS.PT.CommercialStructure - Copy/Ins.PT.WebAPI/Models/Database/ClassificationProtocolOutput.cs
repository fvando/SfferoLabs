﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models.Database
{
    /// <summary>
    /// ClassificationProtocolOutput : IMapped
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.IMapped" />
    public class ClassificationProtocolOutput : IMapped
    {
        /// <summary>
        /// Method that is going to prepare the object mappings.
        /// </summary>
        public void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(ClassificationProtocolOutput));
        }

        /// <summary>
        /// Code
        /// Classification code / agent characteristic
        /// </summary>
        [Column("cdtipo")]
        public string Code { get; set; }

        /// <summary>
        /// Description
        /// Agent Rating / Feature Description
        /// </summary>
        [Column("dstipo")]
        public string Description { get; set; }

    }
}

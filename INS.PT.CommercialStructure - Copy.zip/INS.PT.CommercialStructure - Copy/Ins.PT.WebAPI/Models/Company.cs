﻿using System.Collections.Generic;

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// CompanyCS
    /// </summary>
    public class Company
    {

        /// <summary>
        /// Gets or sets the company.
        /// </summary>
        /// <value>
        /// The company.
        /// </value>
        public string CompanyName { get; set; }

        /// <summary>
        /// Gets or sets the networks.
        /// </summary>
        /// <value>
        /// The networks.
        /// </value>
        public ICollection<Network> Networks { get; set; }       
    }
}

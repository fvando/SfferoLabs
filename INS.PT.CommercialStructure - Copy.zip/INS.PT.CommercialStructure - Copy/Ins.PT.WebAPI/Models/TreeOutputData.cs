﻿namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// OutPDadosClassificationAgents
    /// </summary>
    public class TreeOutputData
    {
        /// <summary>
        /// TIPO_ESTRUTURA
        /// </summary>
        public string TIPO_ESTRUTURA { get; set; }

        /// <summary>
        /// COMPANHIA
        /// </summary>
        public string Companhia { get; set; }

        /// <summary>
        /// NIVEL1
        /// </summary>
        public string Nivel1 { get; set; }

        /// <summary>
        /// NIVEL2
        /// </summary>
        public string Nivel2 { get; set; }

        /// <summary>
        /// NIVEL3
        /// </summary>
        public string Nivel3 { get; set; }

        /// <summary>
        /// NIVEL4
        /// </summary>
        public string Nivel4 { get; set; }

        /// <summary>
        /// CDAGENTE
        /// </summary>
        public string Cdagente { get; set; }

        /// <summary>
        /// DSNOMBRE
        /// </summary>
        public string Dsnombre { get; set; }

        /// <summary>
        /// DSDOMICILIO
        /// </summary>
        public string Dsdomicilio { get; set; }

        
        public string Cdpostal { get; set; }

      
        public string Nmdomicilio { get; set; }

     
        public string Estado { get; set; }

      
        public string DATA_INACTIVO { get; set; }

        public string DATA_ACTIVO { get; set; }


        public string ID_IDENTIDADE { get; set; }
 
        public string ID_IDENT_REPRESENTANTE { get; set; }

        public string TES_DEF { get; set; }

        public string ZONA_ACTUACAO { get; set; }

        public string AREA_INSPECCAO { get; set; }
 
        public string INSP_AC_ESPECIAL { get; set; }

        public string NUMERO_ISP { get; set; }

      
        public string PRODUTOS_ISP { get; set; }


        public string DATA_PROCESSO { get; set; }

        public int ID_PROCESSO { get; set; }

        public string COD_PRODUTOS_ISP { get; set; }

        public bool? IS_DUMMY { get; set; }

        public int? Id_Email { get; set; }

        public string Email { get; set; }

        public string BU { get; set; }
    }

}

﻿using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// Agent returned for a energiser agent
    /// </summary>
    public class StreamlinedAgent : IMapped
    {
        public void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(StreamlinedAgent));
        }


        /// <summary>
        /// Agent code.
        /// </summary>
        /// <example>87795</example>
        [Column("age_dinamizador")]
        public string AgentCode { get; set; }
    }
}

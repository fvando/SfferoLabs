﻿using System.Collections.Generic;
using System.Linq;

namespace INS.PT.WebAPI.Models
{
    public class StructureDeltas
    {
        /// <summary>
        /// Networks that had a change.
        /// </summary>
        public ICollection<NetworkDelta> NetworkDeltas { get; set; } = new List<NetworkDelta>();

        /// <summary>
        /// Zones that had a change.
        /// </summary>
        public ICollection<ZoneDelta> ZoneDeltas { get; set; } = new List<ZoneDelta>();

        /// <summary>
        /// Branches that had a change.
        /// </summary>
        public ICollection<BranchDelta> BranchDeltas { get; set; } = new List<BranchDelta>();

        /// <summary>
        /// Inspectors that had a change.
        /// </summary>
        public ICollection<InspectorDelta> InspectorDeltas { get; set; } = new List<InspectorDelta>();

        /// <summary>
        /// Agents that had a change.
        /// </summary>
        public ICollection<AgentDelta> AgentDeltas { get; set; } = new List<AgentDelta>();


        internal bool AnyData
        {
            get
            {
                var result = NetworkDeltas.Any() || ZoneDeltas.Any();

                result = result || BranchDeltas.Any() || InspectorDeltas.Any();

                return result || AgentDeltas.Any();
            }
        }   
    }
}

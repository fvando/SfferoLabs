﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// InspectorCS
    /// </summary>
    public class Inspector : BaseOutput, IMapped
    {
        public virtual void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(Inspector));
        }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        [Column("ID_IDENTIDADE")]
        public string Id { get; set; }

        /// <summary>
        /// Id of the bank account of the entity.
        /// </summary>
        /// <example>1</example>
        [Column("id_nib")]
        public int? IdBankAccount { get; set; }

        /// <summary>
        /// Id of the phone of the entity.
        /// </summary>
        /// <example>10592272966748706</example>
        [Column("id_telefone")]
        public string IdPhone { get; set; }

        /// <summary>
        /// Id of the email of the entity.
        /// </summary>
        /// <example>1</example>
        [Column("id_email")]
        public int? IdEmail { get; set; }

        [Column("NIVEL4")]
        public override string Code
        {
            get => base.Code;
            set
            {
                base.Code = value;
            }
        }

        /// <summary>
        /// Gets or sets the work area.
        /// </summary>
        /// <value>
        /// The work area.
        /// </value>
        [Column("ZONA_ACTUACAO")]
        public string WorkArea { get; set; }
        /// <summary>
        /// Gets or sets the inspector work area.
        /// </summary>
        /// <value>
        /// The inspector work area.
        /// </value>
        [Column("AREA_INSPECCAO")]
        public string InspectorWorkArea { get; set; }

        /// <summary>
        /// Gets or sets the inspection special ac.
        /// </summary>
        /// <value>
        /// The inspection special ac.
        /// </value>
        [Column("INSP_AC_ESPECIAL")]
        public string InspectionSpecialAc { get; set; }

        /// <summary>
        /// Gets or sets the identifier address.
        /// </summary>
        /// <value>
        /// The identifier address.
        /// </value>
        [Column("NMDOMICILIO")]
        public string IdAddress { get; set; }

        /// <summary>
        /// Email of the entity.
        /// </summary>
        /// <example>1</example>
        [Column("email")]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets the agents1.
        /// </summary>
        /// <value>
        /// The agents1.
        /// </value>
        public virtual ICollection<Agent> Agents { get; set; }      
    }
}

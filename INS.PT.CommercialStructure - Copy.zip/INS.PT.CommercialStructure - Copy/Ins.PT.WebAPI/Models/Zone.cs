﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// ZoneCS
    /// </summary>
    public class Zone : SharedOutput, IMapped
    {
        public virtual void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(Zone));
        }

        /// <summary>
        /// Gets or sets the responsible identifier.
        /// </summary>
        /// <value>
        /// The responsible identifier.
        /// </value>
        [Column("ID_IDENT_REPRESENTANT")]
        public string ResponsibleId { get; set; }

        /// <summary>
        /// Gets or sets the branches.
        /// </summary>
        /// <value>
        /// The branches.
        /// </value>
        public virtual ICollection<Branch> Branches { get; set; }

        [Column("NIVEL2")]
        public override string Code
        {
            get => base.Code;
            set
            {
                base.Code = value;
            }
        }
    }
}

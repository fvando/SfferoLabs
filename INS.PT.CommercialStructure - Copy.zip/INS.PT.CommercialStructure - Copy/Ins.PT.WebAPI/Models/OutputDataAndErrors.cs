﻿// Copyright Ageas 2019 © - Integration Team

using System.Collections.Generic;

/// <summary>
/// INS.PT.WebAPI.Interface
/// </summary>
namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// Base class for output.
    /// </summary>
    /// <typeparam name="L"></typeparam>
    public class OutputDataAndErrors<L> 
    {
        protected OutputDataAndErrors()
        { }

        /// <summary>
        /// Gets or sets the data.
        /// </summary>
        /// <value>
        /// The data.
        /// </value>
        public IEnumerable<L> Data { get; set; }

        /// <summary>
        /// Gets or sets the error.
        /// </summary>
        /// <value>
        /// The error.
        /// </value>
        public IEnumerable<ObjectErrors> Error { get; set; }
    }

}

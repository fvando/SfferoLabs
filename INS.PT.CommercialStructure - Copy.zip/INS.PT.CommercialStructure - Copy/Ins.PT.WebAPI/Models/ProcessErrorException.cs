﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// Error during process execution.
    /// </summary>
    [Serializable]
    public class ProcessErrorException : Exception
    {
        [Serializable]
        public class InnerError
        {
            /// <summary>
            /// Error code.
            /// </summary>
            /// <example>E0001</example>
            public string ErrorCode { get; set; }

            /// <summary>
            /// Error message.
            /// </summary>
            /// <example>Error on process.</example>
            public string ErrorMessage { get; set; }
        }

        /// <summary>
        /// Error code.
        /// </summary>
        /// <example>E0001</example>
        public string ErrorCode { get; set; }

        /// <summary>
        /// Error message.
        /// </summary>
        /// <example>Error on process.</example>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets the inner errors.
        /// </summary>
        /// <example>
        /// The inner errors.
        /// </example>
        public IEnumerable<InnerError> InnerErrors { get; set; }

        #region Contructors
        public ProcessErrorException()
        {
        }

        public ProcessErrorException(string message) : this(message, (Exception)null)
        {
        }

        public ProcessErrorException(string code, string message) : this(message, (Exception)null)
        {
            ErrorCode = code;
        }

        public ProcessErrorException(string message, Exception innerException) : base(message, innerException)
        {
            ErrorMessage = message;
        }

        protected ProcessErrorException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }

        public ProcessErrorException(string errorCode, string errorMessage, IEnumerable<InnerError> innerErrors) : this(errorCode, errorMessage)
        {
            InnerErrors = innerErrors ?? throw new ArgumentNullException(nameof(innerErrors));
        }
        #endregion

        /// <summary>
        /// Gets a message that describes the current exception.
        /// </summary>
        public override string Message => ToString();

        ///<inheritdoc /> 
        /// <summary>
        /// Custom converts to string.
        /// </summary>
        /// <returns>
        /// A <see cref="System.String" /> that represents this instance.
        /// </returns>
        public override string ToString()
        {
            return $"Execution returned error {ErrorCode} with message: {ErrorMessage}";
        }

        /// <inheritdoc /> 
        /// <summary>
        /// Cahnegs the values exposed for serialization.
        /// </summary>
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
            {
                base.GetObjectData(info, context);
                throw new ArgumentNullException(nameof(info));
            }

            info.AddValue(nameof(Source), Source);
            info.AddValue(nameof(ErrorCode), ErrorCode);
            info.AddValue(nameof(ErrorMessage), ErrorMessage);
            info.AddValue(nameof(InnerErrors), InnerErrors);
            info.AddValue(nameof(StackTrace), StackTrace);
        }
    }
}

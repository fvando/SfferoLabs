﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models
{
    public class BaseOutput
    {
        private const int BasePropertiesOrder = -10;

        protected BaseOutput()
        { }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <example>Test name.</example>
        [Column("DSNOMBRE")]
        [JsonProperty(Order = BasePropertiesOrder)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <example>code123</example>>
        [Column("CDAGENTE")]
        [JsonProperty(Order = BasePropertiesOrder)]
        public virtual string Code { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <example>Activo</example>>
        [Column("ESTADO")]
        [JsonProperty(Order = BasePropertiesOrder)]
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the status initial date.
        /// </summary>
        /// <value>
        /// The status initial date.
        /// </value>
        [Column("DATA_ACTIVO")]
        [JsonProperty(Order = BasePropertiesOrder)]
        public DateTime? StatusInitialDate { get; set; }

        /// <summary>
        /// Gets or sets the status end date1.
        /// </summary>
        /// <value>
        /// The status end date1.
        /// </value>
        [Column("DATA_INACTIVO")]
        [JsonProperty(Order = BasePropertiesOrder)]
        public DateTime? StatusEndDate { get; set; }

        /// <summary>
        /// Flag to show if node is dummy.
        /// </summary>
        /// <example>true</example>
        [Column("IS_DUMMY")]
        [JsonProperty(Order = BasePropertiesOrder)]
        public bool? IsDummy { get; set; }
    }
}

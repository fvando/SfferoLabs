﻿namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// Object to read information from package and use to transform.
    /// </summary>
    public class CommercialStructure : OutputDataAndErrors<TreeOutputData>
    { }
}

﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// BranchCS
    /// </summary>
    public class Branch : SharedOutput, IMapped
    {
        public virtual void CreateMapping()
        {
            Helper.MappedHelper.MapWithColumnAttribute(typeof(Branch));
        }

        [Column("NIVEL3")]
        public override string Code
        {
            get => base.Code;
            set
            {
                base.Code = value;
            }
        }

        /// <summary>
        /// Gets or sets the work area.
        /// </summary>
        /// <value>
        /// The work area.
        /// </value>
        [Column("ZONA_ACTUACAO")]
        public string WorkArea { get; set; }

        /// <summary>
        /// Gets or sets the inspectors.
        /// </summary>
        /// <value>
        /// The inspectors.
        /// </value>
        public virtual ICollection<Inspector> Inspectors { get; set; }
    }
}

﻿using INS.PT.WebAPI.Helper;

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// Types of structures in the commercial structure.
    /// </summary>
    public enum ReferenceTypePerson
    {
        // Agente
        [StringValue("A")]
        Agent,

        // Inspetor
        [StringValue("I")]
        Inspector,

        // Balcão
        [StringValue("B")]
        Branch,

        // Zona
        [StringValue("Z")]
        Zone,

        // Rede
        [StringValue("R")]
        Network,

        // Companhia
        [StringValue("C")]
        Company,

        // ASF
        [StringValue("ASF")]
        Asf
    }
}

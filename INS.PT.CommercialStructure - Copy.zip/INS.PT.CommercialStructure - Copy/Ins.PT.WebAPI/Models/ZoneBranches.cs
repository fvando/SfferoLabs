﻿// Copyright Ageas 2019 © - Integration Team

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// NetDesk
    /// </summary>
    public class ZoneBranches : OutputDataAndErrors<Branch>
    { }
}

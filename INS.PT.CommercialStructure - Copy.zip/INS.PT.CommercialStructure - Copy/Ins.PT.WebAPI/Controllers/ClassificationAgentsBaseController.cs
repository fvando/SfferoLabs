﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;

/// <summary>
/// ins.pt.WebAPI.Controllers
/// </summary>
namespace INS.PT.WebAPI.Controllers
{
    /// <summary>
    /// ClassificationAgentsController
    /// </summary>
    public class ClassificationAgentsBaseController : BaseCore
    {
        /// <summary>
        /// The c repository
        /// </summary>
        private readonly ICommomRepository cRepository;

        /// <summary>
        /// The oracle package webservices
        /// </summary>
        const string _oraclePackageWebservices = "NAV.PKG_AGE_WEBSERVICES";

        /// <summary>
        /// Initializes a new instance of the <see cref="ClassificationAgentsBaseController"/> class.
        /// </summary>
        /// <param name="_cRepository">The c repository.</param>
        /// <param name="_httpContext">The HTTP context in use.</param>
        public ClassificationAgentsBaseController(IHttpContextAccessor _httpContext, ICommomRepository _cRepository) : base(_httpContext)
        {
            cRepository = _cRepository;
        }


        /// <summary>
        /// Reads the agent classifications.
        /// </summary>
        /// <param name="idAgent">the agent code</param>
        /// <returns>object with output data.</returns>
        protected virtual async Task<ActionResult<AgentClassification>> ClassificationsAsync(
            [Required]string idAgent, [FromQuery]ClassificationSearchType? searchType)
        {
            return await GetClassificationsAsync(
                (headerParameters) => cRepository.ReadClassificationAsync(headerParameters, idAgent, 
                    searchType ?? ClassificationSearchType.Agent),
                (result) => result == null
                );
        }


        /// <summary>
        /// Reads the classifications deltas.
        /// </summary>
        /// <returns></returns>
        protected virtual async Task<ActionResult<IEnumerable<AgentClassification>>> ClassificationsDeltaAsync([FromQuery][Required]DateTime date)
        {
            return await GetClassificationsAsync(
                (headerParameters) => cRepository.ReadClassificationDeltasAsync(headerParameters, null, date, ClassificationSearchType.Agent),
                (result) => result == null || !result.Any()
                );
        }


        /// <summary>
        /// Reads the agent classifications deltas.
        /// </summary>
        /// <param name="idAgent">the agent code</param>
        /// <returns></returns>
        protected virtual async Task<ActionResult<IEnumerable<AgentClassification>>> ClassificationsDeltaAsync([Required]string idAgent, 
            [FromQuery][Required]DateTime date, [FromQuery]ClassificationSearchType? searchType)
        {
            return await GetClassificationsAsync(
                (headerParameters) => cRepository.ReadClassificationDeltasAsync(headerParameters, idAgent, date, 
                    searchType ?? ClassificationSearchType.Agent),
                (result) => result == null || !result.Any()
                );
        }

        private async Task<ActionResult<OT>> GetClassificationsAsync<OT>(Func<HeaderParameters, Task<OT>> repositoryCall, Func<OT, bool> notFoundLogic)
        {
            try
            {
                var headerParameters = ValidateHeader();

                var result = await repositoryCall.Invoke(headerParameters);

                if (notFoundLogic.Invoke(result))
                {
                    // no results return path
                    Log.Debug($"Return GET: NotFound {result}");
                    return NotFound(result);
                }

                Log.Debug($"Return: OK {JsonConvert.SerializeObject(result)}");

                return Ok(result);
            }
            catch (ProcessErrorException processError)
            {
                // error in logic layer return BadRequest with Error
                return BadRequest(processError);
            }
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception e)
            {
                Log.Error(e);
                throw;
            }
            finally
            {
                Log.Info($"Finish Call GET");
            }
        }


        /// <summary>
        /// Gets the agents of an inspector.
        /// </summary>
        /// <param name="idInspector">The Inspector id.</param>
        /// <returns></returns>
        protected virtual async Task<ActionResult<InspectorAgents>> InspectorsAsync([Required]string idInspector)
        {
            return await ActionAsync<InspectorAgents, Agent>("Get_Inspector_Agents", "P_CDINSPECTOR", idInspector);
        }


        /// <summary>
        /// Returns the Inpectors of a branch.
        /// </summary>
        /// <param name="idBranch">Branch id to get Inpectors.</param>
        /// <returns></returns>
        protected virtual async Task<ActionResult<BranchInspectors>> BranchesAsync([Required]string idBranch)
        {
            return await ActionAsync<BranchInspectors, Inspector>("Get_Balcao_Inspectors", "P_BALCAO", idBranch);
        }


        /// <summary>
        /// Returns the branches of a zone.
        /// </summary>
        /// <param name="idZone">Zone id to get branches.</param>
        /// <returns></returns>
        protected virtual async Task<ActionResult<ZoneBranches>> ZonesAsync([Required]string idZone)
        {
            return await ActionAsync<ZoneBranches, Branch>("Get_Zona_Balcoes", "p_zona", idZone);
        }


        /// <summary>
        /// Returns the zones of a network.
        /// </summary>
        /// <param name="idNetwork">Network id to get the zones.</param>
        /// <returns></returns>
        protected virtual async Task<ActionResult<NetworkZones>> NetworksAsync([Required]string idNetwork)
        {
            return await ActionAsync<NetworkZones, Zone>("Get_Rede_Zonas", "p_rede", idNetwork);
        }

        private async Task<ActionResult<T>> ActionAsync<T, L>(string oracleFunction, string parameterName, string parameterValue
            ) where T : OutputDataAndErrors<L>, new()
        {
            try
            {
                var dyParam = new OracleDynamicParameters();
                var headerParameters = ValidateHeader();

                // Input parameter
                headerParameters.AddToParameters(dyParam);
                dyParam.Add(parameterName, OracleDbType.Varchar2, direction: ParameterDirection.Input, value: parameterValue);

                // Output parameter
                AddOutputParameters(dyParam);

                T result = null;
                await Task.Run(() => result = cRepository.Submit<T, L>(dyParam, _oraclePackageWebservices, oracleFunction));

                if (result == null || !result.Data.Any())
                {
                    // no results return path
                    Log.Debug($"Return GET: NotFound {result}");
                    return NotFound(result);
                }

                Log.Debug($"Return: OK {JsonConvert.SerializeObject(result)}");

                return Ok(result);
            }
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors);
                return NotFound(validateErrors);
            }
            catch (Exception e)
            {
                Log.Error(e);
                return BadRequest(e);
            }
            finally
            {
                Log.Info($"Finish Call GET");
            }
        }
    }
}


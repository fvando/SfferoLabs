﻿using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Controllers
{
    /// <summary>
    /// Controller for the search agents.
    /// </summary>
    public class AgentsSearchBaseController : BaseCore
    {
        private readonly IAgentsSearch repository;

        /// <summary>
        /// Controller constructer.
        /// </summary>
        /// <param name="httpContext">HTTP context to use.</param>
        /// <param name="_repository">repository to use.</param>
        public AgentsSearchBaseController(IHttpContextAccessor httpContext, IAgentsSearch _repository) : base(httpContext)
        {
            repository = _repository;
        }



        /// <summary>
        /// Reads the agents from a energiser agent.
        /// </summary>
        /// <param name="agentCode">energiser agent code.</param>
        /// <returns>List of agents for agent code</returns>
        protected virtual async Task<ActionResult<IEnumerable<StreamlinedAgent>>> FromEnergiserAsync([Required]string agentCode, string controllerVersion)
        {
            Log.Info($"FromEnergiser call from {controllerVersion}");
            return await GetActionResultAsync(
                () => repository.GetAgentsFromEnergiserAsync(agentCode), 
                (result) => result == null || !result.Any());
        }


        /// <summary>
        /// Reads the agents by a class.
        /// </summary>
        /// <param name="classCode">attribute code to read.</param>
        /// <returns>List of classifications for the attribute code</returns>
        protected virtual async Task<ActionResult<IEnumerable<AgentMatch>>> ByClassAsync([Required]string classCode)
        {
            return await GetActionResultAsync(
                () => repository.GetAgentsByClassAsync(classCode),
                (result) => result == null || !result.Any());
        }


        /// <summary>
        /// Reads the agents commercial structure by a class.
        /// </summary>
        /// <param name="classCode">attribute code to read.</param>
        /// <returns>List of classifications for the attribute code</returns>
        protected virtual async Task<ActionResult<IEnumerable<Company>>> StructureByClassAsync([Required]string classCode)
        {
            return await GetActionResultAsync(
                () => repository.GetAgentsStructureByClassAsync(classCode),
                (result) => result == null || !result.Any());
        }


        /// <summary>
        /// Reads the agent with shared commission.
        /// </summary>
        /// <param name="zipCode">zip to search for.</param>
        /// <param name="branchCode">branch code.</param>
        /// <returns>agent code</returns>
        protected virtual async Task<ActionResult<string>> SharedCommissionAsync([Required][FromQuery]string zipCode, [Required][FromQuery]string branchCode)
        {
            return await GetActionResultAsync(
                () =>
                    {
                        var headerParameters = ValidateHeader();
                        return repository.GetSharedCommissionAgentAsync(headerParameters, zipCode, branchCode);
                    },
                (result) => result == null);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Helper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using System.ComponentModel.DataAnnotations;
using INS.PT.WebAPI.Models;

namespace INS.PT.WebAPI.Controllers.V1
{   
    /// <summary>
    /// Commercial Structure version 1 controller.
    /// </summary>
    [Route("v1/[Controller]/[action]")]
    [ApiController]
    public class CommercialStructureController : BaseCore
    {
        const string _oraclePackageWebservices = "NAV.PKG_AGE_WEBSERVICES";
        protected readonly ICommomRepository cRepository;

        /// <summary>
        /// Controller constructer.
        /// </summary>
        /// <param name="_httpContext">http context.</param>
        /// <param name="_cRepository">repository to use.</param>
        public CommercialStructureController(IHttpContextAccessor _httpContext, ICommomRepository _cRepository) : base(_httpContext)
        {
            cRepository = _cRepository;
        }

        /// <summary>
        /// Get the changes in the structure.
        /// </summary>
        /// <param name="date">Date filter.</param>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        ///
        ///     GET /v1/CommercialStructure/Deltas?date=01/31/2017&amp;currentImage=true
        ///</remarks>
        [HttpGet]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(StructureDeltas), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<StructureDeltas>> DeltasAsync([FromQuery][Required] DateTime? date, [FromQuery] bool? currentImage)
        {
            const string _oracleFunction = "ESTRUTURA_COMERCIAL";

            try
            {
                var dyParam = new OracleDynamicParameters();
                // read and validate header parameters
                var headerParameters = ValidateHeader();

                // input parameters
                // add header parameters to package parameters
                headerParameters.AddToParameters(dyParam);
                dyParam.Add("p_data", OracleDbType.Date, ParameterDirection.Input, date.HasValue ? date.Value : (DateTime?)null);
                dyParam.Add("p_img_actual", OracleDbType.Int32, ParameterDirection.Input, currentImage.HasValue && currentImage.Value ? 1 : 0);

                // add output parameters
                AddOutputParameters(dyParam);

                // build results
                var resultData = await cRepository.ReadDeltasAsync(dyParam, _oraclePackageWebservices, _oracleFunction);

                if (resultData == null || !resultData.AnyData)
                {
                    // no results return path
                    Log.Debug($"Return GET: NotFound {resultData}");
                    return NotFound(resultData);
                }

                // log results
                Log.Debug($"Return: OK {JsonConvert.SerializeObject(resultData)}");

                return Ok(resultData);
            }
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception e)
            {
                Log.Error(e);
                return BadRequest(e);
            }
            finally
            {
                Log.Info($"Finish Call GET");
            }
        }


        /// <summary>Gets the structure of the type requested.</summary>
        /// <param name="type">type of structure to return.</param>
        /// <param name="code">code to filter on the type.</param>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/CommercialStructure/Structure/Agent/8751
        ///     GET /v1/CommercialStructure/Structure/Inspector/9437
        ///     GET /v1/CommercialStructure/Structure/Branch/10113
        ///     GET /v1/CommercialStructure/Structure/Zone/010
        ///     GET /v1/CommercialStructure/Structure/Network/010
        ///     GET /v1/CommercialStructure/Structure/Company/AGEAS
        ///     GET /v1/CommercialStructure/Structure/Asf/2002616
        /// </remarks>
        [HttpGet("{type}/{code}", Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(Company), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<Company>>> Structure(
            [FromRoute][Required]ReferenceTypePerson type,
            [FromRoute][Required]string code
            )
        {
            const string _oracleFunction = "Get_Agente_EC";

            try
            {
                OracleDynamicParameters dyParam = new OracleDynamicParameters();

                //InPut parameter
                dyParam.Add("p_cdagente", OracleDbType.Varchar2, direction: ParameterDirection.Input, value: code);
                dyParam.Add("p_tipo", OracleDbType.Varchar2, direction: ParameterDirection.Input, value: type.GetStringValue());

                // add output parameters
                AddOutputParameters(dyParam);

                // build results
                var result = await Task.Run(() =>
                {
                    var stopwatch = new System.Diagnostics.Stopwatch();

                    // invoke package
                    var resultData = cRepository.Submit<CommercialStructure, TreeOutputData>(dyParam, _oraclePackageWebservices, _oracleFunction);

                    stopwatch.Start();
                    var resultDataTmp = new List<Company>();

                    //Hierarchy Make
                    foreach (var item in resultData.Data)
                    {
                        TransformationData.MakeHierarchyStructure(resultDataTmp, item);
                    }
                    stopwatch.Stop();
                    Log.Debug($"Generate output took: {stopwatch.ElapsedMilliseconds}ms");

                    return resultDataTmp;
                });

                // validate results to return
                if (result == null || result.Count <= 0)
                {
                    // no results return path
                    Log.Debug($"Return GET: NotFound {result}");
                    return NotFound(result);
                }

                // log results
                Log.Debug($"Return: OK {JsonConvert.SerializeObject(result)}");

                return Ok(result);
            }
            catch (ProcessErrorException processError)
            {
                // error in logic layer return BadRequest with Error
                return NotFound(processError);
            }
            catch (Exception e)
            {
                Log.Error(e);
                return BadRequest(e);
            }
            finally
            {
                Log.Info($"Finish Call GET");
            }
        }
    }
}

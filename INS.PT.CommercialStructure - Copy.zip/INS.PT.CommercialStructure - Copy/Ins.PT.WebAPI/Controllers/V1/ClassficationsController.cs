﻿using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Controllers.V1
{
    /// <summary>
    /// Controller for the classifications.
    /// </summary>
    [Route("v1/[controller]/[Action]")]
    [ApiController]
    public class ClassficationsController : ClassficationsBaseController
    {
        /// <summary>
        /// Controller constructer.
        /// </summary>
        /// <param name="httpContext">HTTP context to use.</param>
        /// <param name="_repository">repository to use.</param>
        public ClassficationsController(IHttpContextAccessor httpContext, IClassifications _repository) : base(httpContext, _repository)
        {
        }

        /// <summary>
        /// Reads the classifications by the attributes.
        /// </summary>
        /// <param name="attributeCode">attribute code to read.</param>
        /// <returns>List of classifications for the attribute code</returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v1/Classfications/ByAttribute/GA
        /// </remarks>
        [HttpGet("{attributeCode}")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(IEnumerable<Classification>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public new async Task<ActionResult<IEnumerable<Classification>>> ByAttributeAsync([Required]string attributeCode) 
            => await base.ByAttributeAsync(attributeCode);
    }
}

﻿using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.V2;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Controllers
{
    /// <summary>
    /// Controller for the classifications.
    /// </summary>
    public class ClassficationsBaseController : BaseCore
    {
        private readonly IClassifications repository;

        /// <summary>
        /// Controller constructer.
        /// </summary>
        /// <param name="httpContext">HTTP context to use.</param>
        /// <param name="_repository">repository to use.</param>
        public ClassficationsBaseController(IHttpContextAccessor httpContext, IClassifications _repository) : base(httpContext)
        {
            repository = _repository;
        }

        /// <summary>
        /// Reads the classifications by the attributes.
        /// </summary>
        /// <param name="attributeCode">attribute code to read.</param>
        /// <returns>List of classifications for the attribute code</returns>
        protected virtual async Task<ActionResult<IEnumerable<Classification>>> ByAttributeAsync([Required]string attributeCode)
        {
            return await GetActionResultAsync(
                () => repository.ReadClassificationsByAttributeAsync(attributeCode),
                (result) => result == null || !result.Any());
        }

        /// <summary>
        /// Bies the protocol asynchronous.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="code">The code.</param>
        /// <param name="attributeCode">The attribute code.</param>
        /// <returns></returns>
        protected virtual async Task<ActionResult<IEnumerable<ClassificationProtocol>>> ByProtocolAsync(CommercialStructureLevels type, string code, string attributeCode)
        {
            return await GetActionResultAsync(
                () => repository.ReadClassificationsByProtocolAsync(type, code, attributeCode),
                (result) => result == null || !result.Any());
        }

    }
}

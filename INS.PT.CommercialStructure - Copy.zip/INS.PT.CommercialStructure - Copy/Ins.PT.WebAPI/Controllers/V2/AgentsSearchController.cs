﻿using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Controllers.V2
{
    /// <summary>
    /// Controller for the search agents.
    /// </summary>
    [Route("v2/[controller]/[Action]")]
    [ApiController]
    public class AgentsSearchController : AgentsSearchBaseController
    {
        const string ControllerVersion = "v2";

        /// <summary>
        /// Controller constructer.
        /// </summary>
        /// <param name="httpContext">HTTP context to use.</param>
        /// <param name="_repository">repository to use.</param>
        public AgentsSearchController(IHttpContextAccessor httpContext, IAgentsSearch _repository) : base(httpContext, _repository)
        {
        }

        /// <summary>
        /// Reads the agents from a energiser agent.
        /// </summary>
        /// <param name="agentCode">energiser agent code.</param>
        /// <returns>List of agents for agent code</returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v2/AgentsSearch/FromEnergiser/89610
        /// </remarks>
        [HttpGet("{agentCode}")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(IEnumerable<StreamlinedAgent>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<StreamlinedAgent>>> FromEnergiserAsync([Required]string agentCode) 
            => await base.FromEnergiserAsync(agentCode, ControllerVersion);


        /// <summary>
        /// Reads the agents by a class.
        /// </summary>
        /// <param name="classCode">attribute code to read.</param>
        /// <returns>List of classifications for the attribute code</returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v2/AgentsSearch/ByClass/CS
        /// </remarks>
        [HttpGet("{classCode}")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(IEnumerable<AgentMatch>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public new async Task<ActionResult<IEnumerable<AgentMatch>>> ByClassAsync([Required]string classCode) 
            => await base.ByClassAsync(classCode);


        /// <summary>
        /// Reads the agents commercial structure by a class.
        /// </summary>
        /// <param name="classCode">attribute code to read.</param>
        /// <returns>List of classifications for the attribute code</returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v2/AgentsSearch/StructureByClass/CS
        /// </remarks>
        [HttpGet("{classCode}")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(IEnumerable<Company>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public new async Task<ActionResult<IEnumerable<Company>>> StructureByClassAsync([Required]string classCode) 
            => await base.StructureByClassAsync(classCode);


        /// <summary>
        /// Reads the agent with shared commission.
        /// </summary>
        /// <param name="zipCode">zip to search for.</param>
        /// <param name="branchCode">branch code.</param>
        /// <returns>agent code</returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v2/AgentsSearch/SharedCommission/?zipCode=1700-000&amp;branchCode=96
        /// </remarks>
        [HttpGet]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public new async Task<ActionResult<string>> SharedCommissionAsync([Required][FromQuery]string zipCode, [Required][FromQuery]string branchCode)
            => await base.SharedCommissionAsync(zipCode, branchCode);
    }
}

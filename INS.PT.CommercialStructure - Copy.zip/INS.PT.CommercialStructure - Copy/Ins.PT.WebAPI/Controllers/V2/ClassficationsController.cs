﻿using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.V2;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Controllers.V2
{
    /// <summary>
    /// Controller for the classifications.
    /// </summary>
    [Route("v2/[controller]/[Action]")]
    [ApiController]
    public class ClassficationsController : ClassficationsBaseController
    {
        /// <summary>
        /// Controller constructer.
        /// </summary>
        /// <param name="httpContext">HTTP context to use.</param>
        /// <param name="_repository">repository to use.</param>
        public ClassficationsController(IHttpContextAccessor httpContext, IClassifications _repository) : base(httpContext, _repository)
        {
        }

        /// <summary>
        /// Reads the classifications by the attributes.
        /// </summary>
        /// <param name="attributeCode">attribute code to read.</param>
        /// <returns>List of classifications for the attribute code</returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v2/Classfications/ByAttribute/GA
        /// </remarks>
        [HttpGet("{attributeCode}")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(IEnumerable<Classification>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public new async Task<ActionResult<IEnumerable<Classification>>> ByAttributeAsync([Required]string attributeCode) 
            => await base.ByAttributeAsync(attributeCode);

        /// <summary>
        /// Reads the classifications by the protocol.
        /// </summary>
        /// <param name="type">attribute type to read.</param>
        /// <param name="code">attribute code to read.</param>
        /// <param name="attributeCode">attribute code to read.</param>
        /// <returns>List of classifications for the attribute code</returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v2/Classfications/ByProtocol/Zone/010/AT
        /// </remarks>
        [HttpGet("{type}/{code}/{attributeCode}")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(IEnumerable<ClassificationProtocol>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public new async Task<ActionResult<IEnumerable<ClassificationProtocol>>> ByProtocolAsync(
            [FromRoute][Required] CommercialStructureLevels type,
            [FromRoute][Required] string code,
            [FromRoute][Required] string attributeCode)
          => await base.ByProtocolAsync(type, code, attributeCode);
    }
}


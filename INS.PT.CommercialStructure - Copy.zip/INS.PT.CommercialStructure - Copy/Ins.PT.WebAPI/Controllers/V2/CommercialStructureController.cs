﻿using System.Collections.Generic;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System;
using System.Linq;
using INS.PT.WebAPI.Models.V2;
using System.Runtime.InteropServices;
using Newtonsoft.Json;
using v2Deltas = INS.PT.WebAPI.Models.V2.Deltas;
using INS.PT.WebAPI.Models;

namespace INS.PT.WebAPI.Controllers.V2
{
    [Route("v2/[controller]/[action]")]
    [ApiController]
    public class CommercialStructureController : BaseCore
    {
        private readonly ICommercialStructure commercialStructureRepo;

        /// <summary>
        /// Controller constructer.
        /// </summary>
        /// <param name="httpContext">http context.</param>
        public CommercialStructureController(IHttpContextAccessor httpContext, ICommercialStructure commercialStructure) : base(httpContext)
        {
            commercialStructureRepo = commercialStructure;
        }



        /// <summary>
        /// Get the changes in the structure.
        /// </summary>
        /// <param name="date">Date filter.</param>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        ///
        ///     GET /v2/CommercialStructure/Deltas?date=01/31/2017&amp;currentImage=true
        ///</remarks>
        [HttpGet]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(v2Deltas.StructureDeltas), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<v2Deltas.StructureDeltas>> DeltasAsync(
            [FromQuery][Required] DateTime? date, 
            [FromQuery] bool? currentImage)
        {
            return await GetActionResultAsync(
                () => commercialStructureRepo.ReadStructureDeltasSync(ValidateHeader(), date, currentImage),
                (result) => result == null || !result.AnyData);
        }



        /// <summary>Gets the structure of the type requested.</summary>
        /// <param name="type">type of structure to return.</param>
        /// <param name="code">code to filter on the type.</param>
        /// <returns>List of Groups that belong to structure requested</returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v2/CommercialStructure/Structure/Agent/8751
        ///     GET /v2/CommercialStructure/Structure/Inspector/9437
        ///     GET /v2/CommercialStructure/Structure/Branch/10113
        ///     GET /v2/CommercialStructure/Structure/Zone/010
        ///     GET /v2/CommercialStructure/Structure/Network/010
        ///     GET /v2/CommercialStructure/Structure/Management/DIAG2
        ///     GET /v2/CommercialStructure/Structure/Channel/CAAG1
        ///     GET /v2/CommercialStructure/Structure/Brand/MAAG
        ///     GET /v2/CommercialStructure/Structure/Group/ONE
        /// </remarks>
        [HttpGet("{type}/{code}", Name = "[controller]/[action]_v2")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(Group), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<IEnumerable<Group>>> Structure(
            [FromRoute][Required]CommercialStructureLevels type,
            [FromRoute][Required]string code,
            [FromQuery][Optional]bool hideAllChilds
            )
        {
            return await GetActionResultAsync(
                () => commercialStructureRepo.ReadStructureAsync(type, code, hideAllChilds),
                (result) => result == null || !result.Any());
        }


        /// <summary>
        /// Updates or inserts element data to structure.
        /// </summary>
        /// <param name="levelElement">input data.</param>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST
        ///     {
        ///           "levelType": "Group",
        ///           "isNewElement": false,
        ///           "code": "TST",
        ///           "parentCode": null,
        ///           "description": "test GROUP",
        ///           "startDate": "2020-08-18T17:03:30.005Z"
        ///     }
        ///</remarks>
        [HttpPost]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> UpsertAsync(
            [FromBody][Required] LevelElement levelElement)
        {
            object badResult = null;

            try
            {
                var result = await commercialStructureRepo.UpsertElementInformationAsync(levelElement);

                if (!result)
                {
                    // no results return path
                    Log.Debug($"Return POST: NotFound {result}");
                    return NotFound(result);
                }

                Log.Debug($"Return: OK {JsonConvert.SerializeObject(result)}");

                return Ok(result);
            }
            catch (ProcessErrorException processErrors)
            {
                Log.Error(processErrors);
                return NotFound(processErrors);
            }
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors);
                badResult = validateErrors;
            }
            catch (Exception e)
            {
                Log.Error(e);
                badResult = new ProcessErrorException(e.Message);
            }
            finally
            {
                Log.Info($"Finish Call POST");
            }

            return BadRequest(badResult);
        }
    }
}

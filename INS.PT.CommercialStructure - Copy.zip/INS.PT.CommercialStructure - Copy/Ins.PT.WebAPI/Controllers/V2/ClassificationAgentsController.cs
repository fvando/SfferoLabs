﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

/// <summary>
/// ins.pt.WebAPI.Controllers
/// </summary>
namespace INS.PT.WebAPI.Controllers.V2
{
    /// <summary>
    /// ClassificationAgentsController
    /// </summary>
    [Route("v2/[controller]/[Action]")]
    [ApiController]
    public class ClassificationAgentsController : ClassificationAgentsBaseController
    {
        internal const string OperationId_DeltaForAgent = "ClassificationsDeltaForAgentV2";

        /// <summary>
        /// Initializes a new instance of the <see cref="ClassificationAgentsBaseController"/> class.
        /// </summary>
        /// <param name="_cRepository">The c repository.</param>
        /// <param name="_httpContext">The HTTP context in use.</param>
        public ClassificationAgentsController(IHttpContextAccessor _httpContext, ICommomRepository _cRepository) : base(_httpContext, _cRepository)
        {
        }

        /// <summary>
        /// Reads the agent classifications.
        /// </summary>
        /// <param name="idAgent">the agent code</param>
        /// <returns>object with output data.</returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v2/ClassificationAgents/Classifications/87061
        ///     GET /v2/ClassificationAgents/Classifications/1018420?searchType=Inspector
        /// </remarks>
        [HttpGet("{idAgent}")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(AgentClassification), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public new async Task<ActionResult<AgentClassification>> ClassificationsAsync(
            [Required]string idAgent, [FromQuery]ClassificationSearchType? searchType) 
            => await base.ClassificationsAsync(idAgent, searchType);


        /// <summary>
        /// Reads the classifications deltas.
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v2/ClassificationAgents/ClassificationsDelta/?01/28/2019
        /// </remarks>
        [HttpGet(Name = "ClassificationsDeltaV2")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(IEnumerable<AgentClassification>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public new async Task<ActionResult<IEnumerable<AgentClassification>>> ClassificationsDeltaAsync([FromQuery][Required]DateTime date)
            => await base.ClassificationsDeltaAsync(date);


        /// <summary>
        /// Reads the agent classifications deltas.
        /// </summary>
        /// <param name="idAgent">the agent code</param>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v2/ClassificationAgents/ClassificationsDelta/87061?01/28/2019
        ///     GET /v2/ClassificationAgents/ClassificationsDelta/1018420?01/28/2019&amp;searchType=Inspector
        /// </remarks>
        [HttpGet("{idAgent}", Name = OperationId_DeltaForAgent)]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(IEnumerable<AgentClassification>), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public new async Task<ActionResult<IEnumerable<AgentClassification>>> ClassificationsDeltaAsync([Required]string idAgent,
            [FromQuery][Required]DateTime date, [FromQuery]ClassificationSearchType? searchType)
            => await base.ClassificationsDeltaAsync(idAgent, date, searchType);


        /// <summary>
        /// Gets the agents of an inspector.
        /// </summary>
        /// <param name="idInspector">The Inspector id.</param>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v2/ClassificationAgents/Inspectors/2013399
        /// </remarks>
        [HttpGet("{idInspector}")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(InspectorAgents), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public new async Task<ActionResult<InspectorAgents>> InspectorsAsync([Required]string idInspector) 
            => await base.InspectorsAsync(idInspector);


        /// <summary>
        /// Returns the Inpectors of a branch.
        /// </summary>
        /// <param name="idBranch">Branch id to get Inpectors.</param>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v2/ClassificationAgents/Branches/10113
        /// </remarks>
        [HttpGet("{idBranch}")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(BranchInspectors), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public new async Task<ActionResult<BranchInspectors>> BranchesAsync([Required]string idBranch) 
            => await base.BranchesAsync(idBranch);


        /// <summary>
        /// Returns the branches of a zone.
        /// </summary>
        /// <param name="idZone">Zone id to get branches.</param>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v2/ClassificationAgents/Zones/010
        /// </remarks>
        [HttpGet("{idZone}")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(ZoneBranches), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public new async Task<ActionResult<ZoneBranches>> ZonesAsync([Required]string idZone) 
            => await base.ZonesAsync(idZone);


        /// <summary>
        /// Returns the zones of a network.
        /// </summary>
        /// <param name="idNetwork">Network id to get the zones.</param>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        /// 
        ///     GET /v2/ClassificationAgents/Networks/025
        /// </remarks>
        [HttpGet("{idNetwork}")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(NetworkZones), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public new async Task<ActionResult<NetworkZones>> NetworksAsync([Required]string idNetwork) 
            => await base.NetworksAsync(idNetwork);
    }
}

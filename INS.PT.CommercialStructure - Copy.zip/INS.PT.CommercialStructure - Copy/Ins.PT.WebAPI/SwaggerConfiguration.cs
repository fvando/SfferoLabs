﻿// Copyright Ageas 2019 © - Integration Team

using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.IO;
/// <summary>
/// INS.PT.WebAPI
/// </summary>
namespace INS.PT.WebAPI
{
    /// <summary>
    /// SwaggerConfiguration
    /// </summary>
    public static class SwaggerConfiguration
    {
        public static void AddService(IServiceCollection services)
        {
            // Register the Swagger generator, defining one or more Swagger documents
            services?.AddSwaggerGen(swagger =>
            {
                swagger.OperationFilter<Filters.HeaderParametersFilter>();

                // v1 API version
                swagger.SwaggerDoc("v1",
                                   new Microsoft.OpenApi.Models.OpenApiInfo
                                   {
                                       Title = DocInfoTitle,
                                       Version = "v1",
                                       Description = DocInfoDescription,
                                   }
                    );
                // v2 API version
                swagger.SwaggerDoc("v2",
                                   new Microsoft.OpenApi.Models.OpenApiInfo
                                   {
                                       Title = DocInfoTitle,
                                       Version = "v2",
                                       Description = DocInfoDescription,
                                   }
                    );

                // Set the comments path for the Swagger JSON and UI.
                var xmlFile = $"{typeof(Startup).Assembly.GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                swagger.IncludeXmlComments(xmlPath);
            });
        }

        public static void Build(IApplicationBuilder app)
        {

            // Enable middleware to serve generated Swagger as a JSON endpoint.
            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.), specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                // v2 API version
                c.SwaggerEndpoint("../swagger/v2/swagger.json", "CommercialStructure v2");
                // v1 API version
                c.SwaggerEndpoint("../swagger/v1/swagger.json", "CommercialStructure v1");

                c.DocExpansion(Swashbuckle.AspNetCore.SwaggerUI.DocExpansion.None);
            });
        }


        /// <summary>
        /// <para>Foo API</para>
        /// </summary>
        private static string DocInfoTitle => "CommercialStructure API";

        /// <summary>
        /// <para>Foo Api - Sample Web API in ASP.NET Core 2</para>
        /// </summary>
        private static string DocInfoDescription => "CommercialStructure Api";
    }
}

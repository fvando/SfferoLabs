﻿// Copyright Ageas 2019 © - Integration Team

/// <summary>
/// INS.PT.WebAPI
/// </summary>
namespace INS.PT.WebAPI
{
    /// <summary>
    /// ApplicationSettings
    /// </summary>
    public class ApplicationSettings
    {
           public string ApplicationName { get; set; }
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using Oracle.ManagedDataAccess.Client;
using System;
using Microsoft.Extensions.Configuration;
using System.Data;
using Newtonsoft.Json;
using log4net;
using System.Reflection;

namespace INS.PT.WebAPI
{
    ///<inheritdoc /> 
    /// <summary>
    /// concrete class
    /// </summary>
    public class Dbconnectioncs : IDbconnectioncs, IDisposable
    {
        private readonly IConfiguration configuration;
        private readonly ILog _log;
        private IDbConnection connection;

        /// <summary>
        /// Object contructor.
        /// </summary>
        /// <param name="configuration">Configuration to use.</param>
        public Dbconnectioncs(IConfiguration configuration)
        {
            _log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            this.configuration = configuration;
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources.
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            // cleanup
            if (connection != null && connection.State != ConnectionState.Closed)
            {
                connection.Close();
            }
        }

        /// <summary>
        /// GetConnection
        /// </summary>
        /// <returns>Connection to be used.</returns>
        public IDbConnection Connection
        {
            get
            {
                try
                {
                    // open connection if not already open
                    if (connection == null || connection.State == ConnectionState.Closed)
                    {
                        var stopwatch = new System.Diagnostics.Stopwatch();
                        stopwatch.Start();

                        var connectionString = configuration.GetSection("ConnectionStrings").GetSection("DBConnection").Value;

                        var oracleConnection = new OracleConnection(connectionString);
                        oracleConnection.Open();

                        stopwatch.Stop();
                        _log.Info($"GetConnection result: {JsonConvert.SerializeObject(oracleConnection)};\n Open coonnection took {stopwatch.ElapsedMilliseconds}ms");

                        stopwatch.Restart();
                        SetNlsConnectionSettings(oracleConnection);
                        stopwatch.Stop();
                        _log.Info($"GetConnection set NLs settings took {stopwatch.ElapsedMilliseconds}ms");

                        connection = oracleConnection;
                    }
                }
                catch (Exception ex)
                {
                    // exception  
                    _log.Error($"Result: { JsonConvert.SerializeObject(ex.Message, Formatting.Indented)}");
                    throw;
                }

                return connection;
            }
        }

        /// <summary>
        /// Procedure to check NLS settings and update the ones defined in appsettings.json
        /// </summary>
        /// <param name="oracleConnection">Connection to check settings.</param>
        private void SetNlsConnectionSettings(OracleConnection oracleConnection)
        {
            var info = oracleConnection.GetSessionInfo();
            var configSettings = configuration.GetSection("NlsSettings");

            if(configSettings == null)
            {
                return;
            }

            _log.Debug($"GetConnection NLS settings before: {JsonConvert.SerializeObject(info)};");

            info.Calendar = ReadSetting(configSettings, "Calendar", info.Calendar);
            info.Comparison = ReadSetting(configSettings, "Comparison", info.Comparison);
            info.Currency = ReadSetting(configSettings, "Currency", info.Currency);
            info.DateFormat = ReadSetting(configSettings, "DateFormat", info.DateFormat);
            info.DateLanguage = ReadSetting(configSettings, "DateLanguage", info.DateLanguage);
            info.DualCurrency = ReadSetting(configSettings, "DualCurrency", info.DualCurrency);
            info.ISOCurrency = ReadSetting(configSettings, "ISOCurrency", info.ISOCurrency);
            info.Language = ReadSetting(configSettings, "Language", info.Language);
            info.LengthSemantics = ReadSetting(configSettings, "LengthSemantics", info.LengthSemantics);
            info.NCharConversionException = ReadSetting(configSettings, "NCharConversionException", info.NCharConversionException);
            info.NumericCharacters = ReadSetting(configSettings, "NumericCharacters", info.NumericCharacters);
            info.Sort = ReadSetting(configSettings, "Sort", info.Sort);
            info.Territory = ReadSetting(configSettings, "Territory", info.Territory);
            info.TimeStampFormat = ReadSetting(configSettings, "TimeStampFormat", info.TimeStampFormat);
            info.TimeStampTZFormat = ReadSetting(configSettings, "TimeStampTZFormat", info.TimeStampTZFormat);
            info.TimeZone = ReadSetting(configSettings, "TimeZone", info.TimeZone);

            oracleConnection.SetSessionInfo(info);
            _log.Debug($"GetConnection NLS settings after: {JsonConvert.SerializeObject(info)};");
        }

        /// <summary>
        /// Method to read a setting from appsettings.json and return the value or default value.
        /// </summary>
        /// <param name="configSettings">place to read the setting</param>
        /// <param name="settingName">setting name</param>
        /// <param name="defaultValue">default value for non existing setting</param>
        /// <returns>value to use from settings or default value</returns>
        private static string ReadSetting(IConfiguration configSettings, string settingName, string defaultValue)
        {
            var value = configSettings?.GetSection(settingName)?.Value;

            if (string.IsNullOrEmpty(value))
            {
                return defaultValue;
            }

            return value;
        }


        /// <summary>
        /// Method to read a setting from appsettings.json and return the value or default value.
        /// </summary>
        /// <param name="configSettings">place to read the setting</param>
        /// <param name="settingName">setting name</param>
        /// <param name="defaultValue">default value for non existing setting</param>
        /// <returns>value to use from settings or default value</returns>
        private static bool ReadSetting(IConfiguration configSettings, string settingName, bool defaultValue)
        {
            var value = configSettings?.GetSection(settingName)?.Value;

            if (string.IsNullOrEmpty(value))
            {
                return defaultValue;
            }

            return Convert.ToBoolean(value, System.Globalization.CultureInfo.InvariantCulture);
        }
    }

}

﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Models;
using log4net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

/// <summary>
/// INS.PT.WebAPI
/// </summary>
namespace INS.PT.WebAPI
{
    /// <summary>
    ///  BaseCore: ControllerBase
    /// </summary>
    public class BaseCore : ControllerBase
    {
        /// <summary>
        /// The size buffer
        /// </summary>
        const int sizeBuffer = 1000;

        /// <summary>
        /// The object data
        /// </summary>
        const string _ObjectData = "p_dados";


        /// <summary>
        /// The log
        /// </summary>
        protected readonly ILog Log;
        protected readonly IHttpContextAccessor httpContext;

        /// <summary>
        /// COnstructor.
        /// </summary>
        /// <param name="httpContext">http context</param>
        public BaseCore(IHttpContextAccessor httpContext)
        {
            Log = LogManager.GetLogger(typeof(BaseCore));
            this.httpContext = httpContext ?? throw new ArgumentNullException(nameof(httpContext));
        }


        /// <summary>
        /// Method to add output parameters to collection.
        /// </summary>
        /// <param name="oracleDynamicParameters">Oracle parameters to add new parameters.</param>
        internal static void AddOutputParameters(OracleDynamicParameters oracleDynamicParameters)
        {
            oracleDynamicParameters.Add(_ObjectData, OracleDbType.RefCursor, direction: ParameterDirection.Output);
            oracleDynamicParameters.Add(nameof(ObjectErrors.p_erro), OracleDbType.Varchar2, direction: ParameterDirection.Output, value: null, size: sizeBuffer);
            oracleDynamicParameters.Add(nameof(ObjectErrors.p_dserro), OracleDbType.Varchar2, direction: ParameterDirection.Output, value: null, size: sizeBuffer);
        }

        #region Header Parameters
        /// <summary>
        /// Method to read header parameters and validate their value.
        /// </summary>
        /// <returns>HeaderParameers object with values.</returns>
        protected virtual HeaderParameters ValidateHeader()
        {
            var headerParameters = new HeaderParameters();
            var errors = new List<ValidationResult>();

            // read header parameters
            headerParameters.IdCompany = ReadHeaderParameter(nameof(headerParameters.IdCompany));
            headerParameters.IdSource = ReadHeaderParameter(nameof(headerParameters.IdSource));

            // execute validation
            Validator.TryValidateObject(headerParameters, new ValidationContext(headerParameters), errors, true);

            if (errors.Any())
            {
                throw new AggregateException(
                       errors.Select((e) => new ValidationException(e.ErrorMessage)));
            }

            return headerParameters;
        }

        private string ReadHeaderParameter(string parameterName)
        {
            // try to read header value
            if (!string.IsNullOrEmpty(parameterName) && httpContext != null
                && httpContext.HttpContext.Request.Headers.TryGetValue(parameterName, out var headerValues))
            {
                return headerValues.First();
            }

            return null;
        }
        #endregion

        /// <summary>
        /// Typical action for Get Actions that return an Enumerate.
        /// </summary>
        /// <typeparam name="T">Type for the Enumerable to return</typeparam>
        /// <param name="repositoryCall">function where to get the data</param>
        /// <returns>action result object according to the results</returns>
        protected async Task<ActionResult<T>> GetActionResultAsync<T>(Func<Task<T>> repositoryCall, Func<T, bool> notFoundLogic)
        {
            object badResult = null;

            try
            {
                var result = await repositoryCall?.Invoke();

                if (notFoundLogic == null || notFoundLogic.Invoke(result))
                {
                    // no results return path
                    Log.Debug($"Return GET: NotFound {result}");
                    return NotFound(result);
                }

                Log.Debug($"Return: OK {JsonConvert.SerializeObject(result)}");

                return Ok(result);
            }
            catch (ProcessErrorException processErrors)
            {
                Log.Error(processErrors);
                return NotFound(processErrors);
            }
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors);
                badResult = validateErrors;
            }
            catch (Exception e)
            {
                Log.Error(e);
                badResult = new ProcessErrorException(e.Message);
            }
            finally
            {
                Log.Info($"Finish Call GET");
            }

            return BadRequest(badResult);
        }
    }
}

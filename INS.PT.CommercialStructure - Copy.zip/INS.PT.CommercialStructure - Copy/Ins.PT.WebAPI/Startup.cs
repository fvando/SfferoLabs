﻿// Copyright Ageas 2020 © - Integration Team

using System;
using System.IO;
using System.Reflection;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using log4net;
using INS.PT.WebAPI.Middleware;
using System.Linq;
using Microsoft.Extensions.Hosting;


/// <summary>
/// INS.PT.WebAPI
/// </summary>
namespace INS.PT.WebAPI
{
    /// <summary>
    /// Startup
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// Startup
        /// </summary>
        /// <param name="configuration"></param>
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        /// <summary>
        /// ConfigureServices
        /// </summary>
        /// <param name="services"></param>
        public void ConfigureServices(IServiceCollection services)
        {
            // Check health services, Necessary core 2.2
            services.AddHealthChecks();

            services.AddRazorPages();

            // Configure Log4Net
            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
            var logConfigFile = Configuration["Logging:LogConfigFile"];
            log4net.Config.XmlConfigurator.Configure(logRepository, new FileInfo(logConfigFile));

            //Start log
            LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

            // serialization
            services.AddMvc()
                .AddNewtonsoftJson(options =>
                {
                    options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
                    options.SerializerSettings.ContractResolver = new Newtonsoft.Json.Serialization.DefaultContractResolver
                    {
                        NamingStrategy = new Newtonsoft.Json.Serialization.CamelCaseNamingStrategy()
                    };
                })
                .AddJsonOptions(options => options.JsonSerializerOptions.Converters.Add(new System.Text.Json.Serialization.JsonStringEnumConverter()))
                .AddXmlSerializerFormatters()
                .AddXmlDataContractSerializerFormatters();

            services.AddHttpContextAccessor();

            services.AddMvc(option => option.EnableEndpointRouting = false);



            Setups.SetupRepositories(services);

            Setups.SetupMappings();

            services.AddSingleton<IDbconnectioncs>(new Dbconnectioncs(Configuration));

            services.AddSingleton(Configuration);

            // Get Application Settings
            services.Configure<ApplicationSettings>(Configuration.GetSection("ApplicationSettings"));
            services.AddMvc(c => c.Conventions.Add(new ApiExplorerGroupPerVersionConvention()));

            SwaggerConfiguration.AddService(services);
        }

        public static class Setups
        {
            public static void SetupMappings()
            {
                var currentAssembly = typeof(Startup).Assembly;

                // setup mappings for Dapper
                var allModels = AppDomain.CurrentDomain.GetAssemblies()
                    .SelectMany(x => x.GetTypes());

                var dapperMappings = allModels
                    .Where(x => typeof(IMapped).IsAssignableFrom(x)
                            && !x.IsInterface && !x.IsAbstract && x.Assembly == currentAssembly)
                    .Select(x => Activator.CreateInstance(x) as IMapped);

                foreach (var model in dapperMappings)
                {
                    model.CreateMapping();
                }
            }

            public static void SetupRepositories(IServiceCollection services)
            {
                var assemblies = AppDomain.CurrentDomain.GetAssemblies();

                foreach (var repoInterface in
                    assemblies.SelectMany(x => x.GetTypes())
                    .Where(x => typeof(IScopedRepository).IsAssignableFrom(x)))
                {
                    foreach (var repo in
                        assemblies.SelectMany(x => x.GetTypes())
                        .Where(x => repoInterface.IsAssignableFrom(x) && !x.IsInterface && !x.IsAbstract))
                    {
                        services.AddScoped(repoInterface, repo);
                    }
                }
            }
        }


        /// <summary>
        ///  This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// </summary>
        /// <param name="app">Application builder interface</param>
        /// <param name="env">Host environment.</param>
        public static void Configure(IApplicationBuilder app, IHostEnvironment env)
        {
            //add health server
            app.UseHealthChecks(new Microsoft.AspNetCore.Http.PathString("/health"));

            //Middleware correlationID 
            app.UseLogXCorrelationId();
            app.UseLogXRequestResponde();

            if (env.IsDevelopment())
            {
                // When the app runs in the Development environment:
                //   Use the Developer Exception Page to report app runtime errors.
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // When the app doesn't run in the Development environment:
                //   Enable the Exception Handler Middleware to catch exceptions
                //     thrown in the following middlewares.
                app.UseExceptionHandler("/Error");
                //   Use the HTTP Strict Transport Security Protocol (HSTS)
                //     Middleware.
                app.UseHsts();
            }

            // Force Authentication
            app.UseAuthentication();

            // Return static files and end the pipeline.
            app.UseStaticFiles();

            // Use Cookie Policy Middleware to conform to EU General Data 
            // Protection Regulation (GDPR) regulations.
            app.UseCookiePolicy();

            SwaggerConfiguration.Build(app);

            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}

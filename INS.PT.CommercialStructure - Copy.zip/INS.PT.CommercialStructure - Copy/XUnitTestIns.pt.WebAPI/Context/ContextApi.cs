﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Net.Http;

namespace XUnitTestIns.pt.WebAPI.Fixture
{
    /// <summary>
    /// 
    /// </summary>
    class ContextApi
    {
        /// <summary>
        /// 
        /// </summary>
        public HttpClient Client { get; set; }
        public TestServer _server;
 
        public IConfigurationRoot Configuration { get; private set; }
        public IDbConnection connection;

        public ContextApi()
        {
            InitializeConfigurations();
            SetupClient();
        }

        /// <summary>
        /// 
        /// </summary>
        private void InitializeConfigurations()
        {
            Configuration = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", optional: true)
                .AddUserSecrets("e3dfcccf-0cb3-423a-b302-e3e92e95c128")
                .AddEnvironmentVariables()
                .Build();
        }

        /// <summary>
        /// 
        /// </summary>
        private void SetupClient()
        {
            _server = new TestServer(new WebHostBuilder()
                .ConfigureAppConfiguration((appConfiguration) =>
                {
                    appConfiguration.AddConfiguration(Configuration);
                }).UseStartup<Startup>());

            Client = _server.CreateClient();
            Client.BaseAddress = _server.BaseAddress;
            connection = new Dbconnectioncs(Configuration).Connection;
        }
    }
}

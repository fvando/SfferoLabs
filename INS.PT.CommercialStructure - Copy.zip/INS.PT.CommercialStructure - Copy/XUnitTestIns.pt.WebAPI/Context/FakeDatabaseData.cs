﻿using INS.PT.WebAPI.Models;
using System.Collections.Generic;

namespace XUnitTestIns.pt.WebAPI.Context
{
    internal static class FakeDatabaseData
    {
        public static List<TreeOutputData> FakeData()
        {
            return new List<TreeOutputData>
                    {
                        new TreeOutputData
                        {
                            TIPO_ESTRUTURA = "AGENTE",
                            Companhia = "Outra",
                            Nivel1 = "060",
                            Nivel2 = "060",
                            Nivel3 = "060150",
                            Nivel4 = "6015001",
                            Cdagente = "45293",
                            Dsnombre = null,
                            Dsdomicilio = null,
                            Cdpostal = null,
                            Nmdomicilio = null,
                            Estado = "Inactivo",
                            DATA_INACTIVO = null,
                            ID_IDENTIDADE = "10437680",
                            ID_IDENT_REPRESENTANTE = null,
                            TES_DEF = "455",
                            ZONA_ACTUACAO = "50",
                            AREA_INSPECCAO = "1 - ANGARIADORES",
                            INSP_AC_ESPECIAL = null,
                            NUMERO_ISP = null,
                            PRODUTOS_ISP = "Não Vida",
                            DATA_PROCESSO = null,
                            ID_PROCESSO = 373
                        }
                    };
        }
    }
}

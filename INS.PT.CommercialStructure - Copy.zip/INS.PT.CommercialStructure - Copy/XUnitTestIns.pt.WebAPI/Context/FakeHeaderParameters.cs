﻿using INS.PT.WebAPI.Models;
using Microsoft.AspNetCore.Http;
using System;

namespace XUnitTestINS.PT.WebAPI.Context
{
    internal class FakeHeaderParameters : IHttpContextAccessor
    {
        private static readonly HeaderParameters defaultHeaderParameters = new HeaderParameters()
        {
            IdCompany = "AGEAS",
            IdSource = "TECH"
        };

        internal HeaderParameters headerParameters { get; set; }

        public FakeHeaderParameters(HeaderParameters headerParameters)
        {
            this.headerParameters = headerParameters ?? defaultHeaderParameters;
        }

        public HttpContext HttpContext
        {
            get
            {
                var context = new DefaultHttpContext();

                context.Request.Headers[nameof(headerParameters.IdCompany)] = headerParameters.IdCompany;
                context.Request.Headers[nameof(headerParameters.IdSource)] = headerParameters.IdSource;

                return context;
            }

            set => throw new NotImplementedException();
        }
    }
}
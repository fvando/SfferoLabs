﻿using INS.PT.WebAPI.Repository;
using INS.PT.WebAPI;
using INS.PT.WebAPI.Models;
using Moq;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.Context;
using XUnitTestINS.PT.WebAPI.Context;
using INS.PT.WebAPI.Models.Database;

namespace XUnitTestIns.pt.WebAPI.UnitTest
{
    public class CommomRepositoryTests
    {
        private readonly Mock<IDbconnectioncs> _mockConnections;
        private readonly Mock<IDbConnection> _mockConnection;

        public CommomRepositoryTests()
        {
            _mockConnection = new Mock<IDbConnection>();
            _mockConnection.Setup(x => x.ConnectionString).Returns("test connecting string");
            _mockConnections = new Mock<IDbconnectioncs>();
            _mockConnections.Setup(x => x.Connection).Returns(_mockConnection.Object);
        }

        private OracleDynamicParameters BuildTestParameters_Valid()
        {
            var result = new OracleDynamicParameters();
            result.Add(nameof(ObjectErrors.p_erro), OracleDbType.Varchar2, direction: ParameterDirection.Output, value: null, size: 1000);
            result.Add(nameof(ObjectErrors.p_dserro), OracleDbType.Varchar2, direction: ParameterDirection.Output, value: null, size: 1000);
            return result;
        }

        private OracleDynamicParameters BuildTestParameters_Invalid()
        {
            var result = new OracleDynamicParameters();
            result.Add(nameof(ObjectErrors.p_erro), OracleDbType.Varchar2, direction: ParameterDirection.Output, value: null, size: 1000);
            result.Add(nameof(ObjectErrors.p_dserro), OracleDbType.Varchar2, direction: ParameterDirection.Output, value: null, size: 1000);

            result.Parameters.First(p => p.ParameterName == nameof(ObjectErrors.p_erro)).Value =
                new Oracle.ManagedDataAccess.Types.OracleString("TestError");
            result.Parameters.First(p => p.ParameterName == nameof(ObjectErrors.p_dserro)).Value =
                new Oracle.ManagedDataAccess.Types.OracleString("TestErrorDescription");

            return result;
        }



        [Fact]
        public void CommomRepository_Submit_NoParameters()
        {
            // Arrange
            var repository = new CommomRepository(_mockConnections.Object);

            // Act
            var result = repository.Submit<CommercialStructure, TreeOutputData>(null, It.IsAny<string>(), It.IsAny<string>());


            // Assert
            Assert.Null(result);
        }

        [Fact]
        public void CommomRepository_Submit_Invalid()
        {
            // Arrange
            var repository = new CommomRepository(_mockConnections.Object);
            var parameters = BuildTestParameters_Invalid();

            // Act
            Assert.Throws<ProcessErrorException>(() => repository.Submit<CommercialStructure, TreeOutputData>(parameters, It.IsAny<string>(), It.IsAny<string>(),
                (cmd, param, conn) => FakeDatabaseData.FakeData()));
        }

        [Fact]
        public void CommomRepository_Submit_Valid()
        {
            // Arrange
            var repository = new CommomRepository(_mockConnections.Object);
            var parameters = BuildTestParameters_Valid();

            // Act
            var result = repository.Submit<CommercialStructure, TreeOutputData>(parameters, It.IsAny<string>(), It.IsAny<string>(),
                (cmd, param, conn) => FakeDatabaseData.FakeData());


            // Assert
            Assert.NotNull(result);
            Assert.NotNull(result.Data);
            Assert.True(result.Data.Any());
            Assert.Equal("Outra", result.Data.First().Companhia);
        }

        [Fact]
        public void CommomRepository_ReadDeltasAsync_Valid()
        {
            // Arrange
            var repository = new CommomRepository(_mockConnections.Object);
            var parameters = BuildTestParameters_Valid();
            var data = new Mock<IDataReader>();

            var values = new object[,]
                {
                    { 69,"INSPECTOR","Ageas","010","010","10113","1856","","","","","2","Activo","10/04/2018 00:00:00","","9857966","","","13","3 - AREA 3","","","","","21/08/2019 19:27:37" },
                    { 69,"BALCAO","Ageas","050","502","50196","","","JOSÉ ROLÃO","Ed Ageas, Av do Mediterraneo 1-P Nações","1990-156 LISBOA","","Activo","03/03/2007 00:00:00","","","","965","96","","","","","","21/08/2019 19:27:37" },
                    { 69,"AGENTE","Ageas","020","203","65601","2019499","89553","","","","1","Activo","02/04/2098 00:00:00","","17630","","855",""," - ","","9053846","2","Não Vida","21/08/2019 19:27:37" },
                    { 69,"REDE","Ageas","086","","","","","PLATAFORMA","RUA GONÇALO SAMPAIO 39 - AP 4076","4002-001 PORTO","","Activo","20/11/2017 00:00:00","","","12498177","","","","","","","","21/08/2019 19:27:37" },
                    { 69,"ZONA","Ageas","086","558","","","","PLATAFORMA","RUA GONÇALO SAMPAIO 39 - AP 4076","4002-001 PORTO","","Activo","25/01/2017 00:00:00","","","","","","","","","","","21/08/2019 19:27:37"}
                };

            data.SetupDataReader(new List<string> {
                    "ID_PROCESSO","TIPO_ESTRUTURA","COMPANHIA","NIVEL1","NIVEL2","NIVEL3","NIVEL4","CDAGENTE","DSNOMBRE","DSDOMICILIO","CDPOSTAL"
                    ,"NMDOMICILIO","ESTADO","DATA_ACTIVO","DATA_INACTIVO","ID_IDENTIDADE","ID_IDENT_REPRESENTANTE","TES_DEF","ZONA_ACTUACAO","AREA_INSPECCAO"
                    ,"INSP_AC_ESPECIAL","NUMERO_ISP","COD_PRODUTOS_ISP","PRODUTOS_ISP","DATA_PROCESSO"
                }, values);


            // Act
            var result = repository.ReadDeltasAsync(parameters, It.IsAny<string>(), It.IsAny<string>(), (conn, cmd, param) => 
                Task.Run(() => data.Object));


            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void CommomRepository_ReadClassificationDeltasAsync_Valid()
        {
            // Arrange
            var repository = new CommomRepository(_mockConnections.Object);
            var headerParameters = new HeaderParameters
            {
                IdCompany = "AGEAS",
                IdSource = "TECN",
            };


            // Act
            var result = repository.ReadClassificationAsync(headerParameters, "testAgent", DateTime.Now, ClassificationSearchType.Agent,
                (connection, parameters) => new List<ClassificationOutput>
                {
                    new ClassificationOutput
                    {
                        IdAgent = "11001",
                        Code = "AG",
                        Description = "Rede Agentes",
                        Order = 2,
                        Tipology = "Outros",
                        StartDate = DateTime.Now,
                        EndDate = null,
                        Rule = "REGRA_OUT - 22 - Quando e"
                    },
                    new ClassificationOutput
                    {
                        IdAgent = "11001",
                        Code = "11",
                        Description = "med",
                        Order = 1,
                        Tipology = "tipo",
                        StartDate = DateTime.Now,
                        EndDate = null,
                        Rule = null
                    }
                });


            // Assert
            Assert.NotNull(result);
            var resultList = Assert.IsAssignableFrom<IEnumerable<AgentClassification>>(result.Result);
            Assert.NotNull(resultList);
            Assert.True(resultList.Any());
        }

        [Fact]
        public void CommomRepository_ReadClassificationDeltasAsync_ErrorFromBD()
        {
            // Arrange
            var repository = new CommomRepository(_mockConnections.Object);
            var headerParameters = new HeaderParameters
            {
                IdCompany = "AGEAS",
                IdSource = "TECN",
            };


            // Act and Assert
            Assert.ThrowsAsync<ProcessErrorException>(() => repository.ReadClassificationAsync(headerParameters, "testAgent", DateTime.Now, 
                ClassificationSearchType.Agent, (connection, parameters) => FakeErrorFromBD(parameters)));
        }

        private IEnumerable<ClassificationOutput> FakeErrorFromBD(OracleDynamicParameters parameters)
        {
            // fill output parameters
            parameters.Parameters.First(p => p.ParameterName == "p_erro").Value =
                new Oracle.ManagedDataAccess.Types.OracleString("TestError");
            parameters.Parameters.First(p => p.ParameterName == "p_dserro").Value =
                new Oracle.ManagedDataAccess.Types.OracleString("TestErrorDescription");
            return new List<ClassificationOutput>();
        }

    }
}

﻿using INS.PT.WebAPI.Filters;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using Xunit;

namespace XUnitTestIns.pt.WebAPI.UnitTest
{
    public class HeaderParametersFilterTests
    {
        public class FakeMethod : MethodInfo
        {
            private readonly string myName;

            public FakeMethod(string memberName)
            {
                myName = memberName;
            }

            public override string Name => myName;


           public override ICustomAttributeProvider ReturnTypeCustomAttributes => throw new NotImplementedException();

            public override MethodAttributes Attributes => throw new NotImplementedException();

            public override RuntimeMethodHandle MethodHandle => throw new NotImplementedException();

            public override Type DeclaringType => throw new NotImplementedException();

            public override Type ReflectedType => throw new NotImplementedException();

            public override MethodInfo GetBaseDefinition()
            {
                throw new NotImplementedException();
            }

            public override object[] GetCustomAttributes(bool inherit)
            {
                throw new NotImplementedException();
            }

            public override object[] GetCustomAttributes(Type attributeType, bool inherit)
            {
                throw new NotImplementedException();
            }

            public override MethodImplAttributes GetMethodImplementationFlags()
            {
                throw new NotImplementedException();
            }

            public override ParameterInfo[] GetParameters()
            {
                throw new NotImplementedException();
            }

            public override object Invoke(object obj, BindingFlags invokeAttr, Binder binder, object[] parameters, CultureInfo culture)
            {
                throw new NotImplementedException();
            }

            public override bool IsDefined(Type attributeType, bool inherit)
            {
                throw new NotImplementedException();
            }
        }


        [Theory]
        [InlineData("newOperation")]
        [InlineData("AgentsSearch")]
        [InlineData("Classifications/ByProperty")]
        public void OperationFilter_Apply_CommercialStructure(string operationId)
        {
            // Arrange
            var testObject = new HeaderParametersFilter();
            var operation = new OpenApiOperation
            {
                OperationId = operationId,
                Parameters = new List<OpenApiParameter>()
            };

            // Act
            testObject.Apply(operation, null);

            // Assert
            Assert.Equal(0, operation.Parameters.Count);
        }

        [Theory]
        [InlineData("DeltasAsync")]
        [InlineData("ClassificationsAsync")]
        [InlineData("ClassificationsDeltaAsync")]
        [InlineData("ClassificationsDeltaForAgent")]
        [InlineData("ClassificationsDeltaForAgentV2")]
        [InlineData("InspectorsAsync")]
        [InlineData("BranchesAsync")]
        [InlineData("ZonesAsync")]
        [InlineData("NetworksAsync")]
        public void OperationFilter_Apply_OperationsWithHeaders(string operationId)
        {
            // Arrange
            var testObject = new HeaderParametersFilter();
            var operation = new OpenApiOperation
            {
                Parameters = new List<OpenApiParameter>()
            };
            var context = new OperationFilterContext(null, null, null, new FakeMethod(operationId));

            // Act
            testObject.Apply(operation, context);

            // Assert
            Assert.Equal(2, operation.Parameters.Count);
        }
    }
}

﻿using INS.PT.WebAPI.Repository;
using INS.PT.WebAPI;
using INS.PT.WebAPI.Models;
using Moq;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using XUnitTestINS.PT.WebAPI.Context;
using System;

namespace XUnitTest.INS.PT.WebAPI.UnitTest
{
    public class AgentsSearchRepositoryTests
    {
        private readonly Mock<IDbconnectioncs> _mockConnections;
        private readonly HeaderParameters headerParameters;



        public AgentsSearchRepositoryTests()
        {
            headerParameters = new HeaderParameters
            {
                IdCompany = "AGEAS",
                IdSource = "TECH"
            };

            var _mockConnection = new Mock<IDbConnection>();
            _mockConnection.Setup(x => x.ConnectionString).Returns("test connecting string");
            _mockConnections = new Mock<IDbconnectioncs>();
            _mockConnections.Setup(x => x.Connection).Returns(_mockConnection.Object);
        }


        private static IDataReader FakeStructureByClass(OracleDynamicParameters parameters, string errorCode)
        {
            // fill erroCode parameter
            parameters.Parameters.First(p => p.ParameterName == "P_ERRO").Value =
               new Oracle.ManagedDataAccess.Types.OracleString(errorCode);

            // prepare returned information
            var data = new Mock<IDataReader>();
            var values = new object[,]
                {
                    { 69,"INSPECTOR","Ageas","010","010","10113","1856","","","","","2","Activo","10/04/2018 00:00:00","","9857966","","","13","3 - AREA 3","","","","","21/08/2019 19:27:37" },
                    { 69,"BALCAO","Ageas","050","502","50196","","","JOSÉ ROLÃO","Ed Ageas, Av do Mediterraneo 1-P Nações","1990-156 LISBOA","","Activo","03/03/2007 00:00:00","","","","965","96","","","","","","21/08/2019 19:27:37" },
                    { 69,"AGENTE","Ageas","020","203","65601","2019499","89553","","","","1","Activo","02/04/2098 00:00:00","","17630","","855",""," - ","","9053846","2","Não Vida","21/08/2019 19:27:37" },
                    { 69,"REDE","Ageas","086","","","","","PLATAFORMA","RUA GONÇALO SAMPAIO 39 - AP 4076","4002-001 PORTO","","Activo","20/11/2017 00:00:00","","","12498177","","","","","","","","21/08/2019 19:27:37" },
                    { 69,"ZONA","Ageas","086","558","","","","PLATAFORMA","RUA GONÇALO SAMPAIO 39 - AP 4076","4002-001 PORTO","","Activo","25/01/2017 00:00:00","","","","","","","","","","","21/08/2019 19:27:37"}
                };

            data.SetupDataReader(new List<string> {
                    "ID_PROCESSO","TIPO_ESTRUTURA","COMPANHIA","NIVEL1","NIVEL2","NIVEL3","NIVEL4","CDAGENTE","DSNOMBRE","DSDOMICILIO","CDPOSTAL"
                    ,"NMDOMICILIO","ESTADO","DATA_ACTIVO","DATA_INACTIVO","ID_IDENTIDADE","ID_IDENT_REPRESENTANTE","TES_DEF","ZONA_ACTUACAO","AREA_INSPECCAO"
                    ,"INSP_AC_ESPECIAL","NUMERO_ISP","COD_PRODUTOS_ISP","PRODUTOS_ISP","DATA_PROCESSO"
                }, values);

            return data.Object;
        }

        private static IDataReader FakeAgentsByClass(OracleDynamicParameters parameters, string errorCode)
        {
            // fill erroCode parameter
            parameters.Parameters.First(p => p.ParameterName == "P_ERRO").Value =
               new Oracle.ManagedDataAccess.Types.OracleString(errorCode);

            // prepare returned information
            var data = new Mock<IDataReader>();
            var values = new object[,]
                {
                    { "12345", new DateTime(2020, 03, 16)},
                    { "54321", new DateTime(2020, 03, 16)},
                    { "cdoTest", new DateTime(2020, 03, 16)},
                    { "121243", new DateTime(2020, 03, 16)},
                    { "99999", new DateTime(2020, 03, 16)}
                };

            data.SetupDataReader(new List<string> {
                    "ID_PROCESSO","TIPO_ESTRUTURA"
                }, values);

            return data.Object;
        }

        private static IEnumerable<StreamlinedAgent> FakeAgentsFromEnergiser(OracleDynamicParameters parameters, string errorCode)
        {
            // fill erroCode parameter
            parameters.Parameters.First(p => p.ParameterName == "P_ERRO").Value =
               new Oracle.ManagedDataAccess.Types.OracleString(errorCode);

            return new List<StreamlinedAgent>
            {
                new StreamlinedAgent
                {
                    AgentCode = "12345"                    
                },
                new StreamlinedAgent
                {
                    AgentCode = "98765"                    
                }
            };
        }

        private static int FakeCommisionAgent(OracleDynamicParameters parameters, string errorCode)
        {
            // fill erroCode parameter
            parameters.Parameters.First(p => p.ParameterName == "P_ERRO").Value =
               new Oracle.ManagedDataAccess.Types.OracleString(errorCode);
            parameters.Parameters.First(p => p.ParameterName == "p_cdagente").Value =
               new Oracle.ManagedDataAccess.Types.OracleString("testReturnAgent");

            // records affected
            return 1;
        }


        #region GetAgentsStructureByClass
        [Fact]
        public async Task GetAgentsStructureByClassAsync_ValidResponse()
        {
            // Arrange
            var testObject = new AgentsSearchRepository(_mockConnections.Object,
                null,
                (conn, command, parameters) => Task.Run(() => FakeStructureByClass(parameters, "00")),
                null);

            // Act
            var result = await testObject.GetAgentsStructureByClassAsync("testClassCode");

            // Assert
            Assert.True(result.Any());
        }

        [Fact]
        public async Task GetAgentsStructureByClassAsync_InvalidClassCode()
        {
            // Arrange
            var testObject = new AgentsSearchRepository(_mockConnections.Object,
                null,
                (conn, command, parameters) => Task.Run(() => FakeStructureByClass(parameters, "00")),
                null);

            // Act
            var result = await testObject.GetAgentsStructureByClassAsync(null);

            // Assert
            Assert.False(result.Any());
        }

        [Fact]
        public void GetAgentsStructureByClassAsync_ErrorFromDB()
        {
            // Arrange
            var testObject = new AgentsSearchRepository(_mockConnections.Object,
                null,
                (conn, command, parameters) => Task.Run(() => FakeStructureByClass(parameters, "999")),
                null);

            // Act and Assert
            Assert.ThrowsAsync<ProcessErrorException>(() => testObject.GetAgentsStructureByClassAsync("testClassCode"));
        }
        #endregion

        #region GetAgentsByClass
        [Fact]
        public async Task GetAgentsByClassAsync_ValidResponse()
        {
            // Arrange
            var testObject = new AgentsSearchRepository(_mockConnections.Object,
                null,
                (conn, command, parameters) => Task.Run(() => FakeAgentsByClass(parameters, "00")),
                null);

            // Act
            var result = await testObject.GetAgentsByClassAsync("testClassCode");

            // Assert
            Assert.True(result.Any());
        }

        [Fact]
        public async Task GetAgentsByClassAsync_InvalidClassCode()
        {
            // Arrange
            var testObject = new AgentsSearchRepository(_mockConnections.Object,
                null,
                (conn, command, parameters) => Task.Run(() => FakeAgentsByClass(parameters, "00")),
                null);

            // Act
            var result = await testObject.GetAgentsByClassAsync(null);

            // Assert
            Assert.False(result.Any());
        }

        [Fact]
        public void GetAgentsByClassAsync_ErrorFromDB()
        {
            // Arrange
            var testObject = new AgentsSearchRepository(_mockConnections.Object,
                null,
                (conn, command, parameters) => Task.Run(() => FakeAgentsByClass(parameters, "999")),
                null);

            // Act and Assert
            Assert.ThrowsAsync<ProcessErrorException>(() => testObject.GetAgentsByClassAsync("testClassCode"));
        }
        #endregion

        #region GetAgentsFromEnergiser
        [Fact]
        public async Task GetAgentsFromEnergiserAsync_ValidResponse()
        {
            // Arrange
            var testObject = new AgentsSearchRepository(_mockConnections.Object,
                (conn, command, parameters) => Task.Run(() => FakeAgentsFromEnergiser(parameters, "00")),
                null,
                null);

            // Act
            var result = await testObject.GetAgentsFromEnergiserAsync("testClassCode");

            // Assert
            Assert.True(result.Any());
        }

        [Fact]
        public async Task GetAgentsFromEnergiserAsync_InvalidAgentCode()
        {
            // Arrange
            var testObject = new AgentsSearchRepository(_mockConnections.Object,
                (conn, command, parameters) => Task.Run(() => FakeAgentsFromEnergiser(parameters, "00")),
                null,
                null);

            // Act
            var result = await testObject.GetAgentsFromEnergiserAsync(null);

            // Assert
            Assert.False(result.Any());
        }

        [Fact]
        public void GetAgentsFromEnergiserAsync_ErrorFromDB()
        {
            // Arrange
            var testObject = new AgentsSearchRepository(_mockConnections.Object,
                (conn, command, parameters) => Task.Run(() => FakeAgentsFromEnergiser(parameters, "999")),
                null,
                null);

            // Act and Assert
            Assert.ThrowsAsync<ProcessErrorException>(() => testObject.GetAgentsFromEnergiserAsync("testClassCode"));
        }
        #endregion

        #region GetSharedCommissionAgent
        [Fact]
        public async Task GetSharedCommissionAgentAsync_ValidResponse()
        {
            // Arrange
            var testObject = new AgentsSearchRepository(_mockConnections.Object,
                null,
                null,
                (conn, command, parameters) => Task.Run(() => FakeCommisionAgent(parameters, "00"))
                );

            // Act
            var result = await testObject.GetSharedCommissionAgentAsync(headerParameters, "testZip", "testBranchCode");

            // Assert
            Assert.False(string.IsNullOrEmpty(result));
        }

        [Theory]
        [InlineData(false, null, "")]
        [InlineData(false, "", null)]
        [InlineData(false, null, null)]
        [InlineData(false, "", "")]
        [InlineData(true, null, "")]
        [InlineData(true, "", null)]
        [InlineData(true, null, null)]
        [InlineData(true, "", "")]
        public async Task GetSharedCommissionAgentAsync_InvalidParameters(bool withHeader, string zipCode, string branchCode)
        {
            // Arrange
            var testObject = new AgentsSearchRepository(_mockConnections.Object,
                null,
                null,
                (conn, command, parameters) => Task.Run(() => FakeCommisionAgent(parameters, "00"))
                );

            // Act
            var result = await testObject.GetSharedCommissionAgentAsync(withHeader ? headerParameters : null, zipCode, branchCode);

            // Assert
            Assert.True(string.IsNullOrEmpty(result));
        }

        [Fact]
        public void GetSharedCommissionAgentAsync_ErrorFromDB()
        {
            // Arrange
            var testObject = new AgentsSearchRepository(_mockConnections.Object,
                null,
                null,
                (conn, command, parameters) => Task.Run(() => FakeCommisionAgent(parameters, "999"))
                );

            // Act and Assert
            Assert.ThrowsAsync<ProcessErrorException>(() => testObject. GetSharedCommissionAgentAsync(headerParameters, "testZip", "testBranchCode"));
        }
        #endregion
    }
}

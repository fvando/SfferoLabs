﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI;
using INS.PT.WebAPI.Controllers;
using INS.PT.WebAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;
using XUnitTestIns.pt.WebAPI.Context;
using XUnitTestINS.PT.WebAPI.Context;
using v1 = INS.PT.WebAPI.Controllers.V1;
using v2 = INS.PT.WebAPI.Controllers.V2;
using INS.PT.WebAPI.Models.V2;

/// <summary>
/// XUnitTestIns.pt.WebAPI.UnitTest
/// </summary>
namespace XUnitTestIns.pt.WebAPI.UnitTest
{
    /// <summary>
    /// CommercialStructureControllerTest
    /// </summary>
    public class CommercialStructureControllerTest
    {
        public class TestCommercialStructureControllerV1 : v1.CommercialStructureController
        {
            public TestCommercialStructureControllerV1(HeaderParameters headerParameters, IHttpContextAccessor httpContext, ICommomRepository repository) : base(httpContext, repository)
            {
                TestHeaderParameters = headerParameters ?? throw new ArgumentNullException(nameof(headerParameters));
            }

            public HeaderParameters TestHeaderParameters { get; set; }

            protected override HeaderParameters ValidateHeader()
            {
                return TestHeaderParameters;
            }
        }
        public class TestCommercialStructureControllerV2 : v2.CommercialStructureController
        {
            public TestCommercialStructureControllerV2(HeaderParameters headerParameters, IHttpContextAccessor httpContext, ICommomRepository repository, ICommercialStructure commercialStructureRepository) 
                : base(httpContext, commercialStructureRepository)
            {
                TestHeaderParameters = headerParameters ?? throw new ArgumentNullException(nameof(headerParameters));
            }

            public HeaderParameters TestHeaderParameters { get; set; }

            protected override HeaderParameters ValidateHeader()
            {
                return TestHeaderParameters;
            }
        }

        private readonly Mock<ICommomRepository> _repository = new Mock<ICommomRepository>();
        private readonly Mock<IHttpContextAccessor> _httpContext = new Mock<IHttpContextAccessor>();
        private readonly Mock<ICommercialStructure> _commercialStructureRepository = new Mock<ICommercialStructure>();

        [Fact]
        public void CommercialStructure_Deltas_Valid()
        {
            // Arrange
            var controller = new TestCommercialStructureControllerV1(
                new HeaderParameters
                {
                    IdCompany = "AGEAS",
                    IdSource = "TECH"
                },
                _httpContext.Object, _repository.Object);
            var output = new StructureDeltas();

            output.AgentDeltas.Add(new AgentDelta
            {
                Code = "45293",
                Name = null,
                Status = "Inactivo",
                StatusInitialDate = DateTime.Now,
                StatusEndDate = null,
                IsDummy = null,
                Id = "10437680",
                WorkArea = null,
                AgentWorkArea = "1 - ANGARIADORES",
                AsfNumber = null,
                AsfProductCode = null,
                AsfProductCodeDescription = "Não Vida",
                IdAddress = "373"
            });

            _repository.Setup(x => x.ReadDeltasAsync(It.IsAny<OracleDynamicParameters>()
                , "NAV.PKG_AGE_WEBSERVICES", "ESTRUTURA_COMERCIAL")).Returns(
                System.Threading.Tasks.Task.Run(() => output));

            // Act
            var result = controller.DeltasAsync(null, null);

            // Assert
            Assert.NotNull(result);
            var resultObject = result.Result.Result as OkObjectResult;
            Assert.NotNull(resultObject);
            var resultList = resultObject.Value as StructureDeltas;
            Assert.True(resultList.AgentDeltas.Any());
            Assert.Equal("45293", resultList.AgentDeltas.First().Code);
        }

        [Fact]
        public void V2_CommercialStructure_Deltas_Valid()
        {
            // Arrange
            var headerParameters = new HeaderParameters
            {
                IdCompany = "AGEAS",
                IdSource = "TECH"
            };
            var controller = new TestCommercialStructureControllerV2(
                headerParameters,
                _httpContext.Object, _repository.Object, _commercialStructureRepository.Object);
            var output = new INS.PT.WebAPI.Models.V2.Deltas.StructureDeltas();

            output.AgentDeltas.Add(new INS.PT.WebAPI.Models.V2.Deltas.AgentDelta
            {
                Code = "45293",
                Name = null,
                Status = "Inactivo",
                StatusInitialDate = DateTime.Now,
                StatusEndDate = null,
                IsDummy = null,
                Id = "10437680",
                WorkArea = null,
                AgentWorkArea = "1 - ANGARIADORES",
                AsfNumber = null,
                AsfProductCode = null,
                AsfProductCodeDescription = "Não Vida",
                IdAddress = "373"
            });

            _commercialStructureRepository.Setup(x => x.ReadStructureDeltasSync(headerParameters, It.IsAny<DateTime?>(), It.IsAny<bool?>()))
                .Returns(System.Threading.Tasks.Task.Run(() => output));

            // Act
            var result = controller.DeltasAsync(null, null);

            // Assert
            Assert.NotNull(result);
            var resultObject = result.Result.Result as OkObjectResult;
            Assert.NotNull(resultObject);
            var resultList = resultObject.Value as INS.PT.WebAPI.Models.V2.Deltas.StructureDeltas;
            Assert.True(resultList.AgentDeltas.Any());
            Assert.Equal("45293", resultList.AgentDeltas.First().Code);
        }

        [Fact]
        public void CommercialStructure_Deltas_NoData()
        {
            // Arrange
            var controller = new TestCommercialStructureControllerV1(
                new HeaderParameters
                {
                    IdCompany = "AGEAS",
                    IdSource = "TECH"
                },
                _httpContext.Object, _repository.Object);
            var output = new StructureDeltas();

            _repository.Setup(x => x.ReadDeltasAsync(It.IsAny<OracleDynamicParameters>()
                , "NAV.PKG_AGE_WEBSERVICES", "ESTRUTURA_COMERCIAL")).Returns(
                System.Threading.Tasks.Task.Run(() => output));

            // Act
            var result = controller.DeltasAsync(null, null);

            // Assert
            Assert.NotNull(result);
            var resultObject = result.Result.Result as NotFoundObjectResult;
            Assert.NotNull(resultObject);
            var resultList = resultObject.Value as StructureDeltas;
            Assert.False(resultList.AgentDeltas.Any());
        }

        [Fact]
        public void CommercialStructure_Deltas_Invalid()
        {
            // Arrange
            var controller = new v1.CommercialStructureController(new FakeHeaderParameters( 
                new HeaderParameters
                {
                    IdCompany = "AGEAS_1234567890qwertyuiop",
                    IdSource = "TECH_1234567890qwertyuiop"
                }), _repository.Object);

            // Act
            var result = controller.DeltasAsync(null, null);

            // Assert
            Assert.NotNull(result);
            var resultObject = result.Result.Result as BadRequestObjectResult;
            Assert.NotNull(resultObject);
            Assert.Equal(StatusCodes.Status400BadRequest, resultObject.StatusCode);
        }

        [Fact]
        public void V2_CommercialStructure_Deltas_Invalid()
        {
            // Arrange
            var controller = new v2.CommercialStructureController(new FakeHeaderParameters( 
                new HeaderParameters
                {
                    IdCompany = "AGEAS_1234567890qwertyuiop",
                    IdSource = "TECH_1234567890qwertyuiop"
                }), _commercialStructureRepository.Object);

            // Act
            var result = controller.DeltasAsync(null, null);

            // Assert
            Assert.NotNull(result);
            var resultObject = result.Result.Result as BadRequestObjectResult;
            Assert.NotNull(resultObject);
            Assert.Equal(StatusCodes.Status400BadRequest, resultObject.StatusCode);
        }


        [Fact]
        public void CommercialStructure_Structure_Valid()
        {
            // Arrange
            var output = new CommercialStructure
            {
                Data = FakeDatabaseData.FakeData()
            };
            var controller = new TestCommercialStructureControllerV1(
                new HeaderParameters
                {
                    IdCompany = "AGEAS",
                    IdSource = "TECH"
                },
                _httpContext.Object, _repository.Object);


            _repository.Setup(x => x.Submit<CommercialStructure, TreeOutputData>(It.IsAny<OracleDynamicParameters>()
                , "NAV.PKG_AGE_WEBSERVICES", "Get_Agente_EC")).Returns(output);

            // Act
            var result = controller.Structure(It.IsAny<ReferenceTypePerson>(), It.IsAny<string>());

            // Assert
            Assert.NotNull(result);
            var resultObject = result.Result.Result as OkObjectResult;
            Assert.NotNull(resultObject);
            var resultList = resultObject.Value as IEnumerable<Company>;
            Assert.True(resultList.Any());
            Assert.Equal("Outra", resultList.First().CompanyName);
        }

        [Fact]
        public void CommercialStructure_StructureV2_Valid()
        {
            // Arrange
            var controller = new TestCommercialStructureControllerV2(
                new HeaderParameters
                {
                    IdCompany = "AGEAS",
                    IdSource = "TECH"
                },
                _httpContext.Object, _repository.Object, _commercialStructureRepository.Object);


            _commercialStructureRepository.Setup(x => x.ReadStructureAsync(
                It.IsAny<CommercialStructureLevels>(), "OkTest", It.IsAny<bool>()))
                .ReturnsAsync(new List<Group> { new Group { Code = "testCode", Name = "testName" } });

            // Act
            var result = controller.Structure(It.IsAny<CommercialStructureLevels>(), "OkTest");

            // Assert
            Assert.NotNull(result);
            var resultObject = result.Result.Result as OkObjectResult;
            Assert.NotNull(resultObject);
            var resultList = resultObject.Value as IEnumerable<Group>;
            Assert.True(resultList.Any());
            Assert.Equal("testName", resultList.First().Name);
        }


        [Fact]
        public async System.Threading.Tasks.Task CommercialStructure_UpsertElementInformation_ValidAsync()
        {
            // Arrange
            var controller = new TestCommercialStructureControllerV2(
                new HeaderParameters
                {
                    IdCompany = "AGEAS",
                    IdSource = "TECH"
                },
                _httpContext.Object, _repository.Object, _commercialStructureRepository.Object);
            var parameters = new LevelElement
            {
                LevelType = UpdatableCommercialLevels.Management,
                IsNewElement = true,
                Code = "tstCode",
                Description = "test description",
                ParentCode = "testOnly",
                StartDate = DateTime.Now
            };


            _commercialStructureRepository.Setup(x => x.UpsertElementInformationAsync(parameters))
                .ReturnsAsync(true);

            // Act
            var result = await controller.UpsertAsync(parameters);

            // Assert
            Assert.NotNull(result);
            Assert.IsType<OkObjectResult>(result);
        }


        [Fact]
        public async System.Threading.Tasks.Task CommercialStructure_UpsertElementInformation_NoChangesAsync()
        {
            // Arrange
            var controller = new TestCommercialStructureControllerV2(
                new HeaderParameters
                {
                    IdCompany = "AGEAS",
                    IdSource = "TECH"
                },
                _httpContext.Object, _repository.Object, _commercialStructureRepository.Object);
            var parameters = new LevelElement
            {
                LevelType = UpdatableCommercialLevels.Management,
                IsNewElement = true,
                Code = null
            };


            _commercialStructureRepository.Setup(x => x.UpsertElementInformationAsync(It.IsAny<LevelElement>()))
                .ReturnsAsync(false);

            // Act
            var result = await controller.UpsertAsync(parameters);

            // Assert
            Assert.NotNull(result);
            var notFound = Assert.IsType<NotFoundObjectResult>(result);
            var val = Assert.IsType<bool>(notFound.Value);
            Assert.False(val);
        }


        [Fact]
        public async System.Threading.Tasks.Task CommercialStructure_UpsertElementInformation_ErrorAsync()
        {
            // Arrange
            var controller = new TestCommercialStructureControllerV2(
                new HeaderParameters
                {
                    IdCompany = "AGEAS",
                    IdSource = "TECH"
                },
                _httpContext.Object, _repository.Object, _commercialStructureRepository.Object);
            var parameters = new LevelElement
            {
                LevelType = UpdatableCommercialLevels.Management,
                IsNewElement = true,
                Code = null
            };


            _commercialStructureRepository.Setup(x => x.UpsertElementInformationAsync(It.IsAny<LevelElement>()))
                .ThrowsAsync(new ProcessErrorException("test exception"));


            // Act
            var result = await controller.UpsertAsync(parameters);

            // Assert
            Assert.NotNull(result);
            var notFound = Assert.IsType<NotFoundObjectResult>(result);
            var val = Assert.IsType<ProcessErrorException>(notFound.Value);
            Assert.NotNull(val);
        }
    }
}

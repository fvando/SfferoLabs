﻿using INS.PT.WebAPI.Models;
using Moq;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Controllers;
using Microsoft.AspNetCore.Mvc;
using XUnitTestINS.PT.WebAPI.Context;
using v1 = INS.PT.WebAPI.Controllers.V1;
using v2 = INS.PT.WebAPI.Controllers.V2;

namespace XUnitTest.INS.PT.WebAPI.UnitTest
{
    public class ClassficationsControllerTests
    {
        private readonly Mock<IClassifications> _mockRepository;

        public ClassficationsControllerTests()
        {
            _mockRepository = new Mock<IClassifications>();

            _mockRepository.Setup(x => x.ReadClassificationsByAttributeAsync("validTest"))
                .ReturnsAsync(new List<Classification>
            {
                new Classification
                {
                    Code = "00",
                    Description = "test result 00",
                },
                new Classification
                {
                    Code = "01",
                    Description = "test result 01",
                }
            });

            _mockRepository.Setup(x => x.ReadClassificationsByAttributeAsync("empty"))
                .ReturnsAsync(Enumerable.Empty<Classification>());

            _mockRepository.Setup(x => x.ReadClassificationsByAttributeAsync("errorDB"))
                .Throws(new ProcessErrorException("test error"));
        }


        [Fact]
        public async Task ByAttribute_ErrorFromDBAsync()
        {
            // Arrange
            var testObject = new v1.ClassficationsController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.ByAttributeAsync("errorDB");


            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<Classification>>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }
        [Fact]
        public async Task V2_ByAttribute_ErrorFromDBAsync()
        {
            // Arrange
            var testObject = new v2.ClassficationsController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.ByAttributeAsync("errorDB");


            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<Classification>>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }

        [Fact]
        public async Task ByAttribute_No_Results()
        {
            // Arrange
            var testObject = new v1.ClassficationsController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.ByAttributeAsync("empty");

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<Classification>>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }
        [Fact]
        public async Task V2_ByAttribute_No_Results()
        {
            // Arrange
            var testObject = new v2.ClassficationsController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.ByAttributeAsync("empty");

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<Classification>>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }

        [Fact]
        public async Task ByAttribute_ValidResponse()
        {
            // Arrange
            var testObject = new v1.ClassficationsController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.ByAttributeAsync("validTest");

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<Classification>>>(result);
            var okObject = Assert.IsType<OkObjectResult>(taskResult.Result);
            var responseList = Assert.IsAssignableFrom<IEnumerable<Classification>>(okObject.Value);
            Assert.True(responseList.Any());
        }
        [Fact]
        public async Task V2_ByAttribute_ValidResponse()
        {
            // Arrange
            var testObject = new v2.ClassficationsController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.ByAttributeAsync("validTest");

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<Classification>>>(result);
            var okObject = Assert.IsType<OkObjectResult>(taskResult.Result);
            var responseList = Assert.IsAssignableFrom<IEnumerable<Classification>>(okObject.Value);
            Assert.True(responseList.Any());
        }
    }
}

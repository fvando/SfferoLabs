﻿using INS.PT.WebAPI.Models;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Xunit;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class HeaderParametersTests
    {
        [Fact]
        public void Validate_MoreThanMaxLenght()
        {
            // Arrange
            var objectToTest = new HeaderParameters()
                {
                    IdCompany = "TESTE_TESTE_TESTE_TESTE",
                    IdSource = "AGEAS_AGEAS_AGEAS_AGEAS",
                };
            var validationContext = new ValidationContext(objectToTest);
            var validationResults = new List<ValidationResult>();

            // Act
            var isValid = Validator.TryValidateObject(objectToTest, validationContext, validationResults, true);

            // Assert
            Assert.False(isValid);
        }

        [Fact]
        public void Validate_ValidObject()
        {
            // Arrange
            var objectToTest = new HeaderParameters()
            {
                IdCompany = "AGEAS",
                IdSource = "TECH"
            };
            var validationContext = new ValidationContext(objectToTest);
            var validationResults = new List<ValidationResult>();

            // Act
            var isValid = Validator.TryValidateObject(objectToTest, validationContext, validationResults, true);

            // Assert
            Assert.True(isValid);
        }
    }
}

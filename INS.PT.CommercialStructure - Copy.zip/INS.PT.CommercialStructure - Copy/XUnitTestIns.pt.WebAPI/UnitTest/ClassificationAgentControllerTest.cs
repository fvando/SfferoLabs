﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using Moq;
using System.Collections.Generic;
using Xunit;
using Microsoft.AspNetCore.Http;
using System.Linq;
using XUnitTestINS.PT.WebAPI.Context;
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using INS.PT.WebAPI;
using v1 = INS.PT.WebAPI.Controllers.V1;
using v2 = INS.PT.WebAPI.Controllers.V2;

/// <summary>
/// XUnitTestIns.pt.WebAPI.UnitTest
/// </summary>
namespace XUnitTestIns.pt.WebAPI.UnitTest
{
    //Get_Inspector_Agents

    /// <summary>
    /// InspectAgentAgentControllerTest
    /// </summary>
    public class ClassificationAgentControllerTest
    {
        private readonly Mock<IHttpContextAccessor> _httpContext;
        private readonly Mock<ICommomRepository> _mockRepository;

        public ClassificationAgentControllerTest()
        {
            _httpContext = new Mock<IHttpContextAccessor>();
            _mockRepository = new Mock<ICommomRepository>();
            _mockRepository.Setup(x => x.ReadClassificationAsync(
                It.IsAny<HeaderParameters>(), "testAgent", ClassificationSearchType.Agent)).Returns(Task.Run<AgentClassification>(() =>
                        new AgentClassification
                        {
                            AgentCode = "testAgent",
                            AgentType = new AgentClassificationType
                            {
                                AgentTypeCode = "11",
                                AgentTypeDescription = "",
                                StartDate = DateTime.Now
                            },
                            Classifications = new List<Classification>
                            {
                                new Classification
                                {
                                        Code= "AG",
                                        Description = "redes",
                                        Tipology = "outros",
                                        StartDate = DateTime.Now,
                                        Rule = "regra dummy"
                                }
                            }
                        }
                   ));

            _mockRepository.Setup(x => x.ReadClassificationAsync(
                It.IsAny<HeaderParameters>(), "failAgent", ClassificationSearchType.Agent)).Throws<ProcessErrorException>();


            _mockRepository.Setup(x => x.Submit<InspectorAgents, Agent>(It.IsAny<OracleDynamicParameters>(),
                "NAV.PKG_AGE_WEBSERVICES", "Get_Inspector_Agents")).Returns(new InspectorAgents
                {
                    Error = null,
                    Data = new List<Agent>
                    {
                        new Agent
                        {
                            Code = "",
                            Name = ""
                        }
                    }
                });


            _mockRepository.Setup(x => x.Submit<BranchInspectors, Inspector>(It.IsAny<OracleDynamicParameters>(),
                "NAV.PKG_AGE_WEBSERVICES", "Get_Balcao_Inspectors")).Returns(new BranchInspectors
                {
                    Error = null,
                    Data = new List<Inspector>
                    {
                        new Inspector
                        {
                            Code = "",
                            Name = ""
                        }
                    }
                });


            _mockRepository.Setup(x => x.Submit<ZoneBranches, Branch>(It.IsAny<OracleDynamicParameters>(),
                "NAV.PKG_AGE_WEBSERVICES", "Get_Zona_Balcoes")).Returns(new ZoneBranches
                {
                    Error = null,
                    Data = new List<Branch>
                    {
                        new Branch
                        {
                            Code = "",
                            Name = ""
                        }
                    }
                });

            _mockRepository.Setup(x => x.Submit<NetworkZones, Zone>(It.IsAny<OracleDynamicParameters>(),
                "NAV.PKG_AGE_WEBSERVICES", "Get_Rede_Zonas")).Returns(new NetworkZones
                {
                    Error = null,
                    Data = new List<Zone>
                    {
                        new Zone
                        {
                            Code = "",
                            Name = ""
                        }
                    }
                });

        }

        [Fact]
        public void Classifications_Get_Valid()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v1.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);

            // Act
            var taskResult = testObject.ClassificationsAsync("testAgent", null);

            // Assert
            Assert.NotNull(taskResult);
            var resultTask = Assert.IsType<Task<ActionResult<AgentClassification>>>(taskResult);
            Assert.NotNull(resultTask);
            var resultObj = Assert.IsType<ActionResult<AgentClassification>>(resultTask.Result);
            Assert.NotNull(resultObj);
            var actionResult = Assert.IsType<OkObjectResult>(resultObj.Result);
            Assert.NotNull(actionResult);
            var resultList = Assert.IsAssignableFrom<AgentClassification>(actionResult.Value);
            Assert.NotNull(resultList);
        }
        [Fact]
        public void V2_Classifications_Get_Valid()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v2.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);

            // Act
            var taskResult = testObject.ClassificationsAsync("testAgent", null);

            // Assert
            Assert.NotNull(taskResult);
            var resultTask = Assert.IsType<Task<ActionResult<AgentClassification>>>(taskResult);
            Assert.NotNull(resultTask);
            var resultObj = Assert.IsType<ActionResult<AgentClassification>>(resultTask.Result);
            Assert.NotNull(resultObj);
            var actionResult = Assert.IsType<OkObjectResult>(resultObj.Result);
            Assert.NotNull(actionResult);
            var resultList = Assert.IsAssignableFrom<AgentClassification>(actionResult.Value);
            Assert.NotNull(resultList);
        }

        [Fact]
        public void Classifications_Get_ErrorInDatabase()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v1.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);

            // Act and Assert
            Assert.ThrowsAsync<ProcessErrorException>(() => testObject.ClassificationsAsync("failAgent", null));
        }
        [Fact]
        public void V2_Classifications_Get_ErrorInDatabase()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v2.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);

            // Act and Assert
            Assert.ThrowsAsync<ProcessErrorException>(() => testObject.ClassificationsAsync("failAgent", null));
        }

        [Fact]
        public void Classifications_Get_NoHeaders()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(new HeaderParameters
            {
                IdCompany = "",
                IdSource = "",
            });
            var testObject = new v1.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);

            // Act and Assert
            Assert.ThrowsAsync<ProcessErrorException>(() => testObject.ClassificationsAsync("failAgent", null));
        }
        [Fact]
        public void V2_Classifications_Get_NoHeaders()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(new HeaderParameters
            {
                IdCompany = "",
                IdSource = "",
            });
            var testObject = new v2.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);

            // Act and Assert
            Assert.ThrowsAsync<ProcessErrorException>(() => testObject.ClassificationsAsync("failAgent", null));
        }

        [Fact]
        public void Classifications_Networks_NoHeaders()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(new HeaderParameters
            {
                IdCompany = "",
                IdSource = "",
            });
            var testObject = new v1.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);

            // Act and Assert
            Assert.ThrowsAsync<AggregateException>(() => testObject.NetworksAsync("failAgent"));
        }
        [Fact]
        public void V2_Classifications_Networks_NoHeaders()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(new HeaderParameters
            {
                IdCompany = "",
                IdSource = "",
            });
            var testObject = new v2.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);

            // Act and Assert
            Assert.ThrowsAsync<AggregateException>(() => testObject.NetworksAsync("failAgent"));
        }

        [Fact]
        public async Task Classifications_Networks_NoResultsAsync()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v1.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);
            _mockRepository.Reset();

            // Act
            var taskResult = await testObject.NetworksAsync("testAgent");

            // Assert
            Assert.NotNull(taskResult);
            var resultObj = Assert.IsType<ActionResult<NetworkZones>>(taskResult);
            Assert.NotNull(resultObj);
            var actionResult = Assert.IsType<NotFoundObjectResult>(resultObj.Result);
            Assert.NotNull(actionResult);
            Assert.Null(actionResult.Value);
        }
        [Fact]
        public async Task V2_Classifications_Networks_NoResultsAsync()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v2.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);
            _mockRepository.Reset();

            // Act
            var taskResult = await testObject.NetworksAsync("testAgent");

            // Assert
            Assert.NotNull(taskResult);
            var resultObj = Assert.IsType<ActionResult<NetworkZones>>(taskResult);
            Assert.NotNull(resultObj);
            var actionResult = Assert.IsType<NotFoundObjectResult>(resultObj.Result);
            Assert.NotNull(actionResult);
            Assert.Null(actionResult.Value);
        }

        [Fact]
        public async Task Classifications_Inspectors_ValidAsync()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v1.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);

            // Act
            var taskResult = await testObject.InspectorsAsync("testInspector");

            // Assert
            Assert.NotNull(taskResult);
            var resultObj = Assert.IsType<ActionResult<InspectorAgents>>(taskResult);
            Assert.NotNull(resultObj);
            var actionResult = Assert.IsType<OkObjectResult>(resultObj.Result);
            Assert.NotNull(actionResult);
            var resultList = Assert.IsAssignableFrom<InspectorAgents>(actionResult.Value);
            Assert.NotNull(resultList);
            Assert.True(resultList.Data.Any());
        }
        [Fact]
        public async Task V2_Classifications_Inspectors_ValidAsync()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v2.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);

            // Act
            var taskResult = await testObject.InspectorsAsync("testInspector");

            // Assert
            Assert.NotNull(taskResult);
            var resultObj = Assert.IsType<ActionResult<InspectorAgents>>(taskResult);
            Assert.NotNull(resultObj);
            var actionResult = Assert.IsType<OkObjectResult>(resultObj.Result);
            Assert.NotNull(actionResult);
            var resultList = Assert.IsAssignableFrom<InspectorAgents>(actionResult.Value);
            Assert.NotNull(resultList);
            Assert.True(resultList.Data.Any());
        }

        [Fact]
        public async Task Classifications_Branches_ValidAsync()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v1.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);

            // Act
            var taskResult = await testObject.BranchesAsync("testBranch");

            // Assert
            Assert.NotNull(taskResult);
            var resultObj = Assert.IsType<ActionResult<BranchInspectors>>(taskResult);
            Assert.NotNull(resultObj);
            var actionResult = Assert.IsType<OkObjectResult>(resultObj.Result);
            Assert.NotNull(actionResult);
            var resultList = Assert.IsAssignableFrom<BranchInspectors>(actionResult.Value);
            Assert.NotNull(resultList);
            Assert.True(resultList.Data.Any());
        }
        [Fact]
        public async Task V2_Classifications_Branches_ValidAsync()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v2.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);

            // Act
            var taskResult = await testObject.BranchesAsync("testBranch");

            // Assert
            Assert.NotNull(taskResult);
            var resultObj = Assert.IsType<ActionResult<BranchInspectors>>(taskResult);
            Assert.NotNull(resultObj);
            var actionResult = Assert.IsType<OkObjectResult>(resultObj.Result);
            Assert.NotNull(actionResult);
            var resultList = Assert.IsAssignableFrom<BranchInspectors>(actionResult.Value);
            Assert.NotNull(resultList);
            Assert.True(resultList.Data.Any());
        }

        [Fact]
        public async Task Classifications_Zones_ValidAsync()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v1.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);

            // Act
            var taskResult = await testObject.ZonesAsync("testZone");

            // Assert
            Assert.NotNull(taskResult);
            var resultObj = Assert.IsType<ActionResult<ZoneBranches>>(taskResult);
            Assert.NotNull(resultObj);
            var actionResult = Assert.IsType<OkObjectResult>(resultObj.Result);
            Assert.NotNull(actionResult);
            var resultList = Assert.IsAssignableFrom<ZoneBranches>(actionResult.Value);
            Assert.NotNull(resultList);
            Assert.True(resultList.Data.Any());
        }
        [Fact]
        public async Task V2_Classifications_Zones_ValidAsync()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v2.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);

            // Act
            var taskResult = await testObject.ZonesAsync("testZone");

            // Assert
            Assert.NotNull(taskResult);
            var resultObj = Assert.IsType<ActionResult<ZoneBranches>>(taskResult);
            Assert.NotNull(resultObj);
            var actionResult = Assert.IsType<OkObjectResult>(resultObj.Result);
            Assert.NotNull(actionResult);
            var resultList = Assert.IsAssignableFrom<ZoneBranches>(actionResult.Value);
            Assert.NotNull(resultList);
            Assert.True(resultList.Data.Any());
        }

        [Fact]
        public async Task Classifications_Networks_ValidAsync()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v1.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);

            // Act
            var taskResult = await testObject.NetworksAsync("testNetwork");

            // Assert
            Assert.NotNull(taskResult);
            var resultObj = Assert.IsType<ActionResult<NetworkZones>>(taskResult);
            Assert.NotNull(resultObj);
            var actionResult = Assert.IsType<OkObjectResult>(resultObj.Result);
            Assert.NotNull(actionResult);
            var resultList = Assert.IsAssignableFrom<NetworkZones>(actionResult.Value);
            Assert.NotNull(resultList);
            Assert.True(resultList.Data.Any());
        }
        [Fact]
        public async Task V2_Classifications_Networks_ValidAsync()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v2.ClassificationAgentsController(fakeHeaders, _mockRepository.Object);

            // Act
            var taskResult = await testObject.NetworksAsync("testNetwork");

            // Assert
            Assert.NotNull(taskResult);
            var resultObj = Assert.IsType<ActionResult<NetworkZones>>(taskResult);
            Assert.NotNull(resultObj);
            var actionResult = Assert.IsType<OkObjectResult>(resultObj.Result);
            Assert.NotNull(actionResult);
            var resultList = Assert.IsAssignableFrom<NetworkZones>(actionResult.Value);
            Assert.NotNull(resultList);
            Assert.True(resultList.Data.Any());
        }
    }
}

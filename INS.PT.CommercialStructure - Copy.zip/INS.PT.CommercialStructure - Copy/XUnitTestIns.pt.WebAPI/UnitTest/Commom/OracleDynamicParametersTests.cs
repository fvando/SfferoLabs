﻿using INS.PT.WebAPI;
using System.Linq;
using Xunit;

namespace XUnitTestIns.pt.WebAPI.UnitTest
{
    public class OracleDynamicParametersTests
    {
        [Fact]
        public void GetDecimal_ExistsParameter()
        {
            // Arrange
            var parameter = "testParameter";
            var testObject = new OracleDynamicParameters();
            testObject.Add(parameter, Oracle.ManagedDataAccess.Client.OracleDbType.Decimal, System.Data.ParameterDirection.InputOutput);
            testObject.Parameters.First(p => p.ParameterName == parameter).Value = new Oracle.ManagedDataAccess.Types.OracleDecimal(123.321M);

            // Act
            var result = testObject.GetDecimal(parameter);

            // Assert
            Assert.Equal(123.321M, result);
        }

        [Fact]
        public void GetDecimal_UnknownParameter()
        {
            // Arrange
            var testObject = new OracleDynamicParameters();
            testObject.Add("testParameter", Oracle.ManagedDataAccess.Client.OracleDbType.Decimal, System.Data.ParameterDirection.InputOutput);

            // Act
            var result = testObject.GetDecimal("otherParameter");

            // Assert
            Assert.Equal(default(decimal), result);
        }

        [Fact]
        public void GetInt_ExistsParameter()
        {
            // Arrange
            var parameter = "testParameter";
            var testObject = new OracleDynamicParameters();
            testObject.Add(parameter, Oracle.ManagedDataAccess.Client.OracleDbType.Decimal, System.Data.ParameterDirection.InputOutput);
            testObject.Parameters.First(p => p.ParameterName == parameter).Value = new Oracle.ManagedDataAccess.Types.OracleDecimal(123.321M);

            // Act
            var result = testObject.GetInt(parameter);

            // Assert
            Assert.Equal(123, result);
        }

        [Fact]
        public void GetInt_UnknownParameter()
        {
            // Arrange
            var testObject = new OracleDynamicParameters();
            testObject.Add("testParameter", Oracle.ManagedDataAccess.Client.OracleDbType.Decimal, System.Data.ParameterDirection.InputOutput);

            // Act
            var result = testObject.GetInt("otherParameter");

            // Assert
            Assert.Equal(default(int), result);
        }

        [Fact]
        public void GetString_ExistsParameter()
        {
            // Arrange
            var parameter = "testParameter";
            var testObject = new OracleDynamicParameters();
            testObject.Add(parameter, Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, System.Data.ParameterDirection.InputOutput);
            testObject.Parameters.First(p => p.ParameterName == parameter).Value = new Oracle.ManagedDataAccess.Types.OracleString("testValue");

            // Act
            var result = testObject.GetString(parameter);

            // Assert
            Assert.Equal("testValue", result);
        }

        [Fact]
        public void GetString_UnknownParameter()
        {
            // Arrange
            var testObject = new OracleDynamicParameters();
            testObject.Add("testParameter", Oracle.ManagedDataAccess.Client.OracleDbType.Varchar2, System.Data.ParameterDirection.InputOutput);

            // Act
            var result = testObject.GetString("otherParameter");

            // Assert
            Assert.Equal(default(string), result);
        }

        [Fact]
        public void GetXml_ExistsParameter()
        {
            // Arrange
            var parameter = "testParameter";
            var testObject = new OracleDynamicParameters();
            testObject.Add(parameter, Oracle.ManagedDataAccess.Client.OracleDbType.XmlType, System.Data.ParameterDirection.InputOutput);
            testObject.Parameters.First(p => p.ParameterName == parameter).Value = new Oracle.ManagedDataAccess.Types.OracleString("<root />");

            // Act
            var result = testObject.GetXml(parameter);

            // Assert
            Assert.NotNull(result);
        }

        [Fact]
        public void GetXml_UnknownParameter()
        {
            // Arrange
            var testObject = new OracleDynamicParameters();
            testObject.Add("testParameter", Oracle.ManagedDataAccess.Client.OracleDbType.XmlType, System.Data.ParameterDirection.InputOutput);

            // Act
            var result = testObject.GetXml("otherParameter");

            // Assert
            Assert.Null(result);
        }
    }
}

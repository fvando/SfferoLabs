﻿using INS.PT.WebAPI;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using v1 = INS.PT.WebAPI.Controllers.V1;
using System.Collections.Generic;
using Xunit;
using System.Reflection;

namespace XUnitTest.INS.PT.WebAPI.UnitTest.Commom
{
    public class ApiExplorerGroupPerVersionConventionTests
    {
        [Fact]
        public void Controllers_None()
        {
            // Arrange
            var testObject = new ApiExplorerGroupPerVersionConvention();
            ControllerModel controller = null;


            // Act
            testObject.Apply(controller);

            // Assert
            Assert.Null(controller);
        }

        [Fact]
        public void Controllers_Group()
        {
            // Arrange
            var testObject = new ApiExplorerGroupPerVersionConvention();
            var controller = new ControllerModel(typeof(v1.AgentsSearchController).GetTypeInfo(), 
                new List<object>() { });


            // Act
            testObject.Apply(controller);

            // Assert
            Assert.NotNull(controller?.ApiExplorer?.GroupName);
            Assert.NotEmpty(controller.ApiExplorer.GroupName);
        }
    }
}

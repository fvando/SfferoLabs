﻿using INS.PT.WebAPI;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class StartupTests
    {
        [Fact(Skip = "need to refactor this test!")]
        public void SetupRepositories_Create_Valid()
        {
            // Arrange
            var serviceCollection = new ServiceCollection();

            // Act
            Startup.Setups.SetupRepositories(serviceCollection);

            // Assert
            Assert.True(serviceCollection.Count > 0);
        }
    }
}

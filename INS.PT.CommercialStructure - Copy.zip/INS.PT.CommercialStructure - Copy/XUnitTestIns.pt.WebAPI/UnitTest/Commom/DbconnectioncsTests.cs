﻿using INS.PT.WebAPI;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using Xunit;

namespace XUnitTestIns.pt.WebAPI.UnitTest
{
    public class DbconnectioncsTests
    {
        private static IConfiguration _fakeSettings = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build();

        [Fact]
        public void DbConnections_GetConnection_InvalidConnection()
        {
            // Arrange
            var mockConfig = new Mock<IConfiguration>();
            var testObject = new Dbconnectioncs(mockConfig.Object);

            mockConfig.Setup(x => x.GetSection("ConnectionStrings").GetSection("DBConnection").Value).Returns("");

            // Act and Assert
            Assert.Throws<InvalidOperationException>(() =>
                testObject.Connection);
        }

        [Fact]
        public void DbConnections_GetConnection_ValidConnection()
        {
            // Arrange
            var testObject = new Dbconnectioncs(_fakeSettings);


            // Act
            var result = testObject.Connection;

            // Assert
            Assert.NotNull(result);
        }
    }
}

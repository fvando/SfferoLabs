﻿using INS.PT.WebAPI.Models;
using System;
using Xunit;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class ExceptionsTests
    {
        [Fact]
        public void ProcessErrorException_GetObjectData_Invalid()
        {
            // Arrange
            var ProcessErrorException = new ProcessErrorException();
            System.Runtime.Serialization.SerializationInfo serializeInfo = null;
            var streamContext = new System.Runtime.Serialization.StreamingContext(System.Runtime.Serialization.StreamingContextStates.File);

            // Act & Assert
            Assert.Throws<ArgumentNullException>(() => ProcessErrorException.GetObjectData(serializeInfo, streamContext));
        }

        [Fact]
        public void ProcessErrorException_GetObjectData_Valid()
        {
            // Arrange
            const string TestMessage = "test message";
            var ProcessErrorException = new ProcessErrorException(TestMessage);
            var serializeInfo = new System.Runtime.Serialization.SerializationInfo(typeof(ExceptionsTests), new System.Runtime.Serialization.FormatterConverter());
            var streamContext = new System.Runtime.Serialization.StreamingContext(System.Runtime.Serialization.StreamingContextStates.File);

            // Act
            ProcessErrorException.GetObjectData(serializeInfo, streamContext);

            // Assert
            var testValue = serializeInfo.GetValue(nameof(ProcessErrorException.ErrorMessage), ProcessErrorException.ErrorMessage.GetType());
            var value = Assert.IsType<string>(testValue);
            Assert.Equal(TestMessage, value);
        }

        [Fact]
        public void ProcessErrorException_ToString_Valid()
        {
            // Arrange
            const string TestMessage = "test message";
            const string TestCode = "errorCode";
            var ProcessErrorException = new ProcessErrorException(TestMessage, TestCode);

            // Act
            var message = ProcessErrorException.ToString();

            // Assert
            Assert.Contains(TestMessage, message);
            Assert.Contains(TestCode, message);
        }
    }
}

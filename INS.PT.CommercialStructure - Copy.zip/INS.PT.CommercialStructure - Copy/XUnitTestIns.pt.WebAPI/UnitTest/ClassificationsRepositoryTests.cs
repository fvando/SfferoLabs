﻿using INS.PT.WebAPI.Repository;
using INS.PT.WebAPI;
using INS.PT.WebAPI.Models;
using Moq;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using INS.PT.WebAPI.Models.V2;

namespace XUnitTest.INS.PT.WebAPI.UnitTest
{
    public class ClassificationsRepositoryTests
    {
        private readonly Mock<IDbconnectioncs> _mockConnections;


        public ClassificationsRepositoryTests()
        {
            var _mockConnection = new Mock<IDbConnection>();
            _mockConnection.Setup(x => x.ConnectionString).Returns("test connecting string");
            _mockConnections = new Mock<IDbconnectioncs>();
            _mockConnections.Setup(x => x.Connection).Returns(_mockConnection.Object);
        }

        private static IEnumerable<Classification> FakeClassifications(OracleDynamicParameters parameters)
        {
            // fill erroCode parameter
            parameters.Parameters.First(p => p.ParameterName == "P_ERRO").Value =
               new Oracle.ManagedDataAccess.Types.OracleString("00");

            // return fake results
            return new List<Classification>
            {
                new Classification
                {
                    Code = "00",
                    Description = "test result 00",
                },
                new Classification
                {
                    Code = "01",
                    Description = "test result 01",
                }
            };
        }

        private static IEnumerable<ClassificationProtocol> FakeClassificationsProtocol(OracleDynamicParameters parameters)
        {
            // fill erroCode parameter
            parameters.Parameters.First(p => p.ParameterName == "P_ERRO").Value =
               new Oracle.ManagedDataAccess.Types.OracleString("00");

            // return fake results
            return new List<ClassificationProtocol>
            {
                new ClassificationProtocol
                {
                    Code = "00",
                    Description = "test result 00",
                },
                new ClassificationProtocol
                {
                    Code = "01",
                    Description = "test result 01",
                }
            };
        }

        private static IEnumerable<Classification> FakeErroFromDatabase(OracleDynamicParameters parameters)
        {
            // fill erroCode parameter
            parameters.Parameters.First(p => p.ParameterName == "P_ERRO").Value =
               new Oracle.ManagedDataAccess.Types.OracleString("999");
            parameters.Parameters.First(p => p.ParameterName == "P_DSERRO").Value =
               new Oracle.ManagedDataAccess.Types.OracleString("test error");

            // return fake results
            return Enumerable.Empty<Classification>();
        }

        private static IEnumerable<ClassificationProtocol> FakeErroFromDatabaseProtocol(OracleDynamicParameters parameters)
        {
            // fill erroCode parameter
            parameters.Parameters.First(p => p.ParameterName == "P_ERRO").Value =
               new Oracle.ManagedDataAccess.Types.OracleString("999");
            parameters.Parameters.First(p => p.ParameterName == "P_DSERRO").Value =
               new Oracle.ManagedDataAccess.Types.OracleString("test error");

            // return fake results
            return Enumerable.Empty<ClassificationProtocol>();
        }


        [Fact]
        public void ReadClassificationsByAttributeAsync_ErrorFromDB()
        {
            // Arrange
            var testObject = new ClassificationsRepository(_mockConnections.Object, 
                (conn, command, parameters) => Task.Run(() => FakeErroFromDatabase(parameters)), null);

            // Act and Assert
            Assert.ThrowsAsync<ProcessErrorException>(() => testObject.ReadClassificationsByAttributeAsync("testAttribute"));
        }

        [Fact]
        public void ReadClassificationsByProtocolAsync_ErrorFromDB()
        {
            // Arrange
            var testObject = new ClassificationsRepository(_mockConnections.Object, null, 
                (conn, command, parameters) => Task.Run(() => FakeErroFromDatabaseProtocol(parameters)));

            // Act and Assert
            Assert.ThrowsAsync<ProcessErrorException>(() => testObject.ReadClassificationsByProtocolAsync(CommercialStructureLevels.Agent, "Testcode", "testAttribute"));
        }

        [Fact]
        public async Task ReadClassificationsByAttributeAsync_No_AttributeAsync()
        {
            // Arrange
            var testObject = new ClassificationsRepository(_mockConnections.Object, 
                (conn, command, parameters) => Task.Run(() => FakeClassifications(parameters)), null);

            // Act
            var result = await testObject.ReadClassificationsByAttributeAsync(null);

            // Assert
            Assert.False(result.Any());
        }

        [Fact]
        public async Task ReadClassificationsByProtocolAsync_No_AttributeAsync()
        {
            // Arrange
            var testObject = new ClassificationsRepository(_mockConnections.Object, null, 
                (conn, command, parameters) => Task.Run(() => FakeClassificationsProtocol(parameters)));

            // Act
            var result = await testObject.ReadClassificationsByProtocolAsync(CommercialStructureLevels.Agent, null, null);

            // Assert
            Assert.False(result.Any());
        }


        [Fact]
        public async Task ReadClassificationsByAttributeAsync_ValidResponse()
        {
            // Arrange
            var testObject = new ClassificationsRepository(_mockConnections.Object,
                (conn, command, parameters) => Task.Run(() => FakeClassifications(parameters)), null);

            // Act
            var result = await testObject.ReadClassificationsByAttributeAsync("testAttribute");

            // Assert
            Assert.True(result.Any());
        }

        [Fact]
        public async Task ReadClassificationsByProtocolAsync_ValidResponse()
        {
            // Arrange
            var testObject = new ClassificationsRepository(_mockConnections.Object, null,
                (conn, command, parameters) => Task.Run(() => FakeClassificationsProtocol(parameters)));

            // Act
            var result = await testObject.ReadClassificationsByProtocolAsync(CommercialStructureLevels.Agent, "Testcode", "testAttribute");

            // Assert
            Assert.True(result.Any());
        }

    }
}

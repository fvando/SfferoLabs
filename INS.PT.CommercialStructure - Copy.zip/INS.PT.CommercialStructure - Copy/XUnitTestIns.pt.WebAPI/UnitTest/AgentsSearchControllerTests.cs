﻿using INS.PT.WebAPI.Models;
using Moq;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using INS.PT.WebAPI.Interface;
using Microsoft.AspNetCore.Mvc;
using XUnitTestINS.PT.WebAPI.Context;
using Microsoft.AspNetCore.Http;
using v1 = INS.PT.WebAPI.Controllers.V1;
using v2 = INS.PT.WebAPI.Controllers.V2;

namespace XUnitTest.INS.PT.WebAPI.UnitTest
{
    public class AgentsSearchControllerTests
    {
        private readonly Mock<IAgentsSearch> _mockRepository;
        private readonly HeaderParameters headerParameters;

        public class TestAgentsSearchControllerV1 : v1.AgentsSearchController
        {
            private readonly HeaderParameters headerParameters;

            public TestAgentsSearchControllerV1(HeaderParameters headerParameters, IHttpContextAccessor httpContext, IAgentsSearch repository) : base(httpContext, repository)
            {
                this.headerParameters = headerParameters;
            }

            public HeaderParameters TestHeaderParameters { get; set; }

            protected override HeaderParameters ValidateHeader()
            {
                return headerParameters;
            }
        }

        public class TestAgentsSearchControllerV2 : v2.AgentsSearchController
        {
            private readonly HeaderParameters headerParameters;

            public TestAgentsSearchControllerV2(HeaderParameters headerParameters, IHttpContextAccessor httpContext, IAgentsSearch repository) : base(httpContext, repository)
            {
                this.headerParameters = headerParameters;
            }

            public HeaderParameters TestHeaderParameters { get; set; }

            protected override HeaderParameters ValidateHeader()
            {
                return headerParameters;
            }
        }

        public AgentsSearchControllerTests()
        {
            headerParameters = new HeaderParameters
            {
                IdCompany = "AGEAS",
                IdSource = "TECH"
            };

            _mockRepository = new Mock<IAgentsSearch>();


            _mockRepository.Setup(x => x.GetAgentsFromEnergiserAsync("validTest"))
                .ReturnsAsync(new List<StreamlinedAgent>
            {
                new StreamlinedAgent
                {
                    AgentCode = "12345"
                },
                new StreamlinedAgent
                {
                    AgentCode = "98765"
                }
            });

            _mockRepository.Setup(x => x.GetAgentsFromEnergiserAsync("empty"))
                .ReturnsAsync(Enumerable.Empty<StreamlinedAgent>());

            _mockRepository.Setup(x => x.GetAgentsFromEnergiserAsync("errorDB"))
                .Throws(new ProcessErrorException("test error"));


            _mockRepository.Setup(x => x.GetAgentsByClassAsync("validTest"))
                .ReturnsAsync(new List<AgentMatch>
            {
                new AgentMatch
                {
                    Code = "12345",
                    StartDate = new System.DateTime (2020, 3, 16)
                },
                new AgentMatch
                {
                    Code = "98765",
                    StartDate = new System.DateTime (2020, 3, 16)
                }
            });

            _mockRepository.Setup(x => x.GetAgentsByClassAsync("empty"))
                .ReturnsAsync(Enumerable.Empty<AgentMatch>());

            _mockRepository.Setup(x => x.GetAgentsByClassAsync("errorDB"))
                .Throws(new ProcessErrorException("test error"));


            _mockRepository.Setup(x => x.GetAgentsStructureByClassAsync("validTest"))
                .ReturnsAsync(new List<Company>
            {
                new Company
                {
                    CompanyName = "testCompany",
                    Networks = new List<Network>()
                }
            });

            _mockRepository.Setup(x => x.GetAgentsStructureByClassAsync("empty"))
                .ReturnsAsync(Enumerable.Empty<Company>());

            _mockRepository.Setup(x => x.GetAgentsStructureByClassAsync("errorDB"))
                .Throws(new ProcessErrorException("test error"));


            _mockRepository.Setup(x => x.GetSharedCommissionAgentAsync(headerParameters, "validTest", "validTest"))
                .ReturnsAsync("testResult");

            _mockRepository.Setup(x => x.GetSharedCommissionAgentAsync(headerParameters, "empty", "empty"))
                .ReturnsAsync((string)null);

            _mockRepository.Setup(x => x.GetSharedCommissionAgentAsync(headerParameters, "errorDB", "errorDB"))
                .Throws(new ProcessErrorException("test error"));
        }


        #region FromEnergiser
        [Fact]
        public async Task ByAttribute_ErrorFromDBAsync()
        {
            // Arrange
            var testObject = new v1.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.FromEnergiserAsync("errorDB");


            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<StreamlinedAgent>>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }
        [Fact]
        public async Task V2_ByAttribute_ErrorFromDBAsync()
        {
            // Arrange
            var testObject = new v2.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.FromEnergiserAsync("errorDB");


            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<StreamlinedAgent>>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }

        [Fact]
        public async Task ByAttribute_No_Results()
        {
            // Arrange
            var testObject = new v1.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.FromEnergiserAsync("empty");

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<StreamlinedAgent>>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }
        [Fact]
        public async Task V2_ByAttribute_No_Results()
        {
            // Arrange
            var testObject = new v2.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.FromEnergiserAsync("empty");

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<StreamlinedAgent>>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }

        [Fact]
        public async Task ByAttribute_ValidResponse()
        {
            // Arrange
            var testObject = new v1.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.FromEnergiserAsync("validTest");

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<StreamlinedAgent>>>(result);
            var okObject = Assert.IsType<OkObjectResult>(taskResult.Result);
            var responseList = Assert.IsAssignableFrom<IEnumerable<StreamlinedAgent>>(okObject.Value);
            Assert.True(responseList.Any());
        }
        [Fact]
        public async Task V2_ByAttribute_ValidResponse()
        {
            // Arrange
            var testObject = new v2.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.FromEnergiserAsync("validTest");

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<StreamlinedAgent>>>(result);
            var okObject = Assert.IsType<OkObjectResult>(taskResult.Result);
            var responseList = Assert.IsAssignableFrom<IEnumerable<StreamlinedAgent>>(okObject.Value);
            Assert.True(responseList.Any());
        }
        #endregion

        #region ByClass
        [Fact]
        public async Task ByClass_ErrorFromDBAsync()
        {
            // Arrange
            var testObject = new v1.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.ByClassAsync("errorDB");


            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<AgentMatch>>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }
        [Fact]
        public async Task V2_ByClass_ErrorFromDBAsync()
        {
            // Arrange
            var testObject = new v2.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.ByClassAsync("errorDB");


            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<AgentMatch>>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }

        [Fact]
        public async Task ByClass_No_Results()
        {
            // Arrange
            var testObject = new v1.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.ByClassAsync("empty");

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<AgentMatch>>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }
        [Fact]
        public async Task V2_ByClass_No_Results()
        {
            // Arrange
            var testObject = new v2.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.ByClassAsync("empty");

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<AgentMatch>>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }

        [Fact]
        public async Task ByClass_ValidResponse()
        {
            // Arrange
            var testObject = new v1.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.ByClassAsync("validTest");

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<AgentMatch>>>(result);
            var okObject = Assert.IsType<OkObjectResult>(taskResult.Result);
            var responseList = Assert.IsAssignableFrom<IEnumerable<AgentMatch>>(okObject.Value);
            Assert.True(responseList.Any());
        }
        [Fact]
        public async Task V2_ByClass_ValidResponse()
        {
            // Arrange
            var testObject = new v2.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.ByClassAsync("validTest");

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<AgentMatch>>>(result);
            var okObject = Assert.IsType<OkObjectResult>(taskResult.Result);
            var responseList = Assert.IsAssignableFrom<IEnumerable<AgentMatch>>(okObject.Value);
            Assert.True(responseList.Any());
        }
        #endregion

        #region StructureByClass
        [Fact]
        public async Task StructureByClass_ErrorFromDBAsync()
        {
            // Arrange
            var testObject = new v1.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.StructureByClassAsync("errorDB");


            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<Company>>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }
        [Fact]
        public async Task V2_StructureByClass_ErrorFromDBAsync()
        {
            // Arrange
            var testObject = new v2.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.StructureByClassAsync("errorDB");


            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<Company>>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }

        [Fact]
        public async Task StructureByClass_No_Results()
        {
            // Arrange
            var testObject = new v1.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.StructureByClassAsync("empty");

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<Company>>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }
        [Fact]
        public async Task V2_StructureByClass_No_Results()
        {
            // Arrange
            var testObject = new v2.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.StructureByClassAsync("empty");

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<Company>>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }

        [Fact]
        public async Task StructureByClass_ValidResponse()
        {
            // Arrange
            var testObject = new v1.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.StructureByClassAsync("validTest");

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<Company>>>(result);
            var okObject = Assert.IsType<OkObjectResult>(taskResult.Result);
            var responseList = Assert.IsAssignableFrom<IEnumerable<Company>>(okObject.Value);
            Assert.True(responseList.Any());
        }
        [Fact]
        public async Task V2_StructureByClass_ValidResponse()
        {
            // Arrange
            var testObject = new v2.AgentsSearchController(new FakeHeaderParameters(null), _mockRepository.Object);

            // Act
            var result = await testObject.StructureByClassAsync("validTest");

            // Assert
            var taskResult = Assert.IsType<ActionResult<IEnumerable<Company>>>(result);
            var okObject = Assert.IsType<OkObjectResult>(taskResult.Result);
            var responseList = Assert.IsAssignableFrom<IEnumerable<Company>>(okObject.Value);
            Assert.True(responseList.Any());
        }
        #endregion

        #region SharedCommission
        [Fact]
        public async Task SharedCommission_ErrorFromDBAsync()
        {
            // Arrange
            var testObject = new TestAgentsSearchControllerV1(headerParameters, new FakeHeaderParameters(headerParameters), _mockRepository.Object);

            // Act
            var result = await testObject.SharedCommissionAsync("errorDB", "errorDB");


            // Assert
            var taskResult = Assert.IsType<ActionResult<string>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }
        [Fact]
        public async Task V2_SharedCommission_ErrorFromDBAsync()
        {
            // Arrange
            var testObject = new TestAgentsSearchControllerV2(headerParameters, new FakeHeaderParameters(headerParameters), _mockRepository.Object);

            // Act
            var result = await testObject.SharedCommissionAsync("errorDB", "errorDB");


            // Assert
            var taskResult = Assert.IsType<ActionResult<string>>(result);
            var notFoundObject = Assert.IsType<NotFoundObjectResult>(taskResult.Result);
            Assert.NotNull(notFoundObject);
        }

        [Fact]
        public async Task SharedCommission_No_Results()
        {
            // Arrange
            var testObject = new TestAgentsSearchControllerV1(headerParameters, new FakeHeaderParameters(headerParameters), _mockRepository.Object);

            // Act
            var result = await testObject.SharedCommissionAsync("empty", "empty");

            // Assert
            var taskResult = Assert.IsType<ActionResult<string>>(result);
            Assert.Null(taskResult.Value);   
        }
        [Fact]
        public async Task V2_SharedCommission_No_Results()
        {
            // Arrange
            var testObject = new TestAgentsSearchControllerV2(headerParameters, new FakeHeaderParameters(headerParameters), _mockRepository.Object);

            // Act
            var result = await testObject.SharedCommissionAsync("empty", "empty");

            // Assert
            var taskResult = Assert.IsType<ActionResult<string>>(result);
            Assert.Null(taskResult.Value);   
        }

        [Fact]
        public async Task SharedCommission_ValidResponse()
        {
            // Arrange
            var testObject = new TestAgentsSearchControllerV1(headerParameters, new FakeHeaderParameters(headerParameters), _mockRepository.Object);

            // Act
            var result = await testObject.SharedCommissionAsync("validTest", "validTest");

            // Assert
            var taskResult = Assert.IsType<ActionResult<string>>(result);
            var okObject = Assert.IsType<OkObjectResult>(taskResult.Result);
            var responseList = Assert.IsAssignableFrom<string>(okObject.Value);
            Assert.False(string.IsNullOrEmpty(responseList));
        }
        [Fact]
        public async Task V2_SharedCommission_ValidResponse()
        {
            // Arrange
            var testObject = new TestAgentsSearchControllerV2(headerParameters, new FakeHeaderParameters(headerParameters), _mockRepository.Object);

            // Act
            var result = await testObject.SharedCommissionAsync("validTest", "validTest");

            // Assert
            var taskResult = Assert.IsType<ActionResult<string>>(result);
            var okObject = Assert.IsType<OkObjectResult>(taskResult.Result);
            var responseList = Assert.IsAssignableFrom<string>(okObject.Value);
            Assert.False(string.IsNullOrEmpty(responseList));
        }
        #endregion
    }
}

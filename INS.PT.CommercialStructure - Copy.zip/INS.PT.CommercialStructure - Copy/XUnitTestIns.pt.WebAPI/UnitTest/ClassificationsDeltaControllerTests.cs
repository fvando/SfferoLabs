﻿using INS.PT.WebAPI.Controllers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using XUnitTestINS.PT.WebAPI.Context;
using v1 = INS.PT.WebAPI.Controllers.V1;
using v2 = INS.PT.WebAPI.Controllers.V2;

namespace XUnitTestIns.pt.WebAPI.UnitTest
{
    public class ClassificationsDeltaControllerTests
    {
        private readonly Mock<ICommomRepository> mockRepository;

        public ClassificationsDeltaControllerTests()
        {
            mockRepository = new Mock<ICommomRepository>();
            mockRepository.Setup(x => x.ReadClassificationDeltasAsync(
                It.IsAny<HeaderParameters>(), "testAgent", It.IsAny<DateTime>(), ClassificationSearchType.Agent)).Returns(Task.Run<IEnumerable<AgentClassification>>(() =>
                    new List<AgentClassification>
                            {
                                new AgentClassification
                                {
                                    AgentCode = "testAgent",
                                    AgentType = new AgentClassificationType
                                    {
                                        AgentTypeCode = "11",
                                        AgentTypeDescription = "",
                                        StartDate = DateTime.Now
                                    },
                                    Classifications = new List<Classification>
                                    {
                                        new Classification
                                        {
                                             Code= "AG",
                                             Description = "redes",
                                             Tipology = "outros",
                                             StartDate = DateTime.Now,
                                             Rule = "regra dummy"
                                        }
                                    }
                                }
                            }
                   ));
            mockRepository.Setup(x => x.ReadClassificationDeltasAsync(
                It.IsAny<HeaderParameters>(), null, It.IsAny<DateTime>(), ClassificationSearchType.Agent)).Returns(Task.Run<IEnumerable<AgentClassification>>(() =>
                    new List<AgentClassification>
                            {
                                new AgentClassification
                                {
                                    AgentCode = "testAgent",
                                    AgentType = new AgentClassificationType
                                    {
                                        AgentTypeCode = "11",
                                        AgentTypeDescription = "",
                                        StartDate = DateTime.Now
                                    },
                                    Classifications = new List<Classification>
                                    {
                                        new Classification
                                        {
                                             Code= "AG",
                                             Description = "redes",
                                             Tipology = "outros",
                                             StartDate = DateTime.Now,
                                             Rule = "regra dummy"
                                        }
                                    }
                                }
                            }
                   ));

            mockRepository.Setup(x => x.ReadClassificationDeltasAsync(
                It.IsAny<HeaderParameters>(), "failAgent", DateTime.Now, ClassificationSearchType.Agent)).Throws<ProcessErrorException>();
        }

        [Fact]
        public void ClassificationsDelta_Get_Valid()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v1.ClassificationAgentsController(fakeHeaders, mockRepository.Object);

            // Act
            var taskResult = testObject.ClassificationsDeltaAsync("testAgent", DateTime.Now, null);

            // Assert
            Assert.NotNull(taskResult);
            var resultTask = Assert.IsType<Task<ActionResult<IEnumerable<AgentClassification>>>>(taskResult);
            Assert.NotNull(resultTask);
            var resultObj = Assert.IsType<ActionResult<IEnumerable<AgentClassification>>>(resultTask.Result);
            Assert.NotNull(resultObj);
            var actionResult = Assert.IsType<OkObjectResult>(resultObj.Result);
            Assert.NotNull(actionResult);
            var resultList = Assert.IsAssignableFrom<IEnumerable<AgentClassification>>(actionResult.Value);
            Assert.NotNull(resultList);
            Assert.True(resultList.Any());
        }
        [Fact]
        public void V2_ClassificationsDelta_Get_Valid()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v2.ClassificationAgentsController(fakeHeaders, mockRepository.Object);

            // Act
            var taskResult = testObject.ClassificationsDeltaAsync("testAgent", DateTime.Now, null);

            // Assert
            Assert.NotNull(taskResult);
            var resultTask = Assert.IsType<Task<ActionResult<IEnumerable<AgentClassification>>>>(taskResult);
            Assert.NotNull(resultTask);
            var resultObj = Assert.IsType<ActionResult<IEnumerable<AgentClassification>>>(resultTask.Result);
            Assert.NotNull(resultObj);
            var actionResult = Assert.IsType<OkObjectResult>(resultObj.Result);
            Assert.NotNull(actionResult);
            var resultList = Assert.IsAssignableFrom<IEnumerable<AgentClassification>>(actionResult.Value);
            Assert.NotNull(resultList);
            Assert.True(resultList.Any());
        }

        [Fact]
        public void ClassificationsDelta_GetWithoutAgent_Valid()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v1.ClassificationAgentsController(fakeHeaders, mockRepository.Object);

            // Act
            var taskResult = testObject.ClassificationsDeltaAsync(DateTime.Now);

            // Assert
            Assert.NotNull(taskResult);
            var resultTask = Assert.IsType<Task<ActionResult<IEnumerable<AgentClassification>>>>(taskResult);
            Assert.NotNull(resultTask);
            var resultObj = Assert.IsType<ActionResult<IEnumerable<AgentClassification>>>(resultTask.Result);
            Assert.NotNull(resultObj);
            var actionResult = Assert.IsType<OkObjectResult>(resultObj.Result);
            Assert.NotNull(actionResult);
            var resultList = Assert.IsAssignableFrom<IEnumerable<AgentClassification>>(actionResult.Value);
            Assert.NotNull(resultList);
            Assert.True(resultList.Any());
        }
        [Fact]
        public void V2_ClassificationsDelta_GetWithoutAgent_Valid()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v2.ClassificationAgentsController(fakeHeaders, mockRepository.Object);

            // Act
            var taskResult = testObject.ClassificationsDeltaAsync(DateTime.Now);

            // Assert
            Assert.NotNull(taskResult);
            var resultTask = Assert.IsType<Task<ActionResult<IEnumerable<AgentClassification>>>>(taskResult);
            Assert.NotNull(resultTask);
            var resultObj = Assert.IsType<ActionResult<IEnumerable<AgentClassification>>>(resultTask.Result);
            Assert.NotNull(resultObj);
            var actionResult = Assert.IsType<OkObjectResult>(resultObj.Result);
            Assert.NotNull(actionResult);
            var resultList = Assert.IsAssignableFrom<IEnumerable<AgentClassification>>(actionResult.Value);
            Assert.NotNull(resultList);
            Assert.True(resultList.Any());
        }

        [Fact]
        public void ClassificationsDelta_Get_ErrorInDatabase()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v1.ClassificationAgentsController(fakeHeaders, mockRepository.Object);

            // Act and Assert
            Assert.ThrowsAsync<ProcessErrorException>(() => testObject.ClassificationsDeltaAsync("failAgent", DateTime.Now, null));
        }
        [Fact]
        public void V2_ClassificationsDelta_Get_ErrorInDatabase()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(null);
            var testObject = new v2.ClassificationAgentsController(fakeHeaders, mockRepository.Object);

            // Act and Assert
            Assert.ThrowsAsync<ProcessErrorException>(() => testObject.ClassificationsDeltaAsync("failAgent", DateTime.Now, null));
        }


        [Fact]
        public void ClassificationsDelta_Get_InvalidHeaders()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(new HeaderParameters
            {
                IdCompany = "",
                IdSource = "",
            });
            var testObject = new v1.ClassificationAgentsController(fakeHeaders, mockRepository.Object);

            // Act and Assert
            Assert.ThrowsAsync<ProcessErrorException>(() => testObject.ClassificationsDeltaAsync("failAgent", DateTime.Now, null));
        }
        [Fact]
        public void V2_ClassificationsDelta_Get_InvalidHeaders()
        {
            // Arrange
            var fakeHeaders = new FakeHeaderParameters(new HeaderParameters
            {
                IdCompany = "",
                IdSource = "",
            });
            var testObject = new v2.ClassificationAgentsController(fakeHeaders, mockRepository.Object);

            // Act and Assert
            Assert.ThrowsAsync<ProcessErrorException>(() => testObject.ClassificationsDeltaAsync("failAgent", DateTime.Now, null));
        }
    }
}

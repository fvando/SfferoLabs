﻿using System;
using System.Threading.Tasks;
using INS.PT.AgentsPortal.WinSvc.Data;
using INS.PT.AgentsPortal.WinSvc.Models.Requests;
using INS.PT.AgentsPortal.WinSvc.Repository;
using INS.PT.WinSvc.Data;
using INS.PT.WinSvc.Enumerations;
using Microsoft.Azure.ServiceBus;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace INS.PT.WinSvc.Helpers
{
    class ServicesBusDb : BaseCore
    {
        private ISubscriptionClient _subscriptionClient;

        public ServicesBusDb(ISubscriptionClient subscriptionClient)
        {
            _subscriptionClient = subscriptionClient;
        }
        public async Task SaveServiceBusDBGetMessageStepAsync(long messageId)
        {
            if (ApplicationSettings.DatabaseLogEnabled)
            {
                Models.DB.AzureServiceBus.MessageOperation azbMessageOperation = new Models.DB.AzureServiceBus.MessageOperation();

                azbMessageOperation.ResultCode = Enums.MessageOperationResultCode.OK.ToString();
                azbMessageOperation.ProcessEndDate = DateTime.Now;
                azbMessageOperation.AuditUpdatedDate = DateTime.Now;

                await SaveServiceBusDBAsync(azbMessageOperation, Enums.AzbOperation.GetMessage, messageId);
            }
        }
        public async Task SaveMessageExceptionToDb(Models.DB.AzureServiceBus.MessageOperation azbMessageOperation, Exception exception, long messageId, long messageOperationId)
        {
            try
            {
                if (ApplicationSettings.DatabaseLogEnabled)
                {
                    azbMessageOperation.ResultCode = Enums.MessageOperationResultCode.NOK.ToString();
                    azbMessageOperation.ResultDetailMessage = exception.StackTrace;
                    azbMessageOperation.ProcessEndDate = DateTime.Now;

                    // Log Azure Process Message to Trace DB
                    await SaveServiceBusDBAsync(azbMessageOperation, Enums.AzbOperation.Process, messageId, messageOperationId);
                }
            }
            catch (Exception ex)
            {
                _log.Error($"SaveMessageExceptionToDb: {ex}");
            }
        }
        public async Task<long> SaveServiceBusDBAsync(Models.DB.AzureServiceBus.MessageOperation messageOperation, Enums.AzbOperation azbOperationType, long messageId)
        {
            return await SaveServiceBusDBAsync(messageOperation, azbOperationType, messageId, 0);
        }
        public async Task<long> SaveServiceBusDBAsync(Models.DB.AzureServiceBus.MessageOperation messageOperation, Enums.AzbOperation azbOperationType, long messageId, long messageOperationId)
        {
            using (Models.DB.AzureServiceBus.AgeasServiceBus_DVContext _dbContextServiceBus = new Models.DB.AzureServiceBus.AgeasServiceBus_DVContext())
            {
                // Insert
                var modelMessageOperation = await _dbContextServiceBus.MessageOperation
                                            .FirstOrDefaultAsync
                                            (x => x.Id.Equals(messageOperationId));

                if (modelMessageOperation == null)
                {
                    modelMessageOperation = new Models.DB.AzureServiceBus.MessageOperation();

                    // Insert
                    using (var transaction = _dbContextServiceBus.Database.BeginTransaction())
                    {
                        modelMessageOperation.MessageId = messageId;
                        modelMessageOperation.AzbOperationId = (int)azbOperationType;
                        modelMessageOperation.TopicName = _subscriptionClient.TopicPath;
                        modelMessageOperation.SubscriptionName = _subscriptionClient.SubscriptionName;
                        modelMessageOperation.ProcessInitialDate = DateTime.Now;
                        modelMessageOperation.ProcessEndDate = messageOperation.ProcessEndDate;
                        modelMessageOperation.ResultCode = messageOperation.ResultCode;
                        modelMessageOperation.ResultMessage = messageOperation.ResultMessage;
                        modelMessageOperation.ResultDetailMessage = messageOperation.ResultDetailMessage;
                        modelMessageOperation.AuditCreationDate = DateTime.Now;
                        modelMessageOperation.AuditUpdatedDate = messageOperation.AuditUpdatedDate;

                        _dbContextServiceBus.MessageOperation.Add(modelMessageOperation);

                        _log.Debug($"Request Inserted Successful");

                        try
                        {
                            await _dbContextServiceBus.SaveChangesAsync();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            _log.Error($"Error on save changes : {ex}");

                            transaction.Rollback();
                        }
                    }
                }
                else
                {
                    // Update
                    using (var transaction = _dbContextServiceBus.Database.BeginTransaction())
                    {
                        modelMessageOperation.AzbOperationId = (int)azbOperationType;
                        modelMessageOperation.ProcessEndDate = messageOperation.ProcessEndDate;
                        modelMessageOperation.ResultCode = messageOperation.ResultCode;
                        modelMessageOperation.ResultMessage = messageOperation.ResultMessage;
                        modelMessageOperation.ResultDetailMessage = messageOperation.ResultDetailMessage;
                        modelMessageOperation.AuditUpdatedDate = DateTime.Now;

                        _log.Debug($"Request Inserted Successful");

                        try
                        {
                            await _dbContextServiceBus.SaveChangesAsync();

                            transaction.Commit();
                        }
                        catch (Exception ex)
                        {
                            _log.Error($"Error on save changes : {ex}");

                            transaction.Rollback();
                        }
                    }
                }

                return modelMessageOperation.Id;
            }
        }
        public async Task<long> GetMessageIdByXCorrelationId(Message message, RequestServiceBus requestServiceBus)
        {
            using (Models.DB.AzureServiceBus.AgeasServiceBus_DVContext _dbContextServiceBus = new Models.DB.AzureServiceBus.AgeasServiceBus_DVContext())
            {
                string messageXCorrelationId = message.UserProperties["XCorrelationId"].ToString();

                var messageObj = await _dbContextServiceBus.Message
                                .FirstOrDefaultAsync
                                (x => x.XcorrelationId.Equals(messageXCorrelationId));

                if (messageObj == null)
                {
                    messageObj = await CreatFirstEntranceMessageIfNotExist(message, requestServiceBus, messageXCorrelationId);
                }

                return messageObj.Id;
            }
        }
        public async Task<Models.DB.AzureServiceBus.Message> CreatFirstEntranceMessageIfNotExist(Message message, RequestServiceBus requestServiceBus, string xCorrelationId)
        {
            using (Models.DB.AzureServiceBus.AgeasServiceBus_DVContext _dbContextServiceBus = new Models.DB.AzureServiceBus.AgeasServiceBus_DVContext())
            {
                Models.DB.AzureServiceBus.Message modelMessage = new Models.DB.AzureServiceBus.Message();

                // Insert
                using (var transaction = _dbContextServiceBus.Database.BeginTransaction())
                {
                    modelMessage.XcorrelationId = xCorrelationId;
                    modelMessage.DomainId = KeyTablesReference.GetDomains(requestServiceBus.Domain);
                    modelMessage.OperationId = KeyTablesReference.GetOperation(requestServiceBus.Operation);
                    modelMessage.Body = JsonConvert.SerializeObject(requestServiceBus);

                    DateTime messageCreateDate = message.SystemProperties.EnqueuedTimeUtc;

                    modelMessage.ProcessDate = messageCreateDate;
                    modelMessage.AuditCreationDate = messageCreateDate;
                    modelMessage.AuditUpdatedDate = messageCreateDate;

                    _dbContextServiceBus.Message.Add(modelMessage);

                    _log.Debug($"Request Inserted Successful");

                    try
                    {
                        await _dbContextServiceBus.SaveChangesAsync();

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        _log.Error($"Error on save changes : {ex}");

                        transaction.Rollback();
                    }
                }

                return modelMessage;
            }
        }
    }
}

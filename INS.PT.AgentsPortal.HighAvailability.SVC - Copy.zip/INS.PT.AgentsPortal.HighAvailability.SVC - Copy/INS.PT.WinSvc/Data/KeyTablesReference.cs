﻿using System;
using System.Collections.Generic;
using System.Text;

namespace INS.PT.WinSvc.Data
{
    static class KeyTablesReference
    {
        static Dictionary<string, string> _StatusSapToDuckCreek = new Dictionary<string, string>
        {
            { "A", "AN" },
            { "C", "CO" },
            { "E", "AB" },
            { "P", "PG" }
        };

        static Dictionary<string, int> _Operations = new Dictionary<string, int>
        {
            {"create", 1},
            {"read", 2},
            {"update", 3},
            {"delete", 4},
            {"commit", 5},
            {"policiesTransfer", 6},
            {"changeStructure", 7},
            {"agentClassification", 8},
            {"inspectorClassification", 9},
            {"combineEntity", 10},
            {"changeStatus", 11},
            {"updateCommercialStructure", 12}
        };

        static Dictionary<string, int> _Domains = new Dictionary<string, int>
        {
            {"policies", 1},
            {"entities", 2},
            {"type", 3},
            {"addresses", 4},
            {"contacts", 5},
            {"phones", 6},
            {"emails", 7},
            {"bankAccounts", 8},
            {"documents", 9},
            {"caes", 10},
            {"affinities", 11},
            {"claims", 12},
            {"receipts", 13},
            {"walletMovements", 14},
            {"commercialStructure", 15},
            {"requests", 16},
            {"quotations", 17},
            {"simulations", 18},
            {"proposals", 19}
        };

        public static string GetStatusSapToDuckCreek(string name)
        {
            // Try to get the result in the static Dictionary
            string result;

            if (_StatusSapToDuckCreek.TryGetValue(name, out result))
            {
                return result;
            }
            else
            {
                return string.Empty;
            }
        }
        public static int GetOperation(string name)
        {
            // Try to get the result in the static Dictionary
            int result;
            if (_Operations.TryGetValue(name, out result))
            {
                return result;
            }
            else
            {
                return 0;
            }
        }
        public static int GetDomains(string name)
        {
            // Try to get the result in the static Dictionary
            int result;
            if (_Domains.TryGetValue(name, out result))
            {
                return result;
            }
            else
            {
                return 0;
            }
        }
    }
}

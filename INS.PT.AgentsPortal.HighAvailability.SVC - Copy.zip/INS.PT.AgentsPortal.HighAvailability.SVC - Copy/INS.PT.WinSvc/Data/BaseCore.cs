﻿// Copyright Ageas 2019 © - Integration Team

using log4net;
using System.Diagnostics;

namespace INS.PT.AgentsPortal.WinSvc.Data
{
    class BaseCore
    {
        protected ILog _log = LogManager.GetLogger(typeof(BaseCore));

        protected Stopwatch _stopwatch = new Stopwatch();        
    }
}

﻿using System;
using System.ServiceModel;
using System.Threading.Tasks;
using EntitiesService;
using INS.PT.AgentsPortal.WinSvc.Data;
using INS.PT.AgentsPortal.WinSvc.Models;
using INS.PT.AgentsPortal.WinSvc.Models.Requests;
using INS.PT.AgentsPortal.WinSvc.Repository;
using LifeFinancialService;
using Newtonsoft.Json;

namespace INS.PT.WinSvc.Services
{
    class AiaService : BaseCore
    {
        /// <summary>
        /// Processes AIA Message.
        /// </summary>
        /// <param name="requestMessage">The request message.</param>
        public async Task<SendMessageResult> ProcessAiaMessage(RequestServiceBus inputMessage)
        {
            _log.Debug("Start ProcessAiaMessage");

            try
            {
                var binding = new BasicHttpsBinding(BasicHttpsSecurityMode.Transport)
                {
                    MaxReceivedMessageSize = int.MaxValue
                };

                EndpointAddress address = new EndpointAddress(ApplicationSettings.BrokerSoapEndPoint);

                using (EntitiesServiceClient service = new EntitiesServiceClient(binding, address))
                {
                    EntitiesService.AxisValues axisValues = new EntitiesService.AxisValues()
                    {
                        User = ApplicationSettings.BrokerSettingsBsUser,
                        Solution = ApplicationSettings.BrokerSettingsBsSolution
                    };

                    MaintainEntityTecInAIAWASPInputData inputData = new MaintainEntityTecInAIAWASPInputData()
                    {
                        EntityId = inputMessage.DomainId,
                        CompanyCode = inputMessage.Company,
                        NetworkCode = inputMessage.Network
                    };

                    _log.Debug($"Start calling AIA method: maintainEntityTecInAIAWASPAsync");

                    maintainEntityTecInAIAWASPResponse response = await service.maintainEntityTecInAIAWASPAsync(axisValues, inputData);

                    _log.Debug("End calling AIA method: maintainEntityTecInAIAWASPAsync");

                    if (response == null)
                    {
                        _log.Error($"Fail to maintainEntityTecInAIAWASPAsync");

                        return new SendMessageResult
                        {
                            Date = DateTime.Now,
                            Success = false,
                            Code = "-1",
                            Description = "Error calling maintainEntityTecInAIAWASPAsync"
                        };
                    }
                    else
                    {
                        _log.Debug($"End maintainEntityTecInAIAWASPAsync");

                        return new SendMessageResult
                        {
                            Date = DateTime.Now,
                            Success = response.maintainEntityTecInAIAWASPResult.status.Equals("0"),
                            Code = response.maintainEntityTecInAIAWASPResult.status,
                            Description = response.maintainEntityTecInAIAWASPResult.outputMessage
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                _log.Error($"Error ProcessAiaMessage: {ex.Message}");

                throw;
            }
        }

        public async Task<SendMessageResult> ProcessReceiptAiaMessage(RequestServiceBus inputMessage)
        {
            _log.Debug("Start ProcessReceiptAiaMessage");

            try
            {
                var binding = new BasicHttpsBinding(BasicHttpsSecurityMode.Transport)
                {
                    MaxReceivedMessageSize = int.MaxValue
                };

                EndpointAddress address = new EndpointAddress(ApplicationSettings.BrokerSoapEndPoint);

                using (WorkManagementClientSoapClient service = new WorkManagementClientSoapClient(binding, address))
                {
                    string errorDescription = string.Empty;

                    LifeFinancialService.AxisValues axisValues = new LifeFinancialService.AxisValues()
                    {
                        User = ApplicationSettings.BrokerSettingsBsUser,
                        Solution = ApplicationSettings.BrokerSettingsBsSolution
                    };

                    WMEnv environment = new WMEnv { UserID = ApplicationSettings.AIADocumentsCollectedCancelledUser };

                    DocumentsCollectedCancelledAIARequest inputData = new DocumentsCollectedCancelledAIARequest();
                    inputData.ActivityRequest = new ActivityRequest { EffectiveDate = inputMessage.Date ?? DateTime.Now };
                    inputData.Documents = new Documents();

                    string contractNumber = string.Empty;
                    string amount = "0";
                    string statusId = string.Empty;
                    DateTime? operationDate = null;

                    try
                    {
                        var detailInfo = JsonConvert.DeserializeObject(Convert.ToString(inputMessage.DetailedInfo))[0];

                        contractNumber = detailInfo["policyNumber"].Value;
                        amount = detailInfo["amount"].Value;
                        statusId = detailInfo["statusId"].Value;
                        operationDate = detailInfo["operationDate"]?.Value ?? DateTime.Now;
                    }
                    catch (Exception ex)
                    {
                        errorDescription = $"Fields detailedInfo -> contractNumber: {contractNumber}, amount: {amount}, statusId: {statusId} required! - OperationDate {operationDate}";

                        _log.Debug(errorDescription);

                        _log.Error(ex);

                        return new SendMessageResult
                        {
                            Date = DateTime.Now,
                            Success = false,
                            Code = "-1",
                            Description = errorDescription
                        };
                    }

                    Document doc = new Document {
                        ReferenceDocumentNumber = inputMessage.DomainId,
                        ContractNumber = contractNumber,
                        Amount = Convert.ToDecimal(amount),
                        AmountSpecified = true,
                        Status = statusId,
                        OperationDate = operationDate,
                        OperationDateSpecified = true
                    };

                    inputData.Documents.DocumentList = new Document[] { doc };

                    _log.Debug($"Start calling AIA method: DocumentsCollectedCancelledAIAAsync");

                    DocumentsCollectedCancelledAIAResponse response = await service.DocumentsCollectedCancelledAIAAsync(axisValues, environment, inputData.ActivityRequest, inputData.Documents);

                    _log.Debug("End calling AIA method: DocumentsCollectedCancelledAIAAsync");

                    if (response == null)
                    {
                        _log.Error($"Fail to DocumentsCollectedCancelledAIAAsync");

                        return new SendMessageResult
                        {
                            Date = DateTime.Now,
                            Success = false,
                            Code = "-1",
                            Description = "Error calling DocumentsCollectedCancelledAIAAsync"
                        };
                    }
                    else
                    {
                        _log.Debug($"End DocumentsCollectedCancelledAIAAsync");

                        return new SendMessageResult
                        {
                            Date = DateTime.Now,
                            Success = response.ReturnStatus.Code.Equals("WM_SUCCESS"),
                            Code = response.ReturnStatus.Code,
                            Description = JsonConvert.SerializeObject(response.ReturnStatus.ErrorList)
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                _log.Error($"Error ProcessReceiptAiaMessage: {ex.Message}");

                throw;
            }
        }
    }
}

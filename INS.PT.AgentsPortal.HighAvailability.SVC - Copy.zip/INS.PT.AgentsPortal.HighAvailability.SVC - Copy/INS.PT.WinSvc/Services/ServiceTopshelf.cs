// Copyright Ageas 2019 © - Integration Team

using log4net;
using System;
using System.IO;
using System.Reflection;
using INS.PT.AgentsPortal.WinSvc.Data;
using INS.PT.AgentsPortal.WinSvc.Repository;
using INS.PT.WinSvc.BrokerCalls;


namespace INS.PT.AgentsPortal.WinSvc.Services
{
    class ServiceTopshelf : BaseCore
    {
        private readonly IBrokerClient _brokerClient;
        public ServiceTopshelf(IBrokerClient brokerClient)
        {
            _brokerClient = brokerClient;

            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
            var assemblyFolder = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            var configFile = Path.Combine(assemblyFolder, ApplicationSettings.LogConfigFile);

            log4net.Config.XmlConfigurator.Configure(logRepository, new FileInfo(configFile));

            // Start log
            _log = LogManager.GetLogger(typeof(ServiceTopshelf));

            _log.Debug($"Start ServiceTopshelf Constructor - Inicialize LOG");
            Console.WriteLine($"Start ServiceTopshelf Constructor - Inicialize LOG");

            #region Claims

            _log.Debug($"Call Class Lister - Claims - {ApplicationSettings.AgeasPortalTopicClaimsEnabled}");

            if (ApplicationSettings.AgeasPortalTopicClaimsEnabled && ApplicationSettings.SubscriptionClaimsHighAvailabilityEnabled)
            {
                Listener listClaims = new Listener(_brokerClient);

                listClaims.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicClaims, ApplicationSettings.SubscriptionHighAvailability).GetAwaiter().GetResult();
            }

            #endregion

            #region Entities

            _log.Debug($"Call Class Lister - Entities - {ApplicationSettings.AgeasPortalTopicEntitiesEnabled}");

            if (ApplicationSettings.AgeasPortalTopicEntitiesEnabled)
            {
                // HighAvailability
                if (ApplicationSettings.SubscriptionEntitiesHighAvailabilityEnabled)
                {
                    Listener listEntities = new Listener(_brokerClient);

                    listEntities.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicEntities, ApplicationSettings.SubscriptionHighAvailability).GetAwaiter().GetResult();
                }
                // SAP
                if (ApplicationSettings.SubscriptionEntitiesSapEnabled)
                {
                    Listener listSap = new Listener(_brokerClient);

                    listSap.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicEntities, ApplicationSettings.SubscriptionSap).GetAwaiter().GetResult();
                }
                // Facets
                if (ApplicationSettings.SubscriptionEntitiesFacetsEnabled)
                {
                    Listener listFacets = new Listener(_brokerClient);

                    listFacets.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicEntities, ApplicationSettings.SubscriptionFacets).GetAwaiter().GetResult();
                }
                // AIA
                if (ApplicationSettings.SubscriptionEntitiesAiaEnabled)
                {
                    Listener listAia = new Listener(_brokerClient);

                    listAia.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicEntities, ApplicationSettings.SubscriptionAia).GetAwaiter().GetResult();
                }
                // MDM
                if (ApplicationSettings.SubscriptionEntitiesMdmEnabled)
                {
                    Listener listMdm = new Listener(_brokerClient);

                    listMdm.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicEntities, ApplicationSettings.SubscriptionMdm).GetAwaiter().GetResult();
                }
                // DuckCreek
                if (ApplicationSettings.SubscriptionEntitiesDuckCreekEnabled)
                {
                    Listener listDuckCreek = new Listener(_brokerClient);

                    listDuckCreek.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicEntities, ApplicationSettings.SubscriptionDuckCreek).GetAwaiter().GetResult();
                }
            }

            #endregion

            #region Policies

            _log.Debug($"Call Class Lister - Policies - {ApplicationSettings.AgeasPortalTopicPoliciesEnabled}");

            if (ApplicationSettings.AgeasPortalTopicPoliciesEnabled && ApplicationSettings.SubscriptionPoliciesHighAvailabilityEnabled)
            {
                Listener listPolicies = new Listener(_brokerClient);

                listPolicies.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicPolicies, ApplicationSettings.SubscriptionHighAvailability).GetAwaiter().GetResult();
            }

            #endregion

            #region Receipts

            _log.Debug($"Call Class Lister - Receipts - {ApplicationSettings.AgeasPortalTopicReceiptsEnabled}");

            if (ApplicationSettings.AgeasPortalTopicReceiptsEnabled && ApplicationSettings.SubscriptionReceiptsHighAvailabilityEnabled)
            {
                Listener listReceipts = new Listener(_brokerClient);

                listReceipts.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicReceipts, ApplicationSettings.SubscriptionHighAvailability).GetAwaiter().GetResult();
            }

            if (ApplicationSettings.AgeasPortalTopicReceiptsEnabled && ApplicationSettings.SubscriptionReceiptsDuckCreekEnabled)
            {
                Listener listReceipts = new Listener(_brokerClient);

                listReceipts.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicReceipts, ApplicationSettings.SubscriptionDuckCreek).GetAwaiter().GetResult();
            }

            if (ApplicationSettings.AgeasPortalTopicReceiptsEnabled && ApplicationSettings.SubscriptionReceiptsAiaEnabled)
            {
                Listener listReceipts = new Listener(_brokerClient);

                listReceipts.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicReceipts, ApplicationSettings.SubscriptionAia).GetAwaiter().GetResult();
            }

            #endregion

            #region Wallet Movements

            _log.Debug($"Call Class Lister - Quotations - {ApplicationSettings.AgeasPortalTopicWalletMovementsEnabled}");

            if (ApplicationSettings.AgeasPortalTopicWalletMovementsEnabled && ApplicationSettings.SubscriptionWalletMovementsHighAvailabilityEnabled)
            {
                Listener listWalletMovements = new Listener(_brokerClient);

                listWalletMovements.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicWalletMovements, ApplicationSettings.SubscriptionHighAvailability).GetAwaiter().GetResult();
            }
            #endregion

            #region Commercial Structure

            _log.Debug($"Call Class Lister - Commercial Structure - {ApplicationSettings.AgeasPortalTopicCommercialStructureEnabled}");

            if (ApplicationSettings.AgeasPortalTopicCommercialStructureEnabled)
            {
                if (ApplicationSettings.SubscriptionCommercialStructureHighAvailabilityEnabled)
                {
                    Listener listCommercialStructure = new Listener(_brokerClient);

                    listCommercialStructure.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicCommercialStructure, ApplicationSettings.SubscriptionHighAvailability).GetAwaiter().GetResult();
                }

                if (ApplicationSettings.SubscriptionCommercialStructureFacetsEnabled)
                {
                    Listener listFacetsCommercialStructure = new Listener(_brokerClient);

                    listFacetsCommercialStructure.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicCommercialStructure, ApplicationSettings.SubscriptionFacets).GetAwaiter().GetResult();
                }

                if (ApplicationSettings.SubscriptionCommercialStructureDuckCreekEnabled)
                {
                    Listener listCommercialStructureChangeNotification = new Listener(_brokerClient);

                    listCommercialStructureChangeNotification.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicCommercialStructure, ApplicationSettings.SubscriptionDuckCreek).GetAwaiter();
                }
            }

            #endregion

            #region Requests

            _log.Debug($"Call Class Lister - Requests -{ApplicationSettings.AgeasPortalTopicRequestsEnabled}");

            if (ApplicationSettings.AgeasPortalTopicRequestsEnabled && ApplicationSettings.SubscriptionRequestsHighAvailabilityEnabled)
            {
                Listener listRequests = new Listener(_brokerClient);

                listRequests.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicRequests, ApplicationSettings.SubscriptionHighAvailability).GetAwaiter().GetResult();
            }

            #endregion

            #region Quotations

            _log.Debug($"Call Class Lister - Quotations - {ApplicationSettings.AgeasPortalTopicQuotationsEnabled}");

            if (ApplicationSettings.AgeasPortalTopicQuotationsEnabled && ApplicationSettings.SubscriptionQuotationsHighAvailabilityEnabled)
            {
                Listener listQuotations = new Listener(_brokerClient);

                listQuotations.MainAsync(ApplicationSettings.ServiceBusConnectionString, ApplicationSettings.AgeasPortalTopicQuotations, ApplicationSettings.SubscriptionHighAvailability).GetAwaiter().GetResult();
            }

            #endregion
        }

        /// <summary>Start Listener</summary>
        public void Start()
        {
            _log.Debug("ServiceTopshelf - Started");
        }
        /// <summary>Stop Listener</summary>
        public void Stop()
        {
            _log.Debug("ServiceTopshelf - Stopped");
        }
    }
}

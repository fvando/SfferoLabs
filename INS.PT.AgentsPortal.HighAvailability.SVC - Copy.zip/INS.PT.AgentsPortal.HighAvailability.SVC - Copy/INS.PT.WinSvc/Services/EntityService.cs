﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using INS.PT.AgentsPortal.WinSvc.Data;
using INS.PT.AgentsPortal.WinSvc.Models;
using INS.PT.AgentsPortal.WinSvc.Models.Requests;
using INS.PT.AgentsPortal.WinSvc.Repository;
using INS.PT.WinSvc.BrokerCalls;
using INS.PT.WinSvc.Models.Requests;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace INS.PT.WinSvc.Services
{
    class EntityService : BaseCore
    {
        private readonly IBrokerClient _brokerClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="EntityService"/> class.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="brokerClient">Ageas Broker context</param>
        public EntityService(IBrokerClient brokerClient)
        {
            _brokerClient = brokerClient;
        }

        /// <summary>
        /// Processes the entity.
        /// </summary>
        /// <param name="requestMessage">The request message.</param>
        public async Task<SendMessageResult> ProcessGlobalEntityNotification(RequestServiceBus request)
        {
            _log.Debug($"Start ProcessGlobalEntityNotification");

            _brokerClient.BsWebService = ApplicationSettings.BrokerEntityWebService;
            _brokerClient.BsWebmethod = ApplicationSettings.BrokerEntityNotificationWebMethod;
            _brokerClient.AdicionalHeaders.TryAdd("IdCompany", "AGEAS");
            _brokerClient.AdicionalHeaders.TryAdd("IdNetwork", "AGEAS");
            _brokerClient.HttpVerb = "PUT";

            EntityNotificationInput inputMessage = new EntityNotificationInput
            {
                Source = request.Source?.ToUpper(),
                IdEntity = request.DomainId
            };

              var responseMsg = new SendMessageResult
              {
                  Date = DateTime.Now,
                  Success = false,
                  Code = "-1",
                  Description = "Error processing ProcessGlobalEntityNotification"
              };

            var response = await _brokerClient.RequestAsync<bool?>(string.Empty, null, inputMessage, 0, (ex) => {

                var data = (JObject)JsonConvert.DeserializeObject(ex.Call.Response.Content.ReadAsStringAsync().Result);

                responseMsg.Code = "-1";
                responseMsg.Description = JsonConvert.SerializeObject(data["InnerErrors"]);

                return false;
            });

            if (response == null || !(bool)response)
            {
                _log.Error($"Fail to ProcessGlobalEntityNotification");

                return responseMsg;
            }
            else
            {
                _log.Debug($"End ProcessGlobalEntityNotification");

                responseMsg.Code = "0";
                responseMsg.Description = string.Empty;
                responseMsg.Success = response.Value;

                return responseMsg;
            }
        }
    }
}

﻿using System;
using System.ServiceModel;
using System.Threading.Tasks;
using FacetsSupportService;
using INS.PT.AgentsPortal.WinSvc.Data;
using INS.PT.AgentsPortal.WinSvc.Repository;

namespace INS.PT.WinSvc.Services
{
    class FacetsSupportService : BaseCore
    {
        /// <summary>
        /// Processes Facets Message.
        /// </summary>
        /// <param name="requestMessage">The request message.</param>
        public async Task<createSyncLogWASPResponse> ProcessFacetsSupportMessage(Enumerations.FacetsSupportTypeCode typeCode, string message)
        {
            _log.Debug("Start ProcessFacetsSupportMessage");

            try
            {
                var binding = new BasicHttpsBinding(BasicHttpsSecurityMode.Transport)
                {
                    MaxReceivedMessageSize = int.MaxValue
                };

                EndpointAddress address = new EndpointAddress(ApplicationSettings.BrokerSoapEndPoint);

                using (FacetsApplicationSupportServiceClient service = new FacetsApplicationSupportServiceClient(binding, address))
                {
                    AxisValues axisValues = new AxisValues()
                    {
                        User = ApplicationSettings.BrokerSettingsBsUser,
                        Solution = ApplicationSettings.BrokerSettingsBsSolution
                    };

                    byte[] messageArray = System.Text.Encoding.UTF8.GetBytes(message);
                    var base64Message = Convert.ToBase64String(messageArray);

                    CreateSyncLogWASPInputData inputMessage = new CreateSyncLogWASPInputData()
                    {
                        syncLogTypeCode = typeCode.ToString(),
                        syncLogBase64 = base64Message
                    };

                    _log.Debug($"Start calling Facets method: createSyncLogWASPAsync - TypeCode: {typeCode} Base64Message: {base64Message}");

                    createSyncLogWASPResponse response = await service.createSyncLogWASPAsync(axisValues, inputMessage);

                    _log.Debug("End calling Facets method: createSyncLogWASPAsync");

                    if (response != null && response.createSyncLogWASPResult != null && response.createSyncLogWASPResult.status.Equals("0"))
                    {
                        _log.Debug($"Facets createSyncLogWASPAsync method response - OutputMessage: {response.createSyncLogWASPResult.outputMessage} SyncLogCK: {response.createSyncLogWASPResult.syncLogCK}");
                    }
                    else
                    {
                        _log.Debug("Error calling Facets method: createSyncLogWASPAsync");
                    }

                    return response;
                }
            }
            catch (Exception ex)
            {
                _log.Error($"Error ProcessFacetsSupportMessage: {ex}");

                throw;
            }
        }
    }
}

﻿using System;
using System.Threading.Tasks;
using INS.PT.AgentsPortal.WinSvc.Data;
using INS.PT.AgentsPortal.WinSvc.Models;
using INS.PT.AgentsPortal.WinSvc.Models.Requests;
using INS.PT.AgentsPortal.WinSvc.Repository;
using INS.PT.WinSvc.BrokerCalls;
using INS.PT.WinSvc.Helpers;
using INS.PT.WinSvc.Models.Requests;
using INS.PT.WinSvc.Models.Responses.Sap;
using Newtonsoft.Json;

namespace INS.PT.WinSvc.Services
{
    class CommonCollectionEntityService : BaseCore
    {
        private readonly IBrokerClient _brokerClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="CommonCollectionEntityService"/> class.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="brokerClient">Ageas Broker context</param>
        public CommonCollectionEntityService(IBrokerClient brokerClient)
        {
            _brokerClient = brokerClient;
        }

        /// <summary>
        /// Processes the entity.
        /// </summary>
        /// <param name="requestMessage">The request message.</param>
        public async Task<SendMessageResult> ProcessCommonCollectionEntityNotifyMessage(RequestServiceBus request)
        {
            _log.Debug($"Start ProcessCommonCollectionEntityNotifyMessage");

            CommonCollectionEntityInput inputMessage = new CommonCollectionEntityInput();

            inputMessage.Notification = JsonConvert.SerializeObject(request).SerializeJsonToXml("RequestServiceBus");

            _log.Debug($"SAP Entity Notify Input Message: {inputMessage.Notification}");

            _brokerClient.BsWebService = ApplicationSettings.BrokerCommonCollectionWebService;
            _brokerClient.BsWebmethod = ApplicationSettings.BrokerCommonCollectionNotifyWebMethod;
            _brokerClient.AdicionalHeaders.TryAdd("idCompany", "AGEAS");
            _brokerClient.AdicionalHeaders.TryAdd("idNetwork", "AGEAS");
            _brokerClient.HttpVerb = "POST";

            var response = await _brokerClient.RequestAsync<SapServiceNotificationWsResponse>(string.Empty, null, inputMessage);

            if (response?.ServiceNotificationWsResponse?.Errors?.Count > 0)
            {
                _log.Error($"Fail to ProcessCommonCollectionEntityNotifyMessage");

                return new SendMessageResult
                {
                    Date = DateTime.Now,
                    Success = false,
                    Code = "-1",
                    Description = JsonConvert.SerializeObject(response)
                };
            }
            else
            {
                _log.Debug($"End ProcessCommonCollectionEntityNotifyMessage");

                return new SendMessageResult
                {
                    Date = DateTime.Now,
                    Success = true,
                    Code = "0",
                    Description = string.Empty
                };
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using INS.PT.AgentsPortal.WinSvc.Data;
using INS.PT.AgentsPortal.WinSvc.Models;
using INS.PT.AgentsPortal.WinSvc.Models.Requests;
using INS.PT.AgentsPortal.WinSvc.Repository;
using INS.PT.WinSvc.BrokerCalls;
using INS.PT.WinSvc.Enumerations;
using INS.PT.WinSvc.Models.Requests;
using INS.PT.WinSvc.Models.Responses.Duckcreek.PushNotification;
using Newtonsoft.Json;

namespace INS.PT.WinSvc.Services
{
    class DuckCreekService : BaseCore
    {
        private readonly IBrokerClient _brokerClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="DuckCreekService"/> class.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="brokerClient">Ageas Broker context</param>
        public DuckCreekService(IBrokerClient brokerClient)
        {
            _brokerClient = brokerClient;
        }

        public async Task<SendMessageResult> PolicyTransferNotification(RequestServiceBus inputMessage)
        {
            _log.Debug("Start PolicyTransferNotification");

            string errorDescription = string.Empty;

            _brokerClient.BsWebService = ApplicationSettings.BrokerDuckCreekWebService;
            _brokerClient.BsWebmethod = ApplicationSettings.BrokerPolicyTransferNotificationWebMethod;
            _brokerClient.BsEndpoint = ApplicationSettings.BrokerInternalEndpoint;
            _brokerClient.AdicionalHeaders.TryAdd("AgeasUsername", ApplicationSettings.BrokerDuckCreekHeaderUserName);
            _brokerClient.HttpVerb = "POST";

            var agentSourceId = string.Empty;
            var agentDestinationId = string.Empty;
            var collectionAgentId = string.Empty;

            try
            {
                var detailInfo = JsonConvert.DeserializeObject(Convert.ToString(inputMessage.DetailedInfo))[0];

                agentSourceId = detailInfo["agent"]["sourceId"].Value;
                agentDestinationId = detailInfo["agent"]["destinationId"].Value;
                collectionAgentId = detailInfo["collectionAgent"]?["agentId"]?.Value;
            }
            catch (Exception ex)
            {
                errorDescription = $"Fields detailedInfo -> agent -> sourceId: {agentSourceId} and destinationId: {agentDestinationId} OR detailedInfo -> collectionAgent -> agentId: {collectionAgentId} required!";

                _log.Debug(errorDescription);

                _log.Error(ex);

                return new SendMessageResult
                {
                    Date = DateTime.Now,
                    Success = false,
                    Code = "-1",
                    Description = errorDescription
                };
            }

            var response = await _brokerClient.RequestAsync<BrokerClient.GenericResponseString>($"/{agentSourceId}/{agentDestinationId}/", new Dictionary<string, string> { { "collectionAgentReference", collectionAgentId } }, new { }, 0, (ex) => {

                errorDescription = ex.Message;

                return null;
            });

            if (response != null && response.Success)
            {
                _log.Debug($"End PolicyTransferNotification");

                return new SendMessageResult
                {
                    Date = DateTime.Now,
                    Success = true,
                    Code = "0",
                    Description = response.Response
                };
            }
            else
            {
                string message = !string.IsNullOrEmpty(errorDescription) ? errorDescription : "Error calling PolicyTransferNotification";

                _log.Error(message);

                return new SendMessageResult
                {
                    Date = DateTime.Now,
                    Success = false,
                    Code = "-1",
                    Description = message
                };
            }
        }
        public async Task<SendMessageResult> ReceiptsChangeNotifcation(RequestServiceBus inputMessage)
        {
            _log.Debug("Start ReceiptsNotifcation");

            string errorDescription = string.Empty;

            _brokerClient.BsEndpoint = ApplicationSettings.BrokerInternalEndpoint;
            _brokerClient.AdicionalHeaders.TryAdd("AgeasUsername", ApplicationSettings.BrokerDuckCreekHeaderUserName);
            _brokerClient.BsWebService = string.Empty;
            _brokerClient.BsWebmethod = string.Empty;
            _brokerClient.HttpVerb = "POST";

            string paymentMethod = string.Empty;
            string effectiveDate = string.Empty;
            string receiptType = string.Empty;
            string status = string.Empty;
            string accountabilityId = string.Empty;

            try
            {
                var detailInfo = JsonConvert.DeserializeObject(Convert.ToString(inputMessage.DetailedInfo))[0];

                paymentMethod = detailInfo["collectPaymentMethodId"].Value;
                effectiveDate = detailInfo["statusDate"].Value;
                receiptType = detailInfo["documentTypeId"].Value;
                status = detailInfo["statusId"].Value;
                accountabilityId = detailInfo["accountabilityId"]?.Value;
            }
            catch (Exception ex)
            {
                errorDescription = "Fields detailedInfo -> collectPaymentMethodId, statusDate, documentTypeId and statusId required!";

                _log.Debug(errorDescription);

                _log.Error(ex);

                return new SendMessageResult
                {
                    Date = DateTime.Now,
                    Success = false,
                    Code = "-1",
                    Description = errorDescription
                };
            }

            ReceiptChangeDCNotification receiptChangeDCNotification = new ReceiptChangeDCNotification { 
                PaymentMethod = paymentMethod,
                EffectiveDate = effectiveDate,
                ReceiptType = receiptType,
                Status = status,
                AccountabilityId = accountabilityId
            };

            _log.Debug($"Request: {JsonConvert.SerializeObject(receiptChangeDCNotification)}");

            var additionalRoute = $"/{ApplicationSettings.BrokerDuckCreekWebService}/{string.Format(ApplicationSettings.BrokerReceiptNotificationWebMethod, inputMessage.DomainId)}";
            var response = await _brokerClient.RequestAsync<BrokerClient.GenericResponseString>(additionalRoute, null, receiptChangeDCNotification, 0, (ex) => {
                errorDescription = ex.Message;
                return null;
            }, false);

            if (response != null && response.Success)
            {
                _log.Debug($"End ReceiptsNotifcation");

                return new SendMessageResult
                {
                    Date = DateTime.Now,
                    Success = true,
                    Code = "0",
                    Description = response.Response
                };
            }
            else
            {
                string message = !string.IsNullOrEmpty(errorDescription) ? errorDescription : "Error calling ReceiptsNotifcation";

                _log.Error(message);

                return new SendMessageResult
                {
                    Date = DateTime.Now,
                    Success = false,
                    Code = "-1",
                    Description = message
                };
            }
        }

        /// <summary>
        /// Processes the Notification.
        /// </summary>
        /// <param name="requestMessage">The request message.</param>
        public async Task<SendMessageResult> ProcessDuckCreekPushNotificationMessage(RequestServiceBus inputMessage)
        {
            _log.Debug($"Start ProcessDuckCreekPushNotificationMessage");

            _brokerClient.BsWebService = ApplicationSettings.BrokerDuckCreekWebService;
            _brokerClient.BsWebmethod = ApplicationSettings.BrokerDuckCreekNotificationWebMethod;
            _brokerClient.BsEndpoint = ApplicationSettings.BrokerInternalEndpoint;
            _brokerClient.AdicionalHeaders.TryAdd("AgeasUsername", ApplicationSettings.BrokerDuckCreekHeaderUserName);
            _brokerClient.HttpVerb = "POST";

            SendMessageResult sendResult = new SendMessageResult {
                Date = DateTime.Now
            };
            
            var response = await _brokerClient.RequestAsync<PushNotificationResponse>(string.Empty, null, inputMessage, 0, (ex) => { return null; });
            
            if (response != null)
            {
                string resultContent = JsonConvert.SerializeObject(response);

                sendResult.Description = resultContent;

                if (response.Type.Status.ToLower().Equals("success") && response.Type.Message.ToLower().Equals("ok"))
                {
                    sendResult.Success = true;
                    sendResult.Code = "0";

                    _log.Error($"Success ProcessDuckCreekPushNotificationMessage - Response: {resultContent}");
                }
                else
                {
                    sendResult.Success = false;
                    sendResult.Code = "-1";

                    _log.Error($"Failed to ProcessDuckCreekPushNotificationMessage - Response: {resultContent}");
                }
            }
            else
            {
                sendResult.Success = false;
                sendResult.Code = "-1";
                sendResult.Description = "Failed to ProcessDuckCreekPushNotificationMessage";

                _log.Error("Failed to ProcessDuckCreekPushNotificationMessage");
            }

            return sendResult;
        }

        /// <summary>
        /// Processes the Commercial Structure Change Notification.
        /// </summary>
        /// <param name="requestMessage">The request message.</param>
        public async Task<SendMessageResult> ProcessCommercialStructureChangeNotificationMessage(RequestServiceBus inputMessage)
        {
            return await ProcessCommercialStructureOrAgentClassificationMessage(inputMessage, DuckCreekNotificationType.CommercialStructureChangeNotification);
        }

        /// <summary>
        /// Processes the Commercial Structure Change Notification.
        /// </summary>
        /// <param name="requestMessage">The request message.</param>
        public async Task<SendMessageResult> ProcessAgentClassificationMessage(RequestServiceBus inputMessage)
        {
            return await ProcessCommercialStructureOrAgentClassificationMessage(inputMessage, DuckCreekNotificationType.AgentClassification);
        }

        /// <summary>
        /// Processes the Commercial Structure Change or Agent Classification Notification.
        /// </summary>
        /// <param name="requestMessage">The request message.</param>
        private async Task<SendMessageResult> ProcessCommercialStructureOrAgentClassificationMessage(RequestServiceBus inputMessage, DuckCreekNotificationType duckCreekNotificationType)
        {
            _log.Debug($"Start ProcessCommercialStructureOrAgentClassificationMessage");

            var sendResult = new SendMessageResult();

            if (inputMessage.Date == null || inputMessage.Date == DateTime.MinValue)
            {
                inputMessage.Date = DateTime.Now;
            }

            _brokerClient.BsWebService = ApplicationSettings.BrokerDuckCreekWebService;

            switch (duckCreekNotificationType)
            {
                case DuckCreekNotificationType.CommercialStructureChangeNotification:
                    _brokerClient.BsWebmethod = ApplicationSettings.BrokerCommercialStructureChangeNotificationWebMethod;
                    break;
                case DuckCreekNotificationType.AgentClassification:
                    _brokerClient.BsWebmethod = ApplicationSettings.BrokerAgentClassificationDeltaWebMethod;
                    break;
                default:
                    break;
            }

            _brokerClient.BsEndpoint = $"{ApplicationSettings.BrokerInternalEndpoint}";
            _brokerClient.AdicionalHeaders.TryAdd("AgeasUsername", ApplicationSettings.BrokerDuckCreekHeaderUserName);
            _brokerClient.HttpVerb = "GET";

            var response = await _brokerClient.RequestAsync
                (string.Empty, new Dictionary<string, string> { { "date", inputMessage.Date?.ToString("yyyy-MM-dd") } }, new { }, 0, (ex) => 
                {
                    sendResult.Date = DateTime.Now;
                    sendResult.Success = false;
                    sendResult.Code = "-1";
                    sendResult.Description = ex.Message;

                    return new Models.Responses.Duckcreek.CommercialStructureUpdate
                    {
                        Failurecount = 1,
                        ImportFailures = new List<string>
                        {
                            ex.Message
                        }
                    };
                });

            if (response.Failurecount > 0 || response.SuccessCount <= 0 && response.ImportFailures.Any())
            {
                _log.Error($"Fail to ProcessCommercialStructureOrAgentClassificationMessage: {sendResult.Description}");

                return sendResult;
            }
            else
            {
                _log.Debug($"End ProcessCommercialStructureOrAgentClassificationMessage");

                sendResult.Date = DateTime.Now;
                sendResult.Success = true;
                sendResult.Code = "0";
                sendResult.Description = string.Empty;

                return sendResult;
            }
        }
    }
}

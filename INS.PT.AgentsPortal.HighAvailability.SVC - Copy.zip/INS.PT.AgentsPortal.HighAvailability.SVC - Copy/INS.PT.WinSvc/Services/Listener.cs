// Copyright Ageas 2019 © - Integration Team

using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using INS.PT.AgentsPortal.WinSvc.Data;
using INS.PT.AgentsPortal.WinSvc.Models;
using INS.PT.AgentsPortal.WinSvc.Models.Requests;
using INS.PT.AgentsPortal.WinSvc.Repository;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.WinSvc.BrokerCalls;
using INS.PT.WinSvc.Enumerations;
using INS.PT.WinSvc.Helpers;
using INS.PT.WinSvc.Services;
using Microsoft.Azure.ServiceBus;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace INS.PT.AgentsPortal.WinSvc.Services
{
    class Listener : BaseCore
    {
        INS.PT.WinSvc.Models.DB.AzureServiceBus.MessageOperation azbMessageOperation = new PT.WinSvc.Models.DB.AzureServiceBus.MessageOperation();
        ServicesBusDb serviceBusDb = null;

        private readonly IBrokerClient _brokerClient;
        ISubscriptionClient _subscriptionClient;

        public Listener(IBrokerClient brokerClient)
        {
            _brokerClient = brokerClient;
        }

        /// <summary>
        /// Mains the asynchronous.
        /// </summary>
        /// <param name="ServiceBusConnectionString">The service bus connection string.</param>
        /// <param name">Name of the topic.</param>
        /// <param name="SubscriptionName">Name of the subscription.</param>
        /// <returns></returns>
        public async Task MainAsync(string ServiceBusConnectionString, string TopicName, string SubscriptionName)
        {
            try
            {
                _log.Debug($"Start Read Async Messages Service");
                Console.WriteLine($"Start Read Async Messages Service");

                _log.Debug($"Create QueueClient Object ({TopicName}) - ({SubscriptionName})");
                Console.WriteLine($"Create QueueClient Object ({TopicName}) - ({SubscriptionName})");

                //TODO: check if this source code is really necessary 
                // ProxySettingsUseProxy
                try
                {
                    if (ApplicationSettings.ProxySettingsUseProxy)
                    {
                        WebProxy proxy = new WebProxy($"{ApplicationSettings.ProxySettingsProxyHost}:{ApplicationSettings.ProxySettingsProxyPort}");

                        List<string> bypasslist = new List<string>
                    {
                        ApplicationSettings.ProxySettingsProxyByPassList
                    };
                        proxy.BypassList = bypasslist.ToArray();

                        WebRequest.DefaultWebProxy = proxy;
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error Instantitie WebProxy" + ex);
                    _log.Error($"Error Instantitie WebProxy : " + ex);
                    throw;
                }

                _log.Debug($"Create subscriptionClient");
                Console.WriteLine($"Create subscriptionClient");
                _subscriptionClient = new SubscriptionClient(ServiceBusConnectionString, TopicName, SubscriptionName);

                _log.Debug($"Start TransportType");
                Console.WriteLine($"Start TransportType");
                _subscriptionClient.ServiceBusConnection.TransportType = Microsoft.Azure.ServiceBus.TransportType.AmqpWebSockets;

                serviceBusDb = new ServicesBusDb(_subscriptionClient);

                _log.Debug($"Register QueueClient's MessageHandler and receive messages in a loop");
                Console.WriteLine($"Register QueueClient's MessageHandler and receive messages in a loop");

                RegisterOnMessageHandlerAndReceiveMessages(TopicName, SubscriptionName);
            }
            catch (Exception ex)
            {
                _log.Error(ex);

                throw;
            }
        }

        /// <summary>Configure the MessageHandler Options in terms of exception handling, number of concurrent messages to deliver etc.</summary>
        public void RegisterOnMessageHandlerAndReceiveMessages(string topicName, string subscriptionName)
        {
            // Configure the MessageHandler Options in terms of exception handling, number of concurrent messages to deliver etc.
            var messageHandlerOptions = new MessageHandlerOptions(ExceptionReceivedHandler)
            {
                // Maximum number of Concurrent calls to the callback `ProcessMessagesAsync`, set to 1 for simplicity.
                // Set it according to how many messages the application wants to process in parallel.
                MaxConcurrentCalls = ApplicationSettings.MaxConcurrentCalls,

                // Indicates whether MessagePump should automatically complete the messages after returning from User Callback.
                // False below indicates the Complete will be handled by the User Callback as in `ProcessMessagesAsync` below.
                AutoComplete = ApplicationSettings.AutoComplete,
            };

            // Register the function that will process messages
            _log.Debug($"Register the function that will process messages");
            Console.WriteLine($"Register the function that will process messages");

            // Topic = Entities
            // Subscriber = SAP
            if (topicName == ApplicationSettings.AgeasPortalTopicEntities &&
                subscriptionName == ApplicationSettings.SubscriptionSap)
            {
                _subscriptionClient.RegisterMessageHandler(ProcessEntitiesSapMessagesAsync, messageHandlerOptions);
            }
            // Topic = Entities
            // Subscriber = AIA
            else if (topicName == ApplicationSettings.AgeasPortalTopicEntities &&
                subscriptionName == ApplicationSettings.SubscriptionAia)
            {
                _subscriptionClient.RegisterMessageHandler(ProcessEntitiesAiaMessagesAsync, messageHandlerOptions);
            }
            // Topic = Entities
            // Subscriber = MDM
            else if (topicName == ApplicationSettings.AgeasPortalTopicEntities &&
                subscriptionName == ApplicationSettings.SubscriptionMdm)
            {
                _subscriptionClient.RegisterMessageHandler(ProcessGlobalEntityNotification, messageHandlerOptions);
            }
            // Subscriber = Facets
            else if (subscriptionName == ApplicationSettings.SubscriptionFacets)
            {
                _subscriptionClient.RegisterMessageHandler(ProcessFacetsMessagesAsync, messageHandlerOptions);
            }
            // Topic = Commercial Structure
            // Subscriber = DuckCreek
            else if (topicName == ApplicationSettings.AgeasPortalTopicCommercialStructure &&
                subscriptionName == ApplicationSettings.SubscriptionDuckCreek)
            {
                _subscriptionClient.RegisterMessageHandler(ProcessCSOrAgentClassificationMessagesAsync, messageHandlerOptions);
            }
            // Topic = Receipts
            // Subscriber = DuckCreek
            else if (topicName == ApplicationSettings.AgeasPortalTopicReceipts &&
                subscriptionName == ApplicationSettings.SubscriptionDuckCreek)
            {
                _subscriptionClient.RegisterMessageHandler(ProcessReceiptChangeNotificationAsync, messageHandlerOptions);
            }
            else if (topicName == ApplicationSettings.AgeasPortalTopicReceipts &&
                subscriptionName == ApplicationSettings.SubscriptionAia)
            {
                _subscriptionClient.RegisterMessageHandler(ProcessReceiptAiaMessagesAsync, messageHandlerOptions);
            }
            // Subscriber = DuckCreek
            else if (subscriptionName == ApplicationSettings.SubscriptionDuckCreek)
            {
                _subscriptionClient.RegisterMessageHandler(ProcessDuckCreekMessagesAsync, messageHandlerOptions);
            }
            // Subscriber = HighAvailability
            else if (subscriptionName == ApplicationSettings.SubscriptionHighAvailability)
            {
                _subscriptionClient.RegisterMessageHandler(ProcessMessagesAsync, messageHandlerOptions);
            }
            else
            {
                _log.Warn($"Subscription not found: TopicName: {topicName} - SubscriberName: {subscriptionName}");
            }

            //TODO: bellow source code serves only for Sessions POC purposes (and untill the idea is discarded)
            //_subscriptionClient.RegisterSessionHandler(HandleSessionAsync, new SessionHandlerOptions(x => { return Task.CompletedTask; }){ AutoComplete = false, MaxConcurrentSessions = 1 });
        }

        /// <summary>
        /// Process Messages Async Entity Notification
        /// </summary>
        /// <param name="message"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public async Task ProcessGlobalEntityNotification(Message message, CancellationToken token)
        {
            _stopwatch.Restart();
            _stopwatch.Start();

            _log.Debug($"Start ProcessGlobalEntityNotification");

            long messageId = 0;
            long messageOperationId = 0;

            try
            {
                // Process the message
                var requestMessage = JsonConvert.DeserializeObject<RequestServiceBus>(Encoding.UTF8.GetString(message.Body));

                if (requestMessage.Operation.ToUpper().Equals("COMMIT"))
                {
                    _log.Debug($"Start ProcessGlobalEntityNotification Request: {JsonConvert.SerializeObject(requestMessage)}");

                    if (ApplicationSettings.DatabaseLogEnabled)
                    {
                        // Get Message Id
                        messageId = await serviceBusDb.GetMessageIdByXCorrelationId(message, requestMessage);

                        // Log Azure Get Message to Trace DB
                        await serviceBusDb.SaveServiceBusDBGetMessageStepAsync(messageId);

                        azbMessageOperation = new PT.WinSvc.Models.DB.AzureServiceBus.MessageOperation();

                        // Log Azure Sent Message to Trace DB
                        messageOperationId = await serviceBusDb.SaveServiceBusDBAsync(azbMessageOperation, Enums.AzbOperation.Send, messageId);
                    }

                    EntityService entityService = new EntityService(_brokerClient);

                    SendMessageResult sendResult = await entityService.ProcessGlobalEntityNotification(requestMessage);

                    _log.Debug($"End ProcessGlobalEntityNotification Request");

                    _log.Debug($"ProcessGlobalEntityNotification Response: {JsonConvert.SerializeObject(sendResult)}");

                    await SaveServiceBusDBAsync(sendResult, azbMessageOperation, messageId, messageOperationId);

                    await SendToDeadLetterOrComplete(_subscriptionClient, message, sendResult);
                }
            }
            catch (Exception ex)
            {
                _log.Error($"ProcessGlobalEntityNotification Exception: {ex}");

                await serviceBusDb.SaveMessageExceptionToDb(azbMessageOperation, ex, messageId, messageOperationId);

                throw;
            }

            _stopwatch.Stop();

            _log.Debug($"End ProcessGlobalEntityNotification : {_stopwatch.Elapsed.TotalMilliseconds}ms");
        }

        /// <summary>
        /// Process Messages Async Entities SAP
        /// </summary>
        /// <param name="message"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public async Task ProcessEntitiesSapMessagesAsync(Message message, CancellationToken token)
        {
            _stopwatch.Restart();
            _stopwatch.Start();

            _log.Debug($"Start ProcessEntitiesSapMessagesAsync");

            long messageId = 0;
            long messageOperationId = 0;

            try
            {
                // Process the message
                var requestMessage = JsonConvert.DeserializeObject<RequestServiceBus>(Encoding.UTF8.GetString(message.Body));

                _log.Debug($"Start SAP Request: {JsonConvert.SerializeObject(requestMessage)}");

                if (ApplicationSettings.DatabaseLogEnabled)
                {
                    // Get Message Id
                    messageId = await serviceBusDb.GetMessageIdByXCorrelationId(message, requestMessage);

                    // Log Azure Get Message to Trace DB
                    await serviceBusDb.SaveServiceBusDBGetMessageStepAsync(messageId);

                    azbMessageOperation = new PT.WinSvc.Models.DB.AzureServiceBus.MessageOperation();
                    // Log Azure Sent Message to Trace DB
                    messageOperationId = await serviceBusDb.SaveServiceBusDBAsync(azbMessageOperation, Enums.AzbOperation.Send, messageId);
                }

                CommonCollectionEntityService commonCollectionService = new CommonCollectionEntityService(_brokerClient);

                SendMessageResult sendResult = await commonCollectionService.ProcessCommonCollectionEntityNotifyMessage(requestMessage);

                _log.Debug($"End SAP Request");

                _log.Debug($"SAP Response: {JsonConvert.SerializeObject(sendResult)}");

                await SaveServiceBusDBAsync(sendResult, azbMessageOperation, messageId, messageOperationId);

                await SendToDeadLetterOrComplete(_subscriptionClient, message, sendResult);
            }
            catch (Exception ex)
            {
                _log.Error($"ProcessEntitiesSapMessagesAsync Exception: {ex}");

                await serviceBusDb.SaveMessageExceptionToDb(azbMessageOperation, ex, messageId, messageOperationId);

                throw;
            }

            _stopwatch.Stop();

            //Log
            _log.Debug($"End ProcessEntitiesSapMessagesAsync : {_stopwatch.Elapsed.TotalMilliseconds}ms");
        }

        /// <summary>
        /// Process Messages Async Facets
        /// </summary>
        /// <param name="message"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public async Task ProcessFacetsMessagesAsync(Message message, CancellationToken token)
        {
            _stopwatch.Restart();
            _stopwatch.Start();

            _log.Debug($"Start ProcessFacetsMessagesAsync");

            // Process the message
            var requestMessage = JsonConvert.DeserializeObject<RequestServiceBus>(Encoding.UTF8.GetString(message.Body));

            //operation result detailed info
            SendMessageResult sendResult = new SendMessageResult();

            _log.Debug($"Start Facets Request: {JsonConvert.SerializeObject(requestMessage)}");

            long messageId = 0;
            long messageOperationId = 0;

            try
            {
                if (ApplicationSettings.DatabaseLogEnabled)
                {
                    // Get Message Id
                    messageId = await serviceBusDb.GetMessageIdByXCorrelationId(message, requestMessage);

                    // Log Azure Get Message to Trace DB
                    await serviceBusDb.SaveServiceBusDBGetMessageStepAsync(messageId);

                    azbMessageOperation = new PT.WinSvc.Models.DB.AzureServiceBus.MessageOperation();
                    // Log Azure Sent Message to Trace DB
                    messageOperationId = await serviceBusDb.SaveServiceBusDBAsync(azbMessageOperation, Enums.AzbOperation.Send, messageId);
                }

                INS.PT.WinSvc.Services.FacetsSupportService facetsService = new INS.PT.WinSvc.Services.FacetsSupportService();
                FacetsSupportService.createSyncLogWASPResponse response = await facetsService.ProcessFacetsSupportMessage(FacetsSupportTypeCode.SLET, JsonConvert.SerializeObject(requestMessage));

                _log.Debug($"End Facets Request");

                if (response != null && response.createSyncLogWASPResult.status.Equals("0"))
                {
                    sendResult.Success = true;
                    sendResult.Date = DateTime.Now;
                    sendResult.Code = response.createSyncLogWASPResult.status;
                    sendResult.Description = response.createSyncLogWASPResult.outputMessage;
                }
                else
                {
                    sendResult.Success = false;
                    sendResult.Date = DateTime.Now;
                    sendResult.Code = response?.createSyncLogWASPResult?.status;
                    sendResult.Description = response?.createSyncLogWASPResult?.outputMessage;
                }

                _log.Debug($"Facets Response: {JsonConvert.SerializeObject(sendResult)}");

                await SaveServiceBusDBAsync(sendResult, azbMessageOperation, messageId, messageOperationId);

                await SendToDeadLetterOrComplete(_subscriptionClient, message, sendResult);
            }
            catch (Exception ex)
            {
                _log.Error($"ProcessFacetsMessagesAsync Exception: {ex}");

                await serviceBusDb.SaveMessageExceptionToDb(azbMessageOperation, ex, messageId, messageOperationId);

                throw;
            }

            _stopwatch.Stop();

            //Log
            _log.Debug($"End ProcessFacetsMessagesAsync : {_stopwatch.Elapsed.TotalMilliseconds}ms");
        }

        /// <summary>
        /// Process Messages Async DuckCreek
        /// </summary>
        /// <param name="message"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public async Task ProcessDuckCreekMessagesAsync(Message message, CancellationToken token)
        {
            _stopwatch.Restart();
            _stopwatch.Start();

            _log.Debug($"Start ProcessDuckCreekMessagesAsync");

            // Process the message
            var requestMessage = JsonConvert.DeserializeObject<RequestServiceBus>(Encoding.UTF8.GetString(message.Body));

            _log.Debug($"Start DuckCreek Request: {JsonConvert.SerializeObject(requestMessage)}");

            long messageId = 0;
            long messageOperationId = 0;

            try
            {
                if (ApplicationSettings.DatabaseLogEnabled)
                {
                    // Get Message Id
                    messageId = await serviceBusDb.GetMessageIdByXCorrelationId(message, requestMessage);

                    // Log Azure Get Message to Trace DB
                    await serviceBusDb.SaveServiceBusDBGetMessageStepAsync(messageId);

                    azbMessageOperation = new PT.WinSvc.Models.DB.AzureServiceBus.MessageOperation();
                    // Log Azure Sent Message to Trace DB
                    messageOperationId = await serviceBusDb.SaveServiceBusDBAsync(azbMessageOperation, Enums.AzbOperation.Send, messageId);
                }

                DuckCreekService commonCollectionService = new DuckCreekService(_brokerClient);
                SendMessageResult sendResult = await commonCollectionService.ProcessDuckCreekPushNotificationMessage(requestMessage);

                _log.Debug($"End DuckCreek Request");

                await SaveServiceBusDBAsync(sendResult, azbMessageOperation, messageId, messageOperationId);

                await SendToDeadLetterOrComplete(_subscriptionClient, message, sendResult);
            }
            catch (Exception ex)
            {
                _log.Error($"ProcessDuckCreekMessagesAsync Exception: {ex}");

                await serviceBusDb.SaveMessageExceptionToDb(azbMessageOperation, ex, messageId, messageOperationId);

                throw;
            }

            _stopwatch.Stop();

            //Log
            _log.Debug($"End ProcessDuckCreekMessagesAsync : {_stopwatch.Elapsed.TotalMilliseconds}ms");
        }

        /// <summary>
        /// Process Messages Async Commercial Structure Change Notification
        /// </summary>
        /// <param name="message"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public async Task ProcessCSOrAgentClassificationMessagesAsync(Message message, CancellationToken token)
        {
            _stopwatch.Restart();
            _stopwatch.Start();

            _log.Debug($"Start ProcessCommercialStructurChangeOrAgentClassificationMessagesAsync");

            // Process the message
            var requestMessage = JsonConvert.DeserializeObject<RequestServiceBus>(Encoding.UTF8.GetString(message.Body));

            //operation result detailed info
            SendMessageResult sendResult = null;

            DuckCreekService duckCreekService = new DuckCreekService(_brokerClient);

            _log.Debug($"Start ProcessCommercialStructurChangeOrAgentClassificationMessagesAsync Request: {JsonConvert.SerializeObject(requestMessage)}");

            long messageId = 0;
            long messageOperationId = 0;

            try
            {
                if (ApplicationSettings.DatabaseLogEnabled)
                {
                    // Get Message Id
                    messageId = await serviceBusDb.GetMessageIdByXCorrelationId(message, requestMessage);

                    // Log Azure Get Message to Trace DB
                    await serviceBusDb.SaveServiceBusDBGetMessageStepAsync(messageId);

                    azbMessageOperation = new PT.WinSvc.Models.DB.AzureServiceBus.MessageOperation();
                    // Log Azure Sent Message to Trace DB
                    messageOperationId = await serviceBusDb.SaveServiceBusDBAsync(azbMessageOperation, Enums.AzbOperation.Send, messageId);
                }

                if (requestMessage.Operation.ToUpper().Equals("CHANGESTRUCTURE"))
                {
                    _log.Debug("Operation - ChangeStructure");

                    sendResult = await duckCreekService.ProcessCommercialStructureChangeNotificationMessage(requestMessage);

                    await SaveServiceBusDBAsync(sendResult, azbMessageOperation, messageId, messageOperationId);

                    await SendToDeadLetterOrComplete(_subscriptionClient, message, sendResult);
                }
                else if (requestMessage.Operation.ToUpper().Equals("AGENTCLASSIFICATION"))
                {
                    _log.Debug("Operation - AgentClassification");

                    sendResult = await duckCreekService.ProcessAgentClassificationMessage(requestMessage);

                    await SaveServiceBusDBAsync(sendResult, azbMessageOperation, messageId, messageOperationId);

                    await SendToDeadLetterOrComplete(_subscriptionClient, message, sendResult);
                }
                else if (requestMessage.Operation.ToUpper().Equals("POLICIESTRANSFER"))
                {
                    _log.Debug("Operation - PoliciesTransfer");

                    sendResult = await duckCreekService.PolicyTransferNotification(requestMessage);

                    await SaveServiceBusDBAsync(sendResult, azbMessageOperation, messageId, messageOperationId);

                    await SendToDeadLetterOrComplete(_subscriptionClient, message, sendResult);
                }

                _log.Debug($"End ProcessCommercialStructurChangeOrAgentClassificationMessagesAsync Response: {JsonConvert.SerializeObject(sendResult)}");
            }
            catch (Exception ex)
            {
                _log.Error($"ProcessCSOrAgentClassificationMessagesAsync Exception: {ex}");

                await serviceBusDb.SaveMessageExceptionToDb(azbMessageOperation, ex, messageId, messageOperationId);

                throw;
            }

            _stopwatch.Stop();

            _log.Debug($"End ProcessCommercialStructurChangeOrAgentClassificationMessagesAsync : {_stopwatch.Elapsed.TotalMilliseconds}ms");
        }

        /// <summary>
        /// Process Messages Async AIA Notification
        /// </summary>
        /// <param name="message"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public async Task ProcessEntitiesAiaMessagesAsync(Message message, CancellationToken token)
        {
            _stopwatch.Restart();
            _stopwatch.Start();

            _log.Debug($"Start ProcessEntitiesAiaMessagesAsync");

            // Process the message
            var requestMessage = JsonConvert.DeserializeObject<RequestServiceBus>(Encoding.UTF8.GetString(message.Body));

            _log.Debug($"Start ProcessEntitiesAiaMessages Request: {JsonConvert.SerializeObject(requestMessage)}");

            long messageId = 0;
            long messageOperationId = 0;

            try
            {
                if (ApplicationSettings.DatabaseLogEnabled)
                {
                    // Get Message Id
                    messageId = await serviceBusDb.GetMessageIdByXCorrelationId(message, requestMessage);

                    // Log Azure Get Message to Trace DB
                    await serviceBusDb.SaveServiceBusDBGetMessageStepAsync(messageId);

                    azbMessageOperation = new PT.WinSvc.Models.DB.AzureServiceBus.MessageOperation();
                    // Log Azure Sent Message to Trace DB
                    messageOperationId = await serviceBusDb.SaveServiceBusDBAsync(azbMessageOperation, Enums.AzbOperation.Send, messageId);
                }

                SendMessageResult sendResult = await new AiaService().ProcessAiaMessage(requestMessage);

                _log.Debug($"End ProcessEntitiesAiaMessages Request");

                _log.Debug($"ProcessEntitiesAiaMessagesAsync Response: {JsonConvert.SerializeObject(sendResult)}");

                await SaveServiceBusDBAsync(sendResult, azbMessageOperation, messageId, messageOperationId);

                await SendToDeadLetterOrComplete(_subscriptionClient, message, sendResult);
            }
            catch (Exception ex)
            {
                _log.Error($"ProcessEntitiesAiaMessagesAsync Exception: {ex}");

                await serviceBusDb.SaveMessageExceptionToDb(azbMessageOperation, ex, messageId, messageOperationId);

                throw;
            }

            _stopwatch.Stop();

            //Log
            _log.Debug($"End ProcessAiaMessagesAsync : {_stopwatch.Elapsed.TotalMilliseconds}ms");
        }

        /// <summary>
        /// Process Messages Async ReceiptChangeNotification
        /// </summary>
        /// <param name="message"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public async Task ProcessReceiptChangeNotificationAsync(Message message, CancellationToken token)
        {
            _stopwatch.Restart();
            _stopwatch.Start();

            _log.Debug($"Start ProcessReceiptChangeNotificationAsync");

            // Process the message
            var requestMessage = JsonConvert.DeserializeObject<RequestServiceBus>(Encoding.UTF8.GetString(message.Body));

            _log.Debug($"Start DuckCreek Request: {JsonConvert.SerializeObject(requestMessage)}");

            long messageId = 0;
            long messageOperationId = 0;

            try
            {
                if (ApplicationSettings.DatabaseLogEnabled)
                {
                    // Get Message Id
                    messageId = await serviceBusDb.GetMessageIdByXCorrelationId(message, requestMessage);

                    // Log Azure Get Message to Trace DB
                    await serviceBusDb.SaveServiceBusDBGetMessageStepAsync(messageId);

                    azbMessageOperation = new PT.WinSvc.Models.DB.AzureServiceBus.MessageOperation();
                    // Log Azure Sent Message to Trace DB
                    messageOperationId = await serviceBusDb.SaveServiceBusDBAsync(azbMessageOperation, Enums.AzbOperation.Send, messageId);
                }

                var brokerClient = new BrokerClient(_log, _brokerClient);

                DuckCreekService commonCollectionService = new DuckCreekService(brokerClient);
                
                SendMessageResult sendResult = await commonCollectionService.ReceiptsChangeNotifcation(requestMessage);

                _log.Debug($"End DuckCreek Request");

                if (sendResult != null)
                {
                    sendResult.Date = DateTime.Now;
                    sendResult.Code = sendResult.Code;
                    sendResult.Description = sendResult.Description;
                }
                else
                {
                    sendResult.Date = DateTime.Now;
                    sendResult.Code = "-1";
                    sendResult.Description = "Error processing ProcessReceiptChangeNotificationAsync";
                }

                _log.Debug($"DuckCreek Response: {JsonConvert.SerializeObject(sendResult)}");

                await SaveServiceBusDBAsync(sendResult, azbMessageOperation, messageId, messageOperationId);

                await SendToDeadLetterOrComplete(_subscriptionClient, message, sendResult);
            }
            catch (Exception ex)
            {
                _log.Error($"ProcessReceiptChangeNotificationAsync Exception: ", ex);

                await serviceBusDb.SaveMessageExceptionToDb(azbMessageOperation, ex, messageId, messageOperationId);

                throw;
            }

            _stopwatch.Stop();

            //Log
            _log.Debug($"End ProcessReceiptChangeNotificationAsync : {_stopwatch.Elapsed.TotalMilliseconds}ms");
        }

        /// <summary>
        /// Process Messages Async Receipt AIA
        /// </summary>
        /// <param name="message"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public async Task ProcessReceiptAiaMessagesAsync(Message message, CancellationToken token)
        {
            _stopwatch.Restart();
            _stopwatch.Start();

            _log.Debug($"Start ProcessReceiptAiaMessagesAsync");

            // Process the message
            var requestMessage = JsonConvert.DeserializeObject<RequestServiceBus>(Encoding.UTF8.GetString(message.Body));

            _log.Debug($"Start ProcessReceiptAiaMessages Request: {JsonConvert.SerializeObject(requestMessage)}");

            long messageId = 0;
            long messageOperationId = 0;

            try
            {
                if (ApplicationSettings.DatabaseLogEnabled)
                {
                    // Get Message Id
                    messageId = await serviceBusDb.GetMessageIdByXCorrelationId(message, requestMessage);

                    // Log Azure Get Message to Trace DB
                    await serviceBusDb.SaveServiceBusDBGetMessageStepAsync(messageId);

                    azbMessageOperation = new PT.WinSvc.Models.DB.AzureServiceBus.MessageOperation();
                    // Log Azure Sent Message to Trace DB
                    messageOperationId = await serviceBusDb.SaveServiceBusDBAsync(azbMessageOperation, Enums.AzbOperation.Send, messageId);
                }

                SendMessageResult sendResult = await new AiaService().ProcessReceiptAiaMessage(requestMessage);

                _log.Debug($"End ProcessReceiptAiaMessages Request");

                _log.Debug($"ProcessReceiptAiaMessagesAsync Response: {JsonConvert.SerializeObject(sendResult)}");

                await SaveServiceBusDBAsync(sendResult, azbMessageOperation, messageId, messageOperationId);

                await SendToDeadLetterOrComplete(_subscriptionClient, message, sendResult);
            }
            catch (Exception ex)
            {
                _log.Error($"ProcessReceiptAiaMessagesAsync Exception: {ex}");

                await serviceBusDb.SaveMessageExceptionToDb(azbMessageOperation, ex, messageId, messageOperationId);

                throw;
            }

            _stopwatch.Stop();

            //Log
            _log.Debug($"End ProcessReceiptAiaMessagesAsync : {_stopwatch.Elapsed.TotalMilliseconds}ms");
        }

        /// <summary>ProcessMessagesAsync - Process messages Async</summary>
        /// <param name="message"></param>
        /// <param name="token"></param>
        /// <returns></returns>
        public async Task ProcessMessagesAsync(Message message, CancellationToken token)
        {
            _log.Debug($"Start ProcessMessagesAsync : {message.SystemProperties.LockToken}");
            _log.Info($"Received message: SequenceNumber:{message.SystemProperties.SequenceNumber} Body:{Encoding.UTF8.GetString(message.Body)}");

            // Process the message
            var requestMessage = JsonConvert.DeserializeObject<RequestServiceBus>(Encoding.UTF8.GetString(message.Body));

            _log.Debug($"RequestType : {requestMessage.Domain}");

            await SendHighAvailabilityReceiverAsync(_subscriptionClient, message, requestMessage);
        }

        /// <summary>
        /// For now only works HighAvailability
        /// </summary>
        /// <param name="requestMessage"></param>
        public async Task SendHighAvailabilityReceiverAsync(ISubscriptionClient subscriptionClient, Message message, RequestServiceBus requestMessage)
        {
            var sendResult = new SendMessageResult();

            _stopwatch.Restart();
            _stopwatch.Start();

            _log.Debug($"Start HighAvailability");
            Console.WriteLine($"Start HighAvailability");

            long messageId = 0;
            long messageOperationId = 0;

            if (ApplicationSettings.DatabaseLogEnabled)
            {
                // Get Message Id
                messageId = await serviceBusDb.GetMessageIdByXCorrelationId(message, requestMessage);

                azbMessageOperation = new PT.WinSvc.Models.DB.AzureServiceBus.MessageOperation();

                await serviceBusDb.SaveServiceBusDBGetMessageStepAsync(messageId);
            }

            azbMessageOperation = new PT.WinSvc.Models.DB.AzureServiceBus.MessageOperation();

            try
            {
                if (ApplicationSettings.DatabaseLogEnabled)
                {
                    azbMessageOperation.MessageId = messageId;
                    azbMessageOperation.AzbOperationId = (int)Enums.AzbOperation.Send;
                    azbMessageOperation.TopicName = subscriptionClient.TopicPath;
                    azbMessageOperation.SubscriptionName = subscriptionClient.SubscriptionName;
                    azbMessageOperation.ProcessInitialDate = DateTime.Now;

                    messageOperationId = await serviceBusDb.SaveServiceBusDBAsync(azbMessageOperation, Enums.AzbOperation.Send, messageId);
                }

                _log.Debug($"Request message: {JsonConvert.SerializeObject(requestMessage)}");

                //Uri requestUri = new Uri($"{ ApplicationSettings.ServiceHighAvailability }/{ ApplicationSettings.MethodsServiceBusMsg}");
                //HttpResponseMessage responseMessage = await client.PostAsync(requestUri, byteContent);

                string errorDescription = string.Empty;
                _brokerClient.BsWebService = ApplicationSettings.ServicebsWebService;
                _brokerClient.BsWebmethod = ApplicationSettings.ServiceWebMethod;
                _brokerClient.HttpVerb = "POST";

                StandardMessage standardMessage = new StandardMessage();

                sendResult.Date = DateTime.Now;
                sendResult.Code = "0";
                bool isResponseException = false;

                var responseMessage = await _brokerClient.RequestAsync<BrokerClient.GenericResponseString>(string.Empty, null, requestMessage, 0, (ex) =>
                {
                    try
                    {
                        isResponseException = true;
                        // TODO: Above code must be refactored/improved, service responses differ from each other...

                        // Doesn't bind InnerError list?!?
                        //standardMessage = responseMessage.Content.ReadAsAsync<StandardMessage>().Result;

                        string response = ex.Call.Response.Content.ReadAsStringAsync().Result;

                        try
                        {
                            standardMessage = JsonConvert.DeserializeObject<StandardMessage>(response);
                            
                            sendResult.Code = standardMessage.ErrorCode;
                            sendResult.Description = $"{standardMessage.ErrorCode}|{standardMessage.ErrorMessage}|{JsonConvert.SerializeObject(standardMessage.InnerErrors)}";
                        }
                        catch
                        {
                            JObject jObject = JsonConvert.DeserializeObject<JObject>(response);

                            sendResult.Code = jObject["errorCode"].ToString();
                            sendResult.Description = jObject["errorMessage"].ToString();
                        }
                    }
                    catch (Exception exception)
                    {
                        sendResult.Code = ex.Call.Response.StatusCode.ToString();
                        sendResult.Description = $"StatusCode: {ex.Call.Response.StatusCode}|ReasonPhrase: {ex.Call.Response.ReasonPhrase}";

                        _log.Error($"Exception StackTrace: {exception.StackTrace}");
                    }

                    return null;
                }, false);

                if (!isResponseException)
                {
                    sendResult.Description = responseMessage.Response;
                    sendResult.Code = "-1";
                    sendResult.Success = responseMessage.Success;
                }

                _log.Debug($"Request was sent to HighAvailability : " + ApplicationSettings.ServiceWebMethod);
                _log.Debug($"Response message: {JsonConvert.SerializeObject(responseMessage)}");

                if (ApplicationSettings.DatabaseLogEnabled)
                {
                    azbMessageOperation.ResultCode = sendResult.Success ? Enums.MessageOperationResultCode.OK.ToString() : Enums.MessageOperationResultCode.NOK.ToString();
                    azbMessageOperation.ResultMessage = sendResult.Description;
                    azbMessageOperation.ProcessEndDate = DateTime.Now;

                    await serviceBusDb.SaveServiceBusDBAsync(azbMessageOperation, sendResult.Success ? Enums.AzbOperation.Process : Enums.AzbOperation.Send, messageId, messageOperationId);
                }
            }
            catch (Exception ex)
            {
                if (ApplicationSettings.DatabaseLogEnabled)
                {
                    azbMessageOperation.ResultCode = Enums.MessageOperationResultCode.NOK.ToString();
                    azbMessageOperation.ResultDetailMessage = ex.StackTrace;

                    await serviceBusDb.SaveServiceBusDBAsync(azbMessageOperation, Enums.AzbOperation.Send, messageId, messageOperationId);
                }

                _log.Error($"Error calling HighAvailability API : {ex.Message}");
                Console.WriteLine($"Error calling HighAvailability API : {ex.Message}");

                throw;
            }

            await SendToDeadLetterOrComplete(_subscriptionClient, message, sendResult);

            _stopwatch.Stop();
            _log.Debug($"End HighAvailability : {_stopwatch.Elapsed.TotalMilliseconds}ms");
            Console.WriteLine($"End HighAvailability : {_stopwatch.Elapsed.TotalMilliseconds}ms");
        }
        public async Task SendMessageToDeadLetter(ISubscriptionClient subscriptionClient, Message message, HttpResponseMessage responseMessage, SendMessageResult result)
        {
            if (subscriptionClient != null && message != null && ValidateHttpErrorCodeAndSendToDeadLetter(responseMessage))
            {
                await SendToDeadLetterAsync(subscriptionClient, message, result);

                _log.Debug($"Message sent to Service Bus deadletter qeue");
            }
        }

        /// <summary>
        /// Note: Use the cancellationToken passed is necessary to determine if the queueClient has already been closed.
        /// If queueClient has already been Closed, you may choose between not calling CompleteAsync() or AbandonAsync() etc. calls 
        /// to avoid unnecessary exceptions.
        /// Use this Handler to look at the exceptions received on the MessagePump
        /// </summary>
        /// <param name="exceptionReceivedEventArgs">The <see cref="ExceptionReceivedEventArgs"/> instance containing the event data.</param>
        /// <returns></returns>
        public Task ExceptionReceivedHandler(ExceptionReceivedEventArgs exceptionReceivedEventArgs)
        {
            Console.WriteLine($"Message handler encountered an exception {exceptionReceivedEventArgs.Exception}.");
            var context = exceptionReceivedEventArgs.ExceptionReceivedContext;
            Console.WriteLine("Exception context for troubleshooting:");
            Console.WriteLine($"- Endpoint: {context.Endpoint}");
            Console.WriteLine($"- Entity Path: {context.EntityPath}");
            Console.WriteLine($"- Executing Action: {context.Action}");

            _log.Error($"Message handler encountered an exception {exceptionReceivedEventArgs.Exception}.");
            _log.Error("Exception context for troubleshooting:");

            _log.Error($"- Entity Path: {context.EntityPath}");
            _log.Error($"- Executing Action: {context.Action}");

            return Task.CompletedTask;
        }
        private bool ValidateHttpErrorCodeAndSendToDeadLetter(HttpResponseMessage result)
        {
            switch (result.StatusCode)
            {
                case HttpStatusCode.NotFound:
                    return true;
                default:
                    return false;
            }
        }
        private async Task SendToDeadLetterAsync(ISubscriptionClient subscriptionClient, Message message, SendMessageResult result)
        {
            _log.Error($"Start SendToDeadLetterAsync");

            try
            {
                IDictionary<string, object> propertiesToModify = new Dictionary<string, object>();
                propertiesToModify.Add(new KeyValuePair<string, object>("DeadLetterReason", result.Code));
                propertiesToModify.Add(new KeyValuePair<string, object>("DeadLetterErrorDescription", result.Description));

                await subscriptionClient.DeadLetterAsync(message.SystemProperties.LockToken, propertiesToModify);
            }
            catch (Exception ex)
            {
                _log.Error($"Error HandleSessionAsync : {ex.Message}");

                Console.WriteLine($"Error HandleSessionAsync : {ex.Message}");

                throw;
            }
        }
        private async Task SendToDeadLetterOrComplete(ISubscriptionClient subscriptionClient, Message message, SendMessageResult messageResult)
        {
            if (messageResult != null && messageResult.Success && !ApplicationSettings.AutoComplete)
            {
                //allow message to stay in topic queue for another trial
                await _subscriptionClient.CompleteAsync(message.SystemProperties.LockToken);
            }
            else
            {
                await SendToDeadLetterAsync(_subscriptionClient, message, messageResult);
            }
        }
        private async Task SaveServiceBusDBAsync(SendMessageResult sendResult, PT.WinSvc.Models.DB.AzureServiceBus.MessageOperation azbMessageOperation, long messageId, long messageOperationId)
        {
            if (ApplicationSettings.DatabaseLogEnabled)
            {
                azbMessageOperation.ResultCode = sendResult.Success ? Enums.MessageOperationResultCode.OK.ToString() : Enums.MessageOperationResultCode.NOK.ToString();
                azbMessageOperation.ResultMessage = sendResult.Description;
                azbMessageOperation.ProcessEndDate = DateTime.Now;

                // Log Azure Process Message to Trace DB
                await serviceBusDb.SaveServiceBusDBAsync(azbMessageOperation, sendResult.Success ? Enums.AzbOperation.Process : Enums.AzbOperation.Send, messageId, messageOperationId);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;

namespace INS.PT.WinSvc.Models.DB.AzureServiceBus
{
    public partial class Message
    {
        public Message()
        {
            MessageOperation = new HashSet<MessageOperation>();
        }

        public long Id { get; set; }
        public string XcorrelationId { get; set; }
        public int DomainId { get; set; }
        public int OperationId { get; set; }
        public string Body { get; set; }
        public DateTime? ProcessDate { get; set; }
        public DateTime AuditCreationDate { get; set; }
        public DateTime? AuditUpdatedDate { get; set; }

        public virtual Domain Domain { get; set; }
        public virtual Operation Operation { get; set; }
        public virtual ICollection<MessageOperation> MessageOperation { get; set; }
    }
}

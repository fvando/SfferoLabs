﻿using System;
using System.Collections.Generic;

namespace INS.PT.WinSvc.Models.DB.AzureServiceBus
{
    public partial class Operation
    {
        public Operation()
        {
            Message = new HashSet<Message>();
        }

        public int Id { get; set; }
        public string Description { get; set; }
        public bool? Active { get; set; }

        public virtual ICollection<Message> Message { get; set; }
    }
}

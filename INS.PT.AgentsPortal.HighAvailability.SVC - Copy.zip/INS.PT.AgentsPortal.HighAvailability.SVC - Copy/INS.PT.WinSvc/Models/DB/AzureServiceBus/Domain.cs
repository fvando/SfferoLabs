﻿using System;
using System.Collections.Generic;

namespace INS.PT.WinSvc.Models.DB.AzureServiceBus
{
    public partial class Domain
    {
        public Domain()
        {
            InverseParentNavigation = new HashSet<Domain>();
            Message = new HashSet<Message>();
        }

        public int Id { get; set; }
        public string Description { get; set; }
        public int? Parent { get; set; }
        public bool? Active { get; set; }

        public virtual Domain ParentNavigation { get; set; }
        public virtual ICollection<Domain> InverseParentNavigation { get; set; }
        public virtual ICollection<Message> Message { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace INS.PT.WinSvc.Models.DB.AzureServiceBus
{
    public partial class MessageOperation
    {
        public long Id { get; set; }
        public long MessageId { get; set; }
        public int AzbOperationId { get; set; }
        public string TopicName { get; set; }
        public string SubscriptionName { get; set; }
        public DateTime ProcessInitialDate { get; set; }
        public DateTime? ProcessEndDate { get; set; }
        public string ResultCode { get; set; }
        public string ResultMessage { get; set; }
        public string ResultDetailMessage { get; set; }
        public DateTime AuditCreationDate { get; set; }
        public DateTime? AuditUpdatedDate { get; set; }

        public virtual AzbOperation AzbOperation { get; set; }
        public virtual Message Message { get; set; }
    }
}

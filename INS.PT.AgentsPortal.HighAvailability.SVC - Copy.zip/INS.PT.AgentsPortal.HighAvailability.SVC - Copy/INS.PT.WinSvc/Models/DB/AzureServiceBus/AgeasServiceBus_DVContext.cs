﻿using System;
using INS.PT.AgentsPortal.WinSvc.Repository;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace INS.PT.WinSvc.Models.DB.AzureServiceBus
{
    public partial class AgeasServiceBus_DVContext : DbContext
    {
        public AgeasServiceBus_DVContext()
        {
        }

        public AgeasServiceBus_DVContext(DbContextOptions<AgeasServiceBus_DVContext> options)
            : base(options)
        {
        }

        public virtual DbSet<AzbOperation> AzbOperation { get; set; }
        public virtual DbSet<BackupMessageQueue> BackupMessageQueue { get; set; }
        public virtual DbSet<Company> Company { get; set; }
        public virtual DbSet<Domain> Domain { get; set; }
        public virtual DbSet<Message> Message { get; set; }
        public virtual DbSet<MessageOperation> MessageOperation { get; set; }
        public virtual DbSet<Operation> Operation { get; set; }
        public virtual DbSet<Source> Source { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(ApplicationSettings.SQLServerConnectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<AzbOperation>(entity =>
            {
                entity.ToTable("AzbOperation", "dbo");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<BackupMessageQueue>(entity =>
            {
                entity.ToTable("BackupMessageQueue", "dbo");

                entity.Property(e => e.Id)
                    .HasColumnName("id")
                    .ValueGeneratedNever();

                entity.Property(e => e.AuditCreationDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Body).IsRequired();
            });

            modelBuilder.Entity<Company>(entity =>
            {
                entity.ToTable("Company", "dbo");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(25);
            });

            modelBuilder.Entity<Domain>(entity =>
            {
                entity.ToTable("Domain", "dbo");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(25);

                entity.HasOne(d => d.ParentNavigation)
                    .WithMany(p => p.InverseParentNavigation)
                    .HasForeignKey(d => d.Parent)
                    .HasConstraintName("FK_Domain_Domain");
            });

            modelBuilder.Entity<Message>(entity =>
            {
                entity.ToTable("Message", "dbo");

                entity.Property(e => e.AuditCreationDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.AuditUpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.Body).IsRequired();

                entity.Property(e => e.ProcessDate).HasColumnType("datetime");

                entity.Property(e => e.XcorrelationId)
                    .IsRequired()
                    .HasColumnName("XCorrelationId")
                    .HasMaxLength(50);

                entity.HasOne(d => d.Domain)
                    .WithMany(p => p.Message)
                    .HasForeignKey(d => d.DomainId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Message_Domain");

                entity.HasOne(d => d.Operation)
                    .WithMany(p => p.Message)
                    .HasForeignKey(d => d.OperationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Message_Operation");
            });

            modelBuilder.Entity<MessageOperation>(entity =>
            {
                entity.ToTable("MessageOperation", "dbo");

                entity.Property(e => e.AuditCreationDate).HasColumnType("datetime");

                entity.Property(e => e.AuditUpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.ProcessEndDate).HasColumnType("datetime");

                entity.Property(e => e.ProcessInitialDate).HasColumnType("datetime");

                entity.Property(e => e.ResultCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SubscriptionName).HasMaxLength(50);

                entity.Property(e => e.TopicName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.HasOne(d => d.AzbOperation)
                    .WithMany(p => p.MessageOperation)
                    .HasForeignKey(d => d.AzbOperationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MessageOperation_AzbOperation1");

                entity.HasOne(d => d.Message)
                    .WithMany(p => p.MessageOperation)
                    .HasForeignKey(d => d.MessageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MessageOperation_Message");
            });

            modelBuilder.Entity<Operation>(entity =>
            {
                entity.ToTable("Operation", "dbo");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(25);
            });

            modelBuilder.Entity<Source>(entity =>
            {
                entity.ToTable("Source", "dbo");

                entity.Property(e => e.Active)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Description)
                    .IsRequired()
                    .HasMaxLength(25);
            });
        }
    }
}

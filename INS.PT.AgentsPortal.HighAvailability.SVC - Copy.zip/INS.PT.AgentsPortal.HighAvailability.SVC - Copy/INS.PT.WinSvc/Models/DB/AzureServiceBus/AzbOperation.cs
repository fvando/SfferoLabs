﻿using System;
using System.Collections.Generic;

namespace INS.PT.WinSvc.Models.DB.AzureServiceBus
{
    public partial class AzbOperation
    {
        public AzbOperation()
        {
            MessageOperation = new HashSet<MessageOperation>();
        }

        public int Id { get; set; }
        public int Code { get; set; }
        public string Description { get; set; }

        public virtual ICollection<MessageOperation> MessageOperation { get; set; }
    }
}

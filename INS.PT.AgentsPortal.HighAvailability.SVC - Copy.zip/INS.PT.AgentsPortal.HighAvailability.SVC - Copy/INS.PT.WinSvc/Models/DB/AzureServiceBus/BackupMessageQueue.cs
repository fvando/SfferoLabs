﻿using System;
using System.Collections.Generic;

namespace INS.PT.WinSvc.Models.DB.AzureServiceBus
{
    public partial class BackupMessageQueue
    {
        public Guid Id { get; set; }
        public int DomainId { get; set; }
        public int OperationId { get; set; }
        public string Body { get; set; }
        public DateTime AuditCreationDate { get; set; }
    }
}

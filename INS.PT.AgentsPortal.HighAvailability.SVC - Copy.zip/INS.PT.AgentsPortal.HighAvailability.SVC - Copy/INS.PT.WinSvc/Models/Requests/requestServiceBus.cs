﻿// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.AgentsPortal.WinSvc.Models.Requests
{
    public class RequestServiceBus : IValidatableObject
    {
        public RequestServiceBus() { }
        public RequestServiceBus(AxisValues axisValues)
        {
            AxisValues = axisValues;
        }

        /// <summary>AxisValues</summary>
        [JsonProperty("axisValues")]
        public AxisValues AxisValues { get; set; }

        /// <summary>Source</summary>
        /// <example>tecnisys</example>
        [JsonProperty("source")]
        public string Source { get; set; }

        /// <summary>Domain</summary>
        /// <example>claims</example>
        [JsonProperty("domain")]
        public string Domain { get; set; }

        /// <summary>Domain Id</summary>
        /// <example>AU20180000001</example>
        [JsonProperty("domainId")]
        public string DomainId { get; set; }

        /// <summary>Operation</summary>
        /// <example>create</example>
        [JsonProperty("operation")]
        public string Operation { get; set; }

        [JsonProperty("priority")]
        public string Priority { get; set; }

        [JsonProperty("businessType")]
        public string BusinessType { get; set; }

        /// <summary>Operation</summary>
        /// <example>create</example>
        [JsonProperty("date")]
        public DateTime? Date { get; set; }

        /// <summary>Company</summary>
        [JsonProperty("company")]
        public string Company { get; set; }

        /// <summary>Network</summary>
        [JsonProperty("network")]
        public string Network { get; set; }

        /// <summary>subDomains</summary>
        /// <remarks>
        ///    Sample request:
        ///
        ///     POST /v1/SendMessageTopic
        ///     
        ///         "subDomains": [ 
        ///                         {
        ///                         "subDomain": "addresses",
        ///                         "SubDomainId": "3",
        ///                         "operation": "create",
        ///                         "order": "1"
        ///                         }
        ///                       ]
        /// </remarks>

        [JsonProperty("detailedInfo")]
        public dynamic DetailedInfo { get; set; }

        /// <summary>destinations</summary>
        /// <remarks>
        ///    Sample request:
        ///
        ///     POST /v1/SendMessageTopic
        ///     "destinations" : [
        ///                         "duckcreek"
        ///                      ]
        /// </remarks>
        [JsonProperty("destinations")]
        public List<string> Destinations { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            var errors = new List<ValidationResult>();

            // at least one search filter must be filled
            if (string.IsNullOrEmpty(Source)
                && string.IsNullOrEmpty(Domain)
                && string.IsNullOrEmpty(DomainId)
                )
            {
                errors.Add(new ValidationResult("All filters are empty."));
            }
            return errors;
        }
    }
}

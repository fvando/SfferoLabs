﻿// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;

namespace INS.PT.AgentsPortal.WinSvc.Models.Requests
{
    public class AxisValues
    {
        /// <summary>Solution</summary>
        /// <example>DUCKCREEK</example>
        [JsonProperty("solution")]
        public string Solution { get; set; }

        /// <summary>User</summary>
        /// <example>\BS\DUCKCREEKD</example>
        [JsonProperty("user")]
        public string User { get; set; }
    }
}

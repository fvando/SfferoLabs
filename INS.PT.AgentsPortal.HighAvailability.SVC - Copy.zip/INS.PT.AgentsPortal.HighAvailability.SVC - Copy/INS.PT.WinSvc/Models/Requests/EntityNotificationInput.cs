﻿namespace INS.PT.WinSvc.Models.Requests
{
    public class EntityNotificationInput
    {
        public string Source { get; set; }
        public string IdEntity { get; set; }
    }
}

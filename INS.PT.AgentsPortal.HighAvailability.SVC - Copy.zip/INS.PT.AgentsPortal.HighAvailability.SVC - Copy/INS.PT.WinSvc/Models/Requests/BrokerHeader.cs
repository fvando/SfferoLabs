﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.Collections.Generic;
using System.Text;

namespace INS.PT.AgentsPortal.WinSvc.Models.Requests
{
    public class BrokerHeader
    {
        public const string ContentType = "Content-Type";
        public const string AccessControlAllowOrigin = "Access-Control-Allow-Origin";
        public const string AccessControlAllowHeaders = "Access-Control-Allow-Headers";
        public const string AccessControlAllowCredentials = "Access-Control-Allow-Credentials";

        public const string ValueContentType = "application/json";
        public const string ValueAccessControlAllowOrigin = "*";
        public const string ValueAccessControlAllowHeaders = "Origin, X-Requested-With, Content-Type, Accept";
        public const string ValueAccessControlAllowCredentials = "true";
    }
}

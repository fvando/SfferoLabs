﻿using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WinSvc.Models.Requests
{
    public class CommonCollectionEntityInput
    {
        /// <summary>
        /// Gets or Sets Master Origin
        /// </summary>
        [DataMember(Name = "notification", EmitDefaultValue = false)]
        [JsonProperty(PropertyName = "notification")]
        public string Notification { get; set; }
    }
}

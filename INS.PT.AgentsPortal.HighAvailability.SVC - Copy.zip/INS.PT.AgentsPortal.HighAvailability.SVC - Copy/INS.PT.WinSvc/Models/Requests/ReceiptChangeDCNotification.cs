﻿using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WinSvc.Models.Requests
{
    public class ReceiptChangeDCNotification
    {
        [DataMember(Name = "paymentMethod", EmitDefaultValue = false)]
        [JsonProperty(PropertyName = "paymentMethod")]
        public string PaymentMethod { get; set; }

        [DataMember(Name = "effectiveDate", EmitDefaultValue = false)]
        [JsonProperty(PropertyName = "effectiveDate")]
        public string EffectiveDate { get; set; }

        [DataMember(Name = "receiptType", EmitDefaultValue = false)]
        [JsonProperty(PropertyName = "receiptType")]
        public string ReceiptType { get; set; }

        [DataMember(Name = "status", EmitDefaultValue = false)]
        [JsonProperty(PropertyName = "status")]
        public string Status { get; set; }

        [DataMember(Name = "accountabilityId", EmitDefaultValue = false)]
        [JsonProperty(PropertyName = "accountabilityId")]
        public string AccountabilityId { get; set; }
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;

namespace INS.PT.AgentsPortal.WinSvc.Models.Requests
{
    public class SubDomain
    {
        /// <summary>subDomain</summary>
        /// <example>addresses</example>
        [JsonProperty("subDomain")]
        public string Description { get; set; }
        /// <summary>SubDomain Id</summary>
        /// <example>3</example>
        [JsonProperty("subDomainId")]
        public string SubDomainId { get; set; }
        /// <summary>operation</summary>
        /// <example>create</example>
        [JsonProperty("operation")]
        public string Operation { get; set; }
        /// <summary>order</summary>
        /// <example>1</example>
        [JsonProperty("order")]
        public string Order { get; set; }
    }
}
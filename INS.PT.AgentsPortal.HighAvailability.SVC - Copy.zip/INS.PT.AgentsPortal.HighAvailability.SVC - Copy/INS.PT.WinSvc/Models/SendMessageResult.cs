﻿
namespace INS.PT.AgentsPortal.WinSvc.Models
{
    public class SendMessageResult
    {
        public bool Success { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public System.DateTime? Date { get; set; }
    }
}

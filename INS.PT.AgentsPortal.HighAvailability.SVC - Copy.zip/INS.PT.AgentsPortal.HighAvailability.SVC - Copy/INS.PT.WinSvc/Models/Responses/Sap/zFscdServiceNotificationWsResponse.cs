﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace INS.PT.WinSvc.Models.Responses.Sap
{
    public class zFscdServiceNotificationWsResponse
    {
        [JsonProperty(PropertyName = "errors")]
        public List<Error> Errors { get; set; }
    }
}

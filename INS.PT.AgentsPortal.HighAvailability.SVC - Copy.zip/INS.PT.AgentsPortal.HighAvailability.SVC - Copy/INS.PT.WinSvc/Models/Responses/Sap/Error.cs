﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace INS.PT.WinSvc.Models.Responses.Sap
{
    public class Error
    {
        [JsonProperty(PropertyName = "errorCode")]
        public string Code { get; set; }
        [JsonProperty(PropertyName = "errorCodeTxt")]
        public string Description { get; set; }
    }
}

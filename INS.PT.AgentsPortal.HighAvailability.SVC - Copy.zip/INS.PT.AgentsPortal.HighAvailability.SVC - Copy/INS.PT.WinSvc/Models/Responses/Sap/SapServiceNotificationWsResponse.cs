﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using Newtonsoft.Json;

namespace INS.PT.WinSvc.Models.Responses.Sap
{
    [DataContract]
    public class SapServiceNotificationWsResponse
    {
        [JsonProperty(PropertyName = "zFscdServiceNotificationWsResponse")]
        public zFscdServiceNotificationWsResponse ServiceNotificationWsResponse { get; set; }
    }
}

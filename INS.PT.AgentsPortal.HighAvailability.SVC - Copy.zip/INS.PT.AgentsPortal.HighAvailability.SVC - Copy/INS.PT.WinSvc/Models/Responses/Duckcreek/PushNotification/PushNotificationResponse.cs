﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace INS.PT.WinSvc.Models.Responses.Duckcreek.PushNotification
{
    public class PushNotificationResponse
    {
        public Type Type { get; set; }
        public Type BankAccount { get; set; }
        public Type Document { get; set; }
        public Type Cae { get; set; }
        public Type Address { get; set; }
        public Type Contact { get; set; }
    }
}

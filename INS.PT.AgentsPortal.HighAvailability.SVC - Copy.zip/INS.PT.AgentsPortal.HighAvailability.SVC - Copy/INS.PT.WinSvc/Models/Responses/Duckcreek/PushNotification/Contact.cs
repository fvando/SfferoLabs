﻿using System;
using System.Collections.Generic;
using System.Text;

namespace INS.PT.WinSvc.Models.Responses.Duckcreek.PushNotification
{
    public class Contact : Common
    {
    }
}

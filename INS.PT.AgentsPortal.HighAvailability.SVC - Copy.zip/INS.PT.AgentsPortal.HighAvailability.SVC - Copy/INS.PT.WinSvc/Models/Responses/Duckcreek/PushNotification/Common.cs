﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace INS.PT.WinSvc.Models.Responses.Duckcreek.PushNotification
{
    public class Common
    {
        [JsonProperty(PropertyName = "status")]
        public string Status { get; set; }
        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }
    }
}

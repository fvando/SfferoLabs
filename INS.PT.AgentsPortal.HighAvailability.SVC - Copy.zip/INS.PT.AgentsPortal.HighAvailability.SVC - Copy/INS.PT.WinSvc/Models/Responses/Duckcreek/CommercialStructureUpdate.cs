﻿using System.Collections.Generic;

namespace INS.PT.WinSvc.Models.Responses.Duckcreek
{
    /// <summary>
    /// Class to read the response from commercial struture updates.
    /// </summary>
    public class CommercialStructureUpdate
    {
        /// <summary>
        /// SuccessCount
        /// </summary>
        public int SuccessCount { get; set; }

        /// <summary>
        /// Failurecount
        /// </summary>
        public int Failurecount { get; set; }

        /// <summary>
        /// ImportFailures.
        /// </summary>
        public IEnumerable<string> ImportFailures { get; set; }
    }
}

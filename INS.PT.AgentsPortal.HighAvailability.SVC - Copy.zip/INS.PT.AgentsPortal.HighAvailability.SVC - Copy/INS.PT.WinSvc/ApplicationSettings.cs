// Copyright Ageas 2019 © - Integration Team

using Microsoft.Extensions.Configuration;

namespace INS.PT.AgentsPortal.WinSvc.Repository
{
    public static class ApplicationSettings
    {
        public static string ApplicationName { get; set; }

        // Log4net
        public static string LogConfigFile { get; set; }

        #region Constants
        public static string ConstantsCompany { get; set; } 
        public static string ConstantsBrokerReceipts { get; set; }
        public static string AIADocumentsCollectedCancelledUser { get; set; }
        #endregion

        //Broker
        public static string BrokerSettingsBsEndpoint { get; set; }
        public static string BrokerInternalEndpoint { get; set; }
        public static string BrokerSoapEndPoint { get; set; }
        public static string BrokerSettingsBsSolution { get; private set; }
        public static string BrokerSettingsBsUser { get; private set; }

        // Service Bus
        public static string ServiceBusConnectionString { get; set; }

        #region Service Bus - Topic and Subscriptions
        public static string AgeasPortalTopicClaims { get; set; }
        public static string AgeasPortalTopicCommercialStructure { get; set; }
        public static string AgeasPortalTopicEntities { get; set; }
        public static string AgeasPortalTopicPolicies { get; set; }
        public static string AgeasPortalTopicReceipts { get; set; }
        public static string AgeasPortalTopicWalletMovements { get; set; }
        public static string AgeasPortalTopicRequests { get; set; }
        public static string AgeasPortalTopicQuotations { get; set; }
        public static string SubscriptionDuckCreek { get; set; }
        public static string SubscriptionHighAvailability { get; set; }
        public static string SubscriptionFacets { get; set; }
        public static string SubscriptionSap { get; set; }
        public static string SubscriptionAia { get; set; }
        public static string SubscriptionMdm { get; set; }
        public static bool SubscriptionClaimsHighAvailabilityEnabled { get; set; }
        public static bool SubscriptionCommercialStructureAiaEnabled { get; set; }
        public static bool SubscriptionCommercialStructureDuckCreekEnabled { get; set; }
        public static bool SubscriptionCommercialStructureFacetsEnabled { get; set; }
        public static bool SubscriptionCommercialStructureHighAvailabilityEnabled { get; set; }
        public static bool SubscriptionEntitiesAiaEnabled { get; set; }
        public static bool SubscriptionEntitiesDuckCreekEnabled { get; set; }
        public static bool SubscriptionEntitiesFacetsEnabled { get; set; }
        public static bool SubscriptionEntitiesHighAvailabilityEnabled { get; set; }
        public static bool SubscriptionEntitiesMdmEnabled { get; set; }
        public static bool SubscriptionEntitiesSapEnabled { get; set; }
        public static bool SubscriptionEntitiesTecnisysEnabled { get; set; }
        public static bool SubscriptionPoliciesHighAvailabilityEnabled { get; set; }
        public static bool SubscriptionQuotationsHighAvailabilityEnabled { get; set; }
        public static bool SubscriptionReceiptsHighAvailabilityEnabled { get; set; }
        public static bool SubscriptionReceiptsDuckCreekEnabled { get; set; }
        public static bool SubscriptionReceiptsAiaEnabled { get; set; }
        public static bool SubscriptionRequestsHighAvailabilityEnabled { get; set; }
        public static bool SubscriptionWalletMovementsHighAvailabilityEnabled { get; set; }
        #endregion

        public static bool AgeasPortalTopicClaimsEnabled { get; set; }
        public static bool AgeasPortalTopicCommercialStructureEnabled { get; set; }
        public static bool AgeasPortalTopicEntitiesEnabled { get; set; }
        public static bool AgeasPortalTopicPoliciesEnabled { get; set; }
        public static bool AgeasPortalTopicReceiptsEnabled { get; set; }
        public static bool AgeasPortalTopicWalletMovementsEnabled { get; set; }
        public static bool AgeasPortalTopicRequestsEnabled { get; set; }
        public static bool AgeasPortalTopicQuotationsEnabled { get; set; }


        // Definitions ServiceBus 
        public static int MaxConcurrentCalls { get; set; }
        public static bool AutoComplete { get; set; }

        #region Domains
        public static string ServiceBusDomainClaims { get; set; }
        public static string ServiceBusDomainEntities { get; set; }
        public static string ServiceBusDomainPolicies { get; set; }
        public static string ServiceBusDomainReceipts { get; set; }
        public static string ServiceBusDomainWalletMovements { get; set; }
        public static string ServiceBusDomainCommercialStructure { get; set; }
        public static string ServiceBusDomainRequests { get; set; }
        public static string ServiceBusDomainSimulations { get; set; }
        public static string ServiceBusDomainQuotations { get; set; }
        public static string ServiceBusDomainProposals { get; set; }

        #endregion

        #region Services
        public static string ServiceSettingsServiceName { get; set; }
        public static string ServiceSettingsDisplayName { get; set; }
        public static string ServiceSettingsDescription { get; set; }
        public static bool DatabaseLogEnabled { get; set; }
        public static string SendMessageTopicBroker { get; set; }
        public static string ServiceHighAvailability { get; set; }
        public static string ServicebsWebService { get; set; }
        public static string ServiceWebMethod { get; set; }

        //Broker CommonCollection
        public static string BrokerCommonCollectionWebService { get; set; }
        public static string BrokerCommonCollectionNotifyWebMethod { get; set; }

        //Broker DuckCreek
        public static string BrokerDuckCreekWebService { get; set; }
        public static string BrokerDuckCreekHeaderUserName { get; set; }
        public static string BrokerDuckCreekNotificationWebMethod { get; set; }
        public static string BrokerCommercialStructureChangeNotificationWebMethod { get; set; }
        public static string BrokerAgentClassificationDeltaWebMethod { get; set; }
        public static string BrokerPolicyTransferNotificationWebMethod { get; set; }
        public static string BrokerReceiptNotificationWebMethod { get; set; }

        //Broker Entities
        public static string BrokerEntityWebService { get; set; }
        public static string BrokerEntityNotificationWebMethod { get; set; }

        #endregion

        // Methods
        public static string MethodsServiceBusMsg { get; set; }

        #region URL
        public static bool ProxySettingsUseProxy { get; set; }
        public static string ProxySettingsProxyHost { get; set; }
        public static int ProxySettingsProxyPort { get; set; }
        public static string ProxySettingsProxyByPassList { get; set; }
        public static string SQLServerConnectionString { get; set; }
        #endregion

        public static void SetSettings(IConfiguration config)
        {
            #region Constants
            ConstantsCompany = config["Constants:Company"];
            ConstantsBrokerReceipts = config["Constants:BrokerReceipts"];
            AIADocumentsCollectedCancelledUser = config["Constants:AIADocumentsCollectedCancelledUser"];
            #endregion

            // Broker 
            BrokerSettingsBsSolution = config["BrokerSettings:BsSolution"];
            BrokerSettingsBsUser = config["BrokerSettings:BsUser"];
            BrokerSettingsBsEndpoint = config["BrokerSettings:BsEndpoint"];
            BrokerInternalEndpoint = config["BrokerSettings:BsInternalEndpoint"];
            BrokerSoapEndPoint = config["BrokerSettings:SoapEndPoint"];

            // Service Bus
            ServiceBusConnectionString = config["ServiceBus:ConnectionStrings"];

            #region Service Bus - Topic and Subscriptions
            AgeasPortalTopicClaims = config["ServiceBus:AgeasPortalTopicClaims"];
            AgeasPortalTopicClaimsEnabled = bool.Parse(config["ServiceBus:AgeasPortalTopicClaimsEnabled"] ?? "false");
            AgeasPortalTopicCommercialStructure = config["ServiceBus:AgeasPortalTopicCommercialStructure"];
            AgeasPortalTopicCommercialStructureEnabled = bool.Parse(config["ServiceBus:AgeasPortalTopiccommercialstructureEnabled"] ?? "false");
            AgeasPortalTopicEntities = config["ServiceBus:AgeasPortalTopicEntities"];
            AgeasPortalTopicEntitiesEnabled = bool.Parse(config["ServiceBus:AgeasPortalTopicEntitiesEnabled"] ?? "false");
            AgeasPortalTopicPolicies = config["ServiceBus:AgeasPortalTopicPolicies"];
            AgeasPortalTopicPoliciesEnabled = bool.Parse(config["ServiceBus:AgeasPortalTopicPoliciesEnabled"] ?? "false");
            AgeasPortalTopicReceipts = config["ServiceBus:AgeasPortalTopicReceipts"];
            AgeasPortalTopicReceiptsEnabled = bool.Parse(config["ServiceBus:AgeasPortalTopicReceiptsEnabled"] ?? "false");
            AgeasPortalTopicWalletMovements = config["ServiceBus:AgeasPortalTopicWalletMovements"];
            AgeasPortalTopicWalletMovementsEnabled = bool.Parse(config["ServiceBus:AgeasPortalTopicWalletMovementsEnabled"] ?? "false");
            AgeasPortalTopicRequests = config["ServiceBus:AgeasPortalTopicRequests"];
            AgeasPortalTopicRequestsEnabled = bool.Parse(config["ServiceBus:AgeasPortalTopicRequestsEnabled"] ?? "false");
            AgeasPortalTopicQuotations = config["ServiceBus:AgeasPortalTopicQuotations"];
            AgeasPortalTopicQuotationsEnabled = bool.Parse(config["ServiceBus:AgeasPortalTopicQuotationsEnabled"] ?? "false");
            SubscriptionDuckCreek = config["ServiceBus:SubscriptionDuckCreek"];
            SubscriptionHighAvailability = config["ServiceBus:SubscriptionHighAvailability"];
            SubscriptionFacets = config["ServiceBus:SubscriptionFacets"];
            SubscriptionSap = config["ServiceBus:SubscriptionSap"];
            SubscriptionAia = config["ServiceBus:SubscriptionAia"];
            SubscriptionMdm = config["ServiceBus:SubscriptionMdm"];

            SubscriptionClaimsHighAvailabilityEnabled = bool.Parse(config["ServiceBus:SubscriptionClaimsHighAvailabilityEnabled"] ?? "false");
            SubscriptionCommercialStructureAiaEnabled = bool.Parse(config["ServiceBus:SubscriptionCommercialStructureAiaEnabled"] ?? "false");
            SubscriptionCommercialStructureDuckCreekEnabled = bool.Parse(config["ServiceBus:SubscriptionCommercialStructureDuckCreekEnabled"] ?? "false");
            SubscriptionCommercialStructureFacetsEnabled = bool.Parse(config["ServiceBus:SubscriptionCommercialStructureFacetsEnabled"] ?? "false");
            SubscriptionCommercialStructureHighAvailabilityEnabled = bool.Parse(config["ServiceBus:SubscriptionCommercialStructureHighAvailabilityEnabled"] ?? "false");
            SubscriptionEntitiesAiaEnabled = bool.Parse(config["ServiceBus:SubscriptionEntitiesAiaEnabled"] ?? "false");
            SubscriptionEntitiesDuckCreekEnabled = bool.Parse(config["ServiceBus:SubscriptionEntitiesDuckCreekEnabled"] ?? "false");
            SubscriptionEntitiesFacetsEnabled = bool.Parse(config["ServiceBus:SubscriptionEntitiesFacetsEnabled"] ?? "false");
            SubscriptionEntitiesHighAvailabilityEnabled = bool.Parse(config["ServiceBus:SubscriptionEntitiesHighAvailabilityEnabled"] ?? "false");
            SubscriptionEntitiesMdmEnabled = bool.Parse(config["ServiceBus:SubscriptionEntitiesMdmEnabled"] ?? "false");
            SubscriptionEntitiesSapEnabled = bool.Parse(config["ServiceBus:SubscriptionEntitiesSapEnabled"] ?? "false");
            SubscriptionEntitiesTecnisysEnabled = bool.Parse(config["ServiceBus:SubscriptionEntitiesTecnisysEnabled"] ?? "false");
            SubscriptionPoliciesHighAvailabilityEnabled = bool.Parse(config["ServiceBus:SubscriptionPoliciesHighAvailabilityEnabled"] ?? "false");
            SubscriptionQuotationsHighAvailabilityEnabled = bool.Parse(config["ServiceBus:SubscriptionQuotationsHighAvailabilityEnabled"] ?? "false");
            SubscriptionReceiptsHighAvailabilityEnabled = bool.Parse(config["ServiceBus:SubscriptionReceiptsHighAvailabilityEnabled"] ?? "false");
            SubscriptionReceiptsDuckCreekEnabled = bool.Parse(config["ServiceBus:SubscriptionReceiptsDuckCreekEnabled"] ?? "false");
            SubscriptionReceiptsAiaEnabled =  bool.Parse(config["ServiceBus:SubscriptionReceiptsAiaEnabled"] ?? "false");
            SubscriptionRequestsHighAvailabilityEnabled = bool.Parse(config["ServiceBus:SubscriptionRequestsHighAvailabilityEnabled"] ?? "false");
            SubscriptionWalletMovementsHighAvailabilityEnabled = bool.Parse(config["ServiceBus:SubscriptionWalletMovementsHighAvailabilityEnabled"] ?? "false");

            #endregion

            // Definitions ServiceBus 
            MaxConcurrentCalls = int.Parse(config["ServiceBus:MaxConcurrentCalls"]);
            AutoComplete = bool.Parse(config["ServiceBus:AutoComplete"]);

            #region Domains
            ServiceBusDomainClaims = config["ServiceBus:ServiceBusDomainClaims"];
            ServiceBusDomainEntities = config["ServiceBus:ServiceBusDomainEntities"];
            ServiceBusDomainPolicies = config["ServiceBus:ServiceBusDomainPolicies"];
            ServiceBusDomainReceipts = config["ServiceBus:ServiceBusDomainReceipts"];
            ServiceBusDomainWalletMovements = config["ServiceBus:ServiceBusDomainWalletMovements"];
            ServiceBusDomainCommercialStructure = config["ServiceBus:ServiceBusDomainCommercialStructure"];
            ServiceBusDomainRequests = config["ServiceBus:ServiceBusDomainRequests"];
            ServiceBusDomainSimulations = config["ServiceBus:ServiceBusDomainSimulations"];
            ServiceBusDomainQuotations = config["ServiceBus:ServiceBusDomainQuotations"];
            ServiceBusDomainProposals = config["ServiceBus:ServiceBusDomainProposals"];
            #endregion

            #region Service
            ServiceSettingsServiceName = config["ServiceSettings:ServiceName"];
            ServiceSettingsDisplayName = config["ServiceSettings:DisplayName"];
            ServiceSettingsDescription = config["ServiceSettings:Description"];
            DatabaseLogEnabled = bool.Parse(config["ServiceSettings:DatabaseLogEnabled"] ?? "false");

            ServiceHighAvailability = config["Services:HighAvailability"];
            ServicebsWebService = config["Services:bsWebService"];
            ServiceWebMethod = config["Services:bsWebMethod"];

            //Broker CommonCollection
            BrokerCommonCollectionWebService = config["BrokerCommonCollection:bsCommonCollectionWebService"];
            BrokerCommonCollectionNotifyWebMethod = config["BrokerCommonCollection:bsCommonCollectionNotifyWebMethod"];

            //Broker Entities
            BrokerEntityWebService = config["BrokerEntity:bsEntityWebService"];
            BrokerEntityNotificationWebMethod = config["BrokerEntity:bsEntityNotificationWebMethod"];

            //Broker DuckCreek
            BrokerDuckCreekWebService = config["BrokerDuckCreek:bsWebService"];
            BrokerDuckCreekHeaderUserName = config["BrokerDuckCreek:headerUserName"];
            BrokerDuckCreekNotificationWebMethod = config["BrokerDuckCreek:bsNotificationWebMethod"];
            BrokerCommercialStructureChangeNotificationWebMethod = config["BrokerDuckCreek:bsCommercialStructureChangeNotificationWebMethod"];
            BrokerAgentClassificationDeltaWebMethod = config["BrokerDuckCreek:bsAgentClassificationDeltaWebMethod"];
            BrokerPolicyTransferNotificationWebMethod = config["BrokerDuckCreek:bsPolicyTransferNotificationWebMethod"];
            BrokerReceiptNotificationWebMethod = config["BrokerDuckCreek:bsReceiptNotificationWebMethod"];

            #endregion

            // Methods
            MethodsServiceBusMsg = config["Methods:ServiceBusMsg"];

            SendMessageTopicBroker = config["Services:SendMessageTopicBroker"];
     
            // Proxy
            ProxySettingsUseProxy = bool.Parse(config["ProxySettings:UseProxy"]);
            ProxySettingsProxyHost = config["ProxySettings:ProxyHost"];
            ProxySettingsProxyPort = int.Parse(config["ProxySettings:ProxyPort"]);
            ProxySettingsProxyByPassList = config["ProxySettings:ProxyByPassList"];

            //ServiceBusConnectionString DB logging
            SQLServerConnectionString = config["SQLServer:ConnectionStrings"];
        }
    }
}

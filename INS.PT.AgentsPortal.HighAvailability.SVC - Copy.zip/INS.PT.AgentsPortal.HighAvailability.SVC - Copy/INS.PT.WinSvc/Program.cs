﻿// Copyright Ageas 2019 © - Integration Team

using Topshelf;
using log4net;
using System.IO;
using System.Reflection;
using INS.PT.AgentsPortal.WinSvc.Services;
using INS.PT.AgentsPortal.WinSvc.Repository;
using Microsoft.Extensions.Configuration;
using System;
using INS.PT.WinSvc.BrokerCalls;

namespace INS.PT.AgentsPortal.WinSvc
{
    class Program
    {
        static ILog Log;

        static void Main(string[] args)
        {
            //Config App
            IConfiguration config = new ConfigurationBuilder()
                 .AddJsonFile("appsettings.json", true, true)
                 .AddJsonFile($"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")}.json", true, true)
                 .Build();

            BrokerClient brokerClient = new BrokerClient(config);

            // Configure Log4Net
            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
            ApplicationSettings.LogConfigFile = config["Logging:LogConfigFile"];
            log4net.Config.XmlConfigurator.Configure(logRepository, new FileInfo(ApplicationSettings.LogConfigFile));

            // Set Global Variables
            ApplicationSettings.SetSettings(config);

            //Start log
            Log = LogManager.GetLogger(typeof(Program));

            HostFactory.Run(windowsService =>
            {
                Log.Info($"Start INS.PT.AgentsPortal.HighAvailability Service");
             
                windowsService.Service<ServiceTopshelf>(s =>
                {
                    s.ConstructUsing(service => new ServiceTopshelf(brokerClient));
                    s.WhenStarted(service => service.Start());
                    s.WhenStopped(service => service.Stop());
                });

                windowsService.RunAsLocalSystem();
                windowsService.StartAutomatically();

                windowsService.SetDescription(ApplicationSettings.ServiceSettingsDescription);
                windowsService.SetDisplayName(ApplicationSettings.ServiceSettingsDisplayName);
                windowsService.SetServiceName(ApplicationSettings.ServiceSettingsServiceName);
            });
        }
    }
}

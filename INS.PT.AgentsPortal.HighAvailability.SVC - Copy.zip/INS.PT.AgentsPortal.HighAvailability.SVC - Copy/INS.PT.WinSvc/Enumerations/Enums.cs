﻿namespace INS.PT.WinSvc.Enumerations
{
    public enum DuckCreekNotificationType
    {
        CommercialStructureChangeNotification,
        AgentClassification

    }
    public class Enums
    {
        public enum AzbOperation
        {
            Send = 1,
            GetMessage = 2,
            Process = 3,
            Reprocess = 4,
            Delete = 5
        }

        public enum MessageOperationResultCode
        {
            OK,
            NOK
        }
    }
}

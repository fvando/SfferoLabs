﻿using INS.PT.AgentsPortal.WinSvc.Data;

namespace INS.PT.WinSvc.Enumerations
{
    public enum FacetsSupportTypeCode
    {
        [StringValue("slet")]
        SLET,
        [StringValue("slcs")]
        SLCS
    }
}

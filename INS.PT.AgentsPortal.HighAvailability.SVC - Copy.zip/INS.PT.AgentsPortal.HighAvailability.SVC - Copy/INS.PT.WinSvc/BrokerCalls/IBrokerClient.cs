﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Flurl.Http;

namespace INS.PT.WinSvc.BrokerCalls
{
    public interface IBrokerClient
    {
        /// <summary>
        /// Broker endpoint to be used for the request.
        /// </summary>
        string BsEndpoint { get; set; }

        /// <summary>
        /// Http verb to be used.
        /// </summary>
        /// <example>GET</example>
        string HttpVerb { get; set; }

        /// <summary>
        /// Content type header. Defauls to "application/json".
        /// </summary>
        /// <example>application/json</example>
        string ContentType { get; set; }

        /// <summary>
        /// Solution header to be used.
        /// </summary>
        /// <example>DUCKCREEK</example>
        string BsSolution { get; set; }

        /// <summary>
        /// User header to be used.
        /// </summary>
        /// <example>\BS\DUCKCREEKD</example>
        string BsUser { get; set; }

        /// <summary>
        /// Web service header to be used.
        /// </summary>
        /// <example>ageas-api-ReferenceData</example>
        string BsWebService { get; set; }

        /// <summary>
        /// Web method header to be used.
        /// </summary>
        /// <example>v1/ReferenceData/Mappings</example>
        string BsWebmethod { get; set; }

        /// <summary>
        /// Property to define aditional headers to be added to the request.
        /// </summary>
        Dictionary<string, string> AdicionalHeaders { get; set; }



        /// <summary>
        /// Reads the broker endpoint and mandatory headers from the configuration section specified.
        /// </summary>
        /// <param name="brokerSettingsSection">section name to read</param>
        void LoadConfigSettings(string brokerSettingsSection);

        /// <summary>
        /// Makes a request and read is response.
        /// </summary>
        /// <typeparam name="T">result type of the call to ba made</typeparam>
        /// <param name="additionalRoute">route to add to the broker endpoint</param>
        /// <param name="additionalParameters">aditional query parameters to be added</param>
        /// <param name="requestObject">request body if nedded.</param>
        /// <returns>result object that comes from response body</returns>
        Task<T> RequestAsync<T>(string additionalRoute, IDictionary<string, string> additionalParameters, object requestObject);

        /// <summary>
        /// Makes a request and read is response.
        /// </summary>
        /// <typeparam name="T">result type of the call to ba made</typeparam>
        /// <param name="additionalRoute">route to add to the broker endpoint</param>
        /// <param name="additionalParameters">aditional query parameters to be added</param>
        /// <param name="requestObject">request body if nedded.</param>
        /// <param name="retries">number of retries to execute.</param>
        /// <returns>result object that comes from response body</returns>
        Task<T> RequestAsync<T>(string additionalRoute, IDictionary<string, string> additionalParameters, object requestObject, uint retries, Func<FlurlHttpException, T> errorAction) where T : new();

        /// <summary>
        /// Makes a request and read is response.
        /// </summary>
        /// <typeparam name="T">result type of the call to ba made</typeparam>
        /// <param name="additionalRoute">route to add to the broker endpoint</param>
        /// <param name="additionalParameters">aditional query parameters to be added</param>
        /// <param name="requestObject">request body if nedded.</param>
        /// <param name="retries">number of retries to execute.</param>
        /// <returns>result object that comes from response body</returns>
        Task<T> RequestAsync<T>(string additionalRoute, IDictionary<string, string> additionalParameters, object requestObject, uint retries, Func<FlurlHttpException, T> errorAction, bool validateWebServiceAndWebMethod) where T : new();

        /// <summary>
        /// Makes a request and read is response.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="additionalRoute"></param>
        /// <param name="additionalParameters"></param>
        /// <param name="requestObject"></param>
        /// <param name="retries"></param>
        /// <param name="errorAction"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        Task<T> RequestAsync<T>(string additionalRoute, IDictionary<string, string> additionalParameters, object requestObject, uint retries, Func<FlurlHttpException, T> errorAction, bool validateWebServiceAndWebMethod, T defaultValue);

        /// <summary>
        /// validates if broker client is ready to make call.
        /// </summary>
        /// <returns>true if all mandatory headers and configurations are set</returns>
        bool OkToMakeCall();

        /// <summary>
        /// validates if broker client is ready to make call.
        /// </summary>
        /// <returns>true if all mandatory headers and configurations are set</returns>
        bool OkToMakeCall(bool validateWebServiceAndWebMethod);
    }
}

DROP TABLE ComercialStructure;

CREATE TABLE [dbo].[ComercialStructure](
	[ComercialStructureRowId]  AS ((((((((((((((Trim(isnull(CONVERT([char],[ComercialStructureId]),''))+Trim(isnull(CONVERT([char],[Company]),'')))+Trim(isnull(CONVERT([char],[NetworkCode]),'')))+Trim(isnull(CONVERT([char],[NetworkName]),'')))+Trim(isnull(CONVERT([char],[ZoneCode]),'')))+Trim(isnull(CONVERT([char],[ZoneName]),'')))+Trim(isnull(CONVERT([char],[BranchCode]),'')))+Trim(isnull(CONVERT([char],[BranchName]),'')))+Trim(isnull(CONVERT([char],[InspectorCode]),'')))+Trim(isnull(CONVERT([char],[InspectorEntityId]),'')))+Trim(isnull(CONVERT([char],[AgentCode]),'')))+Trim(isnull(CONVERT([char],[AgentEntityId]),'')))+Trim(isnull(CONVERT([char],[ASFNumber]),'')))+Trim(isnull(CONVERT([char],[AuditCreationDate]),'')))+Trim(isnull(CONVERT([char],[AuditUpdatedDate]),''))),
	[ComercialStructureId] [nvarchar](500) NOT NULL,
	[Company] [nvarchar](20) NULL,
	[NetworkCode] [nvarchar](50) NULL,
	[NetworkName] [nvarchar](300) NULL,
	[ZoneCode] [nvarchar](50) NULL,
	[ZoneName] [nvarchar](300) NULL,
	[BranchCode] [nvarchar](50) NULL,
	[BranchName] [nvarchar](300) NULL,
	[InspectorCode] [nvarchar](50) NULL,
	[InspectorEntityId] [nvarchar](50) NULL,
	[AgentCode] [nvarchar](50) NULL,
	[AgentEntityId] [nvarchar](50) NULL,
	[ASFNumber] [nvarchar](50) NULL,
	[AuditCreationDate] [datetime] NOT NULL,
	[AuditUpdatedDate] [datetime] NULL,
 CONSTRAINT [PK_ComercialStructure] PRIMARY KEY CLUSTERED 
(
	[ComercialStructureId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'[Company]|[NetworkCode]|[ZoneCode]|[BranchCode]|[InspectorCode]|[AgentCode]' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'ComercialStructure', @level2type=N'COLUMN',@level2name=N'ComercialStructureId'
GO
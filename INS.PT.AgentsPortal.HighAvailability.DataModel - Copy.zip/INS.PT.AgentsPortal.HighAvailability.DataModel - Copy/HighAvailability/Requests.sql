DROP TABLE [dbo].[Requests]

CREATE TABLE [dbo].[Requests](
	[RequestRowId]  AS (((((((((((((((((((Trim(isnull(CONVERT([char],[InternalNumber]),''))+Trim(isnull(CONVERT([char],[ExternalNumber]),'')))+Trim(isnull(CONVERT([char],[Area]),'')))+Trim(isnull(CONVERT([char],[SubArea]),'')))+Trim(isnull(CONVERT([char],[Task]),'')))+Trim(isnull(CONVERT([char],[SubTask]),'')))+Trim(isnull(CONVERT([char],[Operation]),'')))+Trim(isnull(CONVERT([char],[Type]),'')))+Trim(isnull(CONVERT([char],[Nif]),'')))+Trim(isnull(CONVERT([char],[EntityName]),'')))+Trim(isnull(CONVERT([char],[PolicyNumber]),'')))+Trim(isnull(CONVERT([char],[ClaimNumber]),'')))+Trim(isnull(CONVERT([char],[StatusId]),'')))+Trim(isnull(CONVERT([char],[StatusDescription]),'')))+Trim(isnull(CONVERT([char],[AgentId]),'')))+Trim(isnull(CONVERT([char],[CreationUser]),'')))+Trim(isnull(CONVERT([char],[CreationDate]),'')))+Trim(isnull(CONVERT([char],[CloseDate]),'')))+Trim(isnull(CONVERT([char],[AuditCreationDate]),'')))+Trim(isnull(CONVERT([char],[AuditUpdatedDate]),''))),
	[InternalNumber] [nvarchar](50) NOT NULL,
	[ExternalNumber] [nvarchar](50) NOT NULL,
	[Area] [nvarchar](50) NULL,
	[SubArea] [nvarchar](50) NULL,
	[Task] [nvarchar](50) NULL,
	[SubTask] [nvarchar](50) NULL,
	[Operation] [nvarchar](50) NULL,
	[Type] [nvarchar](50) NULL,
	[Nif] [nvarchar](20) NULL,
	[EntityName] [nvarchar](300) NULL,
	[PolicyNumber] [nvarchar](50) NULL,
	[ClaimNumber] [nvarchar](50) NULL,
	[StatusId] [nvarchar](50) NULL,
	[StatusDescription] [nvarchar](300) NULL,
	[AgentId] [nvarchar](50) NULL,
	[CreationUser] [nvarchar](50) NULL,
	[CreationDate] [datetime] NULL,
	[CloseDate] [datetime] NULL,
	[AuditCreationDate] [datetime] NOT NULL,
	[AuditUpdatedDate] [datetime] NULL,
 CONSTRAINT [PK_InternalNumber] PRIMARY KEY CLUSTERED 
(
	[InternalNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


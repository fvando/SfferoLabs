DROP TABLE Claims

CREATE TABLE [dbo].[Claims](
	[ClaimRowId]  AS (((((((((((((Trim(isnull(CONVERT([char],[ClaimNumber]),''))+Trim(isnull(CONVERT([char],[PolicyNumber]),'')))+Trim(isnull(CONVERT([char],[Source]),'')))+Trim(isnull(CONVERT([char],[Nif]),'')))+Trim(isnull(CONVERT([char],[OccurrenceDate]),'')))+Trim(isnull(CONVERT([char],[OpenDate]),'')))+Trim(isnull(CONVERT([char],[CloseDate]),'')))+Trim(isnull(CONVERT([char],[SituationId]),'')))+Trim(isnull(CONVERT([char],[SituationDescription]),'')))+Trim(isnull(CONVERT([char],[SituationDate]),'')))+Trim(isnull(CONVERT([char],[PaymentsTotal]),'')))+Trim(isnull(CONVERT([char],[Reserve]),'')))+Trim(isnull(CONVERT([char],[AuditCreationDate]),'')))+Trim(isnull(CONVERT([char],[AuditUpdatedDate]),''))),
	[ClaimNumber] [nvarchar](50) NOT NULL,
	[PolicyNumber] [nvarchar](50) NOT NULL,
	[Source] [nvarchar](50) NULL,
	[Nif] [nvarchar](20) NULL,
	[OccurrenceDate] [datetime] NULL,
	[OpenDate] [datetime] NULL,
	[CloseDate] [datetime] NULL,
	[SituationId] [nvarchar](50) NULL,
	[SituationDescription] [nvarchar](300) NULL,
	[SituationDate] [datetime] NULL,
	[PaymentsTotal] [decimal](18, 2) NULL,
	[Reserve] [decimal](18, 2) NULL,
	[AuditCreationDate] [datetime] NOT NULL,
	[AuditUpdatedDate] [datetime] NULL,
 CONSTRAINT [PK_Claim] PRIMARY KEY CLUSTERED 
(
	[ClaimNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO



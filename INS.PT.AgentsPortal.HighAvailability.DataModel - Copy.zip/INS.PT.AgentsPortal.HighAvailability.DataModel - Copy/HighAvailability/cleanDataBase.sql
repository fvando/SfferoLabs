USE [DB_AgentsPortal_HighAvailability_PR]

delete from  [dbo].Claims;
delete from  [dbo].ComercialStructure;
delete from  [dbo].Entities;
delete from  [dbo].InsuredObjects;
delete from  [dbo].Policies;
delete from  [dbo].Receipts;
delete from  [dbo].Requests;
delete from  [dbo].ServiceBusMessages;
delete from  [dbo].WalletMovements;

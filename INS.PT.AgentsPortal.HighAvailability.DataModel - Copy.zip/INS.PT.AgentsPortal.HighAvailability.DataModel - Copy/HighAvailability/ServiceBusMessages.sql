DROP TABLE [dbo].[ServiceBusMessages]

CREATE TABLE [dbo].[ServiceBusMessages](
	[ServiceBusMessagesId] [int] IDENTITY(1,1) NOT NULL,
	[ProcessName] [nvarchar](20) NULL,
	[Source] [nvarchar](20) NULL,
	[Message] [nvarchar](max) NULL,
	[MessageProcessed] [int] NULL,
	[ErrorCode] [nvarchar](20) NULL,
	[ErrorDescritpion] [nvarchar](300) NULL,
	[ProcessDate] [datetime] NULL,
	[ReprocessDate] [datetime] NULL,
	[AuditCreationDate] [datetime] NULL,
	[AuditUpdatedDate] [datetime] NULL,
 CONSTRAINT [PK_ServiceBusMessages] PRIMARY KEY CLUSTERED 
(
	[ServiceBusMessagesId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO



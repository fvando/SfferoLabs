DROP TABLE [dbo].[Receipts]

CREATE TABLE [dbo].[Receipts](
	[ReceiptRowId]  AS ((((((((((((((((((((((((((Trim(isnull(CONVERT([char],[ReceiptNumber]),''))+Trim(isnull(CONVERT([char],[PolicyNumber]),'')))+Trim(isnull(CONVERT([char],[Nif]),'')))+Trim(isnull(CONVERT([char],[Company]),'')))+Trim(isnull(CONVERT([char],[AmountReceipt]),'')))+Trim(isnull(CONVERT([char],[Commission]),'')))+Trim(isnull(CONVERT([char],[Tax]),'')))+Trim(isnull(CONVERT([char],[TypeNatureId]),'')))+Trim(isnull(CONVERT([char],[TypeNatureDescription]),'')))+Trim(isnull(CONVERT([char],[EmissionDate]),'')))+Trim(isnull(CONVERT([char],[StartDate]),'')))+Trim(isnull(CONVERT([char],[MaturityDate]),'')))+Trim(isnull(CONVERT([char],[PaymentDueDate]),'')))+Trim(isnull(CONVERT([char],[AccountabilityId]),'')))+Trim(isnull(CONVERT([char],[AccountabilityDescription]),'')))+Trim(isnull(CONVERT([char],[SituationId]),'')))+Trim(isnull(CONVERT([char],[SituationDescription]),'')))+Trim(isnull(CONVERT([char],[SituationDate]),'')))+Trim(isnull(CONVERT([char],[MethodsPaymentId]),'')))+Trim(isnull(CONVERT([char],[MethodsPaymentDescription]),'')))+Trim(isnull(CONVERT([char],[AgentMediatorId]),'')))+Trim(isnull(CONVERT([char],[AgentCollectorId]),'')))+Trim(isnull(CONVERT([char],[ChannelId]),'')))+Trim(isnull(CONVERT([char],[ChannelDescription]),'')))+Trim(isnull(CONVERT([char],[BankCircuit]),'')))+Trim(isnull(CONVERT([char],[AuditCreationDate]),'')))+Trim(isnull(CONVERT([char],[AuditUpdatedDate]),''))),
	[ReceiptNumber] [nvarchar](50) NOT NULL,
	[PolicyNumber] [nvarchar](50) NOT NULL,
	[Nif] [nvarchar](20) NOT NULL,
	[Company] [nvarchar](20) NULL,
	[AmountReceipt] [decimal](18, 2) NULL,
	[Commission] [decimal](18, 2) NULL,
	[Tax] [decimal](18, 2) NULL,
	[TypeNatureId] [nvarchar](50) NULL,
	[TypeNatureDescription] [nvarchar](300) NULL,
	[EmissionDate] [datetime] NULL,
	[StartDate] [datetime] NULL,
	[MaturityDate] [datetime] NULL,
	[PaymentDueDate] [datetime] NULL,
	[AccountabilityId] [nvarchar](50) NULL,
	[AccountabilityDescription] [nvarchar](300) NULL,
	[SituationId] [nvarchar](50) NULL,
	[SituationDescription] [nvarchar](300) NULL,
	[SituationDate] [datetime] NULL,
	[MethodsPaymentId] [nvarchar](50) NULL,
	[MethodsPaymentDescription] [nvarchar](300) NULL,
	[AgentMediatorId] [nvarchar](50) NULL,
	[AgentCollectorId] [nvarchar](50) NULL,
	[ChannelId] [nvarchar](50) NULL,
	[ChannelDescription] [nvarchar](300) NULL,
	[BankCircuit] [bit] NULL,
	[AuditCreationDate] [datetime] NOT NULL,
	[AuditUpdatedDate] [datetime] NULL,
 CONSTRAINT [PK_Receipt] PRIMARY KEY CLUSTERED 
(
	[ReceiptNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


DROP TABLE [dbo].[WalletMovements]

CREATE TABLE [dbo].[WalletMovements](
	[MovementRowId]  AS ((((((((((((Trim(isnull(CONVERT([char],[CodeMovement]),''))+Trim(isnull(CONVERT([char],[Company]),'')))+Trim(isnull(CONVERT([char],[Nif]),'')))+Trim(isnull(CONVERT([char],[PolicyNumber]),'')))+Trim(isnull(CONVERT([char],[TypeId]),'')))+Trim(isnull(CONVERT([char],[TypeDescription]),'')))+Trim(isnull(CONVERT([char],[EventIdentify]),'')))+Trim(isnull(CONVERT([char],[MovementDate]),'')))+Trim(isnull(CONVERT([char],[AgentId]),'')))+Trim(isnull(CONVERT([char],[SituationId]),'')))+Trim(isnull(CONVERT([char],[SituationDescription]),'')))+Trim(isnull(CONVERT([char],[AuditCreationDate]),'')))+Trim(isnull(CONVERT([char],[AuditUpdatedDate]),''))),
	[CodeMovement] [nvarchar](50) NOT NULL,
	[Company] [nvarchar](20) NULL,
	[Nif] [nvarchar](20) NULL,
	[PolicyNumber] [nvarchar](50) NOT NULL,
	[TypeId] [nvarchar](50) NULL,
	[TypeDescription] [nvarchar](300) NULL,
	[EventIdentify] [nvarchar](50) NULL,
	[MovementDate] [datetime] NULL,
	[AgentId] [nvarchar](50) NULL,
	[SituationId] [nvarchar](10) NULL,
	[SituationDescription] [nvarchar](300) NULL,
	[AuditCreationDate] [datetime] NOT NULL,
	[AuditUpdatedDate] [datetime] NULL,
 CONSTRAINT [PK_WalletMovement] PRIMARY KEY CLUSTERED 
(
	[CodeMovement] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


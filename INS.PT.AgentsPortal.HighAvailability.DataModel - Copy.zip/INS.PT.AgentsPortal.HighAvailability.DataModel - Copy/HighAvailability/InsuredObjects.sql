DROP TABLE [dbo].[InsuredObjects]

CREATE TABLE [dbo].[InsuredObjects](
	[InsuredObjectRowId]  AS ((((Trim(isnull(CONVERT([char],[InsuredObjectId]),''))+Trim(isnull(CONVERT([char],[PolicyNumber]),'')))+Trim(isnull(CONVERT([char],[InsuredObjectDescription]),'')))+Trim(isnull(CONVERT([char],[AuditCreationDate]),'')))+Trim(isnull(CONVERT([char],[AuditUpdatedDate]),''))),
	[InsuredObjectId] [nvarchar](50) NOT NULL,
	[PolicyNumber] [nvarchar](50) NOT NULL,
	[InsuredObjectDescription] [nvarchar](500) NOT NULL,
	[AuditCreationDate] [datetime] NOT NULL,
	[AuditUpdatedDate] [datetime] NULL,
 CONSTRAINT [PK_InsuredObjects] PRIMARY KEY CLUSTERED 
(
	[InsuredObjectId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO





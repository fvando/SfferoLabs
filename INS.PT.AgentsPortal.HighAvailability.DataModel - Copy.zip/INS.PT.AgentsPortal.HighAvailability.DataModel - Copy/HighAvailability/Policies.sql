DROP TABLE [dbo].[Policies]

CREATE TABLE [dbo].[Policies](
	[PolicyRowId]  AS ((((((((((((((((((((((((((((Trim(isnull(CONVERT([char],[PolicyNumber]),''))+Trim(isnull(CONVERT([char],[Company]),'')))+Trim(isnull(CONVERT([char],[Source]),'')))+Trim(isnull(CONVERT([char],[Nif]),'')))+Trim(isnull(CONVERT([char],[SituationId]),'')))+Trim(isnull(CONVERT([char],[SituationDescription]),'')))+Trim(isnull(CONVERT([char],[SituationDate]),'')))+Trim(isnull(CONVERT([char],[EmissionDate]),'')))+Trim(isnull(CONVERT([char],[MaturityDate]),'')))+Trim(isnull(CONVERT([char],[PaymentDate]),'')))+Trim(isnull(CONVERT([char],[StartDate]),'')))+Trim(isnull(CONVERT([char],[MethodsPaymentId]),'')))+Trim(isnull(CONVERT([char],[MethodsPaymentDescription]),'')))+Trim(isnull(CONVERT([char],[LobId]),'')))+Trim(isnull(CONVERT([char],[LobDescription]),'')))+Trim(isnull(CONVERT([char],[ProductId]),'')))+Trim(isnull(CONVERT([char],[ProductDescription]),'')))+Trim(isnull(CONVERT([char],[CommercialPremium]),'')))+Trim(isnull(CONVERT([char],[PremiumIssued]),'')))+Trim(isnull(CONVERT([char],[PremiumCharged]),'')))+Trim(isnull(CONVERT([char],[FractionationId]),'')))+Trim(isnull(CONVERT([char],[FractionationDescription]),'')))+Trim(isnull(CONVERT([char],[DurationId]),'')))+Trim(isnull(CONVERT([char],[DurationDescription]),'')))+Trim(isnull(CONVERT([char],[AgentId]),'')))+Trim(isnull(CONVERT([char],[IssueByCentralizedOffice]),'')))+Trim(isnull(CONVERT([char],[DigitalSignaturePending]),'')))+Trim(isnull(CONVERT([char],[AuditCreationDate]),'')))+Trim(isnull(CONVERT([char],[AuditUpdatedDate]),''))),
	[PolicyNumber] [nvarchar](50) NOT NULL,
	[Company] [nvarchar](20) NULL,
	[Source] [nvarchar](50) NULL,
	[Nif] [nvarchar](20) NULL,
	[SituationId] [nvarchar](50) NULL,
	[SituationDescription] [nvarchar](300) NULL,
	[SituationDate] [datetime] NULL,
	[EmissionDate] [datetime] NULL,
	[MaturityDate] [datetime] NULL,
	[PaymentDate] [datetime] NULL,
	[StartDate] [datetime] NULL,
	[MethodsPaymentId] [nvarchar](50) NULL,
	[MethodsPaymentDescription] [nvarchar](300) NULL,
	[LobId] [nvarchar](50) NULL,
	[LobDescription] [nvarchar](300) NULL,
	[ProductId] [nvarchar](20) NULL,
	[ProductDescription] [nvarchar](300) NULL,
	[CommercialPremium] [decimal](18, 2) NULL,
	[PremiumIssued] [decimal](18, 2) NULL,
	[PremiumCharged] [decimal](18, 2) NULL,
	[FractionationId] [nvarchar](10) NULL,
	[FractionationDescription] [nvarchar](300) NULL,
	[DurationId] [nvarchar](50) NULL,
	[DurationDescription] [nvarchar](300) NULL,
	[AgentId] [nvarchar](50) NULL,
	[IssueByCentralizedOffice] [bit] NULL,
	[DigitalSignaturePending] [bit] NULL,
	[AuditCreationDate] [datetime] NOT NULL,
	[AuditUpdatedDate] [datetime] NULL,
 CONSTRAINT [PK_Policy] PRIMARY KEY CLUSTERED 
(
	[PolicyNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Policies]  WITH CHECK ADD  CONSTRAINT [FK_Policies_Policies] FOREIGN KEY([PolicyNumber])
REFERENCES [dbo].[Policies] ([PolicyNumber])
GO

ALTER TABLE [dbo].[Policies] CHECK CONSTRAINT [FK_Policies_Policies]
GO


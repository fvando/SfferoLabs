DROP TABLE [dbo].[Entities]

CREATE TABLE [dbo].[Entities](
	[EntityRowId]  AS ((((((((((((((((Trim(isnull(CONVERT([char],[EntityId]),''))+Trim(isnull(CONVERT([char],[Nif]),'')))+Trim(isnull(CONVERT([char],[ClientName]),'')))+Trim(isnull(CONVERT([char],[ClientSurname]),'')))+Trim(isnull(CONVERT([char],[BirthDate]),'')))+Trim(isnull(CONVERT([char],[Phone]),'')))+Trim(isnull(CONVERT([char],[Email]),'')))+Trim(isnull(CONVERT([char],[PostalCode]),'')))+Trim(isnull(CONVERT([char],[StatusId]),'')))+Trim(isnull(CONVERT([char],[StatusDescription]),'')))+Trim(isnull(CONVERT([char],[DescendantsNumber]),'')))+Trim(isnull(CONVERT([char],[GenderId]),'')))+Trim(isnull(CONVERT([char],[GenderDescription]),'')))+Trim(isnull(CONVERT([char],[CAE]),'')))+Trim(isnull(CONVERT([char],[CompanyEstablishmentDate]),'')))+Trim(isnull(CONVERT([char],[AuditCreationDate]),'')))+Trim(isnull(CONVERT([char],[AuditUpdatedDate]),''))),
	[EntityId] [nvarchar](20) NOT NULL,
	[Nif] [nvarchar](20) NULL,
	[ClientName] [nvarchar](300) NULL,
	[ClientSurname] [nvarchar](300) NULL,
	[BirthDate] [datetime] NULL,
	[Phone] [nvarchar](20) NULL,
	[Email] [nvarchar](100) NULL,
	[PostalCode] [nvarchar](10) NULL,
	[StatusId] [nvarchar](10) NULL,
	[StatusDescription] [nvarchar](300) NULL,
	[DescendantsNumber] [int] NULL,
	[GenderId] [nvarchar](1) NULL,
	[GenderDescription] [nvarchar](300) NULL,
	[CAE] [nvarchar](50) NULL,
	[CompanyEstablishmentDate] [datetime] NULL,
	[AuditCreationDate] [datetime] NOT NULL,
	[AuditUpdatedDate] [datetime] NULL,
 CONSTRAINT [PK_Entity] PRIMARY KEY CLUSTERED 
(
	[EntityId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO



DROP VIEW [dbo].[vw_elastic_policies]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_elastic_policies]
AS
 SELECT pol.PolicyNumber, 
	   	--pol.Company Policy_Company, 
	   	--Source Policy_Source, 
	   	--pol.Nif Policy_Entity_Nif,
		--ent.ClientName + '  ' + ent.ClientSurname As Policy_Entity_Name,
	   	--ent.BirthDate Policy_Entity_BirthDate,
		--ent.Phone Policy_Entity_Phone,
		--ent.Email Policy_Entity_Email,
	   	--SituationId Policy_SituationId, 
	   	--SituationDescription Policy_SituationDescription, 
	   	--SituationDate Policy_SituationDate, 
	   	--EmissionDate Policy_EmissionDate, 
	   	--MaturityDate Policy_MaturityDate, 
	   	--PaymentDate Policy_PaymentDate, 
	   	--StartDate Policy_StartDate, 
	   	--MethodsPaymentId Policy_MethodsPaymentId, 
	   	--MethodsPaymentDescription Policy_MethodsPaymentDescription, 
	   	--LobId Policy_LobId, 
	   	--LobDescription Policy_LobDescription, 
	   	--ProductId Policy_ProductId, 
	   	--ProductDescription Policy_ProductDescription, 
	   	--CommercialPremium Policy_CommercialPremium, 
	   	--PremiumIssued Policy_PremiumIssued, 
	   	--PremiumCharged Policy_PremiumCharged, 
	   	--FractionationId Policy_FractionationId, 
	   	--FractionationDescription Policy_FractionationDescription, 
	   	--DurationId Policy_DurationId, 
	   	--DurationDescription Policy_DurationDescription, 
	   	AgentId Policy_ComercialStructure_AgentId, 
		cst.ComercialStructureId Policy_ComercialStructureId, 
		--CollectionAgentId Policy_CollectionAgentId,
	   	--IssueByCentralizedOffice Policy_IssueByCentralizedOffice, 
	   	--DigitalSignaturePending Policy_DigitalSignaturePending, 
		--ProcoloId Policy_ProcoloId,
		--ProcoloDescription Policy_ProcoloDescription,
		--BonusMalus Policy_BonusMalus,
	   	pol.AuditCreationDate Policy_AuditCreationDate,
	   	pol.AuditUpdatedDate Policy_AuditUpdatedDate,
		'Policies' index_type
  FROM [dbo].[Policies] AS pol
    LEFT JOIN Entities AS ent ON ent.Nif = pol.Nif
	LEFT JOIN ComercialStructure AS cst ON cst.AgentCode = pol.AgentId 
  WHERE ( (pol.AuditUpdatedDate  > = DATEADD( MINUTE, -10, GETDATE())) OR 
          (pol.AuditCreationDate > = DATEADD( MINUTE, -10, GETDATE())) )
GO

DROP VIEW [dbo].[vw_elastic_requests]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_elastic_requests]
AS
 SELECT InternalNumber, 
		ExternalNumber Request_ExternalNumber, 
		--Area Request_Area, 
		--SubArea Request_SubArea, 
		--Task Request_Task, 
		--SubTask Request_SubTask, 
		--Operation Request_Operation, 
		--Type Request_Type, 
		--req.Nif Request_Entity_Nif, 
		--ent.ClientName + '  ' + ent.ClientSurname As Request_Entity_Name,
	   	--ent.BirthDate Request_Entity_BirthDate,
		--ent.Phone Request_Entity_Phone,
		--ent.Email Request_Entity_Email,
		--EntityName Request_EntityName, 
		--PolicyNumber Request_PolicyNumber, 
		--ClaimNumber Request_ClaimNumber, 
		--req.Status Request_Status, 
		--req.SubStatus Request_SubStatus, 
		--req.StatusDate Request_StatusDate,
		AgentId Request_AgentId, 
		cst.ComercialStructureId Request_ComercialStructureId, 
		--CreationUser Request_CreationUser, 
		--CreationDate Request_CreationDate, 
		--CloseDate Request_CloseDate, 
		--req.Visible Request_Visible, 
		--req.AuditCreationDate Request_AuditCreationDate, 
		--req.AuditUpdatedDate Request_AuditUpdatedDate
		'Requests' index_type
  FROM [dbo].Requests AS req
    LEFT JOIN Entities AS ent ON ent.Nif = req.Nif
    LEFT JOIN comercialStructure AS cst ON cst.AgentCode = req.AgentId 
  WHERE ( (req.AuditUpdatedDate  > = DATEADD( MINUTE, -10, GETDATE())) OR 
          (req.AuditCreationDate > = DATEADD( MINUTE, -10, GETDATE())) )
GO
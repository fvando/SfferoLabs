
DROP VIEW [dbo].[vw_elastic_comercialStructure]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_elastic_comercialStructure]
AS
SELECT  ComercialStructureId, 
        Company ComercialStructure_Company, 
		NetworkCode ComercialStructure_NetworkCode, 
		NetworkName ComercialStructure_NetworkName, 
		ZoneCode ComercialStructure_ZoneCode, 
		ZoneName ComercialStructure_ZoneName, 
		BranchCode ComercialStructure_BranchCode, 
		BranchName ComercialStructure_BranchName, 
		InspectorCode ComercialStructure_InspectorCode, 
		InspectorEntityId ComercialStructure_InspectorEntityId, 
		AgentCode ComercialStructure_AgentCode, 
		AgentEntityId ComercialStructure_AgentEntityId, 
		ASFNumber ComercialStructure_ASFNumber, 
		AuditCreationDate ComercialStructure_AuditCreationDate, 
		AuditUpdatedDate ComercialStructure_AuditUpdatedDate
  FROM [dbo].ComercialStructure
  WHERE AuditUpdatedDate > = DATEADD( MINUTE,-10, GETDATE())
GO
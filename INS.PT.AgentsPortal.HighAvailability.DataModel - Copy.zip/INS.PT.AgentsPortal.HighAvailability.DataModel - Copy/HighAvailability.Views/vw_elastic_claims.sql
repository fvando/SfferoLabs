
DROP VIEW [dbo].[vw_elastic_claims]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_elastic_claims]
AS
ALTER VIEW [dbo].[vw_elastic_claims]
AS
 SELECT cla.ClaimNumber, 
		cla.PolicyNumber Claim_PolicyNumber, 
		pol.AgentId Claim_ComercialStructure_AgentId, 
		cst.ComercialStructureId Claim_ComercialStructureId, 
		--Source Claim_Source, 
		--cl.Nif Claim_Entity_Nif, 
		--ent.ClientName + '  ' + ent.ClientSurname As Claim_Entity_Name,
		--ent.BirthDate Claim_Entity_BirthDate,
		--ent.Phone Claim_Entity_Phone,
		--ent.Email Claim_Entity_Email,
		--OccurrenceDate Claim_OccurrenceDate, 
		--OpenDate Claim_OpenDate, 
		--CloseDate Claim_CloseDate, 
		--SituationId Claim_SituationId, 
		--SituationDescription Claim_SituationDescription, 
		--SituationDate Claim_SituationDate, 
		--PaymentsTotal Claim_PaymentsTotal, 
		--Reserve Claim_Reserve, 
		--cl.AuditCreationDate Claim_AuditCreationDate, 
		--cl.AuditUpdatedDate Claim_AuditUpdatedDate,
		'Claims' index_type
  FROM [dbo].[Claims] AS cla
  LEFT JOIN entities AS ent ON ent.Nif = cla.Nif
  LEFT JOIN policies AS pol ON pol.PolicyNumber = cla.PolicyNumber
  LEFT JOIN comercialStructure AS cst ON cst.AgentCode = pol.AgentId 
  WHERE ( (cla.AuditUpdatedDate  > = DATEADD( MINUTE, -10, GETDATE())) OR 
          (cla.AuditCreationDate > = DATEADD( MINUTE, -10, GETDATE())) )
GO
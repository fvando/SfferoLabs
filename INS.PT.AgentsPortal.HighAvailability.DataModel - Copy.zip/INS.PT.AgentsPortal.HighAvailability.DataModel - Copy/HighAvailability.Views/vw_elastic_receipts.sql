
DROP VIEW [dbo].[vw_elastic_receipts]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_elastic_receipts]
AS
SELECT  ReceiptNumber, 
        rec.PolicyNumber Receipt_PolicyNumber, 
		pol.AgentId Receipt_ComercialStructure_AgentId, 
		cst.ComercialStructureId Receipt_ComercialStructureId, 
		--rec.Nif Receipt_Entity_Nif, 
		--ent.ClientName + '  ' + ent.ClientSurname As Receipt_Entity_Name,
	   	--ent.BirthDate Receipt_Entity_BirthDate,
		--ent.Phone Receipt_Entity_Phone,
		--ent.Email Receipt_Entity_Email,
		--rec.Company Receipt_Company, 
		--AmountReceipt Receipt_AmountReceipt, 
		--Commission Receipt_Commission, 
		--Tax Receipt_Tax, 
		--TypeNatureId Receipt_TypeNatureId, 
		--TypeNatureDescription Receipt_TypeNatureDescription, 
		--rec.EmissionDate Receipt_EmissionDate, 
		--rec.StartDate Receipt_StartDate, 
		--rec.MaturityDate Receipt_MaturityDate, 
		--PaymentDueDate Receipt_PaymentDueDate, 
		--AccountabilityId Receipt_AccountabilityId, 
		--rec.SituationId Receipt_SituationId, 
        --rec.SituationDescription Receipt_SituationDescription, 
		--rec.SituationDate Receipt_SituationDate, 
		--rec.MethodsPaymentId Receipt_MethodsPaymentId, 
		--rec.MethodsPaymentDescription Receipt_MethodsPaymentDescription, 
		--AgentMediatorId Receipt_AgentMediatorId, 
		--AgentCollectorId Receipt_AgentCollectorId, 
		--ChannelId Receipt_ChannelId, 
		--ChannelDescription Receipt_ChannelDescription, 
		--BankCircuit Receipt_BankCircuit, 
		--ClearingReason Receipt_ClearingReason, 
		--rec.AuditCreationDate Receipt_AuditCreationDate, 
		--rec.AuditUpdatedDate Receipt_AuditUpdatedDate,
		'Receipts' index_type
  FROM [dbo].Receipts AS rec
  LEFT JOIN Entities AS ent ON ent.Nif = rec.Nif
  LEFT JOIN policies AS pol ON pol.PolicyNumber = rec.PolicyNumber
  LEFT JOIN comercialStructure AS cst ON cst.AgentCode = pol.AgentId 
  WHERE ( (rec.AuditUpdatedDate  > = DATEADD( MINUTE, -10, GETDATE())) OR 
          (rec.AuditCreationDate > = DATEADD( MINUTE, -10, GETDATE())) )
GO

DROP VIEW [dbo].[vw_elastic_walletMovements]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_elastic_walletMovements]
AS
 SELECT MovementId, 
		CodeMovement WalletMovement_CodeMovement,
		--wal.Company WalletMovement_Company,
		--Source WalletMovement_Source,
		--wal.Nif WalletMovement_Nif,
		--PolicyNumber WalletMovement_PolicyNumber,
		--TypeId WalletMovement_TypeId,
		--TypeDescription WalletMovement_TypeDescription,
		--MovementDate WalletMovement_MovementDate,
		--AgentId WalletMovement_AgentId,
		--ent.ClientName + '  ' + ent.ClientSurname As Name,
	   	--ent.BirthDate,
		--ent.Phone,
		--ent.Email
		'WalletMovements' index_type
  FROM [dbo].WalletMovements AS wal
  LEFT JOIN Entities AS Ent ON ent.Nif = wal.Nif
  WHERE ( (wal.AuditUpdatedDate  > = DATEADD( MINUTE, -10, GETDATE())) OR 
          (wal.AuditCreationDate > = DATEADD( MINUTE, -10, GETDATE())) ) AND
		1=2 -- for now this table is not to be index
GO
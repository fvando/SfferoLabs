
DROP VIEW [dbo].[vw_elastic_insuredObjects]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_elastic_insuredObjects]
AS
 SELECT InsuredObjectId, 
		ins.PolicyNumber InsuredObject_PolicyNumber, 
		pol.AgentId InsuredObject_ComercialStructure_AgentId, 
		cst.ComercialStructureId InsuredObject_ComercialStructureId, 
		InsuredObjectDescription InsuredObject_InsuredObjectDescription, 
		LicencePlate InsuredObject_LicencePlate,
		ins.Nif InsuredObject_Entity_Nif,
		--ent.ClientName + '  ' + ent.ClientSurname As InsuredObject_Entity_Name,
		--ent.Phone InsuredObject_Entity_Phone,
		--ent.Email InsuredObject_Entity_Email,
		--ins.BirthDate InsuredObject_BirthDate,
		--ins.AuditCreationDate InsuredObject_AuditCreationDate, 
		--ins.AuditUpdatedDate InsuredObject_AuditUpdatedDate,
		'InsuredObjects' index_type
  FROM [dbo].InsuredObjects AS ins
    LEFT JOIN Policies AS pol ON pol.PolicyNumber = ins.PolicyNumber
    LEFT JOIN comercialStructure AS cst ON cst.AgentCode = pol.AgentId 
    LEFT JOIN Entities AS ent ON ent.Nif = pol.Nif
  WHERE ( (ins.AuditUpdatedDate  > = DATEADD( MINUTE, -10, GETDATE())) OR 
          (ins.AuditCreationDate > = DATEADD( MINUTE, -10, GETDATE())) )
GO
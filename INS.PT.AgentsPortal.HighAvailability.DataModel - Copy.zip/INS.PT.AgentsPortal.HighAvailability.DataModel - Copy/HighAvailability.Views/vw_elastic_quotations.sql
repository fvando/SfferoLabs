
DROP VIEW [dbo].[vw_elastic_quotations]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_elastic_quotations]
AS
SELECT Id QuotationId, 
	   SimulationNumber Quotation_SimulationNumber, 
	   QuotationNumber Quotation_QuotationNumber, 
	   PolicyNumber Quotation_PolicyNumber, 
	   InternalId Quotation_InternalId, 
	   --UserName Quotation_UserName, 
	   --quo.Company Quotation_Company, 
	   --Source Quotation_Source, 
	   --Nif Quotation_Nif, 
	   --Name Quotation_Name, 
	   --SituationId Quotation_SituationId, 
	   --SituationDescription Quotation_SituationDescription, 
	   --CreationDate Quotation_CreationDate, 
	   --ExpirationDate Quotation_ExpirationDate, 
	   --SituationDate Quotation_SituationDate, 
	   --LobId Quotation_LobId, 
	   --LobDescription Quotation_LobDescription,
	   --ProductId Quotation_ProductId, 
	   --ProductDescription Quotation_ProductDescription, 
	   AgentId Quotation_AgentId, 
	   cst.ComercialStructureId Claim_ComercialStructureId, 
	   LicensePlate Quotation_LicensePlate, 
	   --Description Quotation_Description, 
	   --SimulationState Quotation_SimulationState, 
	   --QuotationState Quotation_QuotationState, 
	   --SimulationDate Quotation_SimulationDate, 
	   --QuotationDate Quotation_QuotationDate, 
	   --quo.AuditCreationDate Quotation_AuditCreationDate, 
	   --quo.AuditUpdatedDate Quotation_AuditUpdatedDate,
	   'Quotations' index_type
   FROM dbo.Quotations quo
     LEFT JOIN comercialStructure AS cst ON cst.AgentCode = quo.AgentId
  WHERE ( (quo.AuditUpdatedDate  > = DATEADD( MINUTE, -10, GETDATE())) OR 
          (quo.AuditCreationDate > = DATEADD( MINUTE, -10, GETDATE())) )
GO
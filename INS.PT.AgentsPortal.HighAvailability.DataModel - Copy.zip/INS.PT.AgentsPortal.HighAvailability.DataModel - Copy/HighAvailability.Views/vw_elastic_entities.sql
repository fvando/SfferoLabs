
DROP VIEW [dbo].[vw_elastic_entities]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[vw_elastic_entities]
AS
 SELECT EntityId, 
       Nif Entity_Nif, 
	   --Company Entity_Company,
	   ClientName Entity_ClientName, 
	   ClientSurname Entity_ClientSurname, 
	   BirthDate Entity_BirthDate, 
	   Phone Entity_Phone,
	   Email Entity_Email, 
	   --PostalCode Entity_PostalCode, 
	   --StatusId Entity_StatusId, 
	   --StatusDescription Entity_StatusDescription, 
	   --DescendantsNumber Entity_DescendantsNumber, 
	   --GenderId Entity_GenderId, 
	   --CAE Entity_CAE, 
	   --GenderDescription Entity_GenderDescription, 
	   --CompanyEstablishmentDate Entity_CompanyEstablishmentDate, 
	   --IsSelfEmployed Entity_IsSelfEmployed, 
	   --AuditCreationDate Entity_AuditCreationDate, 
       --AuditUpdatedDate Entity_AuditUpdatedDate
	   'Entities' index_type
  FROM [dbo].Entities 
  WHERE ( (AuditUpdatedDate  > = DATEADD( MINUTE, -10, GETDATE())) OR 
          (AuditCreationDate > = DATEADD( MINUTE, -10, GETDATE())) )
GO
USE [DB_AgentsPortal_HighAvailability_TS]
GO

SET ANSI_PADDING ON
GO

/****** Object:  Index [uidx_Policies_Nif]    Script Date: 04/09/2019 17:01:34 ******/
CREATE NONCLUSTERED INDEX [uidx_Policies_Nif] ON [dbo].[Policies]
(
	[Nif] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO



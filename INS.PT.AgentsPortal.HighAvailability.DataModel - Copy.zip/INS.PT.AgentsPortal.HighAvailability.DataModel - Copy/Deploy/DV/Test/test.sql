print 'Start script'

select @@VERSION

print @@VERSION

print 'End script'
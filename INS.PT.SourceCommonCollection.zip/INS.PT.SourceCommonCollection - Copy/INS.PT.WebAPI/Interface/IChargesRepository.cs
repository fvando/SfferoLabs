﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// IChargesRepository
    /// </summary>
    public interface IChargesRepository
    {
        /// <summary>
        /// Gets the charged asynchronous.
        /// </summary>
        /// <param name="requestCharged">The request charged.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.Partners.Charged.ZFscdCobradosPostWsResponse1> GetChargedAsync(INS.PT.WebAPI.Model.Partners.Charged.ZFscdCobradosPostWs requestCharged);
    }
}

﻿using INS.PT.WebAPI.Constants;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.Domain;
using INS.PT.WebAPI.Model.Domain.CanonicalCoverage;
using INS.PT.WebAPI.Model.DTO;
using System;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Constants.CommonEnums;

namespace INS.PT.WebAPI.Interface
{
   public interface IStatesRepository
    {
        /// <summary>
        /// Gets the list entities.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        Task<GlobalEntityOutput> GetListEntities(GlobalEntityInput requestObject);
      
        /// <summary>
        /// Gets the list all.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        Task<GlobalEntityOutput> GetListAll(DomainsData requestObject);
        /// <summary>
        /// Sets the memory cache.
        /// </summary>
        /// <param name="IdDomain">The identifier domain.</param>
        /// <param name="Active">if set to <c>true</c> [active].</param>
        /// <returns></returns>
        Task<GlobalEntityOutput> SetMemoryCache(DomainsData IdDomain, Boolean Active = false);
        /// <summary>
        /// Getbies the value.
        /// </summary>
        /// <param name="codInterno">The cod interno.</param>
        /// <returns></returns>
        Task<string> GetbyValueAsync(string codInterno, CommonEnums.DomainsData domainData);

        /// <summary>
        /// Gets the receipt coverage.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        Task<ReceiptCoverageOutput> GetReceiptCoverageAsync(ReceiptCoverageInput requestObject);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="policyNumber"></param>
        /// <returns></returns>
        Task<HamedPolicyListOutput> GetHamedPoliciesAsync(string policyNumber);
        Task<HamedReceiptListOutput> GetHamedReceiptsAsync(string policyNumber);
    }
}

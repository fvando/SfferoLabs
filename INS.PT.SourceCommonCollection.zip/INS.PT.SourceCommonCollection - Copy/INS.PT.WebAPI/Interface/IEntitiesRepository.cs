﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// IEntitiesRepository
    /// </summary>
    public interface IEntitiesRepository
    {
        Task<ServiceNotification.ServiceReference.ZFscdServiceNotificationWsResponse1> GetNotifyAsync(ServiceNotification.ServiceReference.ZFscdServiceNotificationWs requestNotify);
    }
}

﻿using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// IIbanValidationRepository
    /// </summary>
    public interface IIbanRepository
    {
        Task<INS.PT.WebAPI.Model.Partners.Iban.ZFscdCheckIbanWsResponse1> CheckIbanWsAsync(INS.PT.WebAPI.Model.Partners.Iban.ZFscdCheckIbanWs requestIban);
    }
}

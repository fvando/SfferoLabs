﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// IWebReceiptListingRepository
    /// </summary>
    public interface IWebReceiptListingRepository
    {
       
        Task<Model.Partners.WebReceiptListing.ZFscdRecibosListarWsResponse> GestListAsync(Model.Partners.WebReceiptListing.ZFscdRecibosListarWs requestReceipt);

        Task<Model.Partners.WebReceiptListing.ZfscdRecibosWorkLinha> GestListDetailAsync(Model.Partners.WebReceiptListing.ZFscdRecibosListarWs requestReceipt);

        Task<Model.GetOutstandingPolicyPremiumsWASPOutputData> GetOutstandingPolicyPremiumsWASPAsync(Model.GetOutstandingPolicyPremiumsWASPInputData inputData);

    }
}

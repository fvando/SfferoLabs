﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// 
    /// </summary>
    public interface ICancellationsRepository
    {
        /// <summary>
        /// Gets the cancellation cancel asynchronous.
        /// </summary>
        /// <param name="requestCancelReceipt">The request cancel receipt.</param>
        /// <returns></returns>
        Task<Model.Partners.Cancel.ZFscdAnularRecibosPostWsResponse1> GetCancellationCancelAsync(Model.Partners.Cancel.ZFscdAnularRecibosPostWs requestCancelReceipt);
        /// <summary>
        /// Gets the cancellation policy asynchronous.
        /// </summary>
        /// <param name="requestPolicyReceipt">The request policy receipt.</param>
        /// <returns></returns>
        Task<Model.Partners.Cancel.ZFscdAnularApolicesPostWsResponse1> GetCancellationPolicyAsync(Model.Partners.Cancel.ZFscdAnularApolicesPostWs requestPolicyReceipt);

        /// <summary>
        /// Gets the cancellation cancel dates asynchronous.
        /// </summary>
        /// <param name="requestCancelDates">The request cancel dates.</param>
        /// <returns></returns>
        Task<Model.Partners.Cancel.ZFscdAnularDatasPostWsResponse1> GetCancellationCancelDatesAsync(Model.Partners.Cancel.ZFscdAnularDatasPostWs requestCancelDates);

    }
}

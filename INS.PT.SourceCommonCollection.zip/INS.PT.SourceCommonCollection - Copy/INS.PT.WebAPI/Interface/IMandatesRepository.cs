﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// IMandatesRepository
    /// </summary>
    public interface IMandatesRepository
    {
        Task<Model.Partners.Mandate.ZFscdMandatosPostWsResponse1> GetMandatesAsync(Model.Partners.Mandate.ZFscdMandatosPostWs requestMandates);
    }
}

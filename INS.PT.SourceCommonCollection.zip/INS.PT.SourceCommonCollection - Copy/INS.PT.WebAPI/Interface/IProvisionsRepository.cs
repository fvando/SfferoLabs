﻿using INS.PT.WebAPI.Helper;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// IProvisionsRepository
    /// </summary>
    public interface IProvisionsRepository
    {
        Task<Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWsResponse1> GetQueryAsync(Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWs requestQuery);
        Task<ChargedReceiptLineDetailResponse> GetChargedAsync(Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWs requestCharge);
        Task<ChargedReceiptLineDetailResponse> GetChargedAsync(string requestValue);
        Task<LiquidatePaymentsLineDetailResponse> GetLiquidateAsync(Model.Partners.ProvisionWebAccount.ZFscdPcLiquidarWs requestLiquidate);
        Task<Model.Partners.ProvisionWebAccount.ZFscdPcListarWsResponse1> GetListAsync(Model.Partners.ProvisionWebAccount.ZFscdPcListarWs requestList);
        Task<ValidateReceiptLineDetailResponse> GetValidateAsync(Model.Partners.ProvisionWebAccount.ZFscdPcValidarWs requestValidade);
        Task<Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWsResponse1> GetKpiAsync(Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWs requestValidade);
        Task<Model.Partners.ProvisionWebAccount.ZFscdPcContaEfetivaWsResponse1> GetContaEfetivaAsync(Model.Partners.ProvisionWebAccount.ZFscdPcContaEfetivaWs requestValidade);
        Task<Model.Partners.ProvisionWebAccount.ZFscdPcRecibosAgregadoWsResponse1> GetAggregatesReceiptsAsync(Model.Partners.ProvisionWebAccount.ZFscdPcRecibosAgregadoWs requestAggregatesReceipts);
        Task<Model.Partners.ProvisionWebAccount.ZFscdPcEliminarWsResponse1> PostEliminateReceiptsAsync(Model.Partners.ProvisionWebAccount.ZFscdPcEliminarWs requestEliminateReceipts);
    }
}

﻿using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Model.Partners.ProvisionWebAccount;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    public interface ITransformationData
    {

        Task<Model.Partners.ProvisionWebAccount.ZFscdPcListarWsResponse1> PutDomainAsync(Model.Partners.ProvisionWebAccount.ZFscdPcListarWsResponse1 requestList);
        ValidateReceiptLineDetailResponse ValidateList(ZFscdPcValidarWs inputList, ZFscdPcValidarWsResponse1 outPutList);

    }
}

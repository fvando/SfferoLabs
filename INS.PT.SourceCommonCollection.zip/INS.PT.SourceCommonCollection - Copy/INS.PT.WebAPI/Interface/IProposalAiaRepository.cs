﻿using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// IPolicyAiaRepository
    /// </summary>
    public interface IProposalAiaRepository
    {
        /// <summary>
        /// Gets the life proposal asynchronous.
        /// </summary>
        /// <param name="requestPolicy">The request policy.</param>
        /// <returns></returns>
        Task<Model.Partners.Get.ProposalAIA.ZageasLifeGetProposalWsResponse> GetLifeProposalAsync(Model.Partners.Get.ProposalAIA.ZageasLifeGetProposalWs requestPolicy);

        /// <summary>
        /// Upds the life proposal asynchronous.
        /// </summary>
        /// <param name="requestPolicy">The request policy.</param>
        /// <returns></returns>
        Task<Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWsResponse> UpdLifeProposalAsync(Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWs requestPolicy);

        /// <summary>
        /// Gets the before charge life proposal asynchronous.
        /// </summary>
        /// <param name="requestPolicy">The request policy.</param>
        /// <returns></returns>
        Task<Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse> GetBeforeChargeLifeProposalAsync(
            Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWs requestPolicy);
    }
}

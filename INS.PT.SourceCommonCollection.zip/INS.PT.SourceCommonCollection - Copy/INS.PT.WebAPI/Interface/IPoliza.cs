﻿
using SAP.Extern.WCF.WebReciptListing.Service.Reference.Tst;

namespace INS.PT.WebAPI.Interface
{
    public interface IPoliza
    {
        /// <summary>
        /// Submits the store procedure poliza.
        /// </summary>
        /// <param name="oraclePoliza">The oracle poliza.</param>
        /// <returns></returns>
        string SubmitStoreProcedurePoliza(string oraclePoliza);

        /// <summary>
        /// Validates the input poliza.
        /// </summary>
        /// <param name="poliza">The poliza.</param>
        /// <returns></returns>
        string ValidateInputPoliza(string poliza);

        /// <summary>
        /// Updates the number poliza.
        /// </summary>
        /// <param name="receiptResult">The receipt result.</param>
        /// <returns></returns>
        ZFscdRecibosListarWsResponse1 UpdateNumPoliza(ZFscdRecibosListarWsResponse1 receiptResult);

    }
}

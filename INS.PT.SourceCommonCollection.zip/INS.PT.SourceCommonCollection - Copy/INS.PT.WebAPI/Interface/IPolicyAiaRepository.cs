﻿using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// IPolicyAiaRepository
    /// </summary>
    public interface IPolicyAiaRepository
    {
        Task<SAP.Extern.WCF.Police.AIA.Service.Reference.Tst.ZFscdAiaGetApolicesWsResponse1> GetPolicyAiaAsync(INS.PT.WebAPI.Model.Partners.PolicyAIA.ZfscdAiaGetPolicysWs requestPolicy);
    }
}

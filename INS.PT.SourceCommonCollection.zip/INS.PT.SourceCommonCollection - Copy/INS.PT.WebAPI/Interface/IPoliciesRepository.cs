﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// IPoliciesRepository
    /// </summary>
    public interface IPoliciesRepository
    {
        Task<INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWsResponse1> GetMediatorAsync(INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWs requestMediator);
        Task<INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWsResponse1> GetPolicyAsync(INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWs requestPolicy);
        Task<INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWsResponse1> GetClaimsAsync(INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWs requestSinister);
    }
}

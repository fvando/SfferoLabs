﻿using INS.PT.CommonLibrary.Exceptions.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// IDocumentsRepository
    /// </summary>
    public interface IDocumentsRepository
    {
        /// <summary>
        /// Gets the documents asynchronous.
        /// </summary>
        /// <param name="requestDocument">The request document.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWsResponse1> GetDocumentsAsync(INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWs requestDocument);
   
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

/// <summary>
///  INS.PT.WebAPI
/// </summary>
namespace INS.PT.WebAPI
{
    /// <summary>
    /// IDbconnectioncs
    /// </summary>
    public interface IDbconnectioncs
    {
        /// <summary>
        /// GetConnection
        /// </summary>
        /// <returns></returns>
        IDbConnection GetConnection { get; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// IGreenLettersRepository
    /// </summary>
    public interface IGreenLettersRepository
    {
        /// <summary>
        /// Gets the green letter asynchronous.
        /// </summary>
        /// <param name="requestDocument">The request document.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWsResponse1> GetGreenLetterAsync(INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWs requestDocument);
    }
}

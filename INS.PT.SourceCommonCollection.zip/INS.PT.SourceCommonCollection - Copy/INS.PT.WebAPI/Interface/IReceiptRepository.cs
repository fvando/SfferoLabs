﻿using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.DTO;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// IReceiptRepository
    /// </summary>
    public interface IReceiptRepository
    {
        /// <summary>
        /// Submits the store procedure.
        /// </summary>
        /// <param name="OracleExec">The oracle execute.</param>
        /// <param name="InPutParamOracle">The in put parameter oracle.</param>
        /// <returns></returns>
        ReceiptCoverageOutPutDTO SubmitStoreProcedure(string OracleExec, OracleDynamicParameters InPutParamOracle);

        /// <summary>
        /// Validates the parameters.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        OracleDynamicParameters ValidateParams(ReceiptCoverageInput parameters);

        /// <summary>
        /// Gets the receipt asynchronous.
        /// </summary>
        /// <param name="inputData">The input data.</param>
        /// <returns></returns>
        Task<ReceiptCoverageOutPutDTO> GetReceiptAsync(ReceiptCoverageInput inputData);
    }
}

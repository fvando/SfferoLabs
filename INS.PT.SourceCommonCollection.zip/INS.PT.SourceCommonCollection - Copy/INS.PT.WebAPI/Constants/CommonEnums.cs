﻿using INS.PT.WebAPI.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Constants
{
    public class CommonEnums
    {

//        public enum IncomingPaymentDomain
//        {

//            A
//                SEGUROS DA COMPANHIA
//B    
//                BALCAO
//D    
//                DACB - DEBITO AUTOMATICO
//E    
//                CO-SEGURO
//F    
//                FUNCIONAROS
//G    
//                CARTÃO DE CRÉDITO
//M    
//                MEDIADOR
//R    
//                SEPA DD (PC's)
//S SEPA DD(Prémios)
//T CORRETOR
//W DACB- DESCENT.CONVERSÃO
//X    DACB- DEBITO CONTA CENTRALIZAD
//Y    DACB- CENTRALIZADO CONVERSÃO


//            /// <summary>
//            /// SAP - Lista de Ramos SAP
//            /// </summary>
//            [AmbientValue("SAP004")]
//            SAP004
//        }

        public enum DomainsData
        {
            /// <summary>
            /// SAP - Lista de Ramos SAP
            /// </summary>
            [AmbientValue("SAP004")]
            SAP004,

            /// <summary>
            /// Descrição de motivo de devolução
            /// </summary>
            [AmbientValue("PA041")]
            PA041
        }

        public enum Level
        {
            [EnumMember]
            [Description("Company")]
            [AmbientValue("Company")]
            Company = 1,

            [EnumMember]
            [Description("Network")]
            [AmbientValue("Network")]
            Network = 2,

            [EnumMember]
            [Description("Zone")]
            [AmbientValue("Zone")]
            Zone = 3,

            [EnumMember]
            [Description("Branch")]
            [AmbientValue("Branch")]
            Branch = 4,

            [EnumMember]
            [Description("Inspector")]
            [AmbientValue("Inspector")]
            Inspector = 5,

            [EnumMember]
            [Description("ASF")]
            [AmbientValue("ASF")]
            ASF = 6,

            [EnumMember]
            [Description("Agent")]
            [AmbientValue("Agent")]
            Agent = 7,
        }

        public enum HttpRequestVerb
        {
            [EnumMember]
            GET,
            [EnumMember]
            POST,
            [EnumMember]
            PUT,
            [EnumMember]
            DELETE,
            [EnumMember]
            UPDATE
        }

        public enum OrderData
        {
            [EnumMember]
            [Description("Ascending")]
            [AmbientValue("Ascending")]
            [StringValue("Ascending")]
            Ascending,
            [EnumMember]
            [Description("Descending")]
            [AmbientValue("Descending")]
            [StringValue("Descending")]
            Descending
        }
    }
}

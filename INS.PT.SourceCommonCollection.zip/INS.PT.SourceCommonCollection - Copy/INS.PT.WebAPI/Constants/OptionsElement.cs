﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Constants
{
    public class OptionsElement
    {
        public bool HandleList404Response { get; set; }
    }
}

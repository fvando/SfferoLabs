﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Contants
{
    public static class AgentsPortalErrors
    {
        public const string UnexpectedError = "Unexpected Error.";
        public const string GenericError = "An Error as occurred. Please try again.";

        public static class AuthorizationErrors
        {
            public const string InvalidSession = "Invalid Session.";
            public const string InvalidToken = "Invalid Token.";
            public const string NoProfileFound = "No profile found.";
        }

        public static class GPSegurosErrors
        {
            public const string TokenCreationError = "Token not created.";            
        }

        public static class Documents
        {
            public const string DocumentNotFound = "Document not found.";
        }

        public static class AgentErros
        {
            public const string NoAgentFound = "No Agent found.";
        }
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Constants
{
    /// <summary>
    /// 
    /// </summary>
    public static class AgentsPortalEnums
    {
        /// <summary>
        /// 
        /// </summary>
        public enum ReferenceTypePerson
        {
            /// <summary>
            /// 
            /// </summary>
            [StringValue("N")]
            Network = 1,
            /// <summary>
            /// 
            /// </summary>
            [StringValue("Z")]
            Zone = 2,
            /// <summary>
            /// 
            /// </summary>
            [StringValue("B")]
            Branch = 3,
            /// <summary>
            /// 
            /// </summary>
            [StringValue("I")]
            Inspector = 4,
            /// <summary>
            /// 
            /// </summary>
            [StringValue("A")]
            Agent = 5,
            /// <summary>
            /// 
            /// </summary>
            [StringValue("C")]
            Company = 6
        }

        /// <summary>
        /// Gets the reference type person.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public static ReferenceTypePerson GetReferenceTypePerson(string value)
        {
            return (ReferenceTypePerson)Enum.Parse(typeof(ReferenceTypePerson), value);
        }

      
        /// <summary>
        /// 
        /// </summary>
        public enum ComercialStructureData
        {
            /// <summary>
            /// 
            /// </summary>
            [EnumMember]
            [Description("ComercialStructureId")]
            [AmbientValue("ComercialStructureId")]
            ComercialStructureId,
            /// <summary>
            /// 
            /// </summary>
            [EnumMember]
            [Description("Company")]
            [AmbientValue("Company")]
            Company,
            /// <summary>
            /// 
            /// </summary>
            [EnumMember]
            [Description("NetworkCode")]
            [AmbientValue("NetworkCode")]
            NetworkCode,
            /// <summary>
            /// 
            /// </summary>
            [EnumMember]
            [Description("NetworkName")]
            [AmbientValue("NetworkName")]
            NetworkName,
            /// <summary>
            /// 
            /// </summary>
            [EnumMember]
            [Description("ZoneCode")]
            [AmbientValue("ZoneCode")]
            ZoneCode,
            /// <summary>
            /// 
            /// </summary>
            [EnumMember]
            [Description("ZoneName")]
            [AmbientValue("ZoneName")]
            ZoneName,
            /// <summary>
            /// 
            /// </summary>
            [EnumMember]
            [Description("BranchCode")]
            [AmbientValue("BranchCode")]
            BranchCode,
            /// <summary>
            /// 
            /// </summary>
            [EnumMember]
            [Description("BranchName")]
            [AmbientValue("BranchName")]
            BranchName,
            /// <summary>
            /// 
            /// </summary>
            [EnumMember]
            [Description("InspectorCode")]
            [AmbientValue("InspectorCode")]
            InspectorCode,
            /// <summary>
            /// 
            /// </summary>
            [EnumMember]
            [Description("InspectorEntityId")]
            [AmbientValue("InspectorEntityId")]
            InspectorEntityId,
            /// <summary>
            /// 
            /// </summary>
            [EnumMember]
            [Description("AgentCode")]
            [AmbientValue("AgentCode")]
            AgentCode,
            /// <summary>
            /// 
            /// </summary>
            [EnumMember]
            [Description("AgentEntityId")]
            [AmbientValue("AgentEntityId")]
            AgentEntityId,
            /// <summary>
            /// 
            /// </summary>
            [EnumMember]
            [Description("ASFNumber")]
            [AmbientValue("ASFNumber")]
            ASFNumber
        }
    }
}

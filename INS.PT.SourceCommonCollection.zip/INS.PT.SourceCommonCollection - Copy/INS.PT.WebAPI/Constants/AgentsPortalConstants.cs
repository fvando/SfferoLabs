﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Constants
{
    /// <summary>
    /// 
    /// </summary>
    public static class AgentsPortalConstants
    {
        /// <summary>
        ///
        /// </summary>
        public static class ServicesStatus
        {
            private const string oK = "0";
            private const string nOK = "-1";

            /// <summary>
            /// Gets the nok.
            /// </summary>
            /// <value>
            /// The nok.
            /// </value>
            public static string NOK => nOK;
            /// <summary>
            /// Gets the ok.
            /// </summary>
            /// <value>
            /// The ok.
            /// </value>
            public static string OK => oK;
        }

        /// <summary>
        /// 
        /// </summary>
        public static class BrokerHeader
        {
            private const string contentType = "Content-Type";
            private const string accept = "Accept";
            private const string webService = "bsWebService";
            private const string solution = "bsSolution";
            private const string user = "bsUser";
            private const string webmethod = "bsWebmethod";
            private const string idCompany = "idCompany";
            private const string idNetwork = "idNetwork";

            /// <summary>
            /// Gets the type of the content.
            /// </summary>
            /// <value>
            /// The type of the content.
            /// </value>
            public static string ContentType => contentType;

            /// <summary>
            /// Gets the accept.
            /// </summary>
            /// <value>
            /// The accept.
            /// </value>
            public static string Accept => accept;

            /// <summary>
            /// Gets the web service.
            /// </summary>
            /// <value>
            /// The web service.
            /// </value>
            public static string WebService => webService;

            /// <summary>
            /// Gets the solution.
            /// </summary>
            /// <value>
            /// The solution.
            /// </value>
            public static string Solution => solution;

            /// <summary>
            /// Gets the user.
            /// </summary>
            /// <value>
            /// The user.
            /// </value>
            public static string User => user;

            /// <summary>
            /// Gets the webmethod.
            /// </summary>
            /// <value>
            /// The webmethod.
            /// </value>
            public static string Webmethod => webmethod;

            /// <summary>
            /// Gets the identifier company.
            /// </summary>
            /// <value>
            /// The identifier company.
            /// </value>
            public static string IdCompany => idCompany;

            /// <summary>
            /// Gets the identifier network.
            /// </summary>
            /// <value>
            /// The identifier network.
            /// </value>
            public static string IdNetwork => idNetwork;
        }
    }
}
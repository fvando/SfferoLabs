﻿using AutoMapper;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.CommonLibrary.Exceptions.Models;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SAP.Extern.WCF.Mandate.Service.Reference.Tst;
using SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.ServiceModel;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Mandate
{
    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.IMandatesRepository" />
    public class MandatesRepository : IMandatesRepository
    {
        private readonly IMapper _mapper;
        private readonly IConfiguration _configuration;
        private readonly Z_FSCD_MANDATOS_POST_WS referenceInterfaceMandates;

        protected readonly TimeSpan OpenTimeout;
        protected readonly TimeSpan CloseTimeout;
        protected readonly TimeSpan SendTimeout;
        protected readonly TimeSpan ReceiveTimeout;
        protected readonly TimeSpan RestTimeout;

        protected readonly Stopwatch stopWatch;

        public MandatesRepository(IConfiguration configuration, IMapper mapperReference) : this(configuration, mapperReference, null)
        { }

        public MandatesRepository(IConfiguration configuration, IMapper mapperReference, Z_FSCD_MANDATOS_POST_WS referenceInterface)
        {
            _mapper = mapperReference;
            _configuration = configuration;

            if (referenceInterface != null)
            {
                this.referenceInterfaceMandates = referenceInterface;
                return;
            }

            #region Binding

            // read timeouts from config
            OpenTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:OpenTimeout");
            CloseTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:CloseTimeout");
            SendTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:SendTimeout");
            ReceiveTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:ReceiveTimeout");
            RestTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:RestTimeout");

            var binding = new BasicHttpBinding
            {
                MaxReceivedMessageSize = int.MaxValue,
                MaxBufferPoolSize = int.MaxValue,
                MaxBufferSize = int.MaxValue,
                AllowCookies = true,
                TransferMode = TransferMode.Buffered,
                SendTimeout = SendTimeout,
                ReceiveTimeout = ReceiveTimeout,
                CloseTimeout = CloseTimeout,
                OpenTimeout = OpenTimeout
            };

            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;

            // read enpoint address
            var address = new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTMandate").Value);

            // check if it is http or https
            if (string.Compare(address.Uri.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            }
            else
            {
                binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            }

            #endregion

            var client = new SAP.Extern.WCF.Mandate.Service.Reference.Tst.Z_FSCD_MANDATOS_POST_WSClient(binding, new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTMandate").Value));
            client.ClientCredentials.UserName.UserName = _configuration.GetSection("BasicAuth").GetSection("UserNameAuth").Value;
            client.ClientCredentials.UserName.Password = _configuration.GetSection("BasicAuth").GetSection("PasswordAuth").Value;

            referenceInterfaceMandates = client;

            stopWatch = new Stopwatch();
        }

        public IConfiguration Configuration => Configuration1;

        public IConfiguration Configuration1 => _configuration;

        public async Task<INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWsResponse1> GetMandatesAsync(INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWs requestMandates)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = _mapper.Map<SAP.Extern.WCF.Mandate.Service.Reference.Tst.ZFscdMandatosPostWs>(requestMandates);
                var request = new SAP.Extern.WCF.Mandate.Service.Reference.Tst.ZFscdMandatosPostWsRequest {
                    ZFscdMandatosPostWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("ZFscdMandatosPostWsAsync SAP Request: {request}", JsonConvert.SerializeObject(request));
                var _response = await referenceInterfaceMandates.ZFscdMandatosPostWsAsync(request);
                stopWatch.Stop();
                Log.Debug("ZFscdMandatosPostWsAsync SAP Response: {_response} in {Elapsed:000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                return _mapper.Map<INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWsResponse1>(_response);
            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }

        }
    }
}

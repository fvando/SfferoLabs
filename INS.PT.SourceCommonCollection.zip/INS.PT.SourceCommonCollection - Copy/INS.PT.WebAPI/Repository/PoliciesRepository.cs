﻿using AutoMapper;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SAP.Extern.WCF.Policy.Service.Reference.Tst;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.ServiceModel;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Policy
{
    /// <summary>
    /// PoliciesRepository : IPoliciesRepository
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.IPoliciesRepository" />
    public class PoliciesRepository : IPoliciesRepository
    {
        private readonly IMapper _mapper;
        private readonly IConfiguration _configuration;
        private readonly Z_FSCD_INSOBJECTS_POST_WS referenceInterfacePolicies;
        public IConfiguration Configuration => _configuration;

        protected readonly TimeSpan OpenTimeout;
        protected readonly TimeSpan CloseTimeout;
        protected readonly TimeSpan SendTimeout;
        protected readonly TimeSpan ReceiveTimeout;
        protected readonly TimeSpan RestTimeout;
        protected readonly Stopwatch stopWatch;

        /// <summary>
        /// Initializes a new instance of the <see cref="PoliciesRepository"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        /// <param name="mapperReference">The mapper reference.</param>
        public PoliciesRepository(IConfiguration configuration, IMapper mapperReference) : this(configuration, mapperReference, null)
        { }
        /// <summary>
        /// Initializes a new instance of the <see cref="PoliciesRepository"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        /// <param name="mapperReference">The mapper reference.</param>
        /// <param name="referenceInterface">The reference interface.</param>
        public PoliciesRepository(IConfiguration configuration, IMapper mapperReference, Z_FSCD_INSOBJECTS_POST_WS referenceInterface)
        {
            _mapper = mapperReference;
            _configuration = configuration;

            if (referenceInterface != null)
            {
                this.referenceInterfacePolicies = referenceInterface;
                return;
            }

            #region Binding

            // read timeouts from config
            OpenTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:OpenTimeout");
            CloseTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:CloseTimeout");
            SendTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:SendTimeout");
            ReceiveTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:ReceiveTimeout");
            RestTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:RestTimeout");

            var binding = new BasicHttpBinding
            {
                MaxReceivedMessageSize = int.MaxValue,
                MaxBufferPoolSize = int.MaxValue,
                MaxBufferSize = int.MaxValue,
                AllowCookies = true,
                TransferMode = TransferMode.Buffered,
                SendTimeout = SendTimeout,
                ReceiveTimeout = ReceiveTimeout,
                CloseTimeout = CloseTimeout,
                OpenTimeout = OpenTimeout
            };

            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;

            // read enpoint address
            var address = new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTPolicy").Value);

            // check if it is http or https
            if (string.Compare(address.Uri.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            }
            else
            {
                binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            }

            #endregion

            var client = new SAP.Extern.WCF.Policy.Service.Reference.Tst.Z_FSCD_INSOBJECTS_POST_WSClient(binding, new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTPolicy").Value));
            client.ClientCredentials.UserName.UserName = _configuration.GetSection("BasicAuth").GetSection("UserNameAuth").Value;
            client.ClientCredentials.UserName.Password = _configuration.GetSection("BasicAuth").GetSection("PasswordAuth").Value;

            referenceInterfacePolicies = client;

            stopWatch = new Stopwatch();
        }

        public async Task<INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWsResponse1> GetMediatorAsync( INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWs requestMediator)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = _mapper.Map<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZFscdMediadoresPostWs>(requestMediator);
                var request = new SAP.Extern.WCF.Policy.Service.Reference.Tst.ZFscdMediadoresPostWsRequest {
                    ZFscdMediadoresPostWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("ZFscdMediadoresPostWsAsync SAP Request: {request}", JsonConvert.SerializeObject(request));
                var _response = await referenceInterfacePolicies.ZFscdMediadoresPostWsAsync(request);
                stopWatch.Stop();
                Log.Debug("ZFscdMediadoresPostWsAsync SAP Response: {_response} in {Elapsed:000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                return _mapper.Map<INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWsResponse1>(_response);
                
            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }

        }

        public async Task<INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWsResponse1> GetPolicyAsync(INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWs requestPolicy)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = _mapper.Map<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZFscdApolicesPostWs>(requestPolicy);

                var request = new SAP.Extern.WCF.Policy.Service.Reference.Tst.ZFscdApolicesPostWsRequest
                {
                    ZFscdApolicesPostWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("ZFscdApolicesPostWsAsync SAP Request: {request}", JsonConvert.SerializeObject(request));
                var _response = await referenceInterfacePolicies.ZFscdApolicesPostWsAsync(request);
                stopWatch.Stop();
                Log.Debug("ZFscdApolicesPostWsAsync SAP Response: {_response} in {Elapsed:000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                return _mapper.Map<INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWsResponse1>(_response);
            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }

        }

        public async Task<INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWsResponse1> GetClaimsAsync(INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWs requestSinister)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = _mapper.Map<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZFscdSinistrosPostWs>(requestSinister);

                var request = new SAP.Extern.WCF.Policy.Service.Reference.Tst.ZFscdSinistrosPostWsRequest
                {
                    ZFscdSinistrosPostWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("ZFscdSinistrosPostWsAsync SAP Request: {request}", JsonConvert.SerializeObject(request));
                var _response = await referenceInterfacePolicies.ZFscdSinistrosPostWsAsync(request);
                stopWatch.Stop();
                Log.Debug("ZFscdSinistrosPostWsAsync SAP Response: {_response} in {Elapsed:000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                return _mapper.Map<INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWsResponse1>(_response);
            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }

    }
}

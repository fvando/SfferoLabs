﻿using AutoMapper;
using INS.PT.WebAPI.Interface;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using System;
using System.Data;
using System.Reflection;
using Microsoft.Extensions.Configuration;

namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    /// PolizaRepository
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.IPoliza" />
    public class PolizaRepository : IPoliza
    {
     
        const string _ObjectData = "result";
        const string _OracleExec = "NAV.fun_int_npoliza";
        const string _OracleParamInputOutPut = "p_insobject";
        

        private readonly IMapper _mapper;
        private readonly IDbconnectioncs _connection;
        private readonly IConfiguration _configuration;

        /// <summary>
        /// Initializes a new instance of the <see cref="PolizaRepository"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        /// <param name="connection">The connection.</param>
        public PolizaRepository(IConfiguration configuration, IDbconnectioncs connection)
        {
            _configuration = configuration;
            _connection = connection;
        }

        /// <summary>
        /// Submits the store procedure poliza.
        /// </summary>
        /// <param name="oraclePoliza">The oracle poliza.</param>
        /// <returns></returns>
        public string SubmitStoreProcedurePoliza(string oraclePoliza)
        {
           
            var result = oraclePoliza;

            using (OracleConnection con = new OracleConnection(_configuration.GetSection("ConnectionStrings").GetSection("DBConnection").Value))
            using (OracleCommand com = new OracleCommand())
            {
                com.Connection = con;
                con.Open();
                com.Parameters.Add(_ObjectData, OracleDbType.Varchar2, 200, null, ParameterDirection.ReturnValue);
                com.Parameters.Add(_OracleParamInputOutPut, OracleDbType.Varchar2, 200, oraclePoliza, ParameterDirection.InputOutput);
                com.CommandText = _OracleExec;
                com.CommandType = CommandType.StoredProcedure;
                com.ExecuteNonQuery();
                result = com.Parameters[0].Value?.ToString();
            }

            return result;
        }

        /// <summary>
        /// Updates the number poliza.
        /// </summary>
        /// <param name="receiptResult">The receipt result.</param>
        /// <returns></returns>
        public SAP.Extern.WCF.WebReciptListing.Service.Reference.Tst.ZFscdRecibosListarWsResponse1 UpdateNumPoliza(SAP.Extern.WCF.WebReciptListing.Service.Reference.Tst.ZFscdRecibosListarWsResponse1 receiptResult)
        {
            if (receiptResult != null)
            {
                foreach (var item in receiptResult.ZFscdRecibosListarWsResponse.ReceiptsNumbers)
                {
                    item.Contract = ValidateInputPoliza(item.Contract);
                }
            }

            return receiptResult;
        }

        public string ValidateInputPoliza(string poliza)
        {
            //Roles
            var temp = poliza;

           //Rule removed on 7/1 - It doesn't make sense to have rules for calling StoredProcedure, as she already knows the conversion rule
            if (poliza?.Length > 15)
            {
                    //GetDoc SubmitFunction Oracle without document Request
                    var PolizaResult = SubmitStoreProcedurePoliza(poliza);
                temp = PolizaResult;
            }

            return temp;
        }
    }
}

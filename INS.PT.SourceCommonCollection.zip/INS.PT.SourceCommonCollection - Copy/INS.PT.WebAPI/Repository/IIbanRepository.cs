﻿using AutoMapper;
using Canonical.ServiceReference;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.Domain;
using INS.PT.WebAPI.Model.Domain.CanonicalCoverage;
using INS.PT.WebAPI.Model.Partners.Iban;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PayrecService;
using SAP.Extern.WCF.IbanValidation.Service.Reference.Tst;
using SAP.Extern.WCF.WebReciptListing.Service.Reference.Tst;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.ServiceModel;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.IbanCheck
{

    public class IbanRepository : IIbanRepository
    {
        private readonly IMapper mapperReference;
        private readonly IConfiguration configuration;
        private readonly Z_FSCD_CHECK_IBAN_WS referenceInterfaceWebIbanValidate;
        protected readonly IHttpContextAccessor httpContext;

        protected readonly TimeSpan OpenTimeout;
        protected readonly TimeSpan CloseTimeout;
        protected readonly TimeSpan SendTimeout;
        protected readonly TimeSpan ReceiveTimeout;
        protected readonly TimeSpan RestTimeout;

        protected readonly Stopwatch stopwatch;

        public IbanRepository(IConfiguration _configuration, IMapper _mapperReference) : this(_configuration, _mapperReference, null)
        {

        }

        public IbanRepository(IConfiguration _configuration, IMapper _mapperReference, Z_FSCD_CHECK_IBAN_WS _referenceInterface)
        {
            mapperReference = _mapperReference;
            configuration = _configuration;
            if (_referenceInterface != null) {
                referenceInterfaceWebIbanValidate = _referenceInterface;
                return;
            }

            #region Binding

            // read timeouts from config
            OpenTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:OpenTimeout");
            CloseTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:CloseTimeout");
            SendTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:SendTimeout");
            ReceiveTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:ReceiveTimeout");
            RestTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:RestTimeout");

            var binding = new BasicHttpBinding
            {
                MaxReceivedMessageSize = int.MaxValue,
                MaxBufferPoolSize = int.MaxValue,
                MaxBufferSize = int.MaxValue,
                AllowCookies = true,
                TransferMode = TransferMode.Buffered,
                SendTimeout = SendTimeout,
                ReceiveTimeout = ReceiveTimeout,
                CloseTimeout = CloseTimeout,
                OpenTimeout = OpenTimeout
            };

            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
            
            // read enpoint address
            var address = new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTReceipt").Value);
            
            // check if it is http or https
            if (string.Compare(address.Uri.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            } else {
                binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            }

            #endregion

            var client = new Z_FSCD_CHECK_IBAN_WSClient(binding, new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTIban").Value));
            client.ClientCredentials.UserName.UserName = _configuration.GetSection("BasicAuthIban").GetSection("UserNameAuthIban").Value;
            client.ClientCredentials.UserName.Password = _configuration.GetSection("BasicAuthIban").GetSection("PasswordAuthIban").Value;

            referenceInterfaceWebIbanValidate = client;

            stopwatch = new Stopwatch();

        }

        public async Task<Model.Partners.Iban.ZFscdCheckIbanWsResponse1> CheckIbanWsAsync(Model.Partners.Iban.ZFscdCheckIbanWs requestIban)
        {
            try
            {
                var requestToSourceStructure = mapperReference.Map<SAP.Extern.WCF.IbanValidation.Service.Reference.Tst.ZFscdCheckIbanWs>(requestIban);
                var request = new SAP.Extern.WCF.IbanValidation.Service.Reference.Tst.ZFscdCheckIbanWsRequest {
                    ZFscdCheckIbanWs = requestToSourceStructure
                };

                stopwatch.Restart();
                Log.Debug("ZFscdCheckIbanWsAsync SAP Request: {requestReceipt}", JsonConvert.SerializeObject(requestIban));
                var SapResponse = await referenceInterfaceWebIbanValidate.ZFscdCheckIbanWsAsync(request);
                stopwatch.Stop();
                Log.Debug("ZFscdCheckIbanWsAsync SAP Response: {SapResponse} in {Elapsed:000} ms", JsonConvert.SerializeObject(SapResponse), stopwatch.ElapsedMilliseconds);

                //convert to OUT structure
                var ServiceResponse = mapperReference.Map<Model.Partners.Iban.ZFscdCheckIbanWsResponse1>(SapResponse);
                return ServiceResponse;
            }

            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.InnerException?.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.InnerException?.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }

    }
}

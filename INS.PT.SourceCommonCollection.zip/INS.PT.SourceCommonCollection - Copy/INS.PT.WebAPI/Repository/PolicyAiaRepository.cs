﻿using AutoMapper;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SAP.Extern.WCF.Police.AIA.Service.Reference.Tst;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.ServiceModel;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Policy.AIA
{
    /// <summary>
    /// PoliciesRepository : IPoliciesRepository
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.IPoliciesRepository" />
    public class PolicyAiaRepository : IPolicyAiaRepository
    {
        private readonly IMapper _mapper;
        private readonly IConfiguration _configuration;
        private readonly ZFSCD_AIA_GET_POLICY referenceInterfacePolicyAia;
        public IConfiguration Configuration => _configuration;

        protected readonly TimeSpan OpenTimeout;
        protected readonly TimeSpan CloseTimeout;
        protected readonly TimeSpan SendTimeout;
        protected readonly TimeSpan ReceiveTimeout;
        protected readonly TimeSpan RestTimeout;
        protected readonly Stopwatch stopWatch;

        /// <summary>
        /// Initializes a new instance of the <see cref="PoliciesRepository"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        /// <param name="mapperReference">The mapper reference.</param>
        public PolicyAiaRepository(IConfiguration configuration, IMapper mapperReference) : this(configuration, mapperReference, null)
        { }
        /// <summary>
        /// Initializes a new instance of the <see cref="PoliciesRepository"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        /// <param name="mapperReference">The mapper reference.</param>
        /// <param name="referenceInterface">The reference interface.</param>
        public PolicyAiaRepository(IConfiguration configuration, IMapper mapperReference, ZFSCD_AIA_GET_POLICY referenceInterface)
        {
            _mapper = mapperReference;
            _configuration = configuration;

            if (referenceInterface != null)
            {
                this.referenceInterfacePolicyAia = referenceInterface;
                return;
            }

            #region Binding

            // read timeouts from config
            OpenTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:OpenTimeout");
            CloseTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:CloseTimeout");
            SendTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:SendTimeout");
            ReceiveTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:ReceiveTimeout");
            RestTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:RestTimeout");

            var binding = new BasicHttpBinding
            {
                MaxReceivedMessageSize = int.MaxValue,
                MaxBufferPoolSize = int.MaxValue,
                MaxBufferSize = int.MaxValue,
                AllowCookies = true,
                TransferMode = TransferMode.Buffered,
                SendTimeout = SendTimeout,
                ReceiveTimeout = ReceiveTimeout,
                CloseTimeout = CloseTimeout,
                OpenTimeout = OpenTimeout
            };

            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;

            // read enpoint address
            var address = new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTPolicyAia").Value);

            // check if it is http or https
            if (string.Compare(address.Uri.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            }
            else
            {
                binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            }

            #endregion

            var client = new SAP.Extern.WCF.Police.AIA.Service.Reference.Tst.ZFSCD_AIA_GET_POLICYClient(binding, 
                new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTPolicyAia").Value));

            client.ClientCredentials.UserName.UserName = _configuration.GetSection("BasicAuthAia").GetSection("UserNameAuthAia").Value;
            client.ClientCredentials.UserName.Password = _configuration.GetSection("BasicAuthAia").GetSection("PasswordAuthAia").Value;

            referenceInterfacePolicyAia = client;

            stopWatch = new Stopwatch();
        }

        public async Task<SAP.Extern.WCF.Police.AIA.Service.Reference.Tst.ZFscdAiaGetApolicesWsResponse1> GetPolicyAiaAsync(INS.PT.WebAPI.Model.Partners.PolicyAIA.ZfscdAiaGetPolicysWs requestPolicy)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = _mapper.Map<SAP.Extern.WCF.Police.AIA.Service.Reference.Tst.ZFscdAiaGetApolicesWs>(requestPolicy);
                var request = new SAP.Extern.WCF.Police.AIA.Service.Reference.Tst.ZFscdAiaGetApolicesWsRequest{
                    ZFscdAiaGetApolicesWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("Z_FSCD_AIA_GET_POLICYSAsync SAP Request: {request}", JsonConvert.SerializeObject(request));
                var _response = await referenceInterfacePolicyAia.ZFscdAiaGetApolicesWsAsync(request);
                stopWatch.Stop();
                Log.Debug("Z_FSCD_AIA_GET_POLICYSAsync SAP Response: {_response} in {Elapsed:000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                return _response;
                
            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }

        }

    }
}

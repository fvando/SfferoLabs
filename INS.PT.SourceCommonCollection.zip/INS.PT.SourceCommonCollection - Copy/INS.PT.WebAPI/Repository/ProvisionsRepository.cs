﻿using AutoMapper;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.ServiceModel;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    /// ProvisionsRepository : IProvisionsRepository
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.IProvisionsRepository" />
    public class ProvisionsRepository : IProvisionsRepository
    {
        private readonly IMapper mapper;
        private readonly IConfiguration configuration;
        private readonly IStatesRepository statesRepository;
        private readonly Z_FSCD_PC_WS referenceInterfaceProvisionAccount;
        private readonly IWebReceiptListingRepository referenceWebReceiptListRepository;

        protected readonly TimeSpan OpenTimeout;
        protected readonly TimeSpan CloseTimeout;
        protected readonly TimeSpan SendTimeout;
        protected readonly TimeSpan ReceiveTimeout;
        protected readonly TimeSpan RestTimeout;
        protected readonly Stopwatch stopWatch;


        public ProvisionsRepository(IConfiguration _configuration, IMapper _mapperReference, IStatesRepository _statesRepository, IWebReceiptListingRepository _referenceWebReceiptListRepository) : this(_configuration, _mapperReference, _statesRepository, _referenceWebReceiptListRepository, null)
        {
           
        }


        /// <summary>
        /// Initializes a new instance of the <see cref="ProvisionsRepository"/> class.
        /// </summary>
        /// <param name="_configuration">The configuration.</param>
        /// <param name="_mapperReference">The mapper reference.</param>
        /// <param name="_statesRepository">The states repository.</param>
        /// <param name="_referenceInterface">The reference interface.</param>
        public ProvisionsRepository(IConfiguration _configuration, IMapper _mapperReference, IStatesRepository _statesRepository, IWebReceiptListingRepository _referenceWebReceiptListRepository, Z_FSCD_PC_WS _referenceInterface)
        {
            statesRepository = _statesRepository;
            referenceWebReceiptListRepository = _referenceWebReceiptListRepository;
            mapper = _mapperReference;
            configuration = _configuration;

            if (_referenceInterface != null)
            {
                referenceInterfaceProvisionAccount = _referenceInterface;
                return;
            }

            #region Binding

            // read timeouts from config
            OpenTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:OpenTimeout");
            CloseTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:CloseTimeout");
            SendTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:SendTimeout");
            ReceiveTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:ReceiveTimeout");
            RestTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:RestTimeout");

            var binding = new BasicHttpBinding
            {
                MaxReceivedMessageSize = int.MaxValue,
                MaxBufferPoolSize = int.MaxValue,
                MaxBufferSize = int.MaxValue,
                AllowCookies = true,
                TransferMode = TransferMode.Buffered,
                SendTimeout = SendTimeout,
                ReceiveTimeout = ReceiveTimeout,
                CloseTimeout = CloseTimeout,
                OpenTimeout = OpenTimeout
            };

            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;

            // read enpoint address
            var address = new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTProvision").Value);

            // check if it is http or https
            if (string.Compare(address.Uri.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            }
            else
            {
                binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            }

            #endregion


            var client = new SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.Z_FSCD_PC_WSClient(binding, new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTProvision").Value));
            client.ClientCredentials.UserName.UserName = _configuration.GetSection("BasicAuth").GetSection("UserNameAuth").Value;
            client.ClientCredentials.UserName.Password = _configuration.GetSection("BasicAuth").GetSection("PasswordAuth").Value;

            referenceInterfaceProvisionAccount = client;

            stopWatch = new Stopwatch();

        }

        public async Task<Model.Partners.ProvisionWebAccount.ZFscdPcRecibosAgregadoWsResponse1> GetAggregatesReceiptsAsync(Model.Partners.ProvisionWebAccount.ZFscdPcRecibosAgregadoWs requestAggregatesReceipts)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = mapper.Map<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcRecibosAgregadoWs>(requestAggregatesReceipts);
                var request = new SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcRecibosAgregadoWsRequest {
                    ZFscdPcRecibosAgregadoWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Information("ZFscdPcRecibosAgregadoWsAsync SAP request {request}", JsonConvert.SerializeObject(request));
                var _response = await referenceInterfaceProvisionAccount.ZFscdPcRecibosAgregadoWsAsync(request);
                stopWatch.Stop();
                Log.Debug("ZFscdPcRecibosAgregadoWsAsync SAP response {_response} in {Elapsed: 000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                return mapper.Map<Model.Partners.ProvisionWebAccount.ZFscdPcRecibosAgregadoWsResponse1>(_response);
            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                       new ProcessErrorException.InnerError
                                       {
                                           ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                           ErrorMessage = e.Message
                                       }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                       new ProcessErrorException.InnerError
                                       {
                                           ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                           ErrorMessage = e.Message
                                       }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }

        public async Task<ChargedReceiptLineDetailResponse> GetChargedAsync(Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWs requestCharge)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = mapper.Map<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcCobrarWs>(requestCharge);
                var request = new SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcCobrarWsRequest {
                    ZFscdPcCobrarWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Information("ZFscdPcCobrarWsAsync SAP request {request}", JsonConvert.SerializeObject(request));
                var _response = await referenceInterfaceProvisionAccount.ZFscdPcCobrarWsAsync(request);
                stopWatch.Stop();
                Log.Debug("ZFscdPcCobrarWsAsync SAP response: {_response} in {Elapsed: 000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                 var resultResponse = mapper.Map<Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWsResponse1>(_response);

                stopWatch.Restart();
                Log.Debug("ChargedList Request: {requestCharge}", JsonConvert.SerializeObject(requestCharge));
                var _TransInput = new TransformationData(statesRepository);
                var returnList = _TransInput.ChargedList(requestCharge, resultResponse);
                stopWatch.Stop();
                Log.Debug("ChargedList Response: {returnList} in {Elapsed: 000} ms", JsonConvert.SerializeObject(returnList), stopWatch.ElapsedMilliseconds);

                return returnList;

            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }

        /// <summary>
        /// Gets the charged asynchronous.
        /// </summary>
        /// <param name="requestValue">The request value.</param>
        /// <returns></returns>
        public async Task<ChargedReceiptLineDetailResponse> GetChargedAsync(string requestValue)
        {
            //Call WebReceiptList
            Model.Partners.WebReceiptListing.ZFscdRecibosListarWs requestReceipt = 
                new Model.Partners.WebReceiptListing.ZFscdRecibosListarWs() {
                    ReferenceDocumentNumber = requestValue
            };

            stopWatch.Restart();
            Log.Debug("GestListAsync SAP Request {requestReceipt}", JsonConvert.SerializeObject(requestReceipt));
            var _response = await referenceWebReceiptListRepository.GestListAsync(requestReceipt);
            stopWatch.Stop();
            Log.Debug("GestListAsync SAP Response {_response}  in {Elapsed: 000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);
 

            Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWs requestCharge = new Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWs();


            if (_response?.Errors.Count == 0)
            {
                foreach (var item in _response.ReceiptsNumbers)
                {
                    requestCharge.BrokerContract = item.InsuranceAgent;
                    requestCharge.PcReceipts = new List<Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>()
                    {
                        new Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha(){
                            
                            InsuranceBroker = item.InsuranceAgent,
                            CompanyCode = item.CompanyCode,
                            DocumentType = item.DocumentType,
                            ReferenceDocumentNumber = item.ReferenceDocumentNumber,
                            SapDocumentNumber = item.SapDocumentNumber,
                            DocumentNumber = "",
                            InsurancePartner = item.InsurancePartner,
                            InsuranceObject = item.Contract,
                            Amount = item.TotalValue,
                            Currency = item.Currency
                        }
                    }.ToArray();
                }


                Log.Debug($"GetChargedAsync SAP Request: {requestCharge}");
                //With result WebReceiptList, call Charged
                var result = await GetChargedAsync(requestCharge);
                Log.Debug($"GetChargedAsync SAP Response: {requestCharge}");

                return result;
            }
            else {

                //Thare are any problem create a objet Charged with return
                var _TransInput = new TransformationData(statesRepository);

                Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWs inPutList = new Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWs() {
                    BrokerContract = requestValue,
                    PcReceipts = new List<Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>() {
                            new Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha(){
                                ReferenceDocumentNumber = requestValue,
                          }
                    }.ToArray()
                };

                Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWsResponse1 outPutList = new Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWsResponse1() {
                    ZFscdPcCobrarWsResponse = new Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWsResponse() {
                        Errors = new List<Model.Partners.ProvisionWebAccount.ZfscdCodigosErroRecibos>() { }.ToArray()
                    }
                };

                var tempErrorList = new List<Model.Partners.ProvisionWebAccount.ZfscdCodigosErroRecibos>();
                
                foreach (var item in _response?.Errors)
                {
                    tempErrorList.Add(new Model.Partners.ProvisionWebAccount.ZfscdCodigosErroRecibos()
                    {
                        Errors = new List<Model.Partners.ProvisionWebAccount.ZfscdCodigosErroProvisionRecibosLinha>() {
                            new Model.Partners.ProvisionWebAccount.ZfscdCodigosErroProvisionRecibosLinha(){
                                ErrorCode = item.ErrorCode,
                                ErrorCodeTxt = item.ErrorCodeTxt
                            }
                        }.ToArray(),
                        Receipt = requestValue
                    });
                }

                outPutList.ZFscdPcCobrarWsResponse.Errors = tempErrorList.ToArray();

                var returnList = _TransInput.ChargedList(inPutList, outPutList);

                return returnList;
            }
        }

        public async Task<Model.Partners.ProvisionWebAccount.ZFscdPcContaEfetivaWsResponse1> GetContaEfetivaAsync(Model.Partners.ProvisionWebAccount.ZFscdPcContaEfetivaWs requestValidade)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = mapper.Map<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcContaEfetivaWs>(requestValidade);
                var request = new SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcContaEfetivaWsRequest {
                    ZFscdPcContaEfetivaWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("ZFscdPcContaEfetivaWsAsync SAP Request {request}", JsonConvert.SerializeObject(request));
                var _response = await referenceInterfaceProvisionAccount.ZFscdPcContaEfetivaWsAsync(request);
                stopWatch.Stop();
                Log.Debug("ZFscdPcContaEfetivaWsAsync SAP Response {_response} in {Elapsed: 000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                return mapper.Map<Model.Partners.ProvisionWebAccount.ZFscdPcContaEfetivaWsResponse1>(_response);
            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }
    
        public async Task<Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWsResponse1> GetKpiAsync(Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWs requestValidade)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = mapper.Map<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcIndicadoresWs>(requestValidade);
                var request = new SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcIndicadoresWsRequest {
                    ZFscdPcIndicadoresWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("ZFscdPcIndicadoresWsAsync SAP Request: {request}", JsonConvert.SerializeObject(request));
                var _response = await referenceInterfaceProvisionAccount.ZFscdPcIndicadoresWsAsync(request);
                stopWatch.Stop();
                Log.Debug("ZFscdPcIndicadoresWsAsync SPA Response: {_response} in {Elapsed: 000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                return mapper.Map<Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWsResponse1>(_response);
            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }

        public async Task<LiquidatePaymentsLineDetailResponse> GetLiquidateAsync(Model.Partners.ProvisionWebAccount.ZFscdPcLiquidarWs requestLiquidate)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = mapper.Map<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcLiquidarWs>(requestLiquidate);
                var request = new SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcLiquidarWsRequest {
                    ZFscdPcLiquidarWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("ZFscdPcLiquidarWsAsync SAP Request {request}", JsonConvert.SerializeObject(request));
                var _response = await referenceInterfaceProvisionAccount.ZFscdPcLiquidarWsAsync(request);
                stopWatch.Stop();
                Log.Debug("ZFscdPcLiquidarWsAsync SAP Response: {_response} in {Elapsed: 000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
               var resultResponse = mapper.Map<Model.Partners.ProvisionWebAccount.ZFscdPcLiquidarWsResponse1>(_response);

                var _TransInput = new TransformationData(statesRepository);

                stopWatch.Restart();
                Log.Debug("LiquidateList Request: {request}", JsonConvert.SerializeObject(resultResponse));
                var returnList = _TransInput.LiquidateList(requestLiquidate, resultResponse);
                stopWatch.Stop();
                Log.Debug("LiquidateList Response: {returnList} in {Elapsed: 000} ms", JsonConvert.SerializeObject(returnList), stopWatch.ElapsedMilliseconds);

                return returnList;

            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }

        public async Task<Model.Partners.ProvisionWebAccount.ZFscdPcListarWsResponse1> GetListAsync(Model.Partners.ProvisionWebAccount.ZFscdPcListarWs requestList)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = mapper.Map<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcListarWs>(requestList);

                var request = new SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcListarWsRequest
                {
                    ZFscdPcListarWs = requestToSourceStructure
                };

                Log.Debug("ZFscdPcListarWsAsync SAP Request: {request}", JsonConvert.SerializeObject(request));
                var _response = await referenceInterfaceProvisionAccount.ZFscdPcListarWsAsync(request);
                Log.Debug("ZFscdPcListarWsAsync SAP Response: {_response} in {Elapsed: 000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                var  result = mapper.Map<Model.Partners.ProvisionWebAccount.ZFscdPcListarWsResponse1>(_response);

                TransformationData _TransInput = new TransformationData(statesRepository);

                //Branch Description
                stopWatch.Restart();
                Log.Debug("PutDomainAsync Request: {result}", JsonConvert.SerializeObject(result));
                var ResultWithDomain = await _TransInput.PutDomainAsync(result);
                stopWatch.Stop();
                Log.Debug("PutDomainAsync Response: {ResultWithDomain} in {Elapsed: 000} ms", JsonConvert.SerializeObject(ResultWithDomain), stopWatch.ElapsedMilliseconds);

                return ResultWithDomain;

            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }

        public async Task<Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWsResponse1> GetQueryAsync(Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWs requestQuery)
        {
            try
                {
                //convert to IN structure
                var requestToSourceStructure = mapper.Map<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcConsultarWs>(requestQuery);
                var request = new SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcConsultarWsRequest  {
                    ZFscdPcConsultarWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("ZFscdPcConsultarWsAsync SAP Request: {requestQuery}", JsonConvert.SerializeObject(requestQuery));
                var _response = await referenceInterfaceProvisionAccount.ZFscdPcConsultarWsAsync(request);
                stopWatch.Stop();
                Log.Debug("ZFscdPcConsultarWsAsync SAP Response: {_response} in {Elapsed:000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                var result = mapper.Map<Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWsResponse1>(_response);

                TransformationData _TransInput = new TransformationData(statesRepository);

                stopWatch.Restart();
                Log.Debug("PutDomainAsync Request: {result}", JsonConvert.SerializeObject(result));
                await _TransInput.PutDomainAsync(result);
                stopWatch.Stop();
                Log.Debug("PutDomainAsync Response: {result} in {Elapsed:000} ms", JsonConvert.SerializeObject(result), stopWatch.ElapsedMilliseconds);


                return result; 
            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }
        public async Task<ValidateReceiptLineDetailResponse> GetValidateAsync(Model.Partners.ProvisionWebAccount.ZFscdPcValidarWs requestValidade)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = mapper.Map<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcValidarWs>(requestValidade);
                var request = new SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcValidarWsRequest {
                    ZFscdPcValidarWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("ZFscdPcValidarWsAsync SAP Request: {request}", JsonConvert.SerializeObject(request));
                var _response = await referenceInterfaceProvisionAccount.ZFscdPcValidarWsAsync(request);
                stopWatch.Stop();
                Log.Debug("ZFscdPcValidarWsAsync SAP Response: {_response} in {Elapsed:000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);


                //convert to OUT structure
                 var resultResponse = mapper.Map<Model.Partners.ProvisionWebAccount.ZFscdPcValidarWsResponse1>(_response);

                //Processa lista de Recibos
                //ZFscdPcValidarWs, ZFscdPcValidarWsResponse1
                var _TransInput = new TransformationData(statesRepository);

                stopWatch.Restart();
                Log.Debug("ValidateList Request: {request}", JsonConvert.SerializeObject(resultResponse));
                var returnList = _TransInput.ValidateList(requestValidade, resultResponse);
                stopWatch.Stop();
                Log.Debug("ValidateList Response: {returnList} in {Elapsed:000} ms", JsonConvert.SerializeObject(returnList), stopWatch.ElapsedMilliseconds);

                return returnList;

            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }

        public async Task<Model.Partners.ProvisionWebAccount.ZFscdPcEliminarWsResponse1> PostEliminateReceiptsAsync(Model.Partners.ProvisionWebAccount.ZFscdPcEliminarWs requestEliminateReceipts)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = mapper.Map<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcEliminarWs>(requestEliminateReceipts);
                var request = new SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcEliminarWsRequest {
                    ZFscdPcEliminarWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("ZFscdPcEliminarWsAsync SAP Request: {request}", JsonConvert.SerializeObject(request));
                var _response = await referenceInterfaceProvisionAccount.ZFscdPcEliminarWsAsync(request);
                stopWatch.Stop();
                Log.Debug("ZFscdPcEliminarWsAsync SAP Response: {_response} in {Elapsed:000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                var resultResponse = mapper.Map<Model.Partners.ProvisionWebAccount.ZFscdPcEliminarWsResponse1>(_response);

                return resultResponse;

            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }
    }
}

﻿using INS.PT.WebAPI.Constants;
using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Reflection;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Repository
{
    public class HttpClientRepository: IHttpClientRepository
    {
        private readonly IHttpClientFactory httpClientFactory;
        private readonly IConfiguration Configuration;

        public JsonSerializerSettings JsonSettings
        {
            get
            {
                JsonSerializerSettings settings = new JsonSerializerSettings();
                settings.NullValueHandling = NullValueHandling.Ignore;
                settings.Formatting = Formatting.Indented;
                settings.DefaultValueHandling = Newtonsoft.Json.DefaultValueHandling.Ignore;
                return settings;
            }
        }

        public JsonMediaTypeFormatter JsonFormatter
        {
            get
            {
                var jsonFormatter = new JsonMediaTypeFormatter();
                jsonFormatter.SerializerSettings.DefaultValueHandling = Newtonsoft.Json.DefaultValueHandling.Ignore;
                jsonFormatter.SerializerSettings.NullValueHandling = Newtonsoft.Json.NullValueHandling.Ignore;
                return jsonFormatter;
            }
        }

        public HttpClientRepository(IHttpClientFactory _httpClientFactory, IConfiguration _configuration)
        {
            Configuration = _configuration;
            httpClientFactory = _httpClientFactory;
        }


        public async Task<HttpResponseMessage> ProcessRequestAsync(HttpRequestElement request)
        {
            HttpResponseMessage responseMessage = null;

            Log.Debug($" Request Element: {JsonConvert.SerializeObject(request, JsonSettings)}");
            HttpClient client = httpClientFactory.CreateClient();
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.ContentType, request.ContentType);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.WebService, request.ApiService);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Solution, request.Solution);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.User, request.User);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdCompany, Configuration.GetSection("BrokerSettingsReferenceData").GetSection("IdCompany").Value);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdNetwork, Configuration.GetSection("BrokerSettingsReferenceData").GetSection("IdNetwork").Value);

            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Webmethod, request.ApiMethod);

            Log.Debug($" Headers: {client.DefaultRequestHeaders}");

            switch (request.Method)
            {
                case CommonEnums.HttpRequestVerb.GET:
                    responseMessage = await client.GetAsync($"{request.EndPoint}{request.RouteValue}{request.QueryString}");
                    Log.Debug($" GET Endpoint Configuration: {request.EndPoint}{request.RouteValue}{request.QueryString}");
                    break;
                case CommonEnums.HttpRequestVerb.POST:
                    responseMessage = await client.PostAsync($"{request.EndPoint}", request.RequestObject, JsonFormatter);
                    Log.Debug($" POST Endpoint Configuration: {request.EndPoint} Body: {JsonConvert.SerializeObject(request.RequestObject, JsonSettings)}");
                    break;
                case CommonEnums.HttpRequestVerb.PUT:
                    responseMessage = await client.PutAsync($"{request.EndPoint}{request.QueryString}", request.RequestObject, JsonFormatter);
                    Log.Debug($" PUT Endpoint Configuration: {request.EndPoint}{request.RouteValue}{request.QueryString} Body: {JsonConvert.SerializeObject(request.RequestObject, JsonSettings)}");
                    break;
                case CommonEnums.HttpRequestVerb.UPDATE:
                    break;
                case CommonEnums.HttpRequestVerb.DELETE:
                    responseMessage = await client.DeleteAsync($"{request.EndPoint}{request.RouteValue}{request.QueryString}");
                    Log.Debug($" DELETE Endpoint Configuration: {request.EndPoint}{request.RouteValue}{request.QueryString}");
                    break;
            }

            return responseMessage;
        }

      
        public async Task<HttpResponseMessage> ProcessRequestAsync(HttpRequest request, string service, string method, object requestObject = null)
        {
            return await ProcessRequestAsync(request, service, method, null, requestObject);
        }

        public async Task<HttpResponseMessage> ProcessRequestAsync(HttpRequest request, string service, string method, string routeValue, object requestObject = null)
        {
            HttpResponseMessage responseMessage = null;

            HttpClient client = httpClientFactory.CreateClient();

            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.ContentType, Configuration.GetSection("BrokerSettingsReferenceData").GetSection("ContentTypeJson").Value);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.WebService, service);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Solution, Configuration.GetSection("BrokerSettingsReferenceData").GetSection("Solution").Value);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.User, Configuration.GetSection("BrokerSettingsReferenceData").GetSection("User").Value);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdCompany, Configuration.GetSection("BrokerSettingsReferenceData").GetSection("IdCompany").Value);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdNetwork, Configuration.GetSection("BrokerSettingsReferenceData").GetSection("IdNetwork").Value);

            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Webmethod, method);

            Log.Debug($" Headers: {client.DefaultRequestHeaders}");

            switch (request.Method)
            {
                case "GET":
                    responseMessage = await client.GetAsync($"{Configuration.GetSection("BrokerSettingsReferenceData").GetSection("Endpoint").Value}{routeValue}{request.QueryString}");
                    Log.Debug($" GET Endpoint Configuration: {Configuration.GetSection("BrokerSettingsReferenceData").GetSection("Endpoint").Value}{routeValue}{request.QueryString}");
                    break;
                case "POST":
                    responseMessage = await client.PostAsync($"{Configuration.GetSection("BrokerSettingsReferenceData").GetSection("Endpoint").Value}", requestObject, JsonFormatter);
                    Log.Debug($" POST Endpoint Configuration: {Configuration.GetSection("BrokerSettingsReferenceData").GetSection("Endpoint").Value} Body: {JsonConvert.SerializeObject(requestObject, JsonSettings)}");
                    break;
                case "PUT":
                    responseMessage = await client.PutAsync($"{Configuration.GetSection("BrokerSettingsReferenceData").GetSection("Endpoint").Value}{routeValue}{request.QueryString}", requestObject, JsonFormatter);
                    Log.Debug($" PUT Endpoint Configuration: {Configuration.GetSection("BrokerSettingsReferenceData").GetSection("Endpoint").Value}{routeValue}{request.QueryString} Body: {JsonConvert.SerializeObject(requestObject, JsonSettings)}");
                    break;
                case "UPDATE":
                    break;
                case "DELETE":
                    responseMessage = await client.DeleteAsync($"{Configuration.GetSection("BrokerSettingsReferenceData").GetSection("Endpoint").Value}{routeValue}{request.QueryString}");
                    Log.Debug($" DELETE Endpoint Configuration: {Configuration.GetSection("BrokerSettingsReferenceData").GetSection("Endpoint").Value}{routeValue}{request.QueryString}");
                    break;
            }

            return responseMessage;
        }

        public async Task<HttpResponseMessage> ProcessRequestAsync(HttpRequest request, string service, string method, string routeValue, string directURL, string autenticationObj, object requestObject = null)
        {
            HttpResponseMessage responseMessage = null;

            HttpClient client = httpClientFactory.CreateClient();
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.ContentType, Configuration.GetSection("BrokerSettingsReferenceData").GetSection("ContentTypeJson").Value);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.WebService, service);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Solution, Configuration.GetSection("BrokerSettingsReferenceData").GetSection("Solution").Value);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.User, Configuration.GetSection("BrokerSettingsReferenceData").GetSection("User").Value);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdCompany, Configuration.GetSection("BrokerSettingsReferenceData").GetSection("IdCompany").Value);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdNetwork, Configuration.GetSection("BrokerSettingsReferenceData").GetSection("IdNetwork").Value);

            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Webmethod, method);

            Log.Error($" Headers: {client.DefaultRequestHeaders}");

            string endpoint = directURL ?? Configuration.GetSection("BrokerSettingsReferenceData").GetSection("Endpoint").Value;
            if (!string.IsNullOrEmpty(autenticationObj))
            {
                var byteArray = System.Text.Encoding.ASCII.GetBytes(autenticationObj);
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", System.Convert.ToBase64String(byteArray));
            }

            switch (request.Method)
            {
                case "GET":
                    responseMessage = await client.GetAsync($"{endpoint}{routeValue}{request.QueryString}");
                    Log.Debug($" Get Endpoint Configuration: {endpoint}{routeValue}{request.QueryString}");
                    break;
                case "POST":
                    responseMessage = await client.PostAsync($"{endpoint}", requestObject, JsonFormatter);
                    Log.Debug($" POST Endpoint Configuration: {endpoint} Body: {JsonConvert.SerializeObject(requestObject, JsonSettings)}");
                    break;
                case "PUT":
                    responseMessage = await client.PutAsync($"{endpoint}{routeValue}{request.QueryString}", requestObject, JsonFormatter);
                    Log.Debug($" POST Endpoint Configuration: {endpoint}{routeValue}{request.QueryString} Body: {JsonConvert.SerializeObject(requestObject, JsonSettings)}");
                    break;
                case "UPDATE":
                    break;
                case "DELETE":
                    responseMessage = await client.DeleteAsync($"{endpoint}{routeValue}{request.QueryString}");
                    Log.Debug($" POST Endpoint Configuration: {endpoint}{routeValue}{request.QueryString}");
                    break;
            }

            return responseMessage;
        }

        public async Task<HttpResponseMessage> ProcessRequestAsync(HttpRequest request, string service, string method, string routeValue, string directURL, string autenticationObj, object requestObject = null, string ContentTypeJson = "", string Solution = "", string User = "", string Endpoint = "")
        {
            HttpResponseMessage responseMessage = null;

            HttpClient client = httpClientFactory.CreateClient();
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.ContentType, ContentTypeJson);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.WebService, service);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Solution, Solution);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.User, User);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdCompany, Configuration.GetSection("BrokerSettingsReferenceData").GetSection("IdCompany").Value);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdNetwork, Configuration.GetSection("BrokerSettingsReferenceData").GetSection("IdNetwork").Value);

            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Webmethod, method);

            Log.Error($" Headers: {client.DefaultRequestHeaders}");

            string endpoint = directURL ?? Endpoint;
            if (!string.IsNullOrEmpty(autenticationObj))
            {
                var byteArray = System.Text.Encoding.ASCII.GetBytes(autenticationObj);
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", System.Convert.ToBase64String(byteArray));
            }

            switch (request.Method)
            {
                case "GET":
                    responseMessage = await client.GetAsync($"{endpoint}{routeValue}{request.QueryString}");
                    Log.Debug($" Get Endpoint Configuration: {endpoint}{routeValue}{request.QueryString}");
                    break;
                case "POST":
                    responseMessage = await client.PostAsync($"{endpoint}", requestObject, JsonFormatter);
                    Log.Debug($" POST Endpoint Configuration: {endpoint} Body: {JsonConvert.SerializeObject(requestObject, JsonSettings)}");
                    break;
                case "PUT":
                    responseMessage = await client.PutAsync($"{endpoint}{routeValue}{request.QueryString}", requestObject, JsonFormatter);
                    Log.Debug($" POST Endpoint Configuration: {endpoint}{routeValue}{request.QueryString} Body: {JsonConvert.SerializeObject(requestObject, JsonSettings)}");
                    break;
                case "UPDATE":
                    break;
                case "DELETE":
                    responseMessage = await client.DeleteAsync($"{endpoint}{routeValue}{request.QueryString}");
                    Log.Debug($" POST Endpoint Configuration: {endpoint}{routeValue}{request.QueryString}");
                    break;
            }

            return responseMessage;
        }
    }
}

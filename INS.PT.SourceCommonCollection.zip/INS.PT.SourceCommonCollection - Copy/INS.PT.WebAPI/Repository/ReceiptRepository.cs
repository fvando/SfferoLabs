﻿using AutoMapper;
using Dapper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Serialization;
namespace INS.PT.WebAPI.WebReceiptList
{
    public class ReceiptRepository : IReceiptRepository
    {
        const string _oraclePackageWebservices = "nav.pkg_canonical_system";
        const string _oracleStoredProcedure = "pro_execute";
        const int _sizeBuffer = 1000;
        const string _ObjectData = "result";

        private readonly IMapper _mapper;
        private readonly IDbconnectioncs connection;
        private readonly IConfiguration configuration;

        public ReceiptRepository(IConfiguration _configuration, IMapper mapperReference) : this(_configuration, null, mapperReference)
        {

        }
        public ReceiptRepository(IConfiguration _configuration, IDbconnectioncs connection, IMapper mapperReference)
        {
            _mapper = mapperReference;
            this.connection = connection;
            configuration = _configuration;
        }

        /// <summary>
        /// Validates the parameters.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public OracleDynamicParameters ValidateParams(ReceiptCoverageInput parameters)
        {
            var jsonXML = ReceiptInputToXml(parameters);

            Log.Debug($"ValidateParams Request: {JsonConvert.SerializeObject(parameters)}");
            try
            {
                OracleDynamicParameters DyParam = new OracleDynamicParameters();
                
                //OutPut parameter
                DyParam.Add("p_response", OracleDbType.XmlType, direction: ParameterDirection.Output, value: null, size: _sizeBuffer);
                DyParam.Add("p_error", OracleDbType.XmlType, direction: ParameterDirection.Output, value: null, size: _sizeBuffer);

                ////InPut parameter
                DyParam.Add("p_company", OracleDbType.Varchar2, direction: ParameterDirection.Input, value: null);
                DyParam.Add("p_users", OracleDbType.Varchar2, direction: ParameterDirection.Input, value: null);
                DyParam.Add("p_service", OracleDbType.Varchar2, direction: ParameterDirection.Input, value: "GET_POLICY_RECEIPTS");
                DyParam.Add("p_request_id", OracleDbType.Varchar2, direction: ParameterDirection.Input, value: null);
                DyParam.Add("p_request", OracleDbType.Clob, direction: ParameterDirection.Input, value: jsonXML);

                Log.Debug($"ValidateParams Response: {JsonConvert.SerializeObject(DyParam)}");
                return DyParam;
            }
            catch (Exception e)
            {
                Log.Error($"{e}");
                throw;
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }

        public ReceiptCoverageOutPutDTO SubmitStoreProcedure(string OracleExec, OracleDynamicParameters InPutParamOracle)
        {
            var result = new ReceiptCoverageOutPutDTO();
            try
            {
                //OracleFunction
                var conn = connection.GetConnection;
                var command = OracleExec;

                Log.Debug($"ConnectionString: {conn.ConnectionString}");

                var resultSP = conn.Execute(command, param: InPutParamOracle, commandType: CommandType.StoredProcedure);

                var response = InPutParamOracle.GetXml("p_response");
                var erro = InPutParamOracle.GetXml("p_error");

                if (response != null)
                {
                    var receiptsOracle = _mapper.Map<ReceiptCoverage>(response.Document);
                    result.Data = receiptsOracle;
                }
                else
                {
                    var erroOracle = _mapper.Map<ErrorOracle>(erro.Document);
                    result.Errors = erroOracle.CanonicalTypeError.ToList();
                }

                return result;
            }
            catch (ProcessErrorException processError)
            {
                throw new ProcessErrorException(
                           StatusCodes.Status408RequestTimeout.ToString(CultureInfo.CurrentCulture),
                           processError.Message, new List<ProcessErrorException.InnerError>
                           {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status408RequestTimeout.ToString(CultureInfo.CurrentCulture),
                                       ErrorMessage = processError.Message
                                   }
                           }
                           );

            }
            catch (Exception ex)
            {
                Log.Error($"{ex}");
                throw;
            }
        }

        public async Task<ReceiptCoverageOutPutDTO> GetReceiptAsync(ReceiptCoverageInput inputData)
        {
            try
            {

            Stopwatch stopwatch = new Stopwatch();
            //Oracle Params definition
            OracleDynamicParameters DyParam = ValidateParams(inputData);

            //Set ResultData Structure
            var ResultData = new ReceiptCoverageOutPutDTO();

            Log.Debug($"GetDoc SubmitFunction Oracle without document Request: {JsonConvert.SerializeObject(DyParam)}");
            stopwatch.Start();

            var oracleExec = $"{_oraclePackageWebservices}" + $".{_oracleStoredProcedure}";

            //GetDoc SubmitFunction Oracle without document Request
            var validaAgentResult = SubmitStoreProcedure(oracleExec, DyParam);

            stopwatch.Stop();
            Log.Debug($"GetDoc SubmitFunction Oracle without document Response: {JsonConvert.SerializeObject(ResultData)}");

            return validaAgentResult;

            }
            catch (ProcessErrorException processError)
            {
                throw new ProcessErrorException(
                           StatusCodes.Status408RequestTimeout.ToString(CultureInfo.CurrentCulture),
                           processError.Message, new List<ProcessErrorException.InnerError>
                           {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status408RequestTimeout.ToString(CultureInfo.CurrentCulture),
                                       ErrorMessage = processError.Message
                                   }
                           }
                           );

            }
            catch (Exception ex)
            {
                Log.Error($"{ex}");
                throw;
            }
        }

        public static string ReceiptInputToXml(ReceiptCoverageInput inputDataCoverage)
        {
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ReceiptCoverageInput));
            using StringWriter textWriter = new StringWriter();

            xmlSerializer.Serialize(textWriter, inputDataCoverage);
            return textWriter.ToString().Replace($"{ "<?xml version=\"1.0\" encoding=\"utf-16\"?>\r\n<ReceiptCoverageInput xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">\r\n"}", "").Replace("</ReceiptCoverageInput>", "").Trim();
        }
    }
}

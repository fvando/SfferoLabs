﻿using INS.PT.WebAPI.Constants;
using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.Domain;
using INS.PT.WebAPI.Model.Domain.CanonicalCoverage;
using INS.PT.WebAPI.Model.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Constants.CommonEnums;

namespace INS.PT.WebAPI.Repository
{
    public class StatesRepository : BaseRepository, IStatesRepository
    {
        private readonly IHttpClientRepository httpClientRepository;
        private const string GetSettingsMethod = "v1/ReferenceData";
        private const string GetSettingsMethodCoverage = "v1/Receipt/Coverage";
        private const string GetPolicies = "v1/Policies";
        private const string GetReceipts = "v1/Receipts";
        private const string VMESSAGE = "Not found, please try again.";
        private readonly IMemoryCache cache;


        public StatesRepository(IConfiguration _configuration, IMemoryCache _cache, IRepositoryInvoker _repositoryInvoker,
            IHttpClientRepository _httpClientRepository, HttpRequest _request) : base(_configuration, _repositoryInvoker, _request)
        {
            cache = _cache;
            httpClientRepository = _httpClientRepository;
        }

        public async Task<GlobalEntityOutput> GetListEntities(GlobalEntityInput requestObject)
        {
            HttpRequestElement requestElement = new HttpRequestElement
            {
                ApiService = configuration.GetSection("BrokerSettingsReferenceData").GetSection("WebService").Value,
                ApiMethod = GetSettingsMethod,
                Method = CommonEnums.HttpRequestVerb.POST,
                QueryString = request.QueryString,
                Options = new OptionsElement { HandleList404Response = true },
                RequestObject = requestObject,
                ContentType = configuration.GetSection("BrokerSettingsReferenceData").GetSection("ContentTypeJson").Value,
                EndPoint = configuration.GetSection("BrokerSettingsReferenceData").GetSection("Endpoint").Value,
                Solution = configuration.GetSection("BrokerSettingsReferenceData").GetSection("Solution").Value,
                User = configuration.GetSection("BrokerSettingsReferenceData").GetSection("User").Value

            };

            var output =
             await repositoryInvoker.GenericInvokerAsync<GlobalEntityOutput, GlobalEntityOutputDTO>(requestElement);

            return output;
        }

        public async Task<GlobalEntityOutput> GetListAll(DomainsData requestObject)
        {
            HttpRequestElement requestElement = new HttpRequestElement
            {

                ApiService = configuration.GetSection("BrokerSettingsReferenceData").GetSection("WebService").Value,
                ApiMethod = GetSettingsMethod,
                Method = CommonEnums.HttpRequestVerb.GET,
                Options = new OptionsElement { HandleList404Response = true },
                RouteValue = $"/{requestObject}?PageSize=1000",
                ContentType = configuration.GetSection("BrokerSettingsReferenceData").GetSection("ContentTypeJson").Value,
                EndPoint = configuration.GetSection("BrokerSettingsReferenceData").GetSection("Endpoint").Value,
                Solution = configuration.GetSection("BrokerSettingsReferenceData").GetSection("Solution").Value,
                User = configuration.GetSection("BrokerSettingsReferenceData").GetSection("User").Value
            };

            var output =
              await repositoryInvoker.GenericInvokerAsync<GlobalEntityOutput, GlobalEntityOutputDTO>(requestElement);

            return output;
        }

        public async Task<GlobalEntityOutput> SetMemoryCache(DomainsData IdDomain, Boolean Active = false)
        {
            string state = string.Empty;
            GlobalEntityOutput cacheObj = null;

            if (Active)
            {
                if (!cache.TryGetValue($"CashedDomainReferenceData_{IdDomain}", out Dictionary<string, object> states))
                {
                    //Chamar o método e carregar do referenceData
                    states = new Dictionary<string, object>
                    {
                        {
                            IdDomain.ToString(),
                            await GetListAll(IdDomain)
                        }
                    };
                    MemoryCacheEntryOptions options = new MemoryCacheEntryOptions
                    {
                        AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(Convert.ToDouble(configuration.GetSection("CacheDomain")
                        .GetSection("AbsoluteExpirationRelativeToNow").Value)), // cache will expire in 300 seconds or 5 minutes
                        SlidingExpiration = TimeSpan.FromSeconds(Convert.ToDouble(configuration.GetSection("CacheDomain")
                        .GetSection("SlidingExpiration").Value)) // cache will expire if inactive for 60 seconds
                    };
                    if (states != null)
                    {
                        cache.Set($"CashedDomainReferenceData_{IdDomain}", states, options);
                        Log.Debug($"key: {JsonConvert.SerializeObject($"CashedDomainReferenceData_{IdDomain}")}");
                        Log.Debug($"States: {JsonConvert.SerializeObject(states)}");
                        Log.Debug($"Options: {JsonConvert.SerializeObject(options)}");
                    }
                }
                else
                {
                    Log.Information($"Cache: ***Data Found in Cache...***");
                    Log.Debug($"key: {JsonConvert.SerializeObject($"CashedDomainReferenceData_{IdDomain}")}");
                }

                if (states != null)
                {
                    //typecast return object
                    cacheObj = (GlobalEntityOutput)states.GetValueOrDefault(IdDomain.ToString());

                    if (cacheObj == null)
                    {
                        state = VMESSAGE;
                    }
                }
            }
            else
            {
                //get objects from service referenceData
                cacheObj = await GetListAll(IdDomain);
            }

            return cacheObj;
        }

        public async Task<string> GetbyValueAsync(string codInterno, CommonEnums.DomainsData domainData)
        {
            string retorno = string.Empty;

            var cacheObjReturn = await SetMemoryCache(domainData, configuration.GetSection("CacheDomain").GetSection("Active").Value.Equals("true", StringComparison.InvariantCulture));

            //Test for InternalCode
            if (!string.IsNullOrEmpty(codInterno))
            {
                if (!string.IsNullOrEmpty(cacheObjReturn?.resultList?.FirstOrDefault()?.extraProperties?.CodInterno))
                {
                    retorno = cacheObjReturn?.resultList.FirstOrDefault(x => x?.extraProperties?.CodInterno == codInterno)?.Description;
                }
                else
                {
                    retorno = cacheObjReturn?.resultList.FirstOrDefault(x => x?.IdElement == codInterno)?.Description;
                }
            }

            return retorno;
        }

        public async Task<ReceiptCoverageOutput> GetReceiptCoverageAsync(ReceiptCoverageInput requestObject)
        {
            HttpRequestElement requestElement = new HttpRequestElement
            {
                ApiService = configuration.GetSection("CanonicalService").GetSection("WebService").Value,
                ApiMethod = GetSettingsMethodCoverage,
                Method = CommonEnums.HttpRequestVerb.POST,
                QueryString = request.QueryString,
                Options = new OptionsElement { HandleList404Response = true },
                RequestObject = requestObject,
                ContentType = configuration.GetSection("CanonicalService").GetSection("ContentTypeJson").Value,
                EndPoint = configuration.GetSection("CanonicalService").GetSection("Endpoint").Value,
                Solution = configuration.GetSection("CanonicalService").GetSection("BrokerSolution").Value,
                User = configuration.GetSection("CanonicalService").GetSection("BrokerUser").Value

            };

            var output =
             await repositoryInvoker.GenericInvokerAsync<ReceiptCoverageOutput, ReceiptCoverageOutPutDTO>(requestElement);

            return output;
        }
        public async Task<HamedPolicyListOutput> GetHamedPoliciesAsync(string policyNumber)
        {
            HttpRequestElement requestElement = new HttpRequestElement
            {
                ApiService = configuration.GetSection("BrokerSettingsOutstandingPolicyPremiums").GetSection("WebService").Value,
                ApiMethod = GetPolicies,
                Method = CommonEnums.HttpRequestVerb.GET,
                Options = new OptionsElement { HandleList404Response = true },
                ContentType = configuration.GetSection("BrokerSettingsOutstandingPolicyPremiums").GetSection("ContentTypeJson").Value,
                EndPoint = configuration.GetSection("BrokerSettingsOutstandingPolicyPremiums").GetSection("Endpoint").Value + "/" + policyNumber,
                Solution = configuration.GetSection("BrokerSettingsOutstandingPolicyPremiums").GetSection("BrokerSolution").Value,
                User = configuration.GetSection("BrokerSettingsOutstandingPolicyPremiums").GetSection("BrokerUser").Value

            };

            var output =
             await repositoryInvoker.GenericInvokerAsync<HamedPolicyListOutput, HamedPolicyListOutputDTO>(requestElement);

            return output;
        }
        public async Task<HamedReceiptListOutput> GetHamedReceiptsAsync(string policyNumber)
        {
            
            HamedInput input = new HamedInput
            {
                PolicyNumber = policyNumber
            };
            HttpRequestElement requestElement = new HttpRequestElement
            {
                ApiService = configuration.GetSection("BrokerSettingsOutstandingPolicyPremiums").GetSection("WebService").Value,
                ApiMethod = GetReceipts,
                Method = CommonEnums.HttpRequestVerb.POST,
                Options = new OptionsElement { HandleList404Response = true },
                ContentType = configuration.GetSection("BrokerSettingsOutstandingPolicyPremiums").GetSection("ContentTypeJson").Value,
                EndPoint = configuration.GetSection("BrokerSettingsOutstandingPolicyPremiums").GetSection("Endpoint").Value,
                Solution = configuration.GetSection("BrokerSettingsOutstandingPolicyPremiums").GetSection("BrokerSolution").Value,
                User = configuration.GetSection("BrokerSettingsOutstandingPolicyPremiums").GetSection("BrokerUser").Value,
                RequestObject =input

            };

            var output =
             await repositoryInvoker.GenericInvokerAsync<HamedReceiptListOutput, HamedReceiptsListOutputDTO>(requestElement);

            return output;
        }
    }
}

﻿using AutoMapper;
using Canonical.ServiceReference;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.Domain;
using INS.PT.WebAPI.Model.Domain.CanonicalCoverage;
using INS.PT.WebAPI.Model.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PayrecService;
using SAP.Extern.WCF.WebReciptListing.Service.Reference.Tst;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.ServiceModel;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.WebReceiptList
{
    /// <summary>
    /// WebReceiptListingRepository
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.IWebReceiptListingRepository" />
    public class WebReceiptListingRepository : IWebReceiptListingRepository
    {
        private const string NameParam = "POLICY_ID";
        private const string GetSettingsMethod = "v1/ReferenceData";
        private readonly IReceiptRepository receiptRepository;
        private readonly IStatesRepository statesRepository;
        private readonly IMapper mapperReference;
        private readonly IConfiguration configuration;
        private readonly Z_FSCD_RECIBOS_WS referenceInterfaceWebReceiptList;
        private readonly IPolicy canonicalService;
        private readonly IPoliza polizaService;
        private readonly PayrecServicesSoap payrecService;
        protected readonly IHttpContextAccessor httpContext;


        protected readonly TimeSpan OpenTimeout;
        protected readonly TimeSpan CloseTimeout;
        protected readonly TimeSpan SendTimeout;
        protected readonly TimeSpan ReceiveTimeout;
        protected readonly TimeSpan RestTimeout;

        protected readonly Stopwatch stopwatch;

        public WebReceiptListingRepository(IConfiguration _configuration, IMapper _mapperReference, IStatesRepository _statesRepository, IPoliza _polizaService) : this(_configuration, _mapperReference, _statesRepository, _polizaService, null)
        {

        }

        public WebReceiptListingRepository(IConfiguration _configuration, IMapper _mapperReference, IStatesRepository _statesRepository, IPoliza _polizaService, Z_FSCD_RECIBOS_WS _referenceInterface)
        {

            polizaService = _polizaService;
            statesRepository = _statesRepository;
            mapperReference = _mapperReference;
            configuration = _configuration;

            canonicalService = CreateCanonicalClient();
            payrecService = CreatePayrecClient();
            
            if (_referenceInterface != null)
            {
                referenceInterfaceWebReceiptList = _referenceInterface;
                return;
            }

            #region Binding

            // read timeouts from config
            OpenTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:OpenTimeout");
            CloseTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:CloseTimeout");
            SendTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:SendTimeout");
            ReceiveTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:ReceiveTimeout");
            RestTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:RestTimeout");

            var binding = new BasicHttpBinding
            {
                MaxReceivedMessageSize = int.MaxValue,
                MaxBufferPoolSize = int.MaxValue,
                MaxBufferSize = int.MaxValue,
                AllowCookies = true,
                TransferMode = TransferMode.Buffered,
                SendTimeout = SendTimeout,
                ReceiveTimeout = ReceiveTimeout,
                CloseTimeout = CloseTimeout,
                OpenTimeout = OpenTimeout
            };

            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
            
            // read enpoint address
            var address = new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTReceipt").Value);
            
            // check if it is http or https
            if (string.Compare(address.Uri.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            } else {
                binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            }

            #endregion

            var client = new Z_FSCD_RECIBOS_WSClient(binding, new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTReceipt").Value));
            client.ClientCredentials.UserName.UserName = _configuration.GetSection("BasicAuth").GetSection("UserNameAuth").Value;
            client.ClientCredentials.UserName.Password = _configuration.GetSection("BasicAuth").GetSection("PasswordAuth").Value;

            referenceInterfaceWebReceiptList = client;

            stopwatch = new Stopwatch();

        }

        public PolicyClient CreateCanonicalClient()
        {
            // read enpoint address
            var address = new EndpointAddress(configuration.GetSection("CanonicalService").GetSection("CanonicalUrl").Value);

            // commom binding
            var binding = new BasicHttpBinding
            {
                MaxBufferSize = int.MaxValue,
                ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max,
                MaxReceivedMessageSize = int.MaxValue,
                AllowCookies = true,
                SendTimeout = SendTimeout,
                ReceiveTimeout = ReceiveTimeout,
                CloseTimeout = CloseTimeout,
                OpenTimeout = OpenTimeout
            };

            // check if it is http or https
            if (string.Compare(address.Uri.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            }

            // return proxy
            return new PolicyClient(binding, address);
        }
        public PayrecServicesSoapClient CreatePayrecClient()
        {
            // read enpoint address
            var address = new EndpointAddress(configuration.GetSection("BrokerSettingsOutstandingPolicyPremiums").GetSection("SoapEndPoint").Value);

            // commom binding
            var binding = new BasicHttpBinding
            {
                MaxBufferSize = int.MaxValue,
                ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max,
                MaxReceivedMessageSize = int.MaxValue,
                AllowCookies = true,
                SendTimeout = SendTimeout,
                ReceiveTimeout = ReceiveTimeout,
                CloseTimeout = CloseTimeout,
                OpenTimeout = OpenTimeout
        };

            // check if it is http or https
            if (string.Compare(address.Uri.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            }

            // return proxy
            return new PayrecServicesSoapClient(binding, address);
        }

        /// <summary>
        /// Gests the list asynchronous - ZFscdRecibosListarWs
        /// </summary>
        /// <param name="requestReceipt">The request receipt.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">
        /// Not Found
        /// or
        /// Not Found
        /// or
        /// Request Timeout
        /// or
        /// NullReference
        /// or
        /// Fault
        /// </exception>
        /// <exception cref="ProcessErrorException.InnerError">
        /// </exception>
        public async Task<Model.Partners.WebReceiptListing.ZFscdRecibosListarWsResponse> GestListAsync(Model.Partners.WebReceiptListing.ZFscdRecibosListarWs requestReceipt)
        {
            try
            {
                var requestToSourceStructure = mapperReference.Map<ZFscdRecibosListarWs>(requestReceipt);
                var request = new ZFscdRecibosListarWsRequest {
                    ZFscdRecibosListarWs = requestToSourceStructure
                };

                stopwatch.Restart();
                Log.Debug("ZFscdRecibosListarWsAsync SAP Request: {requestReceipt}", JsonConvert.SerializeObject(requestReceipt));
                var SapResponse = await referenceInterfaceWebReceiptList.ZFscdRecibosListarWsAsync(request);
                stopwatch.Stop();
                Log.Debug("ZFscdRecibosListarWsAsync SAP Response: {SapResponse} in {Elapsed:000} ms", JsonConvert.SerializeObject(SapResponse), stopwatch.ElapsedMilliseconds);

                stopwatch.Restart();
                Log.Debug("GestListAsync Responde before transformation Policy: {sapResponse}", SapResponse);
                var SapResponseUpdated = polizaService.UpdateNumPoliza(SapResponse);
                stopwatch.Stop();
                Log.Debug("GestListAsync Response after transformation Policy: {SapResponseUpdated} in {Elapsed:000} ms", SapResponseUpdated, stopwatch.ElapsedMilliseconds);

                //convert to OUT structure
                var ServiceResponse = mapperReference.Map<Model.Partners.WebReceiptListing.ZFscdRecibosListarWsResponse>(SapResponseUpdated?.ZFscdRecibosListarWsResponse);

                //Description Return Reason
                stopwatch.Restart();
                Log.Debug("GetDescriptionDomainAsync Request: {statesRepository}", statesRepository);
                var TransformationInput = new TransformationData(statesRepository);
                var ServiceResponseUpdated = await TransformationInput.GetDescriptionDomainAsync(ServiceResponse, Constants.CommonEnums.DomainsData.PA041);
                stopwatch.Stop();
                Log.Debug("GetDescriptionDomainAsync Response: {ServiceResponseUpdated} in {Elapsed:000} ms", ServiceResponseUpdated, stopwatch.ElapsedMilliseconds);

                return ServiceResponseUpdated;
            }
           
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.InnerException?.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.InnerException?.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }

        }

        /// <summary>
        /// Gests the list detail asynchronous - ZfscdRecibosWorkLinha
        /// </summary>
        /// <param name="requestReceipt">The request receipt.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">
        /// </exception>
        /// <exception cref="List{ProcessErrorException.InnerError}">
        /// </exception>
        /// <exception cref="ProcessErrorException.InnerError">
        /// </exception>
        public async Task<Model.Partners.WebReceiptListing.ZfscdRecibosWorkLinha> GestListDetailAsync(Model.Partners.WebReceiptListing.ZFscdRecibosListarWs requestReceipt)
        {
            try
            {
                var request = new ZFscdRecibosListarWsRequest{
                    ZFscdRecibosListarWs = mapperReference.Map<ZFscdRecibosListarWs>(requestReceipt)
                };

                Log.Information("ZFscdRecibosListarWsAsync SAP Request: {request}", JsonConvert.SerializeObject(request));
                var SapResponse = await referenceInterfaceWebReceiptList.ZFscdRecibosListarWsAsync(request);
                stopwatch.Stop();
                Log.Debug("ZFscdRecibosListarWsAsync SAP Response: {SapResponse} in {Elapsed:000} ms", JsonConvert.SerializeObject(SapResponse), stopwatch.ElapsedMilliseconds);

                stopwatch.Restart();
                Log.Debug($"UpdateNumPoliza Request: {JsonConvert.SerializeObject(SapResponse)}");
                var SapResponseUpdated = polizaService.UpdateNumPoliza(SapResponse);
                stopwatch.Stop();
                Log.Debug("UpdateNumPoliza Response : {SapResponseUpdated} in {Elapsed:000} ms", JsonConvert.SerializeObject(SapResponseUpdated), stopwatch.ElapsedMilliseconds);

                var ResultService = mapperReference.Map<Model.Partners.WebReceiptListing.ZFscdRecibosListarWsResponse1>(SapResponseUpdated);

                //Description Return Reason
                stopwatch.Restart();
                Log.Debug("GetDescriptionDomainAsync Request: {statesRepository}", JsonConvert.SerializeObject(statesRepository));
                var TransformationInput = new TransformationData(statesRepository);
                var ServiceResponseUpdated = await TransformationInput.GetDescriptionDomainAsync(ResultService.ZFscdRecibosListarWsResponse, Constants.CommonEnums.DomainsData.PA041);
                stopwatch.Stop();
                Log.Debug("GetDescriptionDomainAsync Response: {ServiceResponseUpdated} in {Elapsed:000} ms", JsonConvert.SerializeObject(ServiceResponseUpdated), stopwatch.ElapsedMilliseconds);

                //Fill Error Attribute
                if (ServiceResponseUpdated?.ReceiptsNumbers?.FirstOrDefault() != null)
                {
                    if (ServiceResponseUpdated?.Errors?.Count > 0) {
                        ServiceResponseUpdated.ReceiptsNumbers.FirstOrDefault().Errors = ServiceResponseUpdated?.Errors.ToList();
                    }
                    await ReadCanonicalInformation(ServiceResponseUpdated, true);
                }
                else
                {
                    ServiceResponseUpdated.ReceiptsNumbers = new List<Model.Partners.WebReceiptListing.ZfscdRecibosWorkLinha>() {

                        new Model.Partners.WebReceiptListing.ZfscdRecibosWorkLinha(){

                            Errors = ServiceResponseUpdated?.Errors.ToList()
                }

                    }.ToList();
                };

                var Response = ServiceResponseUpdated?.ReceiptsNumbers?.FirstOrDefault();
                
                return Response;

            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }

        /// <summary>
        /// Reads the canonical information.
        /// </summary>
        /// <param name="result">The result.</param>
        /// <param name="isService">if set to <c>true</c> [is service].</param>
        private async Task ReadCanonicalInformation(Model.Partners.WebReceiptListing.ZFscdRecibosListarWsResponse result, bool isService)
        {
            try
            {
                var requestObject = new ReceiptCoverageInput {
                    Request = new Request {
                        Parameters = new Parameters {
                            Parameter = new Parameter {
                                Name = NameParam,
                                Value = result?.ReceiptsNumbers?.FirstOrDefault().Contract
                            }
                        }
                    }
                };

                stopwatch.Restart();
                Log.Debug("GetReceiptCoverageAsync Request: {requestObject}", JsonConvert.SerializeObject(requestObject));
                ReceiptCoverageOutput ReceiptCoverage = await statesRepository.GetReceiptCoverageAsync(requestObject);
                stopwatch.Stop();
                Log.Debug("GetReceiptCoverageAsync Response: {ReceiptCoverage} in {Elapsed:000} ms", JsonConvert.SerializeObject(ReceiptCoverage), stopwatch.ElapsedMilliseconds);

                if (ReceiptCoverage?.Data?.CanonicalReceiptType?.FirstOrDefault().ReceiptId != null)
                {
                    result.ReceiptsNumbers.FirstOrDefault().Coverage = new List<Model.Domain.CoverageElements>();

                    foreach (var coverage in ReceiptCoverage.Data.CanonicalReceiptType)
                    {
                        if (string.Compare(coverage.ReceiptId, result.ReceiptsNumbers.FirstOrDefault().ReferenceDocumentNumber, StringComparison.InvariantCultureIgnoreCase) == 0)
                        {
                            foreach (var item in coverage.CoveragePerValue.TypeCanonicalCoverageValue)
                            {
                                result.ReceiptsNumbers.FirstOrDefault().Coverage.Add(
                                    new Model.Domain.CoverageElements
                                    {
                                        description = item?.CoverDescription,
                                        value = item?.Value
                                    });
                            }
                        }
                    };
                }
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
            }
        }

        /// <summary>
        /// GetOutstandingPolicyPremiumsWASPAsync
        /// </summary>
        /// <param name="inputData"></param>
        /// <returns></returns>
        public async Task<GetOutstandingPolicyPremiumsWASPOutputData> GetOutstandingPolicyPremiumsWASPAsync(GetOutstandingPolicyPremiumsWASPInputData inputData)
        {
            GetOutstandingPolicyPremiumsWASPOutputData output = new GetOutstandingPolicyPremiumsWASPOutputData();
            output.Errors = new List<string>();
            var hamedPolicy = await ReadHamedPolicysync(inputData);
            if (hamedPolicy != null && hamedPolicy.Result.Count() > 0)
            {
                output.ClaimRegularitzaionIndicator = hamedPolicy?.Result?.FirstOrDefault()?.claimRegularitzaion;

                var hamedReceipts = ReadHamedReceiptsync(inputData);

                //get things from urn:bcpcorp.net/ws/bsgFinantial/PayrecServices WebMethod:premiumReceiptListBSG(id:2758)
                var premiumReceiptList = ReadpremiumReceiptListBSGAsync(inputData, hamedPolicy);

                await Task.WhenAll(hamedReceipts, premiumReceiptList);

                if (hamedReceipts != null && hamedReceipts.Result != null && hamedReceipts.Result.Result != null && hamedReceipts.Result.Result.Count() > 0)
                {
                    output.ReceiptArray.AddRange(hamedReceipts.Result.Result.Where(y => y.SituationIdOriginal != "C" && y.SituationIdOriginal != "P").Select(x => new Model.PremiumReceiptElement(x)));
                }

                if (premiumReceiptList != null && premiumReceiptList.Result.premiumReceiptListBSGResult != null && premiumReceiptList.Result.premiumReceiptListBSGResult.receiptArray != null && premiumReceiptList.Result.premiumReceiptListBSGResult.receiptArray.Count() > 0)
                {
                    output.ReceiptArray.AddRange(premiumReceiptList.Result.premiumReceiptListBSGResult.receiptArray.Where(y => y.status != "C" && y.status != "P").Select(x => new Model.PremiumReceiptElement(x)));
                }
                output.OutstandingPremiumsIndicator = output.ReceiptArray != null && output.ReceiptArray.Count() > 0 ? true : false;
            }
            else
            {
                output.Errors.Add(string.Format("A apólice {0} não existe na HAMED", inputData.PolicyNumber));
            }
            return output;
        }
        
        /// <summary>
        /// Reads the canonical information.ya
        /// </summary>
        /// <param name="inputData"></param>
        /// <param name="policies"></param>
        private async Task<premiumReceiptListBSGResponse> ReadpremiumReceiptListBSGAsync(GetOutstandingPolicyPremiumsWASPInputData inputData, HamedPolicyListOutput policies)
        {
            try
            {

                premiumReceiptListBSGResponse premiumReceiptListResponse = new premiumReceiptListBSGResponse();
                if (policies != null && policies.Result != null && !string.IsNullOrEmpty(policies.Result.FirstOrDefault().PaxusCode))
                {
                    // build request for canonical
                    var premiumReceiptListlRequest = new premiumReceiptListBSGRequest
                    {
                        AxisValues = new PayrecService.AxisValues
                        {
                            Solution = configuration.GetSection("BrokerSettingsOutstandingPolicyPremiums").GetSection("BrokerSolution").Value,
                            User = configuration.GetSection("BrokerSettingsOutstandingPolicyPremiums").GetSection("BrokerUser").Value
                        },
                        inputData = new PremiumReceiptListBSGInputData
                        {
                            policyNumber = inputData.PolicyNumber,
                            paxusCompanyCode = policies.Result.FirstOrDefault().PaxusCode,
                            receiptStartDate = inputData.ClaimDate != null ? inputData.ClaimDate.Value : DateTime.MinValue
                        }
                    };

                    stopwatch.Restart();
                    Log.Debug("ReadpremiumReceiptListBSGAsync Request: {premiumReceiptListlRequest} ", JsonConvert.SerializeObject(premiumReceiptListlRequest));
                    // make call to service
                    premiumReceiptListResponse = await payrecService.premiumReceiptListBSGAsync(premiumReceiptListlRequest);
                    stopwatch.Stop();
                    // log results
                    Log.Debug("ReadpremiumReceiptListBSGAsync Response: {premiumReceiptListResponse} in {Elapsed:000} ms", JsonConvert.SerializeObject(premiumReceiptListResponse), stopwatch.ElapsedMilliseconds);

                }
                return premiumReceiptListResponse;
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                return new premiumReceiptListBSGResponse();
            }
        }

        /// <summary>
        /// Reads the canonical information.
        /// </summary>
        /// <param name="inputData"></param>
        private async Task<HamedPolicyListOutput> ReadHamedPolicysync(GetOutstandingPolicyPremiumsWASPInputData inputData)
        {
            HamedPolicyListOutput policies = new HamedPolicyListOutput();
            try
            {
                stopwatch.Restart();
                Log.Debug("ReadHamedPolicysync Request: {PolicyNumber}", JsonConvert.SerializeObject(inputData.PolicyNumber));
                policies = await statesRepository.GetHamedPoliciesAsync(inputData.PolicyNumber);
                if (policies != null && policies.Result != null && policies.Result.Count() > 0)
                {
                    policies.Result.FirstOrDefault().CompanyCode = ConvertCompanyTo.geCompanyCode(policies.Result.FirstOrDefault().Company);
                    policies.Result.FirstOrDefault().claimRegularitzaion = ClaimRegularitzaion.getValue(policies.Result.FirstOrDefault().ProductCode, policies.Result.FirstOrDefault().ProtocolCode);
                    policies.Result.FirstOrDefault().PaxusCode = ConvertCompanyTo.gePaxusCode(policies.Result.FirstOrDefault().Company, policies.Result.FirstOrDefault().Source.ToUpper() == "AIA");
                }

                // make call to service
                stopwatch.Stop();
                // log results
                Log.Debug("ReadHamedPolicysync Response: {policies} in {Elapsed:000} ms", JsonConvert.SerializeObject(policies), stopwatch.ElapsedMilliseconds);

                return policies;
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw e;
            }
        }
        /// <summary>
        /// Reads the canonical information.
        /// </summary>
        /// <param name="inputData"></param>
        private async Task<HamedReceiptListOutput> ReadHamedReceiptsync(GetOutstandingPolicyPremiumsWASPInputData inputData)
        {
            HamedReceiptListOutput receipts = new HamedReceiptListOutput();
            try
            {
                stopwatch.Restart();
                Log.Debug("ReadHamedPolicysync Request: {PolicyNumber}", JsonConvert.SerializeObject(inputData.PolicyNumber));
                receipts = await statesRepository.GetHamedReceiptsAsync(inputData.PolicyNumber);
               
                // make call to service
                stopwatch.Stop();
                // log results
                Log.Debug("ReadHamedPolicysync Response: {policies} in {Elapsed:000} ms", JsonConvert.SerializeObject(receipts), stopwatch.ElapsedMilliseconds);

                return receipts;
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw e;
            }
        }

    }
}

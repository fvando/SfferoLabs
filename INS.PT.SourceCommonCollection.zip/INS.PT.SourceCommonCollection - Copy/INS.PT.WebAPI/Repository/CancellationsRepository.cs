﻿using AutoMapper;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SAP.Extern.WCF.Cancel.Service.Reference.Tst;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.ServiceModel;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Cancel
{
    /// <summary>
    /// CancellationsRepository
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.ICancellationsRepository" />
    public class CancellationsRepository : ICancellationsRepository
    {
        private readonly IMapper _mapper;
        private readonly IConfiguration _configuration;
        private readonly Z_FSCD_ANULAR_WS referenceInterfaceCancel;

        protected readonly TimeSpan OpenTimeout;
        protected readonly TimeSpan CloseTimeout;
        protected readonly TimeSpan SendTimeout;
        protected readonly TimeSpan ReceiveTimeout;
        protected readonly TimeSpan RestTimeout;

        protected readonly Stopwatch stopWatch;
        /// <summary>
        /// Initializes a new instance of the <see cref="CancellationsRepository"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        /// <param name="mapperReference">The mapper reference.</param>
        public CancellationsRepository(IConfiguration configuration, IMapper mapperReference) : this(configuration, mapperReference, null)
        { }

        /// <summary>
        /// Initializes a new instance of the <see cref="CancellationsRepository"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        /// <param name="mapperReference">The mapper reference.</param>
        /// <param name="referenceInterface">The reference interface.</param>
        public CancellationsRepository(IConfiguration configuration, IMapper mapperReference, Z_FSCD_ANULAR_WS referenceInterface)
        {
            _mapper = mapperReference;
            _configuration = configuration;

            if (referenceInterface != null)
            {
                this.referenceInterfaceCancel = referenceInterface;
                return;
            }

            #region Binding

            // read timeouts from config
            OpenTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:OpenTimeout");
            CloseTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:CloseTimeout");
            SendTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:SendTimeout");
            ReceiveTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:ReceiveTimeout");
            RestTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:RestTimeout");

            var binding = new BasicHttpBinding
            {
                MaxReceivedMessageSize = int.MaxValue,
                MaxBufferPoolSize = int.MaxValue,
                MaxBufferSize = int.MaxValue,
                AllowCookies = true,
                TransferMode = TransferMode.Buffered,
                SendTimeout = SendTimeout,
                ReceiveTimeout = ReceiveTimeout,
                CloseTimeout = CloseTimeout,
                OpenTimeout = OpenTimeout
            };

            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;

            // read enpoint address
            var address = new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTCancel").Value);

            // check if it is http or https
            if (string.Compare(address.Uri.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            }
            else
            {
                binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            }

            #endregion


            var client = new Z_FSCD_ANULAR_WSClient(binding, new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTCancel").Value));
            client.ClientCredentials.UserName.UserName = _configuration.GetSection("BasicAuth").GetSection("UserNameAuth").Value;
            client.ClientCredentials.UserName.Password = _configuration.GetSection("BasicAuth").GetSection("PasswordAuth").Value;

            referenceInterfaceCancel = client;

            stopWatch = new Stopwatch();

        }
        /// <summary>
        /// Gets the configuration.
        /// </summary>
        /// <value>
        /// The configuration.
        /// </value>
        public IConfiguration Configuration => _configuration;

        /// <summary>
        /// Gets the cancellation cancel asynchronous.
        /// </summary>
        /// <param name="requestCancelReceipt">The request cancel receipt.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">
        /// Not Found
        /// or
        /// Not Found
        /// or
        /// Request Timeout
        /// or
        /// NullReference
        /// or
        /// Fault
        /// </exception>
        /// <exception cref="ProcessErrorException.InnerError">
        /// </exception>
        public async Task<Model.Partners.Cancel.ZFscdAnularRecibosPostWsResponse1> GetCancellationCancelAsync(Model.Partners.Cancel.ZFscdAnularRecibosPostWs requestCancelReceipt)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = _mapper.Map<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZFscdAnularRecibosPostWs>(requestCancelReceipt);
                var request = new SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZFscdAnularRecibosPostWsRequest {
                    ZFscdAnularRecibosPostWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("ZFscdAnularRecibosPostWsAsync SAP Request: {request}", JsonConvert.SerializeObject(request));
                var _response = await referenceInterfaceCancel.ZFscdAnularRecibosPostWsAsync(request);
                stopWatch.Stop();
                Log.Debug("ZFscdAnularRecibosPostWsAsync SAP Response: {ServiceResponseUpdated} in {Elapsed:000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                return _mapper.Map<INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWsResponse1>(_response);
            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }

        /// <summary>
        /// Gets the cancellation policy asynchronous.
        /// </summary>
        /// <param name="requestPolicyReceipt">The request policy receipt.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">
        /// Not Found
        /// or
        /// Not Found
        /// or
        /// Request Timeout
        /// or
        /// NullReference
        /// or
        /// Fault
        /// </exception>
        /// <exception cref="ProcessErrorException.InnerError">
        /// </exception>
        public async Task<Model.Partners.Cancel.ZFscdAnularApolicesPostWsResponse1> GetCancellationPolicyAsync(Model.Partners.Cancel.ZFscdAnularApolicesPostWs requestPolicyReceipt)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = _mapper.Map<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZFscdAnularApolicesPostWs>(requestPolicyReceipt);
                var request = new SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZFscdAnularApolicesPostWsRequest {
                    ZFscdAnularApolicesPostWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("ZFscdAnularApolicesPostWsAsync SAP Request: {request}", JsonConvert.SerializeObject(request));
                var _response = await referenceInterfaceCancel.ZFscdAnularApolicesPostWsAsync(request);
                stopWatch.Stop();
                Log.Debug("ZFscdAnularApolicesPostWsAsync SAP Response: {_response} in {Elapsed:000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                return _mapper.Map<INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWsResponse1>(_response);
            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (System.ServiceModel.CommunicationException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }
        }

        /// <summary>
        /// Gets the cancellation cancel dates asynchronous.
        /// </summary>
        /// <param name="requestCancelDates">The request cancel dates.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">
        /// </exception>
        /// <exception cref="List{ProcessErrorException.InnerError}">
        /// </exception>
        /// <exception cref="ProcessErrorException.InnerError">
        /// </exception>
        public async Task<Model.Partners.Cancel.ZFscdAnularDatasPostWsResponse1> GetCancellationCancelDatesAsync(Model.Partners.Cancel.ZFscdAnularDatasPostWs requestCancelDates)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = _mapper.Map<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZFscdAnularDatasPostWs>(requestCancelDates);
                var request = new SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZFscdAnularDatasPostWsRequest {
                    ZFscdAnularDatasPostWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("ZFscdAnularDatasPostWsAsync SAP Request: {request}", JsonConvert.SerializeObject(request));
                var _response = await referenceInterfaceCancel.ZFscdAnularDatasPostWsAsync(request);
                stopWatch.Stop();
                Log.Debug("ZFscdAnularDatasPostWsAsync SAP Response: {_response} in {Elapsed:000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                return _mapper.Map<INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularDatasPostWsResponse1>(_response);
            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (System.ServiceModel.CommunicationException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }
        }

    }
}

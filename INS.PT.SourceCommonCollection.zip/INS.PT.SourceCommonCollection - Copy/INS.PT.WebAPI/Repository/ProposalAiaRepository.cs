﻿using AutoMapper;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SAP.Extern.WCF.Police.AIA.Service.Reference.Tst;
using SAP.Extern.WCF.Get.Proposal.AIA.Service.Reference;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.ServiceModel;
using System.Threading.Tasks;
using SAP.Extern.WCF.Upd.Proposal.AIA.Service.Reference;
using SAP.Extern.WCF.BeforeCharge.Proposal.AIA.Service.Reference;

namespace INS.PT.WebAPI.Policy.AIA
{
    /// <summary>
    /// PoliciesRepository : IPoliciesRepository
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.IPoliciesRepository" />
    public class ProposalAiaRepository : IProposalAiaRepository
    {
        private readonly IMapper _mapper;
        private readonly IConfiguration _configuration;
        private readonly ZAGEAS_PROPOSAL_WS referenceInterfaceGetProposalAia;
        private readonly ZAGEAS_UPD_PROPOSAL_WS referenceInterfaceUpdProposalAia;
        private readonly ZAGEAS_GET_BEFORE_CHARGE_WS referenceInterfaceBegoreChargeProposalAia;
        public IConfiguration Configuration => _configuration;

        protected readonly TimeSpan OpenTimeout;
        protected readonly TimeSpan CloseTimeout;
        protected readonly TimeSpan SendTimeout;
        protected readonly TimeSpan ReceiveTimeout;
        protected readonly TimeSpan RestTimeout;
        protected readonly Stopwatch stopWatch;

        /// <summary>
        /// Initializes a new instance of the <see cref="PoliciesRepository"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        /// <param name="mapperReference">The mapper reference.</param>
        public ProposalAiaRepository(IConfiguration configuration, IMapper mapperReference) : this(configuration, mapperReference, null, null, null)
        { }
        /// <summary>
        /// Initializes a new instance of the <see cref="PoliciesRepository"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        /// <param name="mapperReference">The mapper reference.</param>
        /// <param name="referenceInterface">The reference interface.</param>
        public ProposalAiaRepository(IConfiguration configuration, IMapper mapperReference, ZAGEAS_PROPOSAL_WS referenceGetInterface, ZAGEAS_UPD_PROPOSAL_WS referenceUpdInterface, ZAGEAS_GET_BEFORE_CHARGE_WS referenceBegoreChargeInterface)
        {
            _mapper = mapperReference;
            _configuration = configuration;

            #region Binding

            // read timeouts from config
            OpenTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:OpenTimeout");
            CloseTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:CloseTimeout");
            SendTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:SendTimeout");
            ReceiveTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:ReceiveTimeout");
            RestTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:RestTimeout");

            var binding = new BasicHttpBinding
            {
                MaxReceivedMessageSize = int.MaxValue,
                MaxBufferPoolSize = int.MaxValue,
                MaxBufferSize = int.MaxValue,
                AllowCookies = true,
                TransferMode = TransferMode.Buffered,
                SendTimeout = SendTimeout,
                ReceiveTimeout = ReceiveTimeout,
                CloseTimeout = CloseTimeout,
                OpenTimeout = OpenTimeout
            };

            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;


            #endregion

            #region GetAIA

            if (referenceGetInterface != null)
            {
                this.referenceInterfaceGetProposalAia = referenceGetInterface;
                return;
            }

            // read enpoint address
            var addressGet = new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTProposalAia").Value);

            // check if it is http or https
            if (string.Compare(addressGet.Uri.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            }
            else
            {
                binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            }

            var clientGetInterface = new SAP.Extern.WCF.Get.Proposal.AIA.Service.Reference.ZAGEAS_PROPOSAL_WSClient(binding,
              new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTProposalAia").Value));

            clientGetInterface.ClientCredentials.UserName.UserName =
                _configuration.GetSection("BasicAuthProposalAia").GetSection("UserNameAuthProposalAia").Value;

            clientGetInterface.ClientCredentials.UserName.Password =
             _configuration.GetSection("BasicAuthProposalAia").GetSection("PasswordAuthProposalAia").Value;

            referenceInterfaceGetProposalAia = clientGetInterface;

            #endregion

            #region BeforeChargeAIA

            if (referenceInterfaceBegoreChargeProposalAia != null)
            {
                this.referenceInterfaceBegoreChargeProposalAia = referenceBegoreChargeInterface;
                return;
            }
            // read enpoint address
            var addressBeforeCharge = new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTProposalBeforeChargeAia").Value);

            // check if it is http or https
            if (string.Compare(addressBeforeCharge.Uri.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            }
            else
            {
                binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            }

            var clientBeforeChargeInterface = new SAP.Extern.WCF.BeforeCharge.Proposal.AIA.Service.Reference.ZAGEAS_GET_BEFORE_CHARGE_WSClient(binding,
                new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTProposalBeforeChargeAia").Value));

            clientBeforeChargeInterface.ClientCredentials.UserName.UserName =
             _configuration.GetSection("BasicAuthProposalAia").GetSection("UserNameAuthProposalAia").Value;

            clientBeforeChargeInterface.ClientCredentials.UserName.Password =
                _configuration.GetSection("BasicAuthProposalAia").GetSection("PasswordAuthProposalAia").Value;

            referenceInterfaceBegoreChargeProposalAia = clientBeforeChargeInterface;

            #endregion

            #region UpdAIA
            if (referenceUpdInterface != null)
            {
                this.referenceInterfaceUpdProposalAia = referenceUpdInterface;
                return;
            }
            // read enpoint address
            var addressUpd = new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTProposalUpdAia").Value);

            // check if it is http or https
            if (string.Compare(addressUpd.Uri.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            }
            else
            {
                binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            }

            var clientUpdInterface = new SAP.Extern.WCF.Upd.Proposal.AIA.Service.Reference.ZAGEAS_UPD_PROPOSAL_WSClient(binding,
                new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTProposalUpdAia").Value));

            clientUpdInterface.ClientCredentials.UserName.UserName =
             _configuration.GetSection("BasicAuthProposalAia").GetSection("UserNameAuthProposalAia").Value;

            clientUpdInterface.ClientCredentials.UserName.Password =
                _configuration.GetSection("BasicAuthProposalAia").GetSection("PasswordAuthProposalAia").Value;

            referenceInterfaceUpdProposalAia = clientUpdInterface;

            #endregion

            stopWatch = new Stopwatch();
        }



        public async Task<Model.Partners.Get.ProposalAIA.ZageasLifeGetProposalWsResponse> GetLifeProposalAsync(Model.Partners.Get.ProposalAIA.ZageasLifeGetProposalWs requestPolicy)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = _mapper.Map<SAP.Extern.WCF.Get.Proposal.AIA.Service.Reference.ZageasLifeGetProposalWs>(requestPolicy);
                var request = new SAP.Extern.WCF.Get.Proposal.AIA.Service.Reference.ZageasLifeGetProposalWsRequest
                {
                    ZageasLifeGetProposalWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("ZAGEAS_PROPOSAL_WS SAP Request: {request}", JsonConvert.SerializeObject(request));
                var response = await referenceInterfaceGetProposalAia.ZageasLifeGetProposalWsAsync(request);

                var _response = _mapper.Map<Model.Partners.Get.ProposalAIA.ZageasLifeGetProposalWsResponse>(response.ZageasLifeGetProposalWsResponse);
                stopWatch.Stop();
                Log.Debug("ZAGEAS_PROPOSAL_WS SAP Response: {_response} in {Elapsed:000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                return _response;

            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }


        public async Task<INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWsResponse> UpdLifeProposalAsync(Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWs requestPolicy)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = _mapper.Map<SAP.Extern.WCF.Upd.Proposal.AIA.Service.Reference.ZageasLifeUpdProposalWs>(requestPolicy);
                var request = new SAP.Extern.WCF.Upd.Proposal.AIA.Service.Reference.ZageasLifeUpdProposalWsRequest
                {
                    ZageasLifeUpdProposalWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("ZageasLifeUpdProposalWs SAP Request: {request}", JsonConvert.SerializeObject(request));
                var response = await referenceInterfaceUpdProposalAia.ZageasLifeUpdProposalWsAsync(request);

                var _response = _mapper.Map<INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWsResponse>(response.ZageasLifeUpdProposalWsResponse);


                stopWatch.Stop();
                Log.Debug("ZageasLifeUpdProposalWs SAP Response: {_response} in {Elapsed:000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                return _response;

            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }


        public async Task<INS.PT.WebAPI.Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse>GetBeforeChargeLifeProposalAsync(Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWs requestPolicy)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = _mapper.Map<SAP.Extern.WCF.BeforeCharge.Proposal.AIA.Service.Reference.ZageasLifeGetBeforeChargeWs>(requestPolicy);
                var request = new SAP.Extern.WCF.BeforeCharge.Proposal.AIA.Service.Reference.ZageasLifeGetBeforeChargeWsRequest
                {
                    ZageasLifeGetBeforeChargeWs = requestToSourceStructure
                };

                stopWatch.Restart();
                Log.Debug("ZageasLifeGetBeforeChargeWs SAP Request: {request}", JsonConvert.SerializeObject(request));
                var response = await referenceInterfaceBegoreChargeProposalAia.ZageasLifeGetBeforeChargeWsAsync(request);

                var _response = _mapper.Map<INS.PT.WebAPI.Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse>(response.ZageasLifeGetBeforeChargeWsResponse);


                stopWatch.Stop();
                Log.Debug("ZageasLifeGetBeforeChargeWs SAP Response: {_response} in {Elapsed:000} ms", JsonConvert.SerializeObject(_response), stopWatch.ElapsedMilliseconds);

                //convert to OUT structure
                return _response;

            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }
    }
}

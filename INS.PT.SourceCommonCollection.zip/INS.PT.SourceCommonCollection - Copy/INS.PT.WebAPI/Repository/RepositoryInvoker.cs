﻿using AutoMapper;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Repository
{
    public class RepositoryInvoker : IRepositoryInvoker
    {
        #region Properties
        private readonly IMapper mapper;
        private readonly HttpRequest request;
        private readonly IHttpClientRepository httpClientRepository;
        #endregion

        public RepositoryInvoker(IHttpClientRepository _httpClientRepository, IMapper _mapper, HttpRequest _request)
        {
            request = _request;
            mapper = _mapper;
            httpClientRepository = _httpClientRepository;
        }

        public async Task<TWaspOutput> GenericInvokerAsync<TWaspInput, TWaspOutput, TDTOInput, TDTOOutput>(TWaspInput requestObject, string serviceNameSpace, string methodName, [Optional] string routeValue)
        {
            TWaspOutput result = default(TWaspOutput);
            var inputObj = mapper.Map<TDTOInput>(requestObject);

            var responseMessage = await httpClientRepository.ProcessRequestAsync(request, serviceNameSpace, methodName, routeValue, inputObj);

            if (responseMessage.IsSuccessStatusCode)
            {
                var response = responseMessage.Content.ReadAsAsync<TDTOOutput>();
                result = mapper.Map<TWaspOutput>(await response);
            }
            else
            {
                Log.Debug($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(responseMessage)}");

                if (responseMessage.StatusCode == System.Net.HttpStatusCode.BadRequest || responseMessage.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    object badRequestResponse = await responseMessage.Content.ReadAsAsync<object>();
                    throw new ProcessErrorException(
                            responseMessage.StatusCode.ToString(),
                            responseMessage.StatusCode.ToString(), new List<ProcessErrorException.InnerError>
                            {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = responseMessage.StatusCode.ToString(),
                                       ErrorMessage = JsonConvert.SerializeObject(badRequestResponse),
                                       ErrorType = ""
                                   }
                            }
                            );
                }

                throw new ProcessErrorException(
                         responseMessage.StatusCode.ToString(),
                         responseMessage.StatusCode.ToString(), new List<ProcessErrorException.InnerError>
                         {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = responseMessage.StatusCode.ToString(),
                                       ErrorMessage = JsonConvert.SerializeObject(responseMessage.ToString()),
                                       ErrorType = ""
                                   }
                         }
                         );


            }

            return result;
        }

        public async Task<TWaspOutput> GenericInvokerAsync<TWaspOutput, TDTOOutput>(string serviceNameSpace, string methodName, [Optional] string routeValue)
        {
            TWaspOutput result = default(TWaspOutput);

            var responseMessage = await httpClientRepository.ProcessRequestAsync(request, serviceNameSpace, methodName, routeValue);

            if (responseMessage.IsSuccessStatusCode)
            {
                var response = await responseMessage.Content.ReadAsAsync<TDTOOutput>();
                result = mapper.Map<TWaspOutput>(response);
            }
            else
            {
                Log.Debug($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(responseMessage)}");

                if (responseMessage.StatusCode == System.Net.HttpStatusCode.BadRequest || responseMessage.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    object badRequestResponse = await responseMessage.Content.ReadAsAsync<object>();
                    throw new ProcessErrorException(
                            responseMessage.StatusCode.ToString(),
                            responseMessage.StatusCode.ToString(), new List<ProcessErrorException.InnerError>
                            {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = responseMessage.StatusCode.ToString(),
                                       ErrorMessage = JsonConvert.SerializeObject(badRequestResponse),
                                       ErrorType = ""
                                   }
                            }
                            );
                }

                throw new ProcessErrorException(
                      responseMessage.StatusCode.ToString(),
                      responseMessage.StatusCode.ToString(), new List<ProcessErrorException.InnerError>
                      {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = responseMessage.StatusCode.ToString(),
                                       ErrorMessage = JsonConvert.SerializeObject(responseMessage.ToString()),
                                       ErrorType = ""
                                   }
                      }
                      );
            }

            return result;
        }

        public async Task<TWaspOutput> GenericInvokerAsync<TWaspOutput, TDTOOutput>(HttpRequestElement requestElement)
        {
            Log.Debug($"GenericInvokerAsync Request : {JsonConvert.SerializeObject(requestElement)}");

            TWaspOutput result = default(TWaspOutput);

            var responseMessage = await httpClientRepository.ProcessRequestAsync(requestElement);

            if (responseMessage.IsSuccessStatusCode)
            {
                var response = await responseMessage.Content.ReadAsAsync<TDTOOutput>();
                result = mapper.Map<TWaspOutput>(response);

                Log.Debug($"GenericInvokerAsync Response : {JsonConvert.SerializeObject(result)}");
            }
            else
            {
                Log.Debug($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(responseMessage)}");

                return await HandleUnsuccessfulHttpStatusResponse(requestElement, result, responseMessage);
            }

            return result;
        }

        public async Task<TWaspOutput> GenericInvokerAsync<TWaspInput, TWaspOutput, TDTOInput, TDTOOutput>(HttpRequestElement requestElement)
        {
            TWaspOutput result = default(TWaspOutput);

            var responseMessage = await httpClientRepository.ProcessRequestAsync(requestElement);

            if (responseMessage.IsSuccessStatusCode)
            {
                var response = responseMessage.Content.ReadAsAsync<TDTOOutput>();
                result = mapper.Map<TWaspOutput>(await response);
            }
            else
            {
                Log.Debug($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(responseMessage)}");

                return await HandleUnsuccessfulHttpStatusResponse(requestElement, result, responseMessage);
            }

            return result;
        }

        private async Task<TWaspOutput> HandleUnsuccessfulHttpStatusResponse<TWaspOutput>(HttpRequestElement requestElement, TWaspOutput result, HttpResponseMessage responseMessage)
        {
            StandardMessage errorMessage = null;

            if (responseMessage.StatusCode == System.Net.HttpStatusCode.NotFound && (requestElement.Options != null && requestElement.Options.HandleList404Response))
            {
                try
                {
                    errorMessage = responseMessage.Content.ReadAsAsync<StandardMessage>().Result;
                    if (errorMessage == null)
                    {
                        Type primary = typeof(TWaspOutput);
                        return (TWaspOutput)Activator.CreateInstance(primary);
                    }
                    else
                    {
                        throw new ProcessErrorException(
                     errorMessage.ErrorMessage,
                     errorMessage.ErrorMessage, new List<ProcessErrorException.InnerError>
                     {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = responseMessage.StatusCode.ToString(),
                                       ErrorMessage = JsonConvert.SerializeObject(errorMessage),
                                       ErrorType = ""
                                   }
                     }
                     );
                    }
                }
                catch
                {
                    Type primary = typeof(TWaspOutput);
                    return (TWaspOutput)Activator.CreateInstance(primary);

                }
            }
            else if (responseMessage.StatusCode == System.Net.HttpStatusCode.BadRequest)
            {
                object badRequestResponse = await responseMessage.Content.ReadAsAsync<object>();
                throw new ProcessErrorException(
                      StatusCodes.Status400BadRequest.ToString(),
                      StatusCodes.Status400BadRequest.ToString(), new List<ProcessErrorException.InnerError>
                      {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = JsonConvert.SerializeObject(badRequestResponse),
                                       ErrorType = ""
                                   }
                      }
                      );
            }
            else if (responseMessage.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new ProcessErrorException(
                      StatusCodes.Status500InternalServerError.ToString(),
                      StatusCodes.Status500InternalServerError.ToString(), new List<ProcessErrorException.InnerError>
                      {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status500InternalServerError.ToString(),
                                       ErrorMessage = JsonConvert.SerializeObject(responseMessage.ToString()),
                                       ErrorType = ""
                                   }
                      }
                      );
            }

            throw new ProcessErrorException(
                    responseMessage.StatusCode.ToString(),
                     responseMessage.StatusCode.ToString(), new List<ProcessErrorException.InnerError>
                     {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = responseMessage.StatusCode.ToString(),
                                       ErrorMessage = JsonConvert.SerializeObject(responseMessage.ToString()),
                                       ErrorType = ""
                                   }
                     }
                     );
        }
    }
}

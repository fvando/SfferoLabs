﻿using AutoMapper;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.CommonLibrary.Exceptions.Models;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SAP.Extern.WCF.Documents.Service.Reference.Tst;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Dynamic;
using System.Linq;
using System.Reflection;
using System.ServiceModel;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Documents
{
    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.IDocumentsRepository" />
    public class DocumentsRepository : IDocumentsRepository
    {
        private readonly IMapper _mapper;
        private readonly IConfiguration _configuration;
        private readonly Z_FSCD_DOCUMENTOS_POST_WS referenceInterfaceDocuments;


        protected readonly TimeSpan OpenTimeout;
        protected readonly TimeSpan CloseTimeout;
        protected readonly TimeSpan SendTimeout;
        protected readonly TimeSpan ReceiveTimeout;
        protected readonly TimeSpan RestTimeout;

        protected readonly Stopwatch stopwatch;
        

        public DocumentsRepository(IConfiguration configuration, IMapper mapperReference) : this(configuration, mapperReference, null)
        { }

        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentsRepository"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        /// <param name="mapperReference">The mapper reference.</param>
        /// <param name="referenceInterface">The reference interface.</param>
        public DocumentsRepository(IConfiguration configuration, IMapper mapperReference, Z_FSCD_DOCUMENTOS_POST_WS referenceInterface)
        {
            _mapper = mapperReference;
            _configuration = configuration;

            if (referenceInterface != null)
            {
                this.referenceInterfaceDocuments = referenceInterface;
                return;
            }

            #region Binding

            // read timeouts from config
            OpenTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:OpenTimeout");
            CloseTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:CloseTimeout");
            SendTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:SendTimeout");
            ReceiveTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:ReceiveTimeout");
            RestTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:RestTimeout");

            var binding = new BasicHttpBinding
            {
                MaxReceivedMessageSize = int.MaxValue,
                MaxBufferPoolSize = int.MaxValue,
                MaxBufferSize = int.MaxValue,
                AllowCookies = true,
                TransferMode = TransferMode.Buffered,
                SendTimeout = SendTimeout,
                ReceiveTimeout = ReceiveTimeout,
                CloseTimeout = CloseTimeout,
                OpenTimeout = OpenTimeout
            };

            binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;

            // read enpoint address
            var address = new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTDocuments").Value);

            // check if it is http or https
            if (string.Compare(address.Uri.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            }
            else
            {
                binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            }

            #endregion

            var client = new Z_FSCD_DOCUMENTOS_POST_WSClient(binding, new EndpointAddress(_configuration.GetSection("EnvironmentEndPointSAP").GetSection("EPTSTDocuments").Value));
            client.ClientCredentials.UserName.UserName = _configuration.GetSection("BasicAuth").GetSection("UserNameAuth").Value;
            client.ClientCredentials.UserName.Password = _configuration.GetSection("BasicAuth").GetSection("PasswordAuth").Value;

            referenceInterfaceDocuments = client;

            stopwatch = new Stopwatch();

        }

        public IConfiguration Configuration => _configuration;

        /// <summary>
        /// Gets the ws client.
        /// </summary>
        /// <param name="requestDocument"></param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">
        /// Not Found
        /// or
        /// Not Found
        /// or
        /// Request Timeout
        /// or
        /// NullReference
        /// or
        /// Fault
        /// </exception>
        /// <exception cref="ProcessErrorException.InnerError">
        /// </exception>
        public async Task<INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWsResponse1> GetDocumentsAsync(INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWs requestDocument)
        {
            try
            {
                //convert to IN structure
                var requestToSourceStructure = _mapper.Map<SAP.Extern.WCF.Documents.Service.Reference.Tst.ZFscdDocumentosPostWs>(requestDocument);

                var request = new SAP.Extern.WCF.Documents.Service.Reference.Tst.ZFscdDocumentosPostWsRequest {
                    ZFscdDocumentosPostWs = requestToSourceStructure
                };

                stopwatch.Restart();
                //Para os objetos em SAP, o recurso de serilog não consegue resolver a serialização. Neste caso, permanecerá desta forma.
                Log.Information("ZFscdDocumentosPostWsAsync SAP Request {request}", JsonConvert.SerializeObject(request));
                var SapResponse = await referenceInterfaceDocuments.ZFscdDocumentosPostWsAsync(request);
                stopwatch.Stop();
                Log.Information("ZFscdDocumentosPostWsAsync SAP Response: {SapResponse} in {Elapsed:000} ms", JsonConvert.SerializeObject(SapResponse), stopwatch.ElapsedMilliseconds);

                //convert to OUT structure
                return _mapper.Map<INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWsResponse1>(SapResponse);

            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }
    }
}

﻿using Microsoft.AspNetCore.Builder;

namespace INS.PT.WebAPI.Middleware
{
    /// <summary>
    /// RequestResponseLoggingMiddlewareExtensions
    /// </summary>
    public static class RequestResponseLoggingMiddlewareExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="app"></param>
        /// <returns></returns>
        public static IApplicationBuilder UseLogXRequestResponde(this IApplicationBuilder app)
        {
            app.UseMiddleware<RequestResponseLoggingMiddleware>();
            return app;
        }
    }
}

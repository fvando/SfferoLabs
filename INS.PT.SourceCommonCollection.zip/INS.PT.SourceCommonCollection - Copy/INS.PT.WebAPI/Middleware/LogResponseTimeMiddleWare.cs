﻿// Copyright Ageas 2019 © - Integration Team

using Microsoft.AspNetCore.Http;
using System.Diagnostics;
using System.Threading.Tasks;
using System;
using Serilog;

namespace INS.PT.WebAPI.Middleware
{
    /// <summary>
    /// LogResponseTimeMiddleWare
    /// </summary>
    public class LogResponseTimeMiddleWare
    {
        private readonly RequestDelegate _next;

        /// <summary>
        /// LogResponseTimeMiddleWare
        /// </summary>
        /// <param name="next"></param>
        public LogResponseTimeMiddleWare(RequestDelegate next)
        {
            _next = next;
        }

        /// <summary>
        /// Invoke
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InvokeAsync(HttpContext context)
        {
            Log.Debug("***Begin CALL***");

            var stopwatch = new Stopwatch();
            stopwatch.Start();

            // execute the rest of the pipeline
            await _next(context);

            stopwatch.Stop(); //stop measuring

            // write log 
            Log.Debug("Response in {Elapsed:000} ms", stopwatch.ElapsedMilliseconds);

            Log.Debug("***End CALL***");
        }
    }
}

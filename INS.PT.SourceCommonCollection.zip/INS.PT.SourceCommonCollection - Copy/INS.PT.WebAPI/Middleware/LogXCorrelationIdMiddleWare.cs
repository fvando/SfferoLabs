﻿// Copyright Ageas 2019 © - Integration Team

using System;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using System.Linq;
using Serilog.Context;

namespace INS.PT.WebAPI.Middleware
{
    /// <summary>
    /// LogXCorrelationIdMiddleWare
    /// </summary>
    public class LogXCorrelationIdMiddleWare
    {
        private readonly RequestDelegate _next;

        /// <summary>
        /// LogXCorrelationIdMiddleWare
        /// </summary>
        /// <param name="next"></param>
        public LogXCorrelationIdMiddleWare(RequestDelegate next)
        {
            _next = next;
        }

        /// <summary>
        /// Invoke
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InvokeAsync(HttpContext context)
        {
            context.Request.Headers.TryGetValue("XCorrelationId", out var correlationIds);

            var correlationId = correlationIds.FirstOrDefault() ?? Guid.NewGuid().ToString("D", System.Globalization.CultureInfo.InvariantCulture);

            CorrelationContext.SetCorrelationId(correlationId);

            // Add XCorrelationId to HttpContext
            context.Items.Add("XCorrelationId", correlationId);
            LogContext.PushProperty("XCorrelationId", correlationId.ToString());

            // execute the rest of the pipeline
            await _next.Invoke(context);

        }
    }
}

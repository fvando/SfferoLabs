﻿

// Copyright Ageas 2019 © - Integration Team

using System;
using System.Threading;

namespace INS.PT.WebAPI.Middleware
{
    /// <summary>
    /// CorrelationContext
    /// </summary>
    public static class CorrelationContext
    {
        private static readonly AsyncLocal<string> _correlationId = new AsyncLocal<string>();
        /// <summary>
        /// SetCorrelationId
        /// </summary>
        /// <param name="correlationId"></param>
        public static void SetCorrelationId(string correlationId)
        {

            if (string.IsNullOrWhiteSpace(correlationId))
            {
                throw new ArgumentException("Correlation id cannot be null or empty", nameof(correlationId));
            }

            if (!string.IsNullOrWhiteSpace(_correlationId.Value))
            {
                throw new InvalidOperationException("Correlation id is already set");
            }

            _correlationId.Value = correlationId;
        }

        /// <summary>
        /// GetCorrelationId
        /// </summary>
        /// <returns></returns>
        public static string CorrelationId => _correlationId.Value;
    }
}

﻿using System;
using System.IO;
using System.Reflection;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Charged;
using INS.PT.WebAPI.Cancel;
using INS.PT.WebAPI.Documents;
using INS.PT.WebAPI.Repository;
using INS.PT.WebAPI.WebReceiptList;
using INS.PT.WebAPI.GreenLetter;
using INS.PT.WebAPI.Mandate;
using INS.PT.WebAPI.Policy;
using INS.PT.WebAPI.Middleware;
using Ins.PT.WebAPI;
using Microsoft.AspNetCore.Http;
using INS.PT.WebAPI.Helper;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using INS.PT.WebAPI.Filters;
using INS.PT.WebAPI.Mapping;
using INS.PT.WebAPI.Entity;
using Serilog;
using INS.PT.WebAPI.Policy.AIA;
using INS.PT.WebAPI.IbanCheck;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// Startup
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Startup"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        /// <summary>
        /// Gets the configuration.
        /// </summary>
        /// <value>
        /// The configuration.
        /// </value>
        public IConfiguration Configuration { get; }

        /// <summary>
        /// Configures the services.
        /// </summary>
        /// <param name="services">The services.</param>
        public void ConfigureServices(IServiceCollection services)
        {
            // Check health services, Necessary core 2.2
            services.AddHealthChecks();

            // Serilog configuration
            var configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile(Configuration["Logging:LogConfigFile"])
                .Build();

            // Start Serilog
            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(configuration)
                .CreateLogger();

            services.AddMvc()
                .AddNewtonsoftJson(options => {
                    options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
                    options.SerializerSettings.ContractResolver = new Newtonsoft.Json.Serialization.DefaultContractResolver();
                })
                .AddXmlSerializerFormatters()
                .AddXmlDataContractSerializerFormatters()
                .AddJsonOptions(jsonOptions => {
                    jsonOptions.JsonSerializerOptions.PropertyNamingPolicy = null;
                    jsonOptions.JsonSerializerOptions.IgnoreNullValues = true;
                });

            services.AddHttpContextAccessor();


            services.AddScoped(sp => sp.GetRequiredService<IHttpContextAccessor>().HttpContext.Request);
            services.AddScoped(sp => sp.GetRequiredService<IHttpContextAccessor>().HttpContext.Response);
            services.AddScoped<ICancellationsRepository, CancellationsRepository>();
            services.AddScoped<IChargesRepository, ChargesRepository>();
            services.AddScoped<IDocumentsRepository, DocumentsRepository>();
            services.AddScoped<IProvisionsRepository, ProvisionsRepository>();
            services.AddScoped<IWebReceiptListingRepository, WebReceiptListingRepository>();
            services.AddScoped<IGreenLettersRepository, GreenLettersRepository>();
            services.AddScoped<IMandatesRepository, MandatesRepository>();
            services.AddScoped<IPoliciesRepository, PoliciesRepository>();
            services.AddScoped<IEntitiesRepository, EntitiesRepository>();
            services.AddScoped<IStatesRepository, StatesRepository>();
            services.AddScoped<IRepositoryInvoker, RepositoryInvoker>();
            services.AddScoped<IHttpClientRepository, HttpClientRepository>();
            services.AddScoped<IReceiptRepository, ReceiptRepository>();
            services.AddScoped<IPoliza, PolizaRepository>();
            services.AddScoped<IPolicyAiaRepository, PolicyAiaRepository>();
            services.AddScoped<IIbanRepository, IbanRepository>();
            services.AddScoped<IProposalAiaRepository, ProposalAiaRepository>();


            //Singleton
            services.AddSingleton<ITransformationData, TransformationData>();
            services.AddSingleton<IConfiguration>(Configuration);
            services.AddSingleton<IDbconnectioncs>(new Dbconnectioncs(Configuration));

            // Get Application Settings
            services.Configure<ApplicationSettings>(Configuration.GetSection("ApplicationSettings"));

            var config = new AutoMapper.MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new AutoMapperProfileConfiguration());
                cfg.AddProfile(new ReceiptCoverageProfile());
            });

            var mapper = config.CreateMapper();
            services.AddSingleton(mapper);


            // Register the Swagger generator, defining one or more Swagger documents
            services.AddSwaggerGen(swagger =>
            {
                
                swagger.SwaggerDoc(SwaggerConfiguration.DocNameV1,
                     new OpenApiInfo
                     {
                         Title = SwaggerConfiguration.DocInfoTitle,
                         Version = SwaggerConfiguration.DocInfoVersion,
                         Description = SwaggerConfiguration.DocInfoDescription
                     }
                );

                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                swagger.IncludeXmlComments(xmlPath); //comments and sample
                swagger.DescribeAllEnumsAsStrings();

                /* 3.1 XML Example */
                swagger.SchemaFilter<ArraySchemaFilter>();
            });

            services.AddHttpClient();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.        
        /// <summary>
        /// Configures the specified application.
        /// </summary>
        /// <param name="app">The application.</param>
        /// <param name="env">The env.</param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            //Middleware correlationID
            app.UseLogXCorrelationId();
            app.UseLogXRequestResponde();

            if (env.IsDevelopment())
            {
                // When the app runs in the Development environment:
                //   Use the Developer Exception Page to report app runtime errors.
                //   Use the Database Error Page to report database runtime errors.
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // When the app doesn't run in the Development environment:
                //   Enable the Exception Handler Middleware to catch exceptions
                //     thrown in the following middlewares.
                //   Use the HTTP Strict Transport Security Protocol (HSTS)
                //     Middleware.
                app.UseHsts();
            }

            // Force Authentication
            app.UseAuthentication();

            // Use HTTPS Redirection Middleware to redirect HTTP requests to HTTPS.
            app.UseHttpsRedirection();
 

            // Use Cookie Policy Middleware to conform to EU General Data 
            // Protection Regulation (GDPR) regulations.
            app.UseCookiePolicy();


            //migrate 2.2 to 3.1
            app.UseAuthorization();
            app.UseSwagger();

           
            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.), specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint(SwaggerConfiguration.EndpointUrl, SwaggerConfiguration.EndpointDescription);
            });

       

            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

        }
    }
}

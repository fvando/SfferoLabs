﻿
using AutoMapper;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.DTO;
using System.Xml.Linq;
using System.Xml.XPath;

namespace INS.PT.WebAPI.Mapping
{
    public class ReceiptCoverageProfile : Profile
    {
        public ReceiptCoverageProfile()
        {
            //Mapping Error
            CreateMap<XDocument, ErrorOracle>()
             .ForMember(dest => dest.CanonicalTypeError,
              opts => opts.MapFrom(src => src.XPathSelectElements("ERRORS/TYP_CANO_ERROR")));

            CreateMap<XElement, CanonicalTypeError>()
            .ForMember(dest => dest.ErrorType,
                         opts => opts.MapFrom(src => src.XPathSelectElement("ERROR_TYPE").Value))
            .ForMember(dest => dest.ErrorCode,
                         opts => opts.MapFrom(src => src.XPathSelectElement("CODE").Value))
            .ForMember(dest => dest.ErrorTxt,
                         opts => opts.MapFrom(src => src.XPathSelectElement("MESSAGE").Value));


            //Mappings
            CreateMap<XDocument, ReceiptCoverage>()
                .ForMember(dest => dest.CanonicalReceiptType,
                    opts => opts.MapFrom(src => src.XPathSelectElements("RECEIPTS/TYP_CANO_RECEIPT")));

            CreateMap<XElement, CanonicalReceiptType>()
             .ForMember(dest => dest.ReceiptId, opts => opts.MapFrom(src => src.XPathSelectElement("RECEIPT_ID").Value))
             .ForMember(dest => dest.EmissionDate, opts => opts.MapFrom(src => src.XPathSelectElement("DATA_EMISSAO").Value))
             .ForMember(dest => dest.EffectiveDate, opts => opts.MapFrom(src => src.XPathSelectElement("DATA_EFEITO").Value))
             .ForMember(dest => dest.DueDate, opts => opts.MapFrom(src => src.XPathSelectElement("DATA_VENCIMENTO").Value))
             .ForMember(dest => dest.PayDateLimit, opts => opts.MapFrom(src => src.XPathSelectElement("DATA_LIMIT_PAG").Value))
             .ForMember(dest => dest.StatusId, opts => opts.MapFrom(src => src.XPathSelectElement("STATUS_ID").Value))
             .ForMember(dest => dest.Status, opts => opts.MapFrom(src => src.XPathSelectElement("STATUS").Value))
             .ForMember(dest => dest.ReceiptTypeId, opts => opts.MapFrom(src => src.XPathSelectElement("RECEIPT_TYPE_ID").Value))
             .ForMember(dest => dest.ReceiptType, opts => opts.MapFrom(src => src.XPathSelectElement("RECEIPT_TYPE").Value))

             .ForMember(dest => dest.ReceiptValue, opts => opts.MapFrom(src => src.XPathSelectElement("VALOR_RECIBO")))

             .ForMember(dest => dest.CoveragePerValue, opts => opts.MapFrom(src => src.XPathSelectElement("VALOR_POR_COBERTURA")));


            CreateMap<XElement, CoveragePerValue>()
             .ForPath(dest => dest.TypeCanonicalCoverageValue, opts => opts.MapFrom(src => src.XPathSelectElements("TYP_CANO_COVER_VALUE")));

            //Valor TypCanoCoverValue
            CreateMap<XElement, TypeCanonicalCoverageValue>()
           .ForMember(dest => dest.CoverDescription, opts => opts.MapFrom(src => src.XPathSelectElement("COVER_DESCRIPTION").Value))
           .ForMember(dest => dest.Value, opts => opts.MapFrom(src => src.XPathSelectElement("VALUE").Value));

            CreateMap<XElement, ReceiptValue>()
             .ForMember(dest => dest.Amount, opts => opts.MapFrom(src => src.XPathSelectElement("AMOUNT").Value))
             .ForMember(dest => dest.Currency, opts => opts.MapFrom(src => src.XPathSelectElement("CURRENCY").Value));


        }


    }
}

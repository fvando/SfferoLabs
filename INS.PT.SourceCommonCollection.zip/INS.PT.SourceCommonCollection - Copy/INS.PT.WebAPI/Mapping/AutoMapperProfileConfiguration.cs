﻿using AutoMapper;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.Domain;
using INS.PT.WebAPI.Model.Domain.CanonicalCoverage;
using INS.PT.WebAPI.Model.DTO;
using INS.PT.WebAPI.Model.Partners;
using Serilog;
using System;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// AutoMapperProfileConfiguration
    /// </summary>
    /// <seealso cref="AutoMapper.Profile" />
    public class AutoMapperProfileConfiguration : Profile
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AutoMapperProfileConfiguration"/> class.
        /// </summary>
        public AutoMapperProfileConfiguration()
        {
            try
            {

                #region ReceiptCoverage
                //ReceiptCoverage
                CreateMap<CanonicalTypeError, CanonicalTypeError>();
                CreateMap<CanonicalTypeError, CanonicalTypeError>();
                CreateMap<TypeCanonicalCoverageValue, TypeCanonicalCoverageValue>();
                CreateMap<CoveragePerValue, CoveragePerValue>();
                CreateMap<ReceiptValue, ReceiptValue>();
                CreateMap<CanonicalReceiptType, CanonicalReceiptType>();
                CreateMap<ReceiptCoverage, ReceiptCoverage>();
                CreateMap<ReceiptCoverageOutput, ReceiptCoverageOutPutDTO>().ReverseMap();
                #endregion

                #region GenericInvoker
                //GlobalEntityOutput
                CreateMap<ExtraPropertyElement, ExtraPropertyElementDTO>().ReverseMap();
                CreateMap<GlobalEntityElementsRamo, GlobalEntityElementsRamoDTO>().ReverseMap();
                CreateMap<GlobalEntityOutput, GlobalEntityOutputDTO>().ReverseMap();
                CreateMap<HamedPolicy, HamedPolicyDTO>().ReverseMap();
                CreateMap<HamedPolicyListOutput, HamedPolicyListOutputDTO>().ReverseMap();
                CreateMap<HamedReceipt, HamedReceiptDTO>().ReverseMap();
                CreateMap<HamedReceiptListOutput, HamedReceiptsListOutputDTO>().ReverseMap();
                #endregion

                #region WebReceipt
                //Request - WebReceiptList/List
                CreateMap<INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdRecibosListarWs, SAP.Extern.WCF.WebReciptListing.Service.Reference.Tst.ZFscdRecibosListarWs>();
                //Response
                //Note                        /* Segundo definição do negócio os status serão exibidos por interface email Igor Barreto 15/Out/2019  */
                //status = "C"
                //statustxt = "COBRADO"
                //(P) - ABERTO/PENDENTE
                //(C) - COBRADO
                //(A) - ANULADO
                CreateMap<SAP.Extern.WCF.WebReciptListing.Service.Reference.Tst.ZFscdRecibosListarWsResponse1, INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdRecibosListarWsResponse1>();
                CreateMap<SAP.Extern.WCF.WebReciptListing.Service.Reference.Tst.ZFscdRecibosListarWsResponse, INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdRecibosListarWsResponse>();
                CreateMap<SAP.Extern.WCF.WebReciptListing.Service.Reference.Tst.ZfscdCodigosErroLinha, ErrorElement>();
                CreateMap<SAP.Extern.WCF.WebReciptListing.Service.Reference.Tst.ZfscdRecibosWorkLinha, INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZfscdRecibosWorkLinha>();
                #endregion

                #region ProvisionWebAccount
                ////Provision - Query
                CreateMap<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWs, SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcConsultarWs>();
                //Response
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcConsultarWsResponse1, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWsResponse1>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcConsultarWsResponse, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWsResponse>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdPcDetailLinha, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcDetailLinha>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdPcHeaderLinha, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcHeaderLinha>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdPcReceiptsDel, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcReceiptsDel>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdPcPaymentsValReturn, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcPaymentsValReturn>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroProvisionLinhaConsultar>();

                ////Provision - Charged
                CreateMap<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha, SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdPcRecibosLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWs, SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcCobrarWs>();
                //Response
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcCobrarWsResponse1, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWsResponse1>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcCobrarWsResponse, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWsResponse>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdCodigosErroRecibos, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroRecibos>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroProvisionRecibosLinha>();

                ////Provision - Liquidate
                CreateMap<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcPaymentsValues, SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdPcPaymentsValues>();
                CreateMap<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcLiquidarWs, SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcLiquidarWs>();
                //Response
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcLiquidarWsResponse1, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcLiquidarWsResponse1>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcLiquidarWsResponse, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcLiquidarWsResponse>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroProvisionLinhaLiquidar>();

                ////Provision - List
                CreateMap<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcListarWs, SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcListarWs>();
                //Get ReferenceData - Branch Description
                //Response
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcListarWsResponse1, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcListarWsResponse1>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcListarWsResponse, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcListarWsResponse>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroProvisionLinhaListar>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdPcPaymentsValReturn, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcPaymentsValReturn>();
                //doesn't reverse because theres is an field BranchDescription
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdPcHeaderLinha, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcHeaderLinha>();

                ////Provision - Validate
                CreateMap<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha, SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdPcRecibosLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcValidarWs, SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcValidarWs>();
                //Response
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcValidarWsResponse1, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcValidarWsResponse1>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcValidarWsResponse, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcValidarWsResponse>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdCodigosErroRecibos, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroRecibos>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroProvisionRecibosLinha>();


                ////Provision - KPI
                CreateMap<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcBrokerLinha, SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdPcBrokerLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWs, SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcIndicadoresWs>();
                //Response
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcIndicadoresWsResponse1, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWsResponse1>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcIndicadoresWsResponse, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWsResponse>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdPcBrokerLinha, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcBrokerLinha>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroProvisionLinhaIndicadores>();


                ////Provision - ContaEfetiva
                CreateMap<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcContaEfetivaWs, SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcContaEfetivaWs>();
                //Response
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcContaEfetivaWsResponse1, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcContaEfetivaWsResponse1>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcContaEfetivaWsResponse, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcContaEfetivaWsResponse>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcContaEfetivaWsResponse, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcContaEfetivaWsResponse>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.Zcd2GrouptTotalsS, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.Zcd2GrouptTotalsS>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdPcRecibosLinha, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroProvisionLinhaContaEfetiva>();

                //AggregatesReceipts
                CreateMap<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcRecibosAgregadoWs, SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcRecibosAgregadoWs>();
                //Response
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcRecibosAgregadoWsResponse1, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcRecibosAgregadoWsResponse1>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcRecibosAgregadoWsResponse, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcRecibosAgregadoWsResponse>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdPcRecibosAgregados, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosAgregados>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroProvisionLinhaAggregateReceipts>();


                ////Provision - Eliminate
                CreateMap<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcEliminarWs, SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcEliminarWs>();
                //Response
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcEliminarWsResponse1, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcEliminarWsResponse1>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZFscdPcEliminarWsResponse, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcEliminarWsResponse>();
                CreateMap<SAP.Extern.WCF.ProvisionWebAccount.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroProvisionLinhaEliminar>();

                #endregion

                #region ChargesCharged

                //Charged
                CreateMap<INS.PT.WebAPI.Model.Partners.Charged.ZfscdCodigosErroLinhaCobrados, SAP.Extern.WCF.Charged.Service.Reference.Tst.ZfscdCodigosErroLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradosLinha, SAP.Extern.WCF.Charged.Service.Reference.Tst.ZfscdCobradosLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradoLinha, SAP.Extern.WCF.Charged.Service.Reference.Tst.ZfscdCobradoLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Charged.ZFscdCobradosPostWs, SAP.Extern.WCF.Charged.Service.Reference.Tst.ZFscdCobradosPostWs>();

                //Response
                CreateMap<SAP.Extern.WCF.Charged.Service.Reference.Tst.ZFscdCobradosPostWsResponse1, INS.PT.WebAPI.Model.Partners.Charged.ZFscdCobradosPostWsResponse1>();
                CreateMap<SAP.Extern.WCF.Charged.Service.Reference.Tst.ZFscdCobradosPostWsResponse, INS.PT.WebAPI.Model.Partners.Charged.ZFscdCobradosPostWsResponse>();
                CreateMap<SAP.Extern.WCF.Charged.Service.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.Charged.ZfscdCodigosErroLinhaCobrados>();
                CreateMap<SAP.Extern.WCF.Charged.Service.Reference.Tst.ZfscdCobradosLinha, INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradosLinha>();
                CreateMap<SAP.Extern.WCF.Charged.Service.Reference.Tst.ZfscdCobradoLinha, INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradoLinha>();

                #endregion

                #region Police
                //Police - generic Mediators, Policy, Claim
                CreateMap<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectObjectRisk, SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdInsobjectObjectRisk>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador, SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdInsobjectMediador>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario, SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdInsobjectBeneficiario>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaApolice, SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdCodigosErroLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha, SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdInsobjectLinha>();
                
                CreateMap<INS.PT.WebAPI.Model.Partners.Policy.ZfscdMediadoresLinha, SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdMediadoresLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWs, SAP.Extern.WCF.Policy.Service.Reference.Tst.ZFscdMediadoresPostWs>();
                //Response
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZFscdMediadoresPostWsResponse1, INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWsResponse1>();
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZFscdMediadoresPostWsResponse, INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWsResponse>();
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaMediador>();
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdMediadoresLinha, INS.PT.WebAPI.Model.Partners.Policy.ZfscdMediadoresLinha>();
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdInsobjectLinha, INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>();
                //Generic
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdInsobjectObjectRisk, INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectObjectRisk>();
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdInsobjectMediador, INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>();
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdInsobjectBeneficiario, INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>();
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaApolice>();

                //Police - Mediators
                CreateMap<INS.PT.WebAPI.Model.Partners.Policy.ZfscdApolicesLinha, SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdApolicesLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha, SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdInsobjectLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWs, SAP.Extern.WCF.Policy.Service.Reference.Tst.ZFscdApolicesPostWs>();

                //Response
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZFscdApolicesPostWsResponse1, INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWsResponse1>();
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZFscdApolicesPostWsResponse, INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWsResponse>();
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaApolice>();
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdApolicesLinha, INS.PT.WebAPI.Model.Partners.Policy.ZfscdApolicesLinha>();
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdInsobjectLinha, INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>();

                //Claim
                CreateMap<INS.PT.WebAPI.Model.Partners.Policy.ZfscdSinistrosLinha, SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdSinistrosLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha, SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdInsobjectLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWs, SAP.Extern.WCF.Policy.Service.Reference.Tst.ZFscdSinistrosPostWs>();

                //Response
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZFscdSinistrosPostWsResponse1, INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWsResponse1>();
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZFscdSinistrosPostWsResponse, INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWsResponse>();
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaSinistro>();
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdSinistrosLinha, INS.PT.WebAPI.Model.Partners.Policy.ZfscdSinistrosLinha>();
                CreateMap<SAP.Extern.WCF.Policy.Service.Reference.Tst.ZfscdInsobjectLinha, INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>();

                #endregion

                #region Mandates
                //Mandate
                CreateMap<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandato, SAP.Extern.WCF.Mandate.Service.Reference.Tst.ZfscdCodigosErroLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha, SAP.Extern.WCF.Mandate.Service.Reference.Tst.ZfscdMandatoLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatosLinha, SAP.Extern.WCF.Mandate.Service.Reference.Tst.ZfscdMandatosLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWs, SAP.Extern.WCF.Mandate.Service.Reference.Tst.ZFscdMandatosPostWs>();
                
                //Response
                CreateMap<SAP.Extern.WCF.Mandate.Service.Reference.Tst.ZFscdMandatosPostWsResponse1, INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWsResponse1>();
                CreateMap<SAP.Extern.WCF.Mandate.Service.Reference.Tst.ZFscdMandatosPostWsResponse, INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWsResponse>();
                CreateMap<SAP.Extern.WCF.Mandate.Service.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandato>();
                CreateMap<SAP.Extern.WCF.Mandate.Service.Reference.Tst.ZfscdMandatosLinha, INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatosLinha>();
                CreateMap<SAP.Extern.WCF.Mandate.Service.Reference.Tst.ZfscdMandatoLinha, INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha>();


                #endregion

                #region Documents

                //Documents
                CreateMap<INS.PT.WebAPI.Model.Partners.Documents.ZfscdCodigosErroLinhaDocumentos, SAP.Extern.WCF.Documents.Service.Reference.Tst.ZfscdCodigosErroLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress, SAP.Extern.WCF.Documents.Service.Reference.Tst.ZfscdDocumentoAddress>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoDetalheLinha, SAP.Extern.WCF.Documents.Service.Reference.Tst.ZfscdDocumentoDetalheLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoCabecalho, SAP.Extern.WCF.Documents.Service.Reference.Tst.ZfscdDocumentoCabecalho>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoLinha, SAP.Extern.WCF.Documents.Service.Reference.Tst.ZfscdDocumentoLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentosLinha, SAP.Extern.WCF.Documents.Service.Reference.Tst.ZfscdDocumentosLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWs, SAP.Extern.WCF.Documents.Service.Reference.Tst.ZFscdDocumentosPostWs>();
                
                //Response
                CreateMap<SAP.Extern.WCF.Documents.Service.Reference.Tst.ZFscdDocumentosPostWsResponse1, INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWsResponse1>();
                CreateMap<SAP.Extern.WCF.Documents.Service.Reference.Tst.ZFscdDocumentosPostWsResponse, INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWsResponse>();
                CreateMap<SAP.Extern.WCF.Documents.Service.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.Documents.ZfscdCodigosErroLinhaDocumentos>();
                CreateMap<SAP.Extern.WCF.Documents.Service.Reference.Tst.ZfscdDocumentosLinha, INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentosLinha>();
                CreateMap<SAP.Extern.WCF.Documents.Service.Reference.Tst.ZfscdDocumentoLinha, INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoLinha>();
                CreateMap<SAP.Extern.WCF.Documents.Service.Reference.Tst.ZfscdDocumentoDetalheLinha, INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoDetalheLinha>();
                CreateMap<SAP.Extern.WCF.Documents.Service.Reference.Tst.ZfscdDocumentoAddress, INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress>();
                CreateMap<SAP.Extern.WCF.Documents.Service.Reference.Tst.ZfscdDocumentoCabecalho, INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoCabecalho>();
                
                #endregion

                #region GreenLatter
                //Greeletter
                CreateMap<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCodigosErroLinhaCartaVerde, SAP.Extern.WCF.GreenLetter.Service.Reference.Tst.ZfscdCodigosErroLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartasverdeLinha, SAP.Extern.WCF.GreenLetter.Service.Reference.Tst.ZfscdCartasverdeLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha, SAP.Extern.WCF.GreenLetter.Service.Reference.Tst.ZfscdCartaverdeLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWs, SAP.Extern.WCF.GreenLetter.Service.Reference.Tst.ZFscdCartasverdePostWs>();

                //Response
                CreateMap<SAP.Extern.WCF.GreenLetter.Service.Reference.Tst.ZFscdCartasverdePostWsResponse1, INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWsResponse1>();
                CreateMap<SAP.Extern.WCF.GreenLetter.Service.Reference.Tst.ZFscdCartasverdePostWsResponse, INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWsResponse>();
                CreateMap<SAP.Extern.WCF.GreenLetter.Service.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCodigosErroLinhaCartaVerde>();
                CreateMap<SAP.Extern.WCF.GreenLetter.Service.Reference.Tst.ZfscdCartasverdeLinha, INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartasverdeLinha>();
                CreateMap<SAP.Extern.WCF.GreenLetter.Service.Reference.Tst.ZfscdCartaverdeLinha, INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha>();

                #endregion

                #region Cancellations

                //Request - Cancellations - Generic Policy, Receipt
                CreateMap<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoPolicy, SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZfscdAnuladoPolicy>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoReceipt, SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZfscdAnuladoReceipt>();
                CreateMap<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha, SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZfscdAnuladosLinha>();

                //Cancellations - Policy
                CreateMap<INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWs, SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZFscdAnularApolicesPostWs>();

                //Response
                CreateMap<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZFscdAnularApolicesPostWsResponse1, INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWsResponse1>();
                CreateMap<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZFscdAnularApolicesPostWsResponse, INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWsResponse>();
                CreateMap<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaAnularApolice>();

                //Response - Cancellations - Generic Policy, Receipt
                CreateMap<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZfscdAnuladosLinha, INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha>();
                CreateMap<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZfscdAnuladoPolicy, INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoPolicy>();
                CreateMap<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZfscdAnuladoReceipt, INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoReceipt>();

                //Request - Cancellations - Receipt
                CreateMap<INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWs, SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZFscdAnularRecibosPostWs>();

                //Response
                CreateMap<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZFscdAnularRecibosPostWsResponse1, INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWsResponse1>();
                CreateMap<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZFscdAnularRecibosPostWsResponse, INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWsResponse>();
                CreateMap<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaAnularRecibo>();

                //Response - Cancellations - Generic Policy, Receipt
                CreateMap<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZfscdAnuladosLinha, INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha>();
                CreateMap<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZfscdAnuladoPolicy, INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoPolicy>();
                CreateMap<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZfscdAnuladoReceipt, INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoReceipt>();

                //Request - Cancellations - Dates
                CreateMap<INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularDatasPostWs, SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZFscdAnularDatasPostWs>();

                //Response
                CreateMap<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZFscdAnularDatasPostWsResponse1, INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularDatasPostWsResponse1>();
                CreateMap<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZFscdAnularDatasPostWsResponse, INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularDatasPostWsResponse>();
                CreateMap<SAP.Extern.WCF.Cancel.Service.Reference.Tst.ZfscdCodigosErroLinha, INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaAnularDatas>();

                #endregion

                #region PoliceAIA
                //Police - generic Mediators, Policy, Claim

                CreateMap<INS.PT.WebAPI.Model.Partners.PolicyAIA.ZfscdReceiptsData, SAP.Extern.WCF.Police.AIA.Service.Reference.Tst.ZfscdReceiptsData>();
                CreateMap<INS.PT.WebAPI.Model.Partners.PolicyAIA.ZfscdReceiptsCharge, SAP.Extern.WCF.Police.AIA.Service.Reference.Tst.ZfscdReceiptsCharge>();
                CreateMap<INS.PT.WebAPI.Model.Partners.PolicyAIA.ZfscdAiaGetPolicysWs, SAP.Extern.WCF.Police.AIA.Service.Reference.Tst.ZFscdAiaGetApolicesWs>()
                   .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.PolicyAIA.ZfscdCodigosErroLinha, SAP.Extern.WCF.Police.AIA.Service.Reference.Tst.ZfscdCodigosErroLinha>();
                CreateMap<INS.PT.WebAPI.Model.Partners.PolicyAIA.ZfscdAiaGetPolicysRequest, SAP.Extern.WCF.Police.AIA.Service.Reference.Tst.ZFscdAiaGetApolicesWsRequest>();
                CreateMap<INS.PT.WebAPI.Model.Partners.PolicyAIA.ZFscdAiaGetApolicesWsResponse1, SAP.Extern.WCF.Police.AIA.Service.Reference.Tst.ZFscdAiaGetApolicesWsResponse1>();
                CreateMap<INS.PT.WebAPI.Model.Partners.PolicyAIA.ZFscdAiaGetApolicesWsResponse, SAP.Extern.WCF.Police.AIA.Service.Reference.Tst.ZFscdAiaGetApolicesWsResponse>();

                #endregion

                #region IbanValidation
                CreateMap<INS.PT.WebAPI.Model.Partners.Iban.ZFscdCheckIbanWs, SAP.Extern.WCF.IbanValidation.Service.Reference.Tst.ZFscdCheckIbanWs>()
                   .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.Iban.ZFscdCheckIbanWsRequest, SAP.Extern.WCF.IbanValidation.Service.Reference.Tst.ZFscdCheckIbanWsRequest>();
                CreateMap<SAP.Extern.WCF.IbanValidation.Service.Reference.Tst.ZFscdCheckIbanWsResponse1, INS.PT.WebAPI.Model.Partners.Iban.ZFscdCheckIbanWsResponse1>();
                CreateMap<SAP.Extern.WCF.IbanValidation.Service.Reference.Tst.ZFscdCheckIbanWsResponse, INS.PT.WebAPI.Model.Partners.Iban.ZFscdCheckIbanWsResponse>();
                CreateMap<SAP.Extern.WCF.IbanValidation.Service.Reference.Tst.ZfscdCodigosErroLinha, ErrorElement>();

                #endregion

                #region ProposalAIA
                //Police - generic Mediators, Policy, Claim

                CreateMap<INS.PT.WebAPI.Model.Partners.Get.ProposalAIA.ZeaiaProposal, SAP.Extern.WCF.Get.Proposal.AIA.Service.Reference.ZeaiaProposal>()
                    .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.Get.ProposalAIA.ZageasLifeGetProposalWs, SAP.Extern.WCF.Get.Proposal.AIA.Service.Reference.ZageasLifeGetProposalWs>()
                    .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.Get.ProposalAIA.ZfscdCodigosErroGetLinhaAia, SAP.Extern.WCF.Get.Proposal.AIA.Service.Reference.ZfscdCodigosErroLinhaAia>()
                    .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.Get.ProposalAIA.ZageasLifeGetProposalWsRequest, SAP.Extern.WCF.Get.Proposal.AIA.Service.Reference.ZageasLifeGetProposalWsRequest>()
                    .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.Get.ProposalAIA.ZageasLifeGetProposalWsResponse1, SAP.Extern.WCF.Get.Proposal.AIA.Service.Reference.ZageasLifeGetProposalWsResponse1>()
                    .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.Get.ProposalAIA.ZageasLifeGetProposalWsResponse, SAP.Extern.WCF.Get.Proposal.AIA.Service.Reference.ZageasLifeGetProposalWsResponse>()
                    .ReverseMap();

                #endregion

                #region ProposalUpdAIA
                //Police - generic Mediators, Policy, Claim

                CreateMap<INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWs, SAP.Extern.WCF.Upd.Proposal.AIA.Service.Reference.ZageasLifeUpdProposalWs>()
                    .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWsRequest, SAP.Extern.WCF.Upd.Proposal.AIA.Service.Reference.ZageasLifeUpdProposalWsRequest>()
                    .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZfscdCodigosErroLinhaUpdProposal, SAP.Extern.WCF.Upd.Proposal.AIA.Service.Reference.ZfscdCodigosErroLinhaAia>()
                    .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWsResponse1, SAP.Extern.WCF.Upd.Proposal.AIA.Service.Reference.ZageasLifeUpdProposalWsResponse1>()
                    .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWsResponse,SAP.Extern.WCF.Upd.Proposal.AIA.Service.Reference.ZageasLifeUpdProposalWsResponse>()
                    .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZeupdProposal,SAP.Extern.WCF.Upd.Proposal.AIA.Service.Reference.ZeupdProposal>()
                    .ReverseMap();

                #endregion


                #region ProposalBeforeChargeAIA
                //Police - generic Mediators, Policy, Claim

                CreateMap<INS.PT.WebAPI.Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWs, SAP.Extern.WCF.BeforeCharge.Proposal.AIA.Service.Reference.ZageasLifeGetBeforeChargeWs>()
                    .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsRequest, SAP.Extern.WCF.BeforeCharge.Proposal.AIA.Service.Reference.ZageasLifeGetBeforeChargeWsRequest>()
                    .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.BeforeCharge.ProposalAIA.ZfscdCodigosErroLinhaBeforeChargeAia, SAP.Extern.WCF.BeforeCharge.Proposal.AIA.Service.Reference.ZfscdCodigosErroLinhaAia>()
                    .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse1, SAP.Extern.WCF.BeforeCharge.Proposal.AIA.Service.Reference.ZageasLifeGetBeforeChargeWsResponse1>()
                    .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse, SAP.Extern.WCF.BeforeCharge.Proposal.AIA.Service.Reference.ZageasLifeGetBeforeChargeWsResponse>()
                    .ReverseMap();
                CreateMap<INS.PT.WebAPI.Model.Partners.BeforeCharge.ProposalAIA.ZegetProposal, SAP.Extern.WCF.BeforeCharge.Proposal.AIA.Service.Reference.ZegetProposal>()
                    .ReverseMap();

                #endregion

            }
            catch (Exception e)
            {
                Log.Error($"{e}");
                throw;
            }
        }
    }
}

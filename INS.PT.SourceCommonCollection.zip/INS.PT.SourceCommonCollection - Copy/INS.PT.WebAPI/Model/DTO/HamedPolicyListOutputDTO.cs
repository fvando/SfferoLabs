﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class HamedPolicyListOutputDTO
    {
        /// <summary>
        /// 
        /// </summary>
        public HamedPolicyListOutputDTO()
        {
            this.Result = new List<HamedPolicyDTO>();
        }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("data")]
        public List<HamedPolicyDTO> Result { get; set; }



    }
    /// <summary>
    /// 
    /// </summary>
    public class HamedPolicyDTO
    {
        /// <summary>
        /// 
        /// </summary>
        public HamedPolicyDTO()
        {

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="item"></param>
        public HamedPolicyDTO(string item)
        {
            this.Number = item;
        }


        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("policyNumber")]
        public string Number { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("productId")]
        public string ProductCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("protocolId")]
        public string ProtocolCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("company")]
        public string Company { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("source")]
        public string Source { get; set; }
        
    }
}

﻿
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace INS.PT.WebAPI.Model.DTO
{
    public class ReceiptValue
    {
        [JsonProperty("amount")]
        public string Amount { get; set; }

        [JsonProperty("currency")]
        public string Currency { get; set; }
    }

    public class TypeCanonicalCoverageValue
    {
        [JsonProperty("coverDescription")]
        public string CoverDescription { get; set; }

        [JsonProperty("value")]
        public string Value { get; set; }
    }

    public class CoveragePerValue
    {
        [JsonProperty("typeCanonicalCoverageValue")]
        public List<TypeCanonicalCoverageValue> TypeCanonicalCoverageValue { get; set; }
    }

    public class CanonicalReceiptType
    {
        [JsonProperty("receiptId")]
        public string ReceiptId { get; set; }

        [JsonProperty("emissionDate")]
        public string EmissionDate { get; set; }

        [JsonProperty("effectiveDate")]
        public string EffectiveDate { get; set; }

        [JsonProperty("dueDate")]
        public string DueDate { get; set; }

        [JsonProperty("chargedDate")]
        public string ChargedDate { get; set; }

        [JsonProperty("movementDate")]
        public string MovementDate { get; set; }

        [JsonProperty("payDateLimit")]
        public string PayDateLimit { get; set; }

        [JsonProperty("statusId")]
        public string StatusId { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("receiptTypeId")]
        public string ReceiptTypeId { get; set; }

        [JsonProperty("receiptType")]
        public string ReceiptType { get; set; }

        [JsonProperty("receiptValue")]
        public ReceiptValue ReceiptValue { get; set; }

        [JsonProperty("coveragePerValue")]
        public CoveragePerValue CoveragePerValue { get; set; }
    }

    public class ReceiptCoverage
    {
        [JsonProperty("canonicalReceiptType")]
        public List<CanonicalReceiptType> CanonicalReceiptType { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model.DTO
{
    public class ReceiptInPutDTO
    {
    }
}

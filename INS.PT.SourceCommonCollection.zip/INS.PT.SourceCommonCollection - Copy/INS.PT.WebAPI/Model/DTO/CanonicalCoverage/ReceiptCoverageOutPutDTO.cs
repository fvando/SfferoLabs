﻿
using INS.PT.WebAPI.Interface;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Model.DTO
{
    public class ReceiptCoverageOutPutDTO : IOutErrors<ReceiptCoverage>
    {
        public ReceiptCoverage Data { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public List<CanonicalTypeError> Errors { get; set; }
    }
}

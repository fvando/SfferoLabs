﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class HamedReceiptsListOutputDTO
    {
        /// <summary>
        /// 
        /// </summary>
        public HamedReceiptsListOutputDTO()
        {
            this.Result = new List<HamedReceiptDTO>();
        }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("data")]
        public List<HamedReceiptDTO> Result { get; set; }



    }
    /// <summary>
    /// 
    /// </summary>
    public class HamedReceiptDTO
    {
        /// <summary>
        /// 
        /// </summary>
        public HamedReceiptDTO()
        {

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="item"></param>
        public HamedReceiptDTO(string item)
        {
            this.ReceiptNumber = item;
        }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("typeNatureIdOriginal")]
        public string TypeNatureIdOriginal { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("receiptNumber")]
        public string ReceiptNumber { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("situationIdOriginal")]
        public string SituationIdOriginal { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("startDate")]
        public string StartDate { get; set; }

    }
    public class HamedInput
    {
        /// <summary>
        /// 
        /// </summary>
        public HamedInput()
        {

        }


        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("policyNumber")]
        public string PolicyNumber { get; set; }
    }
}

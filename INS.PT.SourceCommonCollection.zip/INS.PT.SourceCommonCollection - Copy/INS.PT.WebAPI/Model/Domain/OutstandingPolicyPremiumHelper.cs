﻿using INS.PT.WebAPI.Model.Partners.WebReceiptListing;
using PayrecService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model.Domain
{
    public class OutstandingPolicyPremiumHelper
    {
        /// <summary>
        /// 
        /// </summary>
        public ZFscdRecibosListarWsResponse WebreceiptList { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public premiumReceiptListBSGResponse PremiumreceipList { get; set; }

    }
}

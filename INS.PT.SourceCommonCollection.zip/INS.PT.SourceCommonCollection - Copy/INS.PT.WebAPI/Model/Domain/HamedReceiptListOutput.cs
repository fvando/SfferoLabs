﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class HamedReceiptListOutput
    {
        /// <summary>
        /// 
        /// </summary>
        public HamedReceiptListOutput()
        {
            this.Result = new List<HamedReceipt>();
        }



        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("result")]
        public List<HamedReceipt> Result { get; set; }



    }
    /// <summary>
    /// 
    /// </summary>
    public class HamedReceipt
    {
        /// <summary>
        /// 
        /// </summary>
        public HamedReceipt()
        {

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="item"></param>
        public HamedReceipt(string item)
        {
            this.ReceiptNumber = item;
        }


        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("typeNatureIdOriginal")]
        public string TypeNatureIdOriginal { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("receiptNumber")]
        public string ReceiptNumber { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("situationIdOriginal")]
        public string SituationIdOriginal { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("startDate")]
        public string StartDate { get; set; }

    }
}

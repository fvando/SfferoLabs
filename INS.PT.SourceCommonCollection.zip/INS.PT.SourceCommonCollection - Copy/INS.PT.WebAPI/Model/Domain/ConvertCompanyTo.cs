﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model.Domain
{
    public class ConvertCompanyTo
    {
        //key1 -> company
        //key2 -> isAIA
        //value -> PaxusCode
        //Value2 -> companyCode
        static List<DomainMock> lstMock = new List<DomainMock>
        {
            new DomainMock { Key1 = "ageas",            Key2="false",     Value=""  ,Value2="AGS"},
            new DomainMock { Key1 = "ageasVida",        Key2="false",     Value=""  ,Value2="AGV"},
            new DomainMock { Key1 = "ageasNaoVida",     Key2="false",     Value=""  ,Value2="AGS"},
            new DomainMock { Key1 = "ageasPensoes",     Key2="false",     Value=""  ,Value2="",  },
            new DomainMock { Key1 = "medis",            Key2="false",     Value="M" ,Value2="CPS"},
            new DomainMock { Key1 = "seguroDirecto",    Key2="false",     Value=""  ,Value2="SGD"},
            new DomainMock { Key1 = "ocidental",        Key2="false",     Value="1" ,Value2="OCS"},
            new DomainMock { Key1 = "ocidental",        Key2="true",      Value="2" ,Value2="OCS"},
            new DomainMock { Key1 = "ocidentalVida",    Key2="false",     Value="2" ,Value2="OCV"},
            new DomainMock { Key1 = "ocidentalNaoVida", Key2="false",     Value="1" ,Value2="OCS"},

        };


        /// <summary>
        /// 
        /// </summary>
        /// <param name="company"></param>
        /// <returns></returns>
        static public string geCompanyCode(string company)
        {
            if (!string.IsNullOrEmpty(company))
            {
                var obj = lstMock.FirstOrDefault(x => x.Key1.ToUpper() == company.ToUpper());

                if (obj != null)
                    return obj.Value2;
            }
            return null;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="company"></param>
        /// <returns></returns>
        static public string gePaxusCode(string company, bool isAIA)
        {
            var obj = lstMock.FirstOrDefault(x => x.Key1.ToUpper() == company.ToUpper() && x.Key2.ToUpper() == isAIA.ToString().ToUpper());

            if (obj != null)
                return obj.Value;

            return null;
        }

    }
}

﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class HamedPolicyListOutput
    {
        /// <summary>
        /// 
        /// </summary>
        public HamedPolicyListOutput()
        {
            this.Result = new List<HamedPolicy>();
        }



        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("result")]
        public List<HamedPolicy> Result { get; set; }



    }
    /// <summary>
    /// 
    /// </summary>
    public class HamedPolicy
    {
        /// <summary>
        /// 
        /// </summary>
        public HamedPolicy()
        {

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="item"></param>
        public HamedPolicy(string item)
        {
            this.Number = item;
        }


        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("number")]
        public string Number { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("productCode")]
        public string ProductCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("protocolCode")]
        public string ProtocolCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("Company")]
        public string Company { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("source")]
        public string Source { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string CompanyCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public bool? claimRegularitzaion { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string PaxusCode { get; set; }
    }
}

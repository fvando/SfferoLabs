﻿using Newtonsoft.Json;

namespace INS.PT.WebAPI.Model.Domain
{
    public class CoverageElements
    {

        [JsonProperty(PropertyName = "description")]
        public string description { get; set; }

        [JsonProperty(PropertyName = "value")]
        public string value { get; set; }

    }
}
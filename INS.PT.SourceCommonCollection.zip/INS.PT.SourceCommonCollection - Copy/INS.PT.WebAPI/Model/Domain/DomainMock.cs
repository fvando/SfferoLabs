﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model.Domain
{
    /// <summary>
    /// 
    /// </summary>
    public class DomainMock
    {
        /// <summary>
        /// 
        /// </summary>
        public string Key1 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Key2 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Key3 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Key4 { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Value { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string Value2 { get; set; }
    }
}

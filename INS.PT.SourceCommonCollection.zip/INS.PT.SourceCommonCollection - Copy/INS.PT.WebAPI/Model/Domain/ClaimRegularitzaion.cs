﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model.Domain
{
    public class ClaimRegularitzaion
    {
        //key1 -> Modalidade
        //key2 -> Protocolo
        static List<DomainMock> lstMock = new List<DomainMock>
        {
            new DomainMock { Key1 = "A07",              Key2="41",   Value="true"},
            new DomainMock { Key1 = "A61",              Key2="RGFC", Value="true"},
            new DomainMock { Key1 = "",                 Key2="RGFC", Value="true"},
            new DomainMock { Key1 = "A72",              Key2="",     Value="true"},
            new DomainMock { Key1 = "A73",              Key2="",     Value="true"},
            new DomainMock { Key1 = "A45",              Key2="",     Value="true"},
            new DomainMock { Key1 = "A44",              Key2="BVAC", Value="true"},
            new DomainMock { Key1 = "",                 Key2="BVAL", Value="true"},
            new DomainMock { Key1 = "",                 Key2="BVCM", Value="true"},
            new DomainMock { Key1 = "",                 Key2="BVKM", Value="true"},

        };


        /// <summary>
        /// 
        /// </summary>
        /// <param name="productId"></param>
        /// <param name="protocolId"></param>
        /// <returns></returns>
        static public bool getValue(string productId, string protocolId)
        {
            var obj = lstMock.FirstOrDefault(x => x.Key1.ToUpper() == productId.ToUpper() && x.Key2.ToUpper() == protocolId.ToUpper());

            if (obj != null)
                return true;

            return false;
        }
    }
}

﻿using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model.DTO;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model.Domain.CanonicalCoverage
{
    public class ReceiptCoverageOutput : IOutErrors<ReceiptCoverage>
    {
        public ReceiptCoverage Data { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public List<CanonicalTypeError> Errors { get; set; }
    }
}

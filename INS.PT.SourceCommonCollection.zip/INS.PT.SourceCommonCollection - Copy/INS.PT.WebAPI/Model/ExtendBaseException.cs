﻿using INS.PT.CommonLibrary.Exceptions;
using INS.PT.CommonLibrary.Exceptions.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.Threading.Tasks;
 

namespace INS.PT.WebAPI.Model
{
    /// <summary>
    /// Error during process execution.
    /// </summary>
    [Serializable]
    public class ExtendStandardMessage: StandardMessage
    {
        public object Response { get; set; }

        public ExtendStandardMessage(string errorCode, string errorMessage, HttpStatusCode statusCode, IEnumerable<InnerError> innerErrors, object response) : base(errorCode, errorMessage, statusCode, innerErrors)
        {
            Response = response;
        }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
            {
                base.GetObjectData(info, context);
                throw new ArgumentNullException(nameof(info));
            }

            info.AddValue(nameof(ErrorCode), ErrorCode);
            info.AddValue(nameof(ErrorMessage), ErrorMessage);
            info.AddValue(nameof(InnerErrors), InnerErrors);
            info.AddValue(nameof(Response), Response);
            info.AddValue(nameof(StackTrace), StackTrace);

        }
    }
}

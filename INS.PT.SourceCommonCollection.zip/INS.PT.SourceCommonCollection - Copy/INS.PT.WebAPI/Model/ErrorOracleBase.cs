﻿
using Newtonsoft.Json;
using System;

namespace INS.PT.WebAPI.Model
{
    public class ErrorOracleBase
    {
        public ErrorOracleBase Errors { get; set; }
    }
}

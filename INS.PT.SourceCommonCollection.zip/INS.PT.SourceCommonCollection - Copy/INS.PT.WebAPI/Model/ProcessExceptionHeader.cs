﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Model
{
    [Serializable]
    public class ProcessErrorExceptionHeader
    {
        [Serializable]
        public class InnerError
        {

            public string ErrorType { get; set; }

            public string ErrorCode { get; set; }

            public string ErrorMessage { get; set; }

        }

        private string ErrorType { get; set; }

        private string ErrorCode { get; set; }

        private string ErrorMessage { get; set; }

        [JsonProperty(PropertyName = "Errors")]
        public IEnumerable<InnerError> Errors { get; set; }

        public ProcessErrorExceptionHeader()
        {
        }


        public ProcessErrorExceptionHeader(string message) : this(message, (Exception)null)
        {
        }


        public ProcessErrorExceptionHeader(string code, string message) : this(message, (Exception)null)
        {
            ErrorCode = code;
        }


        public ProcessErrorExceptionHeader(string message, Exception innerException) 
        {
            ErrorMessage = message;
        }


        protected ProcessErrorExceptionHeader(SerializationInfo info, StreamingContext context) 
        {
        }


        public ProcessErrorExceptionHeader(string errorCode, string errorMessage, IEnumerable<InnerError> innerErrors) : this(errorCode, errorMessage)
        {
            Errors = innerErrors ?? throw new ArgumentNullException(nameof(innerErrors));
        }
        

        public override string ToString()
        {
            return $"Execution returned error {ErrorCode} with message: {ErrorMessage}";
        }

    }

}




﻿
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI_Source
{
    
    public partial class TestIn
    {

        public string Interface;
        public string Origem;
        public string Transact;
        [JsonProperty(PropertyName = "DateTest")]
        public string Date;
        public string Hour;
        public string Online;
        public string ItemsTotality;
        public tttt t;
    }

    [DataContract(Name = "Product")]
    public class tttt
    {

        public string Interface;
        public string Origem;
        public string Transact;
        [JsonProperty(PropertyName = "DateTest")]
        public string Date;
        public string Hour;
        public string Online;
        public string ItemsTotality;
    }

    public partial class TestOut
    {

        public string Interface;
        public string Origem;
        public string Transact;
        [JsonProperty(PropertyName = "DateTestOut")]
        public string Date;
        public string Hour;
        public string Online;
        public string ItemsTotality;
    }

}

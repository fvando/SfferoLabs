﻿namespace INS.PT.WebAPI.Model
{
    public class CanonicalTypeError
    {
        public string ErrorType { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorTxt { get; set; }
    }

}

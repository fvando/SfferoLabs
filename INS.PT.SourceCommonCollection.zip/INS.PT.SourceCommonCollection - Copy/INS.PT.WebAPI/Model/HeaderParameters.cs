﻿using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
 using System.ComponentModel.DataAnnotations;
using System.Data;
 

namespace INS.PT.WebAPI.Model
{
    public class HeaderParameters
    {
        private const int HeaderParametersLength = 20;

        /// <summary>
        /// Company id.
        /// </summary>
        [Required]
        [MaxLength(HeaderParametersLength)]
        [FromHeader]
        public string IdCompany { get; set; }

        /// <summary>
        /// Source id.
        /// </summary>
        [Required]
        [MaxLength(HeaderParametersLength)]
        [FromHeader]
        public string IdSource { get; set; }

        /// <summary>
        /// Method to add default header parameters to oracle package.
        /// </summary>
        /// <param name="oracleDynamicParameters">collection of oracle parameters to add</param>
        internal void AddToParameters(OracleDynamicParameters oracleDynamicParameters, bool newParametersNames = false)
        {
            oracleDynamicParameters.Add("P_COMPANHIA",
                OracleDbType.Varchar2, direction: ParameterDirection.Input, value: IdCompany);
            oracleDynamicParameters.Add("P_ORIGEM",
                OracleDbType.Varchar2, direction: ParameterDirection.Input, value: IdSource);
        }
    }
}

﻿using System.Collections.Generic;

namespace INS.PT.WebAPI.Model
{
    public class ErrorOracle
    {
        public List<CanonicalTypeError> CanonicalTypeError { get; set; }
    }

}

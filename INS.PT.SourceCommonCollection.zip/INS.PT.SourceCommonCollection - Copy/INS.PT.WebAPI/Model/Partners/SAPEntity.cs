﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model.Partners.Entity
{
    public partial class ZFscdParceirosPostWs
    {

        private ZfscdParceirosLinha partnersField;

        public ZfscdParceirosLinha Partners
        {
            get
            {
                return this.partnersField;
            }
            set
            {
                this.partnersField = value;
            }
        }
    }

    public partial class ZfscdParceirosLinha
    {

        private string interfaceField;

        private string originalSystemField;

        private string transactionField;

        private string systemDateField;

        private string systemTimeField;

        private string onlineField;

        private string itemsTotalField;

        private ZfscdParceiroLinha[] partnerField;

        public string Interface
        {
            get
            {
                return this.interfaceField;
            }
            set
            {
                this.interfaceField = value;
            }
        }

        public string OriginalSystem
        {
            get
            {
                return this.originalSystemField;
            }
            set
            {
                this.originalSystemField = value;
            }
        }

        public string Transaction
        {
            get
            {
                return this.transactionField;
            }
            set
            {
                this.transactionField = value;
            }
        }

        public string SystemDate
        {
            get
            {
                return this.systemDateField;
            }
            set
            {
                this.systemDateField = value;
            }
        }

        public string SystemTime
        {
            get
            {
                return this.systemTimeField;
            }
            set
            {
                this.systemTimeField = value;
            }
        }

        public string Online
        {
            get
            {
                return this.onlineField;
            }
            set
            {
                this.onlineField = value;
            }
        }

        public string ItemsTotal
        {
            get
            {
                return this.itemsTotalField;
            }
            set
            {
                this.itemsTotalField = value;
            }
        }

        public ZfscdParceiroLinha[] Partner
        {
            get
            {
                return this.partnerField;
            }
            set
            {
                this.partnerField = value;
            }
        }
    }

    public partial class ZfscdParceiroLinha
    {

        private string entityTypeField;

        private string companyCodeField;

        private string networkField;

        private string masterOriginField;

        private string partnerExternalSystemField;

        private string taxTypeField;

        private string taxNumberField;

        private string formKeyTitleField;

        private string firstNameField;

        private string middleNameField;

        private string middleName2Field;

        private string lastNameField;

        private string birthDateField;

        private string sexField;

        private string maritalStatusField;

        private string nationalityField;

        private string commTypeField;

        private ZfscdParceiroMorada[] addressesField;

        private ZfscdParceiroTelefone[] phonesField;

        private ZfscdParceiroEmail[] mailsField;

        private ZfscdParceiroIban[] banksField;

        private ZfscdCodigosErroLinha[] errorsField;

        public string EntityType
        {
            get
            {
                return this.entityTypeField;
            }
            set
            {
                this.entityTypeField = value;
            }
        }

        public string CompanyCode
        {
            get
            {
                return this.companyCodeField;
            }
            set
            {
                this.companyCodeField = value;
            }
        }

        public string Network
        {
            get
            {
                return this.networkField;
            }
            set
            {
                this.networkField = value;
            }
        }

        public string MasterOrigin
        {
            get
            {
                return this.masterOriginField;
            }
            set
            {
                this.masterOriginField = value;
            }
        }

        public string PartnerExternalSystem
        {
            get
            {
                return this.partnerExternalSystemField;
            }
            set
            {
                this.partnerExternalSystemField = value;
            }
        }

        public string TaxType
        {
            get
            {
                return this.taxTypeField;
            }
            set
            {
                this.taxTypeField = value;
            }
        }

        public string TaxNumber
        {
            get
            {
                return this.taxNumberField;
            }
            set
            {
                this.taxNumberField = value;
            }
        }

        public string FormKeyTitle
        {
            get
            {
                return this.formKeyTitleField;
            }
            set
            {
                this.formKeyTitleField = value;
            }
        }

        public string FirstName
        {
            get
            {
                return this.firstNameField;
            }
            set
            {
                this.firstNameField = value;
            }
        }

        public string MiddleName
        {
            get
            {
                return this.middleNameField;
            }
            set
            {
                this.middleNameField = value;
            }
        }

        public string MiddleName2
        {
            get
            {
                return this.middleName2Field;
            }
            set
            {
                this.middleName2Field = value;
            }
        }

        public string LastName
        {
            get
            {
                return this.lastNameField;
            }
            set
            {
                this.lastNameField = value;
            }
        }

        public string BirthDate
        {
            get
            {
                return this.birthDateField;
            }
            set
            {
                this.birthDateField = value;
            }
        }

        public string Sex
        {
            get
            {
                return this.sexField;
            }
            set
            {
                this.sexField = value;
            }
        }

        public string MaritalStatus
        {
            get
            {
                return this.maritalStatusField;
            }
            set
            {
                this.maritalStatusField = value;
            }
        }

        public string Nationality
        {
            get
            {
                return this.nationalityField;
            }
            set
            {
                this.nationalityField = value;
            }
        }

        public string CommType
        {
            get
            {
                return this.commTypeField;
            }
            set
            {
                this.commTypeField = value;
            }
        }

        public ZfscdParceiroMorada[] Addresses
        {
            get
            {
                return this.addressesField;
            }
            set
            {
                this.addressesField = value;
            }
        }

        public ZfscdParceiroTelefone[] Phones
        {
            get
            {
                return this.phonesField;
            }
            set
            {
                this.phonesField = value;
            }
        }

        public ZfscdParceiroEmail[] Mails
        {
            get
            {
                return this.mailsField;
            }
            set
            {
                this.mailsField = value;
            }
        }

        public ZfscdParceiroIban[] Banks
        {
            get
            {
                return this.banksField;
            }
            set
            {
                this.banksField = value;
            }
        }

        public ZfscdCodigosErroLinha[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }
    }

    public partial class ZfscdParceiroMorada
    {

        private string addressTypeField;

        private string extAddressNumberField;

        private string addressNotesField;

        private string streetField;

        private string strSuppl1Field;

        private string strSuppl2Field;

        private string strSuppl3Field;

        private string houseNumberField;

        private string homeCityField;

        private string postCodeField;

        private string cityField;

        private string countryField;

        public string AddressType
        {
            get
            {
                return this.addressTypeField;
            }
            set
            {
                this.addressTypeField = value;
            }
        }

        public string ExtAddressNumber
        {
            get
            {
                return this.extAddressNumberField;
            }
            set
            {
                this.extAddressNumberField = value;
            }
        }

        public string AddressNotes
        {
            get
            {
                return this.addressNotesField;
            }
            set
            {
                this.addressNotesField = value;
            }
        }

        public string Street
        {
            get
            {
                return this.streetField;
            }
            set
            {
                this.streetField = value;
            }
        }

        public string StrSuppl1
        {
            get
            {
                return this.strSuppl1Field;
            }
            set
            {
                this.strSuppl1Field = value;
            }
        }

        public string StrSuppl2
        {
            get
            {
                return this.strSuppl2Field;
            }
            set
            {
                this.strSuppl2Field = value;
            }
        }

        public string StrSuppl3
        {
            get
            {
                return this.strSuppl3Field;
            }
            set
            {
                this.strSuppl3Field = value;
            }
        }

        public string HouseNumber
        {
            get
            {
                return this.houseNumberField;
            }
            set
            {
                this.houseNumberField = value;
            }
        }

        public string HomeCity
        {
            get
            {
                return this.homeCityField;
            }
            set
            {
                this.homeCityField = value;
            }
        }

        public string PostCode
        {
            get
            {
                return this.postCodeField;
            }
            set
            {
                this.postCodeField = value;
            }
        }

        public string City
        {
            get
            {
                return this.cityField;
            }
            set
            {
                this.cityField = value;
            }
        }

        public string Country
        {
            get
            {
                return this.countryField;
            }
            set
            {
                this.countryField = value;
            }
        }
    }

    public class ZfscdCodigosErroLinha
    {

        private string errorCodeField;

        private string errorCodeTxtField;

        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }

    public partial class ZfscdParceiroIban
    {

        private string ibanField;

        public string Iban
        {
            get
            {
                return this.ibanField;
            }
            set
            {
                this.ibanField = value;
            }
        }
    }

    public partial class ZfscdParceiroEmail
    {

        private string emailField;

        public string Email
        {
            get
            {
                return this.emailField;
            }
            set
            {
                this.emailField = value;
            }
        }
    }

    public partial class ZfscdParceiroTelefone
    {

        private string countryField;

        private string telephoneField;

        private string telDefaultField;

        public string Country
        {
            get
            {
                return this.countryField;
            }
            set
            {
                this.countryField = value;
            }
        }

        public string Telephone
        {
            get
            {
                return this.telephoneField;
            }
            set
            {
                this.telephoneField = value;
            }
        }

        public string TelDefault
        {
            get
            {
                return this.telDefaultField;
            }
            set
            {
                this.telDefaultField = value;
            }
        }
    }

    public partial class ZFscdParceirosPostWsResponse
    {

        private ZfscdCodigosErroLinha[] errorsField;

        private ZfscdParceirosLinha partnersField;

        public ZfscdCodigosErroLinha[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }

        public ZfscdParceirosLinha Partners
        {
            get
            {
                return this.partnersField;
            }
            set
            {
                this.partnersField = value;
            }
        }
    }

    public partial class ZFscdParceirosPostWsRequest
    {

        public INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWs ZFscdParceirosPostWs;

        public ZFscdParceirosPostWsRequest()
        {
        }

        public ZFscdParceirosPostWsRequest(INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWs ZFscdParceirosPostWs)
        {
            this.ZFscdParceirosPostWs = ZFscdParceirosPostWs;
        }
    }

    public partial class ZFscdParceirosPostWsResponse1
    {

        public INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWsResponse ZFscdParceirosPostWsResponse { get; set; }

        public ZFscdParceirosPostWsResponse1()
        {
        }

        public ZFscdParceirosPostWsResponse1(INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWsResponse ZFscdParceirosPostWsResponse)
        {
            this.ZFscdParceirosPostWsResponse = ZFscdParceirosPostWsResponse;
        }
    }

    public partial class ZFscdParceiroNotificacaoWs
    {

        private string masterOriginField;

        private string partnerExternalSystemField;

        public string MasterOrigin
        {
            get
            {
                return this.masterOriginField;
            }
            set
            {
                this.masterOriginField = value;
            }
        }

        public string PartnerExternalSystem
        {
            get
            {
                return this.partnerExternalSystemField;
            }
            set
            {
                this.partnerExternalSystemField = value;
            }
        }
    }

    public partial class ZFscdParceiroNotificacaoWsResponse
    {

        private ZfscdCodigosErroLinha[] errorsField;

        public ZfscdCodigosErroLinha[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }
    }

    public partial class ZFscdParceiroNotificacaoWsRequest
    {

        public INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceiroNotificacaoWs ZFscdParceiroNotificacaoWs;

        public ZFscdParceiroNotificacaoWsRequest()
        {
        }

        public ZFscdParceiroNotificacaoWsRequest(INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceiroNotificacaoWs ZFscdParceiroNotificacaoWs)
        {
            this.ZFscdParceiroNotificacaoWs = ZFscdParceiroNotificacaoWs;
        }
    }

    public partial class ZFscdParceiroNotificacaoWsResponse1
    {

        public INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceiroNotificacaoWsResponse ZFscdParceiroNotificacaoWsResponse { get; set; }

        public ZFscdParceiroNotificacaoWsResponse1()
        {
        }

        public ZFscdParceiroNotificacaoWsResponse1(INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceiroNotificacaoWsResponse ZFscdParceiroNotificacaoWsResponse)
        {
            this.ZFscdParceiroNotificacaoWsResponse = ZFscdParceiroNotificacaoWsResponse;
        }
    }
}

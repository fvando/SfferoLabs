﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Helper.Validations;

namespace INS.PT.WebAPI.Model.Partners.Documents
{
    public partial class ZFscdDocumentosPostWs
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdDocumentosLinha Documents { get; set; }
    }

    
    public partial class ZfscdDocumentosLinha
    {
        /// <summary>
        /// Gets or sets the interface.
        /// </summary>
        /// <value>
        /// The interface.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Interface { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the original system.
        /// </summary>
        /// <value>
        /// The original system.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string OriginalSystem { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the transaction.
        /// </summary>
        /// <value>
        /// The transaction.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Transaction { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the system date.
        /// </summary>
        /// <value>
        /// The system date.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SystemDate { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the system time.
        /// </summary>
        /// <value>
        /// The system time.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SystemTime { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the online.
        /// </summary>
        /// <value>
        /// The online.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Online { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the items total.
        /// </summary>
        /// <value>
        /// The items total.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ItemsTotal { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the document.
        /// </summary>
        /// <value>
        /// The document.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdDocumentoLinha[] Document { get; set; }
    }

    
    public partial class ZfscdDocumentoLinha
    {

        /// <summary>
        /// Gets or sets the company code.
        /// </summary>
        /// <value>
        /// The company code.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyCode { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the reference document number.
        /// </summary>
        /// <value>
        /// The reference document number.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceDocumentNumber { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the header.
        /// </summary>
        /// <value>
        /// The header.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdDocumentoCabecalho Header { get; set; }

        /// <summary>
        /// Gets or sets the details.
        /// </summary>
        /// <value>
        /// The details.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdDocumentoDetalheLinha[] Details { get; set; }

        /// <summary>
        /// Gets or sets the address.
        /// </summary>
        /// <value>
        /// The address.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdDocumentoAddress Address { get; set; }

        /// <summary>
        /// Gets or sets the errors.
        /// </summary>
        /// <value>
        /// The errors.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdCodigosErroLinhaDocumentos[] Errors { get; set; }
    }

    
    public partial class ZfscdDocumentoCabecalho
    {

        /// <summary>
        /// Gets or sets the type of the receipt.
        /// </summary>
        /// <value>
        /// The type of the receipt.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReceiptType { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the collected.
        /// </summary>
        /// <value>
        /// The collected.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Collected { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets our reference.
        /// </summary>
        /// <value>
        /// Our reference.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string OurReference { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the offert code.
        /// </summary>
        /// <value>
        /// The offert code.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string OffertCode { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the network.
        /// </summary>
        /// <value>
        /// The network.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Network { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the business area.
        /// </summary>
        /// <value>
        /// The business area.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessArea { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the type of the document.
        /// </summary>
        /// <value>
        /// The type of the document.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DocumentType { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the billing period from.
        /// </summary>
        /// <value>
        /// The billing period from.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BillingPeriodFrom { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the billing period to.
        /// </summary>
        /// <value>
        /// The billing period to.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BillingPeriodTo { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the document date.
        /// </summary>
        /// <value>
        /// The document date.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DocumentDate { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the net due date.
        /// </summary>
        /// <value>
        /// The net due date.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string NetDueDate { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the posting date.
        /// </summary>
        /// <value>
        /// The posting date.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PostingDate { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the currency.
        /// </summary>
        /// <value>
        /// The currency.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Currency { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the amount total.
        /// </summary>
        /// <value>
        /// The amount total.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal AmountTotal { get; set; }

        /// <summary>
        /// Gets or sets the amount premium.
        /// </summary>
        /// <value>
        /// The amount premium.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal AmountPremium { get; set; }

        /// <summary>
        /// Gets or sets the amount commission.
        /// </summary>
        /// <value>
        /// The amount commission.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal AmountCommission { get; set; }

        /// <summary>
        /// Gets or sets the contract.
        /// </summary>
        /// <value>
        /// The contract.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Contract { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the related contract.
        /// </summary>
        /// <value>
        /// The related contract.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string RelatedContract { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the type of the insurance.
        /// </summary>
        /// <value>
        /// The type of the insurance.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceType { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the divergent payer.
        /// </summary>
        /// <value>
        /// The divergent payer.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DivergentPayer { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the mandate reference.
        /// </summary>
        /// <value>
        /// The mandate reference.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string MandateReference { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the iban.
        /// </summary>
        /// <value>
        /// The iban.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Iban { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the incoming payment method.
        /// </summary>
        /// <value>
        /// The incoming payment method.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string IncomingPaymentMethod { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the incoming clearing lock.
        /// </summary>
        /// <value>
        /// The incoming clearing lock.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string IncomingClearingLock { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the incoming payment lock reason.
        /// </summary>
        /// <value>
        /// The incoming payment lock reason.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string IncomingPaymentLockReason { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the incoming dunning lock reason.
        /// </summary>
        /// <value>
        /// The incoming dunning lock reason.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string IncomingDunningLockReason { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the country control.
        /// </summary>
        /// <value>
        /// The country control.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CountryCtrl { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the type of the business.
        /// </summary>
        /// <value>
        /// The type of the business.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BusinessType { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the installment number.
        /// </summary>
        /// <value>
        /// The installment number.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InstallmentNum { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the type of the fracct.
        /// </summary>
        /// <value>
        /// The type of the fracct.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string FracctType { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the PRT notif document.
        /// </summary>
        /// <value>
        /// The PRT notif document.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PrtNotifDoc { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the PRT document.
        /// </summary>
        /// <value>
        /// The PRT document.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PrtDocument { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the PRT resp civil.
        /// </summary>
        /// <value>
        /// The PRT resp civil.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)] 
        public string PrtRespCivil { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the PRT green letter.
        /// </summary>
        /// <value>
        /// The PRT green letter.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)] 
        public string PrtGreenLetter { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the sibs entity.
        /// </summary>
        /// <value>
        /// The sibs entity.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SibsEntity { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the sibs reference.
        /// </summary>
        /// <value>
        /// The sibs reference.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SibsReference { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the sibs deadline.
        /// </summary>
        /// <value>
        /// The sibs deadline.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SibsDeadline { get; set; } = String.Empty;
    }

    
    public class ZfscdCodigosErroLinhaDocumentos
    {

        /// <summary>
        /// Gets or sets the error code.
        /// </summary>
        /// <value>
        /// The error code.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCode { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the error code text.
        /// </summary>
        /// <value>
        /// The error code text.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCodeTxt { get; set; } = String.Empty;
    }

    
    public partial class ZfscdDocumentoAddress
    {

        /// <summary>
        /// Gets or sets the first name.
        /// </summary>
        /// <value>
        /// The first name.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string FirstName { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the last name.
        /// </summary>
        /// <value>
        /// The last name.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string LastName { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the street.
        /// </summary>
        /// <value>
        /// The street.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Street { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the street complement.
        /// </summary>
        /// <value>
        /// The street complement.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string StreetComplement { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the location.
        /// </summary>
        /// <value>
        /// The location.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Location { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the post code.
        /// </summary>
        /// <value>
        /// The post code.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PostCode { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the city.
        /// </summary>
        /// <value>
        /// The city.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the country.
        /// </summary>
        /// <value>
        /// The country.
        /// </value>

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Country { get; set; } = String.Empty;
    }

    
    public partial class ZfscdDocumentoDetalheLinha
    {

        /// <summary>
        /// Gets or sets the master origin.
        /// </summary>
        /// <value>
        /// The master origin.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string MasterOrigin { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the partner external system.
        /// </summary>
        /// <value>
        /// The partner external system.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PartnerExternalSystem { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the main transaction.
        /// </summary>
        /// <value>
        /// The main transaction.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string MainTransaction { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the sub transaction.
        /// </summary>
        /// <value>
        /// The sub transaction.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SubTransaction { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the coverage.
        /// </summary>
        /// <value>
        /// The coverage.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Coverage { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the sub coverage.
        /// </summary>
        /// <value>
        /// The sub coverage.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SubCoverage { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the fund management.
        /// </summary>
        /// <value>
        /// The fund management.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string FundManagement { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the withholding tax code.
        /// </summary>
        /// <value>
        /// The withholding tax code.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string WithholdingTaxCode { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the product group.
        /// </summary>
        /// <value>
        /// The product group.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ProductGroup { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the item category.
        /// </summary>
        /// <value>
        /// The item category.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ItemCategory { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the amount.
        /// </summary>
        /// <value>
        /// The amount.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets the line text.
        /// </summary>
        /// <value>
        /// The line text.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string LineText { get; set; } = String.Empty;
    }

    
    public partial class ZFscdDocumentosPostWsResponse
    {

        private ZfscdDocumentosLinha documentsField;

        private ZfscdCodigosErroLinhaDocumentos[] errorsField;

        /// <summary>
        /// Gets or sets the documents.
        /// </summary>
        /// <value>
        /// The documents.
        /// </value>
        public ZfscdDocumentosLinha Documents
        {
            get
            {
                return this.documentsField;
            }
            set
            {
                this.documentsField = value;
            }
        }

        /// <summary>
        /// Gets or sets the errors.
        /// </summary>
        /// <value>
        /// The errors.
        /// </value>
        public ZfscdCodigosErroLinhaDocumentos[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }
    }

    public partial class ZFscdDocumentosPostWsRequest
    {
        /// <summary>
        /// The z FSCD documentos post ws
        /// </summary>
        public ZFscdDocumentosPostWs ZFscdDocumentosPostWs;
        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdDocumentosPostWsRequest"/> class.
        /// </summary>
        public ZFscdDocumentosPostWsRequest()
        {
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdDocumentosPostWsRequest"/> class.
        /// </summary>
        /// <param name="ZFscdDocumentosPostWs">The z FSCD documentos post ws.</param>
        public ZFscdDocumentosPostWsRequest(ZFscdDocumentosPostWs ZFscdDocumentosPostWs)
        {
            this.ZFscdDocumentosPostWs = ZFscdDocumentosPostWs;
        }
    }

    public partial class ZFscdDocumentosPostWsResponse1
    {
        /// <summary>
        /// The z FSCD documentos post ws response
        /// </summary>
        public ZFscdDocumentosPostWsResponse ZFscdDocumentosPostWsResponse { get; set; }
        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdDocumentosPostWsResponse1"/> class.
        /// </summary>
        public ZFscdDocumentosPostWsResponse1()
        {
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdDocumentosPostWsResponse1"/> class.
        /// </summary>
        /// <param name="ZFscdDocumentosPostWsResponse">The z FSCD documentos post ws response.</param>
        public ZFscdDocumentosPostWsResponse1(ZFscdDocumentosPostWsResponse ZFscdDocumentosPostWsResponse)
        {
            this.ZFscdDocumentosPostWsResponse = ZFscdDocumentosPostWsResponse;
        }
    }
}

﻿using Newtonsoft.Json;
using System;

namespace INS.PT.WebAPI.Model.Partners.Policy
{
    public partial class ZFscdApolicesPostWs
    {

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdApolicesLinha Policies { get; set; }
    }

   
    public partial class ZfscdApolicesLinha
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Interface { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string OriginalSystem { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Transaction { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SystemDate { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SystemTime { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Online { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ItemsTotal { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdInsobjectLinha[] Policy { get; set; } 
    }

    
    public partial class ZfscdInsobjectLinha
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceObjectCategory { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceObject { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Adherence { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceObjectOriginal { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string RelatedContract { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PublicContractCode { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyCode { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Network { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string MasterOrigin { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PartnerExternalSystem { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Agent { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Broker { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string StartDate { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string EndDate { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string WithholdingTaxCode { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PartnerRelationshipContract { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceType { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Product { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Protocol { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ProtocolStartDate { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ProtocolEndDate { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string IncomingPaymentIban { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string IncomingPaymentMethod { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string IncomingPaymentLockReason { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string MandateReference { get; set; }= String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string MandateReferenceOld { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string OutgoingPaymentIban { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string OutgoingPaymentMethod { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string OutgoingPaymentLockReason { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string AddressType { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string AddressNumber { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ActionZone { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InspectionArea { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SituactionCode { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SituactionCodeDate { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string LoanNumber { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdInsobjectObjectRisk Risk { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdInsobjectMediador Mediators { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdInsobjectBeneficiario[] Beneficiaries { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdCodigosErroLinhaApolice[] Errors { get; set; }

    }

 
    public partial class ZfscdInsobjectObjectRisk
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceObjectRisk { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceObjectLocal { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CurrencyCapital { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal InsuranceCapital1 { get; set; } 

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal InsuranceCapital2 { get; set; } 

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal InsuranceCapital3 { get; set; } 
    }

 
    public partial class ZfscdMediadoresLinha
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Interface { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string OriginalSystem { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Transaction { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SystemDate { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SystemTime { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Online { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ItemsTotal { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdInsobjectLinha[] Mediator { get; set; }
    }

 
    public partial class ZfscdSinistrosLinha
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Interface { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string OriginalSystem { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Transaction { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SystemDate { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SystemTime { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Online { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ItemsTotal { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdInsobjectLinha[] Claim { get; set; } 
    }

    public partial class ZfscdCodigosErroLinhaMediador
    {

        private string errorCodeField;

        private string errorCodeTxtField;
 
        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

 
        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }


    public partial class ZfscdCodigosErroLinhaApolice
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCode { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCodeTxt { get; set; } = String.Empty;
    }


    public partial class ZfscdCodigosErroLinhaSinistro
    {

        private string errorCodeField;

        private string errorCodeTxtField;

 
        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

       
        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }
 
    public partial class ZfscdInsobjectBeneficiario
    {

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PartnerRelationshipContract { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string MasterOrigin { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PartnerExternalSystem { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Iban { get; set; } = String.Empty;

    }
 
    public partial class ZfscdInsobjectMediador
    {

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string IspCode { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PremiumCategory { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CommissionCategory { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ClaimCategory { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CostCategory { get; set; } = String.Empty;
    }
 
    public partial class ZFscdApolicesPostWsResponse
    {
        private ZfscdApolicesLinha policiesField;

        private ZfscdCodigosErroLinhaApolice[] errorsField;

  
        public ZfscdApolicesLinha Policies
        {
            get
            {
                return this.policiesField;
            }
            set
            {
                this.policiesField = value;
            }
        }

 
        public ZfscdCodigosErroLinhaApolice[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }

    }
 
    public partial class ZFscdApolicesPostWsRequest
    {

 
        public ZFscdApolicesPostWs ZFscdApolicesPostWs;

        public ZFscdApolicesPostWsRequest()
        {
        }

        public ZFscdApolicesPostWsRequest(ZFscdApolicesPostWs ZFscdApolicesPostWs)
        {
            this.ZFscdApolicesPostWs = ZFscdApolicesPostWs;
        }
    }

 
    public partial class ZFscdApolicesPostWsResponse1
    {

 
        public ZFscdApolicesPostWsResponse ZFscdApolicesPostWsResponse { get; set; }

        public ZFscdApolicesPostWsResponse1()
        {
        }

        public ZFscdApolicesPostWsResponse1(ZFscdApolicesPostWsResponse ZFscdApolicesPostWsResponse)
        {
            this.ZFscdApolicesPostWsResponse = ZFscdApolicesPostWsResponse;
        }
    }
 
    public partial class ZFscdSinistrosPostWs
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdSinistrosLinha Claims { get; set; }
    }

    public partial class ZFscdSinistrosPostWsResponse
    {

        private ZfscdSinistrosLinha claimsField;

        private ZfscdCodigosErroLinhaSinistro[] errorsField;

 
        public ZfscdSinistrosLinha Claims
        {
            get
            {
                return this.claimsField;
            }
            set
            {
                this.claimsField = value;
            }
        }

    
        public ZfscdCodigosErroLinhaSinistro[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }
    }
 
    public partial class ZFscdSinistrosPostWsRequest
    {

   
        public ZFscdSinistrosPostWs ZFscdSinistrosPostWs;

        public ZFscdSinistrosPostWsRequest()
        {
        }

        public ZFscdSinistrosPostWsRequest(ZFscdSinistrosPostWs ZFscdSinistrosPostWs)
        {
            this.ZFscdSinistrosPostWs = ZFscdSinistrosPostWs;
        }
    }

 
    public partial class ZFscdSinistrosPostWsResponse1
    {

    
        public ZFscdSinistrosPostWsResponse ZFscdSinistrosPostWsResponse { get; set; }

        public ZFscdSinistrosPostWsResponse1()
        {
        }

        public ZFscdSinistrosPostWsResponse1(ZFscdSinistrosPostWsResponse ZFscdSinistrosPostWsResponse)
        {
            this.ZFscdSinistrosPostWsResponse = ZFscdSinistrosPostWsResponse;
        }
    }

 
    public partial class ZFscdMediadoresPostWs
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdMediadoresLinha MediationAccount { get; set; }
    }

 
    public partial class ZFscdMediadoresPostWsResponse
    {


        private ZfscdCodigosErroLinhaMediador[] errorsField;

        private ZfscdMediadoresLinha mediationAccountField;


        public ZfscdCodigosErroLinhaMediador[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }


        public ZfscdMediadoresLinha MediationAccount
        {
            get
            {
                return this.mediationAccountField;
            }
            set
            {
                this.mediationAccountField = value;
            }
        }

 

    }
 
    public partial class ZFscdMediadoresPostWsRequest
    {

 
        public ZFscdMediadoresPostWs ZFscdMediadoresPostWs;

        public ZFscdMediadoresPostWsRequest()
        {
        }

        public ZFscdMediadoresPostWsRequest(ZFscdMediadoresPostWs ZFscdMediadoresPostWs)
        {
            this.ZFscdMediadoresPostWs = ZFscdMediadoresPostWs;
        }
    }

 
    public partial class ZFscdMediadoresPostWsResponse1
    {

  
        public ZFscdMediadoresPostWsResponse ZFscdMediadoresPostWsResponse { get; set; }

        public ZFscdMediadoresPostWsResponse1()
        {
        }

        public ZFscdMediadoresPostWsResponse1(ZFscdMediadoresPostWsResponse ZFscdMediadoresPostWsResponse)
        {
            this.ZFscdMediadoresPostWsResponse = ZFscdMediadoresPostWsResponse;
        }
    }
}
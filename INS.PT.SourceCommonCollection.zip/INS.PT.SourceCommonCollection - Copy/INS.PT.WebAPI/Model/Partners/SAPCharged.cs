﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Helper.Validations;

namespace INS.PT.WebAPI.Model.Partners.Charged
{

 
    public partial class ZFscdCobradosPostWs
    {
        /// <summary>
        /// Gets or sets the receipts collected.
        /// </summary>
        /// <value>
        /// The receipts collected.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdCobradosLinha ReceiptsCollected { get; set; }
    }

 
    public partial class ZfscdCobradosLinha
    {
        /// <summary>
        /// Gets or sets the interface.
        /// </summary>
        /// <value>
        /// The interface.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Interface { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the destiny system.
        /// </summary>
        /// <value>
        /// The destiny system.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DestinySystem { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the transaction.
        /// </summary>
        /// <value>
        /// The transaction.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Transaction { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the system date.
        /// </summary>
        /// <value>
        /// The system date.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SystemDate { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the system time.
        /// </summary>
        /// <value>
        /// The system time.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SystemTime { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the online.
        /// </summary>
        /// <value>
        /// The online.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Online { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the items total.
        /// </summary>
        /// <value>
        /// The items total.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ItemsTotal { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the collect.
        /// </summary>
        /// <value>
        /// The collect.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdCobradoLinha[] Collect { get; set; }
    }

 
    public partial class ZfscdCobradoLinha
    {

        /// <summary>
        /// Gets or sets the original system.
        /// </summary>
        /// <value>
        /// The original system.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string OriginalSystem { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the company code.
        /// </summary>
        /// <value>
        /// The company code.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyCode { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the network.
        /// </summary>
        /// <value>
        /// The network.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Network { get; set; } = String.Empty;


        /// <summary>
        /// Gets or sets the policy.
        /// </summary>
        /// <value>
        /// The policy.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Policy { get; set; } = String.Empty;


        /// <summary>
        /// Gets or sets the claim.
        /// </summary>
        /// <value>
        /// The claim.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Claim { get; set; } = String.Empty;


        /// <summary>
        /// Gets or sets the reference document number.
        /// </summary>
        /// <value>
        /// The reference document number.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceDocumentNumber { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the type of the receipt.
        /// </summary>
        /// <value>
        /// The type of the receipt.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReceiptType { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the operation.
        /// </summary>
        /// <value>
        /// The operation.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Operation { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the operation date.
        /// </summary>
        /// <value>
        /// The operation date.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string OperationDate { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the collect payment method.
        /// </summary>
        /// <value>
        /// The collect payment method.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CollectPaymentMethod { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the amount.
        /// </summary>
        /// <value>
        /// The amount.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets the errors.
        /// </summary>
        /// <value>
        /// The errors.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdCodigosErroLinhaCobrados[] Errors { get; set; }
    }

 
    public class ZfscdCodigosErroLinhaCobrados
    {

        /// <summary>
        /// Gets or sets the error code.
        /// </summary>
        /// <value>
        /// The error code.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCode { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the error code text.
        /// </summary>
        /// <value>
        /// The error code text.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCodeTxt { get; set; } = String.Empty;
    }

 
    public partial class ZFscdCobradosPostWsResponse
    {

        private ZfscdCobradosLinha receiptsCollectedField;

        private ZfscdCodigosErroLinhaCobrados[] errorsField;

  
        public ZfscdCobradosLinha ReceiptsCollected
        {
            get
            {
                return this.receiptsCollectedField;
            }
            set
            {
                this.receiptsCollectedField = value;
            }
        }

 
        public ZfscdCodigosErroLinhaCobrados[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }

    }

 
    public partial class ZFscdCobradosPostWsRequest
    {
        /// <summary>
        /// The z FSCD cobrados post ws
        /// </summary>
        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "urn:sap-com:document:sap:soap:functions:mc-style", Order = 0)]
        public ZFscdCobradosPostWs ZFscdCobradosPostWs;
        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdCobradosPostWsRequest"/> class.
        /// </summary>
        public ZFscdCobradosPostWsRequest()
        {
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdCobradosPostWsRequest"/> class.
        /// </summary>
        /// <param name="ZFscdCobradosPostWs">The z FSCD cobrados post ws.</param>
        public ZFscdCobradosPostWsRequest(ZFscdCobradosPostWs ZFscdCobradosPostWs)
        {
            this.ZFscdCobradosPostWs = ZFscdCobradosPostWs;
        }
    }

 
    public partial class ZFscdCobradosPostWsResponse1
    {
 
        public ZFscdCobradosPostWsResponse ZFscdCobradosPostWsResponse { get; set; }

        public ZFscdCobradosPostWsResponse1()
        {
        }
 
        public ZFscdCobradosPostWsResponse1(ZFscdCobradosPostWsResponse ZFscdCobradosPostWsResponse)
        {
            this.ZFscdCobradosPostWsResponse = ZFscdCobradosPostWsResponse;
        }
    }
 
}

﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

/// <summary>
/// INS.PT.WebAPI.Model.Partners.IbanCheck
/// </summary>
namespace INS.PT.WebAPI.Model.Partners.Iban
{
    /// <summary>
    /// ZFscdCheckIbanWs
    /// </summary>
    public class ZFscdCheckIbanWs
    {
        /// <summary>
        /// Gets or sets the iban.
        /// </summary>
        /// <value>
        /// The iban.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Iban { get; set; } = String.Empty;
    }

    /// <summary>
    /// ZfscdCodigosErroLinha
    /// </summary>
    //public class ZfscdCodigosErroLinha
    //{
    //    /// <summary>
    //    /// Gets or sets the error code.
    //    /// </summary>
    //    /// <value>
    //    /// The error code.
    //    /// </value>
    //    [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
    //    public string ErrorCode { get; set; } = String.Empty;

    //    /// <summary>
    //    /// Gets or sets the error code text.
    //    /// </summary>
    //    /// <value>
    //    /// The error code text.
    //    /// </value>
    //    [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
    //    public string ErrorCodeTxt { get; set; } = String.Empty;
    //}

    /// <summary>
    /// ZFscdCheckIbanWsResponse
    /// </summary>
    public class ZFscdCheckIbanWsResponse
    {
        /// <summary>
        /// Gets or sets the errors.
        /// </summary>
        /// <value>
        /// The errors.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public List<ErrorElement> Errors { get; set; }
    }

    /// <summary>
    /// ZFscdCheckIbanWsRequest
    /// </summary>
    public class ZFscdCheckIbanWsRequest
    {
        /// <summary>
        /// Gets or sets the z FSCD check iban ws.
        /// </summary>
        /// <value>
        /// The z FSCD check iban ws.
        /// </value>
        public INS.PT.WebAPI.Model.Partners.Iban.ZFscdCheckIbanWs ZFscdCheckIbanWs { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdCheckIbanWsRequest"/> class.
        /// </summary>
        public ZFscdCheckIbanWsRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdCheckIbanWsRequest"/> class.
        /// </summary>
        /// <param name="ZFscdCheckIbanWs">The z FSCD check iban ws.</param>
        public ZFscdCheckIbanWsRequest(INS.PT.WebAPI.Model.Partners.Iban.ZFscdCheckIbanWs ZFscdCheckIbanWs)
        {
            this.ZFscdCheckIbanWs = ZFscdCheckIbanWs;
        }
    }

    /// <summary>
    /// ZFscdCheckIbanWsResponse1
    /// </summary>
    public class ZFscdCheckIbanWsResponse1
    {
        /// <summary>
        /// Gets or sets the z FSCD check iban ws response.
        /// </summary>
        /// <value>
        /// The z FSCD check iban ws response.
        /// </value>
        public INS.PT.WebAPI.Model.Partners.Iban.ZFscdCheckIbanWsResponse ZFscdCheckIbanWsResponse { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdCheckIbanWsResponse1"/> class.
        /// </summary>
        public ZFscdCheckIbanWsResponse1()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdCheckIbanWsResponse1"/> class.
        /// </summary>
        /// <param name="ZFscdCheckIbanWsResponse">The z FSCD check iban ws response.</param>
        public ZFscdCheckIbanWsResponse1(INS.PT.WebAPI.Model.Partners.Iban.ZFscdCheckIbanWsResponse ZFscdCheckIbanWsResponse)
        {
            this.ZFscdCheckIbanWsResponse = ZFscdCheckIbanWsResponse;
        }
    }
}
﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Model.Partners.Get.ProposalAIA
{
    /// <summary>
    /// ZageasLifeGetProposalWs
    /// </summary>
    public class ZageasLifeGetProposalWs
    {
        /// <summary>
        /// Gets or sets the e proposal.
        /// </summary>
        /// <value>
        /// The e proposal.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZeaiaProposal EProposal { get; set; }
    }

    /// <summary>
    /// ZeaiaProposal
    /// </summary>
    public class ZeaiaProposal
    {
        /// <summary>
        /// Gets or sets the proposal number.
        /// </summary>
        /// <value>
        /// The proposal number.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ProposalNumber { get; set; }

        /// <summary>
        /// Gets or sets the company.
        /// </summary>
        /// <value>
        /// The company.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Company { get; set; }

        /// <summary>
        /// Gets or sets the nep.
        /// </summary>
        /// <value>
        /// The nep.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Nep { get; set; }

        /// <summary>
        /// Gets or sets the value.
        /// </summary>
        /// <value>
        /// The value.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets the creation date.
        /// </summary>
        /// <value>
        /// The creation date.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CreationDate { get; set; }

        /// <summary>
        /// Gets or sets the creation time.
        /// </summary>
        /// <value>
        /// The creation time.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CreationTime { get; set; }

        /// <summary>
        /// Gets or sets the update date.
        /// </summary>
        /// <value>
        /// The update date.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string UpdateDate { get; set; }

        /// <summary>
        /// Gets or sets the update time.
        /// </summary>
        /// <value>
        /// The update time.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string UpdateTime { get; set; }

        /// <summary>
        /// Gets or sets the paymet.
        /// </summary>
        /// <value>
        /// The paymet.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Paymet { get; set; }


        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DataLimite { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the original aplication.
        /// </summary>
        /// <value>
        /// The original aplication.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string OriginalAplication { get; set; }

        /// <summary>
        /// Gets or sets the iban.
        /// </summary>
        /// <value>
        /// The iban.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BankAcc { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Nif { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string IdEntity { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PhoneId { get; set; }
    }

    /// <summary>
    /// ZfscdCodigosErroGetLinhaAia
    /// </summary>
    public class ZfscdCodigosErroGetLinhaAia
    {
        /// <summary>
        /// Gets or sets the error code.
        /// </summary>
        /// <value>
        /// The error code.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCode { get; set; }

        /// <summary>
        /// Gets or sets the error code text.
        /// </summary>
        /// <value>
        /// The error code text.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCodeTxt { get; set; }
    }

    /// <summary>
    /// ZageasLifeGetProposalWsResponse
    /// </summary>
    public class ZageasLifeGetProposalWsResponse
    {
        /// <summary>
        /// Gets or sets the e proposal.
        /// </summary>
        /// <value>
        /// The e proposal.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZeaiaProposal EProposal { get; set; }

        /// <summary>
        /// Gets or sets the errors.
        /// </summary>
        /// <value>
        /// The errors.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdCodigosErroGetLinhaAia Errors { get; set; }
    }

    /// <summary>
    /// ZageasLifeGetProposalWsRequest
    /// </summary>
    public class ZageasLifeGetProposalWsRequest
    {
        /// <summary>
        /// The zageas life get proposal ws
        /// </summary>
        public INS.PT.WebAPI.Model.Partners.Get.ProposalAIA.ZageasLifeGetProposalWs ZageasLifeGetProposalWs;

        /// <summary>
        /// Initializes a new instance of the <see cref="ZageasLifeGetProposalWsRequest"/> class.
        /// </summary>
        public ZageasLifeGetProposalWsRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ZageasLifeGetProposalWsRequest"/> class.
        /// </summary>
        /// <param name="ZageasLifeGetProposalWs">The zageas life get proposal ws.</param>
        public ZageasLifeGetProposalWsRequest(INS.PT.WebAPI.Model.Partners.Get.ProposalAIA.ZageasLifeGetProposalWs ZageasLifeGetProposalWs)
        {
            this.ZageasLifeGetProposalWs = ZageasLifeGetProposalWs;
        }
    }

    /// <summary>
    /// ZageasLifeGetProposalWsResponse1
    /// </summary>
    public class ZageasLifeGetProposalWsResponse1
    {
        /// <summary>
        /// The zageas life get proposal ws response
        /// </summary>
        public INS.PT.WebAPI.Model.Partners.Get.ProposalAIA.ZageasLifeGetProposalWsResponse ZageasLifeGetProposalWsResponse;

        /// <summary>
        /// Initializes a new instance of the <see cref="ZageasLifeGetProposalWsResponse1"/> class.
        /// </summary>
        public ZageasLifeGetProposalWsResponse1()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ZageasLifeGetProposalWsResponse1"/> class.
        /// </summary>
        /// <param name="ZageasLifeGetProposalWsResponse">The zageas life get proposal ws response.</param>
        public ZageasLifeGetProposalWsResponse1(INS.PT.WebAPI.Model.Partners.Get.ProposalAIA.ZageasLifeGetProposalWsResponse ZageasLifeGetProposalWsResponse)
        {
            this.ZageasLifeGetProposalWsResponse = ZageasLifeGetProposalWsResponse;
        }
    }
}

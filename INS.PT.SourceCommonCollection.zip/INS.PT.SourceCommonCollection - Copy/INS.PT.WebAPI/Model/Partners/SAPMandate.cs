﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Helper.Validations;

namespace INS.PT.WebAPI.Model.Partners.Mandate
{
 
    public partial class ZFscdMandatosPostWs
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdMandatosLinha MandatesReference { get; set; }
    }

 
    public partial class ZfscdMandatosLinha
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Interface { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string OriginalSystem { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Transaction { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SystemDate { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SystemTime { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Online { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ItemsTotal { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdMandatoLinha[] Mandate { get; set; }
    }

 
    public partial class ZfscdMandatoLinha
    {

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string MandateType { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyCode { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Network { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string MandateReference { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string MandateReferenceOld { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SndIban { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Policy { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Adherence { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerContract { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string MasterOrigin { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PartnerExternalSystem { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SndBic { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string StartDateFrom { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string StartDateTo { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PayType { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SignCity { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SignDate { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdCodigosErroLinhaMandato[] Errors { get; set; }
    }

    public class ZfscdCodigosErroLinhaMandato
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCode { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCodeTxt { get; set; }
    }

 
    public partial class ZFscdMandatosPostWsResponse
    {

        private ZfscdMandatosLinha mandatesReferenceField;

        private ZfscdCodigosErroLinhaMandato[] errorsField;

 
        public ZfscdMandatosLinha MandatesReference
        {
            get
            {
                return this.mandatesReferenceField;
            }
            set
            {
                this.mandatesReferenceField = value;
            }
        }

    
        public ZfscdCodigosErroLinhaMandato[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }
    }

  
    public partial class ZFscdMandatosPostWsRequest
    {
        /// <summary>
        /// The z FSCD mandatos post ws
        /// </summary>
        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "urn:sap-com:document:sap:soap:functions:mc-style", Order = 0)]
        public ZFscdMandatosPostWs ZFscdMandatosPostWs;
        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdMandatosPostWsRequest"/> class.
        /// </summary>
        public ZFscdMandatosPostWsRequest()
        {
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdMandatosPostWsRequest"/> class.
        /// </summary>
        /// <param name="ZFscdMandatosPostWs">The z FSCD mandatos post ws.</param>
        public ZFscdMandatosPostWsRequest(ZFscdMandatosPostWs ZFscdMandatosPostWs)
        {
            this.ZFscdMandatosPostWs = ZFscdMandatosPostWs;
        }
    }

 
    public partial class ZFscdMandatosPostWsResponse1
    {
      
        public ZFscdMandatosPostWsResponse ZFscdMandatosPostWsResponse { get; set; }
        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdMandatosPostWsResponse1"/> class.
        /// </summary>
        public ZFscdMandatosPostWsResponse1()
        {
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdMandatosPostWsResponse1"/> class.
        /// </summary>
        /// <param name="ZFscdMandatosPostWsResponse">The z FSCD mandatos post ws response.</param>
        public ZFscdMandatosPostWsResponse1(ZFscdMandatosPostWsResponse ZFscdMandatosPostWsResponse)
        {
            this.ZFscdMandatosPostWsResponse = ZFscdMandatosPostWsResponse;
        }
    }
}

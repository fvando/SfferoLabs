﻿using Newtonsoft.Json;
 

namespace INS.PT.WebAPI.Model.Partners
{
    public class ErrorElement
    {

        /// <summary>
        /// Gets or sets the error code.
        /// </summary>
        /// <value>
        /// The error code.
        /// </value>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCode { get; set; }

        /// <summary>
        /// Gets or sets the error code text.
        /// </summary>
        /// <value>
        /// The error code text.
        /// </value>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCodeTxt { get; set; }
            
        
    }
}

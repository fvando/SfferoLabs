﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Helper.Validations;

namespace INS.PT.WebAPI.Model.Partners.GreenLetter
{
    public partial class ZFscdCartasverdePostWs
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdCartasverdeLinha Greencards { get; set; }
    }

    
    public partial class ZfscdCartasverdeLinha
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Interface { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string OriginalSystem { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Transaction { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SystemDate { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SystemTime { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Online { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ItemsTotal { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdCartaverdeLinha[] Greencard { get; set; }
    }

    
    public partial class ZfscdCartaverdeLinha
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyCode { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceDocumentNumber { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Policy { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Line { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Network { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DocumentType { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string GroupNumber { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)] 
        public string InsuranceType { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SequenceNumber { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PrtGreenLetter { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PrtCertificateNumberLetter { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Prefix { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string FleetFlag { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string MasterOrigin { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PartnerExternalSystem { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerContract { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Street { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCode { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string RiskLocal { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string RiskPostalCode { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Currency { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string AutoNcc { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CivilCertificateNumber { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal CivilLiabilityCapital { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal OwnDamageCapital { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal ExtraCapital { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal OwnDamageValue { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CvStartDate { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CvEndDate { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CvCode1 { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CvDocumentNumber1 { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string RegistrationNumber1 { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CarBrand1 { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string AutoClass1 { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string AutoTxCodRc1 { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string AutoTxVarRc1 { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CvCode2 { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CvDocumentNumber2 { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string RegistrationNumber2 { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CarBrand2 { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string AutoClass2 { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string AutoTxCodRc2 { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string AutoTxVarRc2 { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdCodigosErroLinhaCartaVerde[] Errors { get; set; }

    }

    
    public class ZfscdCodigosErroLinhaCartaVerde
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCode { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCodeTxt { get; set; } = String.Empty;
    }

    
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:sap-com:document:sap:soap:functions:mc-style")]
    public partial class ZFscdCartasverdePostWsResponse
    {
        private ZfscdCartasverdeLinha greencardsField;

        private ZfscdCodigosErroLinhaCartaVerde[] errorsField;

        /// <summary>
        /// Gets or sets the greencards.
        /// </summary>
        /// <value>
        /// The greencards.
        /// </value>
        [System.Xml.Serialization.XmlElementAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 0)]
        public ZfscdCartasverdeLinha Greencards
        {
            get
            {
                return this.greencardsField;
            }
            set
            {
                this.greencardsField = value;
            }
        }


        /// <summary>
        /// Gets or sets the errors.
        /// </summary>
        /// <value>
        /// The errors.
        /// </value>
        [System.Xml.Serialization.XmlArrayAttribute(Form = System.Xml.Schema.XmlSchemaForm.Unqualified, Order = 1)]
        [System.Xml.Serialization.XmlArrayItemAttribute("item", Form = System.Xml.Schema.XmlSchemaForm.Unqualified, IsNullable = false)]
        public ZfscdCodigosErroLinhaCartaVerde[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }

    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class ZFscdCartasverdePostWsRequest
    {
        /// <summary>
        /// The z FSCD cartasverde post ws
        /// </summary>
        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "urn:sap-com:document:sap:soap:functions:mc-style", Order = 0)]
        public ZFscdCartasverdePostWs ZFscdCartasverdePostWs;
        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdCartasverdePostWsRequest"/> class.
        /// </summary>
        public ZFscdCartasverdePostWsRequest()
        {
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdCartasverdePostWsRequest"/> class.
        /// </summary>
        /// <param name="ZFscdCartasverdePostWs">The z FSCD cartasverde post ws.</param>
        public ZFscdCartasverdePostWsRequest(ZFscdCartasverdePostWs ZFscdCartasverdePostWs)
        {
            this.ZFscdCartasverdePostWs = ZFscdCartasverdePostWs;
        }
    }

    [System.Diagnostics.DebuggerStepThroughAttribute()]
    [System.CodeDom.Compiler.GeneratedCodeAttribute("dotnet-svcutil", "1.0.0.1")]
    [System.ComponentModel.EditorBrowsableAttribute(System.ComponentModel.EditorBrowsableState.Advanced)]
    [System.ServiceModel.MessageContractAttribute(IsWrapped = false)]
    public partial class ZFscdCartasverdePostWsResponse1
    {
        /// <summary>
        /// The z FSCD cartasverde post ws response
        /// </summary>
        [System.ServiceModel.MessageBodyMemberAttribute(Namespace = "urn:sap-com:document:sap:soap:functions:mc-style", Order = 0)]
        public ZFscdCartasverdePostWsResponse ZFscdCartasverdePostWsResponse { get; set; }
        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdCartasverdePostWsResponse1"/> class.
        /// </summary>
        public ZFscdCartasverdePostWsResponse1()
        {
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdCartasverdePostWsResponse1"/> class.
        /// </summary>
        /// <param name="ZFscdCartasverdePostWsResponse">The z FSCD cartasverde post ws response.</param>
        public ZFscdCartasverdePostWsResponse1(ZFscdCartasverdePostWsResponse ZFscdCartasverdePostWsResponse)
        {
            this.ZFscdCartasverdePostWsResponse = ZFscdCartasverdePostWsResponse;
        }
    }
}

﻿using INS.PT.WebAPI.Model.Domain;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace INS.PT.WebAPI.Model.Partners.WebReceiptListing
{

    /// <summary>
    /// ZFscdRecibosListarWs
    /// </summary>
    public partial class ZFscdRecibosListarWs
    {

        /// <summary>
        /// Gets or sets the broker.
        /// </summary>
        /// <value>
        /// The broker.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Broker { get; set; } = String.Empty;


        /// <summary>
        /// Gets or sets the company code.
        /// </summary>
        /// <value>
        /// The company code.
        /// </value>

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyCode { get; set; } = String.Empty;


        /// <summary>
        /// Gets or sets the end date.
        /// </summary>
        /// <value>
        /// The end date.
        /// </value>

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string EndDate { get; set; } = String.Empty;


        /// <summary>
        /// Gets or sets the policy.
        /// </summary>
        /// <value>
        /// The policy.
        /// </value>

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Policy { get; set; } = String.Empty;


        /// <summary>
        /// Gets or sets the reference document number.
        /// </summary>
        /// <value>
        /// The reference document number.
        /// </value>

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceDocumentNumber { get; set; } = String.Empty;


        /// <summary>
        /// Gets or sets the start date.
        /// </summary>
        /// <value>
        /// The start date.
        /// </value>

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string StartDate { get; set; } = String.Empty;


        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; } = String.Empty;


        /// <summary>
        /// Gets or sets the tax number.
        /// </summary>
        /// <value>
        /// The tax number.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string TaxNumber { get; set; } = String.Empty;
        
    }

    public partial class ZfscdRecibosWorkLinha
    {

        private string companyCodeField;

        private string insurancePartnerField;

        private string contractField;

        private string referenceDocumentNumberField;

        private string sapDocumentNumberField;

        private string documentTypeField;

        private string taxnumField;

        private string fullNameField;

        private string insurancePayerField;

        private string insuranceAgentField;

        private string insuranceBrokerField;

        private string insuranceInspectorField;

        private string insuranceOtherField;

        private string signalField;

        private string receiptTypeField;

        private string receiptTypeTxtField;

        private string registrationNumberField;

        private string emissionDateField;

        private string emissionHourField;

        private string postingDateField;

        private string netDueDateField;

        private string billingPeriodFromField;

        private string billingPeriodToField;

        private string paymentOrderField;

        private string clearingReasonField;

        private string clearingStatusField;

        private string clearingDocumentTypeField;

        private string clearingDocumentField;

        private string clearingPostDateField;

        private string statusDocField;

        private string statusField;

        private string statusTxtField;

        private string statusDateField;

        private string printDateField;

        private string insuranceTypeField;

        private string insuranceTypeTxtField;

        private string productGroupField;

        private string productGroupTxtField;

        private string paymentSplitTypeField;

        private string paymentSplitTypeTxtField;

        private string paymentMethodField;

        private string paymentMethodTxtField;

        private string paymentClientTxtField;

        private string billingChannelField;

        private string billingChannelTxtField;

        private string returnReasonField;

        private string descriptionReturnReasonField;

        private string returnDateField;

        private string currencyField;

        private decimal premiumValueField;

        private decimal chargesValueField;

        private decimal bonusValueField;

        private decimal atasValueField;

        private decimal inemValueField;

        private decimal fgaValueField;

        private decimal greenLetterValueField;

        private decimal anpcValueField;

        private decimal sealValueField;

        private decimal policyValueField;

        private decimal fatValueField;

        private decimal prpValueField;

        private decimal fractioningValueField;

        private decimal calamityValueField;

        private decimal latePaymentValueField;

        private decimal medicalExamValueField;

        private decimal tgisValueField;

        private decimal totalAddValueField;

        private decimal totalCostValueField;

        private decimal totalTaxValueField;

        private decimal totalValueField;

        private decimal commissionPromotionValueField;

        private decimal commissionChargeValueField;

        private decimal commissionInspectionValueField;

        private decimal commissionAgentValueField;

        private decimal commissionOtherValueField;

        private decimal commissionTaxValueField;

        private decimal totalCommissionField;

        private decimal policyCapitalField;

        private string sibsEntityField;

        private string sibsReferenceField;

        private string sibsDueDateField;

        private string sibsDueHourField;

        private string sibsStatusField;

        private string bankingCircuitField;

        private string bankDetailsIdField;

        private string bankDesignationField;

        private string brokerReportIdentificationField;

        private string premiumCategoryField;

        private string commissionCategoryField;

        private string claimCategoryField;

        private string costCategoryField;

        private string contractTypeField;

        private string situationField;

        private string situationDateField;

        private string originalAplicationField;

        private string documentIdField;

        private string lockIdField;

        private List<CoverageElements> coverageField;

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public List<ErrorElement> Errors { get; set; }

        public string CompanyCode
        {
            get
            {
                return this.companyCodeField;
            }
            set
            {
                this.companyCodeField = value;
            }
        }

        public string InsurancePartner
        {
            get
            {
                return this.insurancePartnerField;
            }
            set
            {
                this.insurancePartnerField = value;
            }
        }

        public string Contract
        {
            get
            {
                return this.contractField;
            }
            set
            {
                this.contractField = value;
            }
        }

        public string ReferenceDocumentNumber
        {
            get
            {
                return this.referenceDocumentNumberField;
            }
            set
            {
                this.referenceDocumentNumberField = value;
            }
        }

        public string SapDocumentNumber
        {
            get
            {
                return this.sapDocumentNumberField;
            }
            set
            {
                this.sapDocumentNumberField = value;
            }
        }

        public string DocumentType
        {
            get
            {
                return this.documentTypeField;
            }
            set
            {
                this.documentTypeField = value;
            }
        }

        public string Taxnum
        {
            get
            {
                return this.taxnumField;
            }
            set
            {
                this.taxnumField = value;
            }
        }

        public string FullName
        {
            get
            {
                return this.fullNameField;
            }
            set
            {
                this.fullNameField = value;
            }
        }

        public string InsurancePayer
        {
            get
            {
                return this.insurancePayerField;
            }
            set
            {
                this.insurancePayerField = value;
            }
        }

        public string InsuranceAgent
        {
            get
            {
                return this.insuranceAgentField;
            }
            set
            {
                this.insuranceAgentField = value;
            }
        }

        public string InsuranceBroker
        {
            get
            {
                return this.insuranceBrokerField;
            }
            set
            {
                this.insuranceBrokerField = value;
            }
        }

        public string InsuranceInspector
        {
            get
            {
                return this.insuranceInspectorField;
            }
            set
            {
                this.insuranceInspectorField = value;
            }
        }

        public string InsuranceOther
        {
            get
            {
                return this.insuranceOtherField;
            }
            set
            {
                this.insuranceOtherField = value;
            }
        }

        public string Signal
        {
            get
            {
                return this.signalField;
            }
            set
            {
                this.signalField = value;
            }
        }

        public string ReceiptType
        {
            get
            {
                return this.receiptTypeField;
            }
            set
            {
                this.receiptTypeField = value;
            }
        }

        public string ReceiptTypeTxt
        {
            get
            {
                return this.receiptTypeTxtField;
            }
            set
            {
                this.receiptTypeTxtField = value;
            }
        }

        public string RegistrationNumber
        {
            get
            {
                return this.registrationNumberField;
            }
            set
            {
                this.registrationNumberField = value;
            }
        }

        public string EmissionDate
        {
            get
            {
                return this.emissionDateField;
            }
            set
            {
                this.emissionDateField = value;
            }
        }

        public string EmissionHour
        {
            get
            {
                return this.emissionHourField;
            }
            set
            {
                this.emissionHourField = value;
            }
        }

        public string PostingDate
        {
            get
            {
                return this.postingDateField;
            }
            set
            {
                this.postingDateField = value;
            }
        }

        public string NetDueDate
        {
            get
            {
                return this.netDueDateField;
            }
            set
            {
                this.netDueDateField = value;
            }
        }

        public string BillingPeriodFrom
        {
            get
            {
                return this.billingPeriodFromField;
            }
            set
            {
                this.billingPeriodFromField = value;
            }
        }

        public string BillingPeriodTo
        {
            get
            {
                return this.billingPeriodToField;
            }
            set
            {
                this.billingPeriodToField = value;
            }
        }

        public string PaymentOrder
        {
            get
            {
                return this.paymentOrderField;
            }
            set
            {
                this.paymentOrderField = value;
            }
        }

        public string ClearingReason
        {
            get
            {
                return this.clearingReasonField;
            }
            set
            {
                this.clearingReasonField = value;
            }
        }

        public string ClearingStatus
        {
            get
            {
                return this.clearingStatusField;
            }
            set
            {
                this.clearingStatusField = value;
            }
        }

        public string ClearingDocumentType
        {
            get
            {
                return this.clearingDocumentTypeField;
            }
            set
            {
                this.clearingDocumentTypeField = value;
            }
        }

        public string ClearingDocument
        {
            get
            {
                return this.clearingDocumentField;
            }
            set
            {
                this.clearingDocumentField = value;
            }
        }

        public string ClearingPostDate
        {
            get
            {
                return this.clearingPostDateField;
            }
            set
            {
                this.clearingPostDateField = value;
            }
        }

        public string StatusDoc
        {
            get
            {
                return this.statusDocField;
            }
            set
            {
                this.statusDocField = value;
            }
        }
        public string Status
        {
            get
            {
                return this.statusField;
            }
            set
            {
                this.statusField = value;
            }
        }

        public string StatusTxt
        {
            get
            {
                return this.statusTxtField;
            }
            set
            {
                this.statusTxtField = value;
            }
        }

        public string StatusDate
        {
            get
            {
                return this.statusDateField;
            }
            set
            {
                this.statusDateField = value;
            }
        }

        public string PrintDate
        {
            get
            {
                return this.printDateField;
            }
            set
            {
                this.printDateField = value;
            }
        }

        public string InsuranceType
        {
            get
            {
                return this.insuranceTypeField;
            }
            set
            {
                this.insuranceTypeField = value;
            }
        }

        public string InsuranceTypeTxt
        {
            get
            {
                return this.insuranceTypeTxtField;
            }
            set
            {
                this.insuranceTypeTxtField = value;
            }
        }

        public string ProductGroup
        {
            get
            {
                return this.productGroupField;
            }
            set
            {
                this.productGroupField = value;
            }
        }

        public string ProductGroupTxt
        {
            get
            {
                return this.productGroupTxtField;
            }
            set
            {
                this.productGroupTxtField = value;
            }
        }

        public string PaymentSplitType
        {
            get
            {
                return this.paymentSplitTypeField;
            }
            set
            {
                this.paymentSplitTypeField = value;
            }
        }

        public string PaymentSplitTypeTxt
        {
            get
            {
                return this.paymentSplitTypeTxtField;
            }
            set
            {
                this.paymentSplitTypeTxtField = value;
            }
        }

        public string PaymentMethod
        {
            get
            {
                return this.paymentMethodField;
            }
            set
            {
                this.paymentMethodField = value;
            }
        }

        public string PaymentMethodTxt
        {
            get
            {
                return this.paymentMethodTxtField;
            }
            set
            {
                this.paymentMethodTxtField = value;
            }
        }

        public string PaymentClientTxt
        {
            get
            {
                return this.paymentClientTxtField;
            }
            set
            {
                this.paymentClientTxtField = value;
            }
        }

        public string BillingChannel
        {
            get
            {
                return this.billingChannelField;
            }
            set
            {
                this.billingChannelField = value;
            }
        }

        public string BillingChannelTxt
        {
            get
            {
                return this.billingChannelTxtField;
            }
            set
            {
                this.billingChannelTxtField = value;
            }
        }

        public string ReturnReason
        {
            get
            {
                return this.returnReasonField;
            }
            set
            {
                this.returnReasonField = value;
            }
        }

        //Add Field
        public string DescriptionReturnReason
        {
            get
            {
                return this.descriptionReturnReasonField;
            }
            set
            {
                this.descriptionReturnReasonField = value;
            }
        }

        public string ReturnDate
        {
            get
            {
                return this.returnDateField;
            }
            set
            {
                this.returnDateField = value;
            }
        }

        public string Currency
        {
            get
            {
                return this.currencyField;
            }
            set
            {
                this.currencyField = value;
            }
        }

        public decimal PremiumValue
        {
            get
            {
                return this.premiumValueField;
            }
            set
            {
                this.premiumValueField = value;
            }
        }

        public decimal ChargesValue
        {
            get
            {
                return this.chargesValueField;
            }
            set
            {
                this.chargesValueField = value;
            }
        }

        public decimal BonusValue
        {
            get
            {
                return this.bonusValueField;
            }
            set
            {
                this.bonusValueField = value;
            }
        }

        public decimal AtasValue
        {
            get
            {
                return this.atasValueField;
            }
            set
            {
                this.atasValueField = value;
            }
        }

        public decimal InemValue
        {
            get
            {
                return this.inemValueField;
            }
            set
            {
                this.inemValueField = value;
            }
        }

        public decimal FgaValue
        {
            get
            {
                return this.fgaValueField;
            }
            set
            {
                this.fgaValueField = value;
            }
        }

        public decimal GreenLetterValue
        {
            get
            {
                return this.greenLetterValueField;
            }
            set
            {
                this.greenLetterValueField = value;
            }
        }

        public decimal AnpcValue
        {
            get
            {
                return this.anpcValueField;
            }
            set
            {
                this.anpcValueField = value;
            }
        }

        public decimal SealValue
        {
            get
            {
                return this.sealValueField;
            }
            set
            {
                this.sealValueField = value;
            }
        }

        public decimal PolicyValue
        {
            get
            {
                return this.policyValueField;
            }
            set
            {
                this.policyValueField = value;
            }
        }

        public decimal FatValue
        {
            get
            {
                return this.fatValueField;
            }
            set
            {
                this.fatValueField = value;
            }
        }

        public decimal PrpValue
        {
            get
            {
                return this.prpValueField;
            }
            set
            {
                this.prpValueField = value;
            }
        }

        public decimal FractioningValue
        {
            get
            {
                return this.fractioningValueField;
            }
            set
            {
                this.fractioningValueField = value;
            }
        }

        public decimal CalamityValue
        {
            get
            {
                return this.calamityValueField;
            }
            set
            {
                this.calamityValueField = value;
            }
        }

        public decimal LatePaymentValue
        {
            get
            {
                return this.latePaymentValueField;
            }
            set
            {
                this.latePaymentValueField = value;
            }
        }

        public decimal MedicalExamValue
        {
            get
            {
                return this.medicalExamValueField;
            }
            set
            {
                this.medicalExamValueField = value;
            }
        }

        public decimal TgisValue
        {
            get
            {
                return this.tgisValueField;
            }
            set
            {
                this.tgisValueField = value;
            }
        }

        public decimal TotalAddValue
        {
            get
            {
                return this.totalAddValueField;
            }
            set
            {
                this.totalAddValueField = value;
            }
        }

        public decimal TotalCostValue
        {
            get
            {
                return this.totalCostValueField;
            }
            set
            {
                this.totalCostValueField = value;
            }
        }

        public decimal TotalTaxValue
        {
            get
            {
                return this.totalTaxValueField;
            }
            set
            {
                this.totalTaxValueField = value;
            }
        }

        public decimal TotalValue
        {
            get
            {
                return this.totalValueField;
            }
            set
            {
                this.totalValueField = value;
            }
        }

        public decimal CommissionPromotionValue
        {
            get
            {
                return this.commissionPromotionValueField;
            }
            set
            {
                this.commissionPromotionValueField = value;
            }
        }

        public decimal CommissionChargeValue
        {
            get
            {
                return this.commissionChargeValueField;
            }
            set
            {
                this.commissionChargeValueField = value;
            }
        }

        public decimal CommissionInspectionValue
        {
            get
            {
                return this.commissionInspectionValueField;
            }
            set
            {
                this.commissionInspectionValueField = value;
            }
        }

        public decimal CommissionAgentValue
        {
            get
            {
                return this.commissionAgentValueField;
            }
            set
            {
                this.commissionAgentValueField = value;
            }
        }

        public decimal CommissionOtherValue
        {
            get
            {
                return this.commissionOtherValueField;
            }
            set
            {
                this.commissionOtherValueField = value;
            }
        }

        public decimal CommissionTaxValue
        {
            get
            {
                return this.commissionTaxValueField;
            }
            set
            {
                this.commissionTaxValueField = value;
            }
        }

        public decimal TotalCommission
        {
            get
            {
                return this.totalCommissionField;
            }
            set
            {
                this.totalCommissionField = value;
            }
        }

        public decimal PolicyCapital
        {
            get
            {
                return this.policyCapitalField;
            }
            set
            {
                this.policyCapitalField = value;
            }
        }

        public string SibsEntity
        {
            get
            {
                return this.sibsEntityField;
            }
            set
            {
                this.sibsEntityField = value;
            }
        }

        public string SibsReference
        {
            get
            {
                return this.sibsReferenceField;
            }
            set
            {
                this.sibsReferenceField = value;
            }
        }

        public string SibsDueDate
        {
            get
            {
                return this.sibsDueDateField;
            }
            set
            {
                this.sibsDueDateField = value;
            }
        }

        public string SibsDueHour
        {
            get
            {
                return this.sibsDueHourField;
            }
            set
            {
                this.sibsDueHourField = value;
            }
        }

        public string SibsStatus
        {
            get
            {
                return this.sibsStatusField;
            }
            set
            {
                this.sibsStatusField = value;
            }
        }

        public string BankingCircuit
        {
            get
            {
                return this.bankingCircuitField;
            }
            set
            {
                this.bankingCircuitField = value;
            }
        }

        public string BankDetailsId
        {
            get
            {
                return this.bankDetailsIdField;
            }
            set
            {
                this.bankDetailsIdField = value;
            }
        }

        public string BankDesignation
        {
            get
            {
                return this.bankDesignationField;
            }
            set
            {
                this.bankDesignationField = value;
            }
        }

        public string BrokerReportIdentification
        {
            get
            {
                return this.brokerReportIdentificationField;
            }
            set
            {
                this.brokerReportIdentificationField = value;
            }
        }

        public string PremiumCategory
        {
            get
            {
                return this.premiumCategoryField;
            }
            set
            {
                this.premiumCategoryField = value;
            }
        }

        public string CommissionCategory
        {
            get
            {
                return this.commissionCategoryField;
            }
            set
            {
                this.commissionCategoryField = value;
            }
        }

        public string ClaimCategory
        {
            get
            {
                return this.claimCategoryField;
            }
            set
            {
                this.claimCategoryField = value;
            }
        }

        public string CostCategory
        {
            get
            {
                return this.costCategoryField;
            }
            set
            {
                this.costCategoryField = value;
            }
        }

        public string ContractType
        {
            get
            {
                return this.contractTypeField;
            }
            set
            {
                this.contractTypeField = value;
            }
        }

        public string Situation
        {
            get
            {
                return this.situationField;
            }
            set
            {
                this.situationField = value;
            }
        }

        public string SituationDate
        {
            get
            {
                return this.situationDateField;
            }
            set
            {
                this.situationDateField = value;
            }
        }

        public string OriginalAplication
        {
            get
            {
                return this.originalAplicationField;
            }
            set
            {
                this.originalAplicationField = value;
            }
        }

        public string DocumentId
        {
            get
            {
                return this.documentIdField;
            }
            set
            {
                this.documentIdField = value;
            }
        }

        public string LockId
        {
            get
            {
                return this.lockIdField;
            }
            set
            {
                this.lockIdField = value;
            }
        }

        public List<CoverageElements> Coverage { get => coverageField; set => coverageField = value; }

    }

    public partial class ZfscdCodigosErroLinha
    {

        private string errorCodeField;

        private string errorCodeTxtField;

        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }

    public partial class ZFscdRecibosListarWsResponse
    {
        private List<ZfscdRecibosWorkLinha> receiptsNumbersField;

        private List<CoverageElements> coverageField;

        public List<CoverageElements> Coverage { get => coverageField; set => coverageField = value; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public List<ErrorElement> Errors { get; set; }

        public List<ZfscdRecibosWorkLinha> ReceiptsNumbers
        {
            get
            {
                return this.receiptsNumbersField;
            }
            set
            {
                this.receiptsNumbersField = value;
            }
        }
    }

   
    //public partial class ZFscdRecibosListarWsResponse
    //{

    //    private List<ZfscdRecibosWorkLinha> receiptsNumbersField;

 
    //    private List<ErrorElement> errorsField;

    //    /// <summary>
    //    /// Gets or sets the receipts numbers.
    //    /// </summary>
    //    /// <value>
    //    /// The receipts numbers.
    //    /// </value>
    //    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
    //    public List<ZfscdRecibosWorkLinha> ReceiptsNumbers
    //    {
    //        get
    //        {
    //            return this.receiptsNumbersField;
    //        }
    //        set
    //        {
    //            this.receiptsNumbersField = value;
    //        }
    //    }

    //    /// <summary>
    //    /// Gets or sets the errors.
    //    /// </summary>
    //    /// <value>
    //    /// The errors.
    //    /// </value>
       
    //    public List<ErrorElement> Errors
    //    {
    //        get
    //        {
    //            return this.errorsField;
    //        }
    //        set
    //        {
    //            this.errorsField = value;
    //        }
    //    }


    //}

    public partial class ZFscdRecibosListarWsRequest
    {

        /// <summary>
        /// The z FSCD recibos listar ws
        /// </summary>
        public ZFscdRecibosListarWs ZFscdRecibosListarWs;

        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdRecibosListarWsRequest"/> class.
        /// </summary>
        public ZFscdRecibosListarWsRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ZFscdRecibosListarWsRequest"/> class.
        /// </summary>
        /// <param name="ZFscdRecibosListarWs">The z FSCD recibos listar ws.</param>
        public ZFscdRecibosListarWsRequest(ZFscdRecibosListarWs ZFscdRecibosListarWs)
        {
            this.ZFscdRecibosListarWs = ZFscdRecibosListarWs;
        }
    }
 

    public partial class ZFscdRecibosListarWsResponse1
    {
        public ZFscdRecibosListarWsResponse ZFscdRecibosListarWsResponse { get; set; }

        public ZFscdRecibosListarWsResponse1()
        {
        }
        
        public ZFscdRecibosListarWsResponse1(ZFscdRecibosListarWsResponse ZFscdRecibosListarWsResponse)
        {
            this.ZFscdRecibosListarWsResponse = ZFscdRecibosListarWsResponse;
        }
    }

    public partial class ZFscdRecibosSearchWs
    {

        private string brokerContractField;

        private string searchField;

        private string statusField;

       
        public string BrokerContract
        {
            get
            {
                return this.brokerContractField;
            }
            set
            {
                this.brokerContractField = value;
            }
        }

         
        public string Search
        {
            get
            {
                return this.searchField;
            }
            set
            {
                this.searchField = value;
            }
        }

       
        public string Status
        {
            get
            {
                return this.statusField;
            }
            set
            {
                this.statusField = value;
            }
        }
    }
 
    public partial class ZFscdRecibosSearchWsResponse
    {
        private ZfscdRecibosWorkLinha[] receiptsField;

        private ErrorElement[] errorsField;


     
        public ZfscdRecibosWorkLinha[] Receipts
        {
            get
            {
                return this.receiptsField;
            }
            set
            {
                this.receiptsField = value;
            }
        }

       
        public ErrorElement[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }
    }

   
    public partial class ZFscdRecibosSearchWsRequest
    {

       
        public ZFscdRecibosSearchWs ZFscdRecibosSearchWs;

        public ZFscdRecibosSearchWsRequest()
        {
        }

        public ZFscdRecibosSearchWsRequest(ZFscdRecibosSearchWs ZFscdRecibosSearchWs)
        {
            this.ZFscdRecibosSearchWs = ZFscdRecibosSearchWs;
        }
    }

   
    public partial class ZFscdRecibosSearchWsResponse1
    {

    
        public ZFscdRecibosSearchWsResponse ZFscdRecibosSearchWsResponse { get; set; }

        public ZFscdRecibosSearchWsResponse1()
        {
        }

        public ZFscdRecibosSearchWsResponse1(ZFscdRecibosSearchWsResponse ZFscdRecibosSearchWsResponse)
        {
            this.ZFscdRecibosSearchWsResponse = ZFscdRecibosSearchWsResponse;
        }
    }
}
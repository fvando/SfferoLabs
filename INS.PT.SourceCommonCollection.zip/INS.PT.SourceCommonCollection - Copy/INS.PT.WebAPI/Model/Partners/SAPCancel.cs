﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Helper.Validations;

namespace INS.PT.WebAPI.Model.Partners.Cancel
{
    public partial class ZFscdAnularApolicesPostWs
    {
        /// <summary>
        /// Gets or sets the policies.
        /// </summary>
        /// <value>
        /// The policies.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdAnuladosLinha Policies { get; set; }
    }

    public partial class ZfscdAnuladosLinha
    {
        /// <summary>
        /// Gets or sets the interface.
        /// </summary>
        /// <value>
        /// The interface.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Interface { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the destiny system.
        /// </summary>
        /// <value>
        /// The destiny system.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DestinySystem { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the transaction.
        /// </summary>
        /// <value>
        /// The transaction.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)] 
        public string Transaction { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the system date.
        /// </summary>
        /// <value>
        /// The system date.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)] 
        public string SystemDate { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the system time.
        /// </summary>
        /// <value>
        /// The system time.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)] 
        public string SystemTime { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the online.
        /// </summary>
        /// <value>
        /// The online.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)] 
        public string Online { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the items total.
        /// </summary>
        /// <value>
        /// The items total.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)] 
        public string ItemsTotal { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the policies.
        /// </summary>
        /// <value>
        /// The policies.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)] 
        public ZfscdAnuladoPolicy[] Policies { get; set; }
    }

    public partial class ZfscdAnuladoPolicy
    {
        /// <summary>
        /// Gets or sets the company code.
        /// </summary>
        /// <value>
        /// The company code.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyCode { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the network.
        /// </summary>
        /// <value>
        /// The network.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Network { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the policy.
        /// </summary>
        /// <value>
        /// The policy.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Policy { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the adherence.
        /// </summary>
        /// <value>
        /// The adherence.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Adherence { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the operation.
        /// </summary>
        /// <value>
        /// The operation.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Operation { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the operation date.
        /// </summary>
        /// <value>
        /// The operation date.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string OperationDate { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the receipts.
        /// </summary>
        /// <value>
        /// The receipts.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdAnuladoReceipt[] Receipts { get; set; }
    }

    public partial class ZfscdAnuladoReceipt
    {
        /// <summary>
        /// Gets or sets the reference document number.
        /// </summary>
        /// <value>
        /// The reference document number.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceDocumentNumber { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the type of the receipt.
        /// </summary>
        /// <value>
        /// The type of the receipt.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReceiptType { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the amount.
        /// </summary>
        /// <value>
        /// The amount.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal Amount { get; set; }
    }

    public partial class ZfscdCodigosErroLinhaAnularApolice
    {

        private string errorCodeField;

        private string errorCodeTxtField;

        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }

    public partial class ZfscdCodigosErroLinhaAnularLinha
    {

        private string errorCodeField;

        private string errorCodeTxtField;

        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }

    public partial class ZfscdCodigosErroLinhaAnularDatas
    {

        private string errorCodeField;

        private string errorCodeTxtField;

        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }

    public partial class ZfscdCodigosErroLinhaAnularRecibo
    {

        private string errorCodeField;

        private string errorCodeTxtField;

        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }

    //ZfscdCodigosErroLinhaAnularApolice
    //ZfscdCodigosErroLinhaAnularData
    //ZfscdCodigosErroLinhaAnularLinha
    
    public partial class ZFscdAnularApolicesPostWsResponse
    {

        private ZfscdCodigosErroLinhaAnularApolice[] errorsField;

        private ZfscdAnuladosLinha policiesField;

        public ZfscdCodigosErroLinhaAnularApolice[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }

        public ZfscdAnuladosLinha Policies
        {
            get
            {
                return this.policiesField;
            }
            set
            {
                this.policiesField = value;
            }
        }
    }

    public partial class ZFscdAnularApolicesPostWsRequest
    {

        public INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWs ZFscdAnularApolicesPostWs;

        public ZFscdAnularApolicesPostWsRequest()
        {
        }

        public ZFscdAnularApolicesPostWsRequest(INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWs ZFscdAnularApolicesPostWs)
        {
            this.ZFscdAnularApolicesPostWs = ZFscdAnularApolicesPostWs;
        }
    }

    public partial class ZFscdAnularApolicesPostWsResponse1
    {

        public INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWsResponse ZFscdAnularApolicesPostWsResponse { get; set; }

        public ZFscdAnularApolicesPostWsResponse1()
        {
        }

        public ZFscdAnularApolicesPostWsResponse1(INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWsResponse ZFscdAnularApolicesPostWsResponse)
        {
            this.ZFscdAnularApolicesPostWsResponse = ZFscdAnularApolicesPostWsResponse;
        }
    }

    public partial class ZFscdAnularRecibosPostWs
    {
        /// <summary>
        /// Gets or sets the receipts.
        /// </summary>
        /// <value>
        /// The receipts.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdAnuladosLinha Receipts { get; set; }
    }

    public partial class ZFscdAnularRecibosPostWsResponse
    {

        private ZfscdCodigosErroLinhaAnularRecibo[] errorsField;

        private ZfscdAnuladosLinha receiptsField;

        public ZfscdCodigosErroLinhaAnularRecibo[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }

        public ZfscdAnuladosLinha Receipts
        {
            get
            {
                return this.receiptsField;
            }
            set
            {
                this.receiptsField = value;
            }
        }
    }

    public partial class ZFscdAnularRecibosPostWsRequest
    {

        public INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWs ZFscdAnularRecibosPostWs;

        public ZFscdAnularRecibosPostWsRequest()
        {
        }

        public ZFscdAnularRecibosPostWsRequest(INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWs ZFscdAnularRecibosPostWs)
        {
            this.ZFscdAnularRecibosPostWs = ZFscdAnularRecibosPostWs;
        }
    }

    public partial class ZFscdAnularRecibosPostWsResponse1
    {

        public INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWsResponse ZFscdAnularRecibosPostWsResponse { get; set; }

        public ZFscdAnularRecibosPostWsResponse1()
        {
        }

        public ZFscdAnularRecibosPostWsResponse1(INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWsResponse ZFscdAnularRecibosPostWsResponse)
        {
            this.ZFscdAnularRecibosPostWsResponse = ZFscdAnularRecibosPostWsResponse;
        }
    }

    public partial class ZFscdAnularDatasPostWs
    {
        /// <summary>
        /// Gets or sets the receipts.
        /// </summary>
        /// <value>
        /// The receipts.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdAnuladosLinha Receipts { get; set; }

    }

    public partial class ZFscdAnularDatasPostWsResponse
    {

        private ZfscdCodigosErroLinhaAnularDatas[] errorsField;

        private ZfscdAnuladosLinha receiptsField;

        public ZfscdCodigosErroLinhaAnularDatas[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }

        public ZfscdAnuladosLinha Receipts
        {
            get
            {
                return this.receiptsField;
            }
            set
            {
                this.receiptsField = value;
            }
        }
    }

    public partial class ZFscdAnularDatasPostWsRequest
    {

        public INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularDatasPostWs ZFscdAnularDatasPostWs;

        public ZFscdAnularDatasPostWsRequest()
        {
        }

        public ZFscdAnularDatasPostWsRequest(INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularDatasPostWs ZFscdAnularDatasPostWs)
        {
            this.ZFscdAnularDatasPostWs = ZFscdAnularDatasPostWs;
        }
    }

    public partial class ZFscdAnularDatasPostWsResponse1
    {

        public INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularDatasPostWsResponse ZFscdAnularDatasPostWsResponse { get; set; }

        public ZFscdAnularDatasPostWsResponse1()
        {
        }

        public ZFscdAnularDatasPostWsResponse1(INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularDatasPostWsResponse ZFscdAnularDatasPostWsResponse)
        {
            this.ZFscdAnularDatasPostWsResponse = ZFscdAnularDatasPostWsResponse;
        }
    }

}

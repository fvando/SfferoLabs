﻿
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Model.Partners.ProvisionWebAccount
{
    /// <summary>
    /// ZfscdCodigosErroProvisionLinhaCobrar
    /// </summary>
    public class ZfscdCodigosErroProvisionLinhaCobrar
    {

        private string errorCodeField;

        private string errorCodeTxtField;

        /// <summary>
        /// Gets or sets the error code.
        /// </summary>
        /// <value>
        /// The error code.
        /// </value>
        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

        /// <summary>
        /// Gets or sets the error code text.
        /// </summary>
        /// <value>
        /// The error code text.
        /// </value>
        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }

    /// <summary>
    /// ZfscdCodigosErroProvisionLinhaConsultar
    /// </summary>
    public partial class ZfscdCodigosErroProvisionLinhaConsultar
    {

        private string errorCodeField;

        private string errorCodeTxtField;

        /// <summary>
        /// Gets or sets the error code.
        /// </summary>
        /// <value>
        /// The error code.
        /// </value>
        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

        /// <summary>
        /// Gets or sets the error code text.
        /// </summary>
        /// <value>
        /// The error code text.
        /// </value>
        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }

    /// <summary>
    /// ZfscdCodigosErroProvisionLinhaEliminar
    /// </summary>
    public class ZfscdCodigosErroProvisionLinhaEliminar
    {

        private string errorCodeField;

        private string errorCodeTxtField;

        /// <summary>
        /// Gets or sets the error code.
        /// </summary>
        /// <value>
        /// The error code.
        /// </value>
        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

        /// <summary>
        /// Gets or sets the error code text.
        /// </summary>
        /// <value>
        /// The error code text.
        /// </value>
        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }

    /// <summary>
    /// ZfscdCodigosErroProvisionLinhaLiquidar
    /// </summary>
    public class ZfscdCodigosErroProvisionLinhaLiquidar
    {

        private string errorCodeField;

        private string errorCodeTxtField;

        /// <summary>
        /// Gets or sets the error code.
        /// </summary>
        /// <value>
        /// The error code.
        /// </value>
        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

        /// <summary>
        /// Gets or sets the error code text.
        /// </summary>
        /// <value>
        /// The error code text.
        /// </value>
        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }

    /// <summary>
    /// ZfscdCodigosErroProvisionLinhaValidar
    /// </summary>
    public class ZfscdCodigosErroProvisionLinhaValidar
    {

        private string errorCodeField;

        private string errorCodeTxtField;

        /// <summary>
        /// Gets or sets the error code.
        /// </summary>
        /// <value>
        /// The error code.
        /// </value>
        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

        /// <summary>
        /// Gets or sets the error code text.
        /// </summary>
        /// <value>
        /// The error code text.
        /// </value>
        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }

    /// <summary>
    /// ZfscdCodigosErroProvisionLinhaListar
    /// </summary>
    public partial class ZfscdCodigosErroProvisionLinhaListar
    {

        private string errorCodeField;

        private string errorCodeTxtField;

        /// <summary>
        /// Gets or sets the error code.
        /// </summary>
        /// <value>
        /// The error code.
        /// </value>
        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

        /// <summary>
        /// Gets or sets the error code text.
        /// </summary>
        /// <value>
        /// The error code text.
        /// </value>
        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }

    /// <summary>
    /// ZfscdCodigosErroProvisionLinhaIndicadores
    /// </summary>
    public class ZfscdCodigosErroProvisionLinhaIndicadores
    {

        private string errorCodeField;

        private string errorCodeTxtField;


        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }

    /// <summary>
    /// ZfscdCodigosErroProvisionLinhaContaEfetiva
    /// </summary>
    public class ZfscdCodigosErroProvisionLinhaContaEfetiva
    {

        private string errorCodeField;

        private string errorCodeTxtField;

        /// <summary>
        /// Gets or sets the error code.
        /// </summary>
        /// <value>
        /// The error code.
        /// </value>
        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

        /// <summary>
        /// Gets or sets the error code text.
        /// </summary>
        /// <value>
        /// The error code text.
        /// </value>
        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }

    /// <summary>
    /// ZfscdCodigosErroProvisionRecibosLinha
    /// </summary>
    public class ZfscdCodigosErroProvisionRecibosLinha
    {

        private string errorCodeField;

        private string errorCodeTxtField;

      
        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

      
        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }

    /// <summary>
    /// ZfscdCodigosErroProvisionLinhaAggregateReceipts
    /// </summary>
    public class ZfscdCodigosErroProvisionLinhaAggregateReceipts
    {

        private string errorCodeField;

        private string errorCodeTxtField;

       
        public string ErrorCode
        {
            get
            {
                return this.errorCodeField;
            }
            set
            {
                this.errorCodeField = value;
            }
        }

      
        public string ErrorCodeTxt
        {
            get
            {
                return this.errorCodeTxtField;
            }
            set
            {
                this.errorCodeTxtField = value;
            }
        }
    }

    /// <summary>
    /// ZFscdPcConsultarWs
    /// </summary>
    public partial class ZFscdPcConsultarWs
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerContract { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerReport { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ViewDeleted { get; set; } = String.Empty;
    }

    /// <summary>
    /// ZfscdPcBrokerLinha
    /// </summary>
    public partial class ZfscdPcBrokerLinha
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerContract { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public int Vida { get; set; } 

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public int Nvida { get; set; } 

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public int Total { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal TotalVida { get; set; } 

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal TotalNvida { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal TotalSum { get; set; }

    }

    /// <summary>
    /// ZfscdPcRecibosAgregados
    /// </summary>
    public partial class ZfscdPcRecibosAgregados
    {

        private string insuredField;

        private string policyField;

        private string referenceDocumentNumberField;

        private string includeAfField;

        private decimal premiumTotalField;

        private decimal commissionTotalField;

        private decimal claimTotalField;

        private decimal sumTotalField;

        private decimal irsTotalField;

        private decimal stampTotalField;

        private decimal ssTotalField;

        private decimal ivaTotalField;

        private string reportSubitemNumberField;

        private string receiptStatusField;

        private string receiptStatusTxtField;

        private string receiptPayTxtField;

        public string Insured
        {
            get
            {
                return this.insuredField;
            }
            set
            {
                this.insuredField = value;
            }
        }

        public string Policy
        {
            get
            {
                return this.policyField;
            }
            set
            {
                this.policyField = value;
            }
        }

        public string ReferenceDocumentNumber
        {
            get
            {
                return this.referenceDocumentNumberField;
            }
            set
            {
                this.referenceDocumentNumberField = value;
            }
        }

        public string IncludeAf
        {
            get
            {
                return this.includeAfField;
            }
            set
            {
                this.includeAfField = value;
            }
        }

        public decimal PremiumTotal
        {
            get
            {
                return this.premiumTotalField;
            }
            set
            {
                this.premiumTotalField = value;
            }
        }

        public decimal CommissionTotal
        {
            get
            {
                return this.commissionTotalField;
            }
            set
            {
                this.commissionTotalField = value;
            }
        }

        public decimal ClaimTotal
        {
            get
            {
                return this.claimTotalField;
            }
            set
            {
                this.claimTotalField = value;
            }
        }

        public decimal SumTotal
        {
            get
            {
                return this.sumTotalField;
            }
            set
            {
                this.sumTotalField = value;
            }
        }

        public decimal IrsTotal
        {
            get
            {
                return this.irsTotalField;
            }
            set
            {
                this.irsTotalField = value;
            }
        }

        public decimal StampTotal
        {
            get
            {
                return this.stampTotalField;
            }
            set
            {
                this.stampTotalField = value;
            }
        }

        public decimal SsTotal
        {
            get
            {
                return this.ssTotalField;
            }
            set
            {
                this.ssTotalField = value;
            }
        }

        public decimal IvaTotal
        {
            get
            {
                return this.ivaTotalField;
            }
            set
            {
                this.ivaTotalField = value;
            }
        }

      
        public string ReportSubitemNumber
        {
            get
            {
                return this.reportSubitemNumberField;
            }
            set
            {
                this.reportSubitemNumberField = value;
            }
        }

      
        public string ReceiptStatus
        {
            get
            {
                return this.receiptStatusField;
            }
            set
            {
                this.receiptStatusField = value;
            }
        }

     
        public string ReceiptStatusTxt
        {
            get
            {
                return this.receiptStatusTxtField;
            }
            set
            {
                this.receiptStatusTxtField = value;
            }
        }
 
        public string ReceiptPayTxt
        {
            get
            {
                return this.receiptPayTxtField;
            }
            set
            {
                this.receiptPayTxtField = value;
            }
        }

    }


    public partial class ZfscdPcReceiptsDel
    {

        private string referenceDocumentNumberField;

        private string receiptStatusField;

        private string receiptStatusTxtField;

        private string receiptPayTxtField;

 
        public string ReferenceDocumentNumber
        {
            get
            {
                return this.referenceDocumentNumberField;
            }
            set
            {
                this.referenceDocumentNumberField = value;
            }
        }

   
        public string ReceiptStatus
        {
            get
            {
                return this.receiptStatusField;
            }
            set
            {
                this.receiptStatusField = value;
            }
        }

  
        public string ReceiptStatusTxt
        {
            get
            {
                return this.receiptStatusTxtField;
            }
            set
            {
                this.receiptStatusTxtField = value;
            }
        }

 
        public string ReceiptPayTxt
        {
            get
            {
                return this.receiptPayTxtField;
            }
            set
            {
                this.receiptPayTxtField = value;
            }
        }
    }


    /// <summary>
    /// ZfscdPcPaymentsValues
    /// </summary>
    public partial class ZfscdPcPaymentsValues
    {

        private string payMethod1Field;

        private decimal valuePay1Field;

        private string payMethod2Field;

        private decimal valuePay2Field;

        private string entSibsField;

        private string refSibsField;

        private decimal totalValueField;

        public string PayMethod1
        {
            get
            {
                return this.payMethod1Field;
            }
            set
            {
                this.payMethod1Field = value;
            }
        }

        public decimal ValuePay1
        {
            get
            {
                return this.valuePay1Field;
            }
            set
            {
                this.valuePay1Field = value;
            }
        }

        public string PayMethod2
        {
            get
            {
                return this.payMethod2Field;
            }
            set
            {
                this.payMethod2Field = value;
            }
        }

        public decimal ValuePay2
        {
            get
            {
                return this.valuePay2Field;
            }
            set
            {
                this.valuePay2Field = value;
            }
        }

        public string EntSibs
        {
            get
            {
                return this.entSibsField;
            }
            set
            {
                this.entSibsField = value;
            }
        }

        public string RefSibs
        {
            get
            {
                return this.refSibsField;
            }
            set
            {
                this.refSibsField = value;
            }
        }

        public decimal TotalValue
        {
            get
            {
                return this.totalValueField;
            }
            set
            {
                this.totalValueField = value;
            }
        }
    }

    /// <summary>
    /// Zcd2GrouptTotalsS
    /// </summary>
    public partial class Zcd2GrouptTotalsS
    {

        private string companyCodeField;

        private string agentField;

        private string docGroupField;

        private decimal totalAmountField;

        private decimal totalAmountPcField;

        private decimal totalAmountAfField;

        private int docCountField;

        public string CompanyCode
        {
            get
            {
                return this.companyCodeField;
            }
            set
            {
                this.companyCodeField = value;
            }
        }

        public string Agent
        {
            get
            {
                return this.agentField;
            }
            set
            {
                this.agentField = value;
            }
        }

        public string DocGroup
        {
            get
            {
                return this.docGroupField;
            }
            set
            {
                this.docGroupField = value;
            }
        }

        public decimal TotalAmount
        {
            get
            {
                return this.totalAmountField;
            }
            set
            {
                this.totalAmountField = value;
            }
        }

        public decimal TotalAmountPc
        {
            get
            {
                return this.totalAmountPcField;
            }
            set
            {
                this.totalAmountPcField = value;
            }
        }

        public decimal TotalAmountAf
        {
            get
            {
                return this.totalAmountAfField;
            }
            set
            {
                this.totalAmountAfField = value;
            }
        }

        public int DocCount
        {
            get
            {
                return this.docCountField;
            }
            set
            {
                this.docCountField = value;
            }
        }
    }

    /// <summary>
    /// ZfscdCodigosErroRecibos
    /// </summary>
    public partial class ZfscdCodigosErroRecibos
    {

        private string receiptField;

        private ZfscdCodigosErroProvisionRecibosLinha[] errorsField;

      
        public string Receipt
        {
            get
            {
                return this.receiptField;
            }
            set
            {
                this.receiptField = value;
            }
        }

     
        public ZfscdCodigosErroProvisionRecibosLinha[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }
    }

    /// <summary>
    /// ZfscdPcRecibosLinha
    /// </summary>
    public partial class ZfscdPcRecibosLinha
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceBroker { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyCode { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DocumentType { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceDocumentNumber { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SapDocumentNumber { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DocumentNumber { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsurancePartner { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceObject { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal Amount { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Currency { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string VwReference { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string VwPolicy { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string VwPostDate { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string VwNetDueDate { get; set; } = String.Empty;
    }





    /// <summary>
    /// ZfscdPcPaymentsValReturn
    /// </summary>
    public partial class ZfscdPcPaymentsValReturn
    {

        private string payMethod1Field;

        private decimal valuePay1Field;

        private string payMethod1TxtField;

        private string payMethod2Field;

        private decimal valuePay2Field;

        private string payMethod2TxtField;

        private string entSibsField;

        private string refSibsField;

        private decimal totalValueField;

     
        public string PayMethod1
        {
            get
            {
                return this.payMethod1Field;
            }
            set
            {
                this.payMethod1Field = value;
            }
        }

      
        public decimal ValuePay1
        {
            get
            {
                return this.valuePay1Field;
            }
            set
            {
                this.valuePay1Field = value;
            }
        }

      
        public string PayMethod1Txt
        {
            get
            {
                return this.payMethod1TxtField;
            }
            set
            {
                this.payMethod1TxtField = value;
            }
        }

      
        public string PayMethod2
        {
            get
            {
                return this.payMethod2Field;
            }
            set
            {
                this.payMethod2Field = value;
            }
        }
 
        public decimal ValuePay2
        {
            get
            {
                return this.valuePay2Field;
            }
            set
            {
                this.valuePay2Field = value;
            }
        }

      
        public string PayMethod2Txt
        {
            get
            {
                return this.payMethod2TxtField;
            }
            set
            {
                this.payMethod2TxtField = value;
            }
        }

       
        public string EntSibs
        {
            get
            {
                return this.entSibsField;
            }
            set
            {
                this.entSibsField = value;
            }
        }

       
        public string RefSibs
        {
            get
            {
                return this.refSibsField;
            }
            set
            {
                this.refSibsField = value;
            }
        }

      
        public decimal TotalValue
        {
            get
            {
                return this.totalValueField;
            }
            set
            {
                this.totalValueField = value;
            }
        }
    }

    /// <summary>
    /// ZfscdPcHeaderLinha
    /// </summary>
    public partial class ZfscdPcHeaderLinha
    {

        private string brokerReportField;

        private string searchTermField;

        private string statusField;

        private string statusDescriptionField;

        private string statusDateField;

        private string brokerField;

        private string brokerContractField;

        private string fullNameField;

        private string periodFromField;

        private string billingPeriodToField;

        private string reportTypeField;

        private string initReasonField;

        private string brokerReportOriginField;

        private string initDateField;

        private string companyCodeField;

        private string postingDateField;

        private string documentDateField;

        private string netDueDateField;

        private string versionField;

        private string createNameField;

        private string createDateField;

        private string createTimeField;

        private string changeNameField;

        private string changeDateField;

        private string changeTimeField;

        private decimal receiptAmountField;

        private decimal comissionAmountField;

        private decimal opsAmmountField;

        private decimal costAmountField;

        private decimal premiumTotalField;

        private decimal commissionTotalField;

        private decimal reversalTotalField;

        private decimal opsTotalPayedField;

        private decimal costTotalField;

        private decimal irsTotalField;

        private decimal stampTotalField;

        private decimal ssTotalField;

        private decimal registryAmountField;

        private decimal registryTotalField;

        private string currencyField;

        private decimal controlSumField;

        private decimal controlNumberField;

        private string branchDescriptonField;

        private ZfscdPcPaymentsValReturn paymentMethodsField;

        public string BrokerReport
        {
            get
            {
                return this.brokerReportField;
            }
            set
            {
                this.brokerReportField = value;
            }
        }

        public string SearchTerm
        {
            get
            {
                return this.searchTermField;
            }
            set
            {
                this.searchTermField = value;
            }
        }

        public string Status
        {
            get
            {
                return this.statusField;
            }
            set
            {
                this.statusField = value;
            }
        }

        public string StatusDescription
        {
            get
            {
                return this.statusDescriptionField;
            }
            set
            {
                this.statusDescriptionField = value;
            }
        }

        public string StatusDate
        {
            get
            {
                return this.statusDateField;
            }
            set
            {
                this.statusDateField = value;
            }
        }

        public string Broker
        {
            get
            {
                return this.brokerField;
            }
            set
            {
                this.brokerField = value;
            }
        }

        public string BrokerContract
        {
            get
            {
                return this.brokerContractField;
            }
            set
            {
                this.brokerContractField = value;
            }
        }

        public string FullName
        {
            get
            {
                return this.fullNameField;
            }
            set
            {
                this.fullNameField = value;
            }
        }

        public string PeriodFrom
        {
            get
            {
                return this.periodFromField;
            }
            set
            {
                this.periodFromField = value;
            }
        }

        public string BillingPeriodTo
        {
            get
            {
                return this.billingPeriodToField;
            }
            set
            {
                this.billingPeriodToField = value;
            }
        }

        public string ReportType
        {
            get
            {
                return this.reportTypeField;
            }
            set
            {
                this.reportTypeField = value;
            }
        }

        public string InitReason
        {
            get
            {
                return this.initReasonField;
            }
            set
            {
                this.initReasonField = value;
            }
        }

        public string BrokerReportOrigin
        {
            get
            {
                return this.brokerReportOriginField;
            }
            set
            {
                this.brokerReportOriginField = value;
            }
        }

        public string InitDate
        {
            get
            {
                return this.initDateField;
            }
            set
            {
                this.initDateField = value;
            }
        }

        public string CompanyCode
        {
            get
            {
                return this.companyCodeField;
            }
            set
            {
                this.companyCodeField = value;
            }
        }

        public string PostingDate
        {
            get
            {
                return this.postingDateField;
            }
            set
            {
                this.postingDateField = value;
            }
        }

        public string DocumentDate
        {
            get
            {
                return this.documentDateField;
            }
            set
            {
                this.documentDateField = value;
            }
        }

        public string NetDueDate
        {
            get
            {
                return this.netDueDateField;
            }
            set
            {
                this.netDueDateField = value;
            }
        }

        public string Version
        {
            get
            {
                return this.versionField;
            }
            set
            {
                this.versionField = value;
            }
        }

        public string CreateName
        {
            get
            {
                return this.createNameField;
            }
            set
            {
                this.createNameField = value;
            }
        }

        public string CreateDate
        {
            get
            {
                return this.createDateField;
            }
            set
            {
                this.createDateField = value;
            }
        }

        public string CreateTime
        {
            get
            {
                return this.createTimeField;
            }
            set
            {
                this.createTimeField = value;
            }
        }

        public string ChangeName
        {
            get
            {
                return this.changeNameField;
            }
            set
            {
                this.changeNameField = value;
            }
        }

        public string ChangeDate
        {
            get
            {
                return this.changeDateField;
            }
            set
            {
                this.changeDateField = value;
            }
        }

        public string ChangeTime
        {
            get
            {
                return this.changeTimeField;
            }
            set
            {
                this.changeTimeField = value;
            }
        }

        public decimal ReceiptAmount
        {
            get
            {
                return this.receiptAmountField;
            }
            set
            {
                this.receiptAmountField = value;
            }
        }

        public decimal ComissionAmount
        {
            get
            {
                return this.comissionAmountField;
            }
            set
            {
                this.comissionAmountField = value;
            }
        }

        public decimal OpsAmmount
        {
            get
            {
                return this.opsAmmountField;
            }
            set
            {
                this.opsAmmountField = value;
            }
        }

        public decimal CostAmount
        {
            get
            {
                return this.costAmountField;
            }
            set
            {
                this.costAmountField = value;
            }
        }

        public decimal PremiumTotal
        {
            get
            {
                return this.premiumTotalField;
            }
            set
            {
                this.premiumTotalField = value;
            }
        }

        public decimal CommissionTotal
        {
            get
            {
                return this.commissionTotalField;
            }
            set
            {
                this.commissionTotalField = value;
            }
        }

        public decimal ReversalTotal
        {
            get
            {
                return this.reversalTotalField;
            }
            set
            {
                this.reversalTotalField = value;
            }
        }

        public decimal OpsTotalPayed
        {
            get
            {
                return this.opsTotalPayedField;
            }
            set
            {
                this.opsTotalPayedField = value;
            }
        }

        public decimal CostTotal
        {
            get
            {
                return this.costTotalField;
            }
            set
            {
                this.costTotalField = value;
            }
        }

        public decimal IrsTotal
        {
            get
            {
                return this.irsTotalField;
            }
            set
            {
                this.irsTotalField = value;
            }
        }

        public decimal StampTotal
        {
            get
            {
                return this.stampTotalField;
            }
            set
            {
                this.stampTotalField = value;
            }
        }

        public decimal SsTotal
        {
            get
            {
                return this.ssTotalField;
            }
            set
            {
                this.ssTotalField = value;
            }
        }

        public decimal RegistryAmount
        {
            get
            {
                return this.registryAmountField;
            }
            set
            {
                this.registryAmountField = value;
            }
        }

        public decimal RegistryTotal
        {
            get
            {
                return this.registryTotalField;
            }
            set
            {
                this.registryTotalField = value;
            }
        }

        public string Currency
        {
            get
            {
                return this.currencyField;
            }
            set
            {
                this.currencyField = value;
            }
        }

        public decimal ControlSum
        {
            get
            {
                return this.controlSumField;
            }
            set
            {
                this.controlSumField = value;
            }
        }

        public decimal ControlNumber
        {
            get
            {
                return this.controlNumberField;
            }
            set
            {
                this.controlNumberField = value;
            }
        }

        public string BranchDescripton
        {
            get
            {
                return this.branchDescriptonField;
            }
            set
            {
                this.branchDescriptonField = value;
            }
        }

        public ZfscdPcPaymentsValReturn PaymentMethods
        {
            get
            {
                return this.paymentMethodsField;
            }
            set
            {
                this.paymentMethodsField = value;
            }
        }
    }

    /// <summary>
    /// ZfscdPcDetailLinha
    /// </summary>
    public partial class ZfscdPcDetailLinha
    {

        private string brokerReportField;

        private string reportItemField;

        private string reportItemCategoryField;

        private string reportItemSubcategoryField;

        private string reportSubitemNumberField;

        private string selectionsField;

        private string multipleGroupsSelectedField;

        private string coinsShareFlagField;

        private string postingStatusField;

        private string confirmationStatusField;

        private string brokerField;

        private string insuranceBrokerField;

        private string documentTypeField;

        private string documentNumberField;

        private string referenceDocumentNumberField;

        private string sapDocumentNumberField;

        private string receiptTypeField;

        private string receiptTypeTxtField;

        private string netDueDateField;

        private string partnerField;

        private string fullNameField;

        private string insuranceObjectField;

        private string insuranceObjectCategoryField;

        private string contractAccountField;

        private decimal totalCommissionField;

        private decimal amountField;

        private string currencyField;

        private string receiptStatusField;

        private string receiptStatusTxtField;

        private string receiptPayTxtField;


        public string BrokerReport
        {
            get
            {
                return this.brokerReportField;
            }
            set
            {
                this.brokerReportField = value;
            }
        }

       
        public string ReportItem
        {
            get
            {
                return this.reportItemField;
            }
            set
            {
                this.reportItemField = value;
            }
        }

       
        public string ReportItemCategory
        {
            get
            {
                return this.reportItemCategoryField;
            }
            set
            {
                this.reportItemCategoryField = value;
            }
        }

      
        public string ReportItemSubcategory
        {
            get
            {
                return this.reportItemSubcategoryField;
            }
            set
            {
                this.reportItemSubcategoryField = value;
            }
        }

     
        public string ReportSubitemNumber
        {
            get
            {
                return this.reportSubitemNumberField;
            }
            set
            {
                this.reportSubitemNumberField = value;
            }
        }

       
        public string Selections
        {
            get
            {
                return this.selectionsField;
            }
            set
            {
                this.selectionsField = value;
            }
        }

       
        public string MultipleGroupsSelected
        {
            get
            {
                return this.multipleGroupsSelectedField;
            }
            set
            {
                this.multipleGroupsSelectedField = value;
            }
        }

     
        public string CoinsShareFlag
        {
            get
            {
                return this.coinsShareFlagField;
            }
            set
            {
                this.coinsShareFlagField = value;
            }
        }

     
        public string PostingStatus
        {
            get
            {
                return this.postingStatusField;
            }
            set
            {
                this.postingStatusField = value;
            }
        }

      
        public string ConfirmationStatus
        {
            get
            {
                return this.confirmationStatusField;
            }
            set
            {
                this.confirmationStatusField = value;
            }
        }

      
        public string Broker
        {
            get
            {
                return this.brokerField;
            }
            set
            {
                this.brokerField = value;
            }
        }

      
        public string InsuranceBroker
        {
            get
            {
                return this.insuranceBrokerField;
            }
            set
            {
                this.insuranceBrokerField = value;
            }
        }

     
        public string DocumentType
        {
            get
            {
                return this.documentTypeField;
            }
            set
            {
                this.documentTypeField = value;
            }
        }

       
        public string DocumentNumber
        {
            get
            {
                return this.documentNumberField;
            }
            set
            {
                this.documentNumberField = value;
            }
        }

      
        public string ReferenceDocumentNumber
        {
            get
            {
                return this.referenceDocumentNumberField;
            }
            set
            {
                this.referenceDocumentNumberField = value;
            }
        }

       
        public string SapDocumentNumber
        {
            get
            {
                return this.sapDocumentNumberField;
            }
            set
            {
                this.sapDocumentNumberField = value;
            }
        }

       
        public string ReceiptType
        {
            get
            {
                return this.receiptTypeField;
            }
            set
            {
                this.receiptTypeField = value;
            }
        }

       
        public string ReceiptTypeTxt
        {
            get
            {
                return this.receiptTypeTxtField;
            }
            set
            {
                this.receiptTypeTxtField = value;
            }
        }

        
        public string NetDueDate
        {
            get
            {
                return this.netDueDateField;
            }
            set
            {
                this.netDueDateField = value;
            }
        }

        
        public string Partner
        {
            get
            {
                return this.partnerField;
            }
            set
            {
                this.partnerField = value;
            }
        }

        public string FullName
        {
            get
            {
                return this.fullNameField;
            }
            set
            {
                this.fullNameField = value;
            }
        }

        public string InsuranceObject
        {
            get
            {
                return this.insuranceObjectField;
            }
            set
            {
                this.insuranceObjectField = value;
            }
        }

        public string InsuranceObjectCategory
        {
            get
            {
                return this.insuranceObjectCategoryField;
            }
            set
            {
                this.insuranceObjectCategoryField = value;
            }
        }

        
        public string ContractAccount
        {
            get
            {
                return this.contractAccountField;
            }
            set
            {
                this.contractAccountField = value;
            }
        }
 
        public decimal TotalCommission
        {
            get
            {
                return this.totalCommissionField;
            }
            set
            {
                this.totalCommissionField = value;
            }
        }

       
        public decimal Amount
        {
            get
            {
                return this.amountField;
            }
            set
            {
                this.amountField = value;
            }
        }

      
        public string Currency
        {
            get
            {
                return this.currencyField;
            }
            set
            {
                this.currencyField = value;
            }
        }

        public string ReceiptStatus
        {
            get
            {
                return this.receiptStatusField;
            }
            set
            {
                this.receiptStatusField = value;
            }
        }

        public string ReceiptStatusTxt
        {
            get
            {
                return this.receiptStatusTxtField;
            }
            set
            {
                this.receiptStatusTxtField = value;
            }
        }

        public string ReceiptPayTxt
        {
            get
            {
                return this.receiptPayTxtField;
            }
            set
            {
                this.receiptPayTxtField = value;
            }
        }

    }

    /// <summary>
    /// ZFscdPcConsultarWsResponse
    /// </summary>
    public partial class ZFscdPcConsultarWsResponse
    {
        public ZfscdCodigosErroProvisionLinhaConsultar[] Errors { get; set; }

        public ZfscdPcDetailLinha[] PcDetail { get; set; }

        public ZfscdPcHeaderLinha PcHeader { get; set; }

        public ZfscdPcReceiptsDel[] PcReceiptDel { get; set; }
    }

    /// <summary>
    /// ZFscdPcConsultarWsRequest
    /// </summary>
    public partial class ZFscdPcConsultarWsRequest
    {

      
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWs ZFscdPcConsultarWs;

        public ZFscdPcConsultarWsRequest()
        {
        }

        public ZFscdPcConsultarWsRequest(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWs ZFscdPcConsultarWs)
        {
            this.ZFscdPcConsultarWs = ZFscdPcConsultarWs;
        }
    }

    /// <summary>
    /// ZFscdPcConsultarWsResponse1
    /// </summary>
    public partial class ZFscdPcConsultarWsResponse1
    {

    
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWsResponse ZFscdPcConsultarWsResponse { get; set; }

        public ZFscdPcConsultarWsResponse1()
        {
        }

        public ZFscdPcConsultarWsResponse1(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWsResponse ZFscdPcConsultarWsResponse)
        {
            this.ZFscdPcConsultarWsResponse = ZFscdPcConsultarWsResponse;
        }
    }

    /// <summary>
    /// ZFscdPcCobrarWs
    /// </summary>
    public partial class ZFscdPcCobrarWs
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerContract { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdPcRecibosLinha[] PcReceipts { get; set; }
    }

    /// <summary>
    /// ZFscdPcCobrarWsResponse
    /// </summary>
    public partial class ZFscdPcCobrarWsResponse
    {
        public ZfscdCodigosErroRecibos[] Errors { get; set; }
    }

    /// <summary>
    /// ZFscdPcCobrarWsRequest
    /// </summary>
    public partial class ZFscdPcCobrarWsRequest
    {

     
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWs ZFscdPcCobrarWs;

        public ZFscdPcCobrarWsRequest()
        {
        }

        public ZFscdPcCobrarWsRequest(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWs ZFscdPcCobrarWs)
        {
            this.ZFscdPcCobrarWs = ZFscdPcCobrarWs;
        }
    }

    /// <summary>
    /// ZFscdPcCobrarWsResponse1
    /// </summary>
    public partial class ZFscdPcCobrarWsResponse1
    {
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWsResponse ZFscdPcCobrarWsResponse { get; set; }

        public ZFscdPcCobrarWsResponse1()
        {
        }

        public ZFscdPcCobrarWsResponse1(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWsResponse ZFscdPcCobrarWsResponse)
        {
            this.ZFscdPcCobrarWsResponse = ZFscdPcCobrarWsResponse;
        }
    }

    /// <summary>
    /// ZFscdPcContaEfetivaWs
    /// </summary>
    public partial class ZFscdPcContaEfetivaWs
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Broker { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyCode { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string EndDate { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string StartDate { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Total { get; set; } = String.Empty;

    }

    /// <summary>
    /// ZFscdPcContaEfetivaWsResponse
    /// </summary>
    public partial class ZFscdPcContaEfetivaWsResponse
    {
        public ZfscdCodigosErroProvisionLinhaContaEfetiva[] Errors { get; set; }
        public Zcd2GrouptTotalsS[] GroupTotals { get; set; }
        public ZfscdPcRecibosLinha[] Receipts { get; set; }
    }

    /// <summary>
    /// ZFscdPcContaEfetivaWsRequest
    /// </summary>
    public partial class ZFscdPcContaEfetivaWsRequest
    {

   
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcContaEfetivaWs ZFscdPcContaEfetivaWs;

        public ZFscdPcContaEfetivaWsRequest()
        {
        }

        public ZFscdPcContaEfetivaWsRequest(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcContaEfetivaWs ZFscdPcContaEfetivaWs)
        {
            this.ZFscdPcContaEfetivaWs = ZFscdPcContaEfetivaWs;
        }
    }

    /// <summary>
    /// ZFscdPcContaEfetivaWsResponse1
    /// </summary>
    public partial class ZFscdPcContaEfetivaWsResponse1
    {

      
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcContaEfetivaWsResponse ZFscdPcContaEfetivaWsResponse { get; set; }

        public ZFscdPcContaEfetivaWsResponse1()
        {
        }

        public ZFscdPcContaEfetivaWsResponse1(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcContaEfetivaWsResponse ZFscdPcContaEfetivaWsResponse)
        {
            this.ZFscdPcContaEfetivaWsResponse = ZFscdPcContaEfetivaWsResponse;
        }
    }

    /// <summary>
    /// ZFscdPcLiquidarWs
    /// </summary>
    public partial class ZFscdPcLiquidarWs
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PortalUser { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerContract { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdPcPaymentsValues BrokerPaymentsValues { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerReport { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public byte ServiceOrigin { get; set; } = 0;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Testrun { get; set; } = String.Empty;
    }

    /// <summary>
    /// ZFscdPcLiquidarWsResponse
    /// </summary>
    public partial class ZFscdPcLiquidarWsResponse
    {
        public ZfscdCodigosErroProvisionLinhaLiquidar[] Errors { get; set; }
    }

    /// <summary>
    /// ZFscdPcLiquidarWsRequest
    /// </summary>
    public partial class ZFscdPcLiquidarWsRequest
    {

     
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcLiquidarWs ZFscdPcLiquidarWs;

        public ZFscdPcLiquidarWsRequest()
        {
        }

        public ZFscdPcLiquidarWsRequest(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcLiquidarWs ZFscdPcLiquidarWs)
        {
            this.ZFscdPcLiquidarWs = ZFscdPcLiquidarWs;
        }
    }

    /// <summary>
    /// ZFscdPcLiquidarWsResponse1
    /// </summary>
    public partial class ZFscdPcLiquidarWsResponse1
    {

        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcLiquidarWsResponse ZFscdPcLiquidarWsResponse { get; set; }

        public ZFscdPcLiquidarWsResponse1()
        {
        }

        public ZFscdPcLiquidarWsResponse1(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcLiquidarWsResponse ZFscdPcLiquidarWsResponse)
        {
            this.ZFscdPcLiquidarWsResponse = ZFscdPcLiquidarWsResponse;
        }
    }

    /// <summary>
    /// ZFscdPcListarWs
    /// </summary>
    public partial class ZFscdPcListarWs
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerContract { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerReport { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyCode { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CreateDateFrom { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CreateDateTo { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string EndDateFrom { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string EndDateTo { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string IndicatorFilter { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; } = String.Empty;
    }

    /// <summary>
    /// ZFscdPcListarWsResponse
    /// </summary>
    public partial class ZFscdPcListarWsResponse
    {
        public ZfscdCodigosErroProvisionLinhaListar[] Errors { get; set; }
        public ZfscdPcHeaderLinha[] PcHeader { get; set; }
    }

    /// <summary>
    /// ZFscdPcListarWsRequest
    /// </summary>
    public partial class ZFscdPcListarWsRequest
    {

     
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcListarWs ZFscdPcListarWs;

        public ZFscdPcListarWsRequest()
        {
        }

        public ZFscdPcListarWsRequest(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcListarWs ZFscdPcListarWs)
        {
            this.ZFscdPcListarWs = ZFscdPcListarWs;
        }
    }

    /// <summary>
    /// ZFscdPcListarWsResponse1
    /// </summary>
    public partial class ZFscdPcListarWsResponse1
    {

    
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcListarWsResponse ZFscdPcListarWsResponse { get; set; }

        public ZFscdPcListarWsResponse1()
        {
        }

        public ZFscdPcListarWsResponse1(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcListarWsResponse ZFscdPcListarWsResponse)
        {
            this.ZFscdPcListarWsResponse = ZFscdPcListarWsResponse;
        }
    }

    /// <summary>
    /// ZFscdPcRecibosAgregadoWs
    /// </summary>
    public partial class ZFscdPcRecibosAgregadoWs
    {

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerContract { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)] 
        public string BrokerReport { get; set; } = String.Empty;

    }

    /// <summary>
    /// ZFscdPcRecibosAgregadoWsResponse
    /// </summary>
    public partial class ZFscdPcRecibosAgregadoWsResponse
    {

        private ZfscdCodigosErroProvisionLinhaAggregateReceipts[] errorsField;

        private ZfscdPcRecibosAgregados[] receiptsField;

      
        public ZfscdCodigosErroProvisionLinhaAggregateReceipts[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }

      
        public ZfscdPcRecibosAgregados[] Receipts
        {
            get
            {
                return this.receiptsField;
            }
            set
            {
                this.receiptsField = value;
            }
        }
    }

    /// <summary>
    /// ZFscdPcRecibosAgregadoWsRequest
    /// </summary>
    public partial class ZFscdPcRecibosAgregadoWsRequest
    {

      
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcRecibosAgregadoWs ZFscdPcRecibosAgregadoWs;

        public ZFscdPcRecibosAgregadoWsRequest()
        {
        }

        public ZFscdPcRecibosAgregadoWsRequest(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcRecibosAgregadoWs ZFscdPcRecibosAgregadoWs)
        {
            this.ZFscdPcRecibosAgregadoWs = ZFscdPcRecibosAgregadoWs;
        }
    }

    /// <summary>
    /// ZFscdPcRecibosAgregadoWsResponse1
    /// </summary>
    public partial class ZFscdPcRecibosAgregadoWsResponse1
    {
    
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcRecibosAgregadoWsResponse ZFscdPcRecibosAgregadoWsResponse { get; set; }

        public ZFscdPcRecibosAgregadoWsResponse1()
        {
        }

        public ZFscdPcRecibosAgregadoWsResponse1(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcRecibosAgregadoWsResponse ZFscdPcRecibosAgregadoWsResponse)
        {
            this.ZFscdPcRecibosAgregadoWsResponse = ZFscdPcRecibosAgregadoWsResponse;
        }
    }

    /// <summary>
    /// ZFscdPcValidarWs
    /// </summary>
    public partial class ZFscdPcValidarWs
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerContract { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string TesteRun { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdPcRecibosLinha[] PcReceipts { get; set; }

    }

    /// <summary>
    /// ZFscdPcValidarWsResponse
    /// </summary>
    public partial class ZFscdPcValidarWsResponse
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdCodigosErroRecibos[] Errors { get; set; }
    }

    /// <summary>
    /// ZFscdPcValidarWsRequest
    /// </summary>
    public partial class ZFscdPcValidarWsRequest
    {

     
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcValidarWs ZFscdPcValidarWs;

        public ZFscdPcValidarWsRequest()
        {
        }

        public ZFscdPcValidarWsRequest(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcValidarWs ZFscdPcValidarWs)
        {
            this.ZFscdPcValidarWs = ZFscdPcValidarWs;
        }
    }

    /// <summary>
    /// ZFscdPcValidarWsResponse1
    /// </summary>
    public partial class ZFscdPcValidarWsResponse1
    {

       
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcValidarWsResponse ZFscdPcValidarWsResponse { get; set; }

        public ZFscdPcValidarWsResponse1()
        {
        }

        public ZFscdPcValidarWsResponse1(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcValidarWsResponse ZFscdPcValidarWsResponse)
        {
            this.ZFscdPcValidarWsResponse = ZFscdPcValidarWsResponse;
        }
    }

    /// <summary>
    /// ZFscdPcEliminarWs
    /// </summary>
    public partial class ZFscdPcEliminarWs
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PortalUserDni { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerContract { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerReport { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public List<string> ReportSubItemNumber { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public byte ServiceOrigin { get; set; } = 0;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Testrun { get; set; } = String.Empty;
    }

    /// <summary>
    /// ZFscdPcEliminarWsResponse
    /// </summary>
    public partial class ZFscdPcEliminarWsResponse
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdCodigosErroProvisionLinhaEliminar[] Errors { get; set; }
    }

    /// <summary>
    /// ZFscdPcEliminarWsRequest
    /// </summary>
    public partial class ZFscdPcEliminarWsRequest
    {
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcEliminarWs ZFscdPcEliminarWs;

        public ZFscdPcEliminarWsRequest()
        {
        }

        public ZFscdPcEliminarWsRequest(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcEliminarWs ZFscdPcEliminarWs)
        {
            this.ZFscdPcEliminarWs = ZFscdPcEliminarWs;
        }
    }

    /// <summary>
    /// ZFscdPcEliminarWsResponse1
    /// </summary>
    public partial class ZFscdPcEliminarWsResponse1
    {
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcEliminarWsResponse ZFscdPcEliminarWsResponse { get; set; }

        public ZFscdPcEliminarWsResponse1()
        {
        }

        public ZFscdPcEliminarWsResponse1(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcEliminarWsResponse ZFscdPcEliminarWsResponse)
        {
            this.ZFscdPcEliminarWsResponse = ZFscdPcEliminarWsResponse;
        }
    }

    /// <summary>
    /// ZFscdPcIndicadoresWs
    /// </summary>
    public partial class ZFscdPcIndicadoresWs
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerContract { get; set; } = String.Empty;

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZfscdPcBrokerLinha[] PcBrokerList { get; set; }
    }

    /// <summary>
    /// ZFscdPcIndicadoresWsResponse
    /// </summary>
    public partial class ZFscdPcIndicadoresWsResponse
    {

        private ZfscdCodigosErroProvisionLinhaIndicadores[] errorsField;

        private int nvidaField;

        private ZfscdPcBrokerLinha[] pcBrokerListField;

        private int totalField;

        private decimal totalSumField;

        private int vidaField;

      
        public ZfscdCodigosErroProvisionLinhaIndicadores[] Errors
        {
            get
            {
                return this.errorsField;
            }
            set
            {
                this.errorsField = value;
            }
        }

     
        public int Nvida
        {
            get
            {
                return this.nvidaField;
            }
            set
            {
                this.nvidaField = value;
            }
        }

      
        public ZfscdPcBrokerLinha[] PcBrokerList
        {
            get
            {
                return this.pcBrokerListField;
            }
            set
            {
                this.pcBrokerListField = value;
            }
        }

       
        public int Total
        {
            get
            {
                return this.totalField;
            }
            set
            {
                this.totalField = value;
            }
        }

        public decimal TotalSum
        {
            get
            {
                return this.totalSumField;
            }
            set
            {
                this.totalSumField = value;
            }
        }


        public int Vida
        {
            get
            {
                return this.vidaField;
            }
            set
            {
                this.vidaField = value;
            }
        }
    }

    /// <summary>
    /// ZFscdPcIndicadoresWsRequest
    /// </summary>
    public partial class ZFscdPcIndicadoresWsRequest
    {

      
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWs ZFscdPcIndicadoresWs;

        public ZFscdPcIndicadoresWsRequest()
        {
        }

        public ZFscdPcIndicadoresWsRequest(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWs ZFscdPcIndicadoresWs)
        {
            this.ZFscdPcIndicadoresWs = ZFscdPcIndicadoresWs;
        }
    }

    /// <summary>
    /// ZFscdPcIndicadoresWsResponse1
    /// </summary>
    public partial class ZFscdPcIndicadoresWsResponse1
    {
        public INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWsResponse ZFscdPcIndicadoresWsResponse { get; set; }

        public ZFscdPcIndicadoresWsResponse1()
        {
        }

        public ZFscdPcIndicadoresWsResponse1(INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWsResponse ZFscdPcIndicadoresWsResponse)
        {
            this.ZFscdPcIndicadoresWsResponse = ZFscdPcIndicadoresWsResponse;
        }
    }
}

﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Model.Partners.PolicyAIA
{
        public class ZfscdAiaGetPolicysWs
        {
            [JsonProperty("Receipts", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public ZfscdReceiptsData[] Receipts { get; set; }
        }

        public class ZfscdReceiptsData
        {
            [JsonProperty("CompanyCode", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string CompanyCode { get; set; } = String.Empty;

            [JsonProperty("DestinySystem", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string DestinySystem { get; set; } = String.Empty;

            [JsonProperty("Policy", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string Policy { get; set; } = String.Empty;

            [JsonProperty("Adherence", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string Adherence { get; set; } = String.Empty;

            [JsonProperty("Operation", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string Operation { get; set; } = String.Empty;

            [JsonProperty("BeginDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string BeginDate { get; set; } = String.Empty;

            [JsonProperty("EndDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string EndDate { get; set; } = String.Empty;

            [JsonProperty("GroupIndicator", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string GroupIndicator { get; set; } = String.Empty;

            [JsonProperty("Receipts", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public ZfscdReceiptsCharge[] Receipts { get; set; }
        }

        public  class ZfscdReceiptsCharge
        {
            [JsonProperty("ReferenceDocumentNumber", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ReferenceDocumentNumber { get; set; } = String.Empty;

            [JsonProperty("ReceiptType", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ReceiptType { get; set; } = String.Empty;

            [JsonProperty("Amount", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public double? Amount { get; set; } = 0;

            [JsonProperty("BeginDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string BeginDate { get; set; } = String.Empty;

            [JsonProperty("EndDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string EndDate { get; set; } = String.Empty;

            [JsonProperty("ChargeDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ChargeDate { get; set; } = String.Empty;

            [JsonProperty("ReverseDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ReverseDate { get; set; } = String.Empty;

            [JsonProperty("ReceiptStatus", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ReceiptStatus { get; set; } = String.Empty;
        }

        public  class ZfscdCodigosErroLinha
        {
            [JsonProperty("ErrorCode", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ErrorCode { get; set; } = String.Empty;

            [JsonProperty("ErrorCodeTxt", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ErrorCodeTxt { get; set; } = String.Empty;
        }

    public class ZFscdAiaGetApolicesWsResponse
    {
        public ZfscdCodigosErroLinha[] Errors { get; set; }

        public ZfscdReceiptsData[] Receipts { get; set; }
    }


    public class ZfscdAiaGetPolicysRequest
        {
            public INS.PT.WebAPI.Model.Partners.PolicyAIA.ZfscdAiaGetPolicysWs ZfscdAiaGetPolicys { get; set; }

            public ZfscdAiaGetPolicysRequest()
            {
            }

            public ZfscdAiaGetPolicysRequest(INS.PT.WebAPI.Model.Partners.PolicyAIA.ZfscdAiaGetPolicysWs ZfscdAiaGetPolicys)
            {
                this.ZfscdAiaGetPolicys = ZfscdAiaGetPolicys;
            }
        }

    public class ZFscdAiaGetApolicesWsResponse1
    {

        public INS.PT.WebAPI.Model.Partners.PolicyAIA.ZFscdAiaGetApolicesWsResponse ZFscdAiaGetApolicesWsResponse;

        public ZFscdAiaGetApolicesWsResponse1()
        {
        }

        public ZFscdAiaGetApolicesWsResponse1(INS.PT.WebAPI.Model.Partners.PolicyAIA.ZFscdAiaGetApolicesWsResponse ZFscdAiaGetApolicesWsResponse)
        {
            this.ZFscdAiaGetApolicesWsResponse = ZFscdAiaGetApolicesWsResponse;
        }
    }
}
﻿

using Newtonsoft.Json;
using System;

namespace INS.PT.WebAPI.Model
{
    public class GetOutstandingPolicyPremiumsWASPInputData
    {
        /// <example>
        /// POLICY_ID
        /// </example>
        [JsonProperty("PolicyNumber", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PolicyNumber { get; set; } = String.Empty;

        /// <example>
        /// 004510611756
        /// </example>
        [JsonProperty("ClaimDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public DateTime? ClaimDate { get; set; } 
    }

    
}

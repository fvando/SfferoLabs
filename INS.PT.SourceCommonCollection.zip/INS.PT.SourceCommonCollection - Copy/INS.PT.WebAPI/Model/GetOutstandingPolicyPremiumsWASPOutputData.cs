﻿

using INS.PT.WebAPI.Model.Domain;
using INS.PT.WebAPI.Model.Partners.WebReceiptListing;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Model
{
    public class GetOutstandingPolicyPremiumsWASPOutputData
    {
        public GetOutstandingPolicyPremiumsWASPOutputData()
        {
            this.ReceiptArray = new List<PremiumReceiptElement>();
        }
        /// <example>
        /// 
        /// </example>
        [JsonProperty("OutputMessage")]
        public string OutputMessage { get; set; }

        /// <example>
        /// Indicador de existência de prémios em dívida
        /// </example>
        [JsonProperty("OutstandingPremiumsIndicator")]
        public bool? OutstandingPremiumsIndicator { get; set; }
        /// <example>
        /// Indicador de regularização do sinistro
        /// </example>
        [JsonProperty("ClaimRegularitzaionIndicator")]
        public bool? ClaimRegularitzaionIndicator { get; set; }
        /// <example>
        /// 
        /// </example>
        [JsonProperty("ReceiptArray")]
        public List<PremiumReceiptElement> ReceiptArray { get; set; }

        /// <example>
        /// 
        /// </example>
        [JsonProperty("Errors")]
        public List<string> Errors { get; set; }
    }

    public class PremiumReceiptElement
    {
        

        public PremiumReceiptElement() { 
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="input"></param>
        public PremiumReceiptElement(ZfscdRecibosWorkLinha input)
        {
            this.ReceiptNumber = input.ReferenceDocumentNumber;
            this.ReceiptType = input.ReceiptType;
            //this.ReceiptStartDate = input.EmissionDate;
            //this.ReceiptEndDate = input.SituationDate;
            this.Status = input.Status;
        }

        public PremiumReceiptElement(PayrecService.PremiumReceiptElement input)
        {
            this.ReceiptNumber = input.receiptNumber;
            this.ReceiptType = input.receiptType;
            this.ReceiptStartDate = input.receiptStartDate;
            this.ReceiptEndDate = input.receiptEndDate;
            this.Status = input.status;
        }

        public PremiumReceiptElement(HamedReceipt input)
        {
            this.ReceiptNumber = input.ReceiptNumber;
            this.ReceiptType = input.TypeNatureIdOriginal;
            if (!string.IsNullOrEmpty(input.StartDate) && DateTime.TryParse(input.StartDate, out DateTime date))
            {
                this.ReceiptStartDate = date;
            }
           
            this.Status = input.SituationIdOriginal;
        }

        /// <example>
        /// 
        /// </example>
        [JsonProperty("ReceiptNumber")]
        public string ReceiptNumber { get; set; }

        /// <example>
        /// 
        /// </example>
        [JsonProperty("ReceiptType")]
        public string ReceiptType { get; set; }
        /// <example>
        /// 
        /// </example>
        [JsonProperty("ReceiptStartDate")]
        public DateTime? ReceiptStartDate { get; set; }
        /// <example>
        /// 
        /// </example>
        [JsonProperty("ReceiptEndDate")]
        public DateTime? ReceiptEndDate { get; set; }
        /// <example>
        /// 
        /// </example>
        [JsonProperty("Status")]
        public string Status { get; set; }

    }
}

﻿

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Model
{
    public class ReceiptCoverageInput
    {
        public Request Request { get; set; }
    }

    public class Parameter
    {
        /// <example>
        /// POLICY_ID
        /// </example>
        [JsonProperty("Name", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; } = "POLICY_ID";

        /// <example>
        /// 004510611756
        /// </example>
        [JsonProperty("Value", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Value { get; set; } = "004510686140";
    }

    public class Parameters
    {
        [JsonProperty("Parameter")]
        public Parameter Parameter { get; set; }
    }

    public class Request
    {
        [JsonProperty("Parameters")]
        public Parameters Parameters { get; set; }
    }
}

﻿using System;
using System.Data;
using System.Threading.Tasks;
using ins.pt.WebAPI;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.DTO;
using INS.PT.WebAPI.Model.Partners.WebReceiptListing;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using Serilog;

namespace INS.PT.WebAPI.Controllers
{
    [Route("v1/[Controller]/[Action]")]
    [ApiController]
    public class ReceiptController : BaseCore //ControllerBase
    {
        private readonly IReceiptRepository _receiptRepository;
        private readonly IDbconnectioncs _connection;

        public ReceiptController(IReceiptRepository receiptRepository, IDbconnectioncs connection)
        {
            _connection = connection;
            _receiptRepository = receiptRepository;
        }

        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(ReceiptCoverageOutPutDTO), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<ReceiptCoverageOutPutDTO>> Coverage([FromBody] ReceiptCoverageInput requestReceipt)
        {
            Log.Debug($"Coverage: {JsonConvert.SerializeObject(requestReceipt)}");
            try
            {
                var Response = await _receiptRepository.GetReceiptAsync(requestReceipt);

                //creates a 200 (OK)
                Log.Debug("Coverage Response: {response}", JsonConvert.SerializeObject(Response));

                if (Response?.Errors?.Count > 0) {   
                    return UnprocessableEntity(Response.Errors);
                }
                else {
                    return Ok(Response);
                }
            }
            catch (ProcessErrorException processError)
            {
                Log.Error($"{processError}");
                return NotFound(processError);
            }
            catch (AggregateException validateErrors)
            {
                Log.Error($"{validateErrors}");
                return BadRequest(validateErrors);
            }
            catch (Exception e)
            {
                Log.Error($"{e}");
                throw;
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }
    }
}

﻿using System;
using System.Threading.Tasks;
using ins.pt.WebAPI;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;

namespace INS.PT.WebAPI.Controllers
{

    [Route("v1/[controller]/[Action]")]
    [ApiController]
    public class ProposalAIAController : BaseCore //ControllerBase
    {
        
        private readonly IProposalAiaRepository _proposalAiaRepository;
        
      
        public ProposalAIAController(IProposalAiaRepository proposalAiaRepository)
        {
            _proposalAiaRepository = proposalAiaRepository;
        }

        /// <summary>
        /// AIA the specified request PolicyAIA - ZfscdAiaGetPolicysWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#v1.2FProposalAIA.2FGetProposalAia
        ///
        ///     {  
        ///         "Eproposal": {
        ///         "ProposalNumber": "2ULP2039930000992",
        ///         "Company": "0010",
        ///         "Nep": "",
        ///         "Value": "2.46",
        ///         "CreationDate": "20210525",
        ///         "CreationTime": "182923",
        ///         "UpdateDate": "",
        ///         "UpdateTime": "",
        ///         "Payment": "S",
        ///         "DataLimite": "20210610",
        ///         "Status": "0",
        ///         "OriginalAplication": "AIA",
        ///         "Bankacc": "PT50001800034339376802088",
        ///         "Nif": "291132014",
        ///         "Nif": "87061",
        ///         "PhoneId": ""
        ///       }
        ///     }
        ///
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(INS.PT.WebAPI.Model.Partners.Get.ProposalAIA.ZageasLifeGetProposalWsResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]

        public async Task<ActionResult<INS.PT.WebAPI.Model.Partners.Get.ProposalAIA.ZageasLifeGetProposalWsResponse>> GetProposalAia([FromBody] 
        INS.PT.WebAPI.Model.Partners.Get.ProposalAIA.ZageasLifeGetProposalWs requestProposal)
        {
            try
            {
                var _response = await _proposalAiaRepository.GetLifeProposalAsync(requestProposal);

                Log.Debug("GetPolicyAia Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response?.Errors != null)
                    {
                        if (_response?.Errors?.ErrorCode == "000" || _response?.Errors?.ErrorCode == "")
                        {
                            return Ok(_response);
                        } else { 
                            if (_response?.Errors?.ErrorCode != "000" || !string.IsNullOrWhiteSpace(_response?.Errors?.ErrorCode) ||
                                !string.IsNullOrEmpty(_response?.Errors?.ErrorCode)) {
                                    return UnprocessableEntity(_response);
                            }
                        }
                    }
                }
                return Ok(_response);


            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError,String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }

        /// <summary>
        /// AIA the specified request PolicyAIA - ZageasLifeUpdProposalWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#v1.2FProposalAIA.2FUpdProposalAia
        ///
        ///     {  
        ///         "Proposal": {
        ///         "ProposalNumber": "2ULP100263300001972",
        ///         "Amount": "10000",
        ///         "Status": "3",
        ///         "EdgeDate": "20210504",
        ///         "SibsEntity": "1",
        ///         "SibsReference": "123456789",
        ///         "PhoneId": "915811405",
        ///         "TerminalId": "",
        ///         "Nep": ""
        ///       }
        ///     }
        ///
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWsResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]

        public async Task<ActionResult<INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWsResponse>> UpdProposalAia([FromBody]
        INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWs requestProposal)
        {
            try
            {
                var _response = await _proposalAiaRepository.UpdLifeProposalAsync(requestProposal);

                Log.Debug("UpdProposalAia Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response?.Errors != null)
                    {
                        if (_response?.Errors?.ErrorCode == "000" || _response?.Errors?.ErrorCode == "")
                        {
                            return Ok(_response);
                        }
                        else
                        {
                            if (!string.IsNullOrWhiteSpace(_response?.Errors?.ErrorCode) ||
                                !string.IsNullOrEmpty(_response?.Errors?.ErrorCode))
                            {
                                return UnprocessableEntity(_response);
                            }
                        }
                    }
                }
                return Ok(_response);


            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }


        /// <summary>
        /// AIA the specified request PolicyAIA - ZageasLifeGetBeforeChargeWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#v1.2FProposalAIA.2FGetBeforeChargeProposalAia
        ///
        ///     {  
        ///         "IProposalNumber": "2ULP100354300009998"
        ///     }
        ///
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(INS.PT.WebAPI.Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]

        public async Task<ActionResult<INS.PT.WebAPI.Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse>> GetBeforeChargeProposalAia([FromBody]
        INS.PT.WebAPI.Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWs requestProposal)
        {
            try
            {
                var _response = await _proposalAiaRepository.GetBeforeChargeLifeProposalAsync(requestProposal);

                Log.Debug("GetBeforeChargeProposalAia Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response?.Errors != null)
                    {
                        if (_response?.Errors?.ErrorCode == "000" || _response?.Errors?.ErrorCode == "")
                        {
                            return Ok(_response);
                        }
                        else
                        {
                            if (!string.IsNullOrWhiteSpace(_response?.Errors?.ErrorCode) ||
                                !string.IsNullOrEmpty(_response?.Errors?.ErrorCode))
                            {
                                return UnprocessableEntity(_response);
                            }
                        }
                    }
                }
                return Ok(_response);


            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }
    }
}
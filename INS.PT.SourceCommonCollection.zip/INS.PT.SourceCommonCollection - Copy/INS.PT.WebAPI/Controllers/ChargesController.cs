﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Threading.Tasks;
using AutoMapper;
using ins.pt.WebAPI;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.WebAPI.Charged;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Serilog;

namespace INS.PT.WebAPI.Controllers
{

    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="ins.pt.WebAPI.BaseCore" />
    [Route("v1/[controller]/[Action]")]
    [ApiController]
    public class ChargesController : BaseCore //ControllerBase
    {
        private readonly IMapper _mapper;

        private readonly IChargesRepository _chargedRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="ChargesController"/> class.
        /// </summary>
        /// <param name="mapper">The mapper.</param>

        /// <param name="chargedRepository">The charged repository.</param>
        public ChargesController(IMapper mapper, IChargesRepository chargedRepository)
        {
            _chargedRepository = chargedRepository;
            _mapper = mapper;

        }

        /// <summary>
        /// Chargeds the specified request charged - ZFscdCobradosPostWs
        /// </summary>
        /// <param name="requestCharged">The request charged.</param>
        /// <response code="200">if any results exist.</response>
        /// <response code="204">if no results exist.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(INS.PT.WebAPI.Model.Partners.Charged.ZFscdCobradosPostWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<INS.PT.WebAPI.Model.Partners.Charged.ZFscdCobradosPostWsResponse1>> Charged([FromBody] INS.PT.WebAPI.Model.Partners.Charged.ZFscdCobradosPostWs requestCharged)
        {
            try
            {
                var _response = await _chargedRepository.GetChargedAsync(requestCharged);

                //creates a 200 (OK)
                Log.Debug("Charged Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response.ZFscdCobradosPostWsResponse.Errors.Length > 0)
                    {
                        return UnprocessableEntity(_response);
                    }
                }
                return Ok(_response);
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }

    }
}

﻿using System;
using System.Threading.Tasks;
using ins.pt.WebAPI;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using INS.PT.WebAPI.Interface;
using Microsoft.AspNetCore.Http;
using INS.PT.WebAPI.Model;
using Serilog;

namespace INS.PT.WebAPI.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="ins.pt.WebAPI.BaseCore" />
    [Route("v1/[Controller]/[Action]")]
    [ApiController]
    public class EntitiesController : BaseCore
    {

        private readonly IEntitiesRepository _entityRepository;


        /// <summary>
        /// Initializes a new instance of the <see cref="EntitiesController"/> class.
        /// </summary>
        /// <param name="entityRepository">The entity repository.</param>
        public EntitiesController(IEntitiesRepository entityRepository)
        {
            _entityRepository = entityRepository;
        }

        /// <summary>
        /// Notifies the specified request notify.
        /// </summary>
        /// <param name="requestNotify">The request notify.</param>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#Entities.2FNotify
        /// 
        ///     {  
        ///        "Notification": "?"
        ///     }
        /// 
        /// </remarks>

        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(ServiceNotification.ServiceReference.ZFscdServiceNotificationWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<ServiceNotification.ServiceReference.ZFscdServiceNotificationWsResponse1>> Notify([FromBody] ServiceNotification.ServiceReference.ZFscdServiceNotificationWs requestNotify)
        {
            try
            {
                var _response = await _entityRepository.GetNotifyAsync(requestNotify);

                //creates a 200 (OK)
                Log.Debug("Notify Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response.ZFscdServiceNotificationWsResponse.Errors.Length > 0)
                    {
                        return UnprocessableEntity(_response);
                    }
                }
                return Ok(_response);

            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }
    }
}

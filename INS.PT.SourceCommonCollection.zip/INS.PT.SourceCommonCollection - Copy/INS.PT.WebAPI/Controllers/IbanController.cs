﻿using System;
using System.Linq;
using System.Threading.Tasks;
using ins.pt.WebAPI;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;

namespace INS.PT.WebAPI.Controllers
{

    [Route("v1/[controller]/[Action]")]
    [ApiController]
    public class IbanController : BaseCore //ControllerBase
    {
        private readonly IIbanRepository iBanCheckRepository;
        
        public IbanController(IIbanRepository IbanValidationRepository)
        {
            iBanCheckRepository = IbanValidationRepository;
        }

        /// <summary>
        /// AIA the specified request IBAN Check - ZFscdCheckIbanWsAsync
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#v1.2FIban.2FIbanCheck
        ///
        ///     {  
        ///         "Iban": "string"
        ///     }  
        ///
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(SAP.Extern.WCF.IbanValidation.Service.Reference.Tst.ZFscdCheckIbanWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]

        public async Task<ActionResult<INS.PT.WebAPI.Model.Partners.Iban.ZFscdCheckIbanWsResponse1>> IbanCheck([FromBody] 
        INS.PT.WebAPI.Model.Partners.Iban.ZFscdCheckIbanWs requestIbanValidation)
        {
            try
            {
                var _response = await iBanCheckRepository.CheckIbanWsAsync(requestIbanValidation);

                Log.Debug("PostIbanValidation Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)  {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response?.ZFscdCheckIbanWsResponse.Errors?.Count > 0)
                    {
                        if (_response.ZFscdCheckIbanWsResponse.Errors.FirstOrDefault()?.ErrorCode == "000") {
                            return Ok(_response);
                        } else
                        {
                            return UnprocessableEntity(_response);
                        }
                    }
                }
                return Ok(_response);


            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError,String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }

      
     
    }
}
﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ins.pt.WebAPI;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.Partners.ProvisionWebAccount;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;

namespace INS.PT.WebAPI.Controllers
{
    [Route("v1/[Controller]/[Action]")]
    [ApiController]
    public class ProvisionWebAccountsController : BaseCore
    {
        private const string ProvisionWebAccountsChargedMethod = "ProvisionWebAccounts/Charged/{IdReceipt}";

        /// <summary>
        /// The provision repository
        /// </summary>
        private readonly IProvisionsRepository provisionRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="ProvisionWebAccountsController"/> class.
        /// </summary>
        /// <param name="_provisionRepository">The provision repository.</param>
        /// <param name="httpContext">The HTTP context.</param>
        public ProvisionWebAccountsController(IProvisionsRepository _provisionRepository, IHttpContextAccessor httpContext)
        {
            provisionRepository = _provisionRepository;
        }

        /// <summary>
        /// Queries the specified request query - ZFscdPcConsultarWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#ProvisionWebAccounts.2FQuery
        /// 
        ///     {  
        ///       "brokerContract": "M066190",
        ///       "brokerReport": "W06619018101",
        ///       "viewDeleted": "X"
        ///     }
        /// Notes: viewDeleted: Accepted codes "" and "X" to view all deleted
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(ZFscdPcConsultarWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<ZFscdPcConsultarWsResponse1>> Query([FromBody] ZFscdPcConsultarWs requestQuery)
        {
            try
            {
                //convert to IN structure
                var response = await provisionRepository.GetQueryAsync(requestQuery);

                //creates a 200 (OK)
                Log.Debug("Query Response: {response}", JsonConvert.SerializeObject(response));

                if (response == null)
                {
                    return NotFound(response);
                }
                else
                {
                    //Erro Externo
                    if (response.ZFscdPcConsultarWsResponse.Errors.Length > 0)
                    {
                        return UnprocessableEntity(response);
                    }
                }
                return Ok(response);

            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }
        }

        /// <summary>
        /// Chargeds the specified request charge - ZFscdPcCobrarWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#ProvisionWebAccounts.2FCharged
        /// 
        ///     v1/ProvisionWebAccounts/Charged/0000000055130964  
        /// 
        /// </remarks>
        [HttpGet("{IdReceipt}")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(Helper.ChargedReceiptLineDetailResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<Helper.ChargedReceiptLineDetailResponse>> Charged([FromRoute] string IdReceipt)
        {
            try
            {
                //convert to IN structure
                var _response = await provisionRepository.GetChargedAsync(IdReceipt);

                //creates a 200 (OK)
                Log.Debug("Charged Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                return Ok(_response);
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }
        }



        /// <summary>
        /// Chargeds the specified request charge - ZFscdPcCobrarWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#ProvisionWebAccounts.2FCharged
        /// 
        ///     {  
        ///       "brokerContract": "M066190",
        ///       "pcReceipts": [{
        ///           "insuranceBroker": "M066190",
        ///           "companyCode": "0020",
        ///           "documentType": "AG",
        ///           "referenceDocumentNumber": "0000000055130964",
        ///           "sapDocumentNumber": "102004202824",
        ///           "documentNumber": "",
        ///           "partner": "1005822884",
        ///           "insuranceObject": "101021349700000",
        ///           "amount": 35.53,
        ///           "currency": "EUR"
        ///         }]
        ///     }
        /// 
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(Helper.ChargedReceiptLineDetailResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<Helper.ChargedReceiptLineDetailResponse>> Charged([FromBody] ZFscdPcCobrarWs requestCharge)
        {
            try
            {
                //convert to IN structure
                var _response = await provisionRepository.GetChargedAsync(requestCharge);

                //creates a 200 (OK)
                Log.Debug("Charged Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                return Ok(_response);
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }

        /// <summary>
        /// Liquidates the specified request liquidate - ZFscdPcLiquidarWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#ProvisionWebAccounts.2FLiquidate
        /// 
        ///     {
        ///       "PortalUser": "",
        ///       "BrokerContract": "M039547",
        ///       "BrokerPaymentsValues": {
        ///          "PayMethod1": "01",
        ///          "ValuePay1": -56.30,
        ///          "PayMethod2": "",
        ///          "ValuePay2": 0,
        ///          "EntSibs": "",
        ///          "RefSibs": "",
        ///          "TotalValue": -56.30
        ///      },
        ///     "BrokerReport": "W0227752031",
        ///     "Testrun": "X"
        ///     }
        /// 
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(Helper.LiquidatePaymentsLineDetailResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<Helper.LiquidatePaymentsLineDetailResponse>> Liquidate([FromBody] ZFscdPcLiquidarWs requestLiquidate)
        {
            try
            {
                //convert to IN structure
                var _response = await provisionRepository.GetLiquidateAsync(requestLiquidate);

                //creates a 200 (OK)
                Log.Debug("Liquidate Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                return Ok(_response);

            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }

        /// <summary>
        /// Lists the specified request list - ZFscdPcListarWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#Service_5
        /// 
        ///     -- By Creation Date 
        ///     {  
        ///       "brokerContract": "66190",
        ///       "brokerReport": "",
        ///       "CompanyCode": "",
        ///       "CreateDateFrom": "20180101",
        ///       "CreateDateTo": "20190101",
        ///       "EndDateFrom": "",
        ///       "EndDateTo": "",      
        ///       "IndicatorFilter": "",
        ///       "status": ""
        ///     }
        ///    -- By End Date 
        ///     {  
        ///       "brokerContract": "66190",
        ///       "brokerReport": "",
        ///       "CompanyCode": "",
        ///       "CreateDateFrom": "",
        ///       "CreateDateTo": "",
        ///       "EndDateFrom": "20180101",
        ///       "EndDateTo": "20190101",      
        ///       "IndicatorFilter": "",
        ///       "status": ""
        ///     }
        /// 
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(Model.Partners.ProvisionWebAccount.ZFscdPcListarWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<Model.Partners.ProvisionWebAccount.ZFscdPcListarWsResponse1>> List([FromBody] ZFscdPcListarWs requestList)
        {
            try
            {
                //convert to IN structure
                var response = await provisionRepository.GetListAsync(requestList);

                //creates a 200 (OK)
                Log.Debug("List Response: {response}", JsonConvert.SerializeObject(response));

                if (response == null)
                {
                    return NotFound(response);
                }
                else
                {
                    if (response.ZFscdPcListarWsResponse.Errors.Length > 0)
                    {
                        return UnprocessableEntity(response);
                    }
                }
                return Ok(response);

            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }

        /// <summary>
        /// Validates the specified request validade - ZFscdPcValidarWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#ProvisionWebAccounts.2FValidate
        /// 
        ///     {  
        ///       "brokerContract": "M089717",
        ///       "testeRun" : "X", //X - Receipt Test, B - Broker Contract 
        ///       "pcReceipts": [{
        ///                         "insuranceBroker": "M089717",
        ///                         "companyCode": "0020",
        ///                         "documentType": "PC",
        ///                         "referenceDocumentNumber": "8971701031810001",
        ///                         "sapDocumentNumber": "652000965272",
        ///                         "documentNumber": "",
        ///                         "insurancePartner": "1004495401",
        ///                         "insuranceObject": "00000451031692700000",
        ///                         "amount": -15.77,
        ///                         "currency": "EUR"
        ///                      }]
        ///         }
        /// 
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(Helper.ValidateReceiptLineDetailResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<Helper.ValidateReceiptLineDetailResponse>> Validate([FromBody] ZFscdPcValidarWs requestValidade)
        {
            try
            {
                //convert to IN structure
                var _response = await provisionRepository.GetValidateAsync(requestValidade);

                //creates a 200 (OK)
                Log.Debug("Validate Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                return Ok(_response);

            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }

        /// <summary>
        /// Kpis the specified request validade - ZFscdPcIndicadoresWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#Service_7
        /// 
        ///     {  
        ///       "brokerContract": "M008683",
        ///       "pcBrokerList": [{
        ///           "brokerContract": "08683"
        ///         }]
        ///     }
        /// 
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(ZFscdPcIndicadoresWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<ZFscdPcIndicadoresWsResponse1>> Kpi([FromBody] ZFscdPcIndicadoresWs requestValidade)
        {
            try
            {
                //convert to IN structure
                var _response = await provisionRepository.GetKpiAsync(requestValidade);

                //creates a 200 (OK)
                Log.Debug("Kpi Response: {_response} ", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response.ZFscdPcIndicadoresWsResponse.Errors.Length > 0)
                    {
                        return UnprocessableEntity(_response);
                    }
                }
                return Ok(_response);

            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error($"{validateErrors}");
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug($"Finish");
            }

        }

        /// <summary>
        /// EffectiveAccount the specified request validade - ZFscdPcContaEfetivaWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#ProvisionWebAccounts.2FEffectiveAccount
        /// 
        ///     {  
        ///        "broker": "66190",
        ///        "companyCode": "0020",
        ///        "endDate": "20191024",
        ///        "startDate": "20190101",
        ///        "total": "x"
        ///     }  
        /// 
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(ZFscdPcContaEfetivaWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<ZFscdPcContaEfetivaWsResponse1>> EffectiveAccount([FromBody] ZFscdPcContaEfetivaWs requestEfetiva)
        {
            try
            {
                //convert to IN structure
                var _response = await provisionRepository.GetContaEfetivaAsync(requestEfetiva);

                //creates a 200 (OK)
                Log.Debug("EffectiveAccount Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response.ZFscdPcContaEfetivaWsResponse.Errors.Length > 0)
                    {
                        return UnprocessableEntity(_response);
                    }
                }
                return Ok(_response);

            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors,String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }

        /// <summary>
        /// GetAggregatesReceiptsAsync the specified request validade - ZFscdPcRecibosAgregadoWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#ProvisionWebAccounts.2FAggregatesReceipts
        /// 
        ///     {  
        ///        "BrokerContract": "M066074",
        ///        "BrokerReport": "W06607413206",
        ///     }  
        /// 
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(ZFscdPcRecibosAgregadoWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<ZFscdPcRecibosAgregadoWsResponse1>> AggregatesReceipts([FromBody] ZFscdPcRecibosAgregadoWs requestAggregates)
        {
            try
            {
                //convert to IN structure
                var _response = await provisionRepository.GetAggregatesReceiptsAsync(requestAggregates);

                //creates a 200 (OK)
                Log.Debug("GetAggregatesReceiptsAsync Response: {_response}",  JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response.ZFscdPcRecibosAgregadoWsResponse.Errors.Length > 0)
                    {
                        return UnprocessableEntity(_response);
                    }
                }
                return Ok(_response);

            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }

        /// <summary>
        /// EliminateReceiptsAsync the specified request validade - ZFscdPcEliminarWsAsync
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#ProvisionWebAccounts.2FEliminateReceipts
        /// 
        ///     {
        ///       "PortalUserDni": "igor.barreto.score@ageas.pt",
        ///       "BrokerContract": "M089750",
        ///       "BrokerReport": "W08975050006",
        ///       "ReportSubItemNumber": [
        ///          "000007"
        ///       ],
        ///       "ServiceOrigin": 1,
        ///       "Testrun": "X"
        ///     }
        /// 
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(ZFscdPcEliminarWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<ZFscdPcEliminarWsResponse1>> EliminateReceiptsAsync([FromBody] ZFscdPcEliminarWs eliminateReceipts)
        {
            try
            {
                //convert to IN structure
                var _response = await provisionRepository.PostEliminateReceiptsAsync(eliminateReceipts);

                //creates a 200 (OK)
                Log.Debug("PostEliminateReceiptsAsync Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response.ZFscdPcEliminarWsResponse.Errors.Length > 0)
                    {
                        return UnprocessableEntity(_response);
                    }
                }
                return Ok(_response);

            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }


    }
}

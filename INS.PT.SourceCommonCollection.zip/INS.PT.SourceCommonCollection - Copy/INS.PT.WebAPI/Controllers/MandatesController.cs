﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Threading.Tasks;
using AutoMapper;
using ins.pt.WebAPI;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Serilog;

namespace INS.PT.WebAPI.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="ins.pt.WebAPI.BaseCore" />
    [Route("v1/[controller]/[action]")]
    [ApiController]
    public class MandatesController : BaseCore //ControllerBase
    {

        /// <summary>
        /// The mandate repository
        /// </summary>
        private readonly IMandatesRepository _mandateRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="MandatesController"/> class.
        /// </summary>
        /// <param name="mandateRepository">The mandate repository.</param>
        public MandatesController(IMandatesRepository mandateRepository)
        {
            _mandateRepository = mandateRepository;
        }

        /// <summary>
        /// Mandates the specified request mandates - ZFscdMandatosPostWs
        /// </summary>
        /// <param name="requestMandates">The request mandates.</param>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#Mandates.2FMandate
        /// 
        ///     {  
        ///        "mandatesReference": {
        ///            "interface": "MN",
        ///            "originalSystem": "AIA",
        ///            "transaction": "1",
        ///            "systemDate": "20190702",
        ///            "systemTime": "153015",
        ///            "online": "X",
        ///            "itemsTotal": "1",
        ///            "mandate": [{
        ///                            "mandateType": "ADC",
        ///                            "companyCode": "PT12",
        ///                            "network": "TECN",
        ///                            "mandateReference": "A-012345678",
        ///                            "mandateReferenceOld": "",
        ///                            "sndIban": "PT50001800000499084100169",
        ///                            "policy": "RVG10000070",
        ///                            "brokerContract": "",
        ///                            "masterOrigin": "",
        ///                            "partnerExternalSystem": "",
        ///                            "sndBic": "TOTAPTPL",
        ///                            "description": "Mandato teste AIA",
        ///                            "status": "1",
        ///                            "startDateFrom": "20190701",
        ///                            "startDateTo": "99991231",
        ///                            "payType": "N",
        ///                            "signCity": "Lisboa",
        ///                            "signDate": "20190701",
        ///                            "errors": [{
        ///                                          "errorCode": "",
        ///                                           "errorCodeTxt": ""
        ///                                       }]
        ///                       }]
        ///           }
        ///     }
        /// 
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWsResponse1>> Mandate([FromBody] INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWs requestMandates)
        {
            try
            {
                var _response = await _mandateRepository.GetMandatesAsync(requestMandates);
                //creates a 200 (OK)
                Log.Debug("GetMandatesAsync Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response?.ZFscdMandatosPostWsResponse?.Errors.Length > 0)
                    {
                        return UnprocessableEntity(_response);
                    }
                }
                return Ok(_response);


            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError,String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }
    }
}

﻿using System;
using System.Threading.Tasks;
using ins.pt.WebAPI;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.Partners.WebReceiptListing;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;

namespace INS.PT.WebAPI.Controllers
{
    [Route("v1/[Controller]/[Action]")]
    [ApiController]
    public class WebReceiptListingController : BaseCore //ControllerBase
    {
        //Canais Cobrança(get) => BillingChannels
        //Grupos Produto(get) => ProductGroups
        //Ramos(get) => Branchs
        //Status(get) => Status
        //Tipos(get) => Types
        //Recibos Listar(post) => ListReceipts
        //ZFscdRecibosMposPostWs(post) => ListReceipts

        private readonly IWebReceiptListingRepository _webReceiptListRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="WebReceiptListingController"/> class.
        /// </summary>
        /// <param name="webReceiptListRepository">The web receipt list repository.</param>
        public WebReceiptListingController(IWebReceiptListingRepository webReceiptListRepository)
        {
            _webReceiptListRepository = webReceiptListRepository;
        }

        /// <summary>
        /// Lists the specified request receipt.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#WebReceiptListing.2FList
        /// 
        ///     {  
        ///       "broker": "89479",
        ///       "companyCode": "0020",
        ///       "endDate": "20190803",
        ///       "referenceDocumentNumber": "55643929",
        ///       "startDate": "20180803"
        ///     }
        /// 
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(ZFscdRecibosListarWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<ZFscdRecibosListarWsResponse1>> List([FromBody] ZFscdRecibosListarWs requestReceipt)
        {
            try
            {
                //convert to IN structure
                var Response = await _webReceiptListRepository.GestListAsync(requestReceipt);

                //creates a 200 (OK)
                Log.Debug("List Response: {response}", JsonConvert.SerializeObject(Response));

                if (Response == null)
                {
                    return NotFound(Response);
                }
                else
                {
                    //Erro Externo
                    if (Response.Errors.Count > 0)
                    {
                        return UnprocessableEntity(Response);
                    }
                }
                return Ok(Response);

            }

            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }


        /// <summary>
        /// Lists the specified request receipt.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#WebReceiptListing.2FList
        /// 
        ///     {  
        ///       "broker": "89479",
        ///       "companyCode": "0020",
        ///       "referenceDocumentNumber": "55643929"
        ///     }
        /// 
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(ZfscdRecibosWorkLinha), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<ZfscdRecibosWorkLinha>> Detail([FromBody] ZFscdRecibosListarWs requestReceipt)
        {
            try
            {
                //convert to IN structure
                var Response = await _webReceiptListRepository.GestListDetailAsync(requestReceipt);

                //creates a 200 (OK)
                Log.Debug("Detail Response: {response}", JsonConvert.SerializeObject(Response));

                if (Response == null)
                {
                    return NotFound(Response);
                }
                else
                {
                    //Erro Externo
                    if (Response?.Errors?.Count > 0)
                    {
                        return UnprocessableEntity(Response);
                    }
                }

                return Ok(Response);
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }
        }

        /// <summary>
        /// Lists the specified request receipt.
        /// </summary>
        /// <remarks>
        /// This service returns, for a policy, information about outstanding premiums
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(GetOutstandingPolicyPremiumsWASPOutputData), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<GetOutstandingPolicyPremiumsWASPOutputData>> GetOutstandingPolicyPremiumsWASP([FromBody] GetOutstandingPolicyPremiumsWASPInputData inputData)
        {
            GetOutstandingPolicyPremiumsWASPOutputData output = new GetOutstandingPolicyPremiumsWASPOutputData();
            try
            {
                
                //convert to IN structure
                var Response = await _webReceiptListRepository.GetOutstandingPolicyPremiumsWASPAsync(inputData);

                //creates a 200 (OK)
                Log.Debug("GetOutstandingPolicyPremiumsWASP Response: {response}", JsonConvert.SerializeObject(Response));

                if (Response == null)
                {
                    return NotFound(Response);
                }
                else
                {
                    //Erro Externo
                    if (Response?.Errors?.Count > 0)
                    {
                        return UnprocessableEntity(Response);
                    }
                }

                return Ok(Response);
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                output.Errors = new System.Collections.Generic.List<string>();
                output.Errors.Add(processError.ErrorMessage);
                return output;
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message);
                return BadRequest(ex);
            }
            finally
            {
                Log.Debug("Finish");
            }
        }

    }
}

﻿using System;
using System.Threading.Tasks;
using ins.pt.WebAPI;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;

namespace INS.PT.WebAPI.Controllers
{

    [Route("v1/[controller]/[action]")]
    [ApiController]
    public class GreenLettersController : BaseCore //ControllerBase
    {
        private readonly IGreenLettersRepository _greenLetterRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="GreenLettersController"/> class.
        /// </summary>
        /// <param name="greenLetterRepository">The green letter repository.</param>
        public GreenLettersController(IGreenLettersRepository greenLetterRepository)
        {
            _greenLetterRepository = greenLetterRepository;
        }

        /// <summary>
        /// Greens the letter -ZFscdCartasverdePostWs
        /// </summary>
        /// <param name="requestDocument">The request document.</param>
        /// <response code="200">if any results exist.</response>
        /// <response code="204">if no results exist.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns></returns>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWsResponse1>> GreenLetter([FromBody] INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWs requestDocument)
        {
            try
            {
                //convert to IN structure
                var _response = await _greenLetterRepository.GetGreenLetterAsync(requestDocument);

                //creates a 200 (OK)
                Log.Debug("GreenLetter Response: {_response}", JsonConvert.SerializeObject(_response));


                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response.ZFscdCartasverdePostWsResponse.Errors.Length > 0)
                    {
                        return UnprocessableEntity(_response);
                    }
                }
                return Ok(_response);

            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors,String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }

    }
}

﻿using System;
using System.Threading.Tasks;
using ins.pt.WebAPI;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;

namespace INS.PT.WebAPI.Controllers
{

    /// <summary></summary>
    /// <seealso cref="ins.pt.WebAPI.BaseCore" />
    [Route("v1/Cancellations/[action]")]
    [ApiController]
    public class CancellationsController : BaseCore
    {
        private readonly ICancellationsRepository _cancelRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="CancellationsController"/> class.
        /// </summary>
        /// <param name="cancelRepository">The cancel repository.</param>
        public CancellationsController(ICancellationsRepository cancelRepository)
        {
            _cancelRepository = cancelRepository;
        }

        /// <summary>
        /// Policies the specified request cancel policy - ZFscdAnularApolicesPostWs
        /// </summary>
        /// <param name="requestCancelPolicy">The request cancel policy.</param>
        /// <returns></returns>
        /// <exception cref="StandardMessage">
        /// Not Found
        /// or
        /// Not Found
        /// </exception>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#Cancellations.2FPolicy
        /// 
        ///     {  
        ///        "policies": {
        ///            "interface": "AN",
        ///            "destinysystem": "AIA",
        ///            "transaction": "1",
        ///            "systemDate": "20190714",
        ///            "systemTime": "153015",
        ///            "online": "X",
        ///            "itemsTotal": "1",
        ///            "policies": [{
        ///                           "companyCode": "PT12",
        ///                           "network": "AGV",
        ///                           "policy": "ARKA000002",
        ///                           "operation": "01",
        ///                           "operationDate": "20190714"
        ///             }]
        ///         }
        ///     }
        /// 
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWsResponse1>> Policy([FromBody] INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWs requestCancelPolicy)
        {
            try
            {
                var _response = await _cancelRepository.GetCancellationPolicyAsync(requestCancelPolicy);

                //creates a 200 (OK)
                Log.Debug("Policy Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response.ZFscdAnularApolicesPostWsResponse.Errors.Length > 0)
                    {
                        return UnprocessableEntity(_response);
                    }
                }
                return Ok(_response);
                //convert to OUT structure
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError, String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors,String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }
        }

        /// <summary>
        /// Receipts the specified request cancel receipt - ZFscdAnularRecibosPostWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#Cancellations.2FReceipt
        /// 
        ///     {  
        ///         "receipts": {
        ///         "interface": "AN",
        ///         "destinysystem": "AIA",
        ///         "transaction": "1",
        ///         "systemDate": "20190714",
        ///         "systemTime": "153015",
        ///         "online": "X",
        ///         "itemsTotal": "1",
        ///         "policies": [{
        ///             "companyCode": "PT12",
        ///             "network": "AGV",
        ///             "policy": "ARKA000002",
        ///             "operation": "01",
        ///             "operationDate": "20190714",
        ///             "Receipts": []
        ///           }]
        ///         }
        ///     }
        /// 
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWsResponse1>> Receipt([FromBody] INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWs requestCancelReceipt)
        {
            try
            {

                var _response = await _cancelRepository.GetCancellationCancelAsync(requestCancelReceipt);

                //creates a 200 (OK)
                Log.Debug("Receipt Response: {_response}", JsonConvert.SerializeObject(_response));


                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response.ZFscdAnularRecibosPostWsResponse.Errors.Length > 0)
                    {
                        return UnprocessableEntity(_response);
                    }
                }
                return Ok(_response);

            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError,String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors,String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }

        /// <summary>
        /// Receipts the specified request cancel receipt - ZfscdAnularDatasPostWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#Cancellations.2FDates
        /// 
        ///     {  
        ///         "receipts": {
        ///         "interface": "AN",
        ///         "destinysystem": "AIA",
        ///         "transaction": "1",
        ///         "systemDate": "20201110",
        ///         "systemTime": "163030",
        ///         "online": "X",
        ///         "itemsTotal": "1",
        ///         "policies": [{
        ///             "companyCode": "PT12",
        ///             "network": "AGV",
        ///             "policy": "2RKA002394",
        ///             "adherence": "",
        ///             "operation": "01",
        ///             "operationDate": "20201110"
        ///           }]
        ///         }
        ///     }
        /// 
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularDatasPostWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularDatasPostWsResponse1>> Dates([FromBody] INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularDatasPostWs requestCancelDates)
        {
            try
            {
                var _response = await _cancelRepository.GetCancellationCancelDatesAsync(requestCancelDates);

                //creates a 200 (OK)
                Log.Debug("Receipt Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response.ZFscdAnularDatasPostWsResponse.Errors.Length > 0)
                    {
                        return UnprocessableEntity(_response);
                    }
                }
                return Ok(_response);
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError,String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors,String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }

    }
}

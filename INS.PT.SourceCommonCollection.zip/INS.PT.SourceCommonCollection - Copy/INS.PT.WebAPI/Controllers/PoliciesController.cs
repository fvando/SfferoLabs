﻿using System;
using System.Threading.Tasks;
using ins.pt.WebAPI;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;

namespace INS.PT.WebAPI.Controllers
{

    [Route("v1/[controller]/[Action]")]
    [ApiController]
    public class PoliciesController : BaseCore //ControllerBase
    {
        /// <summary>
        /// The policy repository
        /// </summary>
        private readonly IPoliciesRepository _policyRepository;
        /// <summary>
        /// Initializes a new instance of the <see cref="PoliciesController"/> class.
        /// </summary>
        /// <param name="policyRepository">The policy repository.</param>
        public PoliciesController(IPoliciesRepository policyRepository)
        {
            _policyRepository = policyRepository;
        }

        /// <summary>
        /// Mediators the specified request mediator - ZFscdMediadoresPostWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#Policies.2FMediator
        ///
        ///     {  
        ///        "mediationAccount": {
        ///        "interface": "MO",
        ///        "originalSystem": "AIA",
        ///        "transaction": "1",
        ///        "systemDate": "20190703",
        ///        "systemTime": "100000",
        ///        "online": "X",
        ///        "itemsTotal": "1",
        ///        "mediator": [{
        ///                        "insuranceObjectCategory": "MO",
        ///                        "insuranceObject": "M1221841",
        ///                        "insuranceObjectOriginal": "M1221841",
        ///                        "companyCode": "PT12",
        ///                        "network": "TECN",
        ///                        "masterOrigin": "DNI",
        ///                        "partnerExternalSystem": "T10000000068021841",
        ///                        "agent": "",
        ///                        "broker": "",
        ///                        "startDate": "20190101",
        ///                        "endDate": "99991231",
        ///                        "withholdingTaxCode": "00",
        ///                        "partnerRelationshipContract": "01",
        ///                        "insuranceType": "",
        ///                        "incomingPaymentIban": "",
        ///                        "incomingPaymentMethod": "B",
        ///                        "incomingPaymentLockReason": "",
        ///                        "mandateReference": "",
        ///                        "outgoingPaymentIban": "",
        ///                        "outgoingPaymentMethod": "C",
        ///                        "outgoingPaymentLockReason": "",
        ///                        "addressType": "0001",
        ///                        "addressNumber": "01",
        ///                        "actionZone": "",
        ///                        "inspectionArea": "",
        ///                        "situactionCode": "E",
        ///                        "situactionCodeDate": "20190101",
        ///                        "mediators": {
        ///                                        "ispCode": "123456",
        ///                                        "premiumCategory": "",
        ///                                        "commissionCategory": "",
        ///                                        "claimCategory": "",
        ///                                        "costCategory": ""
        ///                                      },
        ///                         "beneficiaries": [{
        ///                                              "partnerRelationshipContract": "",
        ///                                              "masterOrigin": "",
        ///                                              "partnerExternalSystem": "",
        ///                                              "iban": "0000000000000000000000000000009999"
        ///                                          }]
        ///                   }]
        ///           }
        ///     }
        ///  
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWsResponse1>> Mediator([FromBody] INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWs requestMediator)
        {
            try
            {
                var _response = await _policyRepository.GetMediatorAsync(requestMediator);

                Log.Debug("Mediator Response: {_response}" , JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response.ZFscdMediadoresPostWsResponse.Errors.Length > 0)
                    {
                        return UnprocessableEntity(_response);
                    }
                }
                return Ok(_response);


            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError,String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }

        /// <summary>
        /// Policies the specified request policy - ZFscdApolicesPostWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#Policies.2FPolicy
        ///
        ///     {  
        ///        "policies": {
        ///                       "interface": "AO",
        ///                       "originalSystem": "DUCK",
        ///                       "transaction": "2",
        ///                       "systemDate": "20190712",
        ///                       "systemTime": "122034",
        ///                       "online": "X",
        ///                       "itemsTotal": "1",
        ///                       "policy": [{
        ///                                      "insuranceObjectCategory": "AO",
        ///                                      "insuranceObject": "45000002",
        ///                                      "insuranceObjectOriginal": "45000002",
        ///                                      "companyCode": "PT13",
        ///                                      "network": "AGS",
        ///                                      "masterOrigin": "DNI",
        ///                                      "partnerExternalSystem": "T10000000068021839",
        ///                                      "agent": "M0221841",
        ///                                      "broker": "M0221842",
        ///                                      "startDate": "20190601",
        ///                                      "endDate": "99991231",
        ///                                      "withholdingTaxCode": "",
        ///                                      "partnerRelationshipContract": "01",
        ///                                      "insuranceType": "400100",
        ///                                      "incomingPaymentIban": "",
        ///                                      "incomingPaymentMethod": "",
        ///                                      "incomingPaymentLockReason": "",
        ///                                      "mandateReference": "",
        ///                                      "outgoingPaymentIban": "",
        ///                                      "outgoingPaymentMethod": "",
        ///                                      "outgoingPaymentLockReason": "",
        ///                                      "addressType": "",
        ///                                      "addressNumber": "01",
        ///                                      "actionZone": "",
        ///                                      "inspectionArea": "",
        ///                                      "situactionCode": "",
        ///                                      "situactionCodeDate": "20190101"
        ///                                   }]
        ///                     }
        ///     }
        ///
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(Model.Partners.Policy.ZFscdApolicesPostWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<Model.Partners.Policy.ZFscdApolicesPostWsResponse1>> Policy([FromBody] Model.Partners.Policy.ZFscdApolicesPostWs requestPolicy)
        {
            try
            {
                //convert to IN structure
                var _response = await _policyRepository.GetPolicyAsync(requestPolicy);

                //creates a 200 (OK)
                Log.Debug("Policy Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response.ZFscdApolicesPostWsResponse.Errors.Length > 0)
                    {
                        return UnprocessableEntity(_response);
                    }
                }
                return Ok(_response);

            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError,String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors,String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }
        }

        /// <summary>
        /// Claimses the specified request sinister - ZFscdSinistrosPostWs
        /// </summary>
        /// <param name="requestSinister">The request sinister.</param>
        /// <returns></returns>
        /// <exception cref="StandardMessage">
        /// Not Found
        /// or
        /// Not Found
        /// </exception>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWsResponse1), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]
        public async Task<ActionResult<INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWsResponse1>> Claims([FromBody] INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWs requestSinister)
        {
            try
            {
                var _response = await _policyRepository.GetClaimsAsync(requestSinister);

                //creates a 200 (OK)
                Log.Debug("Claims Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response.ZFscdSinistrosPostWsResponse.Errors.Length > 0)
                    {
                        return UnprocessableEntity(_response);
                    }
                }
                return Ok(_response);


            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError,String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }
        }
    }
}
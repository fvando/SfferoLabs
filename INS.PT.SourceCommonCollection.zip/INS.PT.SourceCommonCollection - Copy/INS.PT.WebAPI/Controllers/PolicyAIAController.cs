﻿using System;
using System.Threading.Tasks;
using ins.pt.WebAPI;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;

namespace INS.PT.WebAPI.Controllers
{

    [Route("v1/[controller]/[Action]")]
    [ApiController]
    public class PolicyAIAController : BaseCore //ControllerBase
    {
        /// <summary>
        /// The policy repository
        /// </summary>
        private readonly IPolicyAiaRepository _policyAiaRepository;
        
        /// <summary>
        /// Initializes a new instance of the <see cref="PoliciesController"/> class.
        /// </summary>
        /// <param name="policyRepository">The policy repository.</param>
        public PolicyAIAController(IPolicyAiaRepository policyAiaRepository)
        {
            _policyAiaRepository = policyAiaRepository;
        }

        /// <summary>
        /// AIA the specified request PolicyAIA - ZfscdAiaGetPolicysWs
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=SourceCommonCollection_tst_examples#v1.2FPolicyAIA.2FGetPolicyAia
        ///
        ///     {  
        ///       "Receipts": [
        ///        {
        ///          "CompanyCode": "0010",
        ///          "DestinySystem": "AIA",
        ///          "Policy": "2RKA001848",
        ///          "Adherence": "",
        ///          "Operation": "",
        ///          "BeginDate": "20200101",
        ///          "EndDate": "20203112",
        ///          "GroupIndicator": ""
        ///        }
        ///      ]
        ///     }
        ///
        /// </remarks>
        [HttpPost(Name = "[controller]/[action]")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(INS.PT.WebAPI.Model.Partners.PolicyAIA.ZFscdAiaGetApolicesWsResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status408RequestTimeout)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status422UnprocessableEntity)]

        public async Task<ActionResult<SAP.Extern.WCF.Police.AIA.Service.Reference.Tst.ZFscdAiaGetApolicesWsResponse1>> GetPolicyAia([FromBody] 
        INS.PT.WebAPI.Model.Partners.PolicyAIA.ZfscdAiaGetPolicysWs requestPolicy)
        {
            try
            {
                var _response = await _policyAiaRepository.GetPolicyAiaAsync(requestPolicy);

                Log.Debug("GetPolicyAia Response: {_response}", JsonConvert.SerializeObject(_response));

                if (_response == null)
                {
                    return NotFound(_response);
                }
                else
                {
                    //Erro Externo
                    if (_response.ZFscdAiaGetApolicesWsResponse.Errors.Length > 0)
                    {
                        return UnprocessableEntity(_response);
                    }
                }
                return Ok(_response);


            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError,String.Empty);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            finally
            {
                Log.Debug("Finish");
            }

        }

      
     
    }
}
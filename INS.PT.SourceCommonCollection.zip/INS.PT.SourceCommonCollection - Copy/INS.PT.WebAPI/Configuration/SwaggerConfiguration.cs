﻿

using System;

namespace Ins.PT.WebAPI
{
    /// <summary>
    /// 
    /// </summary>
    public static class SwaggerConfiguration
    {

        /// <summary>
        /// The endpoint description
        /// </summary>
        public const string EndpointDescription = "Source Common Collection v2";

        /// <summary>
        /// The endpoint URL
        /// </summary>
        public const string EndpointUrl =  "../swagger/v1/swagger.json";

        /// <summary>
        /// The document name v1
        /// </summary>
        public const string DocNameV1 = "v1";

        /// <summary>
        /// <para>Foo API</para>
        /// </summary>
        public const string DocInfoTitle = "Source Common Collection API";

        /// <summary>
        /// <para>v1</para>
        /// </summary>
        public const string DocInfoVersion = "v2";

        /// <summary>
        /// <para>Foo Api - Sample Web API in ASP.NET Core 2</para>
        /// </summary>
        public const string DocInfoDescription = "Source Common Collection Api - Web API in ASP.NET Core 3.1";

        public static readonly string DocInfoContact = String.Empty;
        public static readonly string DocInfoLicense = String.Empty;
        public static readonly string DocInfoTermsOfService = String.Empty;
    }
}

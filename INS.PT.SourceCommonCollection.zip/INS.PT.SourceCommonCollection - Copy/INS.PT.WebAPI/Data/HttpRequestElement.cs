﻿using INS.PT.WebAPI.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Constants.CommonEnums;

namespace INS.PT.WebAPI.Data
{
    public class HttpRequestElement
    {
  //  "BrokerSettingsCanonical": {
  //  "Solution": "WaspCommonPortfolio",
  //  "User": "\\BS\\AgentsPortalD",
  //  "ContentTypeJson": "application/json",
  //  "IdCompany": "AGEAS",
  //  "IdNetwork": "AGEAS",
  //  "Endpoint": "https://bs-ts.servicenp.ageas.intra/n1/th.ashx",
  //  "SoapEndPoint": "https://bs-ts.servicenp.ageas.intra/n1/ts.ashx",
  //  "WebService": "ageas-api-ReferenceData",
  //  "WebMethod": "v1/ReferenceData"
  //}
        public string ContentType { get; set; }

        public string ApiService { get; set; }

        public string ApiMethod { get; set; }

        public string EndPoint { get; set; }

        public string SoapEndPoint { get; set; }

        public string Solution { get; set; }

        public string User { get; set; }

        public string RouteValue { get; set; }

        public Microsoft.AspNetCore.Http.QueryString QueryString { get; set; }

        public HttpRequestVerb Method { get; set; }

        /// <summary>
        /// Object that contains options for response handling or other exceptions to normal behaviour
        /// </summary>
        public OptionsElement Options { get; set; }

        public object RequestObject { get; set; }
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace ins.pt.WebAPI
{


    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.ControllerBase" />
    public class BaseCore: ControllerBase
    {
        //const int sizeBuffer = 1000;

        //const string _ObjectData = "p_dados";
        //protected readonly IHttpContextAccessor httpContext;

        public BaseCore()
        {
           // this.httpContext = httpContext ?? throw new ArgumentNullException(nameof(httpContext));
        }

        //internal static void AddOutputParameters(OracleDynamicParameters oracleDynamicParameters)
        //{
        //    oracleDynamicParameters.Add(_ObjectData, OracleDbType.RefCursor, direction: ParameterDirection.Output);
        //    oracleDynamicParameters.Add(nameof(ObjectErrors.p_erro), OracleDbType.Varchar2, direction: ParameterDirection.Output, value: null, size: sizeBuffer);
        //    oracleDynamicParameters.Add(nameof(ObjectErrors.p_dserro), OracleDbType.Varchar2, direction: ParameterDirection.Output, value: null, size: sizeBuffer);
        //}


        //protected virtual HeaderParameters ValidateHeader()
        //{
        //    var headerParameters = new HeaderParameters();
        //    var errors = new List<ValidationResult>();

        //    // read header parameters
        //    headerParameters.IdCompany = ReadHeaderParameter(nameof(headerParameters.IdCompany));
        //    headerParameters.IdSource = ReadHeaderParameter(nameof(headerParameters.IdSource));

        //    // execute validation
        //    Validator.TryValidateObject(headerParameters, new ValidationContext(headerParameters), errors, true);

        //    if (errors.Any())
        //    {
        //        throw new AggregateException(
        //               errors.Select((e) => new ValidationException(e.ErrorMessage)));
        //    }

        //    return headerParameters;
        //}

        //private string ReadHeaderParameter(string parameterName)
        //{
        //    // try to read header value
        //    if (!string.IsNullOrEmpty(parameterName) && httpContext != null
        //        && httpContext.HttpContext.Request.Headers.TryGetValue(parameterName, out var headerValues))
        //    {
        //        return headerValues.First();
        //    }

        //    return null;
        //}
    }
}

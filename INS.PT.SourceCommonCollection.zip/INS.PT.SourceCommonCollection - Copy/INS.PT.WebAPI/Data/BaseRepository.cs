﻿using INS.PT.WebAPI.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Data
{
    public class BaseRepository
    {
        #region Properties
        protected readonly HttpRequest request;
        protected readonly IRepositoryInvoker repositoryInvoker;
        protected readonly IConfiguration configuration;

        #endregion

        public BaseRepository(IConfiguration _configuration)
        {
            configuration = _configuration;
        }

        public BaseRepository(IConfiguration _configuration, IRepositoryInvoker _repositoryInvoker)
            : this(_configuration)
        {
            repositoryInvoker = _repositoryInvoker;
        }


        public BaseRepository(IConfiguration _configuration, IRepositoryInvoker _repositoryInvoker, HttpRequest _request)
            : this(_configuration, _repositoryInvoker)
        {
            request = _request;
        }

         
    }
}

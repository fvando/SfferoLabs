﻿using INS.PT.WebAPI.Model.Partners.ProvisionWebAccount;
using Newtonsoft.Json;
using System.Collections.Generic;
 

namespace INS.PT.WebAPI.Helper
{
    /// <summary>
    /// ValidateReceiptLineDetailResponse
    /// </summary>
    public class ValidateReceiptLineDetailResponse 
    {
        public List<ValidateReceiptDetail> PcReceipts { get; set; }
    }

    public class ValidateReceiptDetail: ZfscdPcRecibosLinha
    {
        public List<ValidateStatusDetail> Status { get; set; }
    }

    public class ValidateStatusDetail 
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCodeTxt { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCode { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public bool Situation { get; set; } = true;
    }
}

﻿using INS.PT.WebAPI.Constants;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model.Partners.ProvisionWebAccount;
using INS.PT.WebAPI.Model.Partners.WebReceiptListing;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Helper
{
    public class TransformationData : ITransformationData
    {

        private readonly IStatesRepository statesRepository;

        public TransformationData(IStatesRepository _statesRepository)
        {
            statesRepository = _statesRepository;
        }

        public async Task<Model.Partners.ProvisionWebAccount.ZFscdPcListarWsResponse1> PutDomainAsync(ZFscdPcListarWsResponse1 requestList)
        {
            //BranchDescripton
            foreach (var item in requestList.ZFscdPcListarWsResponse.PcHeader)
            {
                item.BranchDescripton = await statesRepository.GetbyValueAsync(item.CompanyCode, CommonEnums.DomainsData.SAP004);
            }
            return requestList;
        }

        public async Task PutDomainAsync(Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWsResponse1 requestQuery)
        {
            var companyCode = requestQuery?.ZFscdPcConsultarWsResponse?.PcHeader?.CompanyCode;
            //Test for InternalCode
            if (!string.IsNullOrEmpty(companyCode)) {
                requestQuery.ZFscdPcConsultarWsResponse.PcHeader.BranchDescripton = await statesRepository.GetbyValueAsync(companyCode, CommonEnums.DomainsData.SAP004);
            }
        }

        public ChargedReceiptLineDetailResponse ChargedList(ZFscdPcCobrarWs inputList, ZFscdPcCobrarWsResponse1 outPutList)
        {
            //Se lista retornar vazia, todos os recibos estão validados
            var ReceiptLinhaDetail = new ChargedReceiptLineDetailResponse()
            {
                PcReceipts = new List<ChargedReceiptDetail>()
            };

            //InputProcess
            foreach (var item in inputList?.PcReceipts)
            {
                ReceiptLinhaDetail.PcReceipts.Add(new ChargedReceiptDetail()
                {
                    InsuranceBroker = item.InsuranceBroker,
                    CompanyCode = item.CompanyCode,
                    DocumentType = item.DocumentType,
                    ReferenceDocumentNumber = item.ReferenceDocumentNumber,
                    SapDocumentNumber = item.SapDocumentNumber,
                    DocumentNumber = item.DocumentNumber,
                    InsurancePartner = item.InsurancePartner,
                    InsuranceObject = item.InsuranceObject,
                    Amount = item.Amount,
                    Currency = item.Currency,
                    VwReference = item.VwReference,
                    VwPolicy = item.VwPolicy,
                    VwPostDate = item.VwPostDate,
                    VwNetDueDate = item.VwNetDueDate,
                    Status = new List<ChargedStatusDetail>()
                });
            }

            //OutputProcess
            if (outPutList.ZFscdPcCobrarWsResponse?.Errors.Length > 0)
            {
                foreach (var itemError in outPutList?.ZFscdPcCobrarWsResponse?.Errors)
                {
                    //achar a posição na lista ZfscdPcRecibosLinhaDetail e preencher se houver erros
                    foreach (var itemReceipt in ReceiptLinhaDetail?.PcReceipts)
                    {
                        //Depending on the error caused, the SAP result, the itemError?.Receipt field, can come with the receipt number or agent code.
                        //ReferenceDocumentNumber or InsuranceBroker
                        var tmpReference = itemReceipt.ReferenceDocumentNumber;
                        var tmpItemError = itemError?.Receipt;
                        var tmpInputList = inputList?.BrokerContract;

                        if ((tmpReference.Replace("0", "") == tmpItemError.Replace("0", "")) || (tmpInputList.Replace("0", "") == tmpItemError.Replace("0", "")))
                        {
                            foreach (var itemErroDetail in itemError?.Errors)
                            {
                                itemReceipt.Status.Add(new ChargedStatusDetail()
                                {
                                    ErrorCode = itemErroDetail?.ErrorCode,
                                    ErrorCodeTxt = itemErroDetail?.ErrorCodeTxt,
                                    Situation = false
                                });
                            }
                        }
                    }
                }
            }
            else {
                foreach (var itemReceipt in ReceiptLinhaDetail?.PcReceipts)
                {
                            itemReceipt.Status.Add(new ChargedStatusDetail()
                            {
                                Situation = true
                            });
                }
            } 
            
            return ReceiptLinhaDetail;
        }

        public ValidateReceiptLineDetailResponse ValidateList(ZFscdPcValidarWs inputList, ZFscdPcValidarWsResponse1 outPutList)
    {
        //Se lista retornar vazia, todos os recibos estão validados
        var ReceiptLinhaDetail = new ValidateReceiptLineDetailResponse()
        {
            PcReceipts = new List<ValidateReceiptDetail>()
        };

        //InputProcess
        foreach (var item in inputList.PcReceipts)
        {
            ReceiptLinhaDetail.PcReceipts.Add(new ValidateReceiptDetail()
            {
                InsuranceBroker = item.InsuranceBroker,
                CompanyCode = item.CompanyCode,
                DocumentType = item.DocumentType,
                ReferenceDocumentNumber = item.ReferenceDocumentNumber,
                SapDocumentNumber = item.SapDocumentNumber,
                DocumentNumber = item.DocumentNumber,
                InsurancePartner = item.InsurancePartner,
                InsuranceObject = item.InsuranceObject,
                Amount = item.Amount,
                Currency = item.Currency,
                VwReference = item.VwReference,
                VwPolicy = item.VwPolicy,
                VwPostDate = item.VwPostDate,
                VwNetDueDate = item.VwNetDueDate,
                Status = new List<ValidateStatusDetail>()
            });
        }

        //OutputProcess
        if (outPutList.ZFscdPcValidarWsResponse?.Errors.Length > 0)
        {
            foreach (var itemError in outPutList?.ZFscdPcValidarWsResponse?.Errors)
            {
                //achar a posição na lista ZfscdPcRecibosLinhaDetail e preencher se houver erros
                foreach (var itemReceipt in ReceiptLinhaDetail?.PcReceipts)
                {
                        //Depending on the error caused, the SAP result, the itemError?.Receipt field, can come with the receipt number or agent code.
                        //ReferenceDocumentNumber or InsuranceBroker
                    if ((itemReceipt.ReferenceDocumentNumber.Replace("0","") ==  itemError?.Receipt.Replace("0","")) || (inputList?.BrokerContract == itemError?.Receipt))
                    {
                        foreach (var itemErroDetail in itemError?.Errors)
                        {
                                itemReceipt.Status.Add(new ValidateStatusDetail()
                                {
                                    ErrorCode = itemErroDetail?.ErrorCode,
                                    ErrorCodeTxt = itemErroDetail?.ErrorCodeTxt,
                                    Situation = false
                                });
                        }
                    }
                }
            }
        }else {
                foreach (var itemReceipt in ReceiptLinhaDetail?.PcReceipts)
                {
                            itemReceipt.Status.Add(new ValidateStatusDetail()
                            {
                                Situation = true
                            });
                }
        }
        return ReceiptLinhaDetail;
    }

        public LiquidatePaymentsLineDetailResponse LiquidateList(ZFscdPcLiquidarWs inputList, ZFscdPcLiquidarWsResponse1 outPutList)
    {
        //Se lista retornar vazia, todos os recibos estão validados
        var LiquidateLinhaDetail = new LiquidatePaymentsLineDetailResponse()
        {
            PcPayments = new List<LiquidateReceiptDetail>()
        };

        //InputProcess
        LiquidateLinhaDetail.PcPayments.Add(new LiquidateReceiptDetail()
        {
            EntSibs = inputList.BrokerPaymentsValues.EntSibs,
            PayMethod1 = inputList.BrokerPaymentsValues.PayMethod1,
            PayMethod2 = inputList.BrokerPaymentsValues.PayMethod2,
            RefSibs = inputList.BrokerPaymentsValues.RefSibs,
            TotalValue = inputList.BrokerPaymentsValues.TotalValue,
            ValuePay1 = inputList.BrokerPaymentsValues.ValuePay1,
            ValuePay2 = inputList.BrokerPaymentsValues.ValuePay2,
            Status = new List<LiquidateStatusDetail>()
        });

        //OutputProcess
        if (outPutList.ZFscdPcLiquidarWsResponse?.Errors.Length > 0)
        {
            foreach (var itemReceipt in LiquidateLinhaDetail?.PcPayments)
            {
                //achar a posição na lista ZfscdPcRecibosLinhaDetail e preencher se houver erros
                foreach (var itemError in outPutList?.ZFscdPcLiquidarWsResponse?.Errors)
                {
                    itemReceipt.Status.Add(
                        new LiquidateStatusDetail()
                        {
                            ErrorCode = itemError?.ErrorCode,
                            ErrorCodeTxt = itemError?.ErrorCodeTxt,
                            Situation = false
                        }
                   );
                }
            }
        }else
            {
                foreach (var itemReceipt in LiquidateLinhaDetail?.PcPayments)
                {
                    itemReceipt.Status.Add(new LiquidateStatusDetail()
                    {
                        Situation = true
                    });
                }
         }
            return LiquidateLinhaDetail;
    }

        public async Task<ZFscdRecibosListarWsResponse> GetDescriptionDomainAsync(ZFscdRecibosListarWsResponse requestList, CommonEnums.DomainsData domain)
        {
            //BranchDescripton
            foreach (var item in requestList.ReceiptsNumbers)
            {
                item.DescriptionReturnReason = statesRepository.GetbyValueAsync(item.ReturnReason, domain).Result;
            }
            return requestList;
        }

    }
}

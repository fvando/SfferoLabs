﻿using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Helper
{
    public static class ValidationsStatusWebReceiptListing
    {
        //COBRADOS
        public static string StatusConverter(string value, string defaultValue)
        {
            return (!string.IsNullOrEmpty(value) ? "C" : defaultValue);
        }
        public static string StatusTxtConverter(string value, string defaultValue)
        {
            return (!string.IsNullOrEmpty(value) ? "COBRADO" : defaultValue);
        }


    }
}

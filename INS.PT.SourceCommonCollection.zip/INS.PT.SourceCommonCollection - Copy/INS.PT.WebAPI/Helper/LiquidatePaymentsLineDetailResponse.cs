﻿using INS.PT.WebAPI.Model.Partners.ProvisionWebAccount;
using Newtonsoft.Json;
using System.Collections.Generic;
 

namespace INS.PT.WebAPI.Helper
{
    /// <summary>
    /// LiquidatePaymentsLineDetailResponse
    /// </summary>
    public class LiquidatePaymentsLineDetailResponse
    {
        public List<LiquidateReceiptDetail> PcPayments { get; set; }
    }

    public class LiquidateReceiptDetail: ZfscdPcPaymentsValues
    {
        public List<LiquidateStatusDetail> Status { get; set; }
    }

    public class LiquidateStatusDetail
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCodeTxt { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCode { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public bool Situation { get; set; } = true;
    }
}

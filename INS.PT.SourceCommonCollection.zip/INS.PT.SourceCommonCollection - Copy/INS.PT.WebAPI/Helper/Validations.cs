﻿using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Helper
{
    /// <summary>
    /// 
    /// </summary>
    public static class Validations
    {
        /// <summary>
        /// 
        /// </summary>
        /// <seealso cref="Newtonsoft.Json.Converters.IsoDateTimeConverter" />
        public class DateFormatConverter : IsoDateTimeConverter
        {
            /// <summary>
            /// Initializes a new instance of the <see cref="DateFormatConverter"/> class.
            /// </summary>
            /// <param name="format">The format.</param>
            public DateFormatConverter(string format)
            {
                DateTimeFormat = format;
            }

        }

        /// <summary>
        /// Strings the format converter.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public static string StringFormatConverter(string value)
        {
            return String.Format("{0:00000}", value.Trim());
        }




        //String with space



        //Double



    }

  
}

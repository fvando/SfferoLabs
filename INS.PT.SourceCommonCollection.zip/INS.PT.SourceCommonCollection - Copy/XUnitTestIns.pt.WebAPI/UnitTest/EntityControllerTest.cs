﻿using AutoMapper;
using ins.pt.WebAPI;
using INS.PT.WebAPI;
using INS.PT.WebAPI.Cancel;
using INS.PT.WebAPI.Controllers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model.Partners.Policy;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Security.Claims;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.UnitTestEntity
{
    public class EntityControllerTest
    {

        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<ContextApi> _testContextApiMock;
        private readonly Mock<IHttpContextAccessor> _httpContext;

        public EntityControllerTest()
        {
            _testContextApiMock = new Mock<ContextApi>();
            _mapperMock = new Mock<IMapper>();
            _httpContext = new Mock<IHttpContextAccessor>();
        }

        //[Fact]
        //public async Task Entity_Test001_resultAsync()
        //{
        //    //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
        //    //Object OUT

        //    var _erro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdCodigosErroLinhaEntity
        //    {
        //        ErrorCode = "998",
        //        ErrorCodeTxt = ""
        //    };

        //    var _arrayError = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdCodigosErroLinhaEntity>
        //    {
        //        _erro
        //    };

        //    var _phones = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroTelefone()
        //    {
        //        Country = "?",
        //        TelDefault = "?",
        //        Telephone = "?"
        //    };
        //    var _arrayphone = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroTelefone>
        //    {
        //        _phones
        //    };


        //    var _address = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroMorada
        //    {
        //        AddressNotes = "",
        //        AddressType = "",
        //        City = "",
        //        Country = "",
        //        ExtAddressNumber = "",
        //        HomeCity = "",
        //        HouseNumber = "",
        //        PostCode = "",
        //        Street = "",
        //        StrSuppl1 = "",
        //        StrSuppl2 = "",
        //        StrSuppl3 = ""
        //    };

        //    var _banks = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroIban()
        //    {
        //        Iban = "" 
        //    };
        //    var _arrayBanks = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroIban>
        //    {
        //        _banks
        //    };

        //    var _emails = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroEmail() {
        //        Email = ""
        //    };
        //    var _arrayEmail = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroEmail>
        //    {
        //        _emails
        //    };
 
        //    var _arrayAddress = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroMorada>
        //    {
        //        _address
        //    };

        //    var _parceiro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha()
        //    {
        //        Addresses = _arrayAddress.ToArray(),
        //        Banks = _arrayBanks.ToArray(),
        //        BirthDate = "",
        //        CommType = "",
        //        CompanyCode = "",
        //        EntityType = "",
        //        Errors = _arrayError.ToArray(),
        //        FormKeyTitle = "",
        //        FirstName = "",
        //        LastName = "",
        //        Mails = _arrayEmail.ToArray(),
        //        MaritalStatus = "",
        //        MiddleName = "",
 
        //        Nationality = "",
        //        Network = "",
        //        PartnerExternalSystem = "",
        //        Phones = _arrayphone.ToArray(),
        //        Sex = "",
        //        TaxNumber = "",
        //        TaxType = ""
        //    };

        //    var _arrayParceiro = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha>
        //    {
        //        _parceiro
        //    };

        //    //Object IN
        //    var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWs()
        //    {
        //     Partners = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceirosLinha() {
        //         Interface = "",
        //         ItemsTotal = "",
        //         Online = "",
        //         OriginalSystem = "",
        //         Partner = _arrayParceiro.ToArray(),
        //         SystemDate = "",
        //         SystemTime = "",
        //         Transaction = ""
        //     }
        //    };

        //    //auto mapper configurationExpression
        //    var mockMapper = new MapperConfiguration(cfg =>
        //    {
        //        cfg.AddProfile(new AutoMapperProfileConfiguration());
        //    });
        //    var mapper = mockMapper.CreateMapper();

        //    // Arrange
        //    var mockRepository = new Mock<IEntitiesRepository>();
        //    mockRepository.Setup(x => x.GetWsClient("EPTSTEntity")).Returns(new INS.PT.WebAPI.Entity.EntitiesRepository(_testContextApiMock.Object._configuration).GetWsClient("EPTSTEntity"));

        //    var _controller = new INS.PT.WebAPI.Controllers.EntitiesController(mapper, mockRepository.Object);

        //    Exception expectedException = null;
        //    INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWsResponse1 ObjResult = null;
        //    try
        //    {
        //        ObjResult = await _controller.Partner(_pcQueryWsModel);
        //    }
        //    catch (Exception ex)//exception catched - control not stopped 
        //    {
        //        expectedException = ex;
        //        Assert.IsType<System.ServiceModel.FaultException>(expectedException);
        //    }

        //    if (ObjResult != null)
        //    {
        //        Assert.NotNull(ObjResult);
        //    }
        //}

        //[Fact]
        //public async Task Entity_Test002_resultAsync()
        //{
        //    //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
        //    //Object OUT

        //    var _erro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdCodigosErroLinhaEntity
        //    {
        //        ErrorCode = "998",
        //        ErrorCodeTxt = ""
        //    };

        //    var _arrayError = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdCodigosErroLinhaEntity>
        //    {
        //        _erro
        //    };

        //    var _phones = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroTelefone() {
        //        Country = "?",
        //        TelDefault = "?",
        //        Telephone = "?"
        //    };
        //    var _arrayphone = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroTelefone>
        //    {
        //        _phones
        //    };


        //    var _address = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroMorada
        //    {
        //        AddressNotes = "?",
        //        AddressType = "?",
        //        City = "?",
        //        Country = "?",
        //        ExtAddressNumber = "?",
        //        HomeCity = "?",
        //        HouseNumber = "?",
        //        PostCode = "?",
        //        Street = "?",
        //        StrSuppl1 = "?",
        //        StrSuppl2 = "?",
        //        StrSuppl3 = "?"
        //    };

        //    var _banks = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroIban()
        //    {
        //        Iban = "?" 
        //    };
        //    var _arrayBanks = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroIban>
        //    {
        //        _banks
        //    };

        //    var _emails = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroEmail()
        //    {
        //        Email = "?"
        //    };
        //    var _arrayEmail = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroEmail>
        //    {
        //        _emails
        //    };
 
           

        //    var _arrayAddress = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroMorada>
        //    {
        //        _address
        //    };

        //    var _parceiro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha()
        //    {
        //        Addresses = _arrayAddress.ToArray(),
        //        Banks = _arrayBanks.ToArray(),
        //        BirthDate = "?",
        //        CommType = "?",
        //        CompanyCode = "?",
        //        EntityType = "?",
        //        Errors = _arrayError.ToArray(),
        //        FormKeyTitle = "?",
        //        FirstName = "?",
        //        LastName = "",
        //        Mails = _arrayEmail.ToArray(),
        //        MaritalStatus = "?",
        //        MiddleName = "?",
     
        //        Nationality = "?",
        //        Network = "?",
        //        PartnerExternalSystem = "?",
        //        Phones = _arrayphone.ToArray(),
        //        Sex = "?",
        //        TaxNumber = "?",
        //        TaxType = "?"
        //    };

        //    var _arrayParceiro = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha>
        //    {
        //        _parceiro
        //    };

        //    //Object IN
        //    var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWs()
        //    {
        //        Partners = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceirosLinha()
        //        {
        //            Interface = "?",
        //            ItemsTotal = "?",
        //            Online = "?",
        //            OriginalSystem = "?",
        //            Partner = _arrayParceiro.ToArray(),
        //            SystemDate = "?",
        //            SystemTime = "?",
        //            Transaction = "?"
        //        }
        //    };

        //    //auto mapper configurationExpression
        //    var mockMapper = new MapperConfiguration(cfg =>
        //    {
        //        cfg.AddProfile(new AutoMapperProfileConfiguration());
        //    });
        //    var mapper = mockMapper.CreateMapper();

        //    // Arrange
        //    var mockRepository = new Mock<IEntitiesRepository>();
        //    mockRepository.Setup(x => x.GetWsClient("EPTSTEntity")).Returns(new INS.PT.WebAPI.Entity.EntitiesRepository(_testContextApiMock.Object._configuration).GetWsClient("EPTSTEntity"));

        //    var _controller = new INS.PT.WebAPI.Controllers.EntitiesController(mapper, mockRepository.Object);

        //    Exception expectedException = null;
        //    INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWsResponse1 ObjResult = null;
        //    try
        //    {
        //        ObjResult = await _controller.Partner(_pcQueryWsModel);
        //    }
        //    catch (Exception ex)//exception catched - control not stopped 
        //    {
        //        expectedException = ex;
        //        Assert.IsType<System.ServiceModel.FaultException>(expectedException);
        //    }

        //    if (ObjResult != null)
        //    {
        //        Assert.NotNull(ObjResult);
        //    }
        //}


        //[Fact]
        //public async Task Entity_Test003_resultAsync()
        //{
    
        
        //    var _parceiro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha()
        //    {
        //        Addresses = null, //_arrayAddress.ToArray(),
        //        Banks = null, //_arrayBanks.ToArray(),
        //        BirthDate = "?",
        //        CommType = "?",
        //        CompanyCode = "?",
        //        EntityType = "?",
        //        Errors = null, //_arrayError.ToArray(),
        //        FormKeyTitle = "?",
        //        FirstName = "?",
        //        LastName = "",
        //        Mails = null, //_arrayEmail.ToArray(),
        //        MaritalStatus = "?",
        //        MiddleName = "?",
             
        //        Nationality = "?",
        //        Network = "?",
        //        PartnerExternalSystem = "?",
        //        Phones = null, //_arrayphone.ToArray(),
        //        Sex = "?",
        //        TaxNumber = "?",
        //        TaxType = "?"
        //    };

        //    var _arrayParceiro = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha>
        //    {
        //        _parceiro
        //    };

        //    //Object IN
        //    var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWs()
        //    {
        //        Partners = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceirosLinha()
        //        {
        //            Interface = "?",
        //            ItemsTotal = "?",
        //            Online = "?",
        //            OriginalSystem = "?",
        //            Partner = _arrayParceiro.ToArray(),
        //            SystemDate = "?",
        //            SystemTime = "?",
        //            Transaction = "?"
        //        }
        //    };

        //    //auto mapper configurationExpression
        //    var mockMapper = new MapperConfiguration(cfg =>
        //    {
        //        cfg.AddProfile(new AutoMapperProfileConfiguration());
        //    });
        //    var mapper = mockMapper.CreateMapper();

        //    // Arrange
        //    var mockRepository = new Mock<IEntitiesRepository>();
        //    mockRepository.Setup(x => x.GetWsClient("EPTSTEntity")).Returns(new INS.PT.WebAPI.Entity.EntitiesRepository(_testContextApiMock.Object._configuration).GetWsClient("EPTSTEntity"));

        //    var _controller = new INS.PT.WebAPI.Controllers.EntitiesController(mapper, mockRepository.Object);

        //    Exception expectedException = null;
        //    INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWsResponse1 ObjResult = null;
        //    try
        //    {
        //        ObjResult = await _controller.Partner(_pcQueryWsModel);
        //    }
        //    catch (Exception ex)//exception catched - control not stopped 
        //    {
        //        expectedException = ex;
        //        Assert.IsType<System.ServiceModel.FaultException>(expectedException);
        //    }

        //    if (ObjResult != null)
        //    {
        //        Assert.NotNull(ObjResult);
        //    }
        //}

        //[Fact]
        //public async Task Entity_Test004_resultAsync()
        //{
        //    //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
        //    //Object OUT

        //    DateTime max = DateTime.MaxValue;

        //    var _erro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdCodigosErroLinhaEntity
        //    {
        //        ErrorCode = "998",
        //        ErrorCodeTxt = ""
        //    };

        //    var _arrayError = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdCodigosErroLinhaEntity>
        //    {
        //        _erro
        //    };

        //    var _phones = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroTelefone()
        //    {
        //        Country = "?",
        //        TelDefault = "?",
        //        Telephone = "?"
        //    };
        //    var _arrayphone = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroTelefone>
        //    {
        //        _phones
        //    };


        //    var _address = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroMorada
        //    {
        //        AddressNotes = "?",
        //        AddressType = "?",
        //        City = "?",
        //        Country = "?",
        //        ExtAddressNumber = "?",
        //        HomeCity = "?",
        //        HouseNumber = "?",
        //        PostCode = "?",
        //        Street = "?",
        //        StrSuppl1 = "?",
        //        StrSuppl2 = "?",
        //        StrSuppl3 = "?"
        //    };

        //    var _banks = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroIban()
        //    {
        //        Iban = "?" 
        //    };
        //    var _arrayBanks = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroIban>
        //    {
        //        _banks
        //    };

        //    var _emails = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroEmail()
        //    {
        //        Email = "?"
        //    };
        //    var _arrayEmail = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroEmail>
        //    {
        //        _emails
        //    };

       
        //    var _arrayAddress = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroMorada>
        //    {
        //        _address
        //    };

        //    var _parceiro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha()
        //    {
        //        Addresses = _arrayAddress.ToArray(),
        //        Banks = _arrayBanks.ToArray(),
        //        BirthDate = "?",
        //        CommType = "?",
        //        CompanyCode = "?",
        //        EntityType = "?",
        //        Errors = _arrayError.ToArray(),
        //        FormKeyTitle = "?",
        //        FirstName = "?",
        //        LastName = "",
        //        Mails = _arrayEmail.ToArray(),
        //        MaritalStatus = "?",
        //        MiddleName = "?",
           
        //        Nationality = "?",
        //        Network = "?",
        //        PartnerExternalSystem = "?",
        //        Phones = _arrayphone.ToArray(),
        //        Sex = "?",
        //        TaxNumber = "?",
        //        TaxType = "?"
        //    };

        //    var _arrayParceiro = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha>
        //    {
        //        _parceiro
        //    };

        //    //Object IN
        //    var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWs()
        //    {
        //        Partners = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceirosLinha()
        //        {
        //            Interface = "?",
        //            ItemsTotal = "?",
        //            Online = "?",
        //            OriginalSystem = "?",
        //            Partner = _arrayParceiro.ToArray(),
        //            SystemDate = max.ToString(),
        //            SystemTime = "?",
        //            Transaction = "?"
        //        }
        //    };

        //    //auto mapper configurationExpression
        //    var mockMapper = new MapperConfiguration(cfg =>
        //    {
        //        cfg.AddProfile(new AutoMapperProfileConfiguration());
        //    });
        //    var mapper = mockMapper.CreateMapper();

        //    // Arrange
        //    var mockRepository = new Mock<IEntitiesRepository>();
        //    mockRepository.Setup(x => x.GetWsClient("EPTSTEntity")).Returns(new INS.PT.WebAPI.Entity.EntitiesRepository(_testContextApiMock.Object._configuration).GetWsClient("EPTSTEntity"));

        //    var _controller = new INS.PT.WebAPI.Controllers.EntitiesController(mapper, mockRepository.Object);

        //    Exception expectedException = null;
        //    INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWsResponse1 ObjResult = null;
        //    try
        //    {
        //        ObjResult = await _controller.Partner(_pcQueryWsModel);
        //    }
        //    catch (Exception ex)//exception catched - control not stopped 
        //    {
        //        expectedException = ex;
        //        Assert.IsType<System.ServiceModel.FaultException>(expectedException);
        //    }

        //    if (ObjResult != null)
        //    {
        //        Assert.NotNull(ObjResult);
        //    }
        //}


        //[Fact]
        //public async Task Entity_Test005_resultAsync()
        //{
        //    //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
        //    //Object OUT

        //    DateTime min = DateTime.MinValue;

        //    var _erro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdCodigosErroLinhaEntity
        //    {
        //        ErrorCode = "998",
        //        ErrorCodeTxt = ""
        //    };

        //    var _arrayError = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdCodigosErroLinhaEntity>
        //    {
        //        _erro
        //    };

        //    var _phones = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroTelefone()
        //    {
        //        Country = "?",
        //        TelDefault = "?",
        //        Telephone = "?"
        //    };
        //    var _arrayphone = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroTelefone>
        //    {
        //        _phones
        //    };


        //    var _address = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroMorada
        //    {
        //        AddressNotes = "?",
        //        AddressType = "?",
        //        City = "?",
        //        Country = "?",
        //        ExtAddressNumber = "?",
        //        HomeCity = "?",
        //        HouseNumber = "?",
        //        PostCode = "?",
        //        Street = "?",
        //        StrSuppl1 = "?",
        //        StrSuppl2 = "?",
        //        StrSuppl3 = "?"
        //    };

        //    var _banks = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroIban()
        //    {
        //        Iban = "?" 
        //    };
        //    var _arrayBanks = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroIban>
        //    {
        //        _banks
        //    };

        //    var _emails = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroEmail()
        //    {
        //        Email = "?"
        //    };
        //    var _arrayEmail = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroEmail>
        //    {
        //        _emails
        //    };

        
        //    var _arrayAddress = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroMorada>
        //    {
        //        _address
        //    };

        //    var _parceiro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha()
        //    {
        //        Addresses = _arrayAddress.ToArray(),
        //        Banks = _arrayBanks.ToArray(),
        //        BirthDate = "?",
        //        CommType = "?",
        //        CompanyCode = "?",
        //        EntityType = "?",
        //        Errors = _arrayError.ToArray(),
        //        FormKeyTitle = "?",
        //        FirstName = "?",
        //        LastName = "",
        //        Mails = _arrayEmail.ToArray(),
        //        MaritalStatus = "?",
        //        MiddleName = "?",
              
        //        Nationality = "?",
        //        Network = "?",
        //        PartnerExternalSystem = "?",
        //        Phones = _arrayphone.ToArray(),
        //        Sex = "?",
        //        TaxNumber = "?",
        //        TaxType = "?"
        //    };

        //    var _arrayParceiro = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha>
        //    {
        //        _parceiro
        //    };

        //    //Object IN
        //    var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWs()
        //    {
        //        Partners = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceirosLinha()
        //        {
        //            Interface = "?",
        //            ItemsTotal = "?",
        //            Online = "?",
        //            OriginalSystem = "?",
        //            Partner = _arrayParceiro.ToArray(),
        //            SystemDate = min.ToString(),
        //            SystemTime = "?",
        //            Transaction = "?"
        //        }
        //    };

        //    //auto mapper configurationExpression
        //    var mockMapper = new MapperConfiguration(cfg =>
        //    {
        //        cfg.AddProfile(new AutoMapperProfileConfiguration());
        //    });
        //    var mapper = mockMapper.CreateMapper();

        //    // Arrange
        //    var mockRepository = new Mock<IEntitiesRepository>();
        //    mockRepository.Setup(x => x.GetWsClient("EPTSTEntity")).Returns(new INS.PT.WebAPI.Entity.EntitiesRepository(_testContextApiMock.Object._configuration).GetWsClient("EPTSTEntity"));

        //    var _controller = new INS.PT.WebAPI.Controllers.EntitiesController(mapper, mockRepository.Object);

        //    Exception expectedException = null;
        //    INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWsResponse1 ObjResult = null;
        //    try
        //    {
        //        ObjResult = await _controller.Partner(_pcQueryWsModel);
        //    }
        //    catch (Exception ex)//exception catched - control not stopped 
        //    {
        //        expectedException = ex;
        //        Assert.IsType<System.ServiceModel.FaultException>(expectedException);
        //    }

        //    if (ObjResult != null)
        //    {
        //        Assert.NotNull(ObjResult);
        //    }
        //}
    }

}
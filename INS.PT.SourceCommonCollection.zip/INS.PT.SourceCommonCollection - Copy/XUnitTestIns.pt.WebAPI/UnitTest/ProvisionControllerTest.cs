﻿using AutoMapper;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.WebAPI.Controllers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.UnitTestProvision
{
    public class ProvisionQueryControllerTest
    {

        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<ContextApi> _testContextApiMock;
        private readonly Mock<IHttpContextAccessor> _httpContext;

        public ProvisionQueryControllerTest()
        {
            _testContextApiMock = new Mock<ContextApi>();
            _mapperMock = new Mock<IMapper>();
            _httpContext = new Mock<IHttpContextAccessor>();
        }

        //[Fact]
        //public async Task Charged_Test001_resultAsync()
        //{
        //    //Object IN
        //    var Input = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWs
        //    {
        //        BrokerContract = "",
        //        PcReceipts = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>() {
        //            new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha(){
        //             Amount = 0,
        //             CompanyCode = "",
        //             Currency = "",
        //             DocumentNumber = "",
        //             DocumentType = "",
        //             InsuranceBroker = "",
        //             InsuranceObject = "",
        //             InsurancePartner = "",
        //             ReferenceDocumentNumber = "",
        //             SapDocumentNumber = ""
        //            }
        //        }.ToArray()

        //    };

        //    var mockRepository = new Mock<IProvisionsRepository>();

        //    var output = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWsResponse1() {
        //        ZFscdPcCobrarWsResponse = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWsResponse()
        //        {
        //            Errors = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroRecibos>() { }.ToArray()
        //        }
        //    };

        //    mockRepository.Setup(x => x.GetChargedAsync(Input)).ReturnsAsync(output);

        //    var _controller = new ProvisionWebAccountsController(mockRepository.Object, null);

        //    // Act
        //    var result = await _controller.Charged(Input);

        //    // Assert
        //    Assert.IsType<Microsoft.AspNetCore.Mvc.ActionResult<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWsResponse1>>(result);
        //}

        [Theory]
        [InlineData(null, 0, null, null, null, null, null, null, null, null, null)]
        [InlineData("string", 0, "string", "string", "string", "string", "string", "string", "string", "string", "string")]
        [InlineData("", 0, "", "", "", "", "", "", "", "", "")]
        [InlineData("?", 0, "?", "?", "?", "?", "?", "?", "?", "?", "?")]

        public async Task Charged_Test002_resultAsync(string pBrokerContract,
             decimal pAmount,
             string pCompanyCode,
             string pCurrency,
             string pDocumentNumber,
             string pDocumentType,
             string pInsuranceBroker,
             string pInsuranceObject,
             string pInsurancePartner,
             string pReferenceDocumentNumber,
             string pSapDocumentNumber
            )
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcCobrarWs
            {
                BrokerContract = pBrokerContract,
                PcReceipts = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>() {
                    new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha(){
                     Amount = pAmount,
                     CompanyCode = pCompanyCode,
                     Currency = pCurrency,
                     DocumentNumber = pDocumentNumber,
                     DocumentType = pDocumentType,
                     InsuranceBroker = pInsuranceBroker,
                     InsuranceObject = pInsuranceObject,
                     InsurancePartner = pInsurancePartner,
                     ReferenceDocumentNumber = pReferenceDocumentNumber,
                     SapDocumentNumber = pSapDocumentNumber
                    }
                }.ToArray()

            };

            var mockRepository = new Mock<IProvisionsRepository>();

            mockRepository.Setup(x => x.GetChargedAsync(Input)).ReturnsAsync(() => { throw new ProcessErrorException(StatusCodes.Status400BadRequest.ToString(), "test error message"); });

            var _controller = new ProvisionWebAccountsController(mockRepository.Object, null);

            var result = await _controller.Charged(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ObjectResult>(result.Result);

            Microsoft.AspNetCore.Mvc.ObjectResult outputObject = result.Result as Microsoft.AspNetCore.Mvc.ObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status400BadRequest, outputObject.StatusCode.Value);
            Assert.IsType<ProcessErrorException>(outputObject.Value);
        }



        [Fact]
        public async Task Query_Test001_resultAsync()
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWs
            {
                BrokerContract = "",
                BrokerReport = ""

            };

            var mockRepository = new Mock<IProvisionsRepository>();

            var output = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWsResponse1
            {
                ZFscdPcConsultarWsResponse = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWsResponse() {
                    Errors = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroProvisionLinhaConsultar>() { }.ToArray(),
                    PcDetail = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcDetailLinha>() { }.ToArray(),
                    PcHeader = new  INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcHeaderLinha() { }
                }

            };

            mockRepository.Setup(x => x.GetQueryAsync(Input)).ReturnsAsync(output);

            var _controller = new ProvisionWebAccountsController(mockRepository.Object, null);

            // Act
            var result = await _controller.Query(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ActionResult<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWsResponse1>>(result);
        }

        [Theory]
        [InlineData(null, null)]
        [InlineData("string", "string")]
        [InlineData("", "")]
        [InlineData("?", "?")]

        public async Task Query_Test002_resultAsync(string pBrokerContract,
          string pBrokerReport )
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcConsultarWs
            {
                BrokerContract = pBrokerContract,
                BrokerReport = pBrokerReport

            };

            var mockRepository = new Mock<IProvisionsRepository>();

            mockRepository.Setup(x => x.GetQueryAsync(Input)).ReturnsAsync(() => { throw new ProcessErrorException(StatusCodes.Status400BadRequest.ToString(), "test error message"); });

            var _controller = new ProvisionWebAccountsController(mockRepository.Object, null);

            var result = await _controller.Query(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ObjectResult>(result.Result);

            Microsoft.AspNetCore.Mvc.ObjectResult outputObject = result.Result as Microsoft.AspNetCore.Mvc.ObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status400BadRequest, outputObject.StatusCode.Value);
            Assert.IsType<ProcessErrorException>(outputObject.Value);
        }


        //[Fact]
        //public async Task Liquidate_Test001_resultAsync()
        //{
        //    //Object IN
        //    var Input = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcLiquidarWs
        //    {
        //        BrokerPaymentsValues = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcPaymentsValues(),
        //    };

        //    var mockRepository = new Mock<IProvisionsRepository>();

        //    var output = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcLiquidarWsResponse1
        //    {
        //        ZFscdPcLiquidarWsResponse = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcLiquidarWsResponse()
        //        {
        //            Errors = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroProvisionLinhaLiquidar>() { }.ToArray(),
        //        }
        //    };

        //    mockRepository.Setup(x => x.GetLiquidateAsync(Input)).ReturnsAsync(output);

        //    var _controller = new ProvisionWebAccountsController(mockRepository.Object, null);

        //    // Act
        //    var result = await _controller.Liquidate(Input);

        //    // Assert
        //    Assert.IsType<Microsoft.AspNetCore.Mvc.ActionResult<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcLiquidarWsResponse1>>(result);
        //}



        [Theory]
        [InlineData(null, null, null, null, null, 0, 0, null, null, 0)]
        [InlineData("string", "string", "string", "string", "string", 0, 0, "string", "string", 0)]
        [InlineData("", "", "", "", "", 0, 0, "", "", 0)]
        [InlineData("?", "?", "?", "?", "?", 0, 0, "?", "?", 0)]
        public async Task Liquidate_Test002_resultAsync(
             string pBrokerContract,
             string pBrokerReport,
             string pTestrun,
             string pPayMethod1,
             string pPayMethod2,
             decimal pValuePay1,
             decimal pValuePay2,
             string pEntSibs,
             string pRefSibs,
             decimal pTotalValue
            )
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcLiquidarWs
            {
                BrokerContract  = pBrokerContract,
                BrokerReport = pBrokerReport,
                Testrun = pTestrun,
                BrokerPaymentsValues = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcPaymentsValues() {
                   PayMethod1 = pPayMethod1,
                   PayMethod2 = pPayMethod2,
                   ValuePay1 = pValuePay1,
                   ValuePay2 = pValuePay2,
                   EntSibs = pEntSibs,
                   RefSibs = pRefSibs,
                   TotalValue = pTotalValue 
                }
            };

            var mockRepository = new Mock<IProvisionsRepository>();

           

            mockRepository.Setup(x => x.GetLiquidateAsync(Input)).ReturnsAsync(() => { throw new ProcessErrorException(StatusCodes.Status400BadRequest.ToString(), "test error message"); });

            var _controller = new ProvisionWebAccountsController(mockRepository.Object, null);

            var result = await _controller.Liquidate(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ObjectResult>(result.Result);

            Microsoft.AspNetCore.Mvc.ObjectResult outputObject = result.Result as Microsoft.AspNetCore.Mvc.ObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status400BadRequest, outputObject.StatusCode.Value);
            Assert.IsType<ProcessErrorException>(outputObject.Value);
        }

        [Fact]
        public async Task List_Test001_resultAsync()
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcListarWs
            {
             };

            var mockRepository = new Mock<IProvisionsRepository>();

            var output = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcListarWsResponse1
            {
                ZFscdPcListarWsResponse = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcListarWsResponse()
                {
                    Errors = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroProvisionLinhaListar>() { }.ToArray(),
                }
            };

            mockRepository.Setup(x => x.GetListAsync(Input)).ReturnsAsync(output);

            var _controller = new ProvisionWebAccountsController(mockRepository.Object,null);

            // Act
            var result = await _controller.List(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ActionResult<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcListarWsResponse1>>(result);
        }


        [Theory]
        [InlineData(null, null, null, null)]
        [InlineData("string", "string", "string", "string")]
        [InlineData("", "", "", "")]
        [InlineData("?", "?", "?", "?")]
        public async Task List_Test002_resultAsync(string pBrokerContract,
               string pStatus,
               string pDateFrom,
               string pDateTo)
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcListarWs
            {
                BrokerContract = pBrokerContract,
                Status = pStatus,
                CreateDateFrom = pDateFrom,
                CreateDateTo = pDateTo
            };

            var mockRepository = new Mock<IProvisionsRepository>();

            mockRepository.Setup(x => x.GetListAsync(Input)).ReturnsAsync(() => { throw new ProcessErrorException(StatusCodes.Status400BadRequest.ToString(), "test error message"); });

            var _controller = new ProvisionWebAccountsController(mockRepository.Object, null);

            var result = await _controller.List(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ObjectResult>(result.Result);

            Microsoft.AspNetCore.Mvc.ObjectResult outputObject = result.Result as Microsoft.AspNetCore.Mvc.ObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status400BadRequest, outputObject.StatusCode.Value);
            Assert.IsType<ProcessErrorException>(outputObject.Value);
        }



        //[Fact]
        //public async Task Validate_Test001_resultAsync()
        //{
        //    //Object IN
        //    var Input = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcValidarWs
        //    {
        //        PcReceipts = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>() {
        //            new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha()
        //        }.ToArray()
                
        //    };

        //    var mockRepository = new Mock<IProvisionsRepository>();

        //    var output = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcValidarWsResponse1
        //    {
        //        ZFscdPcValidarWsResponse = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcValidarWsResponse()
        //        {
        //            Errors = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroRecibos>() { }.ToArray(),
        //        }
        //    };

        //    mockRepository.Setup(x => x.GetValidateAsync(Input)).ReturnsAsync(output);

        //    var _controller = new ProvisionWebAccountsController(mockRepository.Object, null);

        //    // Act
        //    var result = await _controller.Validate(Input);

        //    // Assert
        //    Assert.IsType<Microsoft.AspNetCore.Mvc.ActionResult<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcValidarWsResponse1>>(result);
        //}



        [Theory]
        [InlineData(null, 0, null, null, null)]
        [InlineData("string", 0, "string", "string", "string", "string", "string", "string", "string", "string", "string")]
        [InlineData("", 0, "", "", "", "", "", "", "", "", "")]
        [InlineData("?", 0, "?", "?", "?", "?", "?", "?", "?", "?", "?")]
        public async Task Validate_Test002_resultAsync(
            string pBrokerContract,
            decimal pAmount = 0,
                string pCompanyCode = "",
                string pCurrency = "",
                string pDocumentNumber = "",
                string pDocumentType = "",
                string pInsuranceBroker = "",
                string pInsuranceObject = "",
                string pInsurancePartner = "",
                string pReferenceDocumentNumber = "",
                string pSapDocumentNumber = ""

            )
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcValidarWs
            {
                BrokerContract = pBrokerContract,
                PcReceipts = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>() {
                    new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha(){
                        Amount = pAmount,
                        CompanyCode = pCompanyCode,
                        Currency = pCurrency,
                        DocumentNumber = pDocumentNumber,
                        DocumentType = pDocumentType,
                        InsuranceBroker = pInsuranceBroker,
                        InsuranceObject = pInsuranceObject,
                        InsurancePartner = pInsurancePartner,
                        ReferenceDocumentNumber = pReferenceDocumentNumber,
                        SapDocumentNumber = pSapDocumentNumber
                    }
                }.ToArray()
            };

            var mockRepository = new Mock<IProvisionsRepository>();


            mockRepository.Setup(x => x.GetValidateAsync(Input)).ReturnsAsync(() => { throw new ProcessErrorException(StatusCodes.Status400BadRequest.ToString(), "test error message"); });

            var _controller = new ProvisionWebAccountsController(mockRepository.Object, null);

            var result = await _controller.Validate(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ObjectResult>(result.Result);

            Microsoft.AspNetCore.Mvc.ObjectResult outputObject = result.Result as Microsoft.AspNetCore.Mvc.ObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status400BadRequest, outputObject.StatusCode.Value);
            Assert.IsType<ProcessErrorException>(outputObject.Value);
        }



        [Fact]
        public async Task Kpi_Test001_resultAsync()
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWs
            {
                PcBrokerList = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcBrokerLinha>() { }.ToArray()
            };

            var mockRepository = new Mock<IProvisionsRepository>();

            var output = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWsResponse1
            {
                 ZFscdPcIndicadoresWsResponse = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWsResponse()
                {
                    Errors = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdCodigosErroProvisionLinhaIndicadores>() { }.ToArray(),
                }
            };

            mockRepository.Setup(x => x.GetKpiAsync(Input)).ReturnsAsync(output);

            var _controller = new ProvisionWebAccountsController(mockRepository.Object, null);

            // Act
            var result = await _controller.Kpi(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ActionResult<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWsResponse1>>(result);
        }



        [Theory]
        [InlineData(null )]
        [InlineData("string" )]
        [InlineData("" )]
        [InlineData("?" )]
        public async Task Kpi_Test002_resultAsync(string pBrokerContract)
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZFscdPcIndicadoresWs
            {
                BrokerContract = pBrokerContract,
                PcBrokerList = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcBrokerLinha>() {
                    new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcBrokerLinha(){}
                }.ToArray()
            };

            var mockRepository = new Mock<IProvisionsRepository>();


            mockRepository.Setup(x => x.GetKpiAsync(Input)).ReturnsAsync(() => { throw new ProcessErrorException(StatusCodes.Status400BadRequest.ToString(), "test error message"); });

            var _controller = new ProvisionWebAccountsController(mockRepository.Object, null);

            var result = await _controller.Kpi(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ObjectResult>(result.Result);

            Microsoft.AspNetCore.Mvc.ObjectResult outputObject = result.Result as Microsoft.AspNetCore.Mvc.ObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status400BadRequest, outputObject.StatusCode.Value);
            Assert.IsType<ProcessErrorException>(outputObject.Value);
        }

    

    }

    public class ProvisionChargedControllerTest
    {

        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<ContextApi> _testContextApiMock;
        private readonly Mock<IHttpContextAccessor> _httpContext;

        public ProvisionChargedControllerTest()
        {
            _testContextApiMock = new Mock<ContextApi>();
            _mapperMock = new Mock<IMapper>();
            _httpContext = new Mock<IHttpContextAccessor>();
        }

      

    }

    public class ProvisionLiquidateControllerTest
    {

        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<ContextApi> _testContextApiMock;
        private readonly Mock<IHttpContextAccessor> _httpContext;

        public ProvisionLiquidateControllerTest()
        {
            _testContextApiMock = new Mock<ContextApi>();
            _mapperMock = new Mock<IMapper>();
            _httpContext = new Mock<IHttpContextAccessor>();
        }

       


    }

    public class ProvisionListControllerTest
    {

        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<ContextApi> _testContextApiMock;
        private readonly Mock<IHttpContextAccessor> _httpContext;

        public ProvisionListControllerTest()
        {
            _testContextApiMock = new Mock<ContextApi>();
            _mapperMock = new Mock<IMapper>();
            _httpContext = new Mock<IHttpContextAccessor>();
        }

    

    }

    public class ProvisionValidateControllerTest
    {

        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<ContextApi> _testContextApiMock;
        private readonly Mock<IHttpContextAccessor> _httpContext;

        public ProvisionValidateControllerTest()
        {
            _testContextApiMock = new Mock<ContextApi>();
            _mapperMock = new Mock<IMapper>();
            _httpContext = new Mock<IHttpContextAccessor>();
        }

   


    }

}
﻿using Ins.PT.WebAPI.Middleware;
using INS.PT.WebAPI.Middleware;
using log4net;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Moq;
using System.Threading.Tasks;
using Xunit;

namespace XUnitTestIns.pt.WebAPI
{
    public class MiddlewareTests
    {

        private readonly Mock<IApplicationBuilder> mockApp;
        private readonly Mock<ILog> mockLog;

        public MiddlewareTests()
        {
            mockApp = new Mock<IApplicationBuilder>();
            mockLog = new Mock<ILog>();
            mockLog.Setup(x => x.Info(It.IsAny<object>()));
        }

        [Fact]
        public void LogResponse_Invoke_Valid()
        {
            // Arrange
            var context = new DefaultHttpContext();
            RequestDelegate next = async (ctx) => {
                await Task.Run(() => System.Console.Write("Test run!"));
            };
            var testObject = new LogResponseTimeMiddleWare(next, mockLog.Object);


            // Act
            var result = testObject.InvokeAsync(context);


            // Assert
            Assert.NotNull(result);
            mockLog.Verify(x => x.Info(It.IsAny<object>()), "Log not written!");
        }

        [Fact]
        public void LogResponseTimeMiddleware_Start()
        {
            // Arrange

            // Act
            var result = mockApp.Object.UseLogResponseTime();

            // Assert
            Assert.NotNull(result);
        }



        [Fact]
        public void RequestResponseLogging_Invoke_Valid()
        {
            // Arrange
            var context = new DefaultHttpContext();
            RequestDelegate next = async (ctx) => {
                await Task.Run(() => System.Console.Write("Test run!"));
            };
            var testObject = new RequestResponseLoggingMiddleware(next, mockLog.Object);


            // Act
            var result = testObject.InvokeAsync(context);


            // Assert
            Assert.NotNull(result);
            mockLog.Verify(x => x.Info(It.IsAny<object>()), "Log not written!");
        }

        [Fact]
        public void RequestResponseLoggingMiddleware_Start()
        {
            // Arrange

            // Act
            var result = mockApp.Object.UseLogXRequestResponde();

            // Assert
            Assert.NotNull(result);
        }
    }
}

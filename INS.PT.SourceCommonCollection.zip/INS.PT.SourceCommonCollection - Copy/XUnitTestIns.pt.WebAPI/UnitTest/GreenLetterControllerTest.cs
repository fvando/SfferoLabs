﻿using AutoMapper;
using ins.pt.WebAPI;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.WebAPI;
using INS.PT.WebAPI.Cancel;
using INS.PT.WebAPI.Controllers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.Partners.Policy;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Security.Claims;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.UnitTestGreenLetter
{
    public class GreenLetterControllerTest
    {
        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<ContextApi> _testContextApiMock;
        private readonly Mock<IHttpContextAccessor> _httpContext;

        public GreenLetterControllerTest()
        {
            _testContextApiMock = new Mock<ContextApi>();
            _mapperMock = new Mock<IMapper>();
            _httpContext = new Mock<IHttpContextAccessor>();
        }

        [Fact]
        public async Task GreenLetter_Test001_resultAsync()
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWs()
            {
                Greencards = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartasverdeLinha()
            };

            var mockRepository = new Mock<IGreenLettersRepository>();

            var output = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWsResponse1
            {
                ZFscdCartasverdePostWsResponse = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWsResponse()
                {
                    Greencards = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartasverdeLinha()
                    {
                        Greencard = new List<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha>() {
                         new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha()
                        }.ToArray()
                    },
                    Errors = new List<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCodigosErroLinhaCartaVerde>() { }.ToArray()
                }
            };

            mockRepository.Setup(x => x.GetGreenLetterAsync(Input)).ReturnsAsync(output);

            var _controller = new GreenLettersController(mockRepository.Object);

            // Act
            var result = await _controller.GreenLetter(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ActionResult<INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWsResponse1>>(result);
        }


        [Theory]
        [InlineData(null, null, null, null, null, null, null, null, null, null, null, 0, null, null, null, null, null, null, null, null, null, 0, null, null, null, null, null, null, 0, 0, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null)]
        [InlineData("", "", "", "", "", "", "", "", "", "", "", 0, "", "", "", "", "", "", "", "", "", 0, "", "", "", "", "", "", 0, 0, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "")]
        [InlineData("string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", 0, "string", "string", "string", "string", "string", "string", "string", "string", "string", 0, "string", "string", "string", "string", "string", "string", 0, 0, "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string")]
        [InlineData("?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", 0, "?", "?", "?", "?", "?", "?", "?", "?", "?", 0, "?", "?", "?", "?", "?", "?", 0, 0, "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?")]
        public async Task GreenLetter_Test002_resultAsync(
            string pAutoClass1,
            string pAutoClass2,
            string pAutoNcc,
            string pAutoTxCodRc1,
            string pAutoTxCodRc2,
            string pAutoTxVarRc1,
            string pAutoTxVarRc2,
            string pBrokerContract,
            string pCarBrand1,
            string pCarBrand2,
            string pCivilCertificateNumber,
            decimal pCivilLiabilityCapital,
            string pCompanyCode,
            string pCurrency,
            string pCvCode1,
            string pCvCode2,
            string pCvDocumentNumber1,
            string pCvDocumentNumber2,
            string pCvEndDate,
            string pCvStartDate,
            string pDocumentType,
            decimal pExtraCapital,
            string pFleetFlag,
            string pGroupNumber,
            string pInsuranceType,
            string pLine,
            string pMasterOrigin,
            string pNetwork,
            decimal pOwnDamageCapital,
            decimal pOwnDamageValue,
            string pPartnerExternalSystem,
            string pPolicy,
            string pPostalCode,
            string pPrefix,
            string pPrtCertificateNumberLetter,
            string pPrtGreenLetter,
            string pReferenceDocumentNumber,
            string pRegistrationNumber1,
            string pRegistrationNumber2,
            string pRiskLocal,
            string pRiskPostalCode,
            string pSequenceNumber,
            string pStreet,
            string pInterface,
            string pItemsTotal,
            string pOnline,
            string pOriginalSystem,
            string pSystemDate,
            string pSystemTime,
            string pTransaction)
        {

            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWs()
            {
                Greencards = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartasverdeLinha()
                {
                    Greencard = new List<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha>(){
                        new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha(){
                     AutoClass1 =         pAutoClass1,
                     AutoClass2 =         pAutoClass2 ,
                     AutoNcc =        pAutoNcc,
                     AutoTxCodRc1 =        pAutoTxCodRc1,
                     AutoTxCodRc2 =        pAutoTxCodRc2,
                     AutoTxVarRc1 =        pAutoTxVarRc1,
                     AutoTxVarRc2 =        pAutoTxVarRc2,
                     BrokerContract =        pBrokerContract,
                     CarBrand1 =         pCarBrand1,
                     CarBrand2 =         pCarBrand2,
                     CivilCertificateNumber =         pCivilCertificateNumber,
                     CivilLiabilityCapital =         pCivilLiabilityCapital,
                     CompanyCode =         pCompanyCode,
                     Currency =         pCurrency,
                     CvCode1 =         pCvCode1,
                     CvCode2 =         pCvCode2,
                     CvDocumentNumber1 =         pCvDocumentNumber1,
                     CvDocumentNumber2 =         pCvDocumentNumber2,
                     CvEndDate =         pCvEndDate,
                     CvStartDate =         pCvStartDate,
                     DocumentType =         pDocumentType,
                     Errors = new List<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCodigosErroLinhaCartaVerde>(){ }.ToArray(),
                     ExtraCapital =         pExtraCapital,
                     FleetFlag =         pFleetFlag,
                     GroupNumber =         pGroupNumber,
                     InsuranceType =         pInsuranceType,
                     Line =         pLine,
                     MasterOrigin =        pMasterOrigin,
                     Network =        pNetwork,
                     OwnDamageCapital =        pOwnDamageCapital,
                     OwnDamageValue =        pOwnDamageValue,
                     PartnerExternalSystem =        pPartnerExternalSystem,
                     Policy =      pPolicy ,
                     PostalCode =   pPostalCode ,
                     Prefix =    pPrefix  ,
                     PrtCertificateNumberLetter =   pPrtCertificateNumberLetter  ,
                     PrtGreenLetter =   pPrtGreenLetter  ,
                     ReferenceDocumentNumber =   pReferenceDocumentNumber  ,
                     RegistrationNumber1 =   pRegistrationNumber1  ,
                     RegistrationNumber2 =    pRegistrationNumber2  ,
                     RiskLocal =  pRiskLocal  ,
                     RiskPostalCode =   pRiskPostalCode  ,
                     SequenceNumber =  pSequenceNumber  ,
                     Street =  pStreet
                        }
                    }.ToArray(),

                    Interface = pInterface,
                    ItemsTotal = pItemsTotal,
                    Online = pOnline,
                    OriginalSystem = pOriginalSystem,
                    SystemDate = pSystemDate,
                    SystemTime = pSystemTime,
                    Transaction = pTransaction
                }
            };

            var mockRepository = new Mock<IGreenLettersRepository>();

            mockRepository.Setup(x => x.GetGreenLetterAsync(Input)).ReturnsAsync(() => { throw new ProcessErrorException(StatusCodes.Status400BadRequest.ToString(), "test error message"); });

            var _controller = new GreenLettersController(mockRepository.Object);

            // Act
            var result = await _controller.GreenLetter(Input);



            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ObjectResult>(result.Result);

            Microsoft.AspNetCore.Mvc.ObjectResult outputObject = result.Result as Microsoft.AspNetCore.Mvc.ObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status400BadRequest, outputObject.StatusCode.Value);
            Assert.IsType<ProcessErrorException>(outputObject.Value);
        }


    }

}
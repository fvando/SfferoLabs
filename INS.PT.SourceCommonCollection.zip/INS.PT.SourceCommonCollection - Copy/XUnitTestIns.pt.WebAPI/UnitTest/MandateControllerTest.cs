﻿using AutoMapper;
using ins.pt.WebAPI;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.WebAPI;
using INS.PT.WebAPI.Cancel;
using INS.PT.WebAPI.Controllers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.Partners.Policy;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Security.Claims;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.UnitTestMandate
{
    public class MandateControllerTest
    {

        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<ContextApi> _testContextApiMock;
        private readonly Mock<IHttpContextAccessor> _httpContext;

        public MandateControllerTest()
        {
            _testContextApiMock = new Mock<ContextApi>();
            _mapperMock = new Mock<IMapper>();
            _httpContext = new Mock<IHttpContextAccessor>();
        }


        [Fact]
        public async Task Mandate_Test001_resultAsync()
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWs
            {
                MandatesReference = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatosLinha() {
                    Mandate = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha>() {
                        new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha(){
                          Errors = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandato>() {
                              new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandato()
                          }.ToArray()
                        }
                    }.ToArray(),
                }
            };

            var mockRepository = new Mock<IMandatesRepository>();

            var output = new INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWsResponse1
            {
                ZFscdMandatosPostWsResponse   =  new INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWsResponse() {
                    Errors = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandato>() { }.ToArray(),
                    MandatesReference = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatosLinha() {
                        Mandate = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha>() {
                            new  INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha(){
                                Errors = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandato>(){ }.ToArray(),
                            }
                        }.ToArray()
                    }
                }
            };

            mockRepository.Setup(x => x.GetMandatesAsync(Input)).ReturnsAsync(output);

            var _controller = new MandatesController(mockRepository.Object);

            // Act
            var result = await _controller.Mandate(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ActionResult<INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWsResponse1>>(result);
        }

        [Theory]
        [InlineData(null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null)]
        [InlineData("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "" )]
        [InlineData("?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?")]
        [InlineData("string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string")]
        public async Task Documents_Test002_resultAsync(
             string pBrokerContract,
                            string pCompanyCode,
                            string pDescription,
                            string pMandateReference,
                            string pMandateReferenceOld,
                            string pMandateType,
                            string pMasterOrigin,
                            string pNetwork,
                            string pPartnerExternalSystem,
                            string pPayType,
                            string pPolicy,
                            string pSignCity,
                            string pSignDate,
                            string pSndBic,
                            string pSndIban,
                            string pStartDateFrom,
                            string pStartDateTo,
                            string pStatus,
                              string pInterface,
                    string pItemsTotal,
                    string pOnline,
                    string pOriginalSystem,
                    string pSystemDate,
                    string pSystemTime,
                    string pTransaction
                           )
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWs
            {
                MandatesReference = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatosLinha()
                {
                    Mandate = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha>() {
                        new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha(){
                          BrokerContract = pBrokerContract,
                          CompanyCode = pCompanyCode,
                          Description = pDescription,
                          MandateReference = pMandateReference,
                          MandateReferenceOld = pMandateReferenceOld,
                          MandateType = pMandateType,
                          MasterOrigin = pMasterOrigin,
                          Network = pNetwork,
                          PartnerExternalSystem = pPartnerExternalSystem,
                          PayType = pPayType,
                          Policy = pPolicy,
                          SignCity = pSignCity,
                          SignDate = pSignDate,
                          SndBic = pSndBic,
                          SndIban = pSndIban,
                          StartDateFrom = pStartDateFrom,
                          StartDateTo = pStartDateTo,
                          Status = pStatus,
                          Errors = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandato>() {
                              new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandato()
                          }.ToArray()
                        }
                    }.ToArray(),
         Interface = pInterface,
         ItemsTotal = pItemsTotal,
         Online = pOnline,
         OriginalSystem = pOriginalSystem,
         SystemDate = pSystemDate,
         SystemTime = pSystemTime,
         Transaction = pTransaction
                }
                
            };

            var mockRepository = new Mock<IMandatesRepository>();

            // Act
            mockRepository.Setup(x => x.GetMandatesAsync(Input)).ReturnsAsync(() => { throw new ProcessErrorException(StatusCodes.Status400BadRequest.ToString(), "test error message"); });

            var _controller = new MandatesController(mockRepository.Object);

            // Act
            var result = await _controller.Mandate(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ObjectResult>(result.Result);

            Microsoft.AspNetCore.Mvc.ObjectResult outputObject = result.Result as Microsoft.AspNetCore.Mvc.ObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status400BadRequest, outputObject.StatusCode.Value);
            Assert.IsType<ProcessErrorException>(outputObject.Value);
        }

    }
}
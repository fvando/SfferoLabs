﻿using AutoMapper;
using INS.PT.WebAPI;
using INS.PT.WebAPI.Controllers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.UnitTestCharged
{
    public class ChargedControllerTest
    {

        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<ContextApi> _testContextApiMock;
        private readonly Mock<IHttpContextAccessor> _httpContext;

        public ChargedControllerTest()
        {
            _testContextApiMock = new Mock<ContextApi>();
            _mapperMock = new Mock<IMapper>();
            _httpContext = new Mock<IHttpContextAccessor>();
        }


        [Fact]
        public async Task Charged_Test001_resultAsync()
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.Charged.ZFscdCobradosPostWs()
            {
                ReceiptsCollected = new INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradosLinha()
                {
                    Collect = new List<INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradoLinha>() {
                        new INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradoLinha(){
                            Errors = new List<INS.PT.WebAPI.Model.Partners.Charged.ZfscdCodigosErroLinhaCobrados>(){ }.ToArray()
                        }
                    }.ToArray()
                }
            };

            // Arrange
            //auto mapper configurationExpression
            var mockMapper = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new AutoMapperProfileConfiguration());
            });

            var mapper = mockMapper.CreateMapper();

            var mockRepository = new Mock<IChargesRepository>();

            var output = new INS.PT.WebAPI.Model.Partners.Charged.ZFscdCobradosPostWsResponse1
            {
                ZFscdCobradosPostWsResponse = new INS.PT.WebAPI.Model.Partners.Charged.ZFscdCobradosPostWsResponse()
                {
                    Errors = new List<INS.PT.WebAPI.Model.Partners.Charged.ZfscdCodigosErroLinhaCobrados>() { }.ToArray(),
                    ReceiptsCollected = new INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradosLinha()
                    {
                        Collect = new List<INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradoLinha>() {
                        new INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradoLinha(){
                            Errors = new List<INS.PT.WebAPI.Model.Partners.Charged.ZfscdCodigosErroLinhaCobrados>(){ }.ToArray()
                        }
                    }.ToArray()
                    }
                }
            };

            mockRepository.Setup(x => x.GetChargedAsync(Input)).ReturnsAsync(output);

            var _controller = new ChargesController(mapper, mockRepository.Object);

            // Act
            var result = await _controller.Charged(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ActionResult<INS.PT.WebAPI.Model.Partners.Charged.ZFscdCobradosPostWsResponse1>>(result);
        }

        [Theory]
        [InlineData(null, null, null, null, null, null, null)]
        [InlineData("", "", "", "", "", "", "")]
        [InlineData("?", "?", "?", "?", "?", "?", "?")]
        [InlineData("string", "string", "string", "string", "string", "string", "string")]
        [InlineData("   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ")]
        public async Task Charged_Test002_resultAsync(string interfacep, string itemsTotal, string online, string originalSystem, string systemDate, string systemTime, string transaction)
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.Charged.ZFscdCobradosPostWs()
            {
                ReceiptsCollected = new INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradosLinha()
                {
                   DestinySystem = originalSystem,
                   Interface = interfacep,
                   ItemsTotal = itemsTotal,
                   Online = online,
                   SystemDate = systemDate,
                   SystemTime = systemTime,
                   Transaction = transaction,
                    Collect = new List<INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradoLinha>() {
                        new INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradoLinha(){
                            Errors = new List<INS.PT.WebAPI.Model.Partners.Charged.ZfscdCodigosErroLinhaCobrados>(){ }.ToArray()
                        }
                    }.ToArray()
                }
            };

            // Arrange
            //auto mapper configurationExpression
            var mockMapper = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new AutoMapperProfileConfiguration());
            });

            var mapper = mockMapper.CreateMapper();

            var mockRepository = new Mock<IChargesRepository>();

        
            mockRepository.Setup(x => x.GetChargedAsync(Input)).ReturnsAsync(() => { throw new ProcessErrorException(StatusCodes.Status400BadRequest.ToString(), "test error message"); });

            var _controller = new ChargesController(mapper, mockRepository.Object);

            // Act
            var result = await _controller.Charged(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ObjectResult>(result.Result);

            Microsoft.AspNetCore.Mvc.ObjectResult outputObject = result.Result as Microsoft.AspNetCore.Mvc.ObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status400BadRequest, outputObject.StatusCode.Value);
            Assert.IsType<ProcessErrorException>(outputObject.Value);
        }
    }
}
﻿using AutoMapper;
using INS.PT.WebAPI.Controllers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.UnitTestWebReceiptList
{
    public class WebReceiptListControllerTest
    {

        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<ContextApi> _testContextApiMock;
        private readonly Mock<IHttpContextAccessor> _httpContext;

        public WebReceiptListControllerTest()
        {
            _testContextApiMock = new Mock<ContextApi>();
            _mapperMock = new Mock<IMapper>();
            _httpContext = new Mock<IHttpContextAccessor>();
        }

        //[Fact]
        //public async Task WebList_Test001_resultAsync()
        //{
        //    //Object IN
        //    var Input = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdRecibosListarWs()
        //    {
        //    };

        //    var mockRepository = new Mock<IWebReceiptListingRepository>();

        //    var output = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdRecibosListarWsResponse1
        //    {
        //        ZFscdRecibosListarWsResponse = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdRecibosListarWsResponse1()
        //        {
                     
        //            ReceiptsNumbers = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZfscdRecibosWorkLinha[] { },
        //            Errors = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZfscdCodigosErroLinhaListar[] { }
        //        }
        //    };

        //    mockRepository.Setup(x => x.GestListAsync(Input)).ReturnsAsync(output);

        //    var _controller = new WebReceiptListingController(mockRepository.Object);

        //    // Act
        //    var result = await _controller.List(Input);

        //    // Assert
        //    Assert.IsType<ActionResult<INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdRecibosListarWsResponse1>>(result);
        //}

        //[Theory]
        //[InlineData(null, null, null, null, null, null, null, null)]
        //[InlineData("string", "string", "string", "string", "string", "string", "string", "string")]
        //[InlineData("", "", "", "", "", "", "", "")]
        //[InlineData("?", "?", "?", "?", "?", "?", "?", "?")]
        //public async Task WebList_Test002_resultAsync(
        //        string pBroker,
        //        string pCompanyCode,
        //        string pEndDate,
        //        string pPolicy,
        //        string pReferenceDocumentNumber,
        //        string pStartDate,
        //        string pStatus,
        //        string pTaxNumber
        //    )
        //{
        //    //Object IN
        //    var Input = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdRecibosListarWs()
        //    {
        //       Broker = pBroker,
        //       CompanyCode = pCompanyCode,
        //       EndDate = pEndDate,
        //       Policy = pPolicy,
        //       ReferenceDocumentNumber = pReferenceDocumentNumber,
        //       StartDate = pStartDate,
        //       Status = pStatus,
        //       TaxNumber = pTaxNumber
        //    };

        //    var mockRepository = new Mock<IWebReceiptListingRepository>();

        //    mockRepository.Setup(x => x.GestListAsync(Input)).ReturnsAsync(() => { throw new ProcessErrorException("99", "test error message"); });

        //    var _controller = new WebReceiptListingController(mockRepository.Object);

        //    var result = await _controller.List(Input);

        //    // Assert
        //    Assert.IsType<NotFoundObjectResult>(result.Result);

        //    NotFoundObjectResult outputObject = result.Result as NotFoundObjectResult;
        //    Assert.NotNull(outputObject);

        //    Assert.NotNull(outputObject.StatusCode);
        //    Assert.Equal(StatusCodes.Status404NotFound, outputObject.StatusCode.Value);
        //    Assert.IsType<ProcessErrorException>(outputObject.Value);
        //}

    }
}
﻿using AutoMapper;
using INS.PT.WebAPI.Controllers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.UnitTestCancel
{
    public class CancelControllerTest
    {

        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<ContextApi> _testContextApiMock;
        private readonly Mock<IHttpContextAccessor> _httpContext;

        public CancelControllerTest()
        {
            _testContextApiMock = new Mock<ContextApi>();
            _mapperMock = new Mock<IMapper>();
            _httpContext = new Mock<IHttpContextAccessor>();
        }

   
    }

    public class ReceiptControllerTest
    {
        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<ContextApi> _testContextApiMock;
        private readonly Mock<IHttpContextAccessor> _httpContext;

        public ReceiptControllerTest()
        {
            _testContextApiMock = new Mock<ContextApi>();
            _mapperMock = new Mock<IMapper>();
            _httpContext = new Mock<IHttpContextAccessor>();
        }

        [Fact]
        public async Task CancelReceipt_Test001_resultAsync()
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWs()
            {
                Receipts = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha() {
                    Policies = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoPolicy>() {}.ToArray()
                }
            };

         

            var mockRepository = new Mock<ICancellationsRepository>();

            var output = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWsResponse1
            {
              ZFscdAnularRecibosPostWsResponse = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWsResponse() {
                    Errors = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaAnularRecibo>(){ }.ToArray(),
                    Receipts = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha() {
                        Policies = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoPolicy>() {}.ToArray()
                    }
                }
            };

            mockRepository.Setup(x => x.GetCancellationCancelAsync(Input)).ReturnsAsync(output);

            var _controller = new CancellationsController(mockRepository.Object);

            // Act
            var result = await _controller.Receipt(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ActionResult<INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWsResponse1>> (result);
        }

        [Theory]
        [InlineData(null, null, null, null, null, null, null)]
        [InlineData("", "", "", "", "", "", "")]
        [InlineData("?", "?", "?", "?", "?", "?", "?")]
        [InlineData("string", "string", "string", "string", "string", "string", "string")]
        [InlineData("   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ")]
        public async Task CancelReceipt_Test002_resultAsync(string interfacep, string itemsTotal, string online, string DestinySystem, string systemDate, string systemTime, string transaction)
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWs()
            {
                Receipts = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha()
                {
                    Interface = interfacep,
                    ItemsTotal = itemsTotal,
                    Online = online,
                    DestinySystem = DestinySystem,
                    SystemDate = systemDate,
                    SystemTime = systemTime,
                    Transaction = transaction,
                    Policies = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoPolicy>() {
                        new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoPolicy(){
                        }
                    }.ToArray()
                }
            };



            var mockRepository = new Mock<ICancellationsRepository>();



            mockRepository.Setup(x => x.GetCancellationCancelAsync(Input)).ReturnsAsync(() => { throw new ProcessErrorException(StatusCodes.Status400BadRequest.ToString(), "test error message"); });

            var _controller = new CancellationsController(mockRepository.Object);

            // Act
            var result = await _controller.Receipt(Input);

             //Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ObjectResult>(result.Result);

            Microsoft.AspNetCore.Mvc.ObjectResult outputObject = result.Result as Microsoft.AspNetCore.Mvc.ObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status400BadRequest, outputObject.StatusCode.Value);
            Assert.IsType<ProcessErrorException>(outputObject.Value);
        }


        [Fact]
        public async Task CancelPolicy_Test001_resultAsync()
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWs()
            {
                Policies = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha()
                {
                    Policies = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoPolicy>() {
                        
                    }.ToArray()
                }
            };

            var mockRepository = new Mock<ICancellationsRepository>();

            var output = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWsResponse1
            {
                ZFscdAnularApolicesPostWsResponse = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWsResponse()
                {
                    Errors = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaAnularApolice>() { }.ToArray(),
                    Policies = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha()
                    {
                        Policies = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoPolicy>() {
                         
                    }.ToArray()
                    }
                }
            };

            mockRepository.Setup(x => x.GetCancellationPolicyAsync(Input)).ReturnsAsync(output);

            var _controller = new CancellationsController(mockRepository.Object);

            // Act
            var result = await _controller.Policy(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ActionResult<INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWsResponse1>>(result);
        }

        [Theory]
        [InlineData(null, null, null, null, null, null, null)]
        [InlineData("", "", "", "", "", "", "")]
        [InlineData("?", "?", "?", "?", "?", "?", "?")]
        [InlineData("string", "string", "string", "string", "string", "string", "string")]
        public async Task CancelPolicy_Test002_resultAsync(string interfacep, string itemsTotal, string online, string destinySystem, string systemDate, string systemTime, string transaction)
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWs()
            {
                Policies = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha()
                {
                    Interface = interfacep,
                    ItemsTotal = itemsTotal,
                    Online = online,
                    DestinySystem = destinySystem,
                    SystemDate = systemDate,
                    SystemTime = systemTime,
                    Transaction = transaction,
                    Policies = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoPolicy>() {
                    }.ToArray()
                }
            };

            var mockRepository = new Mock<ICancellationsRepository>();

            mockRepository.Setup(x => x.GetCancellationPolicyAsync(Input)).ReturnsAsync(() => { throw new ProcessErrorException(StatusCodes.Status400BadRequest.ToString(), "test error message"); });

            var _controller = new CancellationsController(mockRepository.Object);

            // Act
            var result = await _controller.Policy(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ObjectResult>(result.Result);

            Microsoft.AspNetCore.Mvc.ObjectResult outputObject = result.Result as Microsoft.AspNetCore.Mvc.ObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status400BadRequest, outputObject.StatusCode.Value);
            Assert.IsType<ProcessErrorException>(outputObject.Value);
        }

    }
}
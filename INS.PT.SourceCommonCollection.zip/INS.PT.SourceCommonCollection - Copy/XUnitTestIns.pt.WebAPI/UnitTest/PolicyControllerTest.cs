﻿using AutoMapper;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.WebAPI.Controllers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.UnitTestPolicy
{
    public class PolicyControllerTest
    {

        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<ContextApi> _testContextApiMock;
        private readonly Mock<IHttpContextAccessor> _httpContext;

        public PolicyControllerTest()
        {
            _testContextApiMock = new Mock<ContextApi>();
            _mapperMock = new Mock<IMapper>();
            _httpContext = new Mock<IHttpContextAccessor>();
        }


        [Fact]
        public async Task Mediator_Test001_resultAsync()
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWs
            {
                MediationAccount = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdMediadoresLinha()
                {
                    Mediator = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>() {
                        new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha(){
                            Beneficiaries = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>(){
                                new  INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario(){
                                }
                            }.ToArray(),
                            Mediators = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador(),
                            Risk = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectObjectRisk(),
                            Errors = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaApolice>(){ }.ToArray()
                        }
                    }.ToArray()
                }
            };

            var mockRepository = new Mock<IPoliciesRepository>();

            var output = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWsResponse1
            {
                ZFscdMediadoresPostWsResponse = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWsResponse()
                {
                    Errors = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaMediador>() { }.ToArray(),
                    MediationAccount = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdMediadoresLinha()
                    {
                        Mediator = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>() {
                            new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha(){
                                Errors = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaApolice>(){ }.ToArray(),
                                Mediators = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador(),
                                Risk = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectObjectRisk()
                            }
                        }.ToArray()
                    }
                }
            };

            mockRepository.Setup(x => x.GetMediatorAsync(Input)).ReturnsAsync(output);

            var _controller = new PoliciesController(mockRepository.Object);

            // Act
            var result = await _controller.Mediator(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ActionResult<INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWsResponse1>>(result);
        }

        [Theory]
        [InlineData(null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 0, 0, 0, null, null, null, null, null, null, null, null, null, null, null, null)]
        //[InlineData("string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", 0, 0, 0, "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string")]
        //[InlineData("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "", "", "", "", "", "", "", "")]
        //[InlineData("?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", 0, 0, 0, "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?")]
        public async Task Mediator_Test002_resultAsync(
            string pActionZone,
                        string pAddressNumber,
                        string pAddressType,
                            string pAgent,
                                    string pIban,
                                 string pMasterOrigin,
                                string pPartnerExternalSystem,
                                 string pPartnerRelationshipContract,
                          string pBroker,
                         string pCompanyCode,
                          string pEndDate,
                          string pIncomingPaymentIban,
                           string pIncomingPaymentLockReason,
                          string pIncomingPaymentMethod,
                          string pInspectionArea,
                          string pInsuranceObject,
                         string pInsuranceObjectCategory,
                         string pInsuranceObjectOriginal,
                          string pInsuranceType,
                          string pMandateReference,
                              string pClaimCategory,
                             string pCommissionCategory,
                             string pCostCategory,
                             string pIspCode,
                              string pPremiumCategory,
                         string pNetwork,
                          string pOutgoingPaymentIban,
                         string pOutgoingPaymentLockReason,
                          string pOutgoingPaymentMethod,
                          string pPublicContractCode,
                          string pCurrencyCapital,
                          decimal pInsuranceCapital1,
                           decimal pInsuranceCapital2,
                           decimal pInsuranceCapital3,
                           string pInsuranceObjectLocal,
                           string pInsuranceObjectRisk,
                        string pSituactionCode,
                        string pSituactionCodeDate,
                        string pStartDate,
                       string pWithholdingTaxCode,
                  string pItemsTotal,
                  string pOnline,
                  string pOriginalSystem,
                  string pSystemDate,
                  string pSystemTime,
                  string pTransaction
            )
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWs
            {
                MediationAccount = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdMediadoresLinha()
                {
                    Interface = "",
                    Mediator = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>() {
                        new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha(){
                          ActionZone = pActionZone,
                          AddressNumber = pAddressNumber,
                          AddressType = pAddressType,
                          Agent = pAgent,
                            Beneficiaries = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>(){
                                new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario(){
                                   Iban = pIban,
                                   MasterOrigin = pMasterOrigin,
                                   PartnerExternalSystem = pPartnerExternalSystem,
                                   PartnerRelationshipContract = pPartnerRelationshipContract
                                }
                            }.ToArray(),
                           Broker = pBroker,
                           CompanyCode = pCompanyCode,
                           EndDate = pEndDate,
                            Errors = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaApolice>(){ }.ToArray(),
                          IncomingPaymentIban = pIncomingPaymentIban,
                          IncomingPaymentLockReason = pIncomingPaymentLockReason,
                          IncomingPaymentMethod = pIncomingPaymentMethod,
                          InspectionArea = pInspectionArea,
                          InsuranceObject = pInsuranceObject,
                          InsuranceObjectCategory = pInsuranceObjectCategory,
                          InsuranceObjectOriginal = pInsuranceObjectOriginal,
                          InsuranceType = pInsuranceType,
                          MandateReference = pMandateReference,
                          MasterOrigin = pMasterOrigin,
                            Mediators = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador(){
                              ClaimCategory = pClaimCategory,
                              CommissionCategory = pCommissionCategory,
                              CostCategory = pCostCategory,
                              IspCode = pIspCode,
                              PremiumCategory = pPremiumCategory
                            },
                            Network = pNetwork,
                            OutgoingPaymentIban = pOutgoingPaymentIban,
                            OutgoingPaymentLockReason = pOutgoingPaymentLockReason,
                            OutgoingPaymentMethod = pOutgoingPaymentMethod,
                            PartnerExternalSystem = pPartnerExternalSystem,
                            PartnerRelationshipContract = pPartnerRelationshipContract,
                            PublicContractCode = pPublicContractCode,
                            Risk = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectObjectRisk(){
                                CurrencyCapital = pCurrencyCapital,
                                InsuranceCapital1 = pInsuranceCapital1,
                                InsuranceCapital2 = pInsuranceCapital2,
                                InsuranceCapital3 = pInsuranceCapital3,
                                InsuranceObjectLocal = pInsuranceObjectLocal,
                                InsuranceObjectRisk = pInsuranceObjectRisk,
                            },
                           SituactionCode = pSituactionCode,
                           SituactionCodeDate = pSituactionCodeDate,
                           StartDate = pStartDate,
                           WithholdingTaxCode = pWithholdingTaxCode
                        }

                    }.ToArray(),
                    ItemsTotal = pItemsTotal,
                    Online = pOnline,
                    OriginalSystem = pOriginalSystem,
                    SystemDate = pSystemDate,
                    SystemTime = pSystemTime,
                    Transaction = pTransaction
                }
            };

            var mockRepository = new Mock<IPoliciesRepository>();

            mockRepository.Setup(x => x.GetMediatorAsync(Input)).ReturnsAsync(() => { throw new ProcessErrorException(StatusCodes.Status400BadRequest.ToString(), "test error message"); });

            var _controller = new PoliciesController(mockRepository.Object);

            var result = await _controller.Mediator(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ObjectResult>(result.Result);

            Microsoft.AspNetCore.Mvc.ObjectResult outputObject = result.Result as Microsoft.AspNetCore.Mvc.ObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status400BadRequest, outputObject.StatusCode.Value);
            Assert.IsType<ProcessErrorException>(outputObject.Value);

        }


        [Fact]
        public async Task Policy_Test001_resultAsync()
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWs
            {
                Policies = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdApolicesLinha()
                {
                    Policy = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>() {
                        new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha(){
                            Beneficiaries = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>(){
                                new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario(){
                                }
                            }.ToArray()
                        }
                    }.ToArray(),
                }
            };

            var mockRepository = new Mock<IPoliciesRepository>();

            var output = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWsResponse1
            {
                ZFscdApolicesPostWsResponse = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWsResponse()
                {
                    Policies = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdApolicesLinha(),
                    Errors = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaApolice>() { }.ToArray()
                }
            };

            mockRepository.Setup(x => x.GetPolicyAsync(Input)).ReturnsAsync(output);

            var _controller = new PoliciesController(mockRepository.Object);

            // Act
            var result = await _controller.Policy(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ActionResult<INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWsResponse1>>(result);
        }


        [Theory]
        [InlineData(null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 0, 0, 0, null, null, null, null, null, null, null, null, null, null, null, null, null)]
        [InlineData("string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", 0, 0, 0, "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string")]
        [InlineData("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "", "", "", "", "", "", "", "", "")]
        [InlineData("?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", 0, 0, 0, "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?")]
        public async Task Policy_Test002_resultAsync(
          string pActionZone,
                      string pAddressNumber,
                      string pAddressType,
                          string pAgent,
                                  string pIban,
                               string pMasterOrigin,
                              string pPartnerExternalSystem,
                               string pPartnerRelationshipContract,
                        string pBroker,
                       string pCompanyCode,
                        string pEndDate,
                        string pIncomingPaymentIban,
                         string pIncomingPaymentLockReason,
                        string pIncomingPaymentMethod,
                        string pInspectionArea,
                        string pInsuranceObject,
                       string pInsuranceObjectCategory,
                       string pInsuranceObjectOriginal,
                        string pInsuranceType,
                        string pMandateReference,
                            string pClaimCategory,
                           string pCommissionCategory,
                           string pCostCategory,
                           string pIspCode,
                            string pPremiumCategory,
                       string pNetwork,
                        string pOutgoingPaymentIban,
                       string pOutgoingPaymentLockReason,
                        string pOutgoingPaymentMethod,
                        string pPublicContractCode,
                        string pCurrencyCapital,
                        decimal pInsuranceCapital1,
                         decimal pInsuranceCapital2,
                         decimal pInsuranceCapital3,
                         string pInsuranceObjectLocal,
                         string pInsuranceObjectRisk,
                      string pSituactionCode,
                      string pSituactionCodeDate,
                      string pStartDate,
                     string pWithholdingTaxCode,
                string pItemsTotal,
                string pOnline,
                string pOriginalSystem,
                string pSystemDate,
                string pSystemTime,
                string pTransaction,
                string pInterface
          )
        {
            //Object IN
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWs
            {
                Policies = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdApolicesLinha()
                {
                    Interface = pInterface,
                    ItemsTotal = pItemsTotal,
                    Online = pOnline,
                    OriginalSystem = pOriginalSystem,
                    SystemDate = pSystemDate,
                    SystemTime = pSystemTime,
                    Transaction = pTransaction,
                    Policy = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>() {
                        new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha(){
                          ActionZone = pActionZone,
                          AddressNumber = pAddressNumber,
                          AddressType = pAddressType,
                          Agent = pAgent,
                            Beneficiaries = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>(){
                                new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario(){
                                   Iban = pIban,
                                   MasterOrigin = pMasterOrigin,
                                   PartnerExternalSystem = pPartnerExternalSystem,
                                   PartnerRelationshipContract = pPartnerRelationshipContract
                                }
                            }.ToArray(),
                           Broker = pBroker,
                           CompanyCode = pCompanyCode,
                           EndDate = pEndDate,
                            Errors = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaApolice>(){ }.ToArray(),
                          IncomingPaymentIban = pIncomingPaymentIban,
                          IncomingPaymentLockReason = pIncomingPaymentLockReason,
                          IncomingPaymentMethod = pIncomingPaymentMethod,
                          InspectionArea = pInspectionArea,
                          InsuranceObject = pInsuranceObject,
                          InsuranceObjectCategory = pInsuranceObjectCategory,
                          InsuranceObjectOriginal = pInsuranceObjectOriginal,
                          InsuranceType = pInsuranceType,
                          MandateReference = pMandateReference,
                          MasterOrigin = pMasterOrigin,
                            Mediators = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador(){
                              ClaimCategory = pClaimCategory,
                              CommissionCategory = pCommissionCategory,
                              CostCategory = pCostCategory,
                              IspCode = pIspCode,
                              PremiumCategory = pPremiumCategory
                            },
                            Network = pNetwork,
                            OutgoingPaymentIban = pOutgoingPaymentIban,
                            OutgoingPaymentLockReason = pOutgoingPaymentLockReason,
                            OutgoingPaymentMethod = pOutgoingPaymentMethod,
                            PartnerExternalSystem = pPartnerExternalSystem,
                            PartnerRelationshipContract = pPartnerRelationshipContract,
                            PublicContractCode = pPublicContractCode,
                            Risk = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectObjectRisk(){
                                CurrencyCapital = pCurrencyCapital,
                                InsuranceCapital1 = pInsuranceCapital1,
                                InsuranceCapital2 = pInsuranceCapital2,
                                InsuranceCapital3 = pInsuranceCapital3,
                                InsuranceObjectLocal = pInsuranceObjectLocal,
                                InsuranceObjectRisk = pInsuranceObjectRisk,
                            },
                           SituactionCode = pSituactionCode,
                           SituactionCodeDate = pSituactionCodeDate,
                           StartDate = pStartDate,
                           WithholdingTaxCode = pWithholdingTaxCode
                        }
                    }.ToArray(),
                }
            };

            var mockRepository = new Mock<IPoliciesRepository>();

            mockRepository.Setup(x => x.GetPolicyAsync(Input)).ReturnsAsync(() => { throw new ProcessErrorException(StatusCodes.Status400BadRequest.ToString(), "test error message"); });

            var _controller = new PoliciesController(mockRepository.Object);

            var result = await _controller.Policy(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ObjectResult>(result.Result);

            Microsoft.AspNetCore.Mvc.ObjectResult outputObject = result.Result as Microsoft.AspNetCore.Mvc.ObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status400BadRequest, outputObject.StatusCode.Value);
            Assert.IsType<ProcessErrorException>(outputObject.Value);

        }



        [Fact]
        public async Task Claims_Test001_resultAsync()
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWs
            {
                Claims = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdSinistrosLinha()
                {
                    Claim = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>() {
                       new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
                   }.ToArray()

                }
            };

            var mockRepository = new Mock<IPoliciesRepository>();

            var output = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWsResponse1
            {
                ZFscdSinistrosPostWsResponse = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWsResponse()
                {
                    Claims = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdSinistrosLinha(),
                    Errors = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaSinistro>() { }.ToArray()
                }
            };

            mockRepository.Setup(x => x.GetClaimsAsync(Input)).ReturnsAsync(output);

            var _controller = new PoliciesController(mockRepository.Object);

            // Act
            var result = await _controller.Claims(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ActionResult<INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWsResponse1>>(result);
        }


        [Theory]
        [InlineData(null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 0, 0, 0, null, null, null, null, null, null, null, null, null, null, null, null, null)]
        //[InlineData("string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", 0, 0, 0, "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string")]
        //[InlineData("", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "", "", "", "", "", "", "", "", "")]
        //[InlineData("?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", 0, 0, 0, "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?")]
        public async Task Claims_Test002_resultAsync(
    string pActionZone,
                string pAddressNumber,
                string pAddressType,
                    string pAgent,
                            string pIban,
                         string pMasterOrigin,
                        string pPartnerExternalSystem,
                         string pPartnerRelationshipContract,
                  string pBroker,
                 string pCompanyCode,
                  string pEndDate,
                  string pIncomingPaymentIban,
                   string pIncomingPaymentLockReason,
                  string pIncomingPaymentMethod,
                  string pInspectionArea,
                  string pInsuranceObject,
                 string pInsuranceObjectCategory,
                 string pInsuranceObjectOriginal,
                  string pInsuranceType,
                  string pMandateReference,
                      string pClaimCategory,
                     string pCommissionCategory,
                     string pCostCategory,
                     string pIspCode,
                      string pPremiumCategory,
                 string pNetwork,
                  string pOutgoingPaymentIban,
                 string pOutgoingPaymentLockReason,
                  string pOutgoingPaymentMethod,
                  string pPublicContractCode,
                  string pCurrencyCapital,
                  decimal pInsuranceCapital1,
                   decimal pInsuranceCapital2,
                   decimal pInsuranceCapital3,
                   string pInsuranceObjectLocal,
                   string pInsuranceObjectRisk,
                string pSituactionCode,
                string pSituactionCodeDate,
                string pStartDate,
               string pWithholdingTaxCode,
          string pItemsTotal,
          string pOnline,
          string pOriginalSystem,
          string pSystemDate,
          string pSystemTime,
          string pTransaction,
          string pInterface
    )
        {
            //Object IN
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWs
            {
                Claims = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdSinistrosLinha()
                {
                    Interface = pInterface,
                    ItemsTotal = pItemsTotal,
                    Online = pOnline,
                    OriginalSystem = pOriginalSystem,
                    SystemDate = pSystemDate,
                    SystemTime = pSystemTime,
                    Transaction = pTransaction,
                    Claim = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>() {
                        new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha(){
                          ActionZone = pActionZone,
                          AddressNumber = pAddressNumber,
                          AddressType = pAddressType,
                          Agent = pAgent,
                            Beneficiaries = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>(){
                                new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario(){
                                   Iban = pIban,
                                   MasterOrigin = pMasterOrigin,
                                   PartnerExternalSystem = pPartnerExternalSystem,
                                   PartnerRelationshipContract = pPartnerRelationshipContract
                                }
                            }.ToArray(),
                           Broker = pBroker,
                           CompanyCode = pCompanyCode,
                           EndDate = pEndDate,
                            Errors = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaApolice>(){ }.ToArray(),
                          IncomingPaymentIban = pIncomingPaymentIban,
                          IncomingPaymentLockReason = pIncomingPaymentLockReason,
                          IncomingPaymentMethod = pIncomingPaymentMethod,
                          InspectionArea = pInspectionArea,
                          InsuranceObject = pInsuranceObject,
                          InsuranceObjectCategory = pInsuranceObjectCategory,
                          InsuranceObjectOriginal = pInsuranceObjectOriginal,
                          InsuranceType = pInsuranceType,
                          MandateReference = pMandateReference,
                          MasterOrigin = pMasterOrigin,
                            Mediators = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador(){
                              ClaimCategory = pClaimCategory,
                              CommissionCategory = pCommissionCategory,
                              CostCategory = pCostCategory,
                              IspCode = pIspCode,
                              PremiumCategory = pPremiumCategory
                            },
                            Network = pNetwork,
                            OutgoingPaymentIban = pOutgoingPaymentIban,
                            OutgoingPaymentLockReason = pOutgoingPaymentLockReason,
                            OutgoingPaymentMethod = pOutgoingPaymentMethod,
                            PartnerExternalSystem = pPartnerExternalSystem,
                            PartnerRelationshipContract = pPartnerRelationshipContract,
                            PublicContractCode = pPublicContractCode,
                            Risk = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectObjectRisk(){
                                CurrencyCapital = pCurrencyCapital,
                                InsuranceCapital1 = pInsuranceCapital1,
                                InsuranceCapital2 = pInsuranceCapital2,
                                InsuranceCapital3 = pInsuranceCapital3,
                                InsuranceObjectLocal = pInsuranceObjectLocal,
                                InsuranceObjectRisk = pInsuranceObjectRisk,
                            },
                           SituactionCode = pSituactionCode,
                           SituactionCodeDate = pSituactionCodeDate,
                           StartDate = pStartDate,
                           WithholdingTaxCode = pWithholdingTaxCode
                        }
                    }.ToArray(),
                }
            };

            var mockRepository = new Mock<IPoliciesRepository>();

            mockRepository.Setup(x => x.GetClaimsAsync(Input)).ReturnsAsync(() => { throw new ProcessErrorException(StatusCodes.Status400BadRequest.ToString(), "test error message"); });

            var _controller = new PoliciesController(mockRepository.Object);

            var result = await _controller.Claims(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ObjectResult>(result.Result);

            Microsoft.AspNetCore.Mvc.ObjectResult outputObject = result.Result as Microsoft.AspNetCore.Mvc.ObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status400BadRequest, outputObject.StatusCode.Value);
            Assert.IsType<ProcessErrorException>(outputObject.Value);

        }

    }
}
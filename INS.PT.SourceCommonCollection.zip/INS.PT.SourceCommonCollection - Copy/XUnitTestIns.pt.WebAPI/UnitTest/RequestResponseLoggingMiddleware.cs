﻿using Microsoft.AspNetCore.Http;

namespace XUnitTestIns.pt.WebAPI
{
    internal class RequestResponseLoggingMiddleware
    {
        private RequestDelegate next;
        public RequestResponseLoggingMiddleware(RequestDelegate next)
        {
            this.next = next;
        }
    }
}
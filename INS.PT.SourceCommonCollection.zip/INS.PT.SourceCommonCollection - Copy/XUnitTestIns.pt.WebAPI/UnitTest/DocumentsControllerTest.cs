﻿using AutoMapper;
using INS.PT.WebAPI.Controllers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Moq;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.UnitTestDocuments
{
    public class DocumentsControllerTest
    {

        private readonly Mock<IMapper> _mapperMock;
        private readonly Mock<ContextApi> _testContextApiMock;
        private readonly Mock<IHttpContextAccessor> _httpContext;

        public DocumentsControllerTest()
        {
            _testContextApiMock = new Mock<ContextApi>();
            _mapperMock = new Mock<IMapper>();
            _httpContext = new Mock<IHttpContextAccessor>();
        }


        [Fact]
        public async Task Documents_Test001_resultAsync()
        {
            //Object IN
            var Input = new INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWs()
            {
                Documents = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentosLinha()
                { }
            };

            var mockRepository = new Mock<IDocumentsRepository>();

            var output = new INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWsResponse1
            {
                ZFscdDocumentosPostWsResponse = new INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWsResponse()
                {
                    Errors = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdCodigosErroLinhaDocumentos>() { }.ToArray(),
                    Documents = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentosLinha()
                    { }
                }
            };

            mockRepository.Setup(x => x.GetDocumentsAsync(Input)).ReturnsAsync(output);

            var _controller = new DocumentsController(mockRepository.Object);

            // Act
            var result = await _controller.Document(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.ActionResult<INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWsResponse1>>(result);
        }

        [Theory]
        [InlineData(null, null, null, null, null, null, null, null, null, 0, 0, 0, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null)]
        [InlineData("", "", "", "", "", "", "", "", "", int.MaxValue, int.MaxValue, int.MaxValue, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "")]
        [InlineData("", "", "", "", "", "", "", "", "", int.MinValue, int.MinValue, int.MinValue, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "")]
        [InlineData("", "", "", "", "", "", "", "", "", 0, 0, 0, "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "")]
        [InlineData("?", "?", "?", "?", "?", "?", "?", "?", "?", 0, 0, 0, "?", "?", "?", "?", "?", "?", "?", "?", "?", "", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?", "?")]
        [InlineData("string", "string", "string", "string", "string", "string", "string", "string", "string", 0, 0, 0, "", "01-01-2019", "string", "string", "string", "string", "string", "string", "", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string", "string")]
        [InlineData("   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", 0, 0, 0, "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ", "   string   ")]
        public async Task Documents_Test002_resultAsync(string adrCity,
                              string adrCountry,
                              string adrFirstName,
                              string adrLastName,
                              string adrLocation,
                              string adrPostCode,
                              string adrStreet,
                              string adrStreetComplement,
                              string companyCode,
                              decimal headAmountCommission,
                              decimal headAmountPremium,
                              decimal headAmountTotal,
                              string headBillingPeriodFrom,
                              string headBillingPeriodTo,
                              string headBusinessArea,
                              string headBusinessType,
                              string headCollected,
                              string headContract,
                              string headCountryCtrl,
                              string headCurrency,
                              string headDivergentPayer,
                              string headDocumentDate,
                              string headDocumentType,
                              string headFracctType,
                              string headIban,
                              string headIncomingClearingLock,
                              string headIncomingDunningLockReason,
                              string headIncomingPaymentLockReason,
                              string headIncomingPaymentMethod,
                              string headInstallmentNum,
                              string headInsuranceType,
                              string headMandateReference,
                              string headNetDueDate,
                              string headNetwork,
                              string headOffertCode,
                              string headOurReference,
                              string headPostingDate,
                              string headPrtDocument,
                              string headPrtGreenLetter,
                              string headPrtNotifDoc,
                              string headPrtRespCivil,
                              string headReceiptType,
                              string headRelatedContract,
                              string headSibsDeadline,
                              string headSibsEntity,
                              string headSibsReference,
                              string interfacep,
                              string itemsTotal,
                              string online,
                              string originalSystem,
                              string systemDate,
                              string systemTime,
                              string transaction
                               )
        {
            //Object IN
            var Input =
                new INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWs()
                {
                    Documents = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentosLinha()
                    {
                        Document = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoLinha>() {
                       new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoLinha(){
                           Address = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress(){
                               City = adrCity,
                               Country = adrCountry,
                               FirstName = adrFirstName,
                               LastName = adrLastName,
                               Location = adrLocation,
                               PostCode = adrPostCode,
                               Street = adrStreet,
                               StreetComplement = adrStreetComplement,
                           },
                           CompanyCode = companyCode,
                           Details = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoDetalheLinha>(){ }.ToArray(),
                           Errors = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdCodigosErroLinhaDocumentos>(){ }.ToArray(),
                           Header = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoCabecalho(){
                              AmountCommission = headAmountCommission,
                              AmountPremium = headAmountPremium,
                              AmountTotal = headAmountTotal,
                              BillingPeriodFrom = headBillingPeriodFrom,
                              BillingPeriodTo = headBillingPeriodTo,
                              BusinessArea = headBusinessArea,
                              BusinessType = headBusinessType,
                              Collected = headCollected,
                              Contract = headContract,
                              CountryCtrl = headCountryCtrl,
                              Currency = headCurrency,
                              DivergentPayer = headDivergentPayer,
                              DocumentDate = headDocumentDate,
                              DocumentType = headDocumentType,
                              FracctType = headFracctType,
                              Iban = headIban,
                              IncomingClearingLock = headIncomingClearingLock,
                              IncomingDunningLockReason = headIncomingDunningLockReason,
                              IncomingPaymentLockReason = headIncomingPaymentLockReason,
                              IncomingPaymentMethod = headIncomingPaymentMethod,
                              InstallmentNum = headInstallmentNum,
                              InsuranceType = headInsuranceType,
                              MandateReference = headMandateReference,
                              NetDueDate = headNetDueDate,
                              Network = headNetwork,
                              OffertCode = headOffertCode,
                              OurReference = headOurReference,
                              PostingDate = headPostingDate,
                              PrtDocument = headPrtDocument,
                              PrtGreenLetter = headPrtGreenLetter,
                              PrtNotifDoc = headPrtNotifDoc,
                              PrtRespCivil = headPrtRespCivil,
                              ReceiptType = headReceiptType,
                               RelatedContract = headRelatedContract,
                               SibsDeadline = headSibsDeadline,
                               SibsEntity = headSibsEntity,
                               SibsReference = headSibsReference
                           },
                           ReferenceDocumentNumber = ""
                       }

                   }.ToArray(),
                        Interface = interfacep,
                        ItemsTotal = itemsTotal,
                        Online = online,
                        OriginalSystem = originalSystem,
                        SystemDate = systemDate,
                        SystemTime = systemTime,
                        Transaction = transaction

                    }
                };


            var mockRepository = new Mock<IDocumentsRepository>();

            mockRepository.Setup(x => x.GetDocumentsAsync(Input)).ReturnsAsync(() => { throw new ProcessErrorException(StatusCodes.Status400BadRequest.ToString(), "test error message"); });

            var _controller = new DocumentsController(mockRepository.Object);

            // Act
            var result = await _controller.Document(Input);

            // Assert
            Assert.IsType<Microsoft.AspNetCore.Mvc.NotFoundObjectResult>(result.Result);

            Microsoft.AspNetCore.Mvc.NotFoundObjectResult outputObject = result.Result as Microsoft.AspNetCore.Mvc.NotFoundObjectResult;
            Assert.NotNull(outputObject);

            Assert.NotNull(outputObject.StatusCode);
            Assert.Equal(StatusCodes.Status404NotFound, outputObject.StatusCode.Value);
            Assert.IsType<ProcessErrorException>(outputObject.Value);
        }
    }
}
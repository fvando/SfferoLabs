﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.ScenariosPolicy
{
    public class PolicyControllerIntegrationTests
    {
        private readonly ContextApi _testContextApi;
       
        public PolicyControllerIntegrationTests()
        {
            _testContextApi = new ContextApi();
        }

        //[Theory]
        //[InlineData("/v1/Policies/Congener")]
        //public async Task TestPostPolicyCongeners001Async(string uri)
        //{
        //    //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
        //    //Object OUT
        //    var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
        //    {
        //        ErrorCode = "998",
        //        ErrorCodeTxt = ""
        //    };

        //    var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>();
        //    _arrayErrorsSAP.Add(_codeErroLineSAP);


        //    var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
        //    {
        //        PartnerRelationshipContract = "",
        //        Iban = "",
        //        PartnerExternalSystem = ""
        //    };

        //    var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>();
        //    _arraybenef.Add(_benef);

        //    var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
        //    {
        //        ClaimCategory = "",
        //        CommissionCategory = "",
        //        CostCategory = "",
        //        IspCode = "",
        //        PremiumCategory = ""
        //    };

        //    var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>();
        //    _arraymed.Add(_med);


        //    var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
        //    {
        //        ActionZone = "",
        //        Agent = "",
        //        Beneficiaries = _arraybenef.ToArray(),
        //        Broker = "",
        //        Errors = _arrayErrorsSAP.ToArray(),
        //        IncomingPaymentLockReason = "",
        //        InspectionArea = "",
        //        InsuranceObjectOriginal = "",
        //        Mediators = _med,
        //        OutgoingPaymentMethod = "",
        //        PartnerExternalSystem = "",
        //        PartnerRelationshipContract = "",
        //        SituactionCode = "",
        //        SituactionCodeDate = "",
        //        AddressNumber = "",
        //        AddressType = "",
        //        CompanyCode = "",
        //        EndDate = "",
        //        IncomingPaymentIban = "",
        //        IncomingPaymentMethod = "",
        //        InsuranceObject = "",
        //        InsuranceObjectCategory = "",
        //        InsuranceType = "",
        //        MandateReference = "",
        //        Network = "",
        //        OutgoingPaymentIban = "",
        //        OutgoingPaymentLockReason = "",
        //        StartDate = "",
        //        WithholdingTaxCode = ""
        //    };
        //    var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>();
        //    _arrayObject.Add(_obectlinha);


        //    var _congeners = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCongeneresLinha
        //    {
        //        Congener = _arrayObject.ToArray(),
        //        Interface = "",
        //        ItemsTotal = "",
        //        Online = "",
        //        OriginalSystem = "",
        //        SystemDate = "",
        //        SystemTime = "",
        //        Transaction = ""
        //    };

        //    //Object IN
        //    var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdCongeneresPostWs()
        //    {
        //        Coinsurance = _congeners
        //    };


        //    //Arrange
        //    var request = new
        //    {
        //        Body = _pcQueryWsModel
        //    };

        //    // Act
        //    var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

        //    // Assert - 400 
        //    response.StatusCode.Equals(404);

        //    //without return object
        //    Assert.Equal("Not Found", response.ReasonPhrase);

        //}

        //[Theory]
        //[InlineData("/v1/Policies/Congener")]
        //public async Task TestPostPolicyCongeners002Async(string uri)
        //{
        //    //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
        //    //Object OUT
        //    var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
        //    {
        //        ErrorCode = "?",
        //        ErrorCodeTxt = "?"
        //    };

        //    var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>();
        //    _arrayErrorsSAP.Add(_codeErroLineSAP);


        //    var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
        //    {
        //        PartnerExternalSystem = "",
        //        PartnerRelationshipContract = "",
        //        Iban = "?"
        //    };

        //    var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>();
        //    _arraybenef.Add(_benef);

        //    var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
        //    {
        //        ClaimCategory = "?",
        //        CommissionCategory = "?",
        //        CostCategory = "?",
        //        IspCode = "?",
        //        PremiumCategory = "?"
        //    };

        //    var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>();
        //    _arraymed.Add(_med);


        //    var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
        //    {
        //        ActionZone = "?",
        //        Agent = "?",
        //        Beneficiaries = _arraybenef.ToArray(),
        //        Broker = "?",
        //        Errors = _arrayErrorsSAP.ToArray(),
        //        IncomingPaymentLockReason = "?",
        //        InspectionArea = "?",
        //        InsuranceObjectOriginal = "?",
        //        Mediators = _med,
        //        OutgoingPaymentMethod = "?",
        //        PartnerExternalSystem = "?",
        //        PartnerRelationshipContract = "?",
        //        SituactionCode = "?",
        //        SituactionCodeDate = "?",
        //        AddressNumber = "?",
        //        AddressType = "?",
        //        CompanyCode = "?",
        //        EndDate = "?",
        //        IncomingPaymentIban = "?",
        //        IncomingPaymentMethod = "?",
        //        InsuranceObject = "?",
        //        InsuranceObjectCategory = "?",
        //        InsuranceType = "?",
        //        MandateReference = "?",
        //        Network = "?",
        //        OutgoingPaymentIban = "?",
        //        OutgoingPaymentLockReason = "?",
        //        StartDate = "?",
        //        WithholdingTaxCode = "?",
        //    };
        //    var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>();
        //    _arrayObject.Add(_obectlinha);


        //    var _congeners = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCongeneresLinha
        //    {
        //        Congener = _arrayObject.ToArray(),
        //        Interface = "?",
        //        ItemsTotal = "?",
        //        Online = "?",
        //        OriginalSystem = "?",
        //        SystemDate = "?",
        //        SystemTime = "?",
        //        Transaction = "?"
        //    };

        //    //Object IN
        //    var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdCongeneresPostWs()
        //    {
        //        Coinsurance = _congeners
        //    };

         
        //    //Arrange
        //    var request = new
        //    {
        //        Body = _pcQueryWsModel
        //    };

        //    // Act
        //    var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

        //    // Assert - 400 
        //    response.StatusCode.Equals(404);

        //    //without return object
        //    Assert.Equal("Not Found", response.ReasonPhrase);
        //}

        //[Theory]
        //[InlineData("/v1/Policies/Congener")]
        //public async Task TestPostPolicyCongeners003Async(string uri)
        //{
        //    DateTime max = DateTime.MaxValue;
        //    DateTime min = DateTime.MinValue;

        //    //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
        //    //Object OUT
        //    var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
        //    {
        //        ErrorCode = "?",
        //        ErrorCodeTxt = "?"
        //    };

        //    var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>();
        //    _arrayErrorsSAP.Add(_codeErroLineSAP);


        //    var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
        //    {
        //        PartnerRelationshipContract = "",
        //        PartnerExternalSystem = "",
        //        Iban = "?"
        //    };

        //    var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>();
        //    _arraybenef.Add(_benef);

        //    var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
        //    {
        //        ClaimCategory = "?",
        //        CommissionCategory = "?",
        //        CostCategory = "?",
        //        IspCode = "?",
        //        PremiumCategory = "?"
        //    };

        //    var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>();
        //    _arraymed.Add(_med);


        //    var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
        //    {
        //        ActionZone = "?",
        //        Agent = "?",
        //        Beneficiaries = _arraybenef.ToArray(),
        //        Broker = "?",
        //        Errors = _arrayErrorsSAP.ToArray(),
        //        IncomingPaymentLockReason = "?",
        //        InspectionArea = "?",
        //        InsuranceObjectOriginal = "?",
        //        Mediators = _med,
        //        OutgoingPaymentMethod = "?",
        //        PartnerExternalSystem = "?",
        //        PartnerRelationshipContract = "?",
        //        SituactionCode = "?",
        //        SituactionCodeDate = "?",
        //        AddressNumber = "?",
        //        AddressType = "?",
        //        CompanyCode = "?",
        //        EndDate = max.ToString(),
        //        IncomingPaymentIban = "?",
        //        IncomingPaymentMethod = "?",
        //        InsuranceObject = "?",
        //        InsuranceObjectCategory = "?",
        //        InsuranceType = "?",
        //        MandateReference = "?",
        //        Network = "?",
        //        OutgoingPaymentIban = "?",
        //        OutgoingPaymentLockReason = "?",
        //        StartDate = max.ToString(),
        //        WithholdingTaxCode = "?"
        //    };
        //    var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>();
        //    _arrayObject.Add(_obectlinha);


        //    var _congeners = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCongeneresLinha
        //    {
        //        Congener = _arrayObject.ToArray(),
        //        Interface = "?",
        //        ItemsTotal = "?",
        //        Online = "?",
        //        OriginalSystem = "?",
        //        SystemDate = max.ToString(),
        //        SystemTime = "?",
        //        Transaction = "?"
        //    };

        //    //Object IN
        //    var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdCongeneresPostWs()
        //    {
        //        Coinsurance = _congeners
        //    };


        //    //Arrange
        //    var request = new
        //    {
        //        Body = _pcQueryWsModel
        //    };

        //    // Act
        //    var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

        //    // Assert - 400 
        //    response.StatusCode.Equals(404);

        //    //without return object
        //    Assert.Equal("Not Found", response.ReasonPhrase);

        //}

        //[Theory]
        //[InlineData("/v1/Policies/Congener")]
        //public async Task TestPostPolicyCongeners004Async(string uri)
        //{
        //    DateTime max = DateTime.MaxValue;
        //    DateTime min = DateTime.MinValue;

        //    //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
        //    //Object OUT
        //    var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
        //    {
        //        ErrorCode = "?",
        //        ErrorCodeTxt = "?"
        //    };

        //    var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>();
        //    _arrayErrorsSAP.Add(_codeErroLineSAP);


        //    var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
        //    {
        //        PartnerExternalSystem = "?",
        //        PartnerRelationshipContract = "?",
        //        Iban = "?"
        //    };

        //    var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>();
        //    _arraybenef.Add(_benef);

        //    var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
        //    {
        //        ClaimCategory = "?",
        //        CommissionCategory = "?",
        //        CostCategory = "?",
        //        IspCode = "?",
        //        PremiumCategory = "?"
        //    };

        //    var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>();
        //    _arraymed.Add(_med);


        //    var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
        //    {
        //        ActionZone = "?",
        //        Agent = "?",
        //        Beneficiaries = _arraybenef.ToArray(),
        //        Broker = "?",
        //        Errors = _arrayErrorsSAP.ToArray(),
        //        IncomingPaymentLockReason = "?",
        //        InspectionArea = "?",
        //        InsuranceObjectOriginal = "?",
        //        Mediators = _med,
        //        OutgoingPaymentMethod = "?",
        //        PartnerExternalSystem = "?",
        //        PartnerRelationshipContract = "?",
        //        SituactionCode = "?",
        //        SituactionCodeDate = "?",
        //        AddressNumber = "?",
        //        AddressType = "?",
        //        CompanyCode = "?",
        //        EndDate = min.ToString(),
        //        IncomingPaymentIban = "?",
        //        IncomingPaymentMethod = "?",
        //        InsuranceObject = "?",
        //        InsuranceObjectCategory = "?",
        //        InsuranceType = "?",
        //        MandateReference = "?",
        //        Network = "?",
        //        OutgoingPaymentIban = "?",
        //        OutgoingPaymentLockReason = "?",
        //        StartDate = min.ToString(),
        //        WithholdingTaxCode = "?",
        //    };
        //    var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>();
        //    _arrayObject.Add(_obectlinha);


        //    var _congeners = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCongeneresLinha
        //    {
        //        Congener = _arrayObject.ToArray(),
        //        Interface = "?",
        //        ItemsTotal = "?",
        //        Online = "?",
        //        OriginalSystem = "?",
        //        SystemDate = min.ToString(),
        //        SystemTime = "?",
        //        Transaction = "?"
        //    };

        //    //Object IN
        //    var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdCongeneresPostWs()
        //    {
        //        Coinsurance = _congeners
        //    };


        //    //Arrange
        //    var request = new
        //    {
        //        Body = _pcQueryWsModel
        //    };

        //    // Act
        //    var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

        //    // Assert - 400 
        //    response.StatusCode.Equals(404);

        //    //without return object
        //    Assert.Equal("Not Found", response.ReasonPhrase);

        //}


        //[Theory]
        //[InlineData("/v1/Policies/Congener")]
        //public async Task TestPostPolicyCongeners005Async(string uri)
        //{
        //    DateTime max = DateTime.MaxValue;
        //    DateTime min = DateTime.MinValue;

        //    //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
        //    //Object OUT
        //    var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
        //    {
        //        ErrorCode = "string",
        //        ErrorCodeTxt = "string"
        //    };

        //    var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>();
        //    _arrayErrorsSAP.Add(_codeErroLineSAP);


        //    var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
        //    {
        //        PartnerExternalSystem= "string",
        //        PartnerRelationshipContract = "string",
        //        Iban = "string"
        //    };

        //    var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>();
        //    _arraybenef.Add(_benef);

        //    var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
        //    {
        //        ClaimCategory = "string",
        //        CommissionCategory = "string",
        //        CostCategory = "string",
        //        IspCode = "string",
        //        PremiumCategory = "string"
        //    };

        //    var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>();
        //    _arraymed.Add(_med);


        //    var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
        //    {
        //        ActionZone = "string",
        //        Agent = "string",
        //        Beneficiaries = _arraybenef.ToArray(),
        //        Broker = "string",
        //        Errors = _arrayErrorsSAP.ToArray(),
        //        IncomingPaymentLockReason = "string",
        //        InspectionArea = "string",
        //        InsuranceObjectOriginal = "string",
        //        Mediators = _med,
        //        OutgoingPaymentMethod = "string",
        //        PartnerExternalSystem = "string",
        //        PartnerRelationshipContract = "string",
        //        SituactionCode = "string",
        //        SituactionCodeDate = "string",
        //        AddressNumber = "string",
        //        AddressType = "string",
        //        CompanyCode = "string",
        //        EndDate = min.ToString(),
        //        IncomingPaymentIban = "string",
        //        IncomingPaymentMethod = "string",
        //        InsuranceObject = "string",
        //        InsuranceObjectCategory = "string",
        //        InsuranceType = "string",
        //        MandateReference = "string",
        //        Network = "string",
        //        OutgoingPaymentIban = "string",
        //        OutgoingPaymentLockReason = "string",
        //        StartDate = min.ToString(),
        //        WithholdingTaxCode = "?",
        //    };
        //    var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>();
        //    _arrayObject.Add(_obectlinha);


        //    var _congeners = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCongeneresLinha
        //    {
        //        Congener = _arrayObject.ToArray(),
        //        Interface = "string",
        //        ItemsTotal = "string",
        //        Online = "string",
        //        OriginalSystem = "string",
        //        SystemDate = min.ToString(),
        //        SystemTime = "string",
        //        Transaction = "string"
        //    };

        //    //Object IN
        //    var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdCongeneresPostWs()
        //    {
        //        Coinsurance = _congeners
        //    };


        //    //Arrange
        //    var request = new
        //    {
        //        Body = _pcQueryWsModel
        //    };

        //    // Act
        //    var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

        //    // Assert - 400 
        //    response.StatusCode.Equals(404);

        //    //without return object
        //    Assert.Equal("Not Found", response.ReasonPhrase);

        //}

        //[Theory]
        //[InlineData("/v1/Policies/Congener")]
        //public async Task TestPostPolicyCongeners006Async(string uri)
        //{
        //    DateTime max = DateTime.MaxValue;
        //    DateTime min = DateTime.MinValue;

        //    //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
        //    //Object OUT
        //    var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
        //    {
        //        ErrorCode = null,
        //        ErrorCodeTxt = null
        //    };

        //    var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>();
        //    _arrayErrorsSAP.Add(_codeErroLineSAP);


        //    var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
        //    {
        //        PartnerExternalSystem = null,
        //        PartnerRelationshipContract = null,
        //        Iban = null
        //    };

        //    var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>();
        //    _arraybenef.Add(_benef);

        //    var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
        //    {
        //        ClaimCategory = null,
        //        CommissionCategory = null,
        //        CostCategory = null,
        //        IspCode = null,
        //        PremiumCategory = null
        //    };

        //    var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>();
        //    _arraymed.Add(_med);


        //    var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
        //    {
        //        ActionZone = null,
        //        Agent = null,
        //        Beneficiaries = _arraybenef.ToArray(),
        //        Broker = null,
        //        Errors = _arrayErrorsSAP.ToArray(),
        //        IncomingPaymentLockReason = null,
        //        InspectionArea = null,
        //        InsuranceObjectOriginal = null,
        //        Mediators = _med,
        //        OutgoingPaymentMethod = null,
        //        PartnerExternalSystem = null,
        //        PartnerRelationshipContract = null,
        //        SituactionCode = null,
        //        SituactionCodeDate = null,
        //        AddressNumber = null,
        //        AddressType = null,
        //        CompanyCode = null,
        //        EndDate = min.ToString(),
        //        IncomingPaymentIban = null,
        //        IncomingPaymentMethod = null,
        //        InsuranceObject = null,
        //        InsuranceObjectCategory = null,
        //        InsuranceType = null,
        //        MandateReference = null,
        //        Network = null,
        //        OutgoingPaymentIban = null,
        //        OutgoingPaymentLockReason = null,
        //        StartDate = min.ToString(),
        //        WithholdingTaxCode = null,
        //    };
        //    var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>();
        //    _arrayObject.Add(_obectlinha);


        //    var _congeners = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCongeneresLinha
        //    {
        //        Congener = _arrayObject.ToArray(),
        //        Interface = null,
        //        ItemsTotal = null,
        //        Online = null,
        //        OriginalSystem = null,
        //        SystemDate = min.ToString(),
        //        SystemTime = null,
        //        Transaction = null
        //    };

        //    //Object IN
        //    var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdCongeneresPostWs()
        //    {
        //        Coinsurance = _congeners
        //    };


        //    //Arrange
        //    var request = new
        //    {
        //        Body = _pcQueryWsModel
        //    };

        //    // Act
        //    var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

        //    // Assert - 400 
        //    response.StatusCode.Equals(404);

        //    //without return object
        //    Assert.Equal("Not Found", response.ReasonPhrase);

        //}

        [Theory]
        [InlineData("/v1/Policies/Mediator")]
        public async Task TestPostPolicyMediator001Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = "",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerExternalSystem = "",
                PartnerRelationshipContract = "",
                Iban = ""
            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = "",
                CommissionCategory = "",
                CostCategory = "",
                IspCode = "",
                PremiumCategory = ""
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = "",
                Agent = "",
                Beneficiaries = _arraybenef.ToArray(),
                Broker = "",
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = "",
                InspectionArea = "",
                InsuranceObjectOriginal = "",
                Mediators = _med,
                OutgoingPaymentMethod = "",
                PartnerExternalSystem = "",
                PartnerRelationshipContract = "",
                SituactionCode = "",
                SituactionCodeDate = "",
                AddressNumber = "",
                AddressType = "",
                CompanyCode = "",
                EndDate = "",
                IncomingPaymentIban = "",
                IncomingPaymentMethod = "",
                InsuranceObject = "",
                InsuranceObjectCategory = "",
                InsuranceType = "",
                MandateReference = "",
                Network = "",
                OutgoingPaymentIban = "",
                OutgoingPaymentLockReason = "",
                StartDate = "",
                WithholdingTaxCode = ""
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _mediators = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdMediadoresLinha
            {
                Mediator = _arrayObject.ToArray(),
                Interface = "",
                ItemsTotal = "",
                Online = "",
                OriginalSystem = "",
                SystemDate = "",
                SystemTime = "",
                Transaction = ""
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWs()
            {
                MediationAccount = _mediators
            };

          
            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 200 
            response.StatusCode.Equals(200);

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);

        }

        [Theory]
        [InlineData("/v1/Policies/Mediator")]
        public async Task TestPostPolicyMediator002Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = "?",
                ErrorCodeTxt = "?"
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerRelationshipContract = "?", 
                PartnerExternalSystem = "?",
                Iban = "?"
            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = "?",
                CommissionCategory = "?",
                CostCategory = "?",
                IspCode = "?",
                PremiumCategory = "?"
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = "?",
                Agent = "?",
                Beneficiaries = _arraybenef.ToArray(),
                Broker = "?",
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = "?",
                InspectionArea = "?",
                InsuranceObjectOriginal = "?",
                Mediators = _med,
                OutgoingPaymentMethod = "?",
                PartnerExternalSystem = "?",
                PartnerRelationshipContract = "?",
                SituactionCode = "?",
                SituactionCodeDate = "?",
                AddressNumber = "?",
                AddressType = "?",
                CompanyCode = "?",
                EndDate = "?",
                IncomingPaymentIban = "?",
                IncomingPaymentMethod = "?",
                InsuranceObject = "?",
                InsuranceObjectCategory = "?",
                InsuranceType = "?",
                MandateReference = "?",
                Network = "?",
                OutgoingPaymentIban = "?",
                OutgoingPaymentLockReason = "?",
                StartDate = "?",
                WithholdingTaxCode = "?"
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _mediators = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdMediadoresLinha
            {
                Mediator = _arrayObject.ToArray(),
                Interface = "?",
                ItemsTotal = "?",
                Online = "?",
                OriginalSystem = "?",
                SystemDate = "?",
                SystemTime = "?",
                Transaction = "?"
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWs()
            {
                MediationAccount = _mediators
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Policies/Mediator")]
        public async Task TestPostPolicyMediator003Async(string uri)
        {
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = "?",
                ErrorCodeTxt = "?"
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerExternalSystem = "?",
                PartnerRelationshipContract = "?",
                Iban = "?"
            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = "?",
                CommissionCategory = "?",
                CostCategory = "?",
                IspCode = "?",
                PremiumCategory = "?"
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = "?",
                Agent = "?",
                Beneficiaries = _arraybenef.ToArray(),
                Broker = "?",
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = "?",
                InspectionArea = "?",
                InsuranceObjectOriginal = "?",
                Mediators = _med,
                OutgoingPaymentMethod = "?",
                PartnerExternalSystem = "?",
                PartnerRelationshipContract = "?",
                SituactionCode = "?",
                SituactionCodeDate = "?",
                AddressNumber = "?",
                AddressType = "?",
                CompanyCode = "?",
                EndDate = max.ToString(),
                IncomingPaymentIban = "?",
                IncomingPaymentMethod = "?",
                InsuranceObject = "?",
                InsuranceObjectCategory = "?",
                InsuranceType = "?",
                MandateReference = "?",
                Network = "?",
                OutgoingPaymentIban = "?",
                OutgoingPaymentLockReason = "?",
                StartDate = max.ToString(),
                WithholdingTaxCode = "?"
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _mediators = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdMediadoresLinha
            {
                Mediator = _arrayObject.ToArray(),
                Interface = "?",
                ItemsTotal = "?",
                Online = "?",
                OriginalSystem = "?",
                SystemDate = max.ToString(),
                SystemTime = "?",
                Transaction = "?"
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWs()
            {
                MediationAccount = _mediators
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));
            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);

        }

        [Theory]
        [InlineData("/v1/Policies/Mediator")]
        public async Task TestPostPolicyMediator004Async(string uri)
        {
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = "?",
                ErrorCodeTxt = "?"
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerExternalSystem = "?",
                PartnerRelationshipContract = "?",
                Iban = "?"
            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = "?",
                CommissionCategory = "?",
                CostCategory = "?",
                IspCode = "?",
                PremiumCategory = "?"
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = "?",
                Agent = "?",
                Beneficiaries = _arraybenef.ToArray(),
                Broker = "?",
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = "?",
                InspectionArea = "?",
                InsuranceObjectOriginal = "?",
                Mediators = _med,
                OutgoingPaymentMethod = "?",
                PartnerExternalSystem = "?",
                PartnerRelationshipContract = "?",
                SituactionCode = "?",
                SituactionCodeDate = "?",
                AddressNumber = "?",
                AddressType = "?",
                CompanyCode = "?",
                EndDate = min.ToString(),
                IncomingPaymentIban = "?",
                IncomingPaymentMethod = "?",
                InsuranceObject = "?",
                InsuranceObjectCategory = "?",
                InsuranceType = "?",
                MandateReference = "?",
                Network = "?",
                OutgoingPaymentIban = "?",
                OutgoingPaymentLockReason = "?",
                StartDate = min.ToString(),
                WithholdingTaxCode = "?"
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _mediators = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdMediadoresLinha
            {
                Mediator = _arrayObject.ToArray(),
                Interface = "?",
                ItemsTotal = "?",
                Online = "?",
                OriginalSystem = "?",
                SystemDate = min.ToString(),
                SystemTime = "?",
                Transaction = "?"
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWs()
            {
                MediationAccount = _mediators
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);

        }

        [Theory]
        [InlineData("/v1/Policies/Mediator")]
        public async Task TestPostPolicyMediator005Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = "?",
                ErrorCodeTxt = "?"
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerExternalSystem = "?",
                PartnerRelationshipContract = "?",
                Iban = "?"
            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = "?",
                CommissionCategory = "?",
                CostCategory = "?",
                IspCode = "?",
                PremiumCategory = "?"
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = "?",
                Agent = "?",
                Beneficiaries = _arraybenef.ToArray(),
                Broker = "?",
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = "?",
                InspectionArea = "?",
                InsuranceObjectOriginal = "?",
                Mediators = _med,
                OutgoingPaymentMethod = "?",
                PartnerExternalSystem = "?",
                PartnerRelationshipContract = "?",
                SituactionCode = "?",
                SituactionCodeDate = "?",
                AddressNumber = "?",
                AddressType = "?",
                CompanyCode = "?",
                EndDate = "?",
                IncomingPaymentIban = "?",
                IncomingPaymentMethod = "?",
                InsuranceObject = "?",
                InsuranceObjectCategory = "?",
                InsuranceType = "?",
                MandateReference = "?",
                Network = "?",
                OutgoingPaymentIban = "?",
                OutgoingPaymentLockReason = "?",
                StartDate = "?",
                WithholdingTaxCode = "?"
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _mediators = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdMediadoresLinha
            {
                Mediator= _arrayObject.ToArray(),
                Interface = "?",
                ItemsTotal = "?",
                Online = "?",
                OriginalSystem = "?",
                SystemDate = "?",
                SystemTime = "?",
                Transaction = "?"
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWs()
            {
                MediationAccount = _mediators
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }


        [Theory]
        [InlineData("/v1/Policies/Mediator")]
        public async Task TestPostPolicyMediator006Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = "?",
                ErrorCodeTxt = "?"
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerExternalSystem = "?",
                PartnerRelationshipContract = "?",
                Iban = "?"
            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = "?",
                CommissionCategory = "?",
                CostCategory = "?",
                IspCode = "?",
                PremiumCategory = "?"
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = "?",
                Agent = "?",
                Beneficiaries = _arraybenef.ToArray(),
                Broker = "?",
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = "?",
                InspectionArea = "?",
                InsuranceObjectOriginal = "?",
                Mediators = _med,
                OutgoingPaymentMethod = "?",
                PartnerExternalSystem = "?",
                PartnerRelationshipContract = "?",
                SituactionCode = "?",
                SituactionCodeDate = "?",
                AddressNumber = "?",
                AddressType = "?",
                CompanyCode = "?",
                EndDate = "?",
                IncomingPaymentIban = "?",
                IncomingPaymentMethod = "?",
                InsuranceObject = "?",
                InsuranceObjectCategory = "?",
                InsuranceType = "?",
                MandateReference = "?",
                Network = "?",
                OutgoingPaymentIban = "?",
                OutgoingPaymentLockReason = "?",
                StartDate = "?",
                WithholdingTaxCode = "?"
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _mediators = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdMediadoresLinha
            {
                Mediator = _arrayObject.ToArray(),
                Interface = "?",
                ItemsTotal = "?",
                Online = "?",
                OriginalSystem = "?",
                SystemDate = "?",
                SystemTime = "?",
                Transaction = "?"
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdMediadoresPostWs()
            {
                MediationAccount = _mediators
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Policies/Policy")]
        public async Task TestPostPolicyPolicies001Async(string uri)
        {

            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = "?",
                ErrorCodeTxt = "?"
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerExternalSystem = "?",
                PartnerRelationshipContract = "?",
                Iban = "?"
            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = "?",
                CommissionCategory = "?",
                CostCategory = "?",
                IspCode = "?",
                PremiumCategory = "?"
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = "?",
                Agent = "?",
                Beneficiaries = _arraybenef.ToArray(),
                Broker = "?",
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = "?",
                InspectionArea = "?",
                InsuranceObjectOriginal = "?",
                Mediators = _med,
                OutgoingPaymentMethod = "?",
                PartnerExternalSystem = "?",
                PartnerRelationshipContract = "?",
                SituactionCode = "?",
                SituactionCodeDate = "?",
                AddressNumber = "?",
                AddressType = "?",
                CompanyCode = "?",
                EndDate = "?",
                IncomingPaymentIban = "?",
                IncomingPaymentMethod = "?",
                InsuranceObject = "?",
                InsuranceObjectCategory = "?",
                InsuranceType = "?",
                MandateReference = "?",
                Network = "?",
                OutgoingPaymentIban = "?",
                OutgoingPaymentLockReason = "?",
                StartDate = "?",
                WithholdingTaxCode = "?"
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _policies = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdApolicesLinha
            {
                Policy = _arrayObject.ToArray(),
                Interface = "",
                ItemsTotal = "",
                Online = "",
                OriginalSystem = "",
                SystemDate = "",
                SystemTime = "",
                Transaction = ""
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWs()
            {
                Policies = _policies
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);

        }

        [Theory]
        [InlineData("/v1/Policies/Policy")]
        public async Task TestPostPolicyPolicies002Async(string uri)
        {

            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = "?",
                ErrorCodeTxt = "?"
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerExternalSystem = "?",
                PartnerRelationshipContract = "?",
Iban = "?"
            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = "?",
                CommissionCategory = "?",
                CostCategory = "?",
                IspCode = "?",
                PremiumCategory = "?"
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = "?",
                Agent = "?",
                Beneficiaries = _arraybenef.ToArray(),
                Broker = "?",
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = "?",
                InspectionArea = "?",
                InsuranceObjectOriginal = "?",
                Mediators = _med,
                OutgoingPaymentMethod = "?",
                PartnerExternalSystem = "?",
                PartnerRelationshipContract = "?",
                SituactionCode = "?",
                SituactionCodeDate = "?",
                AddressNumber = "?",
                AddressType = "?",
                CompanyCode = "?",
                EndDate = "?",
                IncomingPaymentIban = "?",
                IncomingPaymentMethod = "?",
                InsuranceObject = "?",
                InsuranceObjectCategory = "?",
                InsuranceType = "?",
                MandateReference = "?",
                Network = "?",
                OutgoingPaymentIban = "?",
                OutgoingPaymentLockReason = "?",
                StartDate = "?",
                WithholdingTaxCode = "?"
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _policies = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdApolicesLinha
            {
                Policy = _arrayObject.ToArray(),
                Interface = "?",
                ItemsTotal = "?",
                Online = "?",
                OriginalSystem = "?",
                SystemDate = "?",
                SystemTime = "?",
                Transaction = "?"
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWs()
            {
                Policies = _policies
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Policies/Policy")]
        public async Task TestPostPolicyPolicies003Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = "string",
                ErrorCodeTxt = "string"
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerExternalSystem = "string",
                PartnerRelationshipContract = "string",
                Iban = "string"
            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = "string",
                CommissionCategory = "string",
                CostCategory = "string",
                IspCode = "string",
                PremiumCategory = "string"
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = "string",
                Agent = "string",
                Beneficiaries = _arraybenef.ToArray(),
                Broker = "string",
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = "string",
                InspectionArea = "string",
                InsuranceObjectOriginal = "string",
                Mediators = _med,
                OutgoingPaymentMethod = "string",
                PartnerExternalSystem = "string",
                PartnerRelationshipContract = "string",
                SituactionCode = "string",
                SituactionCodeDate = "string",
                AddressNumber = "string",
                AddressType = "string",
                CompanyCode = "string",
                EndDate = "string",
                IncomingPaymentIban = "string",
                IncomingPaymentMethod = "string",
                InsuranceObject = "string",
                InsuranceObjectCategory = "string",
                InsuranceType = "string",
                MandateReference = "string",
                Network = "string",
                OutgoingPaymentIban = "string",
                OutgoingPaymentLockReason = "string",
                StartDate = "string",
                WithholdingTaxCode = "string"
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _policies = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdApolicesLinha
            {
                Policy = _arrayObject.ToArray(),
                Interface = "string",
                ItemsTotal = "string",
                Online = "string",
                OriginalSystem = "string",
                SystemDate = "string",
                SystemTime = "string",
                Transaction = "string"
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWs()
            {
                Policies = _policies
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);

        }


        [Theory]
        [InlineData("/v1/Policies/Policy")]
        public async Task TestPostPolicyPolicies004Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = null,
                ErrorCodeTxt = null
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerExternalSystem = null,
                PartnerRelationshipContract = null,
                Iban = null
            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = null,
                CommissionCategory = null,
                CostCategory = null,
                IspCode = null,
                PremiumCategory = null
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = null,
                Agent = null,
                Beneficiaries = _arraybenef.ToArray(),
                Broker = null,
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = null,
                InspectionArea = null,
                InsuranceObjectOriginal = null,
                Mediators = _med,
                OutgoingPaymentMethod = null,
                PartnerExternalSystem = null,
                PartnerRelationshipContract = null,
                SituactionCode = null,
                SituactionCodeDate = null,
                AddressNumber = null,
                AddressType = null,
                CompanyCode = null,
                EndDate = null,
                IncomingPaymentIban = null,
                IncomingPaymentMethod = null,
                InsuranceObject = null,
                InsuranceObjectCategory = null,
                InsuranceType = null,
                MandateReference = null,
                Network = null,
                OutgoingPaymentIban = null,
                OutgoingPaymentLockReason = null,
                StartDate = null,
                WithholdingTaxCode = null
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _policies = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdApolicesLinha
            {
                Policy = _arrayObject.ToArray(),
                Interface = null,
                ItemsTotal = null,
                Online = null,
                OriginalSystem = null,
                SystemDate = null,
                SystemTime = null,
                Transaction = null
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWs()
            {
                Policies = _policies
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));
            
            // Assert - 200 
            response.StatusCode.Equals(200);

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);

        }

        [Theory]
        [InlineData("/v1/Policies/Policy")]
        public async Task TestPostPolicyPolicies005Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;

            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = null,
                ErrorCodeTxt = null
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerExternalSystem = null,
                PartnerRelationshipContract = null,
Iban = null
            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = null,
                CommissionCategory = null,
                CostCategory = null,
                IspCode = null,
                PremiumCategory = null
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = null,
                Agent = null,
                Beneficiaries = _arraybenef.ToArray(),
                Broker = null,
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = null,
                InspectionArea = null,
                InsuranceObjectOriginal = null,
                Mediators = _med,
                OutgoingPaymentMethod = null,
                PartnerExternalSystem = null,
                PartnerRelationshipContract = null,
                SituactionCode = null,
                SituactionCodeDate = null,
                AddressNumber = null,
                AddressType = null,
                CompanyCode = null,
                EndDate = max.ToString(),
                IncomingPaymentIban = null,
                IncomingPaymentMethod = null,
                InsuranceObject = null,
                InsuranceObjectCategory = null,
                InsuranceType = null,
                MandateReference = null,
                Network = null,
                OutgoingPaymentIban = null,
                OutgoingPaymentLockReason = null,
                StartDate = max.ToString(),
                WithholdingTaxCode = null
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _policies = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdApolicesLinha
            {
                Policy = _arrayObject.ToArray(),
                Interface = null,
                ItemsTotal = null,
                Online = null,
                OriginalSystem = null,
                SystemDate = max.ToString(),
                SystemTime = null,
                Transaction = null
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWs()
            {
                Policies = _policies
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);

        }

        [Theory]
        [InlineData("/v1/Policies/Policy")]
        public async Task TestPostPolicyPolicies006Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;

            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = null,
                ErrorCodeTxt = null
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerRelationshipContract=null,
                PartnerExternalSystem = null,
                Iban = null
            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = null,
                CommissionCategory = null,
                CostCategory = null,
                IspCode = null,
                PremiumCategory = null
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = null,
                Agent = null,
                Beneficiaries = _arraybenef.ToArray(),
                Broker = null,
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = null,
                InspectionArea = null,
                InsuranceObjectOriginal = null,
                Mediators = _med,
                OutgoingPaymentMethod = null,
                PartnerExternalSystem = null,
                PartnerRelationshipContract = null,
                SituactionCode = null,
                SituactionCodeDate = null,
                AddressNumber = null,
                AddressType = null,
                CompanyCode = null,
                EndDate = max.ToString(),
                IncomingPaymentIban = null,
                IncomingPaymentMethod = null,
                InsuranceObject = null,
                InsuranceObjectCategory = null,
                InsuranceType = null,
                MandateReference = null,
                Network = null,
                OutgoingPaymentIban = null,
                OutgoingPaymentLockReason = null,
                StartDate = max.ToString(),
                WithholdingTaxCode = null
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _policies = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdApolicesLinha
            {
                Policy = _arrayObject.ToArray(),
                Interface = null,
                ItemsTotal = null,
                Online = null,
                OriginalSystem = null,
                SystemDate = min.ToString(),
                SystemTime = null,
                Transaction = null
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdApolicesPostWs()
            {
                Policies = _policies
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));
            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);

        }


        [Theory]
        [InlineData("/v1/Policies/Sinister")]
        public async Task TestPostPolicySinisters001Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;

            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = null,
                ErrorCodeTxt = null
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerRelationshipContract = null,
                PartnerExternalSystem = null,
                Iban = null

            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = null,
                CommissionCategory = null,
                CostCategory = null,
                IspCode = null,
                PremiumCategory = null
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = null,
                Agent = null,
                Beneficiaries = _arraybenef.ToArray(),
                Broker = null,
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = null,
                InspectionArea = null,
                InsuranceObjectOriginal = null,
                Mediators = _med,
                OutgoingPaymentMethod = null,
                PartnerExternalSystem = null,
                PartnerRelationshipContract = null,
                SituactionCode = null,
                SituactionCodeDate = null,
                AddressNumber = null,
                AddressType = null,
                CompanyCode = null,
                EndDate = min.ToString(),
                IncomingPaymentIban = null,
                IncomingPaymentMethod = null,
                InsuranceObject = null,
                InsuranceObjectCategory = null,
                InsuranceType = null,
                MandateReference = null,
                Network = null,
                OutgoingPaymentIban = null,
                OutgoingPaymentLockReason = null,
                StartDate = min.ToString(),
                WithholdingTaxCode = null
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _sinisties = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdSinistrosLinha
            {
                Claim = _arrayObject.ToArray(),
                Interface = null,
                ItemsTotal = null,
                Online = null,
                OriginalSystem = null,
                SystemDate = min.ToString(),
                SystemTime = null,
                Transaction = null
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWs()
            {
                Claims = _sinisties
            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));
            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);

        }


        [Theory]
        [InlineData("/v1/Policies/Sinister")]
        public async Task TestPostPolicySinisters002Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;

            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = null,
                ErrorCodeTxt = null
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerRelationshipContract = null,
                PartnerExternalSystem = null,
                Iban = null

            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = null,
                CommissionCategory = null,
                CostCategory = null,
                IspCode = null,
                PremiumCategory = null
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = null,
                Agent = null,
                Beneficiaries = _arraybenef.ToArray(),
                Broker = null,
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = null,
                InspectionArea = null,
                InsuranceObjectOriginal = null,
                Mediators = _med,
                OutgoingPaymentMethod = null,
                PartnerExternalSystem = null,
                PartnerRelationshipContract = null,
                SituactionCode = null,
                SituactionCodeDate = null,
                AddressNumber = null,
                AddressType = null,
                CompanyCode = null,
                EndDate = max.ToString(),
                IncomingPaymentIban = null,
                IncomingPaymentMethod = null,
                InsuranceObject = null,
                InsuranceObjectCategory = null,
                InsuranceType = null,
                MandateReference = null,
                Network = null,
                OutgoingPaymentIban = null,
                OutgoingPaymentLockReason = null,
                StartDate = max.ToString(),
                WithholdingTaxCode = null
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _sinisties = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdSinistrosLinha
            {
                Claim = _arrayObject.ToArray(),
                Interface = null,
                ItemsTotal = null,
                Online = null,
                OriginalSystem = null,
                SystemDate = max.ToString(),
                SystemTime = null,
                Transaction = null
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWs()
            {
                Claims = _sinisties
            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);

        }

        [Theory]
        [InlineData("/v1/Policies/Sinister")]
        public async Task TestPostPolicySinisters003Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;

            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = "string",
                ErrorCodeTxt = "string"
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerExternalSystem = "string",
                PartnerRelationshipContract = "string",
Iban = "string"
            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = "string",
                CommissionCategory = "string",
                CostCategory = "string",
                IspCode = "string",
                PremiumCategory = "string"
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = "string",
                Agent = "string",
                Beneficiaries = _arraybenef.ToArray(),
                Broker = "string",
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = "string",
                InspectionArea = "string",
                InsuranceObjectOriginal = "string",
                Mediators = _med,
                OutgoingPaymentMethod = "string",
                PartnerExternalSystem = "string",
                PartnerRelationshipContract = "string",
                SituactionCode = "string",
                SituactionCodeDate = "string",
                AddressNumber = "string",
                AddressType = "string",
                CompanyCode = "string",
                EndDate = max.ToString(),
                IncomingPaymentIban = "string",
                IncomingPaymentMethod = "string",
                InsuranceObject = "string",
                InsuranceObjectCategory = "string",
                InsuranceType = "string",
                MandateReference = "string",
                Network = "string",
                OutgoingPaymentIban = "string",
                OutgoingPaymentLockReason = "string",
                StartDate = max.ToString(),
                WithholdingTaxCode = "string"
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _sinisties = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdSinistrosLinha
            {
                Claim = _arrayObject.ToArray(),
                Interface = "string",
                ItemsTotal = "string",
                Online = "string",
                OriginalSystem = "string",
                SystemDate = max.ToString(),
                SystemTime = "string",
                Transaction = "string"
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWs()
            {
                Claims = _sinisties
            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);

        }

        [Theory]
        [InlineData("/v1/Policies/Sinister")]
        public async Task TestPostPolicySinisters004Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;

            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = "?",
                ErrorCodeTxt = "?"
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerExternalSystem = "?",
                PartnerRelationshipContract = "?",
                Iban = "?"
            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = "?",
                CommissionCategory = "?",
                CostCategory = "?",
                IspCode = "?",
                PremiumCategory = "?"
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = "?",
                Agent = "?",
                Beneficiaries = _arraybenef.ToArray(),
                Broker = "?",
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = "?",
                InspectionArea = "?",
                InsuranceObjectOriginal = "?",
                Mediators = _med,
                OutgoingPaymentMethod = "?",
                PartnerExternalSystem = "?",
                PartnerRelationshipContract = "?",
                SituactionCode = "?",
                SituactionCodeDate = "?",
                AddressNumber = "?",
                AddressType = "?",
                CompanyCode = "?",
                EndDate = max.ToString(),
                IncomingPaymentIban = "?",
                IncomingPaymentMethod = "?",
                InsuranceObject = "?",
                InsuranceObjectCategory = "?",
                InsuranceType = "?",
                MandateReference = "?",
                Network = "?",
                OutgoingPaymentIban = "?",
                OutgoingPaymentLockReason = "?",
                StartDate = max.ToString(),
                WithholdingTaxCode = "?"
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _sinisties = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdSinistrosLinha
            {
                Claim = _arrayObject.ToArray(),
                Interface = "?",
                ItemsTotal = "?",
                Online = "?",
                OriginalSystem = "?",
                SystemDate = max.ToString(),
                SystemTime = "?",
                Transaction = "?"
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWs()
            {
                Claims = _sinisties
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);

        }

        [Theory]
        [InlineData("/v1/Policies/Sinister")]
        public async Task TestPostPolicySinisters005Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;

            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy
            {
                ErrorCode = "",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdCodigosErroLinhaPolicy>
            {
                _codeErroLineSAP
            };


            var _benef = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario()
            {
                PartnerExternalSystem = "",
                PartnerRelationshipContract = "",
                Iban = ""
            };

            var _arraybenef = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectBeneficiario>
            {
                _benef
            };

            var _med = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador()
            {
                ClaimCategory = "",
                CommissionCategory = "",
                CostCategory = "",
                IspCode = "",
                PremiumCategory = ""
            };

            var _arraymed = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectMediador>
            {
                _med
            };


            var _obectlinha = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha()
            {
                ActionZone = "",
                Agent = "",
                Beneficiaries = _arraybenef.ToArray(),
                Broker = "",
                Errors = _arrayErrorsSAP.ToArray(),
                IncomingPaymentLockReason = "",
                InspectionArea = "",
                InsuranceObjectOriginal = "",
                Mediators = _med,
                OutgoingPaymentMethod = "",
                PartnerExternalSystem = "",
                PartnerRelationshipContract = "",
                SituactionCode = "",
                SituactionCodeDate = "",
                AddressNumber = "",
                AddressType = "",
                CompanyCode = "",
                EndDate = max.ToString(),
                IncomingPaymentIban = "",
                IncomingPaymentMethod = "",
                InsuranceObject = "",
                InsuranceObjectCategory = "",
                InsuranceType = "",
                MandateReference = "",
                Network = "",
                OutgoingPaymentIban = "",
                OutgoingPaymentLockReason = "",
                StartDate = max.ToString(),
                WithholdingTaxCode = ""
            };
            var _arrayObject = new List<INS.PT.WebAPI.Model.Partners.Policy.ZfscdInsobjectLinha>
            {
                _obectlinha
            };


            var _sinisties = new INS.PT.WebAPI.Model.Partners.Policy.ZfscdSinistrosLinha
            {
                Claim = _arrayObject.ToArray(),
                Interface = "",
                ItemsTotal = "",
                Online = "",
                OriginalSystem = "",
                SystemDate = max.ToString(),
                SystemTime = "",
                Transaction = ""
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Policy.ZFscdSinistrosPostWs()
            {
                Claims = _sinisties
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));
            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);

        }
    }
}

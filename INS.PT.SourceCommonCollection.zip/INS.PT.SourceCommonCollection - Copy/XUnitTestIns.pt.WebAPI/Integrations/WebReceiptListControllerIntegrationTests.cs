﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.ScenariosWebReceiptList
{
    public class WebReceiptListControllerIntegrationTests
    {
        private readonly ContextApi _testContextApi;
       
        public WebReceiptListControllerIntegrationTests()
        {
            _testContextApi = new ContextApi();
        }

        [Theory]
        [InlineData("/v1/WebReceiptListing/List")]
        public async Task TestPostReceiptListing001Async(string uri)
        {
            //Object IN
            DateTime min = DateTime.MinValue;
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdRecibosListarWs()
            {
                Broker = "",
                CompanyCode = "",
                EndDate = min.ToString(),
                Policy = "",
                ReferenceDocumentNumber = "",
                StartDate = min.ToString(),
                Status = "",
                TaxNumber = ""
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/WebReceiptListing/List")]
        public async Task TestPostReceiptListing002Async(string uri)
        {
            //Object IN
            DateTime max = DateTime.MaxValue;
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdRecibosListarWs()
            {
                Broker = "",
                CompanyCode = "",
                EndDate = max.ToString(),
                Policy = "",
                ReferenceDocumentNumber = "",
                StartDate = max.ToString(),
                Status = "",
                TaxNumber = ""
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/WebReceiptListing/List")]
        public async Task TestPostReceiptListing003Async(string uri)
        {
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdRecibosListarWs()
            {
                Broker = "?",
                CompanyCode = "?",
                EndDate = "?",
                Policy = "?",
                ReferenceDocumentNumber = "?",
                StartDate = "?",
                Status = "?",
                TaxNumber = "?"
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(200);

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/WebReceiptListing/List")]
        public async Task TestPostReceiptListing004Async(string uri)
        {
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdRecibosListarWs()
            {
                Broker = "string",
                CompanyCode = "string",
                EndDate = "string",
                Policy = "string",
                ReferenceDocumentNumber = "string",
                StartDate = "string",
                Status = "string",
                TaxNumber = "string"
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/WebReceiptListing/List")]
        public async Task TestPostReceiptListing005Async(string uri)
        {
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdRecibosListarWs()
            {
                Broker = null,
                CompanyCode = null,
                EndDate = null,
                Policy = null,
                ReferenceDocumentNumber = null,
                StartDate = null,
                Status = null,
                TaxNumber = null
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/WebReceiptListing/List")]
        public async Task TestPostReceiptListing006Async(string uri)
        {
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdRecibosListarWs()
            {
                //Broker = null,
                CompanyCode = null,
                EndDate = null,
                //Policy = null,
                ReferenceDocumentNumber = null,
                StartDate = null,
                //Status = null,
                TaxNumber = null
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/WebReceiptListing/BillingChannel")]
        public async Task TestPostBillingChannels001Async(string uri)
        {
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdCanaisCobrancaWs()
            {

            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 200
            response.StatusCode.Equals(200);
        

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/WebReceiptListing/Status")]
        public async Task TestPostStatus001Async(string uri)
        {
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdStatusWs()
            {

            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };


            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400
            response.StatusCode.Equals(200);

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/WebReceiptListing/Type")]
        public async Task TestPostTypes001Async(string uri)
        {
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdTiposWs()
            {

            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };


            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400
            response.StatusCode.Equals(200);
        

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/WebReceiptListing/Branch")]
        public async Task TestPostBranch001Async(string uri)
        {

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdRamosWs()
            {

            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400
            response.StatusCode.Equals(200);

       
            //without return object
            Assert.Equal("OK", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/WebReceiptListing/ProductGroup")]
        public async Task TestPostGroups001Async(string uri)
        {
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.WebReceiptListing.ZFscdGruposProdutoWs()
            {
              
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };
            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request));

            // Assert - 400
            response.StatusCode.Equals(200);

         
            //without return object
            Assert.Equal("OK", response.ReasonPhrase);
        }


    }
}

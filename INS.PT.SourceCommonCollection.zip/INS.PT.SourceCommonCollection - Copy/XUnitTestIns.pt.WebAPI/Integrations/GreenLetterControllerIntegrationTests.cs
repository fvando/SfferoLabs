﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.ScenariosGreenLetter
{
    public class GreenLetterControllerIntegrationTests
    {
        private readonly ContextApi _testContextApi;
       
        public GreenLetterControllerIntegrationTests()
        {
            _testContextApi = new ContextApi();
        }

        [Theory]
        [InlineData("/v1/GreenLetters/GreenLetter")]
        public async Task TestPostGreenLetter001Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            //Object IN
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;
            var _codeErroLine = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCodigosErroLinhaGreenLetter
            {
                ErrorCode = "",
                ErrorCodeTxt = ""
            };

            var _arrayErrors = new List<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCodigosErroLinhaGreenLetter>
            {
                _codeErroLine
            };

            var _greenletters = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha()
            {
                AutoClass1 = "",
                AutoClass2 = "",
                AutoNcc = "",
                AutoTxCodRc1 = "",
                AutoTxCodRc2 = "",
                AutoTxVarRc1 = "",
                AutoTxVarRc2 = "",
                BrokerContract = "",
                CarBrand1 = "",
                CarBrand2 = "",
                CivilCertificateNumber = "",
                CivilLiabilityCapital = "",
                CompanyCode = "",
                Currency = "",
                CvCode1 = "",
                CvCode2 = "",
                CvDocumentNumber1 = "",
                CvDocumentNumber2 = "",
                CvEndDate = "",
                CvStartDate = "",
                Errors = _arrayErrors.ToArray(),
                ExtraCapital = "",
                FleetFlag = "",
                GroupNumber = "",
                InsuranceType = "",
                Line = "",
                Network = "",
                OwnDamageCapital = "",
                OwnDamageValue = "",
                PartnerExternalSystem = "",
                Policy = "",
                PostalCode = "",
                Prefix = "",
                PrtGreenLetter = "",
                PrtCertificateNumberLetter = "",
                ReferenceDocumentNumber = "",
                RegistrationNumber1 = "",
                RegistrationNumber2 = "",
                RiskLocal = "",
                RiskPostalCode = "",
                SequenceNumber = "",
                Street = "",
                DocumentType = "",
                MasterOrigin = ""
            };
            var _arraygreenLetter = new List<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha>
            {
                _greenletters
            };

            var _greenletter = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartasverdeLinha
            {
                Greencard = _arraygreenLetter.ToArray(),
                Interface = "",
                ItemsTotal = "",
                Online = "",
                OriginalSystem = "",
                SystemDate = "",
                SystemTime = "",
                Transaction = ""
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWs()
            {
                Greencards = _greenletter
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 200 
            response.StatusCode.Equals(200);

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);

        }

        [Theory]
        [InlineData("/v1/GreenLetters/GreenLetter")]
        public async Task TestPostGreenLetter002Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            //Object IN
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;

            var _codeErroLine = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCodigosErroLinhaGreenLetter
            {
                ErrorCode = "998",
                ErrorCodeTxt = ""
            };

            var _arrayErrors = new List<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCodigosErroLinhaGreenLetter>
            {
                _codeErroLine
            };

            var _greenletters = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha()
            {
                AutoClass1 = "",
                AutoClass2 = "",
                AutoNcc = "",
                AutoTxCodRc1 = "",
                AutoTxCodRc2 = "",
                AutoTxVarRc1 = "",
                AutoTxVarRc2 = "",
                BrokerContract = "",
                CarBrand1 = "",
                CarBrand2 = "",
                CivilCertificateNumber = "",
                CivilLiabilityCapital = "",
                CompanyCode = "",
                Currency = "",
                CvCode1 = "",
                CvCode2 = "",
                CvDocumentNumber1 = "",
                CvDocumentNumber2 = "",
                CvEndDate = max.ToString(),
                CvStartDate = max.ToString(),
                Errors = _arrayErrors.ToArray(),
                ExtraCapital = "",
                FleetFlag = "",
                GroupNumber = "",
                InsuranceType = "",
                Line = "",
                Network = "",
                OwnDamageCapital = "",
                OwnDamageValue = "",
                PartnerExternalSystem = "",
                Policy = "",
                PostalCode = "",
                Prefix = "",
                PrtCertificateNumberLetter = "",
                PrtGreenLetter = "",
                ReferenceDocumentNumber = "",
                RegistrationNumber1 = "",
                RegistrationNumber2 = "",
                RiskLocal = "",
                RiskPostalCode = "",
                SequenceNumber = "",
                Street = "",
                DocumentType = "",
                MasterOrigin =""
            };
            var _arraygreenLetter = new List<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha>
            {
                _greenletters
            };

            var _greenletter = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartasverdeLinha
            {
                Greencard = _arraygreenLetter.ToArray(),
                Interface = "",
                ItemsTotal = "",
                Online = "",
                OriginalSystem = "",
                SystemDate = max.ToString(),
                SystemTime = "",
                Transaction = ""
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWs()
            {
                Greencards = _greenletter
            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/GreenLetters/GreenLetter")]
        public async Task TestPostGreenLetter003Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            //Object IN
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;

            var _codeErroLine = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCodigosErroLinhaGreenLetter
            {
                ErrorCode = "",
                ErrorCodeTxt = ""
            };

            var _arrayErrors = new List<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCodigosErroLinhaGreenLetter>
            {
                _codeErroLine
            };

            var _greenletters = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha()
            {
                AutoClass1 = "",
                AutoClass2 = "",
                AutoNcc = "",
                AutoTxCodRc1 = "",
                AutoTxCodRc2 = "",
                AutoTxVarRc1 = "",
                AutoTxVarRc2 = "",
                BrokerContract = "",
                CarBrand1 = "",
                CarBrand2 = "",
                CivilCertificateNumber = "",
                CivilLiabilityCapital = "",
                CompanyCode = "",
                Currency = "",
                CvCode1 = "",
                CvCode2 = "",
                CvDocumentNumber1 = "",
                CvDocumentNumber2 = "",
                CvEndDate = min.ToString(),
                CvStartDate = min.ToString(),
                Errors = _arrayErrors.ToArray(),
                ExtraCapital = "",
                FleetFlag = "",
                GroupNumber = "",
                InsuranceType = "",
                Line = "",
                Network = "",
                OwnDamageCapital = "",
                OwnDamageValue = "",
                PartnerExternalSystem = "",
                Policy = "",
                PostalCode = "",
                Prefix = "",
                PrtCertificateNumberLetter = "",
                PrtGreenLetter = "",
                ReferenceDocumentNumber = "",
                RegistrationNumber1 = "",
                RegistrationNumber2 = "",
                RiskLocal = "",
                RiskPostalCode = "",
                SequenceNumber = "",
                Street = "",
                DocumentType = "",
                MasterOrigin = ""
            };
            var _arraygreenLetter = new List<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha>
            {
                _greenletters
            };

            var _greenletter = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartasverdeLinha
            {
                Greencard = _arraygreenLetter.ToArray(),
                Interface = "",
                ItemsTotal = "",
                Online = "",
                OriginalSystem = "",
                SystemDate = min.ToString(),
                SystemTime = "",
                Transaction = ""
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWs()
            {
                Greencards = _greenletter
            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/GreenLetters/GreenLetter")]
        public async Task TestPostGreenLetter004Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            //Object IN

            var _codeErroLine = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCodigosErroLinhaGreenLetter
            {
                ErrorCode = "?",
                ErrorCodeTxt = "?"
            };

            var _arrayErrors = new List<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCodigosErroLinhaGreenLetter>
            {
                _codeErroLine
            };

            var _greenletters = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha()
            {
                AutoClass1 = "?",
                AutoClass2 = "?",
                AutoNcc = "?",
                AutoTxCodRc1 = "?",
                AutoTxCodRc2 = "?",
                AutoTxVarRc1 = "?",
                AutoTxVarRc2 = "?",
                BrokerContract = "?",
                CarBrand1 = "?",
                CarBrand2 = "?",
                CivilCertificateNumber = "?",
                CivilLiabilityCapital = "?",
                CompanyCode = "?",
                Currency = "?",
                CvCode1 = "?",
                CvCode2 = "?",
                CvDocumentNumber1 = "?",
                CvDocumentNumber2 = "?",
                CvEndDate = "?",
                CvStartDate = "?",
                Errors = _arrayErrors.ToArray(),
                ExtraCapital = "?",
                FleetFlag = "?",
                GroupNumber = "?",
                InsuranceType = "?",
                Line = "?",
                Network = "?",
                OwnDamageCapital = "?",
                OwnDamageValue = "?",
                PartnerExternalSystem = "?",
                Policy = "?",
                PostalCode = "?",
                Prefix = "?",
                PrtCertificateNumberLetter = "?",
                PrtGreenLetter = "?",
                ReferenceDocumentNumber = "?",
                RegistrationNumber1 = "?",
                RegistrationNumber2 = "?",
                RiskLocal = "?",
                RiskPostalCode = "?",
                SequenceNumber = "?",
                Street = "?",
                DocumentType = "?",
                MasterOrigin = "?"

            };
            var _arraygreenLetter = new List<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha>
            {
                _greenletters
            };

            var _greenletter = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartasverdeLinha
            {
                Greencard = _arraygreenLetter.ToArray(),
                Interface = "?",
                ItemsTotal = "?",
                Online = "?",
                OriginalSystem = "?",
                SystemDate = "?",
                SystemTime = "?",
                Transaction = "?"
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWs()
            {
                Greencards = _greenletter
            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/GreenLetters/GreenLetter")]
        public async Task TestPostGreenLetter005Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            //Object IN

            var _codeErroLine = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCodigosErroLinhaGreenLetter
            {
                ErrorCode = "string",
                ErrorCodeTxt = "string"
            };

            var _arrayErrors = new List<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCodigosErroLinhaGreenLetter>
            {
                _codeErroLine
            };

            var _greenletters = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha()
            {
                AutoClass1 = "string",
                AutoClass2 = "string",
                AutoNcc = "string",
                AutoTxCodRc1 = "string",
                AutoTxCodRc2 = "string",
                AutoTxVarRc1 = "string",
                AutoTxVarRc2 = "string",
                BrokerContract = "string",
                CarBrand1 = "string",
                CarBrand2 = "string",
                CivilCertificateNumber = "string",
                CivilLiabilityCapital = "string",
                CompanyCode = "string",
                Currency = "string",
                CvCode1 = "string",
                CvCode2 = "string",
                CvDocumentNumber1 = "string",
                CvDocumentNumber2 = "string",
                CvEndDate = "string",
                CvStartDate = "string",
                Errors = _arrayErrors.ToArray(),
                ExtraCapital = "string",
                FleetFlag = "string",
                GroupNumber = "string",
                InsuranceType = "string",
                Line = "string",
                Network = "string",
                OwnDamageCapital = "string",
                OwnDamageValue = "string",
                PartnerExternalSystem = "string",
                Policy = "string",
                PostalCode = "string",
                Prefix = "string",
                PrtCertificateNumberLetter = "string",
                PrtGreenLetter = "string",
                ReferenceDocumentNumber = "string",
                RegistrationNumber1 = "string",
                RegistrationNumber2 = "string",
                RiskLocal = "string",
                RiskPostalCode = "string",
                SequenceNumber = "string",
                Street = "string",
                DocumentType = "string",
                MasterOrigin = "string"
            };
            var _arraygreenLetter = new List<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha>
            {
                _greenletters
            };

            var _greenletter = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartasverdeLinha
            {
                Greencard = _arraygreenLetter.ToArray(),
                Interface = "string",
                ItemsTotal = "string",
                Online = "string",
                OriginalSystem = "string",
                SystemDate = "string",
                SystemTime = "string",
                Transaction = "string"
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWs()
            {
                Greencards = _greenletter
            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/GreenLetters/GreenLetter")]
        public async Task TestPostGreenLetter006Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            //Object IN

            var _codeErroLine = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCodigosErroLinhaGreenLetter
            {
                ErrorCode = null,
                ErrorCodeTxt = null
            };

            var _arrayErrors = new List<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCodigosErroLinhaGreenLetter>
            {
                _codeErroLine
            };

            var _greenletters = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha()
            {
                AutoClass1 = null,
                AutoClass2 = null,
                AutoNcc = null,
                AutoTxCodRc1 = null,
                AutoTxCodRc2 = null,
                AutoTxVarRc1 = null,
                AutoTxVarRc2 = null,
                BrokerContract = null,
                CarBrand1 = null,
                CarBrand2 = null,
                CivilCertificateNumber = null,
                CivilLiabilityCapital = null,
                CompanyCode = null,
                Currency = null,
                CvCode1 = null,
                CvCode2 = null,
                CvDocumentNumber1 = null,
                CvDocumentNumber2 = null,
                CvEndDate = null,
                CvStartDate = null,
                Errors = _arrayErrors.ToArray(),
                ExtraCapital = null,
                FleetFlag = null,
                GroupNumber = null,
                InsuranceType = null,
                Line = null,
                Network = null,
                OwnDamageCapital = null,
                OwnDamageValue = null,
                PartnerExternalSystem = null,
                Policy = null,
                PostalCode = null,
                Prefix = null,
                PrtCertificateNumberLetter = null,
                PrtGreenLetter = null,
                ReferenceDocumentNumber = null,
                RegistrationNumber1 = null,
                RegistrationNumber2 = null,
                RiskLocal = null,
                RiskPostalCode = null,
                SequenceNumber = null,
                Street = null,
                DocumentType = null,
                MasterOrigin = null
            };
            var _arraygreenLetter = new List<INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartaverdeLinha>
            {
                _greenletters
            };

            var _greenletter = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZfscdCartasverdeLinha
            {
                Greencard = _arraygreenLetter.ToArray(),
                Interface = null,
                ItemsTotal = null,
                Online = null,
                OriginalSystem = null,
                SystemDate = null,
                SystemTime = null,
                Transaction = null
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.GreenLetter.ZFscdCartasverdePostWs()
            {
                Greencards = _greenletter
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));
            // Assert - 200 
            response.StatusCode.Equals(200);

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);

        }
    }
}

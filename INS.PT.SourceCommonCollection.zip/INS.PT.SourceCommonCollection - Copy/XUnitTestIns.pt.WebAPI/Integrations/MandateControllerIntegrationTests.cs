﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.ScenariosMandate
{
    public class MandateControllerIntegrationTests
    {
        private readonly ContextApi _testContextApi;
       
        public MandateControllerIntegrationTests()
        {
            _testContextApi = new ContextApi();
        }

        [Theory]
        [InlineData("/v1/Mandates/Mandate")]
        public async Task TestPostMandate001Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandate
            {
                ErrorCode = "",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandate>
            {
                _codeErroLineSAP
            };

            var _mandates = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha()
            {
                CompanyCode = "",
                Description = "",
                Errors = _arrayErrorsSAP.ToArray(),
                MandateReference = "",
                MandateReferenceOld = "",
                Network = "",
                PartnerExternalSystem = "",
                PayType = "",
                Policy = "",
                SignCity = "",
                SignDate = "",
                SndBic = "",
                SndIban = "",
                StartDateFrom = "",
                StartDateTo = "",
                Status = ""
            };

            var _arraymandates = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha>
            {
                _mandates
            };

            var _mandate = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatosLinha
            {
                Interface = "",
                ItemsTotal = "",
                Mandate = _arraymandates.ToArray(),
                Online = "",
                OriginalSystem = "",
                SystemDate = "",
                SystemTime = "",
                Transaction = ""
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWs()
            {
                MandatesReference = _mandate
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 200 
            response.StatusCode.Equals(200);

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Mandates/Mandate")]
        public async Task TestPostMandate002Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandate
            {
                ErrorCode = "?",
                ErrorCodeTxt = "?"
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandate>
            {
                _codeErroLineSAP
            };

            var _mandates = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha()
            {
                CompanyCode = "?",
                Description = "?",
                Errors = _arrayErrorsSAP.ToArray(),
                MandateReference = "?",
                MandateReferenceOld = "?",
                Network = "?",
                PartnerExternalSystem = "?",
                PayType = "?",
                Policy = "?",
                SignCity = "?",
                SignDate = "?",
                SndBic = "?",
                SndIban = "?",
                StartDateFrom = "?",
                StartDateTo = "?",
                Status = "?"
            };

            var _arraymandates = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha>
            {
                _mandates
            };

            var _mandate = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatosLinha
            {
                Interface = "?",
                ItemsTotal = "?",
                Mandate = _arraymandates.ToArray(),
                Online = "?",
                OriginalSystem = "?",
                SystemDate = "?",
                SystemTime = "?",
                Transaction = "?"
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWs()
            {
                MandatesReference = _mandate
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);

        }

        [Theory]
        [InlineData("/v1/Mandates/Mandate")]
        public async Task TestPostMandate003Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandate
            {
                ErrorCode = "string",
                ErrorCodeTxt = "string"
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandate>
            {
                _codeErroLineSAP
            };

            var _mandates = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha()
            {
                CompanyCode = "string",
                Description = "string",
                Errors = _arrayErrorsSAP.ToArray(),
                MandateReference = "string",
                MandateReferenceOld = "string",
                Network = "string",
                PartnerExternalSystem = "string",
                PayType = "string",
                Policy = "string",
                SignCity = "string",
                SignDate = "string",
                SndBic = "string",
                SndIban = "string",
                StartDateFrom = "string",
                StartDateTo = "string",
                Status = "string"
            };

            var _arraymandates = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha>
            {
                _mandates
            };

            var _mandate = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatosLinha
            {
                Interface = "string",
                ItemsTotal = "string",
                Mandate = _arraymandates.ToArray(),
                Online = "string",
                OriginalSystem = "string",
                SystemDate = "string",
                SystemTime = "string",
                Transaction = "string"
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWs()
            {
                MandatesReference = _mandate
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);

        }

        [Theory]
        [InlineData("/v1/Mandates/Mandate")]
        public async Task TestPostMandate004Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandate
            {
                ErrorCode = null,
                ErrorCodeTxt = null
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandate>
            {
                _codeErroLineSAP
            };

            var _mandates = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha()
            {
                CompanyCode = null,
                Description = null,
                Errors = _arrayErrorsSAP.ToArray(),
                MandateReference = null,
                MandateReferenceOld = null,
                Network = null,
                PartnerExternalSystem = null,
                PayType = null,
                Policy = null,
                SignCity = null,
                SignDate = null,
                SndBic = null,
                SndIban = null,
                StartDateFrom = null,
                StartDateTo = null,
                Status = null
            };

            var _arraymandates = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha>
            {
                _mandates
            };

            var _mandate = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatosLinha
            {
                Interface = null,
                ItemsTotal = null,
                Mandate = _arraymandates.ToArray(),
                Online = null,
                OriginalSystem = null,
                SystemDate = null,
                SystemTime = null,
                Transaction = null
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWs()
            {
                MandatesReference = _mandate
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));
            // Assert - 200 
            response.StatusCode.Equals(200);

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);

        }

        [Theory]
        [InlineData("/v1/Mandates/Mandate")]
        public async Task TestPostMandate005Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandate
            {
                ErrorCode = null,
                ErrorCodeTxt = null
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdCodigosErroLinhaMandate>
            {
                _codeErroLineSAP
            };

            var _mandates = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha()
            {
                CompanyCode = null,
                Description = null,
                Errors = null, //_arrayErrorsSAP.ToArray(),
                MandateReference = null,
                MandateReferenceOld = null,
                Network = null,
                PartnerExternalSystem = null,
                PayType = null,
                Policy = null,
                SignCity = null,
                SignDate = null,
                SndBic = null,
                SndIban = null,
                StartDateFrom = null,
                StartDateTo = null,
                Status = null
            };

            var _arraymandates = new List<INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatoLinha>
            {
                _mandates
            };

            var _mandate = new INS.PT.WebAPI.Model.Partners.Mandate.ZfscdMandatosLinha
            {
                Interface = null,
                ItemsTotal = null,
                Mandate = null, //_arraymandates.ToArray(),
                Online = null,
                OriginalSystem = null,
                SystemDate = null,
                SystemTime = null,
                Transaction = null
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Mandate.ZFscdMandatosPostWs()
            {
                MandatesReference = _mandate
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));
            // Assert - 200 
            response.StatusCode.Equals(200);

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);

        }

    }
}

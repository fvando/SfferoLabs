﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.ScenariosCharged
{
    public class ChargedControllerIntegrationTests
    {
        private readonly ContextApi _testContextApi;
       
        public ChargedControllerIntegrationTests()
        {
            _testContextApi = new ContextApi();
        }

        [Theory]
        [InlineData("/v1/Charges/Charged")]
        public async Task TestPostCharged001Async(string uri)
        {
            //Arrange
            var request = new
            {
                Body = new
                {
                    ReceiptsCollected = new INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradosLinha()
                    {
                        Collect = null,  
                        DestinySystem = "",
                        Interface = "",
                        ItemsTotal = "",
                        Online = "",
                        SystemDate = "",
                        SystemTime = "",
                        Transaction = ""
                    }
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 200 
            response.StatusCode.Equals(200);

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Charges/Charged")]
        public async Task TestPostCharged002Async(string uri)
        {
            //Arrange
            var request = new
            {
                Body = new
                {
                    ReceiptsCollected = new INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradosLinha()
                    {
                        Collect = null,  
                        DestinySystem = "?",
                        Interface = "?",
                        ItemsTotal = "?",
                        Online = "?",
                        SystemDate = "?",
                        SystemTime = "?",
                        Transaction = "?"
                    }
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Charges/Charged")]
        public async Task TestPostCharged003Async(string uri)
        {
            DateTime max = DateTime.MaxValue;
            //Arrange
            var request = new
            {
                Body = new
                {
                    ReceiptsCollected = new INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradosLinha()
                    {
                        Collect = null, //_arraypcCobradoLinha.ToArray(),
                        DestinySystem = "?",
                        Interface = "?",
                        ItemsTotal = "?",
                        Online = "?",
                        SystemDate = max.ToString(),
                        SystemTime = "?",
                        Transaction = "?"
                    }
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }


        [Theory]
        [InlineData("/v1/Charges/Charged")]
        public async Task TestPostCharged004Async(string uri)
        {
            DateTime min = DateTime.MinValue;
            //Arrange
            var request = new
            {
                Body = new
                {
                    ReceiptsCollected = new INS.PT.WebAPI.Model.Partners.Charged.ZfscdCobradosLinha()
                    {
                        Collect = null, //_arraypcCobradoLinha.ToArray(),
                        DestinySystem = "?",
                        Interface = "?",
                        ItemsTotal = "?",
                        Online = "?",
                        SystemDate = min.ToString(),
                        SystemTime = "?",
                        Transaction = "?"
                    }
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }
    }
}

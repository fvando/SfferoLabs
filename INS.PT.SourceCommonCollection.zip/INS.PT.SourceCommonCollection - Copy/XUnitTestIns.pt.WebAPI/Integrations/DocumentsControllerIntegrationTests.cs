﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.ScenariosDocuments
{
    public class DocumentsControllerIntegrationTests
    {
        private readonly ContextApi _testContextApi;
       
        public DocumentsControllerIntegrationTests()
        {
            _testContextApi = new ContextApi();
        }

        [Theory]
        [InlineData("/v1/Documents/Document")]
        public async Task TestPostDocuments001Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdCodigosErroLinhaDocuments
            {
                ErrorCode = "",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdCodigosErroLinhaDocuments>
            {
                _codeErroLineSAP
            };

            var _address = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress
            {
                City = "",
                Country = "",
                LastName = "",
                Location = "",
                FirstName = "",
                PostCode = "",
                Street = "",
                StreetComplement = ""
            };


            var _details = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress
            {
                City = "",
                Country = "",
                LastName = "",
                Location = "",
                FirstName = "",
                PostCode = "",
                Street = "",
                StreetComplement = ""
            };

            var _arrayAddress = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress>
            {
                _address
            };


            var _documentoLinha = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoLinha()
            {
                Address = _address,
                CompanyCode = "",
                Details = null,
                Header = null,
                ReferenceDocumentNumber = "",
                Errors = _arrayErrorsSAP.ToArray()
            };

            var _arrayAnulado = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoLinha>
            {
                _documentoLinha
            };
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWs()
            {
                Documents = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentosLinha()
                {

                    Document = _arrayAnulado.ToArray(),
                    Interface = "",
                    ItemsTotal = "",
                    Online = "",
                    OriginalSystem = "",
                    SystemDate = "",
                    SystemTime = "",
                    Transaction = ""

                }

            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 200 
            response.StatusCode.Equals(200);

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Documents/Document")]
        public async Task TestPostDocuments002Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdCodigosErroLinhaDocuments
            {
                ErrorCode = "998",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdCodigosErroLinhaDocuments>
            {
                _codeErroLineSAP
            };

            var _address = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress
            {
                City = "",
                Country = "",
                LastName = "",
                Location = "",
                FirstName = "",
                PostCode = "",
                Street = "",
                StreetComplement = ""
            };


            var _details = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress
            {
                City = "",
                Country = "",
                LastName = "",
                Location = "",
                FirstName = "",
                PostCode = "",
                Street = "",
                StreetComplement = ""
            };

            var _arrayAddress = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress>
            {
                _address
            };


            var _documentoLinha = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoLinha()
            {
                Address = _address,
                CompanyCode = "",
                Details = null,
                Header = null,
                ReferenceDocumentNumber = "",
                Errors = _arrayErrorsSAP.ToArray()
            };

            var _arrayAnulado = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoLinha>
            {
                _documentoLinha
            };
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWs()
            {
                Documents = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentosLinha()
                {

                    Document = _arrayAnulado.ToArray(),
                    Interface = "",
                    ItemsTotal = "",
                    Online = "",
                    OriginalSystem = "",
                    SystemDate = "",
                    SystemTime = "",
                    Transaction = ""

                }

            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 200
            response.StatusCode.Equals(404);
        }

        [Theory]
        [InlineData("/v1/Documents/Document")]
        public async Task TestPostDocuments003Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdCodigosErroLinhaDocuments
            {
                ErrorCode = "998",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdCodigosErroLinhaDocuments>
            {
                _codeErroLineSAP
            };

            var _address = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress
            {
                City = "",
                Country = "",
                LastName = "",
                Location = "",
                FirstName = "",
                PostCode = "",
                Street = "",
                StreetComplement = ""
            };


            var _details = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress
            {
                City = "",
                Country = "",
                LastName = "",
                Location = "",
                FirstName = "",
                PostCode = "",
                Street = "",
                StreetComplement = ""
            };

            var _arrayAddress = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress>
            {
                _address
            };


            var _documentoLinha = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoLinha()
            {
                Address = _address,
                CompanyCode = "",
                Details = null,
                Header = null,
                ReferenceDocumentNumber = "",
                Errors = _arrayErrorsSAP.ToArray()
            };

            var _arrayAnulado = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoLinha>
            {
                _documentoLinha
            };
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWs()
            {
                Documents = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentosLinha()
                {

                    Document = _arrayAnulado.ToArray(),
                    Interface = "",
                    ItemsTotal = "",
                    Online = "",
                    OriginalSystem = "",
                    SystemDate = "",
                    SystemTime = "",
                    Transaction = ""

                }

            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400
            response.StatusCode.Equals(400);
        }

        [Theory]
        [InlineData("/v1/Documents/Document")]
        public async Task TestPostDocuments004Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdCodigosErroLinhaDocuments
            {
                ErrorCode = "998",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdCodigosErroLinhaDocuments>
            {
                _codeErroLineSAP
            };

            var _address = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress
            {
                City = "",
                Country = "",
                LastName = "",
                Location = "",
                FirstName = "",
                PostCode = "",
                Street = "",
                StreetComplement = ""
            };


            var _details = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress
            {
                City = "",
                Country = "",
                LastName = "",
                Location = "",
                FirstName = "",
                PostCode = "",
                Street = "",
                StreetComplement = ""
            };

            var _arrayAddress = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress>
            {
                _address
            };


            var _documentoLinha = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoLinha()
            {
                Address = _address,
                CompanyCode = "",
                Details = null,
                Header = null,
                ReferenceDocumentNumber = "",
                Errors = _arrayErrorsSAP.ToArray()
            };

            var _arrayAnulado = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoLinha>
            {
                _documentoLinha
            };
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWs()
            {
                Documents = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentosLinha()
                {

                    Document = _arrayAnulado.ToArray(),
                    Interface = "",
                    ItemsTotal = "",
                    Online = "",
                    OriginalSystem = "",
                    SystemDate = "",
                    SystemTime = "",
                    Transaction = ""

                }

            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400
            response.StatusCode.Equals(400);
        }

        [Theory]
        [InlineData("/v1/Documents/Document")]
        public async Task TestPostDocuments005Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdCodigosErroLinhaDocuments
            {
                ErrorCode = "998",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdCodigosErroLinhaDocuments>
            {
                _codeErroLineSAP
            };

            var _address = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress
            {
                City = "",
                Country = "",
                LastName = "",
                Location = "",
                FirstName = "",
                PostCode = "",
                Street = "",
                StreetComplement = ""
            };


            var _details = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress
            {
                City = "",
                Country = "",
                LastName = "",
                Location = "",
                FirstName = "",
                PostCode = "",
                Street = "",
                StreetComplement = ""
            };

            var _arrayAddress = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress>
            {
                _address
            };


            var _documentoLinha = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoLinha()
            {
                Address = _address,
                CompanyCode = "",
                Details = null,
                Header = null,
                ReferenceDocumentNumber = "",
                Errors = _arrayErrorsSAP.ToArray()
            };

            var _arrayAnulado = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoLinha>
            {
                _documentoLinha
            };
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWs()
            {
                Documents = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentosLinha()
                {

                    Document = _arrayAnulado.ToArray(),
                    Interface = "",
                    ItemsTotal = "",
                    Online = "",
                    OriginalSystem = "",
                    SystemDate = "",
                    SystemTime = "",
                    Transaction = ""

                }

            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400
            response.StatusCode.Equals(400);
        }

        [Theory]
        [InlineData("/v1/Documents/Document")]
        public async Task TestPostDocuments006Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdCodigosErroLinhaDocuments
            {
                ErrorCode = "998",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdCodigosErroLinhaDocuments>
            {
                _codeErroLineSAP
            };

            var _address = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress
            {
                City = "",
                Country = "",
                LastName = "",
                Location = "",
                FirstName = "",
                PostCode = "",
                Street = "",
                StreetComplement = ""
            };


            var _details = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress
            {
                City = "",
                Country = "",
                LastName = "",
                Location = "",
                FirstName = "",
                PostCode = "",
                Street = "",
                StreetComplement = ""
            };

            var _arrayAddress = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoAddress>
            {
                _address
            };


            var _documentoLinha = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoLinha()
            {
                Address = _address,
                CompanyCode = "",
                Details = null,
                Header = null,
                ReferenceDocumentNumber = "",
                Errors = _arrayErrorsSAP.ToArray()
            };

            var _arrayAnulado = new List<INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentoLinha>
            {
                _documentoLinha
            };
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Documents.ZFscdDocumentosPostWs()
            {
                Documents = new INS.PT.WebAPI.Model.Partners.Documents.ZfscdDocumentosLinha()
                {

                    Document = _arrayAnulado.ToArray(),
                    Interface = "",
                    ItemsTotal = "",
                    Online = "",
                    OriginalSystem = "",
                    SystemDate = "",
                    SystemTime = "",
                    Transaction = ""

                }

            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };
            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request));

            // Assert - 400
            response.StatusCode.Equals(400);
        }

    }
}

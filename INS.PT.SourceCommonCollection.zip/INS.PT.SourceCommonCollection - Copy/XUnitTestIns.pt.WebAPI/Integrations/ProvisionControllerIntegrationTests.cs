﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.ScenariosProvision
{
    public class ProvisionControllerIntegrationTests
    {
        private readonly ContextApi _testContextApi;
       
        public ProvisionControllerIntegrationTests()
        {
            _testContextApi = new ContextApi();
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostQueryAsync")]
        public async Task TestPostQuery001Async(string uri)
        {
            //Arrange
            var request = new
            {
                Body = new
                {
                    BrokerContract = "?",
                    BrokerReportIdentification = "?"
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostQueryAsync")]
        public async Task TestPostQuery002Async(string uri)
        {
            //Arrange
            var request = new
            {
                Body = new
                {
                    BrokerContract = "?",
                    BrokerReportIdentification = "?"
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 200
            response.StatusCode.Equals(404);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostQueryAsync")]
        public async Task TestPostQuery003Async(string uri)
        {
            //Arrange
            var request = new
            {
                Body = new
                {
                    BrokerContract = "?"
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400
            response.StatusCode.Equals(400);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostQueryAsync")]
        public async Task TestPostQuery004Async(string uri)
        {
            //Arrange
            var request = new
            {
                Body = new
                {
                    BrokerContract = "ABABABABABABABABABABXX",
                    BrokerReportIdentification = "ABABABABABABABAXXXXX"
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400
            response.StatusCode.Equals(400);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostQueryAsync")]
        public async Task TestPostQuery005Async(string uri)
        {
            //Arrange
            var request = new
            {
                Body = new
                {
                   
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400
            response.StatusCode.Equals(400);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostQueryAsync")]
        public async Task TestPostQuery006Async(string uri)
        {
            //Arrange
            var request = new
            {
               
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request));

            // Assert - 400
            response.StatusCode.Equals(400);
        }


        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostChargeAsync")]
        public async Task TestPostCharged001Async(string uri)
        {

            //Object IN
            var _pcRecibosWsModel = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha()
            {
                Amount = 0,
                Broker = "",
                BrokerContract = "",
                CompanyCode = "",
                Currency = "",
                DocumentNumber = "",
                DocumentType = "",
                InsuranceObject = "",
                Partner = "",
                ReferenceDocumentNumber = "",
                SapDocumentNumber = ""
            };

            var _arraypcRecibosWsModel = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>
            {
                _pcRecibosWsModel
            };


            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "",
                    PcRecibos = _arraypcRecibosWsModel.ToArray(),
                    Testrun = ""
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostChargeAsync")]
        public async Task TestPostCharged002Async(string uri)
        {

            //Object IN
            var _pcRecibosWsModel = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha()
            {

                Amount = 0,
                Broker = "",
                BrokerContract = "",
                CompanyCode = "",
                Currency = "",
                DocumentNumber = "",
                DocumentType = "",
                InsuranceObject = "",
                Partner = "",
                ReferenceDocumentNumber = "",
                SapDocumentNumber = ""
            };

            var _arraypcRecibosWsModel = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>
            {
                _pcRecibosWsModel
            };


            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "?",
                    PcRecibos = "?", //_arraypcRecibosWsModel.ToArray(),
                    Testrun = "?"
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }


        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostChargeAsync")]
        public async Task TestPostCharged003Async(string uri)
        {

            //Object IN
            var _pcRecibosWsModel = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha()
            {

                Amount = 0,
                Broker = "",
                BrokerContract = "",
                CompanyCode = "",
                Currency = "",
                DocumentNumber = "",
                DocumentType = "",
                InsuranceObject = "",
                Partner = "",
                ReferenceDocumentNumber = "",
                SapDocumentNumber = ""
            };

            var _arraypcRecibosWsModel = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>
            {
                _pcRecibosWsModel
            };


            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "" //,
                    //PcRecibos = _arraypcRecibosWsModel.ToArray(),
                    //Testrun = ""
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }


        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostChargeAsync")]
        public async Task TestPostCharged004Async(string uri)
        {

            //Object IN
            var _pcRecibosWsModel = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha()
            {
                Amount = 0,
                Broker = "",
                BrokerContract = "",
                CompanyCode = "",
                Currency = "",
                DocumentNumber = "",
                DocumentType = "",
                InsuranceObject = "",
                Partner = "",
                ReferenceDocumentNumber = "",
                SapDocumentNumber = ""
            };

            var _arraypcRecibosWsModel = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>
            {
                _pcRecibosWsModel
            };


            //Arrange
            var request = new
            {
                Body = new
                {
                   // Broobj = "",
                   // PcRecibos = _arraypcRecibosWsModel.ToArray(),
                    Testrun = ""
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }


        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostChargeAsync")]
        public async Task TestPostCharged005Async(string uri)
        {

            //Object IN
            var _pcRecibosWsModel = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha()
            {
                Amount = 0,
                Broker = "",
                BrokerContract = "",
                CompanyCode = "",
                Currency = "",
                DocumentNumber = "",
                DocumentType = "",
                InsuranceObject = "",
                Partner = "",
                ReferenceDocumentNumber = "",
                SapDocumentNumber = ""
            };

            var _arraypcRecibosWsModel = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>
            {
                _pcRecibosWsModel
            };


            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
                    PcRecibos = _arraypcRecibosWsModel.ToArray(),
                    Testrun = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostChargeAsync")]
        public async Task TestPostCharged006Async(string uri)
        {

            //Object IN
            var _pcRecibosWsModel = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha()
            {
                Amount = 0,
                Broker = "",
                BrokerContract = "",
                CompanyCode = "",
                Currency = "",
                DocumentNumber = "",
                DocumentType = "",
                InsuranceObject = "",
                Partner = "",
                ReferenceDocumentNumber = "",
                SapDocumentNumber = ""
            };

            var _arraypcRecibosWsModel = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>
            {
                _pcRecibosWsModel
            };


            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "string",
                    PcRecibos = _arraypcRecibosWsModel.ToArray(),
                    Testrun = "string"
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostLiquidateAsync")]
        public async Task TestPostLiquidate001Async(string uri)
        {

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "",
                    Ident = "",
                    Testrun = ""
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostLiquidateAsync")]
        public async Task TestPostLiquidate002Async(string uri)
        {

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "",
                    Ident = "" //,
                   // Testrun = ""
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostLiquidateAsync")]
        public async Task TestPostLiquidate003Async(string uri)
        {

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "",
                    //Ident = "" //,
                               // Testrun = ""
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostLiquidateAsync")]
        public async Task TestPostLiquidate004Async(string uri)
        {

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "",
                   // Ident = "" //,
                               // Testrun = ""
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostLiquidateAsync")]
        public async Task TestPostLiquidate005Async(string uri)
        {

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                    //Broobj = "",
                    Ident = "" //,
                               // Testrun = ""
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostLiquidateAsync")]
        public async Task TestPostLiquidate006Async(string uri)
        {

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "?",
                    Ident = "?" ,
                                Testrun = "?"
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostListAsync")]
        public async Task TestPostList001Async(string uri)
        {
            //Object IN
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "",
                    Fim = "",
                    Inicio = max.ToString(),
                    Status = max.ToString()
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostListAsync")]
        public async Task TestPostList002Async(string uri)
        {
            //Object IN
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "",
                    Fim = "",
                    Inicio = min.ToString(),
                    Status = min.ToString()
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostListAsync")]
        public async Task TestPostList003Async(string uri)
        {
            //Object IN
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "",
                    Fim = "",
                    Inicio = min.ToString(),
                    Status = max.ToString()
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostListAsync")]
        public async Task TestPostList004Async(string uri)
        {
            //Object IN
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "",
                    Fim = "",
                    Inicio = max.ToString(),
                    Status = min.ToString()
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostListAsync")]
        public async Task TestPostList005Async(string uri)
        {
            //Object IN
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "",
                    Fim = "" //,
                   // Inicio = max.ToString(),
                   // Status = max.ToString()
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostListAsync")]
        public async Task TestPostList006Async(string uri)
        {
            //Object IN
            DateTime max = DateTime.MaxValue;
            DateTime min = DateTime.MinValue;

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                   //Broobj = "",
                   // Fim = "",
                    Inicio = max.ToString(),
                    Status = max.ToString()
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostValidateAsync")]
        public async Task TestPostValidate001Async(string uri)
        {

            //Object IN
            var _pcRecibosWsModel = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha()
            {

                Amount = 0,
                Broker = "",
                BrokerContract = "",
                CompanyCode = "",
                Currency = "",
                DocumentNumber = "",
                DocumentType = "",
                InsuranceObject = "",
                Partner = "",
                ReferenceDocumentNumber = "",
                SapDocumentNumber = ""
            };

            var _arraypcRecibosWsModel = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>
            {
                _pcRecibosWsModel
            };

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "",
                    PcRecibos = _arraypcRecibosWsModel.ToArray()
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostValidateAsync")]
        public async Task TestPostValidate002Async(string uri)
        {

            //Object IN
            var _pcRecibosWsModel = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha()
            {

                Amount = 0,
                Broker = "",
                BrokerContract = "",
                CompanyCode = "",
                Currency = "",
                DocumentNumber = "",
                DocumentType = "",
                InsuranceObject = "",
                Partner = "",
                ReferenceDocumentNumber = "",
                SapDocumentNumber = ""
            };

            var _arraypcRecibosWsModel = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>
            {
                _pcRecibosWsModel
            };

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = ""//,
                    //PcRecibos = _arraypcRecibosWsModel.ToArray()
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostValidateAsync")]
        public async Task TestPostValidate003Async(string uri)
        {

            //Object IN
            var _pcRecibosWsModel = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha()
            {

                Amount = 0,
                Broker = "",
                BrokerContract = "",
                CompanyCode = "",
                Currency = "",
                DocumentNumber = "",
                DocumentType = "",
                InsuranceObject = "",
                Partner = "",
                ReferenceDocumentNumber = "",
                SapDocumentNumber = ""
            };

            var _arraypcRecibosWsModel = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>
            {
                _pcRecibosWsModel
            };

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                    //Broobj = ""//,
                    PcRecibos = _arraypcRecibosWsModel.ToArray()
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }


        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostValidateAsync")]
        public async Task TestPostValidate004Async(string uri)
        {

            //Object IN
            var _pcRecibosWsModel = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha()
            {
                Amount = 0,
                Broker = "",
                BrokerContract = "",
                CompanyCode = "",
                Currency = "",
                DocumentNumber = "",
                DocumentType = "",
                InsuranceObject = "",
                Partner = "",
                ReferenceDocumentNumber = "",
                SapDocumentNumber = ""
            };

            var _arraypcRecibosWsModel = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>
            {
                _pcRecibosWsModel
            };

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "?",
                    PcRecibos = _arraypcRecibosWsModel.ToArray()
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/ProvisionWebAccount/PostValidateAsync")]
        public async Task TestPostValidate005Async(string uri)
        {

            //Object IN
            var _pcRecibosWsModel = new INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha()
            {
                Amount = 0,
                Broker = "",
                BrokerContract = "",
                CompanyCode = "",
                Currency = "",
                DocumentNumber = "",
                DocumentType = "",
                InsuranceObject = "",
                Partner = "",
                ReferenceDocumentNumber = "",
                SapDocumentNumber = ""
            };

            var _arraypcRecibosWsModel = new List<INS.PT.WebAPI.Model.Partners.ProvisionWebAccount.ZfscdPcRecibosLinha>
            {
                _pcRecibosWsModel
            };

            //Object IN
            //Arrange
            var request = new
            {
                Body = new
                {
                    Broobj = "?",
                    PcRecibos = "?"
                }
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.ScenariosCancel
{
    public class CancelControllerIntegrationTests
    {
        private readonly ContextApi _testContextApi;
       
        public CancelControllerIntegrationTests()
        {
            _testContextApi = new ContextApi();
        }

        [Theory]
        [InlineData("/v1/Cancellations/Policy")]
        public async Task TestPostCancel001Async(string uri)
        {
            DateTime max = DateTime.MaxValue;
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel
            {
                ErrorCode = "",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel>
            {
                _codeErroLineSAP
            };

            var _Anulado = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha
            {
                CompanyCode = "",
                OperationDate = max.ToString(),
                Network = "",
                Operation = "",
                Policy = "",
                ReferenceDocumentNumber = "",
                Errors = _arrayErrorsSAP.ToArray()
            };

            var _arrayAnulado = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha>
            {
                _Anulado
            };
            //Object IN

            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWs()
            {
                Policies = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha()
                {
                    Annulled = _arrayAnulado.ToArray(),
                    Interface = "",
                    ItemsTotal = "",
                    Online = "",
                    OriginalSystem = "",
                    SystemDate = max.ToString(),
                    SystemTime = "",
                    Transaction = ""
                }
            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Cancellations/Policy")]
        public async Task TestPostCancel002Async(string uri)
        {
            DateTime min = DateTime.MinValue;

            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel
            {
                ErrorCode = "998",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel>
            {
                _codeErroLineSAP
            };

            var _Anulado = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha
            {
                CompanyCode = "",
                OperationDate = min.ToString(),
                Network = "",
                Operation = "",
                Policy = "",
                ReferenceDocumentNumber = "",
                Errors = _arrayErrorsSAP.ToArray()
            };

            var _arrayAnulado = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha>
            {
                _Anulado
            };
            //Object IN


            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWs()
            {
                Policies = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha()
                {
                    Annulled = _arrayAnulado.ToArray(),
                    Interface = "",
                    ItemsTotal = "",
                    Online = "",
                    OriginalSystem = "",
                    SystemDate = min.ToString(),
                    SystemTime = "",
                    Transaction = ""
                }
            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 200
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Cancellations/Policy")]
        public async Task TestPostCancel003Async(string uri)
        {
         
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWs()
            {
                Policies = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha()
                {
                    Annulled = null,  
                    Interface = "",
                    ItemsTotal = "",
                    Online = "",
                    OriginalSystem = "",
                    SystemDate = "",
                    SystemTime = "",
                    Transaction = ""
                }
            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 200
            response.StatusCode.Equals(200);

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Cancellations/Policy")]
        public async Task TestPostCancel004Async(string uri)
        {
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel
            {
                ErrorCode = "998",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel>
            {
                _codeErroLineSAP
            };

            var _Anulado = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha
            {
     
                Errors = _arrayErrorsSAP.ToArray()
            };

            var _arrayAnulado = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha>
            {
                _Anulado
            };
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWs()
            {
                Policies = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha()
                {
                    Annulled = _arrayAnulado.ToArray() 
                 
                }
            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 200
            response.StatusCode.Equals(200);

          
            //without return object
            Assert.Equal("OK", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Cancellations/Policy")]
        public async Task TestPostCancel005Async(string uri)
        {
          
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWs()
            {
                Policies = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha()
                {
                   
                    Interface = "",
                    ItemsTotal = "",
                    Online = "",
                    OriginalSystem = "",
                    SystemDate = "",
                    SystemTime = "",
                    Transaction = ""
                }
            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400
            response.StatusCode.Equals(200);

        
            //without return object
            Assert.Equal("OK", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Cancellations/Policy")]
        public async Task TestPostCancel006Async(string uri)
        {
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel
            {
                ErrorCode = "998",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel>
            {
                _codeErroLineSAP
            };

            var _Anulado = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha
            {
                CompanyCode = "?",
                OperationDate = "?",
                Network = "?",
                Operation = "?",
                Policy = "?",
                ReferenceDocumentNumber = "?",
                Errors = _arrayErrorsSAP.ToArray()
            };

            var _arrayAnulado = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha>
            {
                _Anulado
            };
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularApolicesPostWs()
            {
                Policies = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha()
                {
                    Annulled = _arrayAnulado.ToArray(),
                    Interface = "?",
                    ItemsTotal = "?",
                    Online = "?",
                    OriginalSystem = "?",
                    SystemDate = "?",
                    SystemTime = "?",
                    Transaction = "?"
                }
            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };
            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request));

            // Assert - 400
            response.StatusCode.Equals(404);
         

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Cancellations/Receipt")]
        public async Task TestPostReceipt001Async(string uri)
        {

            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel
            {
                ErrorCode = "",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel>
            {
                _codeErroLineSAP
            };

            var _Anulado = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha
            {
                CompanyCode = "",
                OperationDate = "",
                Network = "",
                Operation = "",
                Policy = "",
                ReferenceDocumentNumber = "",
                Errors = _arrayErrorsSAP.ToArray()
            };

            var _arrayAnulado = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha>
            {
                _Anulado
            };
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWs()
            {

                Receipts = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha()
                {
                    Annulled = _arrayAnulado.ToArray(),
                    Interface = "?",
                    ItemsTotal = "?",
                    Online = "?",
                    OriginalSystem = "?",
                    SystemDate = "?",
                    SystemTime = "?",
                    Transaction = "?"
                }
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Cancellations/Receipt")]
        public async Task TestPostReceipt002Async(string uri)
        {
            DateTime min = DateTime.MinValue;
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel
            {
                ErrorCode = "998",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel>
            {
                _codeErroLineSAP
            };

            var _Anulado = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha
            {
                CompanyCode = "",
                OperationDate = min.ToString(),
                Network = "",
                Operation = "",
                Policy = "",
                ReferenceDocumentNumber = "",
                Errors = _arrayErrorsSAP.ToArray()
            };

            var _arrayAnulado = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha>
            {
                _Anulado
            };
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWs()
            {

                Receipts = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha()
                {
                    Annulled = _arrayAnulado.ToArray(),
                    Interface = "",
                    ItemsTotal = "",
                    Online = "",
                    OriginalSystem = "",
                    SystemDate = min.ToString(),
                    SystemTime = "",
                    Transaction = ""
                }
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }


        [Theory]
        [InlineData("/v1/Cancellations/Receipt")]
        public async Task TestPostReceipt003Async(string uri)
        {
            DateTime max = DateTime.MaxValue;
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel
            {
                ErrorCode = "",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel>
            {
                _codeErroLineSAP
            };

            var _Anulado = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha
            {
                CompanyCode = "",
                OperationDate = max.ToString(),
                Network = "",
                Operation = "",
                Policy = "",
                ReferenceDocumentNumber = "",
                Errors = _arrayErrorsSAP.ToArray()
            };

            var _arrayAnulado = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha>
            {
                _Anulado
            };
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWs()
            {

                Receipts = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha()
                {
                    Annulled = _arrayAnulado.ToArray(),
                    Interface = "",
                    ItemsTotal = "",
                    Online = "",
                    OriginalSystem = "",
                    SystemDate = max.ToString(),
                    SystemTime = "",
                    Transaction = ""
                }
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };
            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }


        [Theory]
        [InlineData("/v1/Cancellations/Receipt")]
        public async Task TestPostReceipt004Async(string uri)
        {
    
 
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWs()
            {

                Receipts = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha()
                {
                    Annulled = null, 
                    Interface = "",
                    ItemsTotal = "",
                    Online = "",
                    OriginalSystem = "",
                    SystemDate = "",
                    SystemTime = "",
                    Transaction = ""
                }
            };
            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };
            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 200 
            response.StatusCode.Equals(200);

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);
        }


        [Theory]
        [InlineData("/v1/Cancellations/Receipt")]
        public async Task TestPostReceipt005Async(string uri)
        {

            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel
            {
                ErrorCode = "",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel>
            {
                _codeErroLineSAP
            };

            var _Anulado = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha
            {
                //CompanyCode = "",
                //SystemDate = "",
                //Network = "",
                //Operation = "",
                //Policy = "",
                //ReferenceDocumentNumber = "",
                Errors = _arrayErrorsSAP.ToArray()
            };

            var _arrayAnulado = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha>
            {
                _Anulado
            };
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWs()
            {

                Receipts = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha()
                {
                    Annulled = _arrayAnulado.ToArray() //,
                    //Interface = "",
                    //ItemsTotal = "",
                    //Online = "",
                    //OriginalSystem = "",
                    //SystemDate = "",
                    //SystemTime = "",
                    //Transaction = ""
                }
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };
            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 200 
            response.StatusCode.Equals(200);

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Cancellations/Receipt")]
        public async Task TestPostReceipt006Async(string uri)
        {

            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT
            var _codeErroLineSAP = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel
            {
                ErrorCode = "",
                ErrorCodeTxt = ""
            };

            var _arrayErrorsSAP = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdCodigosErroLinhaCancel>
            {
                _codeErroLineSAP
            };

            var _Anulado = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha
            {
                CompanyCode = "",
                OperationDate = "",
                Network = "",
                Operation = "",
                Policy = "",
                ReferenceDocumentNumber = "",
                Errors = _arrayErrorsSAP.ToArray()
            };

            var _arrayAnulado = new List<INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladoLinha>
            {
                _Anulado
            };
            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Cancel.ZFscdAnularRecibosPostWs()
            {

                Receipts = new INS.PT.WebAPI.Model.Partners.Cancel.ZfscdAnuladosLinha()
                {
                    Annulled = _arrayAnulado.ToArray(),
                    Interface = "",
                    ItemsTotal = "",
                    Online = "",
                    OriginalSystem = "",
                    SystemDate = "",
                    SystemTime = "",
                    Transaction = ""
                }
            };
            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 200 
            response.StatusCode.Equals(200);

            //without return object
            Assert.Equal("OK", response.ReasonPhrase);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using XUnitTestIns.pt.WebAPI.FixtureApi;

namespace XUnitTestIns.pt.WebAPI.ScenariosEntity
{
    public class EntityControllerIntegrationTests
    {
        private readonly ContextApi _testContextApi;
       
        public EntityControllerIntegrationTests()
        {
            _testContextApi = new ContextApi();
        }

        [Theory]
        [InlineData("/v1/Entities/Partner")]
        public async Task TestPostPartner001Async(string uri)
        {
            var _erro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdCodigosErroLinhaEntity
            {
                ErrorCode = "?",
                ErrorCodeTxt = "?"
            };

            var _arrayError = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdCodigosErroLinhaEntity>
            {
                _erro
            };

            var _phones = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroTelefone()
            {
                Country = "?",
                TelDefault = "?",
                Telephone = "?"
            };
            var _arrayphone = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroTelefone>
            {
                _phones
            };


            var _address = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroMorada
            {
                AddressNotes = "?",
                AddressType = "?",
                City = "?",
                Country = "?",
                ExtAddressNumber = "?",
                HomeCity = "?",
                HouseNumber = "?",
                PostCode = "?",
                Street = "?",
                StrSuppl1 = "?",
                StrSuppl2 = "?",
                StrSuppl3 = "?"
            };

            var _banks = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroIban()
            {
                Iban = "?" 
            };
            var _arrayBanks = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroIban>
            {
                _banks
            };

            var _emails = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroEmail()
            {
                Email = "?"
            };
            var _arrayEmail = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroEmail>
            {
                _emails
            };

         
            var _arrayAddress = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroMorada>
            {
                _address
            };

            var _parceiro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha()
            {
                Addresses = _arrayAddress.ToArray(),
                Banks = _arrayBanks.ToArray(),
                BirthDate = "?",
                CommType = "?",
                CompanyCode = "?",
                EntityType = "?",
                Errors = _arrayError.ToArray(),
                FormKeyTitle = "?",
                FirstName = "?",
                LastName = "?",
                Mails = _arrayEmail.ToArray(),
                MaritalStatus = "?",
                MiddleName = "?",
                Nationality = "?",
                Network = "?",
                PartnerExternalSystem = "?",
                Phones = _arrayphone.ToArray(),
                Sex = "?",
                TaxNumber = "?",
                TaxType = "?"
            };

            var _arrayParceiro = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha>
            {
                _parceiro
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWs()
            {
                Partners = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceirosLinha()
                {
                    Interface = "?",
                    ItemsTotal = "?",
                    Online = "?",
                    OriginalSystem = "?",
                    Partner = _arrayParceiro.ToArray(),
                    SystemDate = "?",
                    SystemTime = "?",
                    Transaction = "?"
                }
            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Entities/Partner")]
        public async Task TestPostPartner002Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT

            var _erro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdCodigosErroLinhaEntity
            {
                ErrorCode = "998",
                ErrorCodeTxt = ""
            };

            var _arrayError = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdCodigosErroLinhaEntity>
            {
                _erro
            };

            var _phones = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroTelefone()
            {
                Country = "?",
                TelDefault = "?",
                Telephone = "?"
            };
            var _arrayphone = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroTelefone>
            {
                _phones
            };


            var _address = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroMorada
            {
                AddressNotes = "?",
                AddressType = "?",
                City = "?",
                Country = "?",
                ExtAddressNumber = "?",
                HomeCity = "?",
                HouseNumber = "?",
                PostCode = "?",
                Street = "?",
                StrSuppl1 = "?",
                StrSuppl2 = "?",
                StrSuppl3 = "?"
            };

            var _banks = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroIban()
            {
                Iban = "?" 
            };
            var _arrayBanks = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroIban>
            {
                _banks
            };

            var _emails = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroEmail()
            {
                Email = "?"
            };
            var _arrayEmail = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroEmail>
            {
                _emails
            };

     
            var _arrayAddress = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroMorada>
            {
                _address
            };

            var _parceiro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha()
            {
                Addresses = _arrayAddress.ToArray(),
                Banks = _arrayBanks.ToArray(),
                BirthDate = "?",
                CommType = "?",
                CompanyCode = "?",
                EntityType = "?",
                Errors = _arrayError.ToArray(),
                FormKeyTitle = "?",
                FirstName = "?",
                LastName = "",
                Mails = _arrayEmail.ToArray(),
                MaritalStatus = "?",
                MiddleName = "?",
          
                Nationality = "?",
                Network = "?",
                PartnerExternalSystem = "?",
                Phones = _arrayphone.ToArray(),
                Sex = "?",
                TaxNumber = "?",
                TaxType = "?"
            };

            var _arrayParceiro = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha>
            {
                _parceiro
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWs()
            {
                Partners = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceirosLinha()
                {
                    Interface = "?",
                    ItemsTotal = "?",
                    Online = "?",
                    OriginalSystem = "?",
                    Partner = _arrayParceiro.ToArray(),
                    SystemDate = "?",
                    SystemTime = "?",
                    Transaction = "?"
                }
            };
            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Entities/Partner")]
        public async Task TestPostPartner003Async(string uri)
        {
           var _parceiro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha()
            {
                Addresses = null, //_arrayAddress.ToArray(),
                Banks = null, //_arrayBanks.ToArray(),
                BirthDate = "?",
                CommType = "?",
                CompanyCode = "?",
                EntityType = "?",
                Errors = null, //_arrayError.ToArray(),
                FormKeyTitle = "?",
                FirstName = "?",
                LastName = "",
                Mails = null, //_arrayEmail.ToArray(),
                MaritalStatus = "?",
                MiddleName = "?",
             
                Nationality = "?",
                Network = "?",
                PartnerExternalSystem = "?",
                Phones = null, //_arrayphone.ToArray(),
                Sex = "?",
                TaxNumber = "?",
                TaxType = "?"
            };

            var _arrayParceiro = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha>
            {
                _parceiro
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWs()
            {
                Partners = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceirosLinha()
                {
                    Interface = "?",
                    ItemsTotal = "?",
                    Online = "?",
                    OriginalSystem = "?",
                    Partner = _arrayParceiro.ToArray(),
                    SystemDate = "?",
                    SystemTime = "?",
                    Transaction = "?"
                }
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Entities/Partner")]
        public async Task TestPostPartner004Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT

            DateTime max = DateTime.MaxValue;

            var _erro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdCodigosErroLinhaEntity
            {
                ErrorCode = "998",
                ErrorCodeTxt = ""
            };

            var _arrayError = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdCodigosErroLinhaEntity>
            {
                _erro
            };

            var _phones = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroTelefone()
            {
                Country = "?",
                TelDefault = "?",
                Telephone = "?"
            };
            var _arrayphone = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroTelefone>
            {
                _phones
            };


            var _address = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroMorada
            {
                AddressNotes = "?",
                AddressType = "?",
                City = "?",
                Country = "?",
                ExtAddressNumber = "?",
                HomeCity = "?",
                HouseNumber = "?",
                PostCode = "?",
                Street = "?",
                StrSuppl1 = "?",
                StrSuppl2 = "?",
                StrSuppl3 = "?"
            };

            var _banks = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroIban()
            {
                Iban = "?" 
            };
            var _arrayBanks = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroIban>
            {
                _banks
            };

            var _emails = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroEmail()
            {
                Email = "?"
            };
            var _arrayEmail = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroEmail>
            {
                _emails
            };

         
        
            var _arrayAddress = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroMorada>
            {
                _address
            };

            var _parceiro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha()
            {
                Addresses = _arrayAddress.ToArray(),
                Banks = _arrayBanks.ToArray(),
                BirthDate = "?",
                CommType = "?",
                CompanyCode = "?",
                EntityType = "?",
                Errors = _arrayError.ToArray(),
                FormKeyTitle = "?",
                FirstName = "?",
                LastName = "",
                Mails = _arrayEmail.ToArray(),
                MaritalStatus = "?",
                MiddleName = "?",
           
                Nationality = "?",
                Network = "?",
                PartnerExternalSystem = "?",
                Phones = _arrayphone.ToArray(),
                Sex = "?",
                TaxNumber = "?",
                TaxType = "?"
            };

            var _arrayParceiro = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha>
            {
                _parceiro
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWs()
            {
                Partners = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceirosLinha()
                {
                    Interface = "?",
                    ItemsTotal = "?",
                    Online = "?",
                    OriginalSystem = "?",
                    Partner = _arrayParceiro.ToArray(),
                    SystemDate = max.ToString(),
                    SystemTime = "?",
                    Transaction = "?"
                }
            };

            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }

        [Theory]
        [InlineData("/v1/Entities/Partner")]
        public async Task TestPostPartner005Async(string uri)
        {
            //note: In this context all the cases are up System.ServiceModel.FaultException, because the IN Object not match with correct structure
            //Object OUT

            DateTime min = DateTime.MinValue;

            var _erro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdCodigosErroLinhaEntity
            {
                ErrorCode = "998",
                ErrorCodeTxt = ""
            };

            var _arrayError = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdCodigosErroLinhaEntity>
            {
                _erro
            };

            var _phones = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroTelefone()
            {
                Country = "?",
                TelDefault = "?",
                Telephone = "?"
            };
            var _arrayphone = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroTelefone>
            {
                _phones
            };


            var _address = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroMorada
            {
                AddressNotes = "?",
                AddressType = "?",
                City = "?",
                Country = "?",
                ExtAddressNumber = "?",
                HomeCity = "?",
                HouseNumber = "?",
                PostCode = "?",
                Street = "?",
                StrSuppl1 = "?",
                StrSuppl2 = "?",
                StrSuppl3 = "?"
            };

            var _banks = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroIban()
            {
                Iban = "?" 
            };
            var _arrayBanks = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroIban>
            {
                _banks
            };

            var _emails = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroEmail()
            {
                Email = "?"
            };
            var _arrayEmail = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroEmail>
            {
                _emails
            };

        
          
            var _arrayAddress = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroMorada>
            {
                _address
            };

            var _parceiro = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha()
            {
                Addresses = _arrayAddress.ToArray(),
                Banks = _arrayBanks.ToArray(),
                BirthDate = "?",
                CommType = "?",
                CompanyCode = "?",
                EntityType = "?",
                Errors = _arrayError.ToArray(),
                FormKeyTitle = "?",
                FirstName = "?",
                LastName = "",
                Mails = _arrayEmail.ToArray(),
                MaritalStatus = "?",
                MiddleName = "?",
            
                Nationality = "?",
                Network = "?",
                PartnerExternalSystem = "?",
                Phones = _arrayphone.ToArray(),
                Sex = "?",
                TaxNumber = "?",
                TaxType = "?"
            };

            var _arrayParceiro = new List<INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceiroLinha>
            {
                _parceiro
            };

            //Object IN
            var _pcQueryWsModel = new INS.PT.WebAPI.Model.Partners.Entity.ZFscdParceirosPostWs()
            {
                Partners = new INS.PT.WebAPI.Model.Partners.Entity.ZfscdParceirosLinha()
                {
                    Interface = "?",
                    ItemsTotal = "?",
                    Online = "?",
                    OriginalSystem = "?",
                    Partner = _arrayParceiro.ToArray(),
                    SystemDate = min.ToString(),
                    SystemTime = "?",
                    Transaction = "?"
                }
            };


            //Arrange
            var request = new
            {
                Body = _pcQueryWsModel
            };

            // Act
            var response = await _testContextApi._client.PostAsync(uri, ContentHelper.GetStringContent(request.Body));

            // Assert - 400 
            response.StatusCode.Equals(404);

            //without return object
            Assert.Equal("Not Found", response.ReasonPhrase);
        }
    }
}

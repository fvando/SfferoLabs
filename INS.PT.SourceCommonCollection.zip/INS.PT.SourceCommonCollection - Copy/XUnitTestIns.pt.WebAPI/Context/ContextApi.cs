﻿
using AutoMapper;
using INS.PT.WebAPI;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Net.Http;


/// <summary>
/// 
/// </summary>
namespace XUnitTestIns.pt.WebAPI.FixtureApi
{
    public class ContextApi
    {
        public HttpClient _client { get; set; }
        public TestServer _server { get; set; }
        public IConfiguration _configuration { get; set; }

        public ContextApi()
        {
            InitializeConfigurations();
            SetupClient();
        }
        private void InitializeConfigurations()
        {
            _configuration = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", optional: true)
                .AddUserSecrets("2faa9e88-65b7-42ce-85f9-7a013f0b2f16")
                .AddEnvironmentVariables()
                .Build();
        }
        private void SetupClient()
        {
            _server = new TestServer(new WebHostBuilder()
                .ConfigureAppConfiguration((appConfiguration) =>
                {
                    appConfiguration.AddConfiguration(_configuration);
                }
                ).UseStartup<Startup>());

            _client = _server.CreateClient();
            _client.BaseAddress = _server.BaseAddress;
        }
    }
}

﻿using INS.PT.WebAPI;
using Microsoft.Extensions.Configuration;
using Moq;
using System;
using Xunit;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class DbconnectioncsTests
    {
        [Fact]
        public void DbConnections_GetConnection_InvalidConnection()
        {
            // Arrange
            var mockConfig = new Mock<IConfiguration>();
            var testObject = new Dbconnectioncs(mockConfig.Object);

            mockConfig.Setup(x => x.GetSection("ConnectionStrings").GetSection("DBConnection").Value).Returns("");

            // Act and Assert
            Assert.Throws<InvalidOperationException>(() =>
                testObject.Connection);
        }

        [Fact]
        public void DbConnections_GetConnection_ValidConnection()
        {
            // Arrange
            var mockConfig = new Mock<IConfiguration>();
            var testObject = new Dbconnectioncs(mockConfig.Object);

            mockConfig.Setup(x => x.GetSection("ConnectionStrings").GetSection("DBConnection").Value).Returns(
                "USER ID=SVNPRVECMS;PASSWORD=v5_mjhu6_kjuDtf;DATA SOURCE=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=picoas-scan.servicenp.ageas.intra)(PORT=1810)))(CONNECT_DATA=(UR=A)(SERVICE_NAME=TECPTDV.axapt.intraxa)))");

            // Act
            var result = testObject.Connection;

            // Assert
            Assert.NotNull(result);
        }
    }
}

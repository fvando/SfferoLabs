﻿using INS.PT.WebAPI;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class StartupTests
    {
        //[Fact]
        //public void SetupMappings_Create_Valid()
        //{
        //    // Arrange
        //    var serviceCollection = new ServiceCollection();

        //    // Act
        //    Startup.SetupMappings(serviceCollection);


        //    // Assert
        //    Assert.True(serviceCollection.Count > 0);
        //}

        //[Fact]
        //public void SetupRepositories_Create_Valid()
        //{
        //    // Arrange
        //    var serviceCollection = new ServiceCollection();

        //    // Act
        //    Startup.SetupRepositories(serviceCollection);

        //    // Assert
        //    Assert.True(serviceCollection.Count > 0);
        //}
    }
}

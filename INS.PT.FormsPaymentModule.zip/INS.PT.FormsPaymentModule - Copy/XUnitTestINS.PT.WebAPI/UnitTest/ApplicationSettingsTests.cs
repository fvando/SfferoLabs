﻿using INS.PT.WebAPI;
using Microsoft.Extensions.Configuration;
using Moq;
using Xunit;

namespace XUnitTestINS.PT.WebAPI.UnitTest
{
    public class ApplicationSettingsTests
    {
        private readonly Mock<IConfiguration> config;

        public ApplicationSettingsTests()
        {
            config = new Mock<IConfiguration>();
            config.Setup(x => x["ApplicationSettings:ApplicationName"]).Returns("unitTest");
            config.Setup(x => x["ApplicationSettings:ApplicationLanguage"]).Returns("unitTest");
        }

        [Fact]
        public void SetSettings_Null_NoChange()
        {
            // Arrange
            ApplicationSettings.SetSettings(config.Object);

            //Act
            ApplicationSettings.SetSettings(null);

            // Assert
            Assert.Equal("unitTest", ApplicationSettings.ApplicationName);
        }

        [Fact]
        public void SetSettings_NewConfig_Change()
        {
            // Arrange
            ApplicationSettings.SetSettings(config.Object);
            config.Setup(x => x["ApplicationSettings:ApplicationName"]).Returns("unitTestNew");
            config.Setup(x => x["ApplicationSettings:ApplicationLanguage"]).Returns("unitTestNew");

            //Act
            ApplicationSettings.SetSettings(config.Object);

            // Assert
            Assert.Equal("unitTestNew", ApplicationSettings.ApplicationName);
        }
    }
}

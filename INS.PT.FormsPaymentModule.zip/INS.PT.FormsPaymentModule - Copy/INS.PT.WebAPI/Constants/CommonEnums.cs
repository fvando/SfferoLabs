﻿using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Constants
{
    /// <summary>
    /// CommonEnums
    /// </summary>
    public class CommonEnums
    {
        /// <summary>
        /// HttpRequestVerb
        /// </summary>
        public enum HttpRequestVerb
        {
            [EnumMember]
            GET,
            [EnumMember]
            POST,
            [EnumMember]
            PUT,
            [EnumMember]
            DELETE,
            [EnumMember]
            UPDATE
        }

        /// <summary>
        /// Accepted company values
        /// </summary>
        public enum EnumCompany
        {
            //WHEN '0010' OR 'PT12' OR '1039'.       bukrs = 'Ageas vida'.
            //WHEN '0020' OR 'PT13' OR '1129'.       bukrs = 'Ageas não vida'.
            //WHEN '1023' OR 'PT16'.                 bukrs = 'Ageas não vida'.
            //WHEN '1024' OR 'PT17'.                 bukrs = 'Ageas vida'.
            //WHEN '1031' OR 'PT18'.                 bukrs = 'Ageas não vida'.

            [StringValue("0010")]
            AgeasVida,
            [StringValue("0020")]
            AgeasNaoVida
        }

        /// <summary>
        /// EnumPayments
        /// </summary>
        public enum EnumPayments
        {
            [StringValue("mbway")]
            MbWay,
            [StringValue("mbreference")]
            MbReference,
            [StringValue("chippin")]
            ChipPin,
            [StringValue("agente")]
            Agente,
            [StringValue("sepa")]
            Sepa,
            [StringValue("tesouraria")]
            Tesouraria
        }

        public enum EnumPaymentsAgentSAP
        {
            [StringValue("S")]
            SEPA,
            [StringValue("B")]
            BALCAO,
            [StringValue("M")]
            MEDIADOR
        }

        public enum EnumTypeSend
        {
            [StringValue("email")]
            email,
            [StringValue("sms")]
            sms
          
        }


        public enum EnumPaymentsWay
        {
            [StringValue("A")]
            [AmbientValue("A")]
            SEGUROS_DA_COMPANHIA,
            [StringValue("B")]
            BALCAO,
            [StringValue("D")]
            DACB_DEBITO_AUTOMATICO,
            [StringValue("E")]
            CO_SEGURO,
            [StringValue("F")]
            FUNCIONAROS,
            [StringValue("G")]
            CARTAO_DE_CREDITO,
            [StringValue("M")]
            MEDIADOR,
            [StringValue("R")]
            SEPADD_PCS,
            [StringValue("S")]
            SEPAD_PREMIOS,
            [StringValue("T")]
            CORRETOR,
            [StringValue("W")]
            DACB_DESCENT_CONVERSAO,
            [StringValue("X")]
            DACB_DEBITO_CONTACENTRALIZAD,
            [StringValue("Y")]
            DACB_CENTRALIZADO_CONVERSAO
        }

        /// <summary>
        /// Header
        /// </summary>
        public enum EnumHeader
        {
            [Description("DynamicForms")]
            [StringValue("DynamicForms")]
            DynamicForms,
            [Description("Another")]
            [StringValue("Another")]
            Another,
            [Description("Life20")]
            [StringValue("Life20")]
            Life20,
            [Description("UnitLinked")]
            [StringValue("UnitLinked")]
            UnitLinked
        }

        public enum Company
        {

            /// <summary>
            /// Ageas
            /// </summary>
            [StringValue("AXA")]
            AGS = 0,
            /// <summary>
            /// SGD
            /// </summary>
            [StringValue("SD")]
            SGD = 1,
            /// <summary>
            /// Ocidental Não Vida 
            /// </summary>
            [StringValue("OCS")]
            OCS = 2,
            /// <summary>
            /// Médis 
            /// </summary>
            [StringValue("CPS")]
            CPS = 3,
            /// <summary>
            /// Ageas Vida 
            /// </summary>
            [StringValue("AGV")]
            AGV = 4,
            /// <summary>
            /// Ocidental Não Vida  
            /// </summary>
            [StringValue("OCV")]
            OCV = 5,
            /// <summary>
            /// Todas
            /// </summary>
            [StringValue("Todas")]
            TODAS = 6,
        }

        public enum UploadBy
        {
            /// <summary>
            /// Apólice
            /// </summary>
            Policy,
            /// <summary>
            /// SimulationNumber
            /// </summary>
            Simulationnumber,
            /// <summary>
            /// NIF
            /// </summary>
            NIF,
        }

        public enum DomainsData
        {
            /// <summary>
            /// SAP - Lista de Ramos SAP
            /// </summary>
            [AmbientValue("SAP004")]
            [StringValue("SAP004")]
            SAP004,

            /// <summary>
            /// Descrição de motivo de devolução
            /// </summary>
            [AmbientValue("PA041")]
            [StringValue("PA041")]
            PA041
        }


        public enum EnumStatusPaymentsSap
        {
            //1 – Pago por SIBS
            //2 – Pago por MB
            //3 – Pago por MW
            //4- Pago por CP
            [StringValue("1")]
            PAGO_POR_SIBS,
            [StringValue("2")]
            PAGO_POR_MBREFERENCE,
            [StringValue("3")]
            PAGO_POR_MBWAY,
            [StringValue("4")]
            PAGO_POR_CP
        }
    }
}

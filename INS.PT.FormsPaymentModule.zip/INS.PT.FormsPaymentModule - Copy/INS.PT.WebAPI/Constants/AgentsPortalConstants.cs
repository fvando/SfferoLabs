﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Constants
{
    /// <summary>
    /// AgentsPortalConstants
    /// </summary>
    public static class AgentsPortalConstants
    {
        /// <summary>
        /// AutoMapperOptionsKeys
        /// </summary>
        public static class AutoMapperOptionsKeys
        {
            /// <summary>
            /// The date to string format
            /// </summary>
            public const string DateToStringFormat = "DateToStringFormat";
            /// <summary>
            /// The string to date format
            /// </summary>
            public const string StringToDateFormat = "StringToDateFormat";
        }

        /// <summary>
        /// StringDateTimeReceivedFormat
        /// </summary>
        public static class StringDateTimeReceivedFormat
        {
            /// <summary>
            /// The year month day
            /// </summary>
            public const string YearMonthDay = "yyyyMMdd";
        }

        /// <summary>
        /// DateTimeConvertToStringFormat
        /// </summary>
        public static class DateTimeConvertToStringFormat
        {
            /// <summary>
            /// The year month day
            /// </summary>
            public const string YearMonthDay = "yyyyMMdd";
        }

        /// <summary>
        /// BrokerHeader
        /// </summary>
        public static class BrokerHeader
        {
            /// <summary>
            /// The content type
            /// </summary>
            public const string ContentType = "Content-Type";
            /// <summary>
            /// The accept
            /// </summary>
            public const string Accept = "Accept";
            /// <summary>
            /// The web service
            /// </summary>
            public const string WebService = "bsWebService";
            /// <summary>
            /// The solution
            /// </summary>
            public const string Solution = "bsSolution";
            /// <summary>
            /// The user
            /// </summary>
            public const string User = "bsUser";
            /// <summary>
            /// The webmethod
            /// </summary>
            public const string Webmethod = "bsWebmethod";
            /// <summary>
            /// The identifier company
            /// </summary>
            public const string IdCompany = "idCompany";
            /// <summary>
            /// The identifier network
            /// </summary>
            public const string IdNetwork = "idNetwork";
            /// <summary>
            /// The identifier source
            /// </summary>
            public const string IdSource = "idSource";
        }
    }
}
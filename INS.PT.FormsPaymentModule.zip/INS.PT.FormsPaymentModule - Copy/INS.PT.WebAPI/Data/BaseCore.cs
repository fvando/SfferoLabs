﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.CommonLibrary.Exceptions;
using INS.PT.WebAPI.Constants;
using INS.PT.WebAPI.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Threading.Tasks;
using Serilog;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// Base class for the controllers.
    /// </summary>
    public class BaseCore : ControllerBase
    {
        protected readonly IHttpContextAccessor httpContext;
        protected const string GenericError = "An Error as occurred. Please try again.";

        /// <summary>
        /// Contructor of the BaseCore.
        /// </summary>
        /// <param name="httpContext">execution context being used.</param>
        public BaseCore(IHttpContextAccessor httpContext)
        {
            this.httpContext = httpContext;
        }

        /// <summary>
        /// Method to read parameter from header.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <returns>value</returns>
        private string ReadHeaderParameter(string parameterName)
        {
            // try to read header value
            if (!string.IsNullOrEmpty(parameterName) && httpContext != null
                && httpContext.HttpContext.Request.Headers.TryGetValue(parameterName, out var headerValues))
            {
                return headerValues.First();
            }

            return null;
        }

        #region tipical verb actions
        /// <summary>
        /// Commom call to a repository to take an action.
        /// </summary>
        /// <typeparam name="T">return type</typeparam>
        /// <param name="method">repository method</param>
        /// <param name="noContent">Logic to determine not found.</param>
        /// <returns>Return of action</returns>
        protected async Task<ActionResult<T>> RepositoryInvokerAsync<T>(Func<Task<T>> method, Func<T, bool> noContent)
        {
            try
            {
                var stopwatch = new System.Diagnostics.Stopwatch();
                stopwatch.Start();

                // get result from method
                var result = await method?.Invoke();

                stopwatch.Stop();
                Log.Information($"Repository call took {stopwatch.ElapsedMilliseconds}ms");

                // check Logic for no results
                var notFoundResult = noContent?.Invoke(result);

                if (!notFoundResult.HasValue || notFoundResult.Value)
                {
                    // no results return path
                    Log.Debug($"Return NoContent: {result}");
                    return NoContent();
                }

                Log.Debug($"Return OK {JsonConvert.SerializeObject(result)}");
                return Ok(result);
            }
            catch (StandardMessageException exception)
            {
                // exceptions generated from repositories
                Log.Error(exception, String.Empty);
                return StatusCode((int)exception.StatusCode, exception);
            }
            catch (AggregateException validateErrors)
            {
                // validation error return BadRequest
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            catch (ProcessErrorException validateErrors)
            {
                // validation error return BadRequest
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            catch (Exception exc)
            {
                // Unexpected exception
                Log.Error(exc, String.Empty);

                return NotFound(
                    new StandardMessageException
                    {
                        ErrorCode = HttpStatusCode.NotFound.ToString(),
                        ErrorMessage = $"{GenericError}"
                    });
            }
            finally
            {
                Log.Information("Finish Call");
            }
        }
        #endregion
    }
}

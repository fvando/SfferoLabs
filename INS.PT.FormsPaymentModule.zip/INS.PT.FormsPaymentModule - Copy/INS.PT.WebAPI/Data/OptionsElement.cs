﻿namespace INS.PT.WebAPI.Data
{
    /// <summary>
    /// OptionsElement
    /// </summary>
    public class OptionsElement
    {
        /// <summary>
        /// Gets or sets a value indicating whether [handle list404 response].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [handle list404 response]; otherwise, <c>false</c>.
        /// </value>
        public bool HandleList404Response { get; set; }

    }
}
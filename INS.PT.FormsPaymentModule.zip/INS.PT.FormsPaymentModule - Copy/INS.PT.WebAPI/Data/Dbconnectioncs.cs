﻿// Copyright Ageas 2019 © - Integration Team

using Oracle.ManagedDataAccess.Client;
using System;
using Microsoft.Extensions.Configuration;
using System.Data;
using Newtonsoft.Json;
using System.Reflection;
using Serilog;

namespace INS.PT.WebAPI
{
    ///<inheritdoc /> 
    /// <summary>
    /// concrete class
    /// </summary>
    public class Dbconnectioncs : IDbconnectioncs, IDisposable
    {
        private readonly IConfiguration configuration;
        private IDbConnection connection;

        /// <summary>
        /// Object contructor.
        /// </summary>
        /// <param name="configuration">Configuration to use.</param>
        public Dbconnectioncs(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources.
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            // cleanup
            if (connection != null && connection.State != ConnectionState.Closed)
            {
                connection.Close();
            }
        }

        /// <summary>
        /// GetConnection
        /// </summary>
        /// <returns>Connection to be used.</returns>
        public IDbConnection Connection
        {
            get
            {
                try
                {
                    // open connection if not already open
                    if (connection == null || connection.State == ConnectionState.Closed)
                    {
                        var stopwatch = new System.Diagnostics.Stopwatch();
                        stopwatch.Start();

                        string connectionString = configuration.GetSection("ConnectionStrings").GetSection("DBConnection").Value;
                        connection = new OracleConnection(connectionString);
                        connection.Open();

                        stopwatch.Stop();
                        Log.Debug($"GetConnection result: {JsonConvert.SerializeObject(connection)};\n Open coonnection took {stopwatch.ElapsedMilliseconds}ms");
                    }
                }
                catch (Exception ex)
                {
                    // exception  
                    Log.Error($"Result: { JsonConvert.SerializeObject(ex.Message, Formatting.Indented)}");
                    throw;
                }

                return connection;
            }
        }
    }

}

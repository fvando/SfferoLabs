﻿using INS.PT.WebAPI.Configurations;
using INS.PT.WebAPI.Interface;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System.Reflection;

namespace INS.PT.WebAPI.Data
{
    /// <summary>
    /// BaseRepository
    /// </summary>
    public class BaseRepository
    {
        #region Properties
        protected readonly HttpRequest request;
        protected readonly IRepositoryInvoker repositoryInvoker;
        protected readonly ApplicationSettings applicationSettings;
        protected readonly IConfiguration configuration;

        #endregion


        /// <summary>
        /// Initializes a new instance of the <see cref="BaseRepository"/> class.
        /// </summary>
        /// <param name="_applicationSettings">The application settings.</param>
        public BaseRepository(IConfiguration _configuration, ApplicationSettings _applicationSettings)
        {
            configuration = _configuration;
            applicationSettings = _applicationSettings;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseRepository"/> class.
        /// </summary>
        /// <param name="_applicationSettings">The application settings.</param>
        /// <param name="_repositoryInvoker">The repository invoker.</param>
        public BaseRepository(IConfiguration _configuration, ApplicationSettings _applicationSettings, IRepositoryInvoker _repositoryInvoker) 
            : this(_configuration, _applicationSettings)
        {
            repositoryInvoker = _repositoryInvoker;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseRepository"/> class.
        /// </summary>
        /// <param name="_applicationSettings">The application settings.</param>
        /// <param name="_repositoryInvoker">The repository invoker.</param>
        /// <param name="_request">The request.</param>
        public BaseRepository(IConfiguration _configuration, ApplicationSettings _applicationSettings, IRepositoryInvoker _repositoryInvoker, HttpRequest _request) 
            : this(_configuration, _applicationSettings, _repositoryInvoker)
        {
            request = _request; 
        }
    }
}

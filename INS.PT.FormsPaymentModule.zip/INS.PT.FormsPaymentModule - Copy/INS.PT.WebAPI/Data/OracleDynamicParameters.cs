﻿// Copyright Ageas 2019 © - Integration Team

using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Xml.Linq;
using Dapper;
using Microsoft.Extensions.Logging;
using Oracle.ManagedDataAccess.Client;

namespace INS.PT.WebAPI
{
    ///<inheritdoc />
    public class OracleDynamicParameters : SqlMapper.IDynamicParameters
    {
        /// <summary>
        /// The dynamic parameters
        /// </summary>
        private readonly DynamicParameters dynamicParameters = new DynamicParameters();
        /// <summary>
        /// The oracle parameters
        /// </summary>
        private readonly ICollection<OracleParameter> OracleParameters = new List<OracleParameter>();
        /// <summary>
        /// Gets the parameters.
        /// </summary>
        /// <value>
        /// The parameters.
        /// </value>
        public ICollection<OracleParameter> Parameters => OracleParameters;

        /// <summary>
        /// Method to log parameters values.
        /// </summary>
        /// <param name="logger">Log instance where to log.</param>
        public void Log(ILogger logger, ParameterDirection direction)
        {
            if(logger == null)
            {
                return;
            }

            logger.LogDebug($"logging {direction} parameters:");

            foreach(var p in OracleParameters.Where(op => op.Direction == direction))
            {
                var value = p.Value;

                if (p.Value is Oracle.ManagedDataAccess.Types.OracleXmlType dbValue)
                {
                    value = dbValue.Value;
                }

                logger.LogDebug($"\tparameter named={p.ParameterName}, type={p.OracleDbType}, value={value}");
            }
        }


        /// <summary>
        /// Creates a new package parameter.
        /// </summary>
        /// <param name="name">Parameter name.</param>
        /// <param name="oracleDbType">Database datatype.</param>
        /// <param name="direction">Parameter direction.</param>
        public void Add(string name, OracleDbType oracleDbType, ParameterDirection direction)
        {
            var oracleParameter = new OracleParameter(name, oracleDbType, direction);
            OracleParameters.Add(oracleParameter);
        }

        /// <summary>
        /// Adds the specified name.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="oracleDbType">Type of the oracle database.</param>
        /// <param name="direction">The direction.</param>
        /// <param name="value">The value.</param>
        public void Add(string name, OracleDbType oracleDbType, ParameterDirection direction, object value)
        {
            Add(name, oracleDbType, direction, value, null);
        }


        /// <summary>
        /// Adds the specified name.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="oracleDbType">Type of the oracle database.</param>
        /// <param name="direction">The direction.</param>
        /// <param name="value">The value.</param>
        /// <param name="size">The size.</param>
        public void Add(string name, OracleDbType oracleDbType, ParameterDirection direction, object value, int? size)
        {
            OracleParameters.Add(
                size.HasValue ?
                    new OracleParameter(name, oracleDbType, size.Value, value, direction)
                    : new OracleParameter(name, oracleDbType, value, direction));
        }

        /// <summary>
        /// Add all the parameters needed to the command just before it executes
        /// </summary>
        /// <param name="command">The raw command prior to execution</param>
        /// <param name="identity">Information about the query</param>
        public void AddParameters(IDbCommand command, SqlMapper.Identity identity)
        {
            ((SqlMapper.IDynamicParameters)dynamicParameters).AddParameters(command, identity);

            if (command is OracleCommand oracleCommand)
            {
                oracleCommand.Parameters.AddRange(OracleParameters.ToArray());
            }
        }

        /// <summary>
        /// Reads the output value from a parameter.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <returns>decimal value of the parameter</returns>
        public decimal GetDecimal(string parameterName)
        {
            return GetDecimal(parameterName, default(decimal));
        }

        /// <summary>
        /// Reads the output value from a parameter.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <param name="defaultValue">default value if parameter is not found or is not the expected type</param>
        /// <returns>decimal value of the parameter or default value</returns>
        public decimal GetDecimal(string parameterName, decimal defaultValue)
        {
            var parameterValue = OracleParameters.FirstOrDefault(op => op.ParameterName == parameterName)?.Value;
            if (parameterValue is Oracle.ManagedDataAccess.Types.OracleDecimal dbValue)
            {
                return dbValue.IsNull ? defaultValue : dbValue.Value;
            }

            return defaultValue;
        }

        /// <summary>
        /// Reads the output value from a parameter.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <returns>int value of the parameter</returns>
        public int GetInt(string parameterName)
        {
            return GetInt(parameterName, default(int));
        }

        /// <summary>
        /// Reads the output value from a parameter.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <param name="defaultValue">default value if parameter is not found or is not the expected type</param>
        /// <returns>int value of the parameter or default value</returns>
        public int GetInt(string parameterName, int defaultValue)
        {
            var parameterValue = OracleParameters.FirstOrDefault(op => op.ParameterName == parameterName)?.Value;
            if (parameterValue is Oracle.ManagedDataAccess.Types.OracleDecimal dbValue)
            {
                return dbValue.IsNull ? defaultValue : decimal.ToInt32(dbValue.Value);
            }

            return defaultValue;
        }

        /// <summary>
        /// Reads the output value from a parameter.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <returns>string value of the parameter</returns>
        public string GetString(string parameterName)
        {
            return GetString(parameterName, default(string));
        }

        /// <summary>
        /// Reads the output value from a parameter.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <param name="defaultValue">default value if parameter is not found or is not the expected type</param>
        /// <returns>string value of the parameter or default value</returns>
        public string GetString(string parameterName, string defaultValue)
        {
            var parameterValue = OracleParameters.FirstOrDefault(op => op.ParameterName == parameterName)?.Value;
            if (parameterValue is Oracle.ManagedDataAccess.Types.OracleString dbValue)
            {
                return dbValue.IsNull ? null : dbValue.Value;
            }

            return defaultValue;
        }

        /// <summary>
        /// Reads the output value from a parameter.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <returns>Xdocument value of the parameter</returns>
        public XDocument GetXml(string parameterName)
        {
            return GetXml(parameterName, null);
        }

        /// <summary>
        /// Reads the output value from a parameter.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <param name="defaultValue">default value if parameter is not found or is not the expected type</param>
        /// <returns>Xdocument value of the parameter or default value</returns>
        public XDocument GetXml(string parameterName, XDocument defaultValue)
        {
            var parameterValue = OracleParameters.FirstOrDefault(op => op.ParameterName == parameterName)?.Value;
            if (parameterValue is Oracle.ManagedDataAccess.Types.OracleXmlType dbValue)
            {
                return dbValue.IsNull ? null : XDocument.Parse(dbValue.Value);
            }
            if (parameterValue is Oracle.ManagedDataAccess.Types.OracleString dbStringValue)
            {
                return dbStringValue.IsNull ? null : XDocument.Parse(dbStringValue.Value);
            }

            return defaultValue;
        }
    }
}

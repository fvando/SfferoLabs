﻿// Copyright Ageas 2019 © - Integration Team

using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.Diagnostics;
using System.IO;
using System;
using Serilog;
using Serilog.Context;
using Newtonsoft.Json;

/// <summary>
/// Ins.PT.WebAPI.Middleware
/// </summary>
namespace INS.PT.WebAPI.Middleware
{
    /// <summary>
    /// RequestResponseLoggingMiddleware
    /// </summary>
    public class RequestResponseLoggingMiddleware
    {
        private readonly RequestDelegate _next;

        public RequestResponseLoggingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        /// <summary>
        /// Invoke
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InvokeAsync(HttpContext context)
        {
            if (context == null) {
                return;
            }

            Log.Debug("***Begin CALL***");

            //Start 
            var stopwatch = new Stopwatch();
            stopwatch.Start();

            //Headers
            var requestHeaders = string.Join("|", context.Request.Headers.Select(x => $"{x.Key}:{x.Value}").OrderBy(x => x));
            Log.Debug("Headers Request: {requestHeaders} ", JsonConvert.SerializeObject(requestHeaders) );

            //Method
            var Method = $"{context.Request.Method}";
            // Add Method to HttpContext
            context.Items.Add("XMethod", $"{Method}");
            LogContext.PushProperty("XMethod", $"{Method}");
            Log.Debug("Header Method: {Method} ", Method);


            //controller
            var controller = $"{context.Request.Path}";
            // Add Method to HttpContext
            context.Items.Add("XController", $"{controller}");
            LogContext.PushProperty("XController", $"{controller}");
            Log.Debug("Header Controler: {controller} ", controller);

            //write body request
            using (var requestBodyStream = new MemoryStream())
            {
                var originalRequestBody = context.Request.Body;

                await context.Request.Body.CopyToAsync(requestBodyStream);
                requestBodyStream.Seek(0, SeekOrigin.Begin);

                var bodyRequest = new StreamReader(requestBodyStream).ReadToEnd();

                // write Log 
                Log.Debug("Request Body: {bodyRequest} ", JsonConvert.SerializeObject(bodyRequest));

                requestBodyStream.Seek(0, SeekOrigin.Begin);
                context.Request.Body = requestBodyStream;

                //Continue down the Middleware pipeline, eventually returning to this class
                await _next(context);
                context.Request.Body = originalRequestBody;
            }

           //Headers Response
            var responseHeaders = string.Join("|", context.Response.Headers.Select(x => $"{x.Key}:{x.Value}").OrderBy(x => x));
            Log.Debug("Headers Response: {responseHeaders} ", JsonConvert.SerializeObject(responseHeaders));

            var UrlInvoque = $"{context.Request.Scheme} {context.Request.Host}{controller}{context.Request.QueryString}";
            // write Log 
            Log.Debug("Url: {UrlInvoque} ", JsonConvert.SerializeObject(UrlInvoque));

            // write Log 
            Log.Debug("Response Status: {StatusCode} ", JsonConvert.SerializeObject(context.Response.StatusCode));

            // write Log 
            stopwatch.Stop(); //stop measuring
            Log.Debug("Response time: {Elapsed:000} ms", stopwatch.ElapsedMilliseconds);

            Log.Debug("***End CALL***");
        }
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using Microsoft.AspNetCore.Http;
using System.Diagnostics;
using System.Threading.Tasks;
using System;
using Serilog;

/// <summary>
/// Ins.PT.WebAPI.Middleware
/// </summary>
namespace INS.PT.WebAPI.Middleware
{
    /// <summary>
    /// LogResponseTimeMiddleWare
    /// </summary>
    public class LogResponseTimeMiddleWare
    {
        private readonly RequestDelegate _next;

        public LogResponseTimeMiddleWare(RequestDelegate next)
        {
            _next = next;
        }

        /// <summary>
        /// Invoke
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InvokeAsync(HttpContext context)
        {
            Log.Debug("***Begin CALL***");

            var stopwatch = new Stopwatch();
            stopwatch.Start();

            // execute the rest of the pipeline
            await _next(context);

            stopwatch.Stop(); //stop measuring

            // write Log 
            Log.Debug($"Response in {stopwatch.ElapsedMilliseconds} ms");

            Log.Debug("***End CALL***");
        }
    }
}

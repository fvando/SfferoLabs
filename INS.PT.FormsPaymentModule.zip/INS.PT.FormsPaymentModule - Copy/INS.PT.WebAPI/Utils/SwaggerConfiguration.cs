﻿namespace INS.PT.WebAPI
{
    /// <summary>
    /// Swagger configuration
    /// </summary>
    public static class SwaggerConfiguration
    {
        /// <summary>
        /// <para>Foo API v1</para>
        /// </summary>
        public const string EndpointDescription = "FormsPaymentModule v2";

        /// <summary>
        /// <para>/swagger/v1/swagger.json</para>
        /// </summary>
        public const string EndpointUrl =  "../swagger/v1/swagger.json";

        /// <summary>
        /// <para>v1</para>
        /// </summary>
        public const string DocNameV1 = "v1";

        /// <summary>
        /// <para>Foo API</para>
        /// </summary>
        public const string DocInfoTitle = "FormsPaymentModule API ";

        /// <summary>
        /// <para>v1</para>
        /// </summary>
        public const string DocInfoVersion = "v2";

        /// <summary>
        /// <para>Foo Api - Sample Web API in ASP.NET Core 2</para>
        /// </summary>
        public const string DocInfoDescription = "Forms Payment Module Api v1";

        public const string DocInfoContact = "";
        public const string DocInfoLicense = "";
        public const string DocInfoTermsOfService = "";
    }
}

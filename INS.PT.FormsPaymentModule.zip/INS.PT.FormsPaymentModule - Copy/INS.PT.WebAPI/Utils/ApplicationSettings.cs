﻿using INS.PT.WebAPI.Configurations.Elements;

using INS.PT.WebAPI.Helper;
using Microsoft.Extensions.Configuration;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// Application settings.
    /// </summary>
    public partial class ApplicationSettings 
    {
        /// <summary>
        /// Gets the name of the application.
        /// </summary>
        /// <value>
        /// The name of the application.
        /// </value>
        public static string ApplicationName { get; private set; }
        /// <summary>
        /// Gets the application environment.
        /// </summary>
        /// <value>
        /// The application environment.
        /// </value>
        public string ApplicationEnvironment { get; set; }
        /// <summary>
        /// Gets or sets the content type json.
        /// </summary>
        /// <value>
        /// The content type json.
        /// </value>
        public string ContentTypeJson { get; set; }
        /// <summary>
        /// Gets or sets the broker settings.
        /// </summary>
        /// <value>
        /// The broker settings.
        /// </value>
        public BrokerSettings BrokerSettings { get; set; }
        /// <summary>
        /// Gets or sets the broker services name spaces.
        /// </summary>
        /// <value>
        /// The broker services name spaces.
        /// </value>
        public BrokerServicesNameSpaces BrokerServicesNameSpaces { get; set; }

        /// <summary>
        /// Gets or sets the canonical service.
        /// </summary>
        /// <value>
        /// The canonical service.
        /// </value>
        public CanonicalService CanonicalService { get; set; }

        /// <summary>
        /// Gets or sets the canonical service life20.
        /// </summary>
        /// <value>
        /// The canonical service life20.
        /// </value>
        public CanonicalServiceLife20 CanonicalServiceLife20 { get; set; }

        /// <summary>
        /// Gets or sets the payment method option.
        /// </summary>
        /// <value>
        /// The payment method option.
        /// </value>
        public PaymentMethodOption PaymentMethodOption { get; set; }

        /// <summary>
        /// Gets or sets the oracle settings.
        /// </summary>
        /// <value>
        /// The oracle settings.
        /// </value>
        public OracleSettings OracleSettings { get; set; }

        /// <summary>
        /// Gets or sets the email settings.
        /// </summary>
        /// <value>
        /// The email settings.
        /// </value>
        public EmailSettings EmailSettings { get; set; }
        public SmsSettings SmsSettings { get; set; }

        public BrokerDuckCreekSettings BrokerDuckCreekSettings { get; set; }




        /// <summary>
        /// Sets the settings.
        /// </summary>
        /// <param name="config">The configuration.</param>
        public static void SetSettings(IConfiguration config)
        {
            if (config == null)
            {
                return;
            }

            ApplicationName = config["ApplicationSettings:ApplicationName"];
        }
    }
}

﻿using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Linq;

namespace INS.PT.WebAPI.Filters
{
    public class ArraySchemaFilter : ISchemaFilter
    {
        public void Apply(OpenApiSchema schema, SchemaFilterContext context)
        {
            var type = context?.Type;

            if (type == null || schema == null)
            {
                return;
            }

            // Fix issues with xml array examples not generating correctly
            if (!type.IsValueType && schema.Properties != null)
            {
                //Array property, which wraps its elements
                foreach (var property in schema.Properties.Where(p => p.Value.Type == "array"))
                {
                    property.Value.Xml = new OpenApiXml
                    {
                        Name = $"{property.Key}",
                        Wrapped = true
                    };

                    property.Value.Items = new OpenApiSchema
                    {
                        AllOf = new List<OpenApiSchema>()
                        {
                            new OpenApiSchema()
                            {
                               Reference  = property.Value.Items.Reference
                            }
                        },
                        //For complex type, Type is null, for simple type i.e string, type is string.
                        Type = property.Value.Items?.Type ?? "object",

                        Xml = new OpenApiXml()
                        {
                            Name = property.Value.Items.Type != null ?

                            //string for simple type.
                            property.Value.Items.Type == "string" ? property.Value.Items.Type : property.Value.Items.Format.Replace("32", "").Replace("64", "") :

                            //Singular property name i.e if parent propery is Accounts, the item will have Account.
                            //Where Account is a complex type object.
                            property.Value.Items.Reference.ReferenceV2.ToString().Replace("#/definitions/", "")
                        }
                    };
                }
            }
        }
    }
}

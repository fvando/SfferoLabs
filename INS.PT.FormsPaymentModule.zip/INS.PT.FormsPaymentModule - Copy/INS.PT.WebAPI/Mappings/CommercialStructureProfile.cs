﻿using AutoMapper;
using INS.PT.WebAPI.Helpers;
using INS.PT.WebAPI.Models.AgentsPortal.CommercialStructure;
using INS.PT.WebAPI.Models.AgentsPortal.CommercialStructure.Element;
using INS.PT.WebAPI.Models.Collections;
using INS.PT.WebAPI.Models.DTO.Collections;
using INS.PT.WebAPI.Models.DTO.Collections.Elements;
using INS.PT.WebAPI.Models.DTO.CommercialStructure;
using INS.PT.WebAPI.Models.DTO.CommercialStructure.Element;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Mappings
{
    /// <summary>
    /// CommercialStructureProfile
    /// </summary>
    /// <seealso cref="AutoMapper.Profile" />
    public class CommercialStructureProfile : Profile
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CommercialStructureProfile"/> class.
        /// </summary>
        public CommercialStructureProfile()
        {
            //Classification Commercial Structure
            CreateMap<AgentClassificationDTO, AgentClassificationWaspOutput>();
            CreateMap<AgentClassificationTypeDTO, AgentClassificationTypeElement>();
            CreateMap<ClassificationDTO, ClassificationElement>();
            CreateMap<List<AgentClassificationWaspOutput>, List<AgentClassificationsResponseDTO>>().ReverseMap();
        }
    }
}

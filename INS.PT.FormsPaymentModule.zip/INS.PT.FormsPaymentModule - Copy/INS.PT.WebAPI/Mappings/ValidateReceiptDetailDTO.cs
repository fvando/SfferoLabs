﻿using INS.PT.WebAPI.Models.DTO.Collections.Elements;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Mappings
{
    public class ValidateReceiptDetailDTO : ZfscdPcRecibosLinhaDTO
    {
        [JsonProperty(PropertyName = "Status", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]

        public List<ValidateStatusDetailDTO> Status { get; set; }
    }
}
﻿using AutoMapper;
using INS.PT.WebAPI.Helpers;
using INS.PT.WebAPI.Models.Collections;
using INS.PT.WebAPI.Models.DTO.Collections;
using INS.PT.WebAPI.Models.DTO.Collections.Elements;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Mappings
{
    /// <summary>
    /// CollectionsProfile
    /// </summary>
    /// <seealso cref="AutoMapper.Profile" />
    public class CollectionsProfile : Profile
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CollectionsProfile"/> class.
        /// </summary>
        public CollectionsProfile()
        {
            CreateMap<ErrorElement, ZfscdErrosReceiptsNumLineDTO>().ReverseMap();
            CreateMap<ErrorElement, ZfscdCodigosErroLinhaListDTO>().ReverseMap();

            CreateMap<DetailReceiptElement, ZfscdRecibosWorkLinhaDTO>().ReverseMap();

            CreateMap<ReceiptDetailWaspInput, ZFscdRecibosListarWsInputDTO>().ReverseMap();
            CreateMap<ReceiptDetailWaspOutput, ZFscdRecibosListarWsDTO>().ReverseMap();

            CreateMap<Models.Common.Error, Models.DTO.Collections.ErrorDTO>()
                .ForMember(dest => dest.ErrorCode, opt => opt.MapFrom(src => src.Code))
                .ForMember(dest => dest.ErrorMessage, opt => opt.MapFrom(src => src.Descritpion))
                .ForMember(dest => dest.ErrorType, opt => opt.MapFrom(src => src.Type)).ReverseMap();

            CreateMap<ReceiptElement, ZfscdPcRecibosLinhaDTO>().ReverseMap();


            //Charged
            CreateMap<ChargedStatusDetail, ChargedStatusDetailDTO>().ReverseMap();
            CreateMap<ChargedReceiptDetailElements, ChargedReceiptDetailDTO>().ReverseMap();
            CreateMap<ChargedReceiptsWaspInput, ZFscdPcCobrarWsDTO>().ReverseMap();
            CreateMap<ChargedReceiptLineDetailResponseWaspOuptut, ChargedReceiptLineDetailResponseDTO>().ReverseMap();


            //Validate
            CreateMap<ValidateStatusDetail, ValidateStatusDetailDTO>().ReverseMap();
            CreateMap<ValidateReceiptDetailElements, ValidateReceiptDetailDTO>().ReverseMap();
            CreateMap<ValidateReceiptsWaspInput, ZFscdPcValidarWsDTO>().ReverseMap();
            CreateMap<ValidateReceiptLineDetailResponseWaspOutput, ValidateReceiptLineDetailResponseDTO>().ReverseMap();


        }
    }
}

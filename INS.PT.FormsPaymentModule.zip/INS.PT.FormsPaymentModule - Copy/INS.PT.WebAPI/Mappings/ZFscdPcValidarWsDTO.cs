﻿using INS.PT.WebAPI.Models.DTO.Collections.Elements;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Mappings
{
    internal class ZFscdPcValidarWsDTO
    {
        /// <summary>
        /// Gets or sets BrokerContract
        /// </summary>
        [JsonProperty(PropertyName = "brokerContract")]
        public string BrokerContract { get; set; }

        /// <summary>
        /// Gets or sets the teste run.
        /// </summary>
        /// <value>
        /// The teste run.
        /// </value>
        [JsonProperty(PropertyName = "testeRun")]
        public string TesteRun { get; set; }

        /// <summary>
        /// Gets or sets PcReceipts
        /// </summary>
        [JsonProperty(PropertyName = "pcReceipts")]
        public List<ZfscdPcRecibosLinhaDTO> PcReceipts { get; set; }
    }
}
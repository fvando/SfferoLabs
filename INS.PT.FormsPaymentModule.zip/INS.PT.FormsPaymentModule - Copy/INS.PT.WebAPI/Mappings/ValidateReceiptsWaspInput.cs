﻿using INS.PT.WebAPI.Models.Collections;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Mappings
{
    public class ValidateReceiptsWaspInput
    {
        /// <summary>
        /// Gets or sets the broker contract.
        /// </summary>
        /// <value>
        /// The broker contract.
        /// </value>
        [JsonProperty(PropertyName = "brokerContract", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerContract { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the test run.
        /// </summary>
        /// <value>
        /// The test run.
        /// </value>
        [JsonProperty(PropertyName = "testeRun", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string TesteRun { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the pc receipts.
        /// </summary>
        /// <value>
        /// The pc receipts.
        /// </value>
        [JsonProperty(PropertyName = "receipts", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public List<ReceiptElement> PcReceipts { get; set; }
    }
}
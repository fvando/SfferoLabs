﻿using AutoMapper;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Models.Domain;
using INS.PT.WebAPI.Models.DTO.Domain;
using Serilog;
using System;

namespace INS.PT.WebAPI.Mappings
{
    /// <summary>
    /// AutoMapperProfileConfiguration
    /// </summary>
    /// <seealso cref="AutoMapper.Profile" />
    public class AutoMapperProfileConfiguration : Profile
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AutoMapperProfileConfiguration"/> class.
        /// </summary>
        public AutoMapperProfileConfiguration()
        {
            try
            {
                #region GenericInvoker
                //GlobalEntityOutput
                CreateMap<ExtraPropertyElement, ExtraPropertyElementDTO>().ReverseMap();
                CreateMap<GlobalEntityElementsRamo, GlobalEntityElementsRamoDTO>().ReverseMap();
                CreateMap<GlobalEntityOutput, GlobalEntityOutputDTO>().ReverseMap();
                #endregion

                #region GenericInvoker
                //GlobalEntityOutput
                CreateMap<SearchEntityOutput, SearchEntityOutput>().ReverseMap();
                CreateMap<PoBox, PoBox>().ReverseMap();
                CreateMap<PoAddress, PoAddress>().ReverseMap();
                CreateMap<AddressTipology, AddressTipology>().ReverseMap();
                CreateMap<SimpleCae, SimpleCae>().ReverseMap();
                CreateMap<Address, Address>().ReverseMap();
                CreateMap<SimpleEntity, SimpleEntity>().ReverseMap();
                #endregion
            }
            catch (Exception e)
            {
                Log.Error($"{e}");
                throw;
            }
        }
    }
}

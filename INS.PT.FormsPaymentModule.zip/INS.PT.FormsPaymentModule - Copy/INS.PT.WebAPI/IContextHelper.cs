﻿// Copyright Ageas 2019 © - Integration Team

namespace INS.PT.WebAPI
{
    internal interface IContextHelper
    {
    }
}
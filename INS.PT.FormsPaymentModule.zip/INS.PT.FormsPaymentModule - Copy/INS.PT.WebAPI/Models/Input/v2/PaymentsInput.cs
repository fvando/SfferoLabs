﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;
using static INS.PT.WebAPI.Constants.CommonEnums;

namespace INS.PT.WebAPI.Models.Input.v2
{
    /// <summary>
    /// PaymentsInput
    /// </summary>
    public class PaymentsInput
    {
        /// <summary>
        /// Payment identifier.
        /// </summary>
        /// <example>mbway</example>
        [JsonRequired]
        [Required]
        [JsonProperty(PropertyName = "IdPaymentMethod", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public EnumPayments IdPaymentMethod { get; set; }

        /// <summary>
        /// Receipt number.
        /// </summary>
        /// <example>R1234</example>
        [JsonProperty(PropertyName = "ReceiptNumber", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReceiptNumber { get; set; } = String.Empty;

        /// <summary>
        /// Aditional information nedded for payment.
        /// </summary>
        /// <example>912345678</example>
        [JsonProperty(PropertyName = "AditionalInformation", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string AditionalInformation { get; set; } = String.Empty;
    }
}

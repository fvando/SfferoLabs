﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Input.v2
{
    /// <summary>
    /// Parameters to retrive payments list.
    /// </summary>
    public class PaymentMethodsInput
    {
        /// <summary>
        /// 
        /// </summary>
        [FromRoute]
        [Required]
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Id { get; set; }

    }
}

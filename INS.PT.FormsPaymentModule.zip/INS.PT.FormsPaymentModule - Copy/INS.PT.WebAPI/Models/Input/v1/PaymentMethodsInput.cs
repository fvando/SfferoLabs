﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Models.Input.v1
{
    /// <summary>
    /// Parameters to retrive payments list.
    /// </summary>
    public class PaymentMethodsInput
    {
        /// <summary>
        /// Id Quote.
        /// </summary>
        [FromRoute]
        [Required]
        public string IdQuote { get; set; }

    }
}

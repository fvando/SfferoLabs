﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using static INS.PT.WebAPI.Constants.CommonEnums;

namespace INS.PT.WebAPI.Models.Input.v1
{
    /// <summary>
    /// PaymentsInput
    /// </summary>
    public class PaymentsInput
    {
        /// <summary>
        /// Payment identifier.
        /// </summary>
        /// <example>mbway</example>
        [JsonRequired]
        [Required]

        public EnumPayments IdPaymentMethod { get; set; }

        /// <summary>
        /// Receipt number.
        /// </summary>
        /// <example>R1234</example>
        [JsonProperty(PropertyName = "ReceiptNumber")]
        public string ReceiptNumber { get; set; }

        /// <summary>
        /// Aditional information nedded for payment.
        /// </summary>
        /// <example>912345678</example>
        public string AditionalInformation { get; set; }
    }
}

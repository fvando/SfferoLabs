﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.Common
{
    /// <summary>
    /// Error
    /// </summary>
    public class Error
    {
        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code.
        /// </value>
        [JsonProperty("code", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string Code { get; set; }
        /// <summary>
        /// Gets or sets the descritpion.
        /// </summary>
        /// <value>
        /// The descritpion.
        /// </value>
        [JsonProperty("descritpion", DefaultValueHandling = DefaultValueHandling.Populate)]
        public dynamic Descritpion { get; set; }
        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>
        /// The type.
        /// </value>
        [JsonProperty("type", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string Type { get; set; }
    }
}

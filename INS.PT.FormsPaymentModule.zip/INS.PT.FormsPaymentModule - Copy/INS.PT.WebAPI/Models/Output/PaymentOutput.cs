﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Constants.CommonEnums;

namespace INS.PT.WebAPI.Models.Output
{
    /// <summary>
    /// PaymentOutput
    /// </summary>
    public class PaymentOutput
    {
        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code.
        /// </value>
        [JsonProperty(PropertyName = "code", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Code { get; set; } 

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        [JsonProperty(PropertyName = "status", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; } 
       
        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>
        /// The message.
        /// </value>
        [JsonProperty(PropertyName = "message", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Message { get; set; } 
     
        /// <summary>
        /// Gets or sets the merchant transaction identifier.
        /// </summary>
        /// <value>
        /// The merchant transaction identifier.
        /// </value>
        [JsonProperty(PropertyName = "merchantTransactionId", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string MerchantTransactionId { get; set; } 
       
        /// <summary>
        /// Gets or sets the amount.
        /// </summary>
        /// <value>
        /// The amount.
        /// </value>
        [JsonProperty(PropertyName = "amount", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Amount { get; set; } 
        
        /// <summary>
        /// Gets or sets the reference.
        /// </summary>
        /// <value>
        /// The reference.
        /// </value>
        [JsonProperty(PropertyName = "reference", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Reference { get; set; } 
    
        /// <summary>
        /// Gets or sets the entity.
        /// </summary>
        /// <value>
        /// The entity.
        /// </value>
        [JsonProperty(PropertyName = "entity", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Entity { get; set; }

        /// <summary>
        /// Gets or sets the contato.
        /// </summary>
        /// <value>
        /// The contato.
        /// </value>
        [JsonProperty(PropertyName = "phone", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Phone { get; set; } 

        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>
        /// The contato.
        /// </value>
        [JsonProperty(PropertyName = "eMail", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; } 

        /// <summary>
        /// Gets or sets the data limite.
        /// </summary>
        /// <value>
        /// The data limite.
        /// </value>
        [JsonProperty(PropertyName = "dueDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DueDate { get; set; } 

        /// <summary>
        /// Gets or sets the back end.
        /// </summary>
        /// <value>
        /// The back end.
        /// </value>
        [JsonProperty(PropertyName = "backEnd", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BackEnd { get; set; } 

        /// <summary>
        /// Gets or sets the policy.
        /// </summary>
        /// <value>
        /// The policy.
        /// </value>
        [JsonProperty(PropertyName = "policy", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Policy { get; set; }

        /// <summary>
        /// Gets or sets the identifier payment method.
        /// </summary>
        /// <value>
        /// The identifier payment method.
        /// </value>
        [JsonProperty(PropertyName = "IdPaymentMethod", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string IdPaymentMethod { get; set; }

        /// <summary>
        /// Gets or sets the status codes.
        /// </summary>
        /// <value>
        /// The status codes.
        /// </value>
        [JsonProperty(PropertyName = "StatusCodes", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string StatusCodes { get; set; }

        /// <summary>
        /// Gets or sets the session payment options.
        /// </summary>
        /// <value>
        /// The session payment options.
        /// </value>
        [JsonProperty(PropertyName = "SessionPaymentOptions", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SessionPaymentOptions { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the channel.
        /// </summary>
        /// <value>
        /// The channel.
        /// </value>
        [JsonProperty(PropertyName = "Channel", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Channel { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the proposal.
        /// </summary>
        /// <value>
        /// The proposal.
        /// </value>
        [JsonProperty(PropertyName = "proposal", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Proposal { get; set; }

    }
}

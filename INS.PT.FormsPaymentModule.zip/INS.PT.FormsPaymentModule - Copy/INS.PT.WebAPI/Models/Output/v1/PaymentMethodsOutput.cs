﻿using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.Output.v1
{
    /// <summary>
    /// PaymentMethodsOutput
    /// </summary>
    public class PaymentMethodsOutput
    {
        /// <summary>
        /// Quote identifier.
        /// </summary>
        public string IdQuote { get; set; }

        /// <summary>
        /// Total payments available.
        /// </summary>
        public int TotalResults { get => ResultList.Count; }

        /// <summary>
        /// List of values.
        /// </summary>
        public ICollection<PaymentMethod> ResultList { get; set; } = new List<PaymentMethod>();
    }
}

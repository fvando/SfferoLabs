﻿
using Newtonsoft.Json;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.Output.v2
{
    /// <summary>
    /// PaymentMethodsOutput
    /// </summary>
    public class PaymentMethodsOutput
    {
        /// <summary>
        /// Receipt identifier.
        /// </summary>
        [JsonProperty(PropertyName = "idReceipt", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string IdReceipt { get; set; }

        /// <summary>
        /// Total payments available.
        /// </summary>
        [JsonProperty(PropertyName = "totalResults", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public int TotalResults { get => ResultList.Count; }

        /// <summary>
        /// List of values.
        /// </summary>
        [JsonProperty(PropertyName = "resultList", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ICollection<PaymentMethod> ResultList { get; set; } = new List<PaymentMethod>();
    }
}

﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Model
{
    [Serializable]
    public class ProcessErrorExceptionCore
    {
        [Serializable]
        public class InnerErrorCore
        {
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ErrorType { get; set; }

            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ErrorCode { get; set; }

            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ErrorMessage { get; set; }

        }

        private string ErrorType { get; set; }

        private string ErrorCode { get; set; }

        private string ErrorMessage { get; set; }

        [JsonProperty(PropertyName = "Errors", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]

        public IEnumerable<InnerErrorCore> Errors { get; set; }
    }
}




﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Constants.CommonEnums;

namespace INS.PT.WebAPI.Models.AgentsPortal
{
    public class UploadDocumentWaspInput
    {
        [JsonProperty(PropertyName = "Uploadby", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public UploadBy Uploadby { get; set; }

        [JsonProperty(PropertyName = "Number", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Number { get; set; } = String.Empty;

        [JsonProperty(PropertyName = "Company", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public Company Company { get; set; }

        [JsonProperty(PropertyName = "DocType", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DocType { get; set; } = String.Empty;

        [JsonProperty(PropertyName = "File", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string File { get; set; } = String.Empty;

        [JsonProperty(PropertyName = "FileName", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string FileName { get; set; } = String.Empty;

        [JsonProperty(PropertyName = "User", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string User { get; set; } = String.Empty;
    }
}

﻿using INS.PT.WebAPI.Models.AgentsPortal.CommercialStructure.Element;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommercialStructure
{
    /// <summary>
    /// AgentClassificationWaspOutput
    /// </summary>
    public class AgentClassificationWaspOutput
    {
        /// <summary>
        /// Gets or sets the agent code.
        /// </summary>
        /// <value>
        /// The agent code.
        /// </value>
        public string AgentCode { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>
        /// The type.
        /// </value>
        public AgentClassificationTypeElement Type { get; set; }

        /// <summary>
        /// Gets or sets the classifications.
        /// </summary>
        /// <value>
        /// The classifications.
        /// </value>
        public ICollection<ClassificationElement> Classifications { get; set; }
    }
}

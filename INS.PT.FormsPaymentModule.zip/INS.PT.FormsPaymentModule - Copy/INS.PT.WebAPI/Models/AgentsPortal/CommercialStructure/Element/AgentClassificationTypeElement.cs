﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommercialStructure.Element
{
    /// <summary>
    /// AgentClassificationTypeElement
    /// </summary>
    public class AgentClassificationTypeElement
    {
        /// <summary>
        /// Gets or sets the agent type code.
        /// </summary>
        /// <value>
        /// The agent type code.
        /// </value>
        public string AgentTypeCode { get; set; }

        /// <summary>
        /// Gets or sets the agent type description.
        /// </summary>
        /// <value>
        /// The agent type description.
        /// </value>
        public string AgentTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets the start date.
        /// </summary>
        /// <value>
        /// The start date.
        /// </value>
        public System.DateTime? StartDate { get; set; }

        /// <summary>
        /// Gets or sets the end date.
        /// </summary>
        /// <value>
        /// The end date.
        /// </value>
        public System.DateTime? EndDate { get; set; }
    }
}

﻿using Newtonsoft.Json;
using System;

namespace INS.PT.WebAPI.Models.Collections
{
    /// <summary>
    /// ReceiptElement - Maps with DTO: ZfscdPcRecibosLinhaDTO
    /// </summary>
    public class ReceiptElement
    {
        /// <summary>
        /// Gets or Sets InsuranceBroker
        /// </summary>
        [JsonProperty(PropertyName = "insuranceBroker", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceBroker { get; set; } = String.Empty;

        /// <summary>
        /// Gets or Sets CompanyCode
        /// </summary>
        [JsonProperty(PropertyName = "companyCode", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyCode { get; set; } = String.Empty;

        /// <summary>
        /// Gets or Sets DocumentType
        /// </summary>
        [JsonProperty(PropertyName = "documentType", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DocumentType { get; set; } = String.Empty;

        /// <summary>
        /// Gets or Sets ReferenceDocumentNumber
        /// </summary>
        [JsonProperty(PropertyName = "referenceDocumentNumber", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceDocumentNumber { get; set; } = String.Empty;

        /// <summary>
        /// Gets or Sets SapDocumentNumber
        /// </summary>
        [JsonProperty(PropertyName = "sapDocumentNumber", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SapDocumentNumber { get; set; } = String.Empty;

        /// <summary>
        /// Gets or Sets DocumentNumber
        /// </summary>
        [JsonProperty(PropertyName = "documentNumber", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DocumentNumber { get; set; } = String.Empty;

        /// <summary>
        /// Gets or Sets InsurancePartner
        /// </summary>
        [JsonProperty(PropertyName = "insurancePartner", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsurancePartner { get; set; } = String.Empty;

        /// <summary>
        /// Gets or Sets InsuranceObject
        /// </summary>
        [JsonProperty(PropertyName = "insuranceObject", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceObject { get; set; } = String.Empty;

        /// <summary>
        /// Gets or Sets Amount
        /// </summary>
        [JsonProperty(PropertyName = "amount", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public double? Amount { get; set; } = 0;

        /// <summary>
        /// Gets or Sets Currency
        /// </summary>
        [JsonProperty(PropertyName = "currency", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Currency { get; set; } = String.Empty;

        /// <summary>
        /// Gets or Sets VwReference
        /// </summary>
        [JsonProperty(PropertyName = "vwReference", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string VwReference { get; set; } = String.Empty;

        /// <summary>
        /// Gets or Sets VwPolicy
        /// </summary>
        [JsonProperty(PropertyName = "vwPolicy", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string VwPolicy { get; set; } = String.Empty;

        /// <summary>
        /// Gets or Sets VwPostDate
        /// </summary>
        [JsonProperty(PropertyName = "vwPostDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string VwPostDate { get; set; } = String.Empty;

        /// <summary>
        /// Gets or Sets VwNetDueDate
        /// </summary>
        [JsonProperty(PropertyName = "vwNetDueDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string VwNetDueDate { get; set; } = String.Empty;
    }
}
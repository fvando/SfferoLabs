﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA
{
    
        /// <summary>
        /// ZageasLifeUpdProposalWs
        /// </summary>
        public class ZageasLifeUpdProposalWs
        {
            /// <summary>
            /// Gets or sets the proposal.
            /// </summary>
            /// <value>
            /// The proposal.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public ZeupdProposal Proposal { get; set; }
        }

        /// <summary>
        /// ZeupdProposal
        /// </summary>
        public class ZeupdProposal
        {
            /// <summary>
            /// Gets or sets the proposal number.
            /// </summary>
            /// <value>
            /// The proposal number.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ProposalNumber { get; set; }

            /// <summary>
            /// Gets or sets the value.
            /// </summary>
            /// <value>
            /// The value.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string Value { get; set; }

            /// <summary>
            /// Gets or sets the status.
            /// </summary>
            /// <value>
            /// The status.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string Status { get; set; }

            /// <summary>
            /// Gets or sets the data limite.
            /// </summary>
            /// <value>
            /// The data limite.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string DataLimite { get; set; }

            /// <summary>
            /// Gets or sets the sibs entity.
            /// </summary>
            /// <value>
            /// The sibs entity.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string SibsEntity { get; set; }

            /// <summary>
            /// Gets or sets the sibs reference.
            /// </summary>
            /// <value>
            /// The sibs reference.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string SibsReference { get; set; }

            /// <summary>
            /// Gets or sets the phone identifier.
            /// </summary>
            /// <value>
            /// The phone identifier.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string PhoneId { get; set; }

            /// <summary>
            /// Gets or sets the terminal identifier.
            /// </summary>
            /// <value>
            /// The terminal identifier.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string TerminalId { get; set; }

            /// <summary>
            /// Gets or sets the nep.
            /// </summary>
            /// <value>
            /// The nep.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string Nep { get; set; }
    }

        /// <summary>
        /// ZfscdCodigosErroLinhaUpdProposal
        /// </summary>
        public class ZfscdCodigosErroLinhaUpdProposal
        {
            /// <summary>
            /// Gets or sets the error code.
            /// </summary>
            /// <value>
            /// The error code.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ErrorCode { get; set; }

            /// <summary>
            /// Gets or sets the error code text.
            /// </summary>
            /// <value>
            /// The error code text.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ErrorCodeTxt { get; set; }
        }

        /// <summary>
        /// ZageasLifeUpdProposalWsResponse
        /// </summary>
        public class ZageasLifeUpdProposalWsResponse
        {
            /// <summary>
            /// Gets or sets the errors.
            /// </summary>
            /// <value>
            /// The errors.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public ZfscdCodigosErroLinhaUpdProposal Errors { get; set; }

            /// <summary>
            /// Gets or sets the proposal.
            /// </summary>
            /// <value>
            /// The proposal.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public ZeupdProposal Proposal { get; set; }
        }

        /// <summary>
        /// ZageasLifeUpdProposalWsRequest
        /// </summary>
        public class ZageasLifeUpdProposalWsRequest
        {
            /// <summary>
            /// The zageas life upd proposal ws
            /// </summary>
            public INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWs ZageasLifeUpdProposalWs;

            /// <summary>
            /// Initializes a new instance of the <see cref="ZageasLifeUpdProposalWsRequest"/> class.
            /// </summary>
            public ZageasLifeUpdProposalWsRequest()
            {
            }

            /// <summary>
            /// Initializes a new instance of the <see cref="ZageasLifeUpdProposalWsRequest"/> class.
            /// </summary>
            /// <param name="ZageasLifeUpdProposalWs">The zageas life upd proposal ws.</param>
            public ZageasLifeUpdProposalWsRequest(INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWs ZageasLifeUpdProposalWs)
            {
                this.ZageasLifeUpdProposalWs = ZageasLifeUpdProposalWs;
            }
        }

        /// <summary>
        /// ZageasLifeUpdProposalWsResponse1
        /// </summary>
        public class ZageasLifeUpdProposalWsResponse1
        {
            /// <summary>
            /// The zageas life upd proposal ws response
            /// </summary>
            public INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWsResponse ZageasLifeUpdProposalWsResponse;

            /// <summary>
            /// Initializes a new instance of the <see cref="ZageasLifeUpdProposalWsResponse1"/> class.
            /// </summary>
            public ZageasLifeUpdProposalWsResponse1()
            {
            }

            /// <summary>
            /// Initializes a new instance of the <see cref="ZageasLifeUpdProposalWsResponse1"/> class.
            /// </summary>
            /// <param name="ZageasLifeUpdProposalWsResponse">The zageas life upd proposal ws response.</param>
            public ZageasLifeUpdProposalWsResponse1(INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWsResponse ZageasLifeUpdProposalWsResponse)
            {
                this.ZageasLifeUpdProposalWsResponse = ZageasLifeUpdProposalWsResponse;
            }
        }
}

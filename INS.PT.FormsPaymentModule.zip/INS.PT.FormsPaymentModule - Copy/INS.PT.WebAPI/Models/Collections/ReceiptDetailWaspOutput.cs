﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.Collections
{
    /// <summary>
    /// ReceiptDetailWaspOutput
    /// </summary>
    public class ReceiptDetailWaspOutput
    { 
        
        /// <summary>
      /// Gets or sets the errors.
      /// </summary>
      /// <value>Gets or sets the errors.</value>

        [JsonProperty("Errors", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public List<ErrorElement> Errors { get; set; }

        /// <summary>
        /// Gets or sets the receipts numbers.
        /// </summary>
        /// <value>Gets or sets the receipts numbers.</value>

        [JsonProperty("ReceiptsNumbers", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public List<DetailReceiptElement> ReceiptsNumbers { get; set; }
    }
}

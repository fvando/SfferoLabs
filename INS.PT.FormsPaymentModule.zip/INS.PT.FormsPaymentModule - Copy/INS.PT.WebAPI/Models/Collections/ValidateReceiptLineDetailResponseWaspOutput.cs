﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.Collections
{
    public partial class ValidateReceiptLineDetailResponseWaspOutput
    {
        /// <summary>
        /// Gets or sets the pc receipts.
        /// </summary>
        /// <value>
        /// The pc receipts.
        /// </value>
        [JsonProperty(PropertyName = "pcReceipts", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public List<ValidateReceiptDetailElements> PcReceipts { get; set; }
    }
}

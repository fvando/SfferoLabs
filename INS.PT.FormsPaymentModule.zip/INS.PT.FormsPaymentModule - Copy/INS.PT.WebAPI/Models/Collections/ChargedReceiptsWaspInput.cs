﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.Collections
{
    public class ChargedReceiptsWaspInput
    {
        /// <summary>
        /// Gets or Sets BrokerContract
        /// </summary>
        [JsonProperty(PropertyName = "brokerContract", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerContract { get; set; } = String.Empty;

        /// <summary>
        /// Gets or Sets PcReceipts
        /// </summary>
        [JsonProperty(PropertyName = "receipts", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public List<ReceiptElement> PcReceipts { get; set; }
    }
}

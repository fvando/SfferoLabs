﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.Collections
{
    public class ChargedStatusDetail
    {
        /// <summary>
        /// Gets or sets the error code text.
        /// </summary>
        /// <value>
        /// The error code text.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCodeTxt { get; set; }
        /// <summary>
        /// Gets or sets the error code.
        /// </summary>
        /// <value>
        /// The error code.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCode { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="ChargedStatusDetail"/> is situation.
        /// </summary>
        /// <value>
        ///   <c>true</c> if situation; otherwise, <c>false</c>.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public bool Situation { get; set; } = true;
    }
}

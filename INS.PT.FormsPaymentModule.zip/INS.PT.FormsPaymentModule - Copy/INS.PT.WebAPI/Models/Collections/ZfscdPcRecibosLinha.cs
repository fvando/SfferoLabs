﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.Collections
{
    /// <summary>
    /// ZfscdPcRecibosLinha
    /// </summary>
    public partial class ZfscdPcRecibosLinha
    {

        [JsonProperty(PropertyName = "InsuranceBroker", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceBroker { get; set; } = String.Empty;

        [JsonProperty(PropertyName = "CompanyCode", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CompanyCode { get; set; } = String.Empty;

        [JsonProperty(PropertyName = "DocumentType", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DocumentType { get; set; } = String.Empty;

        [JsonProperty(PropertyName = "ReferenceDocumentNumber", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceDocumentNumber { get; set; } = String.Empty;

        [JsonProperty(PropertyName = "SapDocumentNumber", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SapDocumentNumber { get; set; } = String.Empty;

        [JsonProperty(PropertyName = "DocumentNumber", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DocumentNumber { get; set; } = String.Empty;

        [JsonProperty(PropertyName = "InsurancePartner", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsurancePartner { get; set; } = String.Empty;

        [JsonProperty(PropertyName = "InsuranceObject", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceObject { get; set; } = String.Empty;

        [JsonProperty(PropertyName = "Amount", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal Amount { get; set; } = 0;

        [JsonProperty(PropertyName = "Currency", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Currency { get; set; } = String.Empty;

        [JsonProperty(PropertyName = "VwReference", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string VwReference { get; set; } = String.Empty;

        [JsonProperty(PropertyName = "VwPolicy", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string VwPolicy { get; set; } = String.Empty;

        [JsonProperty(PropertyName = "VwPostDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string VwPostDate { get; set; } = String.Empty;

        [JsonProperty(PropertyName = "VwNetDueDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string VwNetDueDate { get; set; } = String.Empty;
    }
}

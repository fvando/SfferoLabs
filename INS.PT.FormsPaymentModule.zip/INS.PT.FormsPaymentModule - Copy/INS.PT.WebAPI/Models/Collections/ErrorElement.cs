﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.Collections
{
    /// <summary>
    /// ErrorElement
    /// </summary>
    public class ErrorElement
    { 
        /// <summary>
      /// Gets or Sets ErrorCode
      /// </summary>
        [JsonProperty("ErrorCode", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCode { get; set; }

        /// <summary>
        /// Gets or Sets ErrorCodeTxt
        /// </summary>
        [JsonProperty("ErrorCodeTxt", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]

        public string ErrorCodeTxt { get; set; }
    }
}

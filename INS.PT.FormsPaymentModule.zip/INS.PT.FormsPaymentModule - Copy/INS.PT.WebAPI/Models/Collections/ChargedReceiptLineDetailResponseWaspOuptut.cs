﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.Collections
{
    /// <summary>
    /// ChargedReceiptLineDetailResponseWaspOuptut - Maps with DTO: ChargedReceiptLineDetailResponseDTO
    /// </summary>
    public class ChargedReceiptLineDetailResponseWaspOuptut
    {
        /// <summary>
        /// Gets or sets the pc receipts.
        /// </summary>
        /// <value>
        /// The pc receipts.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public List<ChargedReceiptDetailElements> PcReceipts { get; set; }

    }
}

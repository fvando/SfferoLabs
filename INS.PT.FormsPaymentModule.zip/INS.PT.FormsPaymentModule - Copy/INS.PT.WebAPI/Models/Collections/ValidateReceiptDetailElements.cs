﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.Collections
{
    public class ValidateReceiptDetailElements : ReceiptElement
    {
        [JsonProperty(PropertyName = "Status", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]

        public List<ValidateStatusDetail> Status { get; set; }
    }
}
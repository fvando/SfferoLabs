﻿using INS.PT.WebAPI.Models.PaymentMPOS;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Constants.CommonEnums;

namespace INS.PT.WebAPI.Models.FinancialMPOS
{
    /// <summary>
    /// MBWayPaymentInputDTO
    /// </summary>
    public class MBWayPaymentInputDTO
    {
        /// <summary>
        /// Gets or sets the nif.
        /// </summary>
        /// <value>
        /// The nif.
        /// </value>
        [JsonProperty(PropertyName = "nif", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Nif { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the phone number.
        /// </summary>
        /// <value>
        /// The phone number.
        /// </value>
        [JsonProperty(PropertyName = "phoneNumber", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PhoneNumber { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the timestamp.
        /// </summary>
        /// <value>
        /// The timestamp.
        /// </value>
        [JsonProperty(PropertyName = "timestamp", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Timestamp { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the payment brand.
        /// </summary>
        /// <value>
        /// The payment brand.
        /// </value>
        [JsonProperty(PropertyName = "paymentBrand", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PaymentBrand { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the internal company.
        /// </summary>
        /// <value>
        /// The internal company.
        /// </value>
        [JsonProperty(PropertyName = "internalCompany", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InternalCompany { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the application origem identifier.
        /// </summary>
        /// <value>
        /// The application origem identifier.
        /// </value>
        [JsonProperty(PropertyName = "appOrigemId", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string AppOrigemId { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the total amount.
        /// </summary>
        /// <value>
        /// The total amount.
        /// </value>
        [JsonProperty(PropertyName = "totalAmount", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public Decimal? TotalAmount { get; set; }
        /// <summary>
        /// Gets or sets the user identifier.
        /// </summary>
        /// <value>
        /// The user identifier.
        /// </value>
        [JsonProperty(PropertyName = "userId", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string UserId { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the type of the print.
        /// </summary>
        /// <value>
        /// The type of the print.
        /// </value>
        [JsonProperty(PropertyName = "printType", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PrintType { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the receipts.
        /// </summary>
        /// <value>
        /// The receipts.
        /// </value>
        [JsonProperty(PropertyName = "receipts", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public List<PaymentReceipt> Receipts { get; set; }
        /// <summary>
        /// Gets or sets the third party.
        /// </summary>
        /// <value>
        /// The third party.
        /// </value>
        [JsonProperty(PropertyName = "thirdParty", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ThirdParty { get; set; } = String.Empty;

    }
}

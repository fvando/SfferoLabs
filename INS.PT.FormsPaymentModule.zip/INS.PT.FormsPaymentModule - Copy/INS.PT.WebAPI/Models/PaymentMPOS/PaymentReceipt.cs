﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.PaymentMPOS
{
    /// <summary>
    /// PaymentReceipt
    /// </summary>
    public class PaymentReceipt
    {
        /// <summary>
        /// Gets or sets the policy.
        /// </summary>
        /// <value>
        /// The policy.
        /// </value>
        [JsonProperty(PropertyName = "policy", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Policy { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the identifier receipt.
        /// </summary>
        /// <value>
        /// The identifier receipt.
        /// </value>
        [JsonProperty(PropertyName = "idReceipt", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string IdReceipt { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the prefix document.
        /// </summary>
        /// <value>
        /// The prefix document.
        /// </value>
        [JsonProperty(PropertyName = "prefixDoc", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PrefixDoc { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the amount.
        /// </summary>
        /// <value>
        /// The amount.
        /// </value>
        [JsonProperty(PropertyName = "amount", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? Amount { get; set; } = 0;
        /// <summary>
        /// Gets or sets the identifier document.
        /// </summary>
        /// <value>
        /// The identifier document.
        /// </value>
        [JsonProperty(PropertyName = "idDocument", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string IdDocument { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets a value indicating whether [third party].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [third party]; otherwise, <c>false</c>.
        /// </value>
        [JsonProperty(PropertyName = "thirdParty", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public bool ThirdParty { get; set; } = false;

    }
}

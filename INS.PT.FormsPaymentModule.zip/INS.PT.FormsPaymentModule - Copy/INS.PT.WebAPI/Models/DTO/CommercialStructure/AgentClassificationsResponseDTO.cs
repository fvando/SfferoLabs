﻿using INS.PT.WebAPI.Models.AgentsPortal.CommercialStructure.Element;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.CommercialStructure
{
    /// <summary>
    /// AgentClassificationsResponseDTO
    /// </summary>
    public class AgentClassificationsResponseDTO
    {
        /// <summary>
        /// Gets or sets the classifications.
        /// </summary>
        /// <value>
        /// The classifications.
        /// </value>
        [JsonProperty(PropertyName = "classifications")]
        public ICollection<ClassificationElement> Classifications { get; set; }
    }
}

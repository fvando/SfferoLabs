﻿using INS.PT.WebAPI.Models.DTO.CommercialStructure.Element;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.CommercialStructure
{
    /// <summary>
    /// AgentClassificationDTO
    /// </summary>
    public class AgentClassificationDTO
    {
        /// <summary>
        /// Gets or sets the agent code.
        /// </summary>
        /// <value>
        /// The agent code.
        /// </value>
        public string AgentCode { get; set; }

        /// <summary>
        /// Gets or sets the type.
        /// </summary>
        /// <value>
        /// The type.
        /// </value>
        public AgentClassificationTypeDTO Type { get; set; }

        /// <summary>
        /// Gets or sets the classifications.
        /// </summary>
        /// <value>
        /// The classifications.
        /// </value>
        public ICollection<ClassificationDTO> Classifications { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Domain
{
    public class Email
    {
        /// <summary>
        /// Identifier.
        /// </summary>
        /// <example>1</example>
        public int? EmailIdentifier { get; set; }

        /// <summary>
        /// Email type code.
        /// </summary>
        /// <example>PO</example>
        public string EmailTypeCode { get; set; }

        /// <summary>
        /// Email type description.
        /// </summary>
        /// <example>E-Mail profissional</example>
        public string EmailTypeDescription { get; set; }

        /// <summary>
        /// Address.
        /// </summary>
        /// <example>ruijorge.silva.externo@ageas.pt</example>
        public string EmailAddress { get; set; }

        /// <summary>
        /// Flag to the preferred email.
        /// </summary>
        /// <example>true</example>
        public bool IsPreferred { get; set; }
    }
}

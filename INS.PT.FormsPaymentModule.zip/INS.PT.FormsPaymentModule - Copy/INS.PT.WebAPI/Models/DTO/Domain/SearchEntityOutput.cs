﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Domain
{
    public class SearchEntityOutput
    {
        public ICollection<SimpleEntity> MatchedEntities { get; set; } = new List<SimpleEntity>();
    }
}

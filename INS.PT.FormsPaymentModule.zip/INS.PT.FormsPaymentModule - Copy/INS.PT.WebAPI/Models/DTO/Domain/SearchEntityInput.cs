﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Domain
{
    public class SearchEntityInput
    {
        /// <summary>
        /// Vat number to be searched.
        /// </summary>
        /// <example></example>
        [FromBody]
        public string VatNumber { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Domain
{
    public class AddressTipology
    {
        /// <summary>
        /// Postal address.
        /// </summary>
        public PoAddress PostalAddress { get; set; }

        /// <summary>
        /// Postal Box.
        /// </summary>
        public PoBox PostalBox { get; set; }
    }
}

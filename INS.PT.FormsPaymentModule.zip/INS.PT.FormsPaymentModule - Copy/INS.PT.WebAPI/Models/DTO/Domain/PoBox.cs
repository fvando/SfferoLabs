﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Domain
{
    public class PoBox
    {
        /// <summary>
        /// Po box number.
        /// </summary>
        /// <example>43234</example>
        public string Number { get; set; }

        /// <summary>
        /// Post office name.
        /// </summary>
        /// <example>Torres Vedras</example>
        public string PostOfficeName { get; set; }
    }
}
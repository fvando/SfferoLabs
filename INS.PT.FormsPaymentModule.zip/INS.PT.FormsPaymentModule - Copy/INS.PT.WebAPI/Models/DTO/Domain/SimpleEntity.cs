﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Domain
{
    public class SimpleEntity
    {

        /// <summary>
        /// Company id.
        /// </summary>
        /// <example>AGEAS</example>
        public string IdCompany { get; set; }

        /// <summary>
        /// Network id.
        /// </summary>
        /// <example>AGEAS</example>
        public string IdNetwork { get; set; }

        /// <summary>
        /// Entity id.
        /// </summary>
        /// <example>2233</example>
        public string IdEntity { get; set; }

        /// <summary>
        /// Name.
        /// </summary>
        /// <example>Test entity</example>
        public string Name { get; set; }

        /// <summary>
        /// Vat number.
        /// </summary>
        /// <example>500123123</example>
        public string VatNumber { get; set; }

        /// <summary>
        /// Birthdate.
        /// </summary>
        /// <example>2019-06-14T10:13:27.475Z</example>
        public DateTime? Birthdate { get; set; }

        /// <summary>
        /// Gets or sets the addresses.
        /// </summary>
        /// <value>
        /// The addresses.
        /// </value>
        public IEnumerable<Address> Addresses { get; set; }

        /// <summary>
        /// Entity type.
        /// </summary>
        /// <example>P</example>
        public string EntityType { get; set; }

        /// <summary>
        /// Entity phone.
        /// </summary>
        /// <example>212321321</example>
        public string EntityPhone { get; set; }

        /// <summary>
        /// Entity Caes.
        /// </summary>
        public IEnumerable<SimpleCae> Caes { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Domain
{
    public class Phone
    {
        /// <summary>
        /// Identifier.
        /// </summary>
        /// <example>Permanente</example>
        public string PhoneIdentifier { get; set; }

        /// <summary>
        /// Phone type code.
        /// </summary>
        /// <example>MOB</example>
        public string PhoneTypeCode { get; set; }

        /// <summary>
        /// Phone type description.
        /// </summary>
        /// <example>Telemovel</example>
        public string PhoneTypeDescription { get; set; }

        /// <summary>
        /// Number.
        /// </summary>
        /// <example>921345890</example>
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Flag to the preferred phone.
        /// </summary>
        /// <example>true</example>
        public bool IsPreferred { get; set; }
    }
}

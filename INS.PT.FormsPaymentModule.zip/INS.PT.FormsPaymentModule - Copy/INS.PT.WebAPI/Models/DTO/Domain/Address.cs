﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Domain
{
    public class Address
    {
        /// <summary>
        /// Sequence.
        /// </summary>
        /// <example>1</example>
        public string Sequence { get; set; }

        /// <summary>
        /// Address type.
        /// </summary>
        /// <example>S</example>
        public string AddressType { get; set; }

        /// <summary>
        /// Address type description.
        /// </summary>
        /// <example>Sede</example>
        public string AddressTypeDescription { get; set; }

        /// <summary>
        /// Flag to indicate the Fiscal address.
        /// </summary>
        /// <example>true</example>
        public bool IsFiscalAddress { get; set; }

        /// <summary>
        /// Format type.
        /// </summary>
        /// <example>L</example>
        public string FormatType { get; set; }

        /// <summary>
        /// Tipology.
        /// </summary>
        public AddressTipology Tipology { get; set; }

        /// <summary>
        /// Flag that indicates address needs correction.
        /// </summary>
        /// <example>false</example>
        public bool IsReturnedForCorrection { get; set; }

        /// <summary>
        /// Postal code.
        /// </summary>
        /// <example>2590</example>
        public string PostalCode { get; set; }

        /// <summary>
        /// Postal code description.
        /// </summary>
        /// <example>Torres Vedras</example>
        public string PostalCodeDescription { get; set; }

        /// <summary>
        /// Country code.
        /// </summary>
        /// <example>1</example>
        public string CountryCode { get; set; }

        /// <summary>
        /// Country description.
        /// </summary>
        /// <example>Portugal</example>
        public string CountryDescription { get; set; }

        /// <summary>
        /// Georeference.
        /// </summary>
        /// <example>123.22;43.21</example>
        public string Georeference { get; set; }
    }
}

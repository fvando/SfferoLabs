﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Domain
{
    public class SimpleCae
    {
        /// <summary>
        /// Cae order.
        /// </summary>
        /// <example>1</example>
        public int OrderNumber { get; set; }

        /// <summary>
        /// CAE.
        /// </summary>
        /// <example>47845</example>
        [JsonProperty("cae")]
        public string CaeNumber { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        /// <example>2019-05-02T14:13:27.475Z</example>
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Flag for the principal CAE.
        /// </summary>
        /// <example>true</example>
        public bool IsPrincipal { get; set; }
    }
}

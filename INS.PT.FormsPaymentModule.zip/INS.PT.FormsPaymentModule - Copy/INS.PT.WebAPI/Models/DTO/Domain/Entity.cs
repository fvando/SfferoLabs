﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Domain
{
    public class Entity 
    {
        /// <summary>
        /// Entity id.
        /// </summary>
        /// <example>2233</example>
        public string IdEntity { get; set; }

        /// <summary>
        /// Vat number.
        /// </summary>
        /// <example>500123123</example>
        public string VatNumber { get; set; }

        /// <summary>
        /// Flag that indicates Vat is foreign.
        /// </summary>
        /// <example>false</example>
        public bool IsForeignVat { get; set; }

        /// <summary>
        /// Country code.
        /// </summary>
        /// <example>1</example>
        public string CountryCode { get; set; }

        /// <summary>
        /// Country name.
        /// </summary>
        /// <example>Portugal</example>
        public string CountryDescription { get; set; }
 
        /// <summary>
        /// Lists of all contacts types.
        /// </summary>
        public ContactLists Contacts { get; set; } = new ContactLists();
 
    }
}

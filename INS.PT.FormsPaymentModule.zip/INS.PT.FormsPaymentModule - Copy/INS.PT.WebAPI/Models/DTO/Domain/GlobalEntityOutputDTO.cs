﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Domain
{
    public class GlobalEntityOutputDTO
    {
        [JsonProperty(PropertyName = "totalResults")]
        public string totalResults { get; set; }

        [JsonProperty(PropertyName = "resultList")]
        public List<GlobalEntityElementsRamoDTO> resultList { get; set; }

        [JsonProperty(PropertyName = "pageSize")]
        public string PageSize { get; set; }

        [JsonProperty(PropertyName = "pageNumber")]
        public string PageNumber { get; set; }
    }
}

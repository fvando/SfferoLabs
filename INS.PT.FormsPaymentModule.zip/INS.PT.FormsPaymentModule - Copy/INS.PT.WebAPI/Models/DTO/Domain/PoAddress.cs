﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Domain
{
    public class PoAddress
    {
        /// <summary>
        /// Road type.
        /// </summary>
        /// <example>RUA</example>
        public string RoadType { get; set; }

        /// <summary>
        /// Road name.
        /// </summary>
        /// <example>25 de Abril</example>
        public string RoadName { get; set; }

        /// <summary>
        /// House number.
        /// </summary>
        /// <example>3</example>
        public string HouseNumber { get; set; }

        /// <summary>
        /// Floor number.
        /// </summary>
        /// <example>5ºF</example>
        public string FloorNumber { get; set; }

        /// <summary>
        /// Door number.
        /// </summary>
        /// <example>23</example>
        public string DoorNumber { get; set; }

        /// <summary>
        /// Add to address.
        /// </summary>
        /// <example>Bairro de Abril</example>
        public string AddToAddress { get; set; }

        /// <summary>
        /// Full address.
        /// </summary>
        /// <example>Rua 25 de Abril, 23-3 5ºF</example>
        public string FullAddress { get; set; }

        /// <summary>
        /// Locality.
        /// </summary>
        /// <example>Manteigas</example>
        public string Locality { get; set; }
    }
}

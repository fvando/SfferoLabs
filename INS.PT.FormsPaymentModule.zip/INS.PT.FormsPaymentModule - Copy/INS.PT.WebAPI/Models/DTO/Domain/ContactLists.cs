﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Domain
{
    public class ContactLists 
    {
        /// <summary>
        /// List of phones.
        /// </summary>
        public IEnumerable<Phone> Phones { get; set; }

        /// <summary>
        /// List of emails.
        /// </summary>
        public IEnumerable<Email> Emails { get; set; }
 
    }
}

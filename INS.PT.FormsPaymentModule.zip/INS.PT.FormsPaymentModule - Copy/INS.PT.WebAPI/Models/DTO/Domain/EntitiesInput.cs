﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Domain
{
    public class EntitiesInput
    {
        /// <summary>
        /// Entity identity.
        /// </summary>
        /// <example>10592272</example>
        public string IdEntity { get; set; }
    }
}

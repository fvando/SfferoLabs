﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections
{
    /// <summary>
    /// ZfscdErrosReceiptsNumLineDTO
    /// </summary>
    public class ZfscdErrosReceiptsNumLineDTO
    { 
        
        /// <summary>
       /// Gets or sets the error code.
       /// </summary>
       /// <value>Gets or sets the error code.</value>

        [JsonProperty("error_code", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]

        public string ErrorCode { get; set; }

        /// <summary>
        /// Gets or sets the error code text.
        /// </summary>
        /// <value>Gets or sets the error code text.</value>

        [JsonProperty("error_code_txt", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]

        public string ErrorCodeTxt { get; set; }
    }
}

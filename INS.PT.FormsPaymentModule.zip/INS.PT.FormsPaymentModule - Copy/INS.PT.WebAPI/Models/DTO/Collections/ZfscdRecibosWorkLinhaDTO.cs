﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections
{
    /// <summary>
    /// ZfscdRecibosWorkLinhaDTO
    /// </summary>
    public class ZfscdRecibosWorkLinhaDTO
    {
        /// <summary>
        /// Gets or sets the company code.
        /// </summary>
        /// <value>
        /// The company code.
        /// </value>
        [JsonProperty("companyCode", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]

        public string CompanyCode { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the sap document number.
        /// </summary>
        /// <value>
        /// The sap document number.
        /// </value>
        [JsonProperty("sapDocumentNumber", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SapDocumentNumber { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the type of the document.
        /// </summary>
        /// <value>
        /// The type of the document.
        /// </value>
        [JsonProperty("documentType", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DocumentType { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the contract.
        /// </summary>
        /// <value>
        /// The contract.
        /// </value>
        [JsonProperty("contract", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Contract { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the reference document number.
        /// </summary>
        /// <value>
        /// The reference document number.
        /// </value>
        [JsonProperty("referenceDocumentNumber", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReferenceDocumentNumber { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the insurance partner.
        /// </summary>
        /// <value>
        /// The insurance partner.
        /// </value>
        [JsonProperty("insurancePartner", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsurancePartner { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the tax number.
        /// </summary>
        /// <value>
        /// The tax number.
        /// </value>
        [JsonProperty("taxnum", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string TaxNum { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the full name.
        /// </summary>
        /// <value>
        /// The full name.
        /// </value>
        [JsonProperty("fullName", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string FullName { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the insurance payer.
        /// </summary>
        /// <value>
        /// The insurance payer.
        /// </value>
        [JsonProperty("insurancePayer", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsurancePayer { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the insurance agent.
        /// </summary>
        /// <value>
        /// The insurance agent.
        /// </value>
        [JsonProperty("insuranceAgent", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceAgent { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the insurance broker.
        /// </summary>
        /// <value>
        /// The insurance broker.
        /// </value>
        [JsonProperty("insuranceBroker", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceBroker { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the insurance inspector.
        /// </summary>
        /// <value>
        /// The insurance inspector.
        /// </value>
        [JsonProperty("insuranceInspector", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceInspector { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the insurance other.
        /// </summary>
        /// <value>
        /// The insurance other.
        /// </value>
        [JsonProperty("insuranceOther", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceOther { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the signal.
        /// </summary>
        /// <value>
        /// The signal.
        /// </value>
        [JsonProperty("signal", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Signal { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the type of the receipt.
        /// </summary>
        /// <value>
        /// The type of the receipt.
        /// </value>
        [JsonProperty("receiptType", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReceiptType { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the receipt type text.
        /// </summary>
        /// <value>
        /// The receipt type text.
        /// </value>
        [JsonProperty("receiptTypeTxt", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReceiptTypeTxt { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the registration number.
        /// </summary>
        /// <value>
        /// The registration number.
        /// </value>
        [JsonProperty("registrationNumber", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string RegistrationNumber { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the emission date.
        /// </summary>
        /// <value>
        /// The emission date.
        /// </value>
        [JsonProperty("emissionDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string EmissionDate { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the emission hour.
        /// </summary>
        /// <value>
        /// The emission hour.
        /// </value>
        [JsonProperty("emissionHour", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string EmissionHour { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the posting date.
        /// </summary>
        /// <value>
        /// The posting date.
        /// </value>
        [JsonProperty("postingDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PostingDate { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the net due date.
        /// </summary>
        /// <value>
        /// The net due date.
        /// </value>
        [JsonProperty("netDueDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string NetDueDate { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the billing period from.
        /// </summary>
        /// <value>
        /// The billing period from.
        /// </value>
        [JsonProperty("billingPeriodFrom", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BillingPeriodFrom { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the billing period to.
        /// </summary>
        /// <value>
        /// The billing period to.
        /// </value>
        [JsonProperty("billingPeriodTo", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BillingPeriodTo { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the payment order.
        /// </summary>
        /// <value>
        /// The payment order.
        /// </value>
        [JsonProperty("paymentOrder", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PaymentOrder { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the clearing reason.
        /// </summary>
        /// <value>
        /// The clearing reason.
        /// </value>
        [JsonProperty("clearingReason", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ClearingReason { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the clearing status.
        /// </summary>
        /// <value>
        /// The clearing status.
        /// </value>
        [JsonProperty("clearingStatus", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ClearingStatus { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the clearing document.
        /// </summary>
        /// <value>
        /// The clearing document.
        /// </value>
        [JsonProperty("clearingDocument", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ClearingDocument { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the clearing post date.
        /// </summary>
        /// <value>
        /// The clearing post date.
        /// </value>
        [JsonProperty("clearingPostDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ClearingPostDate { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the status document.
        /// </summary>
        /// <value>
        /// The status document.
        /// </value>
        [JsonProperty("statusDoc", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string StatusDoc { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        [JsonProperty("status", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the status text.
        /// </summary>
        /// <value>
        /// The status text.
        /// </value>
        [JsonProperty("statusTxt", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string StatusTxt { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the status date.
        /// </summary>
        /// <value>
        /// The status date.
        /// </value>
        [JsonProperty("statusDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string StatusDate { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the print date.
        /// </summary>
        /// <value>
        /// The print date.
        /// </value>
        [JsonProperty("printDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PrintDate { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the type of the insurance.
        /// </summary>
        /// <value>
        /// The type of the insurance.
        /// </value>
        [JsonProperty("insuranceType", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceType { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the insurance type text.
        /// </summary>
        /// <value>
        /// The insurance type text.
        /// </value>
        [JsonProperty("insuranceTypeTxt", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string InsuranceTypeTxt { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the product group.
        /// </summary>
        /// <value>
        /// The product group.
        /// </value>
        [JsonProperty("productGroup", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ProductGroup { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the product group text.
        /// </summary>
        /// <value>
        /// The product group text.
        /// </value>
        [JsonProperty("productGroupTxt", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ProductGroupTxt { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the type of the payment split.
        /// </summary>
        /// <value>
        /// The type of the payment split.
        /// </value>
        [JsonProperty("paymentSplitType", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PaymentSplitType { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the payment split type text.
        /// </summary>
        /// <value>
        /// The payment split type text.
        /// </value>
        [JsonProperty("paymentSplitTypeTxt", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PaymentSplitTypeTxt { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the payment method.
        /// </summary>
        /// <value>
        /// The payment method.
        /// </value>
        [JsonProperty("paymentMethod", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PaymentMethod { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the payment method text.
        /// </summary>
        /// <value>
        /// The payment method text.
        /// </value>
        [JsonProperty("paymentMethodTxt", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PaymentMethodTxt { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the billing channel.
        /// </summary>
        /// <value>
        /// The billing channel.
        /// </value>
        [JsonProperty("billingChannel", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BillingChannel { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the billing channel text.
        /// </summary>
        /// <value>
        /// The billing channel text.
        /// </value>
        [JsonProperty("billingChannelTxt", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BillingChannelTxt { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the return reason.
        /// </summary>
        /// <value>
        /// The return reason.
        /// </value>
        [JsonProperty("returnReason", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReturnReason { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the return date.
        /// </summary>
        /// <value>
        /// The return date.
        /// </value>
        [JsonProperty("returnDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReturnDate { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the currency.
        /// </summary>
        /// <value>
        /// The currency.
        /// </value>
        [JsonProperty("currency", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Currency { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the premium value.
        /// </summary>
        /// <value>
        /// The premium value.
        /// </value>
        [JsonProperty("premiumValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? PremiumValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the charges value.
        /// </summary>
        /// <value>
        /// The charges value.
        /// </value>
        [JsonProperty("chargesValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? ChargesValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the bonus value.
        /// </summary>
        /// <value>
        /// The bonus value.
        /// </value>
        [JsonProperty("bonusValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? BonusValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the atas value.
        /// </summary>
        /// <value>
        /// The atas value.
        /// </value>
        [JsonProperty("atasValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? AtasValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the inem value.
        /// </summary>
        /// <value>
        /// The inem value.
        /// </value>
        [JsonProperty("inemValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? InemValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the fga value.
        /// </summary>
        /// <value>
        /// The fga value.
        /// </value>
        [JsonProperty("fgaValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? FgaValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the green letter value.
        /// </summary>
        /// <value>
        /// The green letter value.
        /// </value>
        [JsonProperty("greenLetterValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? GreenLetterValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the anpc value.
        /// </summary>
        /// <value>
        /// The anpc value.
        /// </value>
        [JsonProperty("anpcValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? AnpcValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the seal value.
        /// </summary>
        /// <value>
        /// The seal value.
        /// </value>
        [JsonProperty("sealValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? SealValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the policy value.
        /// </summary>
        /// <value>
        /// The policy value.
        /// </value>
        [JsonProperty("policyValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? PolicyValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the fat value.
        /// </summary>
        /// <value>
        /// The fat value.
        /// </value>
        [JsonProperty("fatValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? FatValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the PRP value.
        /// </summary>
        /// <value>
        /// The PRP value.
        /// </value>
        [JsonProperty("prpValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? PrpValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the fractioning value.
        /// </summary>
        /// <value>
        /// The fractioning value.
        /// </value>
        [JsonProperty("fractioningValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? FractioningValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the calamity value.
        /// </summary>
        /// <value>
        /// The calamity value.
        /// </value>
        [JsonProperty("calamityValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? CalamityValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the late payment value.
        /// </summary>
        /// <value>
        /// The late payment value.
        /// </value>
        [JsonProperty("latePaymentValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? LatePaymentValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the medical exam value.
        /// </summary>
        /// <value>
        /// The medical exam value.
        /// </value>
        [JsonProperty("medicalExamValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? MedicalExamValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the tgis value.
        /// </summary>
        /// <value>
        /// The tgis value.
        /// </value>
        [JsonProperty("tgisValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? TgisValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the total add value.
        /// </summary>
        /// <value>
        /// The total add value.
        /// </value>
        [JsonProperty("totalAddValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? TotalAddValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the total cost value.
        /// </summary>
        /// <value>
        /// The total cost value.
        /// </value>
        [JsonProperty("totalCostValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? TotalCostValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the total tax value.
        /// </summary>
        /// <value>
        /// The total tax value.
        /// </value>
        [JsonProperty("totalTaxValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? TotalTaxValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the total value.
        /// </summary>
        /// <value>
        /// The total value.
        /// </value>
        [JsonProperty("totalValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? TotalValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the commission promotion value.
        /// </summary>
        /// <value>
        /// The commission promotion value.
        /// </value>
        [JsonProperty("commissionPromotionValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? CommissionPromotionValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the commission charge value.
        /// </summary>
        /// <value>
        /// The commission charge value.
        /// </value>
        [JsonProperty("commissionChargeValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? CommissionChargeValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the commission inspection value.
        /// </summary>
        /// <value>
        /// The commission inspection value.
        /// </value>
        [JsonProperty("commissionInspectionValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? CommissionInspectionValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the commission agent value.
        /// </summary>
        /// <value>
        /// The commission agent value.
        /// </value>
        [JsonProperty("commissionAgentValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? CommissionAgentValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the commission other value.
        /// </summary>
        /// <value>
        /// The commission other value.
        /// </value>
        [JsonProperty("commissionOtherValue", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? CommissionOtherValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the total commission.
        /// </summary>
        /// <value>
        /// The total commission.
        /// </value>
        [JsonProperty("totalCommission", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? TotalCommission { get; set; } = 0;
        /// <summary>
        /// Gets or sets the policy capital.
        /// </summary>
        /// <value>
        /// The policy capital.
        /// </value>
        [JsonProperty("policyCapital", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public decimal? PolicyCapital { get; set; } = 0;
        /// <summary>
        /// Gets or sets the sibs entity.
        /// </summary>
        /// <value>
        /// The sibs entity.
        /// </value>
        [JsonProperty("sibsEntity", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SibsEntity { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the sibs reference.
        /// </summary>
        /// <value>
        /// The sibs reference.
        /// </value>
        [JsonProperty("sibsReference", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SibsReference { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the sibs due date.
        /// </summary>
        /// <value>
        /// The sibs due date.
        /// </value>
        [JsonProperty("sibsDueDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SibsDueDate { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the sibs due hour.
        /// </summary>
        /// <value>
        /// The sibs due hour.
        /// </value>
        [JsonProperty("sibsDueHour", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SibsDueHour { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the sibs status.
        /// </summary>
        /// <value>
        /// The sibs status.
        /// </value>
        [JsonProperty("sibsStatus", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SibsStatus { get; set; } = String.Empty;

        /// Gets or sets the banking circuit.
        /// </summary>
        /// <value>
        /// The banking circuit.
        /// </value>
        [JsonProperty("bankingCircuit", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BankingCircuit { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the bank details identifier.
        /// </summary>
        /// <value>
        /// The bank details identifier.
        /// </value>
        [JsonProperty("bankDetailsId", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BankDetailsId { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the bank designation.
        /// </summary>
        /// <value>
        /// The bank designation.
        /// </value>
        [JsonProperty("bankDesignation", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BankDesignation { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the broker report identification.
        /// </summary>
        /// <value>
        /// The broker report identification.
        /// </value>
        [JsonProperty("brokerReportIdentification", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerReportIdentification { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the premium category.
        /// </summary>
        /// <value>
        /// The premium category.
        /// </value>
        [JsonProperty("premiumCategory", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PremiumCategory { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the commission category.
        /// </summary>
        /// <value>
        /// The commission category.
        /// </value>
        [JsonProperty("commissionCategory", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CommissionCategory { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the claim category.
        /// </summary>
        /// <value>
        /// The claim category.
        /// </value>
        [JsonProperty("claimCategory", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ClaimCategory { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the cost category.
        /// </summary>
        /// <value>
        /// The cost category.
        /// </value>
        [JsonProperty("costCategory", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string CostCategory { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the type of the contract.
        /// </summary>
        /// <value>
        /// The type of the contract.
        /// </value>
        [JsonProperty("contractType", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ContractType { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the situation.
        /// </summary>
        /// <value>
        /// The situation.
        /// </value>
        [JsonProperty("situation", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Situation { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the situation date.
        /// </summary>
        /// <value>
        /// The situation date.
        /// </value>
        [JsonProperty("situationDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string SituationDate { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the original aplication.
        /// </summary>
        /// <value>
        /// The original aplication.
        /// </value>
        [JsonProperty("originalAplication", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string OriginalAplication { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the document identifier.
        /// </summary>
        /// <value>
        /// The document identifier.
        /// </value>
        [JsonProperty("documentId", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string DocumentId { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the lock identifier.
        /// </summary>
        /// <value>
        /// The lock identifier.
        /// </value>
        [JsonProperty("lockId", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string LockId { get; set; } = String.Empty;

    }
}

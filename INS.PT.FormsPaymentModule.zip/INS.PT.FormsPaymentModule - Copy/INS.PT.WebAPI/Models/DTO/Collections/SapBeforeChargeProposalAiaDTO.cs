﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.Collections
{
     /// <summary>
        /// ZageasLifeGetBeforeChargeWs
        /// </summary>
        public class ZageasLifeGetBeforeChargeWs
        {
            /// <summary>
            /// Gets or sets the i proposal number.
            /// </summary>
            /// <value>
            /// The i proposal number.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string IProposalNumber { get; set; }

            /// <summary>
            /// Gets or sets the proposal.
            /// </summary>
            /// <value>
            /// The proposal.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public ZegetProposal Proposal { get; set; }
        }

        /// <summary>
        /// ZegetProposal
        /// </summary>
        public class ZegetProposal
        {
            /// <summary>
            /// Gets or sets the proposal number.
            /// </summary>
            /// <value>
            /// The proposal number.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ProposalNumber { get; set; }

            /// <summary>
            /// Gets or sets the value.
            /// </summary>
            /// <value>
            /// The value.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string Value { get; set; }

            /// <summary>
            /// Gets or sets the status.
            /// </summary>
            /// <value>
            /// The status.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string Status { get; set; }

            /// <summary>
            /// Gets or sets the creation date.
            /// </summary>
            /// <value>
            /// The creation date.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string CreationDate { get; set; }

            /// <summary>
            /// Gets or sets the creation time.
            /// </summary>
            /// <value>
            /// The creation time.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string CreationTime { get; set; }

            /// <summary>
            /// Gets or sets the edge date.
            /// </summary>
            /// <value>
            /// The edge date.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string EdgeDate { get; set; }

            /// <summary>
            /// Gets or sets the iban.
            /// </summary>
            /// <value>
            /// The iban.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string Iban { get; set; }
        }

        /// <summary>
        /// ZfscdCodigosErroLinhaBeforeChargeAia
        /// </summary>
        public class ZfscdCodigosErroLinhaBeforeChargeAia
        {
            /// <summary>
            /// Gets or sets the error code.
            /// </summary>
            /// <value>
            /// The error code.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ErrorCode { get; set; }

            /// <summary>
            /// Gets or sets the error code text.
            /// </summary>
            /// <value>
            /// The error code text.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ErrorCodeTxt { get; set; }
        }

        /// <summary>
        /// ZageasLifeGetBeforeChargeWsResponse
        /// </summary>
        public class ZageasLifeGetBeforeChargeWsResponse
        {
            /// <summary>
            /// Gets or sets the proposal.
            /// </summary>
            /// <value>
            /// The proposal.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public ZegetProposal Proposal { get; set; }

            /// <summary>
            /// Gets or sets the errors.
            /// </summary>
            /// <value>
            /// The errors.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public ZfscdCodigosErroLinhaBeforeChargeAia Errors { get; set; }

        }

        /// <summary>
        /// ZageasLifeGetBeforeChargeWsRequest
        /// </summary>
        public class ZageasLifeGetBeforeChargeWsRequest
        {
            /// <summary>
            /// The zageas life get before charge ws
            /// </summary>
            public INS.PT.WebAPI.Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWs ZageasLifeGetBeforeChargeWs;

            /// <summary>
            /// Initializes a new instance of the <see cref="ZageasLifeGetBeforeChargeWsRequest"/> class.
            /// </summary>
            public ZageasLifeGetBeforeChargeWsRequest()
            {
            }

            /// <summary>
            /// Initializes a new instance of the <see cref="ZageasLifeGetBeforeChargeWsRequest"/> class.
            /// </summary>
            /// <param name="ZageasLifeGetBeforeChargeWs">The zageas life get before charge ws.</param>
            public ZageasLifeGetBeforeChargeWsRequest(INS.PT.WebAPI.Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWs ZageasLifeGetBeforeChargeWs)
            {
                this.ZageasLifeGetBeforeChargeWs = ZageasLifeGetBeforeChargeWs;
            }
        }

        /// <summary>
        /// ZageasLifeGetBeforeChargeWsResponse1
        /// </summary>
        public class ZageasLifeGetBeforeChargeWsResponse1
        {
            /// <summary>
            /// The zageas life get before charge ws response
            /// </summary>
            public INS.PT.WebAPI.Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse ZageasLifeGetBeforeChargeWsResponse;

            /// <summary>
            /// Initializes a new instance of the <see cref="ZageasLifeGetBeforeChargeWsResponse1"/> class.
            /// </summary>
            public ZageasLifeGetBeforeChargeWsResponse1()
            {
            }

            /// <summary>
            /// Initializes a new instance of the <see cref="ZageasLifeGetBeforeChargeWsResponse1"/> class.
            /// </summary>
            /// <param name="ZageasLifeGetBeforeChargeWsResponse">The zageas life get before charge ws response.</param>
            public ZageasLifeGetBeforeChargeWsResponse1(INS.PT.WebAPI.Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse ZageasLifeGetBeforeChargeWsResponse)
            {
                this.ZageasLifeGetBeforeChargeWsResponse = ZageasLifeGetBeforeChargeWsResponse;
            }
        }
}

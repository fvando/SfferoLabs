﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections
{
    /// <summary>
    /// ZFscdRecibosListarWsResponseDTO
    /// </summary>
    public class ZFscdRecibosListarWsResponseDTO
    {
        /// <summary>
        /// Gets or sets the response.
        /// </summary>
        /// <value>Gets or sets the response.</value>
        [JsonProperty("ZFscdRecibosListarWsResponse", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZFscdRecibosListarWsDTO ZFscdRecibosListarWsResponse { get; set; }
    }
}

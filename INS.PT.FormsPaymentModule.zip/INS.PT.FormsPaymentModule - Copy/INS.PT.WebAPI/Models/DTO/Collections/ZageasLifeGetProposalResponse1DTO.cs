﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections
{
    public class ZageasLifeGetProposalResponse1DTO
    {
        public ZeAiaProposalDTO Eproposal { get; set; }
        public ZfscdCodigosErroLinhaDTO Errors { get; set; }

    }
}

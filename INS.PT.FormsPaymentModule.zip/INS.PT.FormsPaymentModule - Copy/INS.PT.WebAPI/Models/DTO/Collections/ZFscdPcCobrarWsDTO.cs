﻿using INS.PT.WebAPI.Models.DTO.Collections.Elements;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections
{
    public class ZFscdPcCobrarWsDTO
    {
        /// <summary>
        /// Gets or Sets BrokerContract
        /// </summary>
        [JsonProperty(PropertyName = "brokerContract", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string BrokerContract { get; set; } = String.Empty;

        /// <summary>
        /// Gets or Sets PcReceipts
        /// </summary>
        [JsonProperty(PropertyName = "pcReceipts", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public List<ZfscdPcRecibosLinhaDTO> PcReceipts { get; set; }
    }
}

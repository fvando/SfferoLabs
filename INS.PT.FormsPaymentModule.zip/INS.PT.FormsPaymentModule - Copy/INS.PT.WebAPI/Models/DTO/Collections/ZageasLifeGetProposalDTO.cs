﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections
{
    public class ZageasLifeGetProposalDTO
    {
        public ZeAiaProposalDTO Eproposal { get; set; }
    }
}

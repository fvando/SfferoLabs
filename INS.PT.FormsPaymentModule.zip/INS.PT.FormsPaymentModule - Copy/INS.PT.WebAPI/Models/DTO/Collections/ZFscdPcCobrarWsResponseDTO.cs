﻿using INS.PT.WebAPI.Models.DTO.Collections.Elements;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections
{
    public class ZFscdPcCobrarWsResponseDTO
    {
        [JsonProperty("ZFscdPcCobrarWsResponse", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public ZFscdPcCobrarWsResponse ZFscdPcCobrarWsResponse { get; set; }
    }

    /// <summary>
    /// ZFscdPcCobrarWsResponseDTO
    /// </summary>
    public class ZFscdPcCobrarWsResponse
    {
        /// <summary>
        /// Gets or Sets Errors
        /// </summary>
        [JsonProperty("errors", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public List<ZfscdCodigosErroRecibosDTO> Errors { get; set; }
    }
}

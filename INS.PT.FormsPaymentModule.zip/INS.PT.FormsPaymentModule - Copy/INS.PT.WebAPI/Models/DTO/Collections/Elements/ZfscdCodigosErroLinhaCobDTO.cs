﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections.Elements
{
    /// <summary>
    /// ZfscdCodigosErroLinhaCobDTO
    /// </summary>
    public class ZfscdCodigosErroLinhaCobDTO
    {
        /// <summary>
        /// Gets or Sets ErrorCode
        /// </summary>
        [JsonProperty("ErrorCode", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]

        public string ErrorCode { get; set; }

        /// <summary>
        /// Gets or Sets ErrorCodeTxt
        /// </summary>
        [JsonProperty("ErrorCodeTxt", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCodeTxt { get; set; }
    }
}

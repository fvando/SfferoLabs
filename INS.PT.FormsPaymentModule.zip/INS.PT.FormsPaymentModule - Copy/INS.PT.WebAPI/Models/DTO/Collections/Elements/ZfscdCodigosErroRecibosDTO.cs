﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections.Elements
{
    /// <summary>
    /// ZfscdCodigosErroRecibosDTO
    /// </summary>
    public class ZfscdCodigosErroRecibosDTO
    {
        /// <summary>
        /// Gets or Sets Receipt
        /// </summary>
        [JsonProperty("Receipt", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Receipt { get; set; }

        /// <summary>
        /// Gets or sets the errors.
        /// </summary>
        [JsonProperty("Errors", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]

        public List<ZfscdCodigosErroLinhaCobDTO> Errors { get; set; }
    }
}

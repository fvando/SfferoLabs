﻿using INS.PT.WebAPI.Models.DTO.Collections.Elements;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections
{
    public class ChargedReceiptLineDetailResponseDTO
    {
        /// <summary>
        /// Gets or sets the pc receipts.
        /// </summary>
        /// <value>
        /// The pc receipts.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public List<ChargedReceiptDetailDTO> PcReceipts { get; set; }
    }
}


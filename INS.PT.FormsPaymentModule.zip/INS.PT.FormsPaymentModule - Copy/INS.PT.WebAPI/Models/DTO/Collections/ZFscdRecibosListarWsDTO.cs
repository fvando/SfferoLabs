﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections
{
    /// <summary>
    /// ZFscdRecibosListarWsDTO
    /// </summary>
    public class ZFscdRecibosListarWsDTO
    {
        /// <summary>
        /// Gets or sets the errors.
        /// </summary>
        /// <value>
        /// The errors.
        /// </value>
        [JsonProperty("Errors", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public List<ZfscdErrosReceiptsNumLineDTO> Errors { get; set; }
        /// <summary>
        /// Gets or sets the receipts numbers.
        /// </summary>
        /// <value>
        /// The receipts numbers.
        /// </value>
        [JsonProperty("ReceiptsNumbers", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public List<ZfscdRecibosWorkLinhaDTO> ReceiptsNumbers { get; set; }
    }
}

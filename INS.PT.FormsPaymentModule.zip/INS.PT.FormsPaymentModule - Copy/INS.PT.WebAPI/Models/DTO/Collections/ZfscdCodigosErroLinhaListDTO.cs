﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections
{
    /// <summary>
    /// ZfscdCodigosErroLinhaListDTO
    /// </summary>
    public class ZfscdCodigosErroLinhaListDTO
    {
        /// <summary>
        /// Gets or Sets ErrorCode
        /// </summary>
        [JsonProperty("errorCode", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]

        public string ErrorCode { get; set; }
        /// <summary>
        /// Gets or Sets ErrorCodeTxt
        /// </summary>
        [JsonProperty("errorCodeTxt", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]

        public string ErrorCodeTxt { get; set; }
    }
}

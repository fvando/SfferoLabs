﻿using Newtonsoft.Json;
using System;

namespace INS.PT.WebAPI.Models.DuckCreek
{
    public class ReceiptsChangeNotifcationInput
    {
        /// <summary>
        /// Gets or sets the payment method.
        /// </summary>
        /// <value>
        /// The payment method.
        /// </value>
        [JsonProperty(PropertyName = "paymentMethod", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string PaymentMethod { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the effective date.
        /// </summary>
        /// <value>
        /// The effective date.
        /// </value>
        [JsonProperty(PropertyName = "effectiveDate", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string EffectiveDate { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the type of the receipt.
        /// </summary>
        /// <value>
        /// The type of the receipt.
        /// </value>
        [JsonProperty(PropertyName = "receiptType", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ReceiptType { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        [JsonProperty(PropertyName = "status", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Status { get; set; } = String.Empty;
        /// <summary>
        /// Gets or sets the accountability identifier.
        /// </summary>
        /// <value>
        /// The accountability identifier.
        /// </value>
        [JsonProperty(PropertyName = "accountabilityId", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string AccountabilityId { get; set; } = String.Empty;

    }
}

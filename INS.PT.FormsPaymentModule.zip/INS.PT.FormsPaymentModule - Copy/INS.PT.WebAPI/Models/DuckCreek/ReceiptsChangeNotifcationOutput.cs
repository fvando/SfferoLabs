﻿
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DuckCreek
{
    /// <summary>
    /// ReceiptsChangeNotifcationOutput
    /// </summary>
    public class ReceiptsChangeNotifcationOutput
    {
        [JsonProperty("Response", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string Response { get; set; }

        [JsonProperty("Success", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public bool Success { get; set; }
    }
}

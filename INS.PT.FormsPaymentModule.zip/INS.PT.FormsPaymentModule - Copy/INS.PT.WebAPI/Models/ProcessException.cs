﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model
{
    /// <summary>
    /// ProcessErrorException
    /// </summary>
    /// <seealso cref="System.Exception" />
    [Serializable]
     public class ProcessErrorException : Exception
     {
        /// <summary>
        /// InnerError
        /// </summary>
        [Serializable]
        public class InnerError
        {
            /// <summary>
            /// Gets or sets the type of the error.
            /// </summary>
            /// <value>
            /// The type of the error.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ErrorType { get; set; }
            /// <summary>
            /// Gets or sets the error code.
            /// </summary>
            /// <value>
            /// The error code.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ErrorCode { get; set; }
            /// <summary>
            /// Gets or sets the error message.
            /// </summary>
            /// <value>
            /// The error message.
            /// </value>
            [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
            public string ErrorMessage { get; set; }
             
        }

        /// <summary>
        /// Gets or sets the type of the error.
        /// </summary>
        /// <value>
        /// The type of the error.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorType { get; set; }
        /// <summary>
        /// Gets or sets the error code.
        /// </summary>
        /// <value>
        /// The error code.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCode { get; set; }
        /// <summary>
        /// Gets or sets the error message.
        /// </summary>
        /// <value>
        /// The error message.
        /// </value>
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets the inner errors.
        /// </summary>
        /// <value>
        /// The inner errors.
        /// </value>
        public IEnumerable<InnerError> InnerErrors { get; set; }


        #region Contructors        
        /// <summary>
        /// Initializes a new instance of the <see cref="ProcessErrorException"/> class.
        /// </summary>
        public ProcessErrorException()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProcessErrorException"/> class.
        /// </summary>
        /// <param name="message">The message that describes the error.</param>
        public ProcessErrorException(string message) : this(message, (Exception)null)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProcessErrorException"/> class.
        /// </summary>
        /// <param name="code">The code.</param>
        /// <param name="message">The message.</param>
        public ProcessErrorException(string code, string message) : this(message, (Exception)null)
        {
            ErrorCode = code;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProcessErrorException"/> class.
        /// </summary>
        /// <param name="message">The error message that explains the reason for the exception.</param>
        /// <param name="innerException">The exception that is the cause of the current exception, or a null reference (Nothing in Visual Basic) if no inner exception is specified.</param>
        public ProcessErrorException(string message, Exception innerException) : base(message, innerException)
        {
            ErrorMessage = message;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProcessErrorException" /> class.
        /// </summary>
        /// <param name="info">The <see cref="T:System.Runtime.Serialization.SerializationInfo"></see> that holds the serialized object data about the exception being thrown.</param>
        /// <param name="context">The <see cref="T:System.Runtime.Serialization.StreamingContext"></see> that contains contextual information about the source or destination.</param>
        protected ProcessErrorException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProcessErrorException"/> class.
        /// </summary>
        /// <param name="errorCode">The error code.</param>
        /// <param name="errorMessage">The error message.</param>
        /// <param name="innerErrors">The inner errors.</param>
        /// <exception cref="ArgumentNullException">innerErrors</exception>
        public ProcessErrorException(string errorCode, string errorMessage, IEnumerable<InnerError> innerErrors) : this(errorCode, errorMessage)
        {
            InnerErrors = innerErrors ?? throw new ArgumentNullException(nameof(innerErrors));
        }
        #endregion

        /// <summary>
        /// Gets a message that describes the current exception.
        /// </summary>
        public override string Message => ToString();

        ///<inheritdoc /> 
        /// <summary>
        /// Custom converts to string.
        /// </summary>
        /// <returns>
        /// A <see cref="System.String" /> that represents this instance.
        /// </returns>
        public override string ToString()
        {
            return $"Execution returned error {ErrorCode} with message: {ErrorMessage}";
        }

        /// <inheritdoc /> 
        /// <summary>
        /// Cahnegs the values exposed for serialization.
        /// </summary>
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
            {
                throw new ArgumentNullException(nameof(info));
            }

            info.AddValue("Errors", InnerErrors);
        }
    }
    }
 

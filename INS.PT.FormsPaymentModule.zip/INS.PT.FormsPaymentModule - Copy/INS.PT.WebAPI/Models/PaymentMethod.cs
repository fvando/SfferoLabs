﻿using Ins.PT.WebAPI;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using static INS.PT.WebAPI.Constants.CommonEnums;

namespace INS.PT.WebAPI.Models
{
    /// <summary>
    /// PaymentMethod
    /// </summary>
    /// <seealso cref="Ins.PT.WebAPI.IMapped" />
    public class PaymentMethod : ICloneable
    {
        /// <summary>
        /// Gets or sets the identifier payment method.
        /// </summary>
        /// <value>
        /// The identifier payment method.
        /// </value>
        [JsonProperty(PropertyName = "idPaymentMethod", NullValueHandling = NullValueHandling.Ignore)]
        [JsonConverter(typeof(StringEnumConverter))]
        public EnumPayments IdPaymentMethod { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        [JsonProperty(PropertyName = "description", NullValueHandling = NullValueHandling.Ignore)]
        public string Description { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the subtitle.
        /// </summary>
        /// <value>
        /// The subtitle.
        /// </value>
        [JsonProperty(PropertyName = "subtitle", NullValueHandling = NullValueHandling.Ignore)]
        public string Subtitle { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the icon.
        /// </summary>
        /// <value>
        /// The icon.
        /// </value>
        [JsonProperty(PropertyName = "icon", NullValueHandling = NullValueHandling.Ignore)]
        public string Icon { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the payment destination.
        /// </summary>
        /// <value>
        /// The payment destination.
        /// </value>
        [JsonProperty(PropertyName = "redirect", NullValueHandling = NullValueHandling.Ignore)]
        public string PaymentDestination { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets a value indicating whether this instance is available.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is available; otherwise, <c>false</c>.
        /// </value>
        [JsonProperty(PropertyName = "isAvailable", NullValueHandling = NullValueHandling.Ignore)]
        //[JsonIgnore]
        public bool IsAvailable { get; set; } = false;

        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>
        /// The message.
        /// </value>
        [JsonProperty(PropertyName = "message", NullValueHandling = NullValueHandling.Ignore)]
        public string Message { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the contato.
        /// </summary>
        /// <value>
        /// The contato.
        /// </value>
        [JsonProperty(PropertyName = "phone", NullValueHandling = NullValueHandling.Ignore)]
        public string Phone { get; set; } = String.Empty;

        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>
        /// The contato.
        /// </value>
        [JsonProperty(PropertyName = "eMail", NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; } = String.Empty;


        /// <summary>
        /// Gets or sets the contato.
        /// </summary>
        /// <value>
        /// The contato.
        /// </value>
        [JsonProperty(PropertyName = "isSelected", NullValueHandling = NullValueHandling.Ignore)]
        public bool IsSelected { get; set; } = false;

        /// <summary>
        /// Gets or sets the contato.
        /// </summary>
        /// <value>
        /// The contato.
        /// </value>
        [JsonProperty(PropertyName = "order", NullValueHandling = NullValueHandling.Ignore)]
        public int Order { get; set; } = 0;

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}

﻿using INS.PT.CommonLibrary.Exceptions;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Interface.v2;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Models.Input.v2;
using INS.PT.WebAPI.Models.Output;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Controllers.v2
{
    [Route("v2/[controller]")]
    [ApiController]
    public class PaymentsController : BaseCore
    {
        private readonly IPayments repository;

        /// <summary>
        /// Controller constructor.
        /// </summary>
        /// <param name="repository">Repository to use.</param>
        /// <param name="httpContext">Execution context.</param>
        public PaymentsController(IPayments repository, IHttpContextAccessor httpContext) : base(httpContext)
        {
            this.repository = repository;
        }


        /// <summary>
        /// Get method to read an element from a table of reference data.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     POST /v2/Payments/
        ///     
        ///     {
        ///          "IdPaymentMethod": "mbway",
        ///          "ReceiptNumber": "55643929",
        ///          "AditionalInformation": "912345678" 
        ///     }
        ///     
        ///     POST /v2/Payments/
        ///     
        ///     {
        ///          "IdPaymentMethod": "mbreference",
        ///          "ReceiptNumber": "55643929"
        ///     }
        ///     
        ///     POST /v2/Payments/
        ///     
        ///     {
        ///          "IdPaymentMethod": "chippin"
        ///     }
        ///     
        ///     POST /v2/Payments/
        ///     
        ///     {
        ///          "IdPaymentMethod": "agente",
        ///           "ReceiptNumber": "55643929"
        ///     }
        /// 
        /// 
        /// 
        /// 
        /// </remarks>
        /// <param name="parameters">Defines what reference data is requested.</param>
        /// <response code="202">if payment is accepted.</response>
        /// <response code="204">if no results exist.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The reference data.</returns>
        [HttpPost]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(PaymentOutput), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<PaymentOutput>> PostAsync([FromBody]PaymentsInput parameters)
        {
            return await MakePaymentd(parameters);
        }

        /// <summary>
        /// SharePaymentsReference
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     POST /v2/Payments/SharePaymentsReference
        ///     
        ///     {
        ///          "type": "sms",
        ///          "recipient": "999999999" 
        ///     }
        ///     
        ///     POST /v2/Payments/SharePaymentsReference
        ///     
        ///     {
        ///          "type": "email",
        ///          "recipient": "@"
        ///     }
        ///     
        /// 
        /// 
        /// </remarks>
        /// <param name="inputShare"></param>
        /// <returns></returns>
        [HttpPost("SharePaymentsReference")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(PaymentOutput), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<PaymentOutput>> ShareAsync([FromBody]SharePaymentInfo inputShare)
        {
            return await SharePaymentReference(Request, inputShare);
        }

        /// <summary>
        /// Makes the paymentd.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        private async Task<ActionResult<PaymentOutput>> MakePaymentd(PaymentsInput parameters)
        {
            try
            {
                var result = await repository.MakePaymentAsync(Request, parameters);

                Log.Debug($"MakePaymentd Response: {JsonConvert.SerializeObject(result)}");

                if (result?.Code == StatusCodes.Status200OK.ToString() || result?.Code == null)
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest(result);
                }
            }
            catch (ProcessErrorException processError)
            {
                Log.Error("{@error}", processError);
                return StatusCode(Convert.ToInt32(processError.ErrorCode), processError);
            }
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            catch (CanonicalException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            catch (System.Exception e)
            {
                Log.Error(e, String.Empty);
                throw;
            }
            finally
            {
                Log.Debug($"Finish PostAsync");
            }
        }

        /// <summary>
        /// SharePaymentReference
        /// </summary>
        /// <param name="requestValue"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        private async Task<ActionResult<PaymentOutput>> SharePaymentReference(HttpRequest requestValue, SharePaymentInfo parameters)
        {
            try
            {
                var result = await repository.SharePaymentAsync(Request, parameters);

                if (result?.Code == StatusCodes.Status200OK.ToString())
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest(result);
                }

            }
            catch (ProcessErrorException processError)
            {
                Log.Error("{@error}", processError);
                return NotFound(processError);
            }
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            catch (System.Exception e)
            {
                Log.Error(e, String.Empty);
                throw;
            }
            finally
            {
                Log.Debug("Finish PostAsync");
            }
        }
    }


}

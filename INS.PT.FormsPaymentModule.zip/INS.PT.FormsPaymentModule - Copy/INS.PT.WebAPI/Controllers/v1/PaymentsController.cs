﻿using INS.PT.WebAPI.Interface.v1;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Models.Input.v1;
using INS.PT.WebAPI.Models.Output;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Serilog;
using System;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Controllers.v1
{
    [Route("v1/[controller]")]
    [ApiController]
    public class PaymentsController : BaseCore
    {
        private readonly IPayments repository;

        /// <summary>
        /// Controller constructor.
        /// </summary>
        /// <param name="repository">Repository to use.</param>
        /// <param name="httpContext">Execution context.</param>
        public PaymentsController(IPayments repository, IHttpContextAccessor httpContext) : base(httpContext)
        {
            this.repository = repository;
        }


        /// <summary>
        /// Get method to read an element from a table of reference data.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// 
        ///     POST /v1/Payments/
        ///     
        ///     {
        ///          "IdPaymentMethod": "mbway",
        ///          "ReceiptNumber": "55643929",
        ///          "AditionalInformation": "912345678" 
        ///     }
        ///     
        ///     POST /v1/Payments/
        ///     
        ///     {
        ///          "IdPaymentMethod": "mbreference",
        ///          "ReceiptNumber": "55643929"
        ///     }
        ///     
        ///     POST /v1/Payments/
        ///     
        ///     {
        ///          "IdPaymentMethod": "chippin"
        ///     }
        ///     
        ///     POST /v1/Payments/
        ///     
        ///     {
        ///          "IdPaymentMethod": "agente"
        ///     }
        /// 
        /// 
        /// 
        /// 
        /// </remarks>
        /// <param name="parameters">Defines what reference data is requested.</param>
        /// <response code="202">if payment is accepted.</response>
        /// <response code="204">if no results exist.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The reference data.</returns>
        [Obsolete("v1 is deprecated, please use v2 to correct execute operation.", true)]
        [HttpPost]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(PaymentOutput), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<PaymentOutput>> PostAsync([FromBody]PaymentsInput parameters)
        {
            return await MakePaymentd(parameters);
        }

        /// <summary>
        /// Makes the paymentd.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        private async Task<ActionResult<PaymentOutput>> MakePaymentd(PaymentsInput parameters)
        {
            try
            {
                var result = await repository.MakePaymentAsync(parameters);

                if (result?.Code == StatusCodes.Status200OK.ToString())
                {
                    return Ok(result);
                }
                else
                {
                    return BadRequest(result);
                }
            }
            catch (ProcessErrorException processError)
            {
                Log.Error("{@error}", processError);
                return NotFound(processError);
            }
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors, String.Empty);
                return BadRequest(validateErrors);
            }
            catch (System.Exception e)
            {
                Log.Error(e, String.Empty);
                throw;
            }
            finally
            {
                Log.Debug($"Finish PostAsync");
            }
        }
    }

}

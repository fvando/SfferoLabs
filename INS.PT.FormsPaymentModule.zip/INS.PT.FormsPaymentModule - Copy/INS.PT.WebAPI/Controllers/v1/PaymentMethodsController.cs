﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Models.Input.v1;
using INS.PT.WebAPI.Models.Output.v1;
using INS.PT.WebAPI.v1;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace INS.PT.WebAPI.Controllers.v1
{
    [Route("v1/[controller]")]
    [ApiController]
    public class PaymentMethodsController : BaseCore
    {
        private readonly IPaymentMethods repository;

        /// <summary>
        /// Controller constructor.
        /// </summary>
        /// <param name="repository">Repository to use.</param>
        /// <param name="httpContext">Execution context.</param>
        public PaymentMethodsController(IPaymentMethods repository, IHttpContextAccessor httpContext) : base(httpContext)
        {
            this.repository = repository;
        }

        /// <summary>
        /// Get method to read an element from a table of reference data.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///     
        ///     Header
        ///     Content-Type:application/json
        ///     
        ///     Channel: DynamicForms
        ///     GET /v1/PaymentMethods/0SIP10013426
        ///     GET /v1/PaymentMethods/0SIP10098130
        ///     
        ///     
        ///     Channel: Life2.0
        ///     GET /v1/PaymentMethods/210002387
        ///     
        ///     
        /// </remarks>
        /// <param name="parameters">Defines what reference data is requested.</param>
        /// <response code="200">if any results exist.</response>
        /// <response code="204">if no results exist.</response>
        /// <response code="400">if any error found or invalid parameters.</response>
        /// <returns>The reference data.</returns>
        [Obsolete("v1 is deprecated, please use v2 to correct execute operation.", true)]
        [HttpGet("{IdQuote}")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(PaymentMethodsOutput), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<PaymentMethodsOutput>> GetAsync([FromHeader(Name = "Channel")] string header, [FromRoute] PaymentMethodsInput parameters)
        {
            return await RepositoryInvokerAsync(
                () => {    
                    // retrive data
                    return Task.Run(() => 
                        repository.ReadDataAsync(Request, parameters));
                    },
                (result) => result == null || result.TotalResults == 0 || !result.ResultList.Any()
                );
        }

    }

}

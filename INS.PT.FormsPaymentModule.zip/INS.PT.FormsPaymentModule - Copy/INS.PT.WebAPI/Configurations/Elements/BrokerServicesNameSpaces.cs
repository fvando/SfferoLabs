﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Configurations.Elements
{
    /// <summary>
    /// BrokerServicesNameSpaces
    /// </summary>
    public class BrokerServicesNameSpaces
    {
        /// <summary>
        /// Gets or sets the agents portal.
        /// </summary>
        /// <value>
        /// The agents portal.
        /// </value>
        public string AgentsPortal { get; set; }
        /// <summary>
        /// Gets or sets the entity.
        /// </summary>
        /// <value>
        /// The entity.
        /// </value>
        public string Entity { get; set; }
        /// <summary>
        /// Gets or sets the reference data.
        /// </summary>
        /// <value>
        /// The reference data.
        /// </value>
        public string ReferenceData { get; set; }
        /// <summary>
        /// Gets or sets the agent.
        /// </summary>
        /// <value>
        /// The agent.
        /// </value>
        public string Agent { get; set; }
        /// <summary>
        /// Gets or sets the document.
        /// </summary>
        /// <value>
        /// The document.
        /// </value>
        public string Document { get; set; }
        /// <summary>
        /// Gets or sets the documents.
        /// </summary>
        /// <value>
        /// The documents.
        /// </value>
        public string Documents { get; set; }
        /// <summary>
        /// Gets or sets the collections.
        /// </summary>
        /// <value>
        /// The collections.
        /// </value>
        public string Collections { get; set; }
        /// <summary>
        /// Gets or sets the web med.
        /// </summary>
        /// <value>
        /// The web med.
        /// </value>
        public string WebMed { get; set; }
        /// <summary>
        /// Gets or sets the agents portal utils.
        /// </summary>
        /// <value>
        /// The agents portal utils.
        /// </value>
        public string AgentsPortalUtils { get; set; }
        /// <summary>
        /// Gets or sets the payment mpos.
        /// </summary>
        /// <value>
        /// The payment mpos.
        /// </value>
        public string PaymentMpos { get; set; }

        /// <summary>
        /// Gets or sets the life2.
        /// </summary>
        /// <value>
        /// The life2.
        /// </value>
        public string Life2 { get; set; }

        /// <summary>
        /// Gets or sets the life2 front.
        /// </summary>
        /// <value>
        /// The life2 front.
        /// </value>
        public string Life2Front { get; set; }

        /// <summary>
        /// Gets or sets the users profile management.
        /// </summary>
        /// <value>
        /// The users profile management.
        /// </value>
        public string UsersProfileManagement { get; set; }

        /// <summary>
        /// Gets or sets the duck creek.
        /// </summary>
        /// <value>
        /// The duck creek.
        /// </value>
        public string DuckCreek { get; set; }
    }
}

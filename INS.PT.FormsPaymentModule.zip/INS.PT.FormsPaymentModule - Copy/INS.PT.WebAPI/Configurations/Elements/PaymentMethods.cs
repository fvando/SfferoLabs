﻿namespace INS.PT.WebAPI.Configurations.Elements
{
    public class PaymentMethods
    {
        public string IdPaymentMethod { get; set; }
        public string Description { get; set; }
        public string Subtitle { get; set; }
        public string Icon { get; set; }
        public string PaymentDestination { get; set; }
        public string IsAvailable { get; set; }
        public string Message { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Configurations.Elements
{
    public class CanonicalServiceLife20
    {
        public string CanonicalUrl { get; set; }
        public string BrokerSolution { get; set; }
        public string BrokerUser { get; set; }
    }
}

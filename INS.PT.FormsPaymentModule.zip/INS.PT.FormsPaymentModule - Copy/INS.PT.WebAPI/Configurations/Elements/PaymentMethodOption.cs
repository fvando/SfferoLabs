﻿using INS.PT.WebAPI.Models;
using System.Collections.Generic;
 
namespace INS.PT.WebAPI.Configurations.Elements
{
    public class PaymentMethodOption
    {
        public string AppOrigem { get; set; }
        public string KeyHeaderPemissionOnAgent { get; set; }

        public List<PaymentMethod> PaymentMethods { get; set; }
    }
}

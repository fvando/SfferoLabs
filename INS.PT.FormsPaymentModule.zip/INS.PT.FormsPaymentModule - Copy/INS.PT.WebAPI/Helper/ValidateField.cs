﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Helper
{
    /// <summary>
    /// ValidateField
    /// </summary>
    public class ValidateField
    {
        /// <summary>
        /// Validates the nif.
        /// </summary>
        /// <param name="nif">The nif.</param>
        /// <returns></returns>
        public static string ValidateNif(string nif)
        {
            return  nif.Replace("PT", "");
        }

        /// <summary>
        /// Validates the agent.
        /// </summary>
        /// <param name="nif">The nif.</param>
        /// <returns></returns>
        public static string ValidateAgent(string nif)
        {
            return nif.Replace("M0", "").Replace("M1", "");
        }
    }
}

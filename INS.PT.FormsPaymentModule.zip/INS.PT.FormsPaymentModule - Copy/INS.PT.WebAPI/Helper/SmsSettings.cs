﻿namespace INS.PT.WebAPI.Helper
{
    public class SmsSettings
    {
        public string WSDLSmsSetting { get; set; }
        public string User { get; set; }
        public string UserName { get; set; }
        public string Solution { get; set; }
        public string Ip { get; set; }
        public string ClientVersion { get; set; }
        public string Body { get; set; }
        public string Originator { get; set; }
        public string Phone { get; set; }
        public string Scheduleddate { get; set; }
        public string OriginalTransactionID { get; set; }
        public string OriginalSystemName { get; set; }
        public string EnvironmentName { get; set; }
        public string Author { get; set; }
        public string Company { get; set; }
    }
}

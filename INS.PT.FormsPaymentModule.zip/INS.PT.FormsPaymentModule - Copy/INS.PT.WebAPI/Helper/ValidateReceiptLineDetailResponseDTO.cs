﻿using INS.PT.WebAPI.Mappings;
using INS.PT.WebAPI.Models.DTO.Collections.Elements;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Helpers
{
    public class ValidateReceiptLineDetailResponseDTO : ZfscdPcRecibosLinhaDTO
    {
        [JsonProperty(PropertyName = "PcReceipts", DefaultValueHandling = DefaultValueHandling.Ignore, NullValueHandling = NullValueHandling.Ignore)]
        public List<ValidateReceiptDetailDTO> PcReceipts { get; set; }
    }
}
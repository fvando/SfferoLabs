﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Helper
{
    public class OraclePackageWebservice
    {
        [Column("PackageName")]
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string PackageName { get; set; }

        [Column("FunctionName")]
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string FunctionName { get; set; }
    }
}

﻿
namespace INS.PT.WebAPI.Helper
{
    public class SharePaymentOutPut
    {
        public string Type { get; set; }
        public string Message { get; set; }
    }
}

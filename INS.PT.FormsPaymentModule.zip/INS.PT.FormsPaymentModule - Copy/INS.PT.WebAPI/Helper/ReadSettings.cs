﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace INS.PT.WebAPI.Helper
{
    internal static class ReadSettings
    {
        public static TimeSpan DefaultTimeout = new TimeSpan(00, 02, 30);

        /// <summary>
        /// Get the IConfiguration service from the given context.
        /// </summary>
        /// <param name="httpContextAccessor">context accessor to be searched for the configuration service</param>
        /// <returns>service found or null</returns>
        public static IConfiguration GetConfiguration(this IHttpContextAccessor httpContextAccessor)
        {
            return GetConfiguration(httpContextAccessor?.HttpContext);
        }

        /// <summary>
        /// Get the IConfiguration service from the given context.
        /// </summary>
        /// <param name="httpContext">context to be searched for the configuration service</param>
        /// <returns>service found or null</returns>
        public static IConfiguration GetConfiguration(this HttpContext httpContext)
        {
            return httpContext?.RequestServices.GetService(typeof(IConfiguration)) as IConfiguration;
        }

        /// <summary>
        /// Reads a Timespan from the settings file
        /// </summary>
        /// <param name="_configuration">configuration settings</param>
        /// <param name="configKey">setting key to be read</param>
        /// <returns>DefaultTimeout if key not found or with invalid value</returns>
        public static TimeSpan ReadTimeSpanFromConfig(this IConfiguration _configuration, string configKey)
        {
            if (TimeSpan.TryParse(_configuration.GetValue<string>(configKey), out var configValue))
            {
                return configValue;
            }

            return DefaultTimeout;
        }
    }
}

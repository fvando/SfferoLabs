﻿using Dapper;
using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;

namespace INS.PT.WebAPI.Helper
{
    /// <summary>
    /// Helper methods for mapping database results.
    /// </summary>
    public static class MappedHelper
    {
        /// <summary>
        /// Creates the mapping using the <seealso cref="ColumnAttribute"/> for the data comming from database.
        /// </summary>
        /// <param name="mappedType">type to be mapped</param>
        public static void MapWithColumnAttribute(Type mappedType)
        {
            SqlMapper.SetTypeMap(mappedType, new CustomPropertyTypeMap(mappedType, (type, columnName) => GetColumnAttribute(type, columnName)));
        }

        /// <summary>
        /// Gets the column attribute.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="columnName">Name of the column.</param>
        /// <returns></returns>
        private static System.Reflection.PropertyInfo GetColumnAttribute(Type type, string columnName)
        {
            return type?.GetProperties().FirstOrDefault(prop => prop.GetCustomAttributes(false).OfType<ColumnAttribute>().Any(
                attr => string.Compare(attr.Name, columnName, StringComparison.InvariantCultureIgnoreCase) == 0));
        }
    }
}

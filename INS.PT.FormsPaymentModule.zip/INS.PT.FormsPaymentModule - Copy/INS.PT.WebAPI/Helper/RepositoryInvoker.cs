﻿using AutoMapper;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.CommonLibrary.Exceptions.Models;
using INS.PT.WebAPI.Constants;
using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Models.DTO.Collections;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Helpers
{
    /// <summary>
    /// RepositoryInvoker : IRepositoryInvoker
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.IRepositoryInvoker" />
    public class RepositoryInvoker : IRepositoryInvoker
    {
        #region Properties

        private readonly IMapper mapper;
        private readonly HttpRequest request;
        private readonly IHttpClientRepository httpClientRepository;

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="RepositoryInvoker"/> class.
        /// </summary>
        /// <param name="_httpClientRepository">The HTTP client repository.</param>
        /// <param name="_mapper">The mapper.</param>
        /// <param name="_request">The request.</param>
        public RepositoryInvoker(IHttpClientRepository _httpClientRepository, IMapper _mapper, HttpRequest _request)
        {
            request = _request;
            mapper = _mapper;
            httpClientRepository = _httpClientRepository;
        }

        /// <summary>
        /// Generics the invoker asynchronous.
        /// </summary>
        /// <typeparam name="TWaspInput">The type of the wasp input.</typeparam>
        /// <typeparam name="TWaspOutput">The type of the wasp output.</typeparam>
        /// <typeparam name="TDTOInput">The type of the dto input.</typeparam>
        /// <typeparam name="TDTOOutput">The type of the dto output.</typeparam>
        /// <param name="requestObject">The request object.</param>
        /// <param name="serviceNameSpace">The service name space.</param>
        /// <param name="methodName">Name of the method.</param>
        /// <param name="routeValue">Route value if existent is the request</param>
        /// <returns></returns>
        /// <exception cref="CanonicalException">
        /// </exception>
        public async Task<TWaspOutput> GenericInvokerAsync<TWaspInput, TWaspOutput, TDTOInput, TDTOOutput>(TWaspInput requestObject, string serviceNameSpace, string methodName, [Optional] string routeValue)
        {
            TWaspOutput result = default(TWaspOutput);
            var inputObj = mapper.Map<TDTOInput>(requestObject);

            var responseMessage = await httpClientRepository.ProcessRequestAsync(request, serviceNameSpace, methodName, routeValue, inputObj);

            if (responseMessage.IsSuccessStatusCode)
            {
                var response = responseMessage.Content.ReadAsAsync<TDTOOutput>();
                result = mapper.Map<TWaspOutput>(await response);
            }
            else
            {
                Log.Debug($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(responseMessage)}");

                if (responseMessage.StatusCode == System.Net.HttpStatusCode.BadRequest || responseMessage.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    object badRequestResponse = await responseMessage.Content.ReadAsAsync<object>();
                    throw new CanonicalException(responseMessage.StatusCode, JsonConvert.SerializeObject(badRequestResponse));
                }

                throw new CanonicalException(responseMessage);
            }

            return result;
        }

        /// <summary>
        /// Generics the get invoker asynchronous.
        /// </summary>
        /// <typeparam name="TWaspOutput">The type of the wasp output.</typeparam>
        /// <typeparam name="TDTOOutput">The type of the dto output.</typeparam>
        /// <param name="serviceNameSpace">The service name space.</param>
        /// <param name="methodName">Name of the method.</param>
        /// <param name="routeValue">The route value.</param>
        /// <returns></returns>
        /// <exception cref="CanonicalException">
        /// </exception>        
        public async Task<TWaspOutput> GenericInvokerAsync<TWaspOutput, TDTOOutput>(string serviceNameSpace, string methodName, [Optional] string routeValue)
        {
            TWaspOutput result = default(TWaspOutput);

            var responseMessage = await httpClientRepository.ProcessRequestAsync(request, serviceNameSpace, methodName, routeValue);

            if (responseMessage.IsSuccessStatusCode)
            {
                var response = await responseMessage.Content.ReadAsAsync<TDTOOutput>();
                result = mapper.Map<TWaspOutput>(response);
            }
            else
            {
                Log.Debug($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(responseMessage)}");

                if (responseMessage.StatusCode == System.Net.HttpStatusCode.BadRequest || responseMessage.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    object badRequestResponse = await responseMessage.Content.ReadAsAsync<object>();
                    throw new CanonicalException(responseMessage.StatusCode, JsonConvert.SerializeObject(badRequestResponse));
                }

                throw new CanonicalException(responseMessage);
            }

            return result;
        }

        /// <summary>
        /// DownloadInvokerAsync
        /// </summary>
        /// <param name="requestElement"></param>
        /// <returns></returns>
        public async Task<DocumentDownloadWaspOutput> DownloadInvokerAsync(HttpRequestElement requestElement)
        {
            DocumentDownloadWaspOutput result = new DocumentDownloadWaspOutput();
            var responseMessage = await httpClientRepository.ProcessRequestAsync(requestElement);

            if (responseMessage.IsSuccessStatusCode)
            {
                if (requestElement.ResponseIsStream)
                {
                    var jsonString = await responseMessage.Content.ReadAsStringAsync();
                    result = JsonConvert.DeserializeObject<DocumentDownloadWaspOutput>(jsonString);
                }
            }
            else
            {
                Log.Debug($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(responseMessage)}");

                return await HandleUnsuccessfulHttpStatusResponse(requestElement, result, responseMessage);
            }

            return result;
        }

        /// <summary>
        /// GenericInvokerAsync
        /// </summary>
        /// <typeparam name="TWaspOutput"></typeparam>
        /// <typeparam name="TDTOOutput"></typeparam>
        /// <param name="requestElement"></param>
        /// <param name="isUpload"></param>
        /// <returns></returns>
        public async Task<TWaspOutput> GenericInvokerAsync<TWaspOutput, TDTOOutput>(HttpRequestElement requestElement, bool isUpload = false, bool jsonBroker = false)
        {
            TWaspOutput result = default(TWaspOutput);

            var responseMessage = await httpClientRepository.ProcessRequestAsync(requestElement, isUpload, jsonBroker);

            if (responseMessage.IsSuccessStatusCode)
            {
                if (requestElement.ResponseIsStream)
                {
                    var response = await responseMessage.Content.ReadAsStreamAsync();
                    result = mapper.Map<TWaspOutput>(response);
                }
                else
                {
                    var response = await responseMessage.Content.ReadAsAsync<TDTOOutput>();
                    result = mapper.Map<TWaspOutput>(response);
                }
            }
            else
            {
                Log.Debug($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(responseMessage)}");
                return await HandleUnsuccessfulHttpStatusResponse(requestElement, result, responseMessage);
            }

            return result;
        }

        /// <summary>
        /// GenericInvokerAsync
        /// </summary>
        /// <typeparam name="TWaspInput"></typeparam>
        /// <typeparam name="TWaspOutput"></typeparam>
        /// <typeparam name="TDTOInput"></typeparam>
        /// <typeparam name="TDTOOutput"></typeparam>
        /// <param name="requestElement"></param>
        /// <param name="jsonBroker"></param>
        /// <returns></returns>
        public async Task<TWaspOutput> GenericInvokerAsync<TWaspInput, TWaspOutput, TDTOInput, TDTOOutput>(HttpRequestElement requestElement, bool jsonBroker = false)
        {
            Stopwatch stopWatch = new Stopwatch();

            TWaspOutput result = default(TWaspOutput);
            var inputObj = mapper.Map<TDTOInput>(requestElement.RequestObject);
            // Map to DTO
            requestElement.RequestObject = inputObj;

            stopWatch.Start();
            Log.Debug($"Timeline({requestElement.ApiService}/{requestElement.ApiMethod}) - GenericInvokerAsync() - Start ProcessRequestAsync");
            var responseMessage = await httpClientRepository.ProcessRequestAsync(requestElement, false, jsonBroker);
            stopWatch.Stop();
            Log.Debug($"Timeline({requestElement.ApiService}/{requestElement.ApiMethod}) - GenericInvokerAsync() - End ProcessRequestAsync: Time {stopWatch.ElapsedMilliseconds }ms");

            if (responseMessage.IsSuccessStatusCode)
            {
                var response = responseMessage.Content.ReadAsAsync<TDTOOutput>();
                result = mapper.Map<TWaspOutput>(await response);
            }
            else
            {
                Log.Debug($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(responseMessage)}");

                await HandleUnsuccessfulHttpStatusResponse(requestElement, result, responseMessage);
            }

            return result;
        }

        /// <summary>
        /// GenericInvokerDetailAsync
        /// </summary>
        /// <typeparam name="TWaspInput"></typeparam>
        /// <typeparam name="TWaspOutput"></typeparam>
        /// <typeparam name="TDTOInput"></typeparam>
        /// <typeparam name="TDTOOutput"></typeparam>
        /// <param name="requestElement"></param>
        /// <param name="jsonBroker"></param>
        /// <param name="detailError"></param>
        /// <returns></returns>
        public async Task<TWaspOutput> GenericInvokerDetailAsync<TWaspInput, TWaspOutput, TDTOInput, TDTOOutput>(HttpRequestElement requestElement, [Optional] bool jsonBroker, [Optional] bool detailError)
        {
            Stopwatch stopWatch = new Stopwatch();
            TWaspOutput result = default(TWaspOutput);

            var inputObj = mapper.Map<TDTOInput>(requestElement.RequestObject);
            // Map to DTO
            requestElement.RequestObject = inputObj;

            stopWatch.Start();
            Log.Debug($"Timeline({requestElement.ApiService}/{requestElement.ApiMethod}) - GenericInvokerDetailAsync() - Start ProcessRequestAsync");
            var responseMessage = await httpClientRepository.ProcessRequestAsync(requestElement, false, jsonBroker);
            stopWatch.Stop();
            Log.Debug($"Timeline({requestElement.ApiService}/{requestElement.ApiMethod}) - GenericInvokerDetailAsync() - End ProcessRequestAsync: Time {stopWatch.ElapsedMilliseconds }ms");

            if (responseMessage.IsSuccessStatusCode)
            {
                var response = responseMessage.Content.ReadAsAsync<TDTOOutput>();
                Log.Debug($"{MethodBase.GetCurrentMethod()} ResponseMessage: {JsonConvert.SerializeObject(response)}");
                result = mapper.Map<TWaspOutput>(await response);
            }
            else
            {
                Log.Debug($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(responseMessage)}");

                await HandleSAPUnsuccessfulHttpStatusResponseDetailAsync<TWaspOutput, TDTOOutput>(requestElement, responseMessage);
            }

            return result;
        }

        /// <summary>
        /// Generic Invoker return ResponseMessage
        /// </summary>
        /// <typeparam name="TWaspInput"></typeparam>
        /// <typeparam name="TWaspOutput"></typeparam>
        /// <typeparam name="TDTOInput"></typeparam>
        /// <typeparam name="TDTOOutput"></typeparam>
        /// <param name="requestElement"></param>
        /// <param name="jsonBroker"></param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> GenericInvokerResponseMessageAsync<TWaspInput, TWaspOutput, TDTOInput, TDTOOutput>(HttpRequestElement requestElement, bool jsonBroker = false)
        {
            Stopwatch stopWatch = new Stopwatch();
            //var inputObj = mapper.Map<TDTOInput>(requestElement.RequestObject);
            //requestElement.RequestObject = inputObj;

            stopWatch.Start();
            Log.Debug($"Timeline({requestElement.ApiService}/{requestElement.ApiMethod}) - GenericInvokerResponseMessageAsync() - Start ProcessRequestAsync");
            var responseMessage = await httpClientRepository.ProcessRequestAsync(requestElement, false, jsonBroker);
            stopWatch.Stop();
            Log.Debug($"Timeline({requestElement.ApiService}/{requestElement.ApiMethod}) - GenericInvokerResponseMessageAsync() - End ProcessRequestAsync: Time {stopWatch.ElapsedMilliseconds }ms");

            if (!responseMessage.IsSuccessStatusCode)
            {
                Log.Debug($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(responseMessage)}");
            }

            return responseMessage;
        }


        #region Private Methods

        private async Task<TWaspOutput> HandleUnsuccessfulHttpStatusResponse<TWaspOutput>(HttpRequestElement requestElement, TWaspOutput result, HttpResponseMessage responseMessage)
        {
            StandardMessageException errorMessage = null;
            // This will handle all the 404 related to lists not having result and that are provided by 'canonical services' for exemple:
            // * High Availibility
            // * WebMed Lists
            // The method will know if this handling is necessary, if the parameter HandleList404Response e set to 'true', this property is set on the repository!
            if (responseMessage.StatusCode == System.Net.HttpStatusCode.NotFound && (requestElement.Options != null && requestElement.Options.HandleList404Response))
            {
                try
                {
                    errorMessage = new StandardMessageException
                    {
                        StatusCode = responseMessage.StatusCode,
                        ErrorCode = responseMessage.StatusCode.ToString(),
                        ErrorMessage = await responseMessage.Content.ReadAsStringAsync(),
                        InnerErrors = new List<InnerError>
                        {
                                   new InnerError
                                   {
                                       ErrorCode = responseMessage.StatusCode.ToString(),
                                       ErrorMessage = await responseMessage.Content.ReadAsStringAsync(),
                                       Detail = ""
                                   }
                        }
                    };

                    // It was agreed with Business that POST Requests should return 204 and not 404
                    if (requestElement.Method == CommonEnums.HttpRequestVerb.POST || errorMessage == null)
                    {
                        throw new CanonicalException(System.Net.HttpStatusCode.NoContent, null);
                    }
                }
                catch
                {
                    // Prevent if convervsion fails in Exception
                    throw new CanonicalException(System.Net.HttpStatusCode.NoContent, responseMessage.Content.ReadAsStringAsync().Result);
                }

                // If message is an error throw the error
                if (errorMessage != null)
                {
                    throw new CanonicalException(errorMessage.ErrorMessage, errorMessage.StatusCode);
                }
            }
            else if (responseMessage.StatusCode == System.Net.HttpStatusCode.UnprocessableEntity || responseMessage.StatusCode == System.Net.HttpStatusCode.BadRequest
                || responseMessage.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                var badRequestResponse = await responseMessage.Content.ReadAsAsync<object>();

                try
                {
                    errorMessage = mapper.Map<StandardMessageException>(badRequestResponse);
                    if (errorMessage == null)
                    {
                        throw new CanonicalException(System.Net.HttpStatusCode.NoContent, null);
                    }
                }

                catch
                {
                    // Prevent if convervsion fails in Exception
                    throw new CanonicalException(responseMessage.StatusCode, JsonConvert.SerializeObject(badRequestResponse));
                }

                if (errorMessage != null)
                {
                    if (!string.IsNullOrEmpty(errorMessage.ErrorMessage))
                        throw new CanonicalException(responseMessage.StatusCode, errorMessage.ErrorMessage);
                    throw new CanonicalException(responseMessage.StatusCode, JsonConvert.SerializeObject(badRequestResponse));
                }
            }

            throw new CanonicalException(responseMessage);
        }

        /// <summary>
        /// Handles the sap unsuccessful HTTP status response detail asynchronous.
        /// </summary>
        /// <typeparam name="TWaspOutput">The type of the wasp output.</typeparam>
        /// <typeparam name="TDTOOutput">The type of the dto output.</typeparam>
        /// <param name="requestElement">The request element.</param>
        /// <param name="result">The result.</param>
        /// <param name="responseMessage">The response message.</param>
        /// <returns></returns>
        /// <exception cref="CanonicalException"></exception>
        /// <exception cref="List{InnerError}">
        /// </exception>
        /// <exception cref="InnerError">
        /// </exception>
        /// <exception cref="BusinessException">
        /// </exception>
        public async Task<TWaspOutput> HandleSAPUnsuccessfulHttpStatusResponseDetailAsync<TWaspOutput, TDTOOutput>(HttpRequestElement requestElement, HttpResponseMessage responseMessage)
        {
            StandardMessageException errorMessage = null;

            if (responseMessage.StatusCode == System.Net.HttpStatusCode.NotFound &&
                (requestElement.Options != null && requestElement.Options.HandleList404Response))
            {
                try
                {
                    errorMessage = await responseMessage.Content.ReadAsAsync<StandardMessageException>();
                    if (errorMessage == null)
                    {
                        Type primary = typeof(TWaspOutput);
                        return (TWaspOutput)Activator.CreateInstance(primary);
                    }
                    else
                    {
                        throw new CanonicalException(
                            errorMessage.ErrorMessage,
                            errorMessage.ErrorMessage, new List<InnerError>{
                                   new InnerError {
                                       ErrorCode = responseMessage.StatusCode.ToString(),
                                       ErrorMessage = JsonConvert.SerializeObject(errorMessage),
                                       Detail = ""
                                   }
                            }
                      );
                    }
                }
                catch
                {
                    Type primary = typeof(TWaspOutput);
                    return (TWaspOutput)Activator.CreateInstance(primary);
                }
            }
            else if (responseMessage.StatusCode == System.Net.HttpStatusCode.UnprocessableEntity || responseMessage.StatusCode == System.Net.HttpStatusCode.BadRequest || responseMessage.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                Log.Debug($"{MethodBase.GetCurrentMethod()} Response: {responseMessage}");

                TDTOOutput resultObject = default(TDTOOutput);
                TDTOOutput badRequestResponse = await responseMessage.Content.ReadAsAsync<TDTOOutput>();
                resultObject = mapper.Map<TDTOOutput>(badRequestResponse);

                if (resultObject is ZFscdPcCobrarWsResponseDTO obj3)
                {
                    var tmpListObj = new List<InnerError>();

                    if (obj3.ZFscdPcCobrarWsResponse == null)
                    {
                        throw new BusinessException(
                            responseMessage.StatusCode.ToString(),
                            responseMessage.StatusCode.ToString()
                            , new List<InnerError> {
                                new InnerError {
                                    ErrorCode = responseMessage.StatusCode.ToString(),
                                    ErrorMessage = JsonConvert.SerializeObject(responseMessage.ToString()),
                                    Detail = ""
                                }
                            }
                       );
                    }

                    foreach (var item in obj3.ZFscdPcCobrarWsResponse?.Errors)
                    {
                        foreach (var item1 in item.Errors)
                        {
                            tmpListObj.Add(
                               new InnerError
                               {
                                   ErrorCode = item1.ErrorCode,
                                   ErrorMessage = item1.ErrorCodeTxt
                               });
                        }
                    }

                    throw new BusinessException(
                        responseMessage.StatusCode.ToString(),
                         "", tmpListObj);
                }

             
                if (resultObject is ChargedReceiptLineDetailResponseDTO obj6)
                {
                    var tmpListObj = new List<InnerError>();

                    if(obj6.PcReceipts == null) {
                        throw new BusinessException(
                            responseMessage.StatusCode.ToString(),
                            responseMessage.StatusCode.ToString()
                            , new List<InnerError> {
                                new InnerError {
                                    ErrorCode = responseMessage.StatusCode.ToString(),
                                    ErrorMessage = JsonConvert.SerializeObject(responseMessage.ToString()),
                                    Detail = ""
                                }
                            }
                       );
                    }

                    foreach (var item5 in obj6.PcReceipts)
                    {
                        foreach (var item6 in item5.Status)
                        {
                            tmpListObj.Add(
                           new InnerError
                           {
                               ErrorCode = item6.ErrorCode,
                               ErrorMessage = item6.ErrorCodeTxt
                           });
                        }
                    }

                    throw new BusinessException(
                        responseMessage.StatusCode.ToString(),
                         "", tmpListObj);
                }

            }

            throw new BusinessException(
                    responseMessage.StatusCode.ToString(),
                    responseMessage.StatusCode.ToString()
                    , new List<InnerError>
                    {
                        new InnerError
                        {
                            ErrorCode = responseMessage.StatusCode.ToString(),
                            ErrorMessage = JsonConvert.SerializeObject(responseMessage.ToString()),
                            Detail = ""
                        }
                    }
                    );
        }
        #endregion
    }
}

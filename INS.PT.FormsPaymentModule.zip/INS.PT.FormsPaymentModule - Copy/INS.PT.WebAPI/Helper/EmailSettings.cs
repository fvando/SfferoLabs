﻿using Newtonsoft.Json;
namespace INS.PT.WebAPI.Helper
{
    public class EmailSettings
    {
        public string WSDLEmailSetting { get; set; }
        public string toAddresses { get; set; }
        public string fromAddress { get; set; }

        [JsonProperty(PropertyName = "Mail.Environment")]
        public string MailEnvironment { get; set; }

        [JsonProperty(PropertyName = "Mail.Company")]
        public string MailCompany { get; set; }
        public string Body { get; set; }
        public string Subject { get; set; }

        public string OriginalTransactionID { get; set; }
        public string OriginalSystemName { get; set; }
        public string EnvironmentName { get; set; }
        public string Author { get; set; }
        public string Company { get; set; }

    }
}

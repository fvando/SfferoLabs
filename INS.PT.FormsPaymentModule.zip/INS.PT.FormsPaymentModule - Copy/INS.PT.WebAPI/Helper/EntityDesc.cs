﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Constants.CommonEnums;

namespace INS.PT.WebAPI.Helper
{
    /// <summary>
    /// EntityDesc
    /// </summary>
    public static class EntityDesc
    {
        /// <summary>
        /// Gets the desc company.
        /// </summary>
        /// <param name="companyCode">The company code.</param>
        /// <returns></returns>
        public static EnumCompany GetDescCompany(string companyCode)
        {
            EnumCompany companyVal = EnumCompany.AgeasNaoVida;

            foreach (EnumCompany ev in Enum.GetValues(typeof(EnumCompany)))
            {
                string strValue = ev.GetStringValue();

                if (string.Compare(strValue, companyCode, StringComparison.InvariantCultureIgnoreCase) == 0)
                {
                    companyVal = ev;
                    break;
                }
            }
            return companyVal;
        }
        /// <summary>
        /// Gets the desc channel.
        /// </summary>
        /// <param name="channel">The channel.</param>
        /// <returns></returns>
        public static EnumHeader GetDescChannel(string channel)
        {
            if (channel == null)
            {
                return EnumHeader.Another;
            }
            else
            {

                EnumHeader channelVal = EnumHeader.DynamicForms;

                foreach (EnumHeader ev in Enum.GetValues(typeof(EnumHeader)))
                {
                    string strValue = ev.GetStringValue();

                    if (string.Compare(strValue, channel, StringComparison.InvariantCultureIgnoreCase) == 0)
                    {
                        channelVal = ev;
                        break;
                    }
                }
                return channelVal;


            }
        }

        /// <summary>
        /// Gets the desc payment.
        /// </summary>
        /// <param name="payment">The payment.</param>
        /// <returns></returns>
        //public static EnumPayments GetDescPayment(string payment)
        //{
        //    EnumPayments paymentVal = EnumPayments.AGENTE;

        //    foreach (EnumPayments ev in Enum.GetValues(typeof(EnumPayments)))
        //    {
        //        string strValue = ev.GetStringValue();

        //        if (string.Compare(strValue, payment, StringComparison.InvariantCultureIgnoreCase) == 0)
        //        {
        //            paymentVal = ev;
        //            break;
        //        }
        //    }
        //    return paymentVal;
        //}
    }
}

﻿using INS.PT.WebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Helper
{
    /// <summary>
    /// 
    /// </summary>
    public class PaymentMethodOption
    {
        /// <summary>
        /// Gets or sets the payment methods.
        /// </summary>
        /// <value>
        /// The payment methods.
        /// </value>
        public IEnumerable<PaymentMethod> PaymentMethods { get; set; } = new List<PaymentMethod>();

    }

}

﻿namespace INS.PT.WebAPI.Helpers
{
    public class DocumentDownloadWaspOutput
    {
        /// <summary>
        /// Document
        /// </summary>
        /// <value>Document</value>
        public byte[] Document { get; set; }
        /// <summary>
        /// Document Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// ContentType
        /// </summary>
        public string ContentType { get; set; }
        /// <summary>
        /// Error
        /// </summary>
        public string Error { get; set; }
    }
}
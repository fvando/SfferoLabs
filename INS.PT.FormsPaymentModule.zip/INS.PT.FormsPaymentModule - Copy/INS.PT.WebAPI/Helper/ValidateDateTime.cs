﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Helper
{
    /// <summary>
    /// ValidateDateTime
    /// </summary>
    public class ValidateDateTime
    {
        /// <summary>
        /// Converts to correctdatetime.
        /// </summary>
        /// <param name="dateString">The date string.</param>
        /// <param name="timeString">The time string.</param>
        /// <returns></returns>
        public static string ToCorrectDateTime(string dateString, string timeString = "")
        {
            string dateValue = null;

            if (!string.IsNullOrEmpty(dateString))
            {
                if (!string.IsNullOrEmpty(timeString))
                {
                    dateValue = DateTime.Parse(DateTime.ParseExact(dateString + timeString, "yyyyMMddHHmmss",
                        CultureInfo.InvariantCulture).ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'", CultureInfo.CurrentCulture), CultureInfo.CurrentCulture).ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'");
                }
                else
                {
                    dateValue = DateTime.Parse(DateTime.ParseExact(dateString, "yyyyMMdd", CultureInfo.InvariantCulture).AddHours(24).AddMinutes(59).ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.CurrentCulture), CultureInfo.CurrentCulture).ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'");
                }
            }

            return dateValue;
        }
    }
}

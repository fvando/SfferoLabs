﻿using Newtonsoft.Json;
using static INS.PT.WebAPI.Constants.CommonEnums;

namespace INS.PT.WebAPI.Helper
{
    public class SharePaymentInfo
    {
        /// <summary>
        /// Gets or sets the type send.
        /// </summary>
        /// <value>
        /// The type send.
        /// </value>
        /// <example>sms</example>
        [JsonProperty(PropertyName = "type")]
        [JsonRequired]
        public EnumTypeSend Type { get; set; }


        /// <summary>
        /// Gets or sets the recipient.
        /// </summary>
        /// <value>
        /// The recipient.
        /// </value>
        [JsonProperty(PropertyName = "recipient")]
        public string Recipient { get; set; }

    }
}

﻿
using System.Collections.Generic;

namespace INS.PT.WebAPI.Helper
{
    public class OracleSettings
    {
        public List<OraclePackageWebservice> OraclePackageWebservice { get; set; }

        public string sizeBuffer { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Helper
{
    public class BrokerDuckCreekSettings
    {
        /// <summary>
        /// Gets or sets the broker duck creek.
        /// </summary>
        /// <value>
        /// The broker duck creek.
        /// </value>
        public string BrokerDuckCreek { get; set; }

        /// <summary>
        /// Gets or sets the bs web service.
        /// </summary>
        /// <value>
        /// The bs web service.
        /// </value>
        public string BsWebService { get; set; }

        /// <summary>
        /// Gets or sets the name of the header user.
        /// </summary>
        /// <value>
        /// The name of the header user.
        /// </value>
        public string HeaderUserName { get; set; }

        /// <summary>
        /// Gets or sets the bs receipt notification web method.
        /// </summary>
        /// <value>
        /// The bs receipt notification web method.
        /// </value>
        public string BsReceiptNotificationWebMethod { get; set; }
    }
}

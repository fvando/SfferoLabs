﻿using AutoMapper;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.CommonLibrary.Exceptions.Models;
using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Models.Collections;
using INS.PT.WebAPI.Models.DTO;
using INS.PT.WebAPI.Models.DTO.Collections;
using INS.PT.WebAPI.Models.FinancialMPOS;
using INS.PT.WebAPI.Models.Input;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Constants.AgentsPortalConstants;

namespace INS.PT.WebAPI.Repository
{

    /// <summary>
    /// PaymentMposRepository 
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Data.BaseRepository" />
    /// <seealso cref="INS.PT.WebAPI.Interface.IPaymentMposRepository" />
    public class PaymentMposRepository : BaseRepository, IPaymentMposRepository
    {

        private const string MbWayPayment = "v1/mbwayPayment";
        private const string RefMBPayment = "v1/refMBPayment";

        private readonly IMapper mapper;
        private readonly IHttpClientRepository httpClientRepository;
        private readonly HttpRequest Request;
        private readonly IConfiguration configuration;


        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentMposRepository"/> class.
        /// </summary>
        /// <param name="_httpClientRepository">The HTTP client repository.</param>
        /// <param name="_repositoryInvoker">The repository invoker.</param>
        /// <param name="_applicationSettings">The application settings.</param>
        /// <param name="_mapper">The mapper.</param>
        /// <param name="_request">The request.</param>
        public PaymentMposRepository(IConfiguration _configuration, IHttpClientRepository _httpClientRepository, IRepositoryInvoker _repositoryInvoker, ApplicationSettings _applicationSettings, IMapper _mapper, HttpRequest _request)
            : base(_configuration, _applicationSettings, _repositoryInvoker, _request)
        {
            mapper = _mapper;
            httpClientRepository = _httpClientRepository;
            Request = _request;
        }

        /// <summary>
        /// Mbs the way payment asynchronous.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        public async Task<MBWayPaymentOutputDTO> MBWayPaymentAsync(MBWayPaymentInputDTO requestObject)
        {

            MBWayPaymentOutputDTO requestsOutput = null;

            HttpResponseMessage responseMessage = await httpClientRepository.ProcessRequestAsync(Request, applicationSettings.BrokerServicesNameSpaces.PaymentMpos, MbWayPayment, string.Empty, requestObject);

            if (responseMessage.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var response = await responseMessage.Content.ReadAsAsync<MBWayPaymentOutputDTO>();
                Log.Debug($"{MethodBase.GetCurrentMethod()} ResponseMessage: {JsonConvert.SerializeObject(response)}");
                requestsOutput = response;
            }
            else
            {
                var jsonString = await responseMessage.Content.ReadAsStringAsync();
                Log.Debug($"{MethodBase.GetCurrentMethod()} ResponseMessage: {JsonConvert.SerializeObject(jsonString)}");
                requestsOutput = JsonConvert.DeserializeObject<MBWayPaymentOutputDTO>(jsonString);
                Log.Debug($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(requestsOutput)}");

                throw new ProcessErrorException(
                    StatusCodes.Status404NotFound.ToString(),
                    requestsOutput.ErrorMessage, new List<ProcessErrorException.InnerError> {
                        new ProcessErrorException.InnerError{
                            ErrorCode =  requestsOutput.ErrorCode,
                            ErrorMessage = requestsOutput.ErrorMessage,
                            ErrorType = String.Empty
                        }
                    });
            }

            return requestsOutput;
        }

        /// <summary>
        /// References the mb payment asynchronous.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        public async Task<RefMBPaymentOutputDTO> RefMBPaymentAsync(RefMBPaymentInputDTO requestObject)
        {

            RefMBPaymentOutputDTO requestsOutput = null;

            HttpResponseMessage responseMessage = await httpClientRepository.ProcessRequestAsync(Request, applicationSettings.BrokerServicesNameSpaces.PaymentMpos, RefMBPayment, string.Empty, requestObject);

            if (responseMessage.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var response = await responseMessage.Content.ReadAsAsync<RefMBPaymentOutputDTO>();
                Log.Debug($"{MethodBase.GetCurrentMethod()} ResponseMessage: {JsonConvert.SerializeObject(response)}");
                requestsOutput = response;
            }
            else
            {
                var jsonString = await responseMessage.Content.ReadAsStringAsync();
                Log.Debug($"{MethodBase.GetCurrentMethod()} ResponseMessage: {JsonConvert.SerializeObject(jsonString)}");
                requestsOutput = JsonConvert.DeserializeObject<RefMBPaymentOutputDTO>(jsonString);
                Log.Debug($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(requestsOutput)}");

                throw new ProcessErrorException(
                    StatusCodes.Status404NotFound.ToString(),
                    requestsOutput.ErrorMessage, new List<ProcessErrorException.InnerError> {
                        new ProcessErrorException.InnerError {
                            ErrorCode =  requestsOutput.ErrorCode,
                            ErrorMessage = requestsOutput.ErrorMessage,
                            ErrorType = String.Empty
                        }
                    });

            }

            return requestsOutput;
        }
    }
}

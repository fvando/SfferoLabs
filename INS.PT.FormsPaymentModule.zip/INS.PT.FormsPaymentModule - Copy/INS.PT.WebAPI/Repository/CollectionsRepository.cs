﻿using AutoMapper;
using INS.PT.WebAPI.Constants;
using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Helpers;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Mappings;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Models.Collections;
using INS.PT.WebAPI.Models.DTO.Collections;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Constants.AgentsPortalConstants;

namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    /// CollectionsRepository : BaseRepository, ICollectionsRepository
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Data.BaseRepository" />
    /// <seealso cref="INS.PT.WebAPI.Interface.ICollectionsRepository" />
    public class CollectionsRepository : BaseRepository, ICollectionsRepository
    {
        #region Route Constants
        private const string CollectionsReceiptDetail = "v1/WebReceiptListing/List";
        private const string CollectionsCharged = "v1/ProvisionWebAccounts/Charged";
        private const string CollectionsProvisionWebAccountsValidate = "v1/ProvisionWebAccounts/Validate";
        private const string CollectionsGetProposalAIA = "v1/ProposalAIA/GetProposalAia";
        #endregion

        #region Properties
        private readonly IMapper mapper;
        private readonly HttpRequest Request;
        private readonly IHttpClientRepository httpClientRepository;
        private readonly IConfiguration configuration;
        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="CollectionsRepository"/> class.
        /// </summary>
        /// <param name="_httpClientRepository">The HTTP client repository.</param>
        /// <param name="_repositoryInvoker">The repository invoker.</param>
        /// <param name="_applicationSettings">The application settings.</param>
        /// <param name="_mapper">The mapper.</param>
        /// <param name="_request">The request.</param>
        public CollectionsRepository(IConfiguration _configuration, IHttpClientRepository _httpClientRepository,  IRepositoryInvoker _repositoryInvoker, ApplicationSettings _applicationSettings, IMapper _mapper, HttpRequest _request)
            : base(_configuration, _applicationSettings, _repositoryInvoker, _request)
        {
            mapper = _mapper;
            httpClientRepository = _httpClientRepository;
            Request = _request;
            configuration = _configuration;
        }

        #endregion

        #region Actions

        /// <summary>
        /// Receiptses the detail.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        public async Task<ReceiptDetailWaspOutput> ReceiptsDetail(ReceiptDetailWaspInput requestObject)
        {
            ReceiptDetailWaspOutput requestsOutput = null;
            var detailDTO = mapper.Map<ZFscdRecibosListarWsInputDTO>(requestObject);

            Request.Method = "POST";

            HttpResponseMessage responseMessage = await httpClientRepository.ProcessRequestAsync(Request, applicationSettings.BrokerServicesNameSpaces.Collections, CollectionsReceiptDetail, string.Empty, detailDTO);

            if (responseMessage.StatusCode == System.Net.HttpStatusCode.OK){
                var response = await responseMessage.Content.ReadAsAsync<ZFscdRecibosListarWsDTO>();
                requestsOutput = mapper.Map<ReceiptDetailWaspOutput>(response);
            }
            else{
                var jsonString = await responseMessage.Content.ReadAsStringAsync();
                requestsOutput = JsonConvert.DeserializeObject<ReceiptDetailWaspOutput>(jsonString);
                Log.Debug($"{MethodBase.GetCurrentMethod()} Response: {responseMessage}");

                if (requestsOutput?.Errors == null)  {
                    throw new ProcessErrorException(
                                            StatusCodes.Status404NotFound.ToString(),
                                            "Erros", new List<ProcessErrorException.InnerError>{
                                            new ProcessErrorException.InnerError{
                                                ErrorCode =  "001",
                                                ErrorMessage = "Não foram encontrados recibos"
                                            }
                                            });
                } else { 
                throw new ProcessErrorException(
                                        StatusCodes.Status404NotFound.ToString(),
                                        "Erros", new List<ProcessErrorException.InnerError>{
                                            new ProcessErrorException.InnerError{
                                                ErrorCode =  requestsOutput?.Errors?.FirstOrDefault()?.ErrorCode,
                                                ErrorMessage = requestsOutput?.Errors?.FirstOrDefault()?.ErrorCodeTxt == null? "Não foram encontrados recibos": requestsOutput?.Errors?.FirstOrDefault()?.ErrorCodeTxt
                                            }
                                        });
                }

            }
            return requestsOutput;
        }

        /// <summary>
        /// Chargeds the specified receipt number.
        /// </summary>
        /// <param name="receiptNumber">The receipt number.</param>
        /// <returns></returns>
        public async Task<ChargedReceiptLineDetailResponseWaspOuptut> Charged(string receiptNumber)
        {
            ///v1/ProvisionWebAccounts/Charged/{IdReceipt}
            ChargedReceiptsWaspInput requestObject = new ChargedReceiptsWaspInput(){
                PcReceipts = new List<ReceiptElement>() {
                    new ReceiptElement(){}}.ToList()
            };


            HttpRequestElement requestElement = new HttpRequestElement
            {
                ApiService = applicationSettings.BrokerServicesNameSpaces.Collections,
                ApiMethod = CollectionsCharged,
                QueryString = request.QueryString,
                RouteValue = $"/{receiptNumber}",
                Method = CommonEnums.HttpRequestVerb.GET
            };

            Task<ChargedReceiptLineDetailResponseWaspOuptut> output =
                repositoryInvoker.GenericInvokerDetailAsync<ChargedReceiptsWaspInput, ChargedReceiptLineDetailResponseWaspOuptut, ZFscdPcCobrarWsDTO, ChargedReceiptLineDetailResponseDTO>(requestElement);

            return await output;

        }

        public async Task<ValidateReceiptLineDetailResponseWaspOutput> ValidateChargeReceipts(ValidateReceiptsWaspInput requestObject)
        {
            HttpRequestElement requestElement = new HttpRequestElement
            {
                ApiService = applicationSettings.BrokerServicesNameSpaces.Collections,
                ApiMethod = CollectionsProvisionWebAccountsValidate,
                QueryString = request.QueryString,
                Method = CommonEnums.HttpRequestVerb.POST,
                RequestObject = requestObject
            };

            var output =
               await repositoryInvoker.GenericInvokerDetailAsync<ValidateReceiptsWaspInput, ValidateReceiptLineDetailResponseWaspOutput, ZFscdPcValidarWsDTO, ValidateReceiptLineDetailResponseDTO>(requestElement, false);
            return output;
        }

        public async Task<LifeProposalOutput> GetLifeProposalAsync(LifeProposalInput requestObject)
        {
            //ZageasLifeGetProposalDTO
            //ZeAiaProposalDTO
            //ZageasLifeGetProposalResponse1DTO
            //ZeAiaProposalDTO
            //ZfscdCodigosErroLinhaDTO

            //LifeGetProposalOutput-->ZageasLifeGetProposalResponse1DTO
            //ProposalInput --> ZageasLifeGetProposalDTO
            //ProposalElement --> ZeAiaProposalDTO
            //ProposalError --> ZfscdCodigosErroLinhaDTO

            HttpRequestElement requestElement = new HttpRequestElement
            {
                ApiService = applicationSettings.BrokerServicesNameSpaces.Collections,
                ApiMethod = CollectionsGetProposalAIA,
                QueryString = request.QueryString,
                Method = CommonEnums.HttpRequestVerb.POST,
                RequestObject = requestObject
            };

            var output =
               await repositoryInvoker.GenericInvokerDetailAsync<LifeProposalInput, LifeProposalOutput, ZageasLifeGetProposalDTO, ZageasLifeGetProposalResponse1DTO>(requestElement, false);
            return output;
        }

        #endregion
    }
}

﻿using AutoMapper;
using INS.PT.WebAPI.Constants;
using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Interface.v2;
using INS.PT.WebAPI.Models.AgentsPortal.CommercialStructure;
using INS.PT.WebAPI.Models.DTO.CommercialStructure;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    /// CommercialStructureRepository
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Data.BaseRepository" />
    /// <seealso cref="INS.PT.WebAPI.Interface.v2.ICommercialStructureRepository" />
    public class CommercialStructureRepository : BaseRepository, ICommercialStructureRepository
    {
        #region Properties

        private readonly IHttpClientRepository httpClientRepository;
        private readonly IMapper mapper;
        private readonly IConfiguration configuration;

        #endregion

        #region Route Constants

        private const string ClassificationAgentsMethod = "v1/ClassificationAgents/Classifications";

        #endregion

        public CommercialStructureRepository(IConfiguration _configuration, IHttpClientRepository _httpClientRepository, IRepositoryInvoker _repositoryInvoker,
          IMapper _mapper, ApplicationSettings _applicationSettings, HttpRequest _request)
                     : base(_configuration, _applicationSettings, _repositoryInvoker, _request)
        {
            httpClientRepository = _httpClientRepository;
            mapper = _mapper;
            httpClientRepository = _httpClientRepository;
       
        }


        /// <summary>
        /// Gets the agent classifications.
        /// </summary>
        /// <param name="idAgent">The identifier agent.</param>
        /// <returns></returns>
        public async Task<AgentClassificationWaspOutput> GetAgentClassifications(string idAgent)
        {
            
            HttpRequestElement requestElement = new HttpRequestElement
            {
                ApiService = applicationSettings.BrokerServicesNameSpaces.Agent,
                ApiMethod = ClassificationAgentsMethod,
                QueryString = request.QueryString,
                RouteValue = $"/{idAgent}",
                Method = CommonEnums.HttpRequestVerb.GET
            };

            return await repositoryInvoker.GenericInvokerAsync<AgentClassificationWaspOutput, AgentClassificationDTO>(requestElement);
        }
    }
}

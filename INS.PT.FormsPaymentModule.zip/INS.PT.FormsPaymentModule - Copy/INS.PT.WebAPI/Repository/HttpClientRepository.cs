﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Reflection;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using INS.PT.WebAPI.Configurations;
using INS.PT.WebAPI.Constants;
using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Models.AgentsPortal;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Serilog;

namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    /// HttpClientRepository
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.IHttpClientRepository" />
    public class HttpClientRepository : IHttpClientRepository
    {

        #region Properties
        private readonly IHttpClientFactory httpClientFactory;
        private readonly IHttpContextAccessor httpContext;
        private readonly ApplicationSettings applicationSettings;
        #endregion

        /// <summary>
        /// Gets the json settings.
        /// </summary>
        /// <value>
        /// The json settings.
        /// </value>
        public JsonSerializerSettings JsonSettings
        {
            get
            {
                JsonSerializerSettings settings = new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore,
                    Formatting = Formatting.Indented,
                    DefaultValueHandling = Newtonsoft.Json.DefaultValueHandling.Ignore
                };
                return settings;
            }
        }
        /// <summary>
        /// Gets the json formatter.
        /// </summary>
        /// <value>
        /// The json formatter.
        /// </value>
        public JsonMediaTypeFormatter JsonFormatter
        {
            get
            {
                var jsonFormatter = new JsonMediaTypeFormatter();
                jsonFormatter.SerializerSettings.DefaultValueHandling = Newtonsoft.Json.DefaultValueHandling.Ignore;
                jsonFormatter.SerializerSettings.NullValueHandling = Newtonsoft.Json.NullValueHandling.Ignore;
                return jsonFormatter;
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="HttpClientRepository"/> class.
        /// </summary>
        /// <param name="_httpClientFactory">The HTTP client factory.</param>
        /// <param name="_applicationSettings">The application settings.</param>
        public HttpClientRepository(IHttpClientFactory _httpClientFactory, ApplicationSettings _applicationSettings, IHttpContextAccessor _httpContext)
        {
            httpClientFactory = _httpClientFactory;
            httpContext = _httpContext;
            applicationSettings = _applicationSettings;
        }

        /// <summary>
        /// Processes the request asynchronous.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> ProcessRequestAsync(HttpRequestElement request)
        {
            HttpResponseMessage responseMessage = null;

            Log.Debug($" Request Element: {JsonConvert.SerializeObject(request, JsonSettings)}");

            HttpClient client = httpClientFactory.CreateClient();
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.ContentType, applicationSettings.ContentTypeJson);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.WebService, request.ApiService);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Solution, applicationSettings.BrokerSettings.Solution);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.User, applicationSettings.BrokerSettings.User);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdCompany, applicationSettings.BrokerSettings.IdCompany);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdNetwork, applicationSettings.BrokerSettings.IdNetwork);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdSource, applicationSettings.BrokerSettings.IdSource);

            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Webmethod, request.ApiMethod);

            Log.Debug($" Headers: {client.DefaultRequestHeaders}");

            switch (request.Method)
            {
                case CommonEnums.HttpRequestVerb.GET:
                    responseMessage = await client.GetAsync($"{applicationSettings.BrokerSettings.Endpoint}{request.RouteValue}{request.QueryString}");
                    Log.Debug($" GET Endpoint Configuration: {applicationSettings.BrokerSettings.Endpoint}{request.RouteValue}{request.QueryString}");
                    break;
                case CommonEnums.HttpRequestVerb.POST:
                    responseMessage = await client.PostAsync($"{applicationSettings.BrokerSettings.Endpoint}", request.RequestObject, JsonFormatter);
                    Log.Debug($" POST Endpoint Configuration: {applicationSettings.BrokerSettings.Endpoint} Body: {JsonConvert.SerializeObject(request.RequestObject, JsonSettings)}");
                    break;
                case CommonEnums.HttpRequestVerb.PUT:
                    responseMessage = await client.PutAsync($"{applicationSettings.BrokerSettings.Endpoint}{request.RouteValue}{request.QueryString}", request.RequestObject, JsonFormatter);
                    Log.Debug($" PUT Endpoint Configuration: {applicationSettings.BrokerSettings.Endpoint}{request.RouteValue}{request.QueryString} Body: {JsonConvert.SerializeObject(request.RequestObject, JsonSettings)}");
                    break;
                case CommonEnums.HttpRequestVerb.UPDATE:
                    break;
                case CommonEnums.HttpRequestVerb.DELETE:
                    responseMessage = await client.DeleteAsync($"{applicationSettings.BrokerSettings.Endpoint}{request.RouteValue}{request.QueryString}");
                    Log.Debug($" DELETE Endpoint Configuration: {applicationSettings.BrokerSettings.Endpoint}{request.RouteValue}{request.QueryString}");
                    break;
            }

            return responseMessage;
        }

        public async Task<HttpResponseMessage> ProcessRequestAsync(HttpRequestElement request, Boolean isUpload = false, bool jsonBroker = false)
        {
            HttpResponseMessage responseMessage = null;

            Log.Debug($" Request Element: {JsonConvert.SerializeObject(request, JsonSettings)}");

            HttpClient client = httpClientFactory.CreateClient();
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.ContentType, applicationSettings.ContentTypeJson);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Accept, applicationSettings.ContentTypeJson);
            
            if (!request.Headers.Any(p => string.Compare(p.Key, AgentsPortalConstants.BrokerHeader.Solution, StringComparison.InvariantCultureIgnoreCase) == 0))
            {
                client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Solution, applicationSettings.BrokerSettings.Solution);
            }

            if (!request.Headers.Any(p => string.Compare(p.Key, AgentsPortalConstants.BrokerHeader.User, StringComparison.InvariantCultureIgnoreCase) == 0))
            {
                client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.User, applicationSettings.BrokerSettings.User);
            }

            //// check for the existing header request bsUser
            //if (httpContext.HttpContext.Request.Headers.TryGetValue(AgentsPortalConstants.BrokerHeader.User, out var requestBsUserValue)
            //    // and confirm a valid value exists
            //    && !string.IsNullOrEmpty(requestBsUserValue))
            //{
            //    // pass valid value(s) to the new request
            //    client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.User, requestBsUserValue.ToList());
            //}
            //else
            //{
            //    // add bsUser header to the following request
            //    client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.User, applicationSettings.BrokerSettings.User);
            //}

            if (!request.Headers.Any(p => string.Compare(p.Key, AgentsPortalConstants.BrokerHeader.IdCompany, StringComparison.InvariantCultureIgnoreCase) == 0))
            {
                client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdCompany, applicationSettings.BrokerSettings.IdCompany);
            }

            if (!request.Headers.Any(p => string.Compare(p.Key, AgentsPortalConstants.BrokerHeader.IdNetwork, StringComparison.InvariantCultureIgnoreCase) == 0))
            {
                client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdNetwork, applicationSettings.BrokerSettings.IdNetwork);
            }

            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdSource, applicationSettings.BrokerSettings.IdSource);

            httpContext.HttpContext.Request.Headers.TryGetValue("X-Correlation-ID", out var correlationIds);

            if (!string.IsNullOrEmpty(correlationIds))
            {
                request.Headers.Add(new KeyValuePair<string, string>("X-Correlation-ID", httpContext.HttpContext.Request.Headers["X-Correlation-ID"]));
            }
            else
            {
                request.Headers.Add(new KeyValuePair<string, string>("X-Correlation-ID", Guid.NewGuid().ToString()));
            }

            if (!isUpload)
            {
                client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.WebService, request.ApiService);
                if (request.ApiService != null && request.ApiService.Equals(applicationSettings.BrokerServicesNameSpaces.AgentsPortal))
                {
                    httpContext.HttpContext.Request.Headers.TryGetValue("Hamed-Cache-Control", out var hamedControlIds);

                    if (!string.IsNullOrEmpty(hamedControlIds))
                    {
                        request.Headers.Add(new KeyValuePair<string, string>("Hamed-Cache-Control", httpContext.HttpContext.Request.Headers["Hamed-Cache-Control"]));
                    }
                }

                client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Webmethod, request.ApiMethod);
            }

            if (request.Headers != null)
            {
                foreach (var header in request.Headers)
                {
                    client.DefaultRequestHeaders.TryAddWithoutValidation(header.Key, header.Value);
                }
            }

            Log.Debug($" Headers: {client.DefaultRequestHeaders}");

            // TODO
            //Valid input is json
            string stringPayload = string.Empty;
            bool isJson = false;
            try
            {
                if (request.RequestObject != null)
                {
                    if (request.RequestObject is string)
                    {
                        JObject.Parse(request.RequestObject.ToString());
                    }

                    stringPayload = await Task.Run(() => JsonConvert.SerializeObject(request.RequestObject));
                }
            }
            catch
            {
                if (request.RequestObject != null) stringPayload = request.RequestObject.ToString();
                isJson = true;
            }
            switch (request.Method)
            {
                case CommonEnums.HttpRequestVerb.GET:
                    responseMessage = await client.GetAsync($"{applicationSettings.BrokerSettings.Endpoint}{request.RouteValue}{request.QueryString}");
                    Log.Debug($" GET Endpoint Configuration: {applicationSettings.BrokerSettings.Endpoint}{request.RouteValue}{request.QueryString}");
                    break;
                case CommonEnums.HttpRequestVerb.POST:
                    StringContent httpContent;

                    if (!isUpload)
                    {
                        //Case input is not json change new content type for post/put
                        //httpContent = new StringContent(stringPayload, Encoding.UTF8, "application/json");
                        httpContent = new StringContent(stringPayload, Encoding.UTF8, "application/json");

                        if (jsonBroker)
                        {
                            var addressconcat = string.Concat(applicationSettings.BrokerSettings.Endpoint, request.RouteValue);
                            responseMessage = await client.PostAsync($"{addressconcat}", httpContent);
                        }
                        else
                        {
                            responseMessage = await client.PostAsync($"{applicationSettings.BrokerSettings.Endpoint}", httpContent);
                        }
                    }
                    else
                    {
                        client.DefaultRequestHeaders.TryAddWithoutValidation("Content-Type", "multipart/form-data");

                        MultipartFormDataContent form = new MultipartFormDataContent();
                        form.Add(new StringContent(((UploadDocumentWaspInput)request.RequestObject).Uploadby.ToString()), "Uploadby");
                        form.Add(new StringContent(((UploadDocumentWaspInput)request.RequestObject).Number), "Number");
                        form.Add(new StringContent(((UploadDocumentWaspInput)request.RequestObject).Company.ToString()), "Company");
                        form.Add(new StringContent(((UploadDocumentWaspInput)request.RequestObject).DocType.ToString()), "DocType");
                        form.Add(new StringContent(((UploadDocumentWaspInput)request.RequestObject).User), "User");
                        form.Add(new StringContent(((UploadDocumentWaspInput)request.RequestObject).FileName), "FileName");
                        form.Add(new StringContent(((UploadDocumentWaspInput)request.RequestObject).File), "File");

                        string endPoint = string.Concat(applicationSettings.BrokerSettings.Endpoint, "/", request.ApiService, "/", request.ApiMethod);
                        responseMessage = await client.PostAsync($"{endPoint}", form);
                    }
                    //Log.Debug($" POST Endpoint Configuration: {applicationSettings.BrokerSettings.Endpoint} Body: {JsonConvert.SerializeObject(request.RequestObject, JsonSettings)}");
                    Log.Debug($" POST Endpoint Configuration: {applicationSettings.BrokerSettings.Endpoint} Body: {JsonConvert.SerializeObject(request.RequestObject, JsonSettings)}");
                    break;
                case CommonEnums.HttpRequestVerb.PUT:
                    responseMessage = await client.PutAsync($"{applicationSettings.BrokerSettings.Endpoint}{request.RouteValue}{request.QueryString}", request.RequestObject, JsonFormatter);
                    Log.Debug($" PUT Endpoint Configuration: {applicationSettings.BrokerSettings.Endpoint}{request.RouteValue}{request.QueryString} Body: {JsonConvert.SerializeObject(request.RequestObject, JsonSettings)}");
                    break;
                case CommonEnums.HttpRequestVerb.UPDATE:
                    break;
                case CommonEnums.HttpRequestVerb.DELETE:
                    responseMessage = await client.DeleteAsync($"{applicationSettings.BrokerSettings.Endpoint}{request.RouteValue}{request.QueryString}");
                    Log.Debug($" DELETE Endpoint Configuration: {applicationSettings.BrokerSettings.Endpoint}{request.RouteValue}{request.QueryString}");
                    break;
            }

            return responseMessage;
        }

        /// <summary>
        /// Processes the request asynchronous.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="service">The service.</param>
        /// <param name="method">The method.</param>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> ProcessRequestAsync(HttpRequest request, string service, string method, object requestObject = null)
        {
            return await ProcessRequestAsync(request, service, method, null, requestObject);
        }

        /// <summary>
        /// Processes the request asynchronous.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="service">The service.</param>
        /// <param name="method">The method.</param>
        /// <param name="routeValue">The route value.</param>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        public async Task<HttpResponseMessage> ProcessRequestAsync(HttpRequest request, string service, string method, string routeValue, object requestObject = null)
        {
            HttpResponseMessage responseMessage = null;

            HttpClient client = httpClientFactory.CreateClient();
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.ContentType, applicationSettings.ContentTypeJson);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.WebService, service);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Solution, applicationSettings.BrokerSettings.Solution);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.User, applicationSettings.BrokerSettings.User);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdCompany, applicationSettings.BrokerSettings.IdCompany);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdNetwork, applicationSettings.BrokerSettings.IdNetwork);

            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Webmethod, method);

            Log.Debug($" Headers: {client.DefaultRequestHeaders}");

            switch (request.Method)
            {
                case "GET":
                    responseMessage = await client.GetAsync($"{applicationSettings.BrokerSettings.Endpoint}{routeValue}{request.QueryString}");
                    Log.Debug($" GET Endpoint Configuration: {applicationSettings.BrokerSettings.Endpoint}{routeValue}{request.QueryString}");
                    break;
                case "POST":
                    responseMessage = await client.PostAsync($"{applicationSettings.BrokerSettings.Endpoint}", requestObject, JsonFormatter);
                    Log.Debug($" POST Endpoint Configuration: {applicationSettings.BrokerSettings.Endpoint} Body: {JsonConvert.SerializeObject(requestObject, JsonSettings)}");
                    break;
                case "PUT":
                    responseMessage = await client.PutAsync($"{applicationSettings.BrokerSettings.Endpoint}{routeValue}{request.QueryString}", requestObject, JsonFormatter);
                    Log.Debug($" PUT Endpoint Configuration: {applicationSettings.BrokerSettings.Endpoint}{routeValue}{request.QueryString} Body: {JsonConvert.SerializeObject(requestObject, JsonSettings)}");
                    break;
                case "UPDATE":
                    break;
                case "DELETE":
                    responseMessage = await client.DeleteAsync($"{applicationSettings.BrokerSettings.Endpoint}{routeValue}{request.QueryString}");
                    Log.Debug($" DELETE Endpoint Configuration: {applicationSettings.BrokerSettings.Endpoint}{routeValue}{request.QueryString}");
                    break;
            }

            return responseMessage;
        }

        /// <summary>
        /// Processes the request asynchronous.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="service">The service.</param>
        /// <param name="method">The method.</param>
        /// <param name="routeValue">The route value.</param>
        /// <param name="directURL">The direct URL.</param>
        /// <param name="autenticationObj">The autentication object.</param>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        [ObsoleteAttribute("This Method is obsolete. Use ProcessRequestAsync(HttpRequestElement request)")]
        public async Task<HttpResponseMessage> ProcessRequestAsync(HttpRequest request, string service, string method, string routeValue, string directURL, string autenticationObj, object requestObject = null)
        {
            HttpResponseMessage responseMessage = null;

            HttpClient client = httpClientFactory.CreateClient();
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.ContentType, applicationSettings.ContentTypeJson);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.WebService, service);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Solution, applicationSettings.BrokerSettings.Solution);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.User, applicationSettings.BrokerSettings.User);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdCompany, applicationSettings.BrokerSettings.IdCompany);
            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.IdNetwork, applicationSettings.BrokerSettings.IdNetwork);

            client.DefaultRequestHeaders.TryAddWithoutValidation(AgentsPortalConstants.BrokerHeader.Webmethod, method);

            Log.Error($" Headers: {client.DefaultRequestHeaders}");

            string endpoint = directURL ?? applicationSettings.BrokerSettings.Endpoint;
            if (!string.IsNullOrEmpty(autenticationObj))
            {
                var byteArray = System.Text.Encoding.ASCII.GetBytes(autenticationObj);
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", System.Convert.ToBase64String(byteArray));
            }

            switch (request.Method)
            {
                case "GET":
                    responseMessage = await client.GetAsync($"{endpoint}{routeValue}{request.QueryString}");
                    Log.Debug($" Get Endpoint Configuration: {endpoint}{routeValue}{request.QueryString}");
                    break;
                case "POST":
                    responseMessage = await client.PostAsync($"{endpoint}", requestObject, JsonFormatter);
                    Log.Debug($" POST Endpoint Configuration: {endpoint} Body: {JsonConvert.SerializeObject(requestObject, JsonSettings)}");
                    break;
                case "PUT":
                    responseMessage = await client.PutAsync($"{endpoint}{routeValue}{request.QueryString}", requestObject, JsonFormatter);
                    Log.Debug($" POST Endpoint Configuration: {endpoint}{routeValue}{request.QueryString} Body: {JsonConvert.SerializeObject(requestObject, JsonSettings)}");
                    break;
                case "UPDATE":
                    break;
                case "DELETE":
                    responseMessage = await client.DeleteAsync($"{endpoint}{routeValue}{request.QueryString}");
                    Log.Debug($" POST Endpoint Configuration: {endpoint}{routeValue}{request.QueryString}");
                    break;
            }

            return responseMessage;
        }
    }
}

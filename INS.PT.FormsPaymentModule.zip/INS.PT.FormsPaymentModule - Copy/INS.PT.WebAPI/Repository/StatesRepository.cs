﻿using INS.PT.WebAPI.Constants;
using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Models.Domain;
using INS.PT.WebAPI.Models.DTO.Domain;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Constants.CommonEnums;

namespace INS.PT.WebAPI.Repository
{
    public class StatesRepository : BaseRepository, IStatesRepository
    {

        private const string EntityRoute = "{" + nameof(Entity.IdEntity) + "}";
        private const string ContactsRoute = EntityRoute + "/" + nameof(Entity.Contacts);

        private readonly IHttpClientRepository httpClientRepository;
        private const string GetSettingsMethod = "v1/ReferenceData";
        private const string GetEntitiesSearchMethod = "v1/Entities/search";
        private const string GetContactsByEntityMethod = "v1/Entities";
        private const string VMESSAGE = "Not found, please try again.";
        private readonly IMemoryCache cache;


        public StatesRepository(IConfiguration _configuration, IRepositoryInvoker _repositoryInvoker,
            IHttpClientRepository _httpClientRepository, ApplicationSettings _applicationSettings,  HttpRequest _request, IMemoryCache _cache) : base(_configuration, _applicationSettings, _repositoryInvoker, _request)
        {
            cache = _cache;
            httpClientRepository = _httpClientRepository;
        }

        public async Task<GlobalEntityOutput> GetListEntities(GlobalEntityInput requestObject)
        {
            HttpRequestElement requestElement = new HttpRequestElement
            {
                ApiService = configuration.GetSection("BrokerSettingsReferenceData").GetSection("WebService").Value,
                ApiMethod = GetSettingsMethod,
                Method = CommonEnums.HttpRequestVerb.POST,
                QueryString = request.QueryString,
                Options = new OptionsElement { HandleList404Response = true },
                RequestObject = requestObject,
                ContentType = configuration.GetSection("BrokerSettingsReferenceData").GetSection("ContentTypeJson").Value,
                EndPoint = configuration.GetSection("BrokerSettingsReferenceData").GetSection("Endpoint").Value,
                Solution = configuration.GetSection("BrokerSettingsReferenceData").GetSection("Solution").Value,
                User = configuration.GetSection("BrokerSettingsReferenceData").GetSection("User").Value

            };

            var output =
             await repositoryInvoker.GenericInvokerAsync<GlobalEntityOutput, GlobalEntityOutputDTO>(requestElement);

            return output;
        }

        public async Task<GlobalEntityOutput> GetListAll(DomainsData requestObject)
        {
            HttpRequestElement requestElement = new HttpRequestElement
            {

                ApiService = configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsReferenceData").GetSection("WebService").Value,
                ApiMethod = GetSettingsMethod,
                Method = CommonEnums.HttpRequestVerb.GET,
                Options = new OptionsElement { HandleList404Response = true },
                RouteValue = $"/{requestObject}?PageSize=1000",
                ContentType = configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsReferenceData").GetSection("ContentTypeJson").Value,
                EndPoint = configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsReferenceData").GetSection("Endpoint").Value,
                Solution = configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsReferenceData").GetSection("Solution").Value,
                User = configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsReferenceData").GetSection("User").Value
            };

            var output =
              await repositoryInvoker.GenericInvokerAsync<GlobalEntityOutput, GlobalEntityOutputDTO>(requestElement);

            return output;
        }

        public async Task<GlobalEntityOutput> SetMemoryCache(DomainsData IdDomain, Boolean Active = false)
        {
            string state = string.Empty;
            GlobalEntityOutput cacheObj = null;

            if (Active)
            {
                if (!cache.TryGetValue($"CashedDomainReferenceData_{IdDomain}", out Dictionary<string, object> states))
                {
                    //Chamar o método e carregar do referenceData
                    states = new Dictionary<string, object>
                    {
                        {
                            IdDomain.ToString(),
                            await GetListAll(IdDomain)
                        }
                    };
                    MemoryCacheEntryOptions options = new MemoryCacheEntryOptions
                    {
                        AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(Convert.ToDouble(configuration
                        .GetSection("ApplicationSettings").GetSection("CacheDomain")
                            .GetSection("AbsoluteExpirationRelativeToNow").Value)), // cache will expire in 300 seconds or 5 minutes
                        SlidingExpiration = TimeSpan.FromSeconds(Convert.ToDouble(configuration
                        .GetSection("ApplicationSettings").GetSection("CacheDomain")
                            .GetSection("SlidingExpiration").Value)) // cache will expire if inactive for 60 seconds
                    };
                    if (states != null)
                    {
                        cache.Set($"CashedDomainReferenceData_{IdDomain}", states, options);
                        Log.Debug($"key: {JsonConvert.SerializeObject($"CashedDomainReferenceData_{IdDomain}")}");
                        Log.Debug($"States: {JsonConvert.SerializeObject(states)}");
                        Log.Debug($"Options: {JsonConvert.SerializeObject(options)}");
                    }
                }
                else
                {
                    Log.Information($"Cache: ***Data Found in Cache...***");
                    Log.Debug($"key: {JsonConvert.SerializeObject($"CashedDomainReferenceData_{IdDomain}")}");
                }

                if (states != null)
                {
                    //typecast return object
                    cacheObj = (GlobalEntityOutput)states.GetValueOrDefault(IdDomain.ToString());

                    if (cacheObj == null)
                    {
                        state = VMESSAGE;
                    }
                }
            }
            else
            {
                //get objects from service referenceData
                cacheObj = await GetListAll(IdDomain);
            }

            return cacheObj;
        }

        public async Task<string> GetbyValueAsync(string codInterno, CommonEnums.DomainsData domainData)
        {
            string retorno = string.Empty;
            
            var cacheObjReturn = await SetMemoryCache(domainData, configuration.GetSection("ApplicationSettings").GetSection("CacheDomain").GetSection("Active").Value.Equals("true", StringComparison.InvariantCulture));

            //Test for InternalCode
            if (!string.IsNullOrEmpty(codInterno))
            {
                if (!string.IsNullOrEmpty(cacheObjReturn?.resultList?.FirstOrDefault()?.extraProperties?.CodInterno))
                {
                    retorno = cacheObjReturn?.resultList.FirstOrDefault(x => x?.extraProperties?.CodInterno == codInterno)?.Description;
                }
                else
                {
                    retorno = cacheObjReturn?.resultList.FirstOrDefault(x => x?.IdElement == codInterno)?.Description;
                }
            }

            return retorno;
        }


        public async Task<SearchEntityOutput> GetEntitiesSearchAsync(SearchEntityInput requestObject)
        {
            HttpRequestElement requestElement = new HttpRequestElement
            {
                ApiService = configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsGlobalEntity").GetSection("WebService").Value, 
                ApiMethod = GetEntitiesSearchMethod,
                Method = CommonEnums.HttpRequestVerb.POST,
                //QueryString = request.QueryString,
                RequestObject = requestObject,
                ContentType = configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsGlobalEntity").GetSection("ContentTypeJson").Value,
                EndPoint = configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsGlobalEntity").GetSection("Endpoint").Value
                //Solution = configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsGlobalEntity").GetSection("Solution").Value,
                //User = configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsGlobalEntity").GetSection("User").Value
            };

            //temporary
            //Necessary to activated process on FormsPaymentsModule
            requestElement.Headers.Add(new KeyValuePair<string, string>("bsUser", configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsGlobalEntity").GetSection("User").Value));
            requestElement.Headers.Add(new KeyValuePair<string, string>("bsSolution", configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsGlobalEntity").GetSection("Solution").Value));

            var output =
             await repositoryInvoker.GenericInvokerAsync<SearchEntityOutput, SearchEntityOutput>(requestElement);

            return output;
        }


        public async Task<ContactLists> GetContactsByEntityAsync(EntitiesInput requestObject)
        {
            HttpRequestElement requestElement = new HttpRequestElement
            {
                ApiService = configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsGlobalEntity").GetSection("WebService").Value, 
                ApiMethod = GetContactsByEntityMethod,
                Method = CommonEnums.HttpRequestVerb.GET,
                QueryString = request.QueryString,
                RouteValue = $"/{requestObject.IdEntity}/Contacts",
                RequestObject = requestObject,
                ContentType = configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsGlobalEntity").GetSection("ContentTypeJson").Value,
                EndPoint = configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsGlobalEntity").GetSection("Endpoint").Value,
                Solution = configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsGlobalEntity").GetSection("Solution").Value,
                User = configuration.GetSection("ApplicationSettings").GetSection("BrokerSettingsGlobalEntity").GetSection("User").Value

            };
            var output =
             await repositoryInvoker.GenericInvokerAsync<ContactLists, ContactLists>(requestElement);

            return output;
        }

    }
}

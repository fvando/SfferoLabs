﻿using AutoMapper;
using INS.PT.WebAPI.Interface;
using Microsoft.Extensions.Configuration;
using System;
using System.Data;
using System.Reflection;
using Oracle.ManagedDataAccess.Client;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Types;
using Serilog;

namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    /// GetEntityPaymentRepository
    /// </summary>
    public sealed class GetEntityPaymentRepository : IGetEntityPaymentRepository
    {
        #region Route Constants
        const int sizeBuffer = 1000;
        const string ObjectData = "result";
        #endregion

        #region Properties

        private readonly IConfiguration configuration;
        private readonly IDbconnectioncs connection;
        private readonly IMapper mapper;
        private readonly Action<IDbConnection, OracleDynamicParameters> searchEntityPackage;
        public IMapper Mapper => mapper;
        public Action<IDbConnection, OracleDynamicParameters> SearchEntityPackage => searchEntityPackage;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="GetEntityPaymentRepository"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        /// <param name="connection">The connection.</param>
        /// <param name="mapper">The mapper.</param>
        public GetEntityPaymentRepository(IConfiguration configuration, IDbconnectioncs connection, IMapper mapper) : this(configuration, connection, null, null)
        { }

        /// <summary>
        /// Initializes a new instance of the <see cref="GetEntityPaymentRepository"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        /// <param name="connection">The connection.</param>
        /// <param name="mapper">The mapper.</param>
        /// <param name="searchEntityPackage">The search entity package.</param>
        public GetEntityPaymentRepository(IConfiguration configuration, IDbconnectioncs connection, IMapper mapper
            , Action<IDbConnection, OracleDynamicParameters> searchEntityPackage)
        {
            this.configuration = configuration;
            this.connection = connection;
            this.mapper = mapper;
        }

        #endregion

        #region Actions

        /// <summary>
        /// Validates the parameters.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        OracleDynamicParameters IGetEntityPaymentRepository.ValidateParams(string parameters)
        {
            Log.Debug($"ValidateParams Request: {JsonConvert.SerializeObject(parameters)}");
            try
            {
                OracleDynamicParameters DyParam = new OracleDynamicParameters();
                //OutPut parameter
                DyParam.Add(ObjectData, OracleDbType.RefCursor, direction: ParameterDirection.Output);
                //InPut parameter
                DyParam.Add("v_code_company", OracleDbType.Varchar2, direction: ParameterDirection.Input, value: parameters);
                Log.Debug($"ValidateParams Response: {JsonConvert.SerializeObject(DyParam)}");
                return DyParam;
            }
            catch (Exception e)
            {
                Log.Error(e, String.Empty);
                throw;
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }

        /// <summary>
        /// Submits the store procedure.
        /// </summary>
        /// <param name="OracleExec">The oracle execute.</param>
        /// <param name="OracleParaCompany">The oracle para company.</param>
        /// <returns></returns>
        public string SubmitStoreProcedure(string OracleExec, string OracleParaCompany)
        {
            var result = "";
            var sql = @"begin :result :=" + OracleExec +"(v_code_company => :v_code_company); end;";

            using (OracleConnection con = new OracleConnection(configuration.GetSection("ConnectionStrings").GetSection("DBConnection").Value))
            using (OracleCommand com = new OracleCommand())
            {
                com.Connection = con;
                con.Open();
                com.Parameters.Add(":result", OracleDbType.RefCursor, ParameterDirection.Output);
                com.Parameters.Add(":v_code_company", OracleParaCompany);
                com.CommandText = sql;
                com.CommandType = CommandType.Text;
                com.ExecuteNonQuery();
                OracleRefCursor curr = (OracleRefCursor)com.Parameters[0].Value;
                using (OracleDataReader dr = curr.GetDataReader())
                {
                    if (dr.Read())
                    {
                        result = dr.GetString(0);
                    }
                }
            }
            return result;
        }

        #endregion
    }
}

﻿using AutoMapper;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.CommonLibrary.Redis.Interfaces;
using INS.PT.CommonLibrary.Redis.Models;
using INS.PT.WebAPI.Constants;
using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Interface.v2;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Collections;
using INS.PT.WebAPI.Models.DuckCreek;
using INS.PT.WebAPI.Models.FinancialMPOS;
using INS.PT.WebAPI.Models.Input.v2;
using INS.PT.WebAPI.Models.Output;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using Serilog;
using Service.Email;
using Service.SMS;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ServiceModel;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Repository.v2
{
    /// <summary>
    /// PaymentsRepository
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.IPayments" />
    public class PaymentsRepository : BaseRepository, IPayments
    {

        #region Route Constants
        private const string GetBeforeChargeProposalAiaMethod = "v1/ProposalAIA/GetBeforeChargeProposalAia";
        private const string PostUpdProposalAiaAiaMethod = "v1/ProposalAIA/UpdProposalAia";
        const string ConstPrintType = "E";
        const string ConstIdDocument = "idD";
        const string ConstPrefixDoc = "RC";
        const string ConstPrefixProposalAiaDoc = "R2";
        const string ConstThirdParty = "0";
        const string ConstErrorMessage = "Not Found";
        const string ConstErrorMessageAgente = "DocId Not Found";
        const string ConstMessageSms = "Referência enviada para o telemóvel indicado";
        const string ConstMessageEmail = "Referência enviada para o e-mail indicado";
        const string ConstMessageEmailUnsuccessfull = "Send E-mail Unsuccessfull";
        const string ConstMessageRedis = "Sincronização não realizada, contexto expirado";
        const string ConstMessageMbReference = "Este recibo tem forma de cobrança SDD e já se encontra em circuito bancário pelo que já não é possível efetuar a cobrança utilizando outro método de pagamento";


        #endregion

        #region Properties

        private readonly ICollectionsRepository collectionsRepository;
        private readonly IPaymentMposRepository paymentMposRepository;
        private readonly IGetEntityPaymentRepository getEntityPaymentRepository;
        private readonly IConfiguration configuration;
        private readonly IHttpClientRepository httpClientRepository;
        private readonly IMapper mapper;

        private readonly IRedisManager redisManager;
        private readonly SendMailWSSoap serviceEMail;
        private readonly SendSoap serviceSms;

        protected readonly HttpRequest request;
        protected readonly Stopwatch stopwatch;

        protected readonly TimeSpan OpenTimeout;
        protected readonly TimeSpan CloseTimeout;
        protected readonly TimeSpan SendTimeout;
        protected readonly TimeSpan ReceiveTimeout;
        protected readonly TimeSpan RestTimeout;

        #endregion

        #region Constructors

        public PaymentsRepository(IConfiguration _configuration, IHttpClientRepository _httpClientRepository, IRepositoryInvoker _repositoryInvoker, ApplicationSettings _applicationSettings, IMapper _mapper, HttpRequest _request, ICollectionsRepository _collectionsRepository, IPaymentMposRepository _paymentMposRepository, IGetEntityPaymentRepository _getEntityPaymentRepository, IRedisManager _redisManager) : this(_configuration, _httpClientRepository, _repositoryInvoker, _applicationSettings, _mapper, _request, _collectionsRepository, _paymentMposRepository, _getEntityPaymentRepository, _redisManager, null, null)
        { }

        public PaymentsRepository(IConfiguration _configuration, IHttpClientRepository _httpClientRepository, IRepositoryInvoker _repositoryInvoker, ApplicationSettings _applicationSettings, IMapper _mapper, HttpRequest _request, ICollectionsRepository _collectionsRepository, IPaymentMposRepository _paymentMposRepository, IGetEntityPaymentRepository _getEntityPaymentRepository, IRedisManager _redisManager, SendMailWSSoap _serviceEMail, SendSoap _serviceSms)
       : base(_configuration, _applicationSettings, _repositoryInvoker)
        {
            request = _request;
            redisManager = _redisManager;
            mapper = _mapper;
            httpClientRepository = _httpClientRepository;
            collectionsRepository = _collectionsRepository ?? throw new ArgumentNullException(nameof(_collectionsRepository));
            paymentMposRepository = _paymentMposRepository ?? throw new ArgumentNullException(nameof(_paymentMposRepository));
            getEntityPaymentRepository = _getEntityPaymentRepository ?? throw new ArgumentNullException(nameof(_getEntityPaymentRepository));

            #region Binding

            configuration = _configuration;

            // read timeouts from config
            OpenTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:OpenTimeout");
            CloseTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:CloseTimeout");
            SendTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:SendTimeout");
            ReceiveTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:ReceiveTimeout");
            RestTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:RestTimeout");

            var binding = new BasicHttpBinding
            {
                MaxReceivedMessageSize = int.MaxValue,
                MaxBufferPoolSize = int.MaxValue,
                MaxBufferSize = int.MaxValue,
                AllowCookies = true,
                TransferMode = TransferMode.Buffered,
                SendTimeout = SendTimeout,
                ReceiveTimeout = ReceiveTimeout,
                CloseTimeout = CloseTimeout,
                OpenTimeout = OpenTimeout,
                ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max
            };

            #endregion

            #region Email
            //Email
            // read enpoint address
            EndpointAddress addressEmail = null;
            if (applicationSettings?.EmailSettings?.WSDLEmailSetting != String.Empty)
            {
                addressEmail = new System.ServiceModel.EndpointAddress(applicationSettings?.EmailSettings?.WSDLEmailSetting);
            }

            // check if it is http or https
            if (string.Compare(addressEmail?.Uri?.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            }
            else
            {
                binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            }

            // return proxy
            serviceEMail = new SendMailWSSoapClient(binding, addressEmail);

            #endregion

            #region SMS
            //sms
            // read enpoint address
            EndpointAddress addressSms = null;
            if (applicationSettings?.SmsSettings?.WSDLSmsSetting != String.Empty) {
                addressSms = new System.ServiceModel.EndpointAddress(applicationSettings?.SmsSettings?.WSDLSmsSetting);
            }

            // check if it is http or https
            if (string.Compare(addressSms?.Uri?.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            }
            else
            {
                binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;
            }

            // return proxy
            serviceSms = new SendSoapClient(binding, addressSms);

            #endregion

            stopwatch = new Stopwatch();

        }

        #endregion

      

        /// <summary>
        /// Method to register payment request.
        /// </summary>
        /// <param name="parameters">Parameters register payment.</param>
        /// <returns>
        /// Object with results.
        /// </returns>
        /// <exception cref="ProcessErrorException">
        /// Erros
        /// or
        /// Erros
        /// or
        /// Erros
        /// </exception>
        public async Task<PaymentOutput> MakePaymentAsync(HttpRequest requestValue, PaymentsInput parameters)
        {
            //GetContext - Channel
            StringValues token;
            requestValue?.Headers.TryGetValue("Authorization", out token);

            var keyQuery = String.Empty;
            keyQuery = $"{ApplicationSettings.ApplicationName}-{parameters.ReceiptNumber}-{token}";
            RedisOutput<PaymentOutput> contextPayment = await redisManager.GetContextAsync<PaymentOutput>(keyQuery);

            var channel = String.Empty;
            if (contextPayment.IsValid)
            {
                channel = contextPayment.Value.Channel;
            }else
            {
                ////get receipt informations
                var requestObject = new ReceiptDetailWaspInput
                {
                    ReferenceDocumentNumber = parameters.ReceiptNumber
                };

                ////WebReceiptList
                var receiptResult = await PostReceiptsDetailWaspAsync(requestObject);
                var contract = receiptResult?.ReceiptsNumbers?.FirstOrDefault()?.Contract;

                keyQuery = $"{ApplicationSettings.ApplicationName}-{contract}-{token}";
                contextPayment = await redisManager.GetContextAsync<PaymentOutput>(keyQuery);

                if (contextPayment.IsValid)
                {
                    channel = contextPayment.Value.Channel;
                }
                else {
                    Log.Error($"{"No Context Data Information on Redis"}");
                    throw new ProcessErrorException(
                        StatusCodes.Status404NotFound.ToString(),
                        "Erros", new List<ProcessErrorException.InnerError>{
                                            new ProcessErrorException.InnerError{
                                                ErrorCode =  "Redis",
                                                ErrorMessage = "No Context Data Information on Redis"
                                            }
                        }
                        );
                }
            }


            switch (channel)
            {
                case null:
                case nameof(Constants.CommonEnums.EnumHeader.DynamicForms):
                    return await MakePaymentByDinamicsAsync(requestValue, parameters);

                case nameof(Constants.CommonEnums.EnumHeader.UnitLinked):

                    stopwatch.Stop();
                    Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds} ms");
                    return await MakePaymentByUniLinkAsync(requestValue, parameters);

                default:

                    Log.Error($"{"Unauthorized Channel"}");
                    throw new ProcessErrorException(
                        StatusCodes.Status404NotFound.ToString(),
                        "Erros", new List<ProcessErrorException.InnerError>{
                                        new ProcessErrorException.InnerError{
                                            ErrorCode =  "Channel",
                                            ErrorMessage = "Unauthorized Channel"
                                        }
                        }
                        );
            }
        }

        /// <summary>
        /// MakePaymentByDinamicsAsync
        /// </summary>
        /// <param name="requestValue"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<PaymentOutput> MakePaymentByDinamicsAsync(HttpRequest requestValue, PaymentsInput parameters)
        {

            ReceiptDetailWaspOutput receiptRequestAgentResult = null;
            //Logging Default
            Log.Debug($"MakePayment Request: {JsonConvert.SerializeObject(parameters)}");

            //ValidaInput
            ValidInputPayment(parameters);
            var appOrigem = applicationSettings.PaymentMethodOption.AppOrigem;
            List<PaymentMethod> paymentMethods = applicationSettings.PaymentMethodOption.PaymentMethods.ToList();

            PaymentOutput result = null;
            try
            {

                #region DadosPolicy
                //set ReceiptDetail
                var receiptRequestAgent = new ReceiptDetailWaspInput
                {
                    ReferenceDocumentNumber = parameters.ReceiptNumber
                };

                stopwatch.Restart();
                Log.Debug("PostReceiptsDetailWaspAsync SAP Request: {mbreferenceReceiptResultAgent}", JsonConvert.SerializeObject(receiptRequestAgent));

                //WebReceiptList
                receiptRequestAgentResult = await PostReceiptsDetailWaspAsync(receiptRequestAgent);

                stopwatch.Stop();
                Log.Debug("PostReceiptsDetailWaspAsync SAP Response: {mbreferenceReceiptResultAgent} in {Elapsed:000} ms", JsonConvert.SerializeObject(receiptRequestAgentResult), stopwatch.ElapsedMilliseconds);

                #endregion

                switch (parameters.IdPaymentMethod)
                {
                    #region MBWay
                    case CommonEnums.EnumPayments.MbWay:
                        Log.Debug("Payment Selected: {MbWay}", nameof(CommonEnums.EnumPayments.MbWay));

                        if ((receiptRequestAgentResult?.Errors.Count) <= 0)
                        {
                            const string ConstPaymentBrand = "1";

                            //Call Api Financial - MBWayPayment
                            MBWayPaymentInputDTO mbway = null;

                            foreach (var item in receiptRequestAgentResult?.ReceiptsNumbers)
                            {
                                var TimestampTmp = DateTime.Now.ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'");
                                var UserIdTmp = ValidateField.ValidateAgent(!string.IsNullOrEmpty(item.InsuranceAgent) ? item.InsuranceAgent : !string.IsNullOrEmpty(item.InsuranceBroker) ? item.InsuranceBroker : "");

                                mbway = new MBWayPaymentInputDTO()
                                {
                                    AppOrigemId = appOrigem,
                                    InternalCompany = item.CompanyCode,
                                    Nif = ValidateField.ValidateNif(item.TaxNum),
                                    PaymentBrand = ConstPaymentBrand,
                                    PhoneNumber = parameters.AditionalInformation,
                                    PrintType = ConstPrintType,
                                    Receipts = new List<Models.PaymentMPOS.PaymentReceipt>() {
                                            new Models.PaymentMPOS.PaymentReceipt(){
                                                Amount = item.TotalValue,
                                                IdDocument = ConstIdDocument,
                                                IdReceipt = item.ReferenceDocumentNumber,
                                                Policy = item.Contract,
                                                PrefixDoc = ConstPrefixDoc,
                                                ThirdParty = false
                                            }
                                        },
                                    ThirdParty = ConstThirdParty,
                                    Timestamp = TimestampTmp,
                                    TotalAmount = item.TotalValue,
                                    UserId = UserIdTmp
                                };
                            }

                            //Call WebReceiptList
                            stopwatch.Restart();
                            Log.Debug("PostMBWayPaymentAsync SIBS Request: {mbway}", JsonConvert.SerializeObject(mbway));
                            MBWayPaymentOutputDTO resultMbWay = await PostMBWayPaymentAsync(mbway);
                            stopwatch.Stop();
                            Log.Debug("PostMBWayPaymentAsync SIBS Response: {resultMbWay} in {Elapsed:000} ms", JsonConvert.SerializeObject(resultMbWay), stopwatch.ElapsedMilliseconds);

                            var StatusCodesTmp = resultMbWay.ErrorCode == "200" ? StatusCodes.Status200OK.ToString() : String.Empty;
                            result = new PaymentOutput()
                            {
                                IdPaymentMethod = nameof(CommonEnums.EnumPayments.MbWay),
                                Code = resultMbWay.ErrorCode,
                                Status = resultMbWay.Status,
                                Message = resultMbWay.ErrorMessage,
                                MerchantTransactionId = resultMbWay.MerchantTransactionId,
                                StatusCodes = StatusCodesTmp
                            };

                            Log.Debug("PaymentOutput SIBS Response: {result} in {Elapsed:000} ms", JsonConvert.SerializeObject(result), stopwatch.ElapsedMilliseconds);

                            //Update Redis
                            await UpdatePaymentMethodOnRedisAsync(requestValue, result, receiptRequestAgentResult);

                        }
                        else
                        {
                            throw new ProcessErrorException(
                                StatusCodes.Status400BadRequest.ToString(),
                                "Erros", new List<ProcessErrorException.InnerError>{
                                        new ProcessErrorException.InnerError{
                                            ErrorCode =  receiptRequestAgentResult?.Errors?.FirstOrDefault()?.ErrorCode,
                                            ErrorMessage = receiptRequestAgentResult?.Errors?.FirstOrDefault()?.ErrorCodeTxt
                                        }
                                }
                                );
                        }

                        break;
                    #endregion

                    #region MBReference
                    case CommonEnums.EnumPayments.MbReference:
                        stopwatch.Restart();
                        Log.Debug("Payment Selected: {MbReference}", nameof(CommonEnums.EnumPayments.MbReference));
                        var refLmtDtTm = String.Empty;

                        if ((receiptRequestAgentResult?.Errors.Count) <= 0)
                        {
                            const string ConstPaymentBrand = "2";

                            //ReceipStatu == 2, 3 - Este recibo tem forma de cobrança SDD e já se encontra em circuito bancário pelo que já não é possível efetuar a cobrança utilizando outro método de pagamento
                            //ValidaFormasdePagamento
                            var doublecheckreceiptFlag = receiptRequestAgentResult?.ReceiptsNumbers?.FirstOrDefault()?.SibsStatus;
                            if (doublecheckreceiptFlag.Equals("2"))
                            {
                                Log.Error($"{doublecheckreceiptFlag}");
                                throw new ProcessErrorException(
                                    StatusCodes.Status400BadRequest.ToString(),
                                    "Erros", new List<ProcessErrorException.InnerError>{
                                        new ProcessErrorException.InnerError{
                                            ErrorCode =  StatusCodes.Status400BadRequest.ToString(),
                                            ErrorMessage = ConstMessageMbReference
                                        }
                                    }
                                    );
                            }

                            //Call Api Financial - refMbPayment
                            RefMBPaymentInputDTO refmbreference = null;

                            foreach (var item in receiptRequestAgentResult?.ReceiptsNumbers)
                            {
                                //Receipt of tests
                                var entityValue = GetEntityPayment(item.CompanyCode);
                                refLmtDtTm = (parameters?.ReceiptNumber == "55643929") ? DateTime.Now.AddDays(2).ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'") :
                                    ValidateDateTime.ToCorrectDateTime(item.NetDueDate).ToString();
                                refmbreference = new RefMBPaymentInputDTO()
                                {
                                    PtMntEntty = entityValue,
                                    RefIntlDtTm = (parameters?.ReceiptNumber == "55643929") ? DateTime.Now.AddDays(1).ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'") :
                                            ValidateDateTime.ToCorrectDateTime(item.EmissionDate, item.EmissionHour).ToString(),
                                    RefLmtDtTm = (parameters?.ReceiptNumber == "55643929") ? DateTime.Now.AddDays(2).ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'") :
                                            ValidateDateTime.ToCorrectDateTime(item.NetDueDate).ToString(),
                                    Timestamp = DateTime.Now.ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'"),
                                    AppOrigemId = appOrigem,
                                    InternalCompany = item.CompanyCode,
                                    Nif = item.TaxNum,
                                    PaymentBrand = ConstPaymentBrand, //Valor Default
                                    PrintType = ConstPrintType,
                                    Receipts = new List<Models.PaymentMPOS.PaymentReceipt>()
                                    {
                                        new Models.PaymentMPOS.PaymentReceipt()
                                        {
                                            Amount = item.TotalValue,
                                            IdDocument = ConstIdDocument,
                                            IdReceipt = item.ReferenceDocumentNumber,
                                            Policy = item.Contract,
                                            PrefixDoc = ConstPrefixDoc,
                                            ThirdParty = false
                                        }
                                    },
                                    ThirdParty = ConstThirdParty,
                                    TotalAmount = item.TotalValue,
                                    UserId = ValidateField.ValidateAgent(!string.IsNullOrEmpty(item.InsuranceAgent) ? item.InsuranceAgent : !string.IsNullOrEmpty(item.InsuranceBroker) ? item.InsuranceBroker : "")
                                };
                            }

                            stopwatch.Restart();
                            Log.Debug("PostRefMBWayPaymentAsync MPOS Request: {receiptMbReferenceRequestObject}", JsonConvert.SerializeObject(refmbreference));

                            var resultrefMbWay = await PostRefMBWayPaymentAsync(refmbreference);

                            stopwatch.Stop();
                            Log.Debug("PostRefMBWayPaymentAsync MPOS Response: {resultrefMbWay} in {Elapsed:000} ms", JsonConvert.SerializeObject(resultrefMbWay), stopwatch.ElapsedMilliseconds);
                            //Customization Message
                            var tempMessage = applicationSettings.PaymentMethodOption.PaymentMethods.FirstOrDefault(opt => opt.IdPaymentMethod == CommonEnums.EnumPayments.MbReference).Message;
                            var StatusCodestmp = resultrefMbWay.ErrorCode == "200" ? StatusCodes.Status200OK.ToString() : String.Empty;
                            var MessageTmp = string.IsNullOrEmpty(tempMessage) ? resultrefMbWay.ErrorMessage : tempMessage;

                            result = new PaymentOutput()
                            {
                                IdPaymentMethod = nameof(CommonEnums.EnumPayments.MbReference),
                                StatusCodes = StatusCodestmp,
                                Code = resultrefMbWay.ErrorCode,
                                Status = resultrefMbWay.Status,
                                Message = MessageTmp,
                                MerchantTransactionId = resultrefMbWay.MerchantTransactionId,
                                Amount = resultrefMbWay.Amount,
                                Entity = resultrefMbWay.Entity,
                                Reference = resultrefMbWay.Reference,
                                DueDate = refLmtDtTm
                            };

                            Log.Debug("PaymentOutput SIBS Response: {result} in {Elapsed:000} ms", JsonConvert.SerializeObject(result), stopwatch.ElapsedMilliseconds);

                            //Update Redis
                            await UpdatePaymentMethodOnRedisAsync(requestValue, result, receiptRequestAgentResult);

                        }
                        else
                        {
                            throw new ProcessErrorException(
                                                     StatusCodes.Status400BadRequest.ToString(),
                                                     "Erros", new List<ProcessErrorException.InnerError>
                                                     {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  receiptRequestAgentResult?.Errors?.FirstOrDefault()?.ErrorCode,
                                       ErrorMessage = receiptRequestAgentResult?.Errors?.FirstOrDefault()?.ErrorCodeTxt
                                   }
                                                     });
                        }

                        break;
                    #endregion

                    #region ChipPin
                    case CommonEnums.EnumPayments.ChipPin:
                        stopwatch.Restart();
                        Log.Debug("Payment Selected: {ChipPin}", nameof(CommonEnums.EnumPayments.ChipPin));

                        var paymentChip = paymentMethods?.Where(x => x.IdPaymentMethod == CommonEnums.EnumPayments.ChipPin).ToList();

                        result = new PaymentOutput()
                        {
                            IdPaymentMethod = nameof(CommonEnums.EnumPayments.ChipPin),
                            Message = paymentChip?.FirstOrDefault()?.Message,
                            Code = StatusCodes.Status200OK.ToString(),
                            StatusCodes = StatusCodes.Status200OK.ToString()
                        };

                        stopwatch.Stop();
                        Log.Debug("PaymentOutput Response: {result} in {Elapsed:000} ms", JsonConvert.SerializeObject(result), stopwatch.ElapsedMilliseconds);

                        //Update Redis
                        await UpdatePaymentMethodOnRedisAsync(requestValue, result, receiptRequestAgentResult);

                        break;
                    #endregion

                    #region Agent
                    case CommonEnums.EnumPayments.Agente:
                        Log.Debug("Payment Selected: {Agente}", nameof(CommonEnums.EnumPayments.Agente));
                        if ((receiptRequestAgentResult?.Errors.Count) <= 0)
                        {
                            stopwatch.Restart();
                            //Sepa or Balcao
                            if (receiptRequestAgentResult?.ReceiptsNumbers?.FirstOrDefault()?.PaymentMethod == nameof(CommonEnums.EnumPaymentsAgentSAP.SEPA) ||
                                receiptRequestAgentResult?.ReceiptsNumbers?.FirstOrDefault()?.PaymentMethod == nameof(CommonEnums.EnumPaymentsAgentSAP.BALCAO))
                            {
                                var paymentMethodsAgent = applicationSettings.PaymentMethodOption.PaymentMethods
                                    .ToList().Where(x => x.IdPaymentMethod == CommonEnums.EnumPayments.Agente).ToList();

                                result = new PaymentOutput()
                                {
                                    //O recibo será incluído automaticamente numa prestação de contas
                                    IdPaymentMethod = nameof(CommonEnums.EnumPayments.Agente),
                                    Message = paymentMethodsAgent?.FirstOrDefault()?.Message,
                                    Code = StatusCodes.Status200OK.ToString(),
                                    StatusCodes = StatusCodes.Status200OK.ToString()
                                };

                                stopwatch.Stop();
                                Log.Debug("PaymentOutput Response: {result} in {Elapsed:000} ms", JsonConvert.SerializeObject(result), stopwatch.ElapsedMilliseconds);

                                //Update Redis
                                await UpdatePaymentMethodOnRedisAsync(requestValue, result, receiptRequestAgentResult);

                            }//Mediador                            
                            else if (receiptRequestAgentResult.ReceiptsNumbers.FirstOrDefault().PaymentMethod == nameof(CommonEnums.EnumPaymentsAgentSAP.MEDIADOR))
                            {
                                //get payments
                                var paymentMethodsAgentM = applicationSettings.PaymentMethodOption.PaymentMethods
                                    .ToList().Where(x => x.IdPaymentMethod == CommonEnums.EnumPayments.Agente).ToList();

                                stopwatch.Restart();
                                Log.Debug("PostChargedWaspAsync SAP Request: {ReceiptNumber}", JsonConvert.SerializeObject(parameters.ReceiptNumber));

                                //put Charged
                                var paymentAgentStatus = await PostChargedWaspAsync(parameters.ReceiptNumber);

                                stopwatch.Stop();
                                Log.Debug("PostChargedWaspAsync SAP Response: {mbreferenceReceiptResultAgent} in {Elapsed:000} ms", JsonConvert.SerializeObject(paymentAgentStatus), stopwatch.ElapsedMilliseconds);
                                var StatusCodesTmp = paymentAgentStatus?.PcReceipts.FirstOrDefault()?.Status.FirstOrDefault()?.ErrorCode == "200" ? StatusCodes.Status200OK.ToString() : String.Empty;

                                //Return unsucess
                                result = new PaymentOutput()
                                {
                                    IdPaymentMethod = nameof(CommonEnums.EnumPayments.Agente),
                                    Message = paymentAgentStatus?.PcReceipts.FirstOrDefault()?.Status.FirstOrDefault()?.ErrorCodeTxt,
                                    Code = paymentAgentStatus?.PcReceipts.FirstOrDefault()?.Status.FirstOrDefault()?.ErrorCode,
                                    StatusCodes = StatusCodesTmp
                                };

                                stopwatch.Restart();
                                stopwatch.Stop();
                                Log.Debug("PaymentOutput Response: {result} in {Elapsed:000} ms", JsonConvert.SerializeObject(result), stopwatch.ElapsedMilliseconds);


                                //Update Redis
                                await UpdatePaymentMethodOnRedisAsync(requestValue, result, receiptRequestAgentResult);

                            }
                        }
                        else
                        {
                            throw new ProcessErrorException(
                                                     StatusCodes.Status400BadRequest.ToString(),
                                                     "Erros", new List<ProcessErrorException.InnerError>{
                                                         new ProcessErrorException.InnerError{
                                                             ErrorCode =  receiptRequestAgentResult?.Errors?.FirstOrDefault()?.ErrorCode,
                                                             ErrorMessage = receiptRequestAgentResult?.Errors?.FirstOrDefault()?.ErrorCodeTxt
                                                         }
                                                     });
                        }
                        break;
                    #endregion

                    #region Sepa
                    case CommonEnums.EnumPayments.Sepa:
                        stopwatch.Restart();
                        Log.Debug("Payment Selected: {Sepa}", nameof(CommonEnums.EnumPayments.Sepa));

                        var paymentMethodsSepa = applicationSettings.PaymentMethodOption.PaymentMethods.ToList().Where(x => x.IdPaymentMethod == CommonEnums.EnumPayments.Sepa).ToList();

                        if ((receiptRequestAgentResult?.Errors.Count) <= 0)
                        {
                            result = new PaymentOutput()
                            {
                                IdPaymentMethod = nameof(CommonEnums.EnumPayments.Sepa),
                                Message = paymentMethodsSepa?.FirstOrDefault()?.Message,
                                Code = StatusCodes.Status200OK.ToString(),
                                StatusCodes = StatusCodes.Status200OK.ToString()
                            };

                            stopwatch.Stop();
                            Log.Debug("PaymentOutput Response: {result} in {Elapsed:000} ms", JsonConvert.SerializeObject(result), stopwatch.ElapsedMilliseconds);

                            //Update Redis
                            await UpdatePaymentMethodOnRedisAsync(requestValue, result, receiptRequestAgentResult);

                        }
                        else
                        {
                            throw new ProcessErrorException(
                                                     StatusCodes.Status400BadRequest.ToString(),
                                                     "Erros", new List<ProcessErrorException.InnerError>{
                                                         new ProcessErrorException.InnerError{
                                                             ErrorCode =  receiptRequestAgentResult?.Errors?.FirstOrDefault()?.ErrorCode,
                                                             ErrorMessage = receiptRequestAgentResult?.Errors?.FirstOrDefault()?.ErrorCodeTxt
                                                         }
                                                     });
                        }

                        break;
                    #endregion

                    #region Tesouraria
                    case CommonEnums.EnumPayments.Tesouraria:
                        stopwatch.Restart();
                        Log.Debug("Payment Selected: {Tesouraria}", nameof(CommonEnums.EnumPayments.Tesouraria));


                        var paymentMethodsTesouraria = applicationSettings.PaymentMethodOption.PaymentMethods.ToList().Where(x => x.IdPaymentMethod ==
                        CommonEnums.EnumPayments.Tesouraria).ToList();

                        if ((receiptRequestAgentResult?.Errors.Count) <= 0)
                        {
                            result = new PaymentOutput()
                            {
                                IdPaymentMethod = nameof(CommonEnums.EnumPayments.Tesouraria),
                                Message = paymentMethodsTesouraria?.FirstOrDefault()?.Message,
                                Code = StatusCodes.Status200OK.ToString(),
                                StatusCodes = StatusCodes.Status200OK.ToString()
                            };


                            stopwatch.Stop();
                            Log.Debug("PaymentOutput Response: {result} in {Elapsed:000} ms", JsonConvert.SerializeObject(result), stopwatch.ElapsedMilliseconds);

                            //Update Redis
                            await UpdatePaymentMethodOnRedisAsync(requestValue, result, receiptRequestAgentResult);

                        }
                        else
                        {
                            throw new ProcessErrorException(
                                                     StatusCodes.Status400BadRequest.ToString(),
                                                     "Erros", new List<ProcessErrorException.InnerError>{
                                                         new ProcessErrorException.InnerError{
                                                             ErrorCode =  receiptRequestAgentResult?.Errors?.FirstOrDefault()?.ErrorCode,
                                                             ErrorMessage = receiptRequestAgentResult?.Errors?.FirstOrDefault()?.ErrorCodeTxt
                                                         }
                                                     });
                        }
                        break;
                    #endregion

                    #region Default
                    default:

                        stopwatch.Stop();
                        Log.Debug($"default Payments Response Time: {stopwatch.ElapsedMilliseconds}ms");

                        break;

                        #endregion
                }

                //Make Param
                return result;
            }

            #region ErrorExceptions
            catch (AggregateException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);

                var errorNumber = StatusCodes.Status404NotFound.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message,
                        ErrorType = String.Empty
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message,
                            ErrorType = String.Empty
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            catch (TimeoutException e)
            {
                await UpdatePaymentMethodOnRedisAsync(requestValue, result, receiptRequestAgentResult);
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                await UpdatePaymentMethodOnRedisAsync(requestValue, result, receiptRequestAgentResult);
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (BusinessException e)
            {
                await UpdatePaymentMethodOnRedisAsync(requestValue, result, receiptRequestAgentResult);
                Log.Error("Unsuccessful call! Status with exception: {e}", e);

                var errorNumber = StatusCodes.Status404NotFound.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    //In this case, return innerErros filled
                    var innerExcepErrors = ((BusinessException)e)?.InnerErrors;
                    if (innerExcepErrors == null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = e.Message
                        });
                    }
                    else
                    {
                        foreach (var item in innerExcepErrors)
                        {
                            innerErrors.Add(new ProcessErrorException.InnerError
                            {
                                ErrorCode = errorNumber,
                                ErrorMessage = innerExcepErrors?.FirstOrDefault()?.ErrorMessage,
                                ErrorType = String.Empty
                            });
                        }
                    }
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message,
                            ErrorType = String.Empty
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            catch (FaultException e)
            {
                await UpdatePaymentMethodOnRedisAsync(requestValue, result, receiptRequestAgentResult);
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                await UpdatePaymentMethodOnRedisAsync(requestValue, result, receiptRequestAgentResult);
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    //In this case, return innerErros filled
                    var innerExcepErrors = ((ProcessErrorException)e)?.InnerErrors;
                    if (innerExcepErrors == null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = e.Message
                        });
                    }
                    else
                    {
                        foreach (var item in innerExcepErrors)
                        {
                            innerErrors.Add(new ProcessErrorException.InnerError
                            {
                                ErrorCode = errorNumber,
                                ErrorMessage = innerExcepErrors?.FirstOrDefault()?.ErrorMessage,
                                ErrorType = String.Empty
                            });
                        }
                    }
                }
                else
                {
                    await UpdatePaymentMethodOnRedisAsync(requestValue, result, receiptRequestAgentResult);
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }

            #endregion
        }

        /// <summary>
        /// MakePaymentByUniLinkAsync
        /// </summary>
        /// <param name="requestValue"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public async Task<PaymentOutput> MakePaymentByUniLinkAsync(HttpRequest requestValue, PaymentsInput parameters)
        {
            Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse resultDataProposalSap = null;
            List<PaymentMethod> paymentMethods = applicationSettings.PaymentMethodOption.PaymentMethods.ToList();
            PaymentOutput result = null;

            //ValidaInput
            ValidInputPayment(parameters);

            try
            {
                #region DadosProposal
                //set Proposal Detail
                //Call ProposalSAP
                resultDataProposalSap = await CallProposalAsync(parameters.ReceiptNumber);
                #endregion

                switch (parameters.IdPaymentMethod)
                {
                
                    #region MBWay
                    case CommonEnums.EnumPayments.MbWay:
                        result = await CallPaymentMbWayAsync(parameters, requestValue, resultDataProposalSap);
                        break;
                    #endregion

                    #region MBReference
                    case CommonEnums.EnumPayments.MbReference:
                        result = await CallPaymentMbReferenceAsync(parameters, requestValue, resultDataProposalSap);
                        break;
                    #endregion

                    #region Default
                    default:

                        stopwatch.Stop();
                        Log.Debug($"default Payments Response Time: {stopwatch.ElapsedMilliseconds}ms");

                        break;

                        #endregion
                }

                //Make Param
                return result;
            }

            #region ErrorExceptions
            catch (AggregateException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);

                var errorNumber = StatusCodes.Status404NotFound.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message,
                        ErrorType = String.Empty
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message,
                            ErrorType = String.Empty
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            catch (TimeoutException e)
            {
                //await UpdatePaymentMethodOnRedisAsync(requestValue, result, resultDataProposalSap);
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                //await UpdatePaymentMethodOnRedisAsync(requestValue, result, resultDataProposalSap);
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (BusinessException e)
            {
                //await UpdatePaymentMethodOnRedisAsync(requestValue, result, resultDataProposalSap);
                Log.Error("Unsuccessful call! Status with exception: {e}", e);

                var errorNumber = StatusCodes.Status404NotFound.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    //In this case, return innerErros filled
                    var innerExcepErrors = ((BusinessException)e)?.InnerErrors;
                    if (innerExcepErrors == null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = e.Message
                        });
                    }
                    else
                    {
                        foreach (var item in innerExcepErrors)
                        {
                            innerErrors.Add(new ProcessErrorException.InnerError
                            {
                                ErrorCode = errorNumber,
                                ErrorMessage = innerExcepErrors?.FirstOrDefault()?.ErrorMessage,
                                ErrorType = String.Empty
                            });
                        }
                    }
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message,
                            ErrorType = String.Empty
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            catch (FaultException e)
            {
                //await UpdatePaymentMethodOnRedisAsync(requestValue, result, resultDataProposalSap);
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (CanonicalException e)
            {
                //await UpdatePaymentMethodOnRedisAsync(requestValue, result, resultDataProposalSap);
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                //await UpdatePaymentMethodOnRedisAsync(requestValue, result, resultDataProposalSap);
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    //In this case, return innerErros filled
                    var innerExcepErrors = ((ProcessErrorException)e)?.InnerErrors;
                    if (innerExcepErrors == null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = e.Message
                        });
                    }
                    else
                    {
                        foreach (var item in innerExcepErrors)
                        {
                            innerErrors.Add(new ProcessErrorException.InnerError
                            {
                                ErrorCode = errorNumber,
                                ErrorMessage = innerExcepErrors?.FirstOrDefault()?.ErrorMessage,
                                ErrorType = String.Empty
                            });
                        }
                    }
                }
                else
                {
                    //await UpdatePaymentMethodOnRedisAsync(requestValue, result, resultDataProposalSap);
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            #endregion
        }

        /// <summary>
        /// Posts the reference mb way payment asynchronous.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        public async Task<RefMBPaymentOutputDTO> PostRefMBWayPaymentAsync(RefMBPaymentInputDTO requestObject)
        {
            return await paymentMposRepository.RefMBPaymentAsync(requestObject);
        }

        /// <summary>
        /// Posts the mb way payment asynchronous.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException"></exception>
        /// <exception cref="ProcessErrorException.InnerError"></exception>
        public async Task<MBWayPaymentOutputDTO> PostMBWayPaymentAsync(MBWayPaymentInputDTO requestObject)
        {
            return await paymentMposRepository.MBWayPaymentAsync(requestObject);
        }

        /// <summary>
        /// Posts the receipts detail wasp.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        public async Task<ReceiptDetailWaspOutput> PostReceiptsDetailWaspAsync(ReceiptDetailWaspInput requestObject)
        {
            return await collectionsRepository.ReceiptsDetail(requestObject);
        }

        /// <summary>
        /// Gets the before charge proposal aia asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public async Task<Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse> GetBeforeChargeProposalAiaAsync(PaymentMethodsInput parameters)
        {
            //Structure Create
            var requestObject =
                 new Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWs()
                 {
                     IProposalNumber = parameters.Id
                 };

            //Logging Default
            stopwatch.Restart();
            Log.Debug($"GetBeforeChargeProposalAiaAsync requestObject Request: {JsonConvert.SerializeObject(requestObject)}");

            HttpRequestElement requestElement = new HttpRequestElement
            {
                ApiService = applicationSettings.BrokerServicesNameSpaces.Collections,
                ApiMethod = GetBeforeChargeProposalAiaMethod,
                QueryString = request.QueryString,
                Method = CommonEnums.HttpRequestVerb.POST,
                RequestObject = requestObject
            };

            //Logging Default
            Log.Debug($"GetBeforeChargeProposalAiaAsync requestElement Request: {JsonConvert.SerializeObject(requestElement)}");

            stopwatch.Restart();
            Log.Debug($"GetBeforeChargeProposalAiaAsync requestElement Request: {JsonConvert.SerializeObject(requestElement)}");

            Task<Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse> output = repositoryInvoker
                .GenericInvokerAsync<Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse, Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse>(requestElement);

            stopwatch.Stop();
            Log.Debug("GetBeforeChargeProposalAiaAsync Response: {output} in {Elapsed:000} ms", output, stopwatch.ElapsedMilliseconds);
            return await output;
        }

        /// <summary>
        /// Upds the life proposal asynchronous.
        /// </summary>
        /// <param name="requestPolicy">The request policy.</param>
        /// <returns></returns>
        public async Task UpdLifeProposalAsync(Model.Partners.Upd.ProposalAIA.ZeupdProposal requestPolicy)
        {
            //Structure Create
            //convert to IN structure
            var requestObject = new Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWs() {
                Proposal = requestPolicy
            };
            

            //Logging Default
            stopwatch.Restart();
            Log.Debug($"UpdLifeProposalAsync requestObject Request: {JsonConvert.SerializeObject(requestObject)}");

            HttpRequestElement requestElement = new HttpRequestElement
            {
                ApiService = applicationSettings.BrokerServicesNameSpaces.Collections,
                ApiMethod = PostUpdProposalAiaAiaMethod,
                //QueryString = request.QueryString,
                Method = CommonEnums.HttpRequestVerb.POST,
                RequestObject = requestObject
            };

            //Logging Default
            Log.Debug($"UpdLifeProposalAsync requestElement Request: {JsonConvert.SerializeObject(requestElement)}");

            stopwatch.Restart();
            Log.Debug($"UpdLifeProposalAsync requestElement Request: {JsonConvert.SerializeObject(requestElement)}");

            Task<INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWsResponse> output = repositoryInvoker
                .GenericInvokerAsync<INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWsResponse, INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWsResponse>(requestElement);

            stopwatch.Stop();
            Log.Debug("UpdLifeProposalAsync Response: {output} in {Elapsed:000} ms", output, stopwatch.ElapsedMilliseconds);

            var result = await output;

            if (result.Errors != null && result.Errors?.ErrorCode == "000" && (!string.IsNullOrWhiteSpace(result?.Errors?.ErrorCode) || !string.IsNullOrEmpty(result?.Errors?.ErrorCode)))
            {
                throw new ProcessErrorException(
                                   StatusCodes.Status400BadRequest.ToString(),
                                   "Erros", new List<ProcessErrorException.InnerError> {
                                                       new ProcessErrorException.InnerError
                                                       {
                                                           ErrorCode =  result.Errors.ErrorCode,
                                                           ErrorMessage = result.Errors.ErrorCodeTxt
                                                       }
                                   }
                              );

            }

        }

        /// <summary>
        /// Posts the charged wasp asynchronous.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        public async Task<ChargedReceiptLineDetailResponseWaspOuptut> PostChargedWaspAsync(string requestObject)
        {
            return await collectionsRepository.Charged(requestObject);
        }

        /// <summary>
        /// Valids the input payment.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <exception cref="ProcessErrorException">
        /// Erros
        /// or
        /// Erros
        /// or
        /// Erros
        /// </exception>
        /// <exception cref="List{ProcessErrorException.InnerError}">
        /// </exception>
        /// <exception cref="ProcessErrorException.InnerError">
        /// </exception>
        public void ValidInputPayment(PaymentsInput parameters)
        {
            //Logging Default
            Log.Debug($"ValidInputPayment Request: {JsonConvert.SerializeObject(parameters)}");
            var stopwatch = new Stopwatch();
            stopwatch.Start();

            if (parameters == null)
            {
                throw new ProcessErrorException(
                      StatusCodes.Status406NotAcceptable.ToString(),
                      "Erros", new List<ProcessErrorException.InnerError>
                      {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status406NotAcceptable.ToString(),
                                       ErrorMessage = "Errors"
                                   }
                      });
            }

            if (parameters?.IdPaymentMethod == null)
            {
                throw new ProcessErrorException(
                      StatusCodes.Status406NotAcceptable.ToString(),
                      "Erros", new List<ProcessErrorException.InnerError>
                      {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status406NotAcceptable.ToString(),
                                       ErrorMessage = "Errors"
                                   }
                      });
            }

            switch (parameters.IdPaymentMethod)
            {
                case CommonEnums.EnumPayments.MbWay:
                case CommonEnums.EnumPayments.MbReference:
                    if (string.IsNullOrEmpty(parameters.ReceiptNumber))
                    {
                        throw new ProcessErrorException(
                                                StatusCodes.Status406NotAcceptable.ToString(),
                                                "Erros", new List<ProcessErrorException.InnerError>
                                                {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status406NotAcceptable.ToString(),
                                       ErrorMessage = "Errors"
                                   }
                                                });
                    }

                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Gets the entity payment.
        /// </summary>
        /// <param name="company">The company.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException"></exception>
        /// <exception cref="List{ProcessErrorException.InnerError}"></exception>
        /// <exception cref="ProcessErrorException.InnerError"></exception>
        public string GetEntityPayment(string company)
        {
            //Logging Default
            Log.Debug($"GetEntityPayment Request: {company}");
            var stopwatch = new Stopwatch();
            stopwatch.Start();

            //Oracle Params definition
            OracleDynamicParameters DyParam = getEntityPaymentRepository.ValidateParams(company);
            //Set ResultData Structure

            var oracleExec = $"{applicationSettings.OracleSettings.OraclePackageWebservice?.ToList()?.Where(x => x.FunctionName == "fun_get_entity_refpaym")?.FirstOrDefault()?.PackageName}" +
                $".{applicationSettings.OracleSettings.OraclePackageWebservice?.ToList()?.Where(x => x.FunctionName == "fun_get_entity_refpaym")?.FirstOrDefault()?.FunctionName}";

            //GetDoc SubmitFunction Oracle without document Request
            var validaAgentResult = getEntityPaymentRepository.SubmitStoreProcedure(oracleExec, company);


            if (validaAgentResult == "")
            {
                throw new ProcessErrorException(
                           StatusCodes.Status401Unauthorized.ToString(CultureInfo.CurrentCulture),
                           ConstErrorMessage, new List<ProcessErrorException.InnerError>
                           {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status401Unauthorized.ToString(CultureInfo.CurrentCulture),
                                       ErrorMessage = ConstErrorMessageAgente.ToString(CultureInfo.CurrentCulture)
                                   }
                           }
                           );
            }

            stopwatch.Stop();
            Log.Debug($"GetEntityPayment Response Time: {stopwatch.ElapsedMilliseconds}ms");

            return validaAgentResult;

        }

        /// <summary>
        /// Payments the methods output parameter.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <param name="subkey">The subkey.</param>
        /// <returns></returns>
        public dynamic PaymentMethodsOutputParam(string key, string subkey)
        {
            //AppOrigem - PaymentMethodOption:AppOrigem
            //Header - PaymentMethodOption:KeyHeaderPemissionOnAgent
            string concatKeySubKey = $"{key}:{subkey}";
            return configuration.GetSection(concatKeySubKey).Get<string>();
        }

        /// <summary>
        /// Shares the payment asynchronous.
        /// </summary>
        /// <param name="requestValue">The request value.</param>
        /// <param name="requestPaymentInfo">The request payment information.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">
        /// Redis
        /// or
        /// SendMail
        /// or
        /// SendSms
        /// or
        /// SendMail
        /// </exception>
        /// <exception cref="List{ProcessErrorException.InnerError}">
        /// </exception>
        /// <exception cref="ProcessErrorException.InnerError">
        /// </exception>
        public async Task<PaymentOutput> SharePaymentAsync(HttpRequest requestValue, SharePaymentInfo requestPaymentInfo)
        {
            try
            {

                PaymentOutput result = null;
                RedisOutput<PaymentOutput> contextPayment = null;

                //Add to Redis
                //ApplicationName - Token - Environment
                StringValues token;
                requestValue?.Headers.TryGetValue("Authorization", out token);

                var receiptContract = await GetReferecenDocumentOnRedisAsync(requestValue);

                if (token.Count > 0)
                {
                    //Create Context on Redis
                    //Validade if exists
                    //Stardard : ApplicationName | Contract | Token
                    var keyQuery = String.Empty;
                    if (!string.IsNullOrEmpty(receiptContract)){
                        keyQuery = $"{ApplicationSettings.ApplicationName}-{receiptContract}-{token}";
                    }
                    else {
                        keyQuery = $"{ApplicationSettings.ApplicationName}-{token}";
                    }

                    contextPayment = await redisManager.GetContextAsync<PaymentOutput>(keyQuery);

                    if (!contextPayment.IsValid)
                    {
                        throw new ProcessErrorException(
                                         StatusCodes.Status400BadRequest.ToString(CultureInfo.CurrentCulture),
                                          "Redis", new List<ProcessErrorException.InnerError>
                                          {
                                                               new ProcessErrorException.InnerError
                                                               {
                                                                   ErrorCode = StatusCodes.Status400BadRequest.ToString(CultureInfo.CurrentCulture),
                                                                   ErrorMessage = "No Context Data Information on Redis"
                                                               }
                                          }
                                          );
                    }
                }

                if (contextPayment == null)
                {
                    throw new ProcessErrorException(
                                     StatusCodes.Status400BadRequest.ToString(CultureInfo.CurrentCulture),
                                      "Redis", new List<ProcessErrorException.InnerError>
                                      {
                                                               new ProcessErrorException.InnerError
                                                               {
                                                                   ErrorCode = StatusCodes.Status400BadRequest.ToString(CultureInfo.CurrentCulture),
                                                                   ErrorMessage = "No Context Data Information on Redis"
                                                               }
                                      }
                                      );
                }


                //Choice send E-Mail or SMS
                switch (requestPaymentInfo.Type)
                {
                    case CommonEnums.EnumTypeSend.email:
                        //SendEmailAsync
                        var resultTask = await SendEmailAsync(requestPaymentInfo, contextPayment);

                        if (!resultTask.sendResult)
                        {
                            throw new ProcessErrorException(
                                      StatusCodes.Status400BadRequest.ToString(CultureInfo.CurrentCulture),
                                       "SendMail", new List<ProcessErrorException.InnerError>
                                       {
                                                               new ProcessErrorException.InnerError
                                                               {
                                                                   ErrorCode = StatusCodes.Status400BadRequest.ToString(CultureInfo.CurrentCulture),
                                                                   ErrorMessage = "Fault Send Email"
                                                               }
                                       }
                                       );
                        }

                        if (resultTask.sendResult)
                        {
                            result = new PaymentOutput()
                            {
                                Code = StatusCodes.Status200OK.ToString(CultureInfo.CurrentCulture),
                                Message = ConstMessageEmail
                            };
                        }
                        else
                        {
                            result = new PaymentOutput()
                            {
                                Code = StatusCodes.Status400BadRequest.ToString(CultureInfo.CurrentCulture),
                                Message = ConstMessageEmailUnsuccessfull
                            };
                        }

                        break;

                    case CommonEnums.EnumTypeSend.sms:
                        //SendSMS
                        var resultTaskSms = await SendSmsAsync(requestPaymentInfo, contextPayment);
                        if (resultTaskSms.SendSmsResult.ERROR_MSG != "OK")
                        {
                            throw new ProcessErrorException(
                                      StatusCodes.Status400BadRequest.ToString(CultureInfo.CurrentCulture),
                                       "SendSms", new List<ProcessErrorException.InnerError>
                                       {
                                                               new ProcessErrorException.InnerError
                                                               {
                                                                   ErrorCode = resultTaskSms.SendSmsResult.ERROR_CODE.ToString(),
                                                                   ErrorMessage = resultTaskSms.SendSmsResult.ERROR_MSG
                                                               }
                                       }
                                       );
                        }

                        result = new PaymentOutput()
                        {
                            Code = StatusCodes.Status200OK.ToString(CultureInfo.CurrentCulture),
                            Message = ConstMessageSms
                        };

                        break;

                    default:
                        break;
                }

                //Make Param
                return result;
            }
            catch (Exception ex)
            {
                Log.Debug($"SendEmailAsync Response result: {JsonConvert.SerializeObject(ex)}");
                throw;
            }
        }

        /// <summary>
        /// Sends the email asynchronous.
        /// </summary>
        /// <param name="requestPaymentInfo">The request payment information.</param>
        /// <param name="contextPayment">The context payment.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">SendMail</exception>
        /// <exception cref="List{ProcessErrorException.InnerError}"></exception>
        /// <exception cref="ProcessErrorException.InnerError"></exception>
        public async Task<sendResponse> SendEmailAsync(SharePaymentInfo requestPaymentInfo, RedisOutput<PaymentOutput> contextPayment)
        {
            try
            {
                Service.Email.eMail email = new Service.Email.eMail
                {
                    toAddresses = new[] { requestPaymentInfo.Recipient },
                    fromAddress = applicationSettings.EmailSettings.fromAddress,
                    subject = string.Format(applicationSettings.EmailSettings.Subject, contextPayment?.Value.Policy),
                    body = string.Format(applicationSettings.EmailSettings.Body, contextPayment?.Value.Entity, contextPayment?.Value.Reference, contextPayment?.Value.Amount, ValidateDate(contextPayment))
                };

                Service.Email.eMailMsg emailMsg = new Service.Email.eMailMsg
                {
                    Body = new Service.Email.eMailBody
                    {
                        Mail = email
                    }
                };

                emailMsg.Body.Mail.isHtml = "S";
                emailMsg.Header = new Service.Email.AxaMessageHeader
                {
                    OriginalTransactionID = applicationSettings.SmsSettings.OriginalTransactionID,
                    OriginalSystemName = applicationSettings.SmsSettings.OriginalSystemName,
                    EnvironmentName = applicationSettings.SmsSettings.EnvironmentName,
                    Author = applicationSettings.SmsSettings.Author,
                    Company = applicationSettings.SmsSettings.Company,
                    CurrentDate = new DateTime()
                };

                sendRequest requestMail = new sendRequest
                {
                    AxaMessage = emailMsg
                };

                Log.Debug($"SendEmailAsync Response result: {JsonConvert.SerializeObject(requestMail)}");

                var emailSendResult = await serviceEMail.sendAsync(requestMail);

                return emailSendResult;

            }
            catch (Exception ex)
            {
                Log.Debug($"SendEmailAsync Response result: {JsonConvert.SerializeObject(ex)}");
                throw new ProcessErrorException(
                             StatusCodes.Status400BadRequest.ToString(CultureInfo.CurrentCulture),
                              "SendMail", new List<ProcessErrorException.InnerError>
                              {
                                                           new ProcessErrorException.InnerError
                                                           {
                                                               ErrorCode = StatusCodes.Status400BadRequest.ToString(CultureInfo.CurrentCulture),
                                                               ErrorMessage = ex.Message.ToString(CultureInfo.CurrentCulture)
                                                           }
                              }
                              );
            }
        }

        /// <summary>
        /// Sends the SMS asynchronous.
        /// </summary>
        /// <param name="requestPaymentInfo">The request payment information.</param>
        /// <param name="contextPayment">The context payment.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">SendSms</exception>
        /// <exception cref="List{ProcessErrorException.InnerError}"></exception>
        /// <exception cref="ProcessErrorException.InnerError"></exception>
        public async Task<SendSmsResponse1> SendSmsAsync(SharePaymentInfo requestPaymentInfo, RedisOutput<PaymentOutput> contextPayment)
        {
            try
            {
                //Required
                Service.SMS.AxisValues axisValuesSms = new AxisValues()
                {
                    User = applicationSettings.SmsSettings.User,
                    UserName = applicationSettings.SmsSettings.UserName,
                    Solution = applicationSettings.SmsSettings.Solution
                };

                //Body
                Service.SMS.SmsRequestBody bodySms = new Service.SMS.SmsRequestBody()
                {
                    message = new SmsRequestBodyMessage()
                    {
                        body = string.Format(applicationSettings.SmsSettings.Body, contextPayment?.Value.Policy, contextPayment?.Value.Entity, contextPayment?.Value.Reference, contextPayment?.Value.Amount, ValidateDate(contextPayment)),
                        originator = applicationSettings.SmsSettings.Originator,
                        phone = requestPaymentInfo.Recipient,
                        scheduleddate = applicationSettings.SmsSettings.Scheduleddate
                    }
                };

                //Compose
                Service.SMS.AxaMessageHeader headerSms = new Service.SMS.AxaMessageHeader()
                {
                    OriginalTransactionID = applicationSettings.SmsSettings.OriginalTransactionID,
                    OriginalSystemName = applicationSettings.SmsSettings.OriginalSystemName,
                    EnvironmentName = applicationSettings.SmsSettings.EnvironmentName,
                    Author = applicationSettings.SmsSettings.Author,
                    Company = applicationSettings.SmsSettings.Company,
                    CurrentDate = new DateTime()
                };

                Service.SMS.SendSmsRequest requestSms = new SendSmsRequest()
                {
                    AxisValues = axisValuesSms,
                    AxaMessage = new SmsRequestMsg()
                    {
                        Body = bodySms,
                        Header = headerSms
                    }
                };


                Log.Debug($"SendSmsAsync Request: {JsonConvert.SerializeObject(requestSms)}");

                var smsSendResult = await serviceSms.SendSmsAsync(requestSms);

                return smsSendResult;

            }
            catch (Exception ex)
            {
                Log.Debug($"SendSmsAsync Response result: {JsonConvert.SerializeObject(ex)}");
                throw new ProcessErrorException(
                             StatusCodes.Status400BadRequest.ToString(CultureInfo.CurrentCulture),
                              "SendSms", new List<ProcessErrorException.InnerError>
                              {
                                                           new ProcessErrorException.InnerError
                                                           {
                                                               ErrorCode = StatusCodes.Status400BadRequest.ToString(CultureInfo.CurrentCulture),
                                                               ErrorMessage = ex.Message.ToString(CultureInfo.CurrentCulture)
                                                           }
                              }
                              );
            }
        }

        /// <summary>
        /// Validas the status invoices.
        /// </summary>
        /// <param name="input">The input.</param>
        /// <returns></returns>
        private string validaReceiptTypeInvoices(string input)
        {
            //receiptType-> "Signal": "P"-> 01;
            //              "Signal": "E"-> 02;
            string returnTemp = string.Empty;
            switch (input)
            {
                case "P":
                    returnTemp = "01";
                    break;
                case "E":
                    returnTemp = "02";
                    break;
                default:
                    break;
            }
            return returnTemp;
        }

        /// <summary>
        /// Validas the receipt type invoices.
        /// </summary>
        /// <param name="inputStatus">The input status.</param>
        /// <param name="inputSignal">The input signal.</param>
        /// <returns></returns>
        private string validaStatusInvoices(string inputStatus, string inputSignal)
        {
            //status-> "Status": "P"->AB
            //         "Status": "A"->AN
            //         "Status": "C" e "Signal": "E"->PG
            //         "Status":"C" e "Signal":"P"->CO

            string returnTemp = string.Empty;
            switch (inputStatus)
            {
                case "P":
                    returnTemp = "AB";
                    break;
                case "A":
                    returnTemp = "AN";
                    break;
                case "C":
                    if (inputSignal.Equals("E", StringComparison.InvariantCultureIgnoreCase))
                    {
                        returnTemp = "PG";
                    }
                    else if (inputSignal.Equals("P", StringComparison.InvariantCultureIgnoreCase))
                    {
                        returnTemp = "PG";
                    }
                    break;
                default:
                    break;
            }

            return returnTemp;
        }

        /// <summary>
        /// Invoices the specified invoice input.
        /// </summary>
        /// <param name="invoiceInput">The invoice input.</param>
        /// <returns></returns>
        public async Task<object> ReceiptsChangeNotifcation(string receiptNumber, ReceiptsChangeNotifcationInput invoiceInput)
        {
            //Route
            var route = string.Format($"{applicationSettings.BrokerDuckCreekSettings.BsWebService}/{applicationSettings.BrokerDuckCreekSettings.BsReceiptNotificationWebMethod}", $"{receiptNumber}");

            //Set Object
            var requestElement = new HttpRequestElement
            {
                ResponseIsStream = true,
                RequestObject = invoiceInput, //body
                RouteValue = $"/{route}",
                Method = CommonEnums.HttpRequestVerb.POST
            };

            //Required
            requestElement.Headers.Add(new KeyValuePair<string, string>("AgeasUsername", applicationSettings.BrokerDuckCreekSettings.HeaderUserName));

            Log.Debug($"ReceiptsChangeNotifcation Request : {JsonConvert.SerializeObject(requestElement)}");

            Task<object> output = repositoryInvoker.GenericInvokerAsync<object, ReceiptsChangeNotifcationInput>(requestElement, false, true);

            return await output;
        }

        /// <summary>
        /// Gets the string from memory stream.
        /// </summary>
        /// <param name="ms">The ms.</param>
        /// <returns></returns>
        private static string GetStringFromMemoryStream(MemoryStream ms)
        {
            ms.Position = 0;
            using (StreamReader sr = new StreamReader(ms))
            {
                return sr.ReadToEnd();
            }
        }

        /// <summary>
        /// Validates the date.
        /// </summary>
        /// <param name="contextPayment">The context payment.</param>
        /// <returns></returns>
        private static string ValidateDate(RedisOutput<PaymentOutput> contextPayment)
        {
            var result = DateTime.ParseExact(contextPayment.Value.DueDate, "yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'", CultureInfo.InvariantCulture).ToString("dd-MM-yyyy", CultureInfo.CurrentCulture);
            return result;
        }

        /// <summary>
        /// Updates the payment method on redis asynchronous.
        /// </summary>
        /// <param name="requestValue">The request value.</param>
        /// <param name="resultMethods">The result methods.</param>
        /// <param name="receiptRequestAgentResult">The receipt request agent result.</param>
        public async Task UpdatePaymentMethodOnRedisAsync(HttpRequest requestValue, PaymentOutput resultMethods, ReceiptDetailWaspOutput receiptRequestAgentResult)
       {
            StringValues token;
            requestValue?.Headers.TryGetValue("Authorization", out token);
            var receiptDetailResultContract = receiptRequestAgentResult?.ReceiptsNumbers?.FirstOrDefault().Contract;

            //Add to Redis Session
            //Session Payments stores the payment that was made
            StringValues sessionPaymentOptions;
            requestValue?.Headers.TryGetValue("SessionPaymentOptions", out sessionPaymentOptions);

            var keyQuery = String.Empty;

            if (sessionPaymentOptions.Count > 0)
            {
                keyQuery = $"{sessionPaymentOptions}-{ApplicationSettings.ApplicationName}-{receiptDetailResultContract}-{token}";
            }
            else
            {
                keyQuery = $"{ApplicationSettings.ApplicationName}-{receiptDetailResultContract}-{token}";
            }

            RedisOutput<PaymentOutput> contextPayment = await redisManager.GetContextAsync<PaymentOutput>(keyQuery);

            if (!contextPayment.IsValid)
            {
                RedisOutput<PaymentOutput> redisAgentOutput = await redisManager.CreateContextAsync<PaymentOutput>(keyQuery, resultMethods, null);
            }
            else
            {
                if (contextPayment.IsValid)
                {

                    contextPayment.Value.Phone = contextPayment.Value.Phone;
                    contextPayment.Value.Email = contextPayment.Value.Email;
                    contextPayment.Value.BackEnd = contextPayment.Value.BackEnd;
                    contextPayment.Value.Policy = contextPayment.Value.Policy;

                    contextPayment.Value.IdPaymentMethod = resultMethods?.IdPaymentMethod;
                    contextPayment.Value.StatusCodes = resultMethods?.StatusCodes;
                    contextPayment.Value.Status = resultMethods?.Status;
                    contextPayment.Value.Message = resultMethods?.Message; 
                    contextPayment.Value.MerchantTransactionId = resultMethods?.MerchantTransactionId;
                    contextPayment.Value.Amount = resultMethods?.Amount;
                    contextPayment.Value.Entity = resultMethods?.Entity;
                    contextPayment.Value.Reference = resultMethods?.Reference;
                    contextPayment.Value.DueDate = resultMethods?.DueDate;
                    contextPayment.Value.IdPaymentMethod = resultMethods?.IdPaymentMethod;
                    contextPayment.Value.Message = resultMethods?.Message;
                    contextPayment.Value.Code = resultMethods?.Code;

                    Stopwatch stopWatch = new Stopwatch();
                    stopWatch.Start();
                    Log.Debug("Timeline - LogOut() - Start redisManager.RemoveContext");
                    var result = await redisManager.RemoveContextAsync<RedisOutput<bool>>(keyQuery);
                    stopWatch.Stop();
                    Log.Debug("Timeline - LogOut() - End redisManager.RemoveContext: Time {ElapsedMilliseconds}ms", stopWatch.ElapsedMilliseconds);

                    if (!result)
                    {
                        Log.Debug("LogOutWasp returned error. Object not removed or non existent!");
                    }

                    RedisOutput<PaymentOutput> contextPaymentUpdated = await redisManager.UpdateContextAsync<PaymentOutput>(keyQuery, contextPayment.Value, null);
                }
            }
        }

        /// <summary>
        /// Updates the payment method on redis asynchronous.
        /// </summary>
        /// <param name="requestValue">The request value.</param>
        /// <param name="resultMethods">The result methods.</param>
        /// <param name="proposalResult">The proposal result.</param>
        public async Task UpdatePaymentMethodOnRedisAsync(HttpRequest requestValue, PaymentOutput resultMethods, Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse proposalResult)
        {
            StringValues token;
            requestValue?.Headers.TryGetValue("Authorization", out token);
            var receiptDetailResultContract = proposalResult?.Proposal?.ProposalNumber;

            //Add to Redis Session
            //Session Payments stores the payment that was made
            StringValues sessionPaymentOptions;
            requestValue?.Headers.TryGetValue("SessionPaymentOptions", out sessionPaymentOptions);

            var keyQuery = String.Empty;

            if (sessionPaymentOptions.Count > 0)
            {
                keyQuery = $"{sessionPaymentOptions}-{ApplicationSettings.ApplicationName}-{receiptDetailResultContract}-{token}";
            }
            else
            {
                keyQuery = $"{ApplicationSettings.ApplicationName}-{receiptDetailResultContract}-{token}";
            }

            RedisOutput<PaymentOutput> contextPayment = await redisManager.GetContextAsync<PaymentOutput>(keyQuery);

            if (!contextPayment.IsValid)
            {
                RedisOutput<PaymentOutput> redisAgentOutput = await redisManager.CreateContextAsync<PaymentOutput>(keyQuery, resultMethods, null);
            }
            else
            {
                if (contextPayment.IsValid)
                {
                    resultMethods.Channel = contextPayment.Value.Channel;

                    contextPayment.Value.Phone = contextPayment.Value.Phone;
                    contextPayment.Value.Email = contextPayment.Value.Email;
                    contextPayment.Value.BackEnd = contextPayment.Value.BackEnd;
                    contextPayment.Value.Policy = contextPayment.Value.Policy;
                    contextPayment.Value.Channel = contextPayment.Value.Channel;

                    contextPayment.Value.IdPaymentMethod = resultMethods?.IdPaymentMethod;
                    contextPayment.Value.StatusCodes = resultMethods?.StatusCodes;
                    contextPayment.Value.Status = resultMethods?.Status;
                    contextPayment.Value.Message = resultMethods?.Message;
                    contextPayment.Value.MerchantTransactionId = resultMethods?.MerchantTransactionId;
                    contextPayment.Value.Amount = resultMethods?.Amount;
                    contextPayment.Value.Entity = resultMethods?.Entity;
                    contextPayment.Value.Reference = resultMethods?.Reference;
                    contextPayment.Value.DueDate = resultMethods?.DueDate;
                    contextPayment.Value.IdPaymentMethod = resultMethods?.IdPaymentMethod;
                    contextPayment.Value.Message = resultMethods?.Message;
                    contextPayment.Value.Code = resultMethods?.Code;

                    Stopwatch stopWatch = new Stopwatch();
                    stopWatch.Start();
                    Log.Debug("Timeline - LogOut() - Start redisManager.RemoveContext");
                    var result = await redisManager.RemoveContextAsync<RedisOutput<bool>>(keyQuery);
                    stopWatch.Stop();
                    Log.Debug("Timeline - LogOut() - End redisManager.RemoveContext: Time {ElapsedMilliseconds}ms", stopWatch.ElapsedMilliseconds);

                    if (!result)
                    {
                        Log.Debug("LogOutWasp returned error. Object not removed or non existent!");
                    }

                    RedisOutput<PaymentOutput> contextPaymentUpdated = await redisManager.UpdateContextAsync<PaymentOutput>(keyQuery, contextPayment.Value, null);
                }
            }
        }

        /// <summary>
        /// Gets the receipt on redis asynchronous.
        /// </summary>
        /// <param name="requestValue">The request value.</param>
        /// <returns></returns>
        public async Task<string> GetReferecenDocumentOnRedisAsync(HttpRequest requestValue) {

            //Get from Redis
            StringValues token;
            requestValue?.Headers.TryGetValue("Authorization", out token);

            StringValues ReferenceDocument;
            requestValue?.Headers.TryGetValue("ReferenceDocument", out ReferenceDocument);


            var keyQuery = String.Empty;
            keyQuery = $"{ApplicationSettings.ApplicationName}-{ReferenceDocument}-{token}";
            RedisOutput<PaymentOutput> contextPayment = await redisManager.GetContextAsync<PaymentOutput>(keyQuery);

            var channel = String.Empty;
            var proposal = String.Empty;
            if (contextPayment.IsValid)
            {
                channel = contextPayment.Value.Channel;
                proposal = contextPayment.Value.Proposal;
            } else
            {
                Log.Error($"{"No Context Data Information on Redis"}");
                throw new ProcessErrorException(
                    StatusCodes.Status404NotFound.ToString(),
                    "Erros", new List<ProcessErrorException.InnerError>{
                                        new ProcessErrorException.InnerError{
                                            ErrorCode =  "Redis",
                                            ErrorMessage = "No Context Data Information on Redis"
                                        }
}
                    );
            }

            switch (channel)
            {
                case null:
                case nameof(Constants.CommonEnums.EnumHeader.DynamicForms):
                    //Get Contract based on IdReceipt
                    //get receipt informations
                    var requestObject = new ReceiptDetailWaspInput
                    {
                        ReferenceDocumentNumber = ReferenceDocument
                    };

                    //WebReceiptList
                    var receiptResult = await PostReceiptsDetailWaspAsync(requestObject);
                    var receiptContract = receiptResult.ReceiptsNumbers.FirstOrDefault().Contract;
                    return receiptContract;

                case nameof(Constants.CommonEnums.EnumHeader.UnitLinked):
                    var  resultDataProposalSap = await CallProposalAsync(proposal);
                    return resultDataProposalSap.Proposal.ProposalNumber;

                default:

                    Log.Error($"{"Unauthorized Channel"}");
                    throw new ProcessErrorException(
                        StatusCodes.Status404NotFound.ToString(),
                        "Erros", new List<ProcessErrorException.InnerError>{
                                        new ProcessErrorException.InnerError{
                                            ErrorCode =  "Channel",
                                            ErrorMessage = "Unauthorized Channel"
                                        }
                        }
                        );
            }
        }

        /// <summary>
        /// Calls the proposal asynchronous.
        /// </summary>
        /// <param name="idProposal">The identifier proposal.</param>
        /// <returns></returns>
        public async Task<Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse> CallProposalAsync(string idProposal)
        {

            //Call ProposalSAP
            var inputProposalSap = new PaymentMethodsInput
            {
                Id = idProposal
            };

            stopwatch.Restart();
            Log.Debug($"GetBeforeChargeProposalAiaAsync inputProposalSap Request: {JsonConvert.SerializeObject(inputProposalSap)}");
            ///v1/ProposalAIA/GetBeforeChargeProposalAia
            var resultDataPropostaSap = await GetBeforeChargeProposalAiaAsync(inputProposalSap);
            stopwatch.Stop();
            Log.Debug("GetBeforeChargeProposalAiaAsync resultDataPropostaSap Response: {resultDataPropostaSap} in {Elapsed:000} ms", JsonConvert.SerializeObject(resultDataPropostaSap), stopwatch.ElapsedMilliseconds);

            return resultDataPropostaSap;
        }

        /// <summary>
        /// Calls the payment mb way asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <param name="requestValue">The request value.</param>
        /// <param name="resultDataProposalSap">The result data proposal sap.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">Erros</exception>
        /// <exception cref="List{ProcessErrorException.InnerError}"></exception>
        /// <exception cref="ProcessErrorException.InnerError"></exception>
        public async Task<PaymentOutput> CallPaymentMbWayAsync(PaymentsInput parameters, HttpRequest requestValue, Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse resultDataProposalSap)
        {
            INS.PT.WebAPI.Model.Partners.Upd.ProposalAIA.ZageasLifeUpdProposalWsResponse UpdProposalSap  = null;
            var appOrigem = applicationSettings.PaymentMethodOption.AppOrigem;
            Log.Debug("Payment Selected: {MbWay}", nameof(CommonEnums.EnumPayments.MbWay));

            const string ConstPaymentBrandMbWay = "1";

            //Call Api Financial - MBWayPayment
            MBWayPaymentInputDTO mbway = null;

            var TimestampTmp = DateTime.Now.ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'");
            var defaultamountMbWay = resultDataProposalSap?.Proposal?.Value == "" ? "0" : resultDataProposalSap?.Proposal?.Value == null ? "0" : resultDataProposalSap?.Proposal?.Value;
            var amountMbWay = Decimal.Parse(defaultamountMbWay, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture);

            mbway = new MBWayPaymentInputDTO()
            {
                AppOrigemId = appOrigem,
                InternalCompany = resultDataProposalSap.Proposal.Company,
                Nif = ValidateField.ValidateNif(resultDataProposalSap.Proposal.Nif),
                PaymentBrand = ConstPaymentBrandMbWay,
                PhoneNumber = parameters.AditionalInformation,
                PrintType = ConstPrintType,
                Receipts = new List<Models.PaymentMPOS.PaymentReceipt>() {
                                    new Models.PaymentMPOS.PaymentReceipt(){
                                        Amount = Decimal.Parse(resultDataProposalSap.Proposal.Value, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture),
                                        IdDocument = ConstIdDocument,
                                        IdReceipt = "0",
                                        Policy = resultDataProposalSap.Proposal.ProposalNumber,
                                        PrefixDoc = ConstPrefixProposalAiaDoc,
                                        ThirdParty = false
                                    }
                                },
                ThirdParty = ConstThirdParty,
                Timestamp = TimestampTmp,
                TotalAmount = amountMbWay,
                UserId = resultDataProposalSap.Proposal.IdEntity
            };

            Log.Debug("CallPaymentMbWayAsync mbway MPOS Request: {mbway}", JsonConvert.SerializeObject(mbway));
       
            MBWayPaymentOutputDTO resultMbWay = await PostMBWayPaymentAsync(mbway);

            if (resultMbWay.ErrorCode == "200")
            {
                //Criar enum para o status

                //Se ok, Atualiza Prosta no SAP
                Model.Partners.Upd.ProposalAIA.ZeupdProposal updProposal = new Model.Partners.Upd.ProposalAIA.ZeupdProposal()
                {
                    DataLimite = string.Empty,
                    PhoneId = parameters.AditionalInformation,
                    ProposalNumber = resultDataProposalSap.Proposal.ProposalNumber,
                    SibsEntity = string.Empty,
                    SibsReference = string.Empty,
                    Status = CommonEnums.EnumStatusPaymentsSap.PAGO_POR_MBWAY.GetStringValue(),
                    TerminalId = string.Empty,
                    Value = defaultamountMbWay,
                    Nep = resultMbWay.MerchantTransactionId,
                };

                Log.Debug("CallPaymentMbWayAsync SAP Request: {updProposal}", JsonConvert.SerializeObject(updProposal));

                await UpdLifeProposalAsync(updProposal);

            } 

            var StatusCodesTmp = resultMbWay.ErrorCode == "200" ? StatusCodes.Status200OK.ToString() : resultMbWay.ErrorCode;

            var result = new PaymentOutput()
            {
                IdPaymentMethod = nameof(CommonEnums.EnumPayments.MbWay),
                Code = resultMbWay.ErrorCode,
                Status = resultMbWay.Status,
                Message = resultMbWay.ErrorMessage,
                MerchantTransactionId = resultMbWay.MerchantTransactionId,
                StatusCodes = StatusCodesTmp
            };

             Log.Debug("CallPaymentMbWayAsync SAP Request: {result}", JsonConvert.SerializeObject(result));

            //Update Redis
            await UpdatePaymentMethodOnRedisAsync(requestValue, result, resultDataProposalSap);

            return result;
        }

        /// <summary>
        /// Calls the payment mb reference asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <param name="requestValue">The request value.</param>
        /// <param name="resultDataProposalSap">The result data proposal sap.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">Erros</exception>
        /// <exception cref="List{ProcessErrorException.InnerError}"></exception>
        /// <exception cref="ProcessErrorException.InnerError"></exception>
        public async Task<PaymentOutput> CallPaymentMbReferenceAsync(PaymentsInput parameters, HttpRequest requestValue, Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse resultDataProposalSap) {

            var appOrigem = applicationSettings.PaymentMethodOption.AppOrigem;

            stopwatch.Restart();
            Log.Debug("Payment Selected: {MbReference}", nameof(CommonEnums.EnumPayments.MbReference));

            const string ConstPaymentBrandMbReference = "2";

            //Call Api Financial - refMbPayment
            RefMBPaymentInputDTO refmbreference = null;

            var defaultamountMbRef = resultDataProposalSap?.Proposal?.Value == "" ? "0" : resultDataProposalSap?.Proposal?.Value == null ? "0" : resultDataProposalSap?.Proposal?.Value;
            var amountMbRef = Decimal.Parse(defaultamountMbRef, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture);
            var refIntlDtTm = ValidateDateTime.ToCorrectDateTime(resultDataProposalSap.Proposal.CreationDate, resultDataProposalSap.Proposal.CreationTime).ToString();
            var refLmtDtTm = ValidateDateTime.ToCorrectDateTime(resultDataProposalSap.Proposal.DataLimite).ToString();

            //Receipt of tests
            var entityValue = GetEntityPayment(resultDataProposalSap.Proposal.Company);
            refmbreference = new RefMBPaymentInputDTO()
            {
                PtMntEntty = entityValue,
                RefIntlDtTm = refIntlDtTm,
                RefLmtDtTm = refLmtDtTm,
                Timestamp = DateTime.Now.ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'"),
                AppOrigemId = appOrigem,
                InternalCompany = resultDataProposalSap.Proposal.Company,
                Nif = resultDataProposalSap.Proposal.Nif,
                PaymentBrand = ConstPaymentBrandMbReference, //Valor Default
                PrintType = ConstPrintType,
                Receipts = new List<Models.PaymentMPOS.PaymentReceipt>()
                            {
                                new Models.PaymentMPOS.PaymentReceipt()
                                {
                                    Amount =  amountMbRef,
                                    IdDocument = ConstIdDocument,
                                    IdReceipt = "0",
                                    Policy = resultDataProposalSap.Proposal.ProposalNumber,
                                    PrefixDoc = ConstPrefixProposalAiaDoc,
                                    ThirdParty = false
                                }
                            },
                ThirdParty = ConstThirdParty,
                TotalAmount = amountMbRef,
                UserId = resultDataProposalSap.Proposal.IdEntity
            };

            stopwatch.Restart();
            Log.Debug("PostRefMBWayPaymentAsync MPOS Request: {receiptMbReferenceRequestObject}", JsonConvert.SerializeObject(refmbreference));
            var resultrefMbWay = await PostRefMBWayPaymentAsync(refmbreference);

            if (resultrefMbWay.ErrorCode == "200")
            {
                //Se ok, Atualiza Prosta no SAP
                Model.Partners.Upd.ProposalAIA.ZeupdProposal updProposal = new Model.Partners.Upd.ProposalAIA.ZeupdProposal()
                {
                    DataLimite = resultDataProposalSap.Proposal.DataLimite,
                    PhoneId = string.Empty,
                    ProposalNumber = resultDataProposalSap.Proposal.ProposalNumber,
                    SibsEntity = resultrefMbWay.Entity,
                    SibsReference = resultrefMbWay.Reference,
                    Status = CommonEnums.EnumStatusPaymentsSap.PAGO_POR_MBREFERENCE.GetStringValue(),
                    TerminalId = string.Empty,
                    Value = defaultamountMbRef,
                    Nep = string.Empty
                };
                await UpdLifeProposalAsync(updProposal);
            }

            //Customization Message
            var tempMessage = applicationSettings.PaymentMethodOption.PaymentMethods.FirstOrDefault(opt => opt.IdPaymentMethod == CommonEnums.EnumPayments.MbReference).Message;
            var StatusCodestmp = resultrefMbWay.ErrorCode == "200" ? StatusCodes.Status200OK.ToString() : String.Empty;
            var MessageTmp = string.IsNullOrEmpty(tempMessage) ? resultrefMbWay.ErrorMessage : tempMessage;

            var result = new PaymentOutput()
            {
                IdPaymentMethod = nameof(CommonEnums.EnumPayments.MbReference),
                StatusCodes = StatusCodestmp,
                Code = resultrefMbWay.ErrorCode,
                Status = resultrefMbWay.Status,
                Message = MessageTmp,
                MerchantTransactionId = resultrefMbWay.MerchantTransactionId,
                Amount = resultrefMbWay.Amount,
                Entity = resultrefMbWay.Entity,
                Reference = resultrefMbWay.Reference,
                DueDate = refLmtDtTm
            };
            Log.Debug("CallPaymentMbWayAsync SAP Request: {result}", JsonConvert.SerializeObject(result));

            //Update Redis
            await UpdatePaymentMethodOnRedisAsync(requestValue, result, resultDataProposalSap);
            return result;
        }
    }
}

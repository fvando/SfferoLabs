﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.ServiceModel;
using System.Threading.Tasks;
using AutoMapper;
using Canonical.ServiceReference;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.CommonLibrary.Redis.Interfaces;
using INS.PT.CommonLibrary.Redis.Models;
using INS.PT.WebAPI.Constants;
using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Interface.v2;
using INS.PT.WebAPI.Life20;
using INS.PT.WebAPI.Mappings;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.Partners.BeforeCharge.ProposalAIA;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.AgentsPortal.CommercialStructure;
using INS.PT.WebAPI.Models.Collections;
using INS.PT.WebAPI.Models.DTO.Domain;
using INS.PT.WebAPI.Models.DuckCreek;
using INS.PT.WebAPI.Models.Input.v2;
using INS.PT.WebAPI.Models.Output;
using INS.PT.WebAPI.Models.Output.v2;
using INS.PT.WebAPI.v2;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using Serilog;

namespace INS.PT.WebAPI.Repository
{
    /// <summary>
    /// Reference data repository.
    /// </summary>
    public class PaymentMethodsRepository : BaseRepository, IPaymentMethods
    {

        #region Route Constants
        private const string GetProcessDetailMethod = "v1/Life2Front/GetProcessDetail";
        private const string GetBeforeChargeProposalAiaMethod = "v1/ProposalAIA/GetBeforeChargeProposalAia";


        #endregion

        #region Properties

        private readonly IMapper mapper;
        private readonly IRedisManager redisManager;
        private readonly IConfiguration configuration;
        private readonly IPoliciesService canonicalService;
        private readonly IHttpClientRepository httpClientRepository;
        private readonly ICollectionsRepository collectionsRepository;
        private readonly ICommercialStructureRepository commercialStructure;
        private readonly Stopwatch stopwatch;
        private readonly IStatesRepository statesRepository;

        #endregion

        #region Constructors

        public PaymentMethodsRepository(IConfiguration _configuration, IHttpClientRepository _httpClientRepository, IRepositoryInvoker _repositoryInvoker, ApplicationSettings _applicationSettings, IMapper _mapper, HttpRequest _request, ICollectionsRepository _collectionsRepository, IRedisManager _redisManager, IStatesRepository _statesRepository, ICommercialStructureRepository _commercialStructure)
       : base(_configuration, _applicationSettings, _repositoryInvoker, _request)
        {
            mapper = _mapper;
            redisManager = _redisManager;
            httpClientRepository = _httpClientRepository;
            configuration = _configuration;
            canonicalService = CreateCanonicalClient();
            collectionsRepository = _collectionsRepository ?? throw new ArgumentNullException(nameof(_collectionsRepository));
            commercialStructure = _commercialStructure ?? throw new ArgumentNullException(nameof(_commercialStructure));
            stopwatch = new Stopwatch();
            statesRepository = _statesRepository;
        }



        #endregion

        #region Actions

        /// <summary>
        /// Posts the receipts detail wasp asynchronous.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        public async Task<ValidateReceiptLineDetailResponseWaspOutput> ValidateChargeReceiptsAsync(ValidateReceiptsWaspInput requestObject)
        {
            return await collectionsRepository.ValidateChargeReceipts(requestObject);
        }

        /// <summary>
        /// Posts the receipts detail wasp asynchronous.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        public async Task<ReceiptDetailWaspOutput> PostReceiptsDetailWaspAsync(ReceiptDetailWaspInput requestObject)
        {
            return await collectionsRepository.ReceiptsDetail(requestObject);
        }

        /// <summary>
        /// Method to read list of payment methods.
        /// </summary>
        /// <param name="parameters">Parameters to retrive the data.</param>
        /// <returns>Object with results.</returns>
        ///<inheritdoc /> 
        public async Task<PaymentMethodsOutput> GetPaymentsAsync(HttpRequest requestValue, PaymentMethodsInput parameters)
        {

            #region Geral Header

            StringValues validateChannel;
            requestValue?.Headers.TryGetValue("Channel", out validateChannel);
            var keyHeader = validateChannel.FirstOrDefault();

            #endregion

            stopwatch.Restart();
            Log.Debug("CommonPortifolioAsync Request: {requestValue}", JsonConvert.SerializeObject(parameters));

            //Select Payment
            switch (keyHeader)
            {
                case null:
                case nameof(Constants.CommonEnums.EnumHeader.DynamicForms):

                    stopwatch.Stop();
                    Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds} ms");
                    return await GetPaymentsByCommonPortifolioAsync(parameters, validateChannel, requestValue);

                case nameof(Constants.CommonEnums.EnumHeader.UnitLinked):

                    stopwatch.Stop();
                    Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds} ms");

                    return await GetPaymentsByUnitLinkedAsync(parameters, validateChannel, requestValue);

                case nameof(Constants.CommonEnums.EnumHeader.Life20):

                    stopwatch.Stop();
                    Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds} ms");
                    return await GetPaymentsByLife20(parameters, validateChannel, requestValue);

                default:

                    Log.Error($"{"Unauthorized Channel"}");
                    throw new ProcessErrorException(
                        StatusCodes.Status404NotFound.ToString(),
                        "Erros", new List<ProcessErrorException.InnerError>{
                                        new ProcessErrorException.InnerError{
                                            ErrorCode =  "Chanell",
                                            ErrorMessage = "Unauthorized Channel"
                                        }
                        }
                        );
            }
            stopwatch.Stop();
            Log.Debug("CommonPortifolioAsync Response: in {Elapsed:000} ms", stopwatch.ElapsedMilliseconds);

        }

        /// <summary>
        /// Commons the portifolio asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <param name="validateChannel">The validate channel.</param>
        /// <param name="requestValue">The request value.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">
        /// Erros
        /// or
        /// </exception>
        /// <exception cref="List{ProcessErrorException.InnerError}">
        /// </exception>
        /// <exception cref="ProcessErrorException.InnerError">
        /// </exception>
        public async Task<PaymentMethodsOutput> GetPaymentsByCommonPortifolioAsync(PaymentMethodsInput parameters, StringValues validateChannel, HttpRequest requestValue)
        {
            //Double check if receipt include on charged
            var doublecheckreceiptchaged = false;

            #region Receipts

            var keyHeaderSetting = applicationSettings.PaymentMethodOption.KeyHeaderPemissionOnAgent;
            var keyHeader = validateChannel.FirstOrDefault();

            //Call WebReceiptlist
            Log.Debug($"Request: {parameters.Id}");

            //get receipt informations
            var requestObject = new ReceiptDetailWaspInput
            {
                ReferenceDocumentNumber = parameters.Id
            };

            //Logging Default
            stopwatch.Restart();
            Log.Debug($"PostReceiptsDetailWaspAsync SAP Request: {JsonConvert.SerializeObject(requestObject)}");

            //WebReceiptList
            var receiptResult = await PostReceiptsDetailWaspAsync(requestObject);

            stopwatch.Stop();
            Log.Debug("PostReceiptsDetailWaspAsync Response: {ServiceResponseUpdated} in {Elapsed:000} ms", JsonConvert.SerializeObject(receiptResult), stopwatch.ElapsedMilliseconds);

            //Doublecheck, if agent can do charged
            var requestValidateReceiptsObject = new ValidateReceiptsWaspInput
            {
                BrokerContract = receiptResult?.ReceiptsNumbers?.FirstOrDefault()?.InsuranceAgent,
                TesteRun = "B",
                PcReceipts = new List<ReceiptElement> {
                    new ReceiptElement {}
                }
            };

            //Logging Default
            stopwatch.Restart();
            Log.Debug($"ValidateChargeReceiptsAsync SAP Request: {JsonConvert.SerializeObject(requestValidateReceiptsObject)}");

            //Check if Agent can do Charged
            var validateAgentCharged = await ValidateChargeReceiptsAsync(requestValidateReceiptsObject);

            if (validateAgentCharged == null)
            {
                throw new ProcessErrorException(
                                            StatusCodes.Status404NotFound.ToString(),
                                            "Erros", new List<ProcessErrorException.InnerError>{
                                            new ProcessErrorException.InnerError{
                                                ErrorCode =  "001",
                                                ErrorMessage = "Não foram encontrados dados de validação de agente para prestação de contas"
                                            }
                                            });
            }

            var resultValidationAgent = validateAgentCharged.PcReceipts.FirstOrDefault().Status.FirstOrDefault().Situation;

            stopwatch.Stop();
            Log.Debug("ValidateChargeReceiptsAsync SAP Response: {resultValidationAgent} in {Elapsed:000} ms", JsonConvert.SerializeObject(resultValidationAgent), stopwatch.ElapsedMilliseconds);

            //ValidaFormasdePagamento
            if (receiptResult?.Errors.Count > 0)
            {
                Log.Error($"{receiptResult?.Errors}");
                throw new ProcessErrorException(
                    StatusCodes.Status400BadRequest.ToString(),
                    "Erros", new List<ProcessErrorException.InnerError>{
                                        new ProcessErrorException.InnerError{
                                            ErrorCode =  receiptResult?.Errors?.FirstOrDefault()?.ErrorCode,
                                            ErrorMessage = receiptResult?.Errors?.FirstOrDefault()?.ErrorCodeTxt
                                        }
                    }
                    );
            }

            #endregion

            #region CommonPortfolio

            //Call CommonPortfolio
            var inputCommonPortifolio = new PaymentMethodsInput
            {
                Id = receiptResult?.ReceiptsNumbers?.FirstOrDefault()?.Contract
            };

            //Logging Default
            stopwatch.Restart();
            Log.Debug($"ReadCanonicalInformationAsync CommonPortifolio Request: {JsonConvert.SerializeObject(inputCommonPortifolio)}");

            //Read data of CommonPortfolio
            var resultDataPortfolio = await ReadCanonicalInformationAsync(inputCommonPortifolio);

            stopwatch.Stop();
            Log.Debug("ReadCanonicalInformationAsync CommonPortifolio Response: {resultValidationAgent} in {Elapsed:000} ms",
                JsonConvert.SerializeObject(resultDataPortfolio), stopwatch.ElapsedMilliseconds);

            //Valida RestultPortifolio
            if (resultDataPortfolio == null)
            {
                throw new ProcessErrorException(
                                            StatusCodes.Status404NotFound.ToString(),
                                            "Erros", new List<ProcessErrorException.InnerError>{
                                            new ProcessErrorException.InnerError{
                                                ErrorCode =  "001",
                                                ErrorMessage = "Não foram encontrados dados canonicos da apólice"
                                            }
                                            });
            }

            #endregion

            #region PaymentList

            List<PaymentMethod> paymentMethods = applicationSettings.PaymentMethodOption.PaymentMethods.ToList();
            List<PaymentMethod> resultList = new List<PaymentMethod>();
            PaymentMethodsOutput resultPaymentMethods = null;

            #endregion

            if (receiptResult?.ReceiptsNumbers.Count > 0)
            {
                #region ChargedValidadate
                //Doublecheck if the receipt is on Charged
                doublecheckreceiptchaged = string.IsNullOrWhiteSpace(receiptResult.ReceiptsNumbers?.FirstOrDefault()?.BrokerReportIdentification);

                //Doublecheck if the receipt is on status SAP to SEPA and Balcao 
                var doublecheckreceiptStatus = receiptResult?.ReceiptsNumbers?.FirstOrDefault()?.Status;
                #endregion

                foreach (var item in paymentMethods)
                {
                    #region PaymentList
                    //all method available
                    var availablePaymentMethod = (PaymentMethod)item.Clone();
                    //paymentMethod of receipt
                    var receiptPaymentMethod = receiptResult?.ReceiptsNumbers?.FirstOrDefault()?.PaymentMethod;
                    #endregion

                    #region SEPA
                    //Sepa - SDD
                    //S SEPA DD(Prémios)
                    if (receiptPaymentMethod == CommonEnums.EnumPaymentsAgentSAP.SEPA.GetStringValue() &&
                        availablePaymentMethod.IdPaymentMethod == CommonEnums.EnumPayments.Sepa)
                    {
                        //Doublecheck if the receipt status equal C, not show it
                        availablePaymentMethod.IsSelected = true;

                        ////Set MbWay to false
                        validaSelectPaymentOptions(resultList);

                        //Add to Redis
                        //ApplicationName - Token - Environment
                        var isResult = await AddPaymentOnRedisAsync(availablePaymentMethod, requestValue, resultDataPortfolio, receiptResult);

                        //Doublecheck if the receipt status equal C, not show it
                        //Doublecheck if there is in Redis, not show it
                        availablePaymentMethod.IsAvailable = (!isResult && !doublecheckreceiptStatus.Equals("C"));

                        Log.Debug("PaymentMethods response: {receiptPaymentMethod} Status: {doublecheckreceiptStatus}", receiptPaymentMethod, doublecheckreceiptStatus);

                    }
                    #endregion

                    #region TesourariaBalcal
                    //Tesoura
                    //B BALCAO
                    if (receiptPaymentMethod == CommonEnums.EnumPaymentsAgentSAP.BALCAO.GetStringValue() && availablePaymentMethod.IdPaymentMethod == CommonEnums.EnumPayments.Tesouraria)
                    {
                        //Doublecheck if the receipt status equal C, not show it
                        availablePaymentMethod.IsSelected = true;

                        ////Set MbWay to false
                        validaSelectPaymentOptions(resultList);

                        //Add to Redis
                        //ApplicationName - Token - Environment
                        var isResult = await AddPaymentOnRedisAsync(availablePaymentMethod, requestValue, resultDataPortfolio, receiptResult);

                        //Doublecheck if the receipt status equal C, not show it
                        //Doublecheck if there is in Redis, not show it
                        availablePaymentMethod.IsAvailable = (!isResult && !doublecheckreceiptStatus.Equals("C"));

                        Log.Debug("PaymentMethods response: {receiptPaymentMethod} Status: {doublecheckreceiptStatus}", receiptPaymentMethod, doublecheckreceiptStatus);


                    }
                    #endregion

                    #region Mediador-Agente
                    //Agente 
                    //M MEDIADOR
                    if (receiptPaymentMethod == CommonEnums.EnumPaymentsAgentSAP.MEDIADOR.GetStringValue() && availablePaymentMethod.IdPaymentMethod == CommonEnums.EnumPayments.Agente)
                    {
                        //Doublecheck if the receipt is on Charged - doublecheckreceiptchaged
                        //Doublecheck, if agent can do charged - resultValidationAgent
                        availablePaymentMethod.IsSelected = true;

                        //Set MbWay to false
                        validaSelectPaymentOptions(resultList);

                        //Add to Redis
                        //ApplicationName - Token - Environment
                        var isResult = await AddPaymentOnRedisAsync(availablePaymentMethod, requestValue, resultDataPortfolio, receiptResult);

                        //Doublecheck, if the receipt is on Charged - doublecheckreceiptchaged
                        //Doublecheck, if agent can do charged - resultValidationAgent
                        //Doublecheck, if there is in Redis, not show it
                        availablePaymentMethod.IsAvailable = (!isResult && (doublecheckreceiptchaged && resultValidationAgent));

                        Log.Debug("PaymentMethods response: {receiptPaymentMethod} CheckReceiptChange: {doublecheckreceiptchaged} {resultValidationAgent}", receiptPaymentMethod, resultValidationAgent);
                    }

                    #endregion

                    #region MbWay
                    //Valida se há contato na apolice
                    if (availablePaymentMethod.IdPaymentMethod == Constants.CommonEnums.EnumPayments.MbWay)
                    {

                        //Case there's no AgentMethod, enabled MBWay
                        availablePaymentMethod.IsSelected = (doublecheckreceiptchaged && !resultValidationAgent);
                        availablePaymentMethod.Phone = (resultDataPortfolio?.getPolicyDetailWASPResult?.Detail?.HolderPerson)?.Contacts?.FirstOrDefault(opt => opt.Type == CommonEnumsContactType.Mobile)?.Value ?? "";

                        //Add to Redis
                        //ApplicationName - Token - Environment
                        var isResult = await AddPaymentOnRedisAsync(availablePaymentMethod, requestValue, resultDataPortfolio, receiptResult);

                        //Doublecheck if the receipt is on Charged
                        //Doublecheck if there is in Redis, not show it
                        availablePaymentMethod.IsAvailable = (!isResult && doublecheckreceiptchaged);

                        Log.Debug("PaymentMethods response: {receiptPaymentMethod} CheckReceiptChange: {doublecheckreceiptchaged}", receiptPaymentMethod, doublecheckreceiptchaged);

                    }

                    #endregion

                    #region MbReference
                    //Valida se há contato na apolice
                    if (availablePaymentMethod.IdPaymentMethod == Constants.CommonEnums.EnumPayments.MbReference)
                    {
                        availablePaymentMethod.Phone = (resultDataPortfolio.getPolicyDetailWASPResult?.Detail?.HolderPerson)?.Contacts?.FirstOrDefault(opt => opt.Type == CommonEnumsContactType.Mobile)?.Value ?? "";
                        availablePaymentMethod.Email = (resultDataPortfolio.getPolicyDetailWASPResult?.Detail?.HolderPerson)?.Contacts?.FirstOrDefault(opt =>
                        opt.Type == CommonEnumsContactType.Email && opt.Id == "1")?.Value ?? "";

                        //Add to Redis
                        //ApplicationName - Token - Environment
                        var isResult = await AddPaymentOnRedisAsync(availablePaymentMethod, requestValue, resultDataPortfolio, receiptResult);

                        //Doublecheck if the receipt is on Charged
                        //Doublecheck if there is in Redis, not show it
                        availablePaymentMethod.IsAvailable = (!isResult && doublecheckreceiptchaged);

                        Log.Debug("PaymentMethods response: {receiptPaymentMethod} CheckReceiptChange: {doublecheckreceiptchaged}", receiptPaymentMethod, doublecheckreceiptchaged);


                    }

                    #endregion

                    #region ChipPin
                    //Chip & Pin
                    if (availablePaymentMethod.IdPaymentMethod == Constants.CommonEnums.EnumPayments.ChipPin)
                    {

                        //Validate Agent if has privilege to pay with chipandpin
                        var isClassificationCanPayResult = await GetClassificationAgentsAsync(receiptResult.ReceiptsNumbers.FirstOrDefault().InsuranceAgent);

                        //Add to Redis
                        //ApplicationName - Token - Environment
                        var isResult = await AddPaymentOnRedisAsync(availablePaymentMethod, requestValue, resultDataPortfolio, receiptResult);

                        //Doublecheck if the receipt is on Charged
                        //Doublecheck if there is in Redis, not show it
                        availablePaymentMethod.IsAvailable = (!isResult && doublecheckreceiptchaged) && isClassificationCanPayResult;

                        Log.Debug("PaymentMethods response: {receiptPaymentMethod} CheckReceiptChange: {doublecheckreceiptchaged}", receiptPaymentMethod, doublecheckreceiptchaged);

                    }

                    #endregion

                    #region ValidateList
                    //validade there is paymentonRedis
                    if (availablePaymentMethod.IsAvailable)
                    {
                        resultList.Add(availablePaymentMethod);
                    }
                    #endregion

                }

                #region AddListOnRedis

                //Add to Redis
                var availablePaymentMethodResult = resultList?.FirstOrDefault();
                if (availablePaymentMethodResult != null)
                {
                    await AddPaymentOnRedisAsync(availablePaymentMethodResult, requestValue, resultDataPortfolio, receiptResult, true);
                }

                #endregion

                #region ShowList
                resultPaymentMethods = new PaymentMethodsOutput
                {
                    IdReceipt = parameters.Id,
                    ResultList = resultList
                };

                #endregion

            }
            else
            {
                throw new ProcessErrorException(
                        StatusCodes.Status400BadRequest.ToString(), ""
                        , new List<ProcessErrorException.InnerError>
                        {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = receiptResult?.Errors?.FirstOrDefault().ErrorCodeTxt
                                   }
                        });
            }


            stopwatch.Stop();
            Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds} ms");

            return resultPaymentMethods;


        }

        /// <summary>
        /// Life20s the specified parameters.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <param name="validateChannel">The validate channel.</param>
        /// <param name="requestValue">The request value.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">
        /// Erros
        /// or
        /// </exception>
        /// <exception cref="List{ProcessErrorException.InnerError}">
        /// </exception>
        /// <exception cref="ProcessErrorException.InnerError">
        /// </exception>
        public async Task<PaymentMethodsOutput> GetPaymentsByLife20(PaymentMethodsInput parameters, StringValues validateChannel, HttpRequest requestValue)
        {
            //Logging Default
            Log.Debug($" Life20 Request: {requestValue}");

            var stopwatch = new Stopwatch();
            stopwatch.Start();

            var requestObject = new ReceiptDetailWaspInput()
            {
                ReferenceDocumentNumber = parameters.Id
            };


            var receiptResult = await PostReceiptsDetailWaspAsync(requestObject);

            //ValidaFormasdePagamento
            if (receiptResult?.Errors.Count > 0)
            {
                Log.Error($"{receiptResult?.Errors}");
                throw new ProcessErrorException(
                    StatusCodes.Status400BadRequest.ToString(),
                    "Erros", new List<ProcessErrorException.InnerError>{
                                        new ProcessErrorException.InnerError{
                                            ErrorCode =  receiptResult.Errors[0].ErrorCode,
                                            ErrorMessage = receiptResult.Errors[0].ErrorCodeTxt
                                        }
                    }
                    );
            }

            #region Life20

            var keyHeaderSetting = applicationSettings.PaymentMethodOption.KeyHeaderPemissionOnAgent;
            var keyHeader = validateChannel.FirstOrDefault();

            var inputlife20 = new GetProcessDetailRequest()
            {
                Input = new GetProcessDetailInput()
                {
                    Process_id = Convert.ToInt32(receiptResult?.ReceiptsNumbers.FirstOrDefault().Contract)
                }
            };

            var resultDataLife20 = await ReadCanonicalInformationlife20Async(inputlife20);
            List<PaymentMethod> paymentMethodsLife20 = applicationSettings.PaymentMethodOption.PaymentMethods.Where(opt => opt.IsAvailable).ToList();

            List<PaymentMethod> resultList = new List<PaymentMethod>();
            PaymentMethodsOutput resultLife20 = null;

            //receiptNumber
            if (resultDataLife20.Output.Error_message == "OK")
            {
                foreach (var item in paymentMethodsLife20)
                {
                    if (item.IdPaymentMethod == Constants.CommonEnums.EnumPayments.MbWay)
                    {
                        item.Phone = resultDataLife20.Output.Taker.Phone;
                    }
                    else if (item.IdPaymentMethod == Constants.CommonEnums.EnumPayments.Agente)
                    {
                        if (string.IsNullOrEmpty(keyHeader) || (keyHeader?.ToString() == "Life2.0"))
                        {
                            item.IsAvailable = false;
                        }
                        else
                        {
                            item.IsAvailable = !string.IsNullOrEmpty(resultDataLife20.Output?.Process?.Agent_id.ToString());
                        }
                    }

                    if (item.IsAvailable)
                    {
                        resultList.Add(item);
                    }
                }

                //undone mock data
                resultLife20 = new PaymentMethodsOutput
                {
                    IdReceipt = parameters.Id,
                    ResultList = resultList
                };

            }
            else
            {
                throw new ProcessErrorException(
                        StatusCodes.Status400BadRequest.ToString(),
                        resultDataLife20.Output.Error_message, new List<ProcessErrorException.InnerError>
                        {
                                       new ProcessErrorException.InnerError
                                       {
                                           ErrorCode =  StatusCodes.Status400BadRequest.ToString(),
                                           ErrorMessage = resultDataLife20.Output.Error_message
                                       }
                        });
            }

            stopwatch.Stop();
            Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds} ms");


            return resultLife20;
            #endregion
        }

        /// <summary>
        /// Gets the payments by unit linked asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <param name="validateChannel">The validate channel.</param>
        /// <param name="requestValue">The request value.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">
        /// </exception>
        /// <exception cref="List{ProcessErrorException.InnerError}">
        /// </exception>
        /// <exception cref="ProcessErrorException.InnerError">
        /// </exception>
        public async Task<PaymentMethodsOutput> GetPaymentsByUnitLinkedAsync(PaymentMethodsInput parameters, StringValues validateChannel, HttpRequest requestValue)
        {
            //PaymentList
            List<PaymentMethod> paymentMethods = applicationSettings.PaymentMethodOption.PaymentMethods.ToList();
            List<PaymentMethod> resultList = new List<PaymentMethod>();
            PaymentMethodsOutput resultPaymentMethods = null;

            try
            {
                #region Header

                var keyHeaderSetting = applicationSettings.PaymentMethodOption.KeyHeaderPemissionOnAgent;
                var keyHeaderChannel = validateChannel.FirstOrDefault();

                #endregion

                #region UnitLinked

                #region CallProposal
                var resultDataPropostaSap = await CallProposalAsync(parameters.Id);
                #endregion

                #region GetPhoneEmailEntitiesByNIF
                var contacts = await GetPhoneEmailEntitiesByNifAsync(resultDataPropostaSap.Proposal.Nif);
                #endregion

                #region ViewPaymentsMethods

                foreach (var item in paymentMethods)
                {
                    //all method available
                    var availablePaymentMethod = (PaymentMethod)item.Clone();
                    availablePaymentMethod.IsAvailable = false;

                    #region MbWay                    
                    //Valida se há contato na apolice
                    if (availablePaymentMethod.IdPaymentMethod == Constants.CommonEnums.EnumPayments.MbWay)
                    {
                        //Case there's no AgentMethod, enabled MBWay
                        availablePaymentMethod.IsSelected = false;
                        availablePaymentMethod.Phone = contacts?.Phones?.FirstOrDefault()?.PhoneNumber;
                        availablePaymentMethod.Email = contacts?.Emails?.FirstOrDefault()?.EmailAddress;

                        //Add to Redis
                        //ApplicationName - Token - Environment
                        var isResult = await AddPaymentOnRedisAsync(availablePaymentMethod, requestValue, resultDataPropostaSap);

                        //Doublecheck if there is in Redis, not show it
                        availablePaymentMethod.IsAvailable = !isResult;
                    }

                    #endregion
                    #region MbReference
                    //Valida se há contato na apolice
                    if (availablePaymentMethod.IdPaymentMethod == Constants.CommonEnums.EnumPayments.MbReference)
                    {
                        availablePaymentMethod.Phone = contacts?.Phones?.FirstOrDefault()?.PhoneNumber;
                        availablePaymentMethod.Email = contacts?.Emails?.FirstOrDefault()?.EmailAddress;

                        //Add to Redis
                        //ApplicationName - Token - Environment
                        var isResult = await AddPaymentOnRedisAsync(availablePaymentMethod, requestValue, resultDataPropostaSap);

                        //Doublecheck if there is in Redis, not show it
                        availablePaymentMethod.IsAvailable = !isResult;
                    }

                    //validade there is paymentonRedis
                    if (availablePaymentMethod.IsAvailable)
                    {
                        resultList.Add(availablePaymentMethod);
                    }
                }

                resultPaymentMethods = new PaymentMethodsOutput
                {
                    IdReceipt = parameters.Id,
                    ResultList = resultList
                };
                
                #endregion

                #region AddListOnRedis

                //Add to Redis
                var availablePaymentMethodResult = resultList?.FirstOrDefault();
                if (availablePaymentMethodResult != null)
                {
                    await AddPaymentOnRedisAsync(availablePaymentMethodResult, requestValue, resultDataPropostaSap, true);
                }

                #endregion

                stopwatch.Stop();
                Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds} ms");


                //Validade return
                if (resultPaymentMethods?.TotalResults <= 0)
                {
                    Log.Error($"{"No payments available to show"}");
                    throw new ProcessErrorException(
                        StatusCodes.Status404NotFound.ToString(),
                        "NotFound", new List<ProcessErrorException.InnerError>{
                                        new ProcessErrorException.InnerError{
                                            ErrorCode =  "Payments",
                                            ErrorMessage = "No payments available to show"
                                        }
                                }
                        );
                }

                return resultPaymentMethods;

                #endregion

                #endregion


                #region ErrorExceptions
            }
            catch (AggregateException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);

                var errorNumber = StatusCodes.Status404NotFound.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    innerErrors.Add(new ProcessErrorException.InnerError
                    {
                        ErrorCode = errorNumber,
                        ErrorMessage = e.Message,
                        ErrorType = String.Empty
                    });
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message,
                            ErrorType = String.Empty
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            catch (TimeoutException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status408RequestTimeout.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status408RequestTimeout.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               });
            }
            catch (NullReferenceException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                throw new ProcessErrorException(
                               StatusCodes.Status404NotFound.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status404NotFound.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (BusinessException e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);

                var errorNumber = StatusCodes.Status404NotFound.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    //In this case, return innerErros filled
                    var innerExcepErrors = ((BusinessException)e)?.InnerErrors;
                    if (innerExcepErrors == null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = e.Message
                        });
                    }
                    else
                    {
                        foreach (var item in innerExcepErrors)
                        {
                            innerErrors.Add(new ProcessErrorException.InnerError
                            {
                                ErrorCode = errorNumber,
                                ErrorMessage = innerExcepErrors?.FirstOrDefault()?.ErrorMessage,
                                ErrorType = String.Empty
                            });
                        }
                    }
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message,
                            ErrorType = String.Empty
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }
            catch (FaultException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (CanonicalException e)
            {
                Log.Error("Error" + e);
                throw new ProcessErrorException(
                               StatusCodes.Status400BadRequest.ToString(),
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = e.Message
                                   }
                               }
                               );
            }
            catch (Exception e)
            {
                Log.Error("Unsuccessful call! Status with exception: {e}", e);
                var errorNumber = StatusCodes.Status400BadRequest.ToString();
                var innerErrors = new List<ProcessErrorException.InnerError>();
                if (e.InnerException == null)
                {
                    //In this case, return innerErros filled
                    var innerExcepErrors = ((ProcessErrorException)e)?.InnerErrors;
                    if (innerExcepErrors == null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = e.Message
                        });
                    }
                    else
                    {
                        foreach (var item in innerExcepErrors)
                        {
                            innerErrors.Add(new ProcessErrorException.InnerError
                            {
                                ErrorCode = errorNumber,
                                ErrorMessage = innerExcepErrors?.FirstOrDefault()?.ErrorMessage,
                                ErrorType = String.Empty
                            });
                        }
                    }
                }
                else
                {
                    var innerExcep = e.InnerException;
                    while (innerExcep != null)
                    {
                        innerErrors.Add(new ProcessErrorException.InnerError
                        {
                            ErrorCode = errorNumber,
                            ErrorMessage = innerExcep.Message
                        });

                        innerExcep = innerExcep.InnerException;
                    }
                }
                throw new ProcessErrorException(errorNumber, e.Message, innerErrors);
            }

            #endregion
        }

        #region Canonical

        /// <summary>
        /// Posts the get life proposal asynchronous.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        public async Task<LifeProposalOutput> PostGetLifeProposalAsync(LifeProposalInput requestObject)
        {
            return await collectionsRepository.GetLifeProposalAsync(requestObject);
        }


        /// <summary>
        /// Creates the canonical client.
        /// </summary>
        /// <returns></returns>
        public PoliciesServiceClient CreateCanonicalClient()
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();


            // read enpoint address
            var address = new EndpointAddress(applicationSettings.CanonicalService.CanonicalUrl);

            //#region Binding

            // read timeouts from config
            TimeSpan OpenTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:OpenTimeout");
            TimeSpan CloseTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:CloseTimeout");
            TimeSpan SendTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:SendTimeout");
            TimeSpan ReceiveTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:ReceiveTimeout");
            TimeSpan RestTimeout = configuration.ReadTimeSpanFromConfig("ServicesTimeouts:RestTimeout");

            var binding = new BasicHttpBinding
            {
                MaxBufferSize = int.MaxValue,
                ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max,
                MaxReceivedMessageSize = int.MaxValue,
                AllowCookies = true,
                SendTimeout = SendTimeout,
                ReceiveTimeout = ReceiveTimeout,
                CloseTimeout = CloseTimeout,
                OpenTimeout = OpenTimeout
            };

            // check if it is http or https
            if (string.Compare(address.Uri.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            }

            // return proxy
            return new PoliciesServiceClient(binding, address);
        }

        ///v1/ProposalAIA/GetBeforeChargeProposalAia
        public async Task<Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse> GetBeforeChargeProposalAiaAsync(PaymentMethodsInput parameters)
        {
            //Structure Create
            var requestObject =
                 new Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWs()
                 {
                     IProposalNumber = parameters.Id
                 };

            //Logging Default
            stopwatch.Restart();
            Log.Debug($"GetBeforeChargeProposalAiaAsync requestObject Request: {JsonConvert.SerializeObject(requestObject)}");

            HttpRequestElement requestElement = new HttpRequestElement
            {
                ApiService = applicationSettings.BrokerServicesNameSpaces.Collections,
                ApiMethod = GetBeforeChargeProposalAiaMethod,
                QueryString = request.QueryString,
                Method = CommonEnums.HttpRequestVerb.POST,
                RequestObject = requestObject
            };

            //Logging Default
            Log.Debug($"GetBeforeChargeProposalAiaAsync requestElement Request: {JsonConvert.SerializeObject(requestElement)}");

            stopwatch.Restart();
            Log.Debug($"GetBeforeChargeProposalAiaAsync requestElement Request: {JsonConvert.SerializeObject(requestElement)}");

            Task<Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse> output = repositoryInvoker
                .GenericInvokerAsync<Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse, Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse>(requestElement);

            stopwatch.Stop();
            Log.Debug("GetBeforeChargeProposalAiaAsync Response: {output} in {Elapsed:000} ms", output, stopwatch.ElapsedMilliseconds);
            return await output;
        }

        /// <summary>
        /// Reads the canonical information asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public async Task<getPolicyDetailWASPResponse> ReadCanonicalInformationAsync(PaymentMethodsInput parameters)
        {
            //Logging Default
            Log.Debug($"ReadCanonicalInformation Async Request: {JsonConvert.SerializeObject(parameters)}");

            var stopwatch = new Stopwatch();
            stopwatch.Start();

            getPolicyDetailWASPResponse canonicalResponse = null;
            stopwatch.Start();

            try
            {
                // build request for canonical
                var canonicalRequest = new getPolicyDetailWASPRequest
                {
                    AxisValues = new AxisValues
                    {
                        Solution = applicationSettings.CanonicalService.BrokerSolution,
                        User = applicationSettings.CanonicalService.BrokerUser
                    },
                    inputData = new GetPolicyDetailWASPInputData()
                    {
                        PolicyNumber = parameters.Id,
                        ClearCache = false,
                        GetMockup = false,
                        SolutionChannel = applicationSettings.CanonicalService.BrokerSolution
                    }
                };

                stopwatch.Restart();
                Log.Debug($"GetPolicyDetailWASPAsync SAP Request: {JsonConvert.SerializeObject(canonicalRequest)}");
                // make call to service
                canonicalResponse = await canonicalService.getPolicyDetailWASPAsync(canonicalRequest);

                stopwatch.Stop();
                Log.Debug($"GetPolicyDetailWASPAsync SAP Response: {JsonConvert.SerializeObject(canonicalResponse)} in {stopwatch.ElapsedMilliseconds} ms");


            }
            catch (Exception e)
            {
                Log.Error($"Error calling canonical service: {e}");
            }
            return canonicalResponse;
        }

        /// <summary>
        /// Reads the canonical informationlife20 asynchronous.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        private async Task<GetProcessDetailResponse> ReadCanonicalInformationlife20Async(GetProcessDetailRequest requestObject)
        {
            //Logging Default
            Log.Debug($"ReadCanonicalInformationlife20Async Request: {requestObject}");

            var stopwatch = new Stopwatch();
            stopwatch.Start();

            HttpRequestElement requestElement = new HttpRequestElement
            {
                ApiService = applicationSettings.BrokerServicesNameSpaces.Life2Front,
                ApiMethod = GetProcessDetailMethod,
                QueryString = request.QueryString,
                Method = CommonEnums.HttpRequestVerb.POST,
                RequestObject = requestObject
            };

            Task<GetProcessDetailResponse> output = repositoryInvoker
                .GenericInvokerAsync<GetProcessDetailResponse, GetProcessDetailResponse>(requestElement);

            stopwatch.Stop();
            Log.Debug($"ReadCanonicalInformationlife20Async Response Time: {stopwatch.ElapsedMilliseconds}ms");

            return await output;

        }

        #endregion

        /// <summary>
        /// Calls the proposal asynchronous.
        /// </summary>
        /// <param name="idProposal">The identifier proposal.</param>
        /// <returns></returns>
        public async Task<Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse> CallProposalAsync(string idProposal)
        {

            //Call ProposalSAP
            var inputProposalSap = new PaymentMethodsInput
            {
                Id = idProposal
            };

            stopwatch.Restart();
            Log.Debug($"GetBeforeChargeProposalAiaAsync inputProposalSap Request: {JsonConvert.SerializeObject(inputProposalSap)}");
            ///v1/ProposalAIA/GetBeforeChargeProposalAia
            var resultDataPropostaSap = await GetBeforeChargeProposalAiaAsync(inputProposalSap);
            stopwatch.Stop();
            Log.Debug("GetBeforeChargeProposalAiaAsync resultDataPropostaSap Response: {resultDataPropostaSap} in {Elapsed:000} ms", JsonConvert.SerializeObject(resultDataPropostaSap), stopwatch.ElapsedMilliseconds);

            return resultDataPropostaSap;
        }

        /// <summary>
        /// Gets the phone email entities by nif asynchronous.
        /// </summary>
        /// <param name="nif">The nif.</param>
        /// <returns></returns>
        public async Task<ContactLists> GetPhoneEmailEntitiesByNifAsync(string nif)
        {
            //v1/Entities/search - Get Entities from NIF
            SearchEntityInput inputSearch = new SearchEntityInput()
            {
                VatNumber = nif //"213200104"
            };

            //Return Entities
            var resultSearch = await statesRepository.GetEntitiesSearchAsync(inputSearch);

            EntitiesInput entitiesinput = new EntitiesInput()
            {
                IdEntity = resultSearch.MatchedEntities.FirstOrDefault().IdEntity
            };

            //Return Entities
            var resultEntitiesContact = await statesRepository.GetContactsByEntityAsync(entitiesinput);
            resultEntitiesContact.Phones = resultEntitiesContact.Phones.Where(c => c.IsPreferred == true).ToList();
            resultEntitiesContact.Emails = resultEntitiesContact.Emails.Where(c => c.IsPreferred == true).ToList();

            return resultEntitiesContact;

        }


        #region SuportMethods

        /// <summary>
        /// Validas the select payment options.
        /// </summary>
        /// <param name="lstActual">The LST actual.</param>
        public void validaSelectPaymentOptions(List<PaymentMethod> lstActual)
        {
            //A lista é populada de forma sequencial, depois é necessário validar se houver realmente não há serviços de Agente, SEPA.
            foreach (var itemList in lstActual)
            {
                if (itemList.IdPaymentMethod.Equals(CommonEnums.EnumPayments.MbWay))
                {
                    itemList.IsSelected = false;
                }
            }
        }

        /// <summary>
        /// Adds the payment on redis asynchronous.
        /// </summary>
        /// <param name="availablePaymentMethod">The available payment method.</param>
        /// <param name="requestValue">The request value.</param>
        /// <param name="resultDataPortfolio">The result data portfolio.</param>
        /// <param name="receiptResult">The receipt result.</param>
        /// <returns></returns>
        public async Task<bool> AddPaymentOnRedisAsync(PaymentMethod availablePaymentMethod, HttpRequest requestValue, getPolicyDetailWASPResponse resultDataPortfolio, ReceiptDetailWaspOutput receiptResult, bool AddItem = false)
        {
            bool isExisteResult = false;

            //Add to Redis
            //ApplicationName - Token - Environment
            StringValues token;
            requestValue?.Headers.TryGetValue("Authorization", out token);

            //Default contrat when return by Receipt
            //Proposal when return by proposal
            var receiptDetailResultContract = receiptResult?.ReceiptsNumbers?.FirstOrDefault().Contract;

            //Add to Redis Session
            //Session Payments stores the payment that was made
            StringValues sessionPaymentOptions;
            requestValue?.Headers.TryGetValue("SessionPaymentOptions", out sessionPaymentOptions);

            //Add to Redis Session
            StringValues channel;
            requestValue?.Headers.TryGetValue("channel", out channel);

            if (token.Count > 0)
            {
                //Create Context on Redis
                //Validade if exists
                //Stardard : ApplicationName | Token | Environment
                var keyQuery = String.Empty;

                if (sessionPaymentOptions.Count > 0)
                {
                    keyQuery = $"{sessionPaymentOptions}-{ApplicationSettings.ApplicationName}-{receiptDetailResultContract}-{token}";
                }
                else
                {
                    keyQuery = $"{ApplicationSettings.ApplicationName}-{receiptDetailResultContract}-{token}";
                }

                Log.Debug("CheckRedis response: {keyQuery} ", keyQuery);
                RedisOutput<PaymentOutput> contextPayment = await redisManager.GetContextAsync<PaymentOutput>(keyQuery);
                Log.Debug("CheckRedis response: {contextPayment} ", JsonConvert.SerializeObject(contextPayment));
                if (!contextPayment.IsValid && AddItem)
                {
                    var BackEndValue = resultDataPortfolio?.getPolicyDetailWASPResult?.Detail?.Backend.ToString() ?? "SAP";

                    //Create a object default
                    var paymentMethodsQuery = new PaymentOutput()
                    {
                        Phone = availablePaymentMethod.Phone,
                        Email = availablePaymentMethod.Email,
                        BackEnd = BackEndValue,
                        Policy = receiptResult?.ReceiptsNumbers?.FirstOrDefault()?.Contract,
                        StatusCodes = String.Empty,
                        SessionPaymentOptions = sessionPaymentOptions,
                        Channel = channel.ToString() == "" ? "DynamicForms" : channel.ToString()
                    };
                    RedisOutput<PaymentOutput> redisAgentOutput = await redisManager.CreateContextAsync<PaymentOutput>(keyQuery, paymentMethodsQuery, null);
                    Log.Debug("CheckRedis CreateContext: {redisAgentOutput} ", JsonConvert.SerializeObject(redisAgentOutput));
                }
                else
                {
                    if (contextPayment.IsValid)
                    {
                        // if exist code, don´t show it.
                        if(contextPayment.Value?.StatusCodes != null)
                        {
                            isExisteResult = contextPayment.Value.StatusCodes.Equals("200");
                        } 
                    }
                }
            }

            Log.Debug("CheckRedis response: {isExisteResult200} ", isExisteResult);

            return isExisteResult;
        }

        /// <summary>
        /// Validates the current payment.
        /// </summary>
        /// <param name="requestValue">The request value.</param>
        /// <param name="receiptResult">The receipt result.</param>
        /// <returns></returns>
        public async Task<bool> ValidateCurrentPayment(HttpRequest requestValue, ReceiptDetailWaspOutput receiptResult)
        {
            //Add to Redis
            //ApplicationName - Token - Environment
            StringValues token;
            requestValue?.Headers.TryGetValue("Authorization", out token);

            //Add to Redis Session
            //Session Payments stores the payment that was made
            StringValues sessionPaymentOptions;
            requestValue?.Headers.TryGetValue("SessionPaymentOptions", out sessionPaymentOptions);

            var receiptDetailResultContract = receiptResult?.ReceiptsNumbers?.FirstOrDefault().Contract;

            var keyQuery = String.Empty;
            if (sessionPaymentOptions.Count > 0)
            {
                keyQuery = $"{sessionPaymentOptions}-{ApplicationSettings.ApplicationName}-{receiptDetailResultContract}-{token}";
            }
            else
            {
                keyQuery = $"{ApplicationSettings.ApplicationName}-{receiptDetailResultContract}-{token}";
            }

            RedisOutput<PaymentOutput> contextPayment = await redisManager.GetContextAsync<PaymentOutput>(keyQuery);
            Log.Debug("ValidateCurrentPayment {contextPayment} ", JsonConvert.SerializeObject(contextPayment));

            if (contextPayment.IsValid)
            {
                return contextPayment.Value.StatusCodes.Equals("200");
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Gets the classification agents asynchronous.
        /// </summary>
        /// <param name="codeAgent">The code agent.</param>
        /// <returns></returns>
        public async Task<bool> GetClassificationAgentsAsync(string codeAgent)
        {
            stopwatch.Restart();
            Log.Debug("GetClassificationAgentsAsync Request: {requestValue}", JsonConvert.SerializeObject(codeAgent));

            //Remove os caracteres, a pesquisa no CommercialStructure busca somente via código do agente
            var codeAgentReplaced = codeAgent.Replace("M0", "").Replace("M1", "").TrimStart('0');
            Log.Debug("GetClassificationAgentsAsync Request: {requestValue}", JsonConvert.SerializeObject(codeAgentReplaced));

            //Result Validate
            var isClassificationOutput = await commercialStructure.GetAgentClassifications(codeAgentReplaced);
            Log.Debug("isClassificationOutput Response: {isClassificationOutput}", JsonConvert.SerializeObject(isClassificationOutput));

            //=01 - Com Cobrança
            //=02 - Sem Cobrança
            // Regra - se o agente que está associado ao recibo, tiver a opção 01 - Cobrança. Será disponibilizado a forma de pagamento chippin

            var isClassificationOutputSelected = isClassificationOutput?.Classifications?.Where(c => c.Code == "01").ToList();
            Log.Debug("isClassificationOutput Response: {isClassificationOutputSelected}", JsonConvert.SerializeObject(isClassificationOutputSelected));

            var isResult = isClassificationOutputSelected.Count > 0;
            stopwatch.Stop();
            Log.Debug("GetClassificationAgentsAsync Response: in {Elapsed:000} ms", stopwatch.ElapsedMilliseconds);

            return isResult;
        }

        public async Task<bool> AddPaymentOnRedisAsync(PaymentMethod availablePaymentMethod, HttpRequest requestValue, Model.Partners.BeforeCharge.ProposalAIA.ZageasLifeGetBeforeChargeWsResponse proposalResult, bool AddItem = false)
        {
            bool isExisteResult = false;

            //Add to Redis
            //ApplicationName - Token - Environment
            StringValues token;
            requestValue?.Headers.TryGetValue("Authorization", out token);

            //Default contrat when return by Receipt
            //Proposal when return by proposal
            var receiptDetailResultContract = proposalResult?.Proposal?.ProposalNumber;

            //Add to Redis Session
            //Session Payments stores the payment that was made
            StringValues sessionPaymentOptions;
            requestValue?.Headers.TryGetValue("SessionPaymentOptions", out sessionPaymentOptions);

            //Add to Redis Session
            StringValues channel;
            requestValue?.Headers.TryGetValue("channel", out channel);

            if (token.Count > 0)
            {
                //Create Context on Redis
                //Validade if exists
                //Stardard : ApplicationName | Token | Environment
                var keyQuery = String.Empty;

                if (sessionPaymentOptions.Count > 0)
                {
                    keyQuery = $"{sessionPaymentOptions}-{ApplicationSettings.ApplicationName}-{receiptDetailResultContract}-{token}";
                }
                else
                {
                    keyQuery = $"{ApplicationSettings.ApplicationName}-{receiptDetailResultContract}-{token}";
                }

                Log.Debug("CheckRedis response: {keyQuery} ", keyQuery);
                RedisOutput<PaymentOutput> contextPayment = await redisManager.GetContextAsync<PaymentOutput>(keyQuery);
                Log.Debug("CheckRedis response: {contextPayment} ", JsonConvert.SerializeObject(contextPayment));
                if (!contextPayment.IsValid && AddItem)
                {
                    var BackEndValue = "SAP";

                    //Create a object default
                    var paymentMethodsQuery = new PaymentOutput()
                    {
                        Phone = availablePaymentMethod.Phone,
                        Email = availablePaymentMethod.Email,
                        BackEnd = BackEndValue,
                        Proposal = receiptDetailResultContract,
                        StatusCodes = String.Empty,
                        SessionPaymentOptions = sessionPaymentOptions,
                        Channel = channel.ToString() == "" ? "DynamicForms" : channel.ToString()
                    };
                    RedisOutput<PaymentOutput> redisAgentOutput = await redisManager.CreateContextAsync<PaymentOutput>(keyQuery, paymentMethodsQuery, null);
                    Log.Debug("CheckRedis CreateContext: {redisAgentOutput} ", JsonConvert.SerializeObject(redisAgentOutput));
                }
                else
                {
                    if (contextPayment.IsValid)
                    {
                        // if exist code, don´t show it.
                        isExisteResult = contextPayment.Value.StatusCodes.Equals("200");
                    }
                }
            }

            Log.Debug("CheckRedis response: {isExisteResult200} ", isExisteResult);

            return isExisteResult;
        }


        #endregion  
    }

    #endregion
}

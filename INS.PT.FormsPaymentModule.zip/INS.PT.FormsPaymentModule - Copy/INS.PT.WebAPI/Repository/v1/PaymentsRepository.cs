﻿using AutoMapper;
using INS.PT.WebAPI.Constants;
using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Interface.v1;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Collections;
using INS.PT.WebAPI.Models.FinancialMPOS;
using INS.PT.WebAPI.Models.Input.v1;
using INS.PT.WebAPI.Models.Output;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Repository.v1
{
    /// <summary>
    /// PaymentsRepository
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.IPayments" />
    public class PaymentsRepository : BaseRepository, IPayments
    {
        const string ConstPrintType = "E";
        const string ConstIdDocument = "idD";
        const string ConstPrefixDoc = "RC";
        const string ConstThirdParty = "0";

        private readonly string ConstErrorMessage = "Not Found";
        private readonly string ConstErrorMessageAgente = "DocId Not Found";

        private readonly ICollectionsRepository _collectionsRepository;
        private readonly IPaymentMposRepository _paymentMposRepository;
        private readonly IGetEntityPaymentRepository _getEntityPaymentRepository;
        private readonly IConfiguration _configuration;
        private readonly IHttpClientRepository httpClientRepository;
   
        private readonly IMapper mapper;

 
        public PaymentsRepository(IConfiguration _configuration, IHttpClientRepository _httpClientRepository, IRepositoryInvoker _repositoryInvoker, ApplicationSettings _applicationSettings, IMapper _mapper, HttpRequest _request, ICollectionsRepository collectionsRepository, IPaymentMposRepository paymentMposRepository, IGetEntityPaymentRepository getEntityPaymentRepository)
       : base(_configuration, _applicationSettings, _repositoryInvoker)
        {
       
            mapper = _mapper;
            httpClientRepository = _httpClientRepository;
            _collectionsRepository = collectionsRepository ?? throw new ArgumentNullException(nameof(collectionsRepository));
            _paymentMposRepository = paymentMposRepository ?? throw new ArgumentNullException(nameof(paymentMposRepository));
            _getEntityPaymentRepository = getEntityPaymentRepository ?? throw new ArgumentNullException(nameof(getEntityPaymentRepository));
        }


 
        /// <summary>
        /// Posts the reference mb way payment asynchronous.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException"></exception>
        /// <exception cref="ProcessErrorException.InnerError"></exception>
        public async Task<RefMBPaymentOutputDTO> PostRefMBWayPaymentAsync(RefMBPaymentInputDTO requestObject)
        {
            return await _paymentMposRepository.RefMBPaymentAsync(requestObject);
        }

        /// <summary>
        /// Posts the mb way payment asynchronous.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException"></exception>
        /// <exception cref="ProcessErrorException.InnerError"></exception>
        public async Task<MBWayPaymentOutputDTO> PostMBWayPaymentAsync(MBWayPaymentInputDTO requestObject)
        {
            return await _paymentMposRepository.MBWayPaymentAsync(requestObject);
        }

        /// <summary>
        /// Posts the receipts detail wasp.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        public async Task<ReceiptDetailWaspOutput> PostReceiptsDetailWaspAsync(ReceiptDetailWaspInput requestObject)
        {
            return await _collectionsRepository.ReceiptsDetail(requestObject);
        }

        public async Task<ChargedReceiptLineDetailResponseWaspOuptut> PostChargedWaspAsync(string requestObject)
        {
            return await _collectionsRepository.Charged(requestObject);
        }


        public string GetEntityPayment(string company)
        {
            //Logging Default
            Log.Debug($"GetEntityPayment Request: {company}");
            var stopwatch = new Stopwatch();
            stopwatch.Start();

            //Oracle Params definition
            OracleDynamicParameters DyParam = _getEntityPaymentRepository.ValidateParams(company);
            //Set ResultData Structure
 
            var oracleExec = $"{applicationSettings.OracleSettings.OraclePackageWebservice?.ToList()?.Where(x => x.FunctionName == "fun_get_entity_refpaym")?.FirstOrDefault()?.PackageName}" +
                $".{applicationSettings.OracleSettings.OraclePackageWebservice?.ToList()?.Where(x => x.FunctionName == "fun_get_entity_refpaym")?.FirstOrDefault()?.FunctionName}";

            //GetDoc SubmitFunction Oracle without document Request
            var validaAgentResult = _getEntityPaymentRepository.SubmitStoreProcedure(oracleExec, company);


            if (validaAgentResult == "")
            {
                throw new ProcessErrorException(
                           StatusCodes.Status401Unauthorized.ToString(CultureInfo.CurrentCulture),
                           ConstErrorMessage, new List<ProcessErrorException.InnerError>
                           {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status401Unauthorized.ToString(CultureInfo.CurrentCulture),
                                       ErrorMessage = ConstErrorMessageAgente.ToString(CultureInfo.CurrentCulture)
                                   }
                           }
                           );
            }

            stopwatch.Stop();
            Log.Debug($"GetEntityPayment Response Time: {stopwatch.ElapsedMilliseconds}ms");

            return validaAgentResult;

        }

        public dynamic PaymentMethodsOutputParam(string key, string subkey)
        {
            //AppOrigem - PaymentMethodOption:AppOrigem
            //Header - PaymentMethodOption:KeyHeaderPemissionOnAgent

            string concatKeySubKey = key + ":" + subkey;
            return _configuration.GetSection(concatKeySubKey).Get<string>();
        }

        public async Task<PaymentOutput> MakePaymentAsync(PaymentsInput parameters)
        {
            //Logging Default
            Log.Debug($"Request: {parameters}");

            var stopwatch = new Stopwatch();
            stopwatch.Start();

            //ValidaInput
            ValidInputPayment(parameters);
            var appOrigem = applicationSettings.PaymentMethodOption.AppOrigem;
            List<PaymentMethod> paymentMethods = applicationSettings.PaymentMethodOption.PaymentMethods.Where(opt => opt.IsAvailable).ToList();

            PaymentOutput result = null;
            try
            {

                switch (parameters.IdPaymentMethod)
                {
                    case CommonEnums.EnumPayments.MbWay:
                        //REcebipt number obrigatory

                        //set ReceiptDetail
                        ReceiptDetailWaspInput receiptMbWayRequestObject = new ReceiptDetailWaspInput()
                        {
                            ReferenceDocumentNumber = parameters.ReceiptNumber
                        };

                        //Call WebReceiptList
                        ReceiptDetailWaspOutput receiptResult = await PostReceiptsDetailWaspAsync(receiptMbWayRequestObject);

                        if (receiptResult?.Errors.Count > 0)
                        {
                            throw new ProcessErrorException(
                                StatusCodes.Status400BadRequest.ToString(),
                                "Erros", new List<ProcessErrorException.InnerError>{
                                        new ProcessErrorException.InnerError{
                                            ErrorCode =  receiptResult.Errors[0].ErrorCode,
                                            ErrorMessage = receiptResult.Errors[0].ErrorCodeTxt
                                        }
                                }
                                );
                        }
                        else
                        {
                            const string ConstPaymentBrand = "1";



                            //Call Api Financial - MBWayPayment
                            MBWayPaymentInputDTO mbway = null;

                            foreach (var item in receiptResult?.ReceiptsNumbers)
                            {
                                mbway = new MBWayPaymentInputDTO()
                                {
                                    AppOrigemId = appOrigem,
                                    InternalCompany = item.CompanyCode,
                                    Nif = ValidateField.ValidateNif(item.TaxNum),
                                    PaymentBrand = ConstPaymentBrand,
                                    PhoneNumber = parameters.AditionalInformation,
                                    PrintType = ConstPrintType,
                                    Receipts = new List<Models.PaymentMPOS.PaymentReceipt>() {
                                            new Models.PaymentMPOS.PaymentReceipt(){
                                                Amount = item.TotalValue,
                                                IdDocument = ConstIdDocument,
                                                IdReceipt = item.ReferenceDocumentNumber,
                                                Policy = item.Contract,
                                                PrefixDoc = ConstPrefixDoc,
                                                ThirdParty = false
                                            }
                                        },
                                    ThirdParty = ConstThirdParty,
                                    Timestamp = DateTime.Now.ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'"),
                                    TotalAmount = item.TotalValue,
                                    UserId = ValidateField.ValidateAgent(!string.IsNullOrEmpty(item.InsuranceAgent) ? item.InsuranceAgent : !string.IsNullOrEmpty(item.InsuranceBroker) ? item.InsuranceBroker : "")
                                };
                            }

                            Log.Debug($"{MethodBase.GetCurrentMethod()} Request: {JsonConvert.SerializeObject(mbway)}");

                            MBWayPaymentOutputDTO resultMbWay = await PostMBWayPaymentAsync(mbway);

                            result = new PaymentOutput()
                            {
                                Code = resultMbWay.ErrorCode,
                                Status = resultMbWay.Status,
                                Message = resultMbWay.ErrorMessage,
                                MerchantTransactionId = resultMbWay.MerchantTransactionId
                            };
                        }

                        stopwatch.Stop();
                        Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds}ms");

                        break;

                    case CommonEnums.EnumPayments.MbReference:
                        var refLmtDtTm = "";
                        //call ReceiptDetail
                        ReceiptDetailWaspInput receiptMbReferenceRequestObject = new ReceiptDetailWaspInput()
                        {
                            ReferenceDocumentNumber = parameters.ReceiptNumber
                        };

                        //Call WebReceiptList
                        ReceiptDetailWaspOutput mbreferenceReceiptResult = await PostReceiptsDetailWaspAsync(receiptMbReferenceRequestObject);

                        if (mbreferenceReceiptResult?.Errors.Count > 0)
                        {
                            throw new ProcessErrorException(
                                                     StatusCodes.Status400BadRequest.ToString(),
                                                     "Erros", new List<ProcessErrorException.InnerError>
                                                     {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  mbreferenceReceiptResult.Errors[0].ErrorCode,
                                       ErrorMessage = mbreferenceReceiptResult.Errors[0].ErrorCodeTxt
                                   }
                                                     });
                        }
                        else
                        {
                            const string ConstPaymentBrand = "2";


                            //Call Api Financial - refMbPayment
                            RefMBPaymentInputDTO refmbreference = null;

                            foreach (var item in mbreferenceReceiptResult?.ReceiptsNumbers)
                            {
                                var entityValue = GetEntityPayment(item.CompanyCode);
                                refLmtDtTm = ValidateDateTime.ToCorrectDateTime(item.NetDueDate).ToString();

                                refmbreference = new RefMBPaymentInputDTO()
                                {
                                    PtMntEntty = entityValue,
                                    RefIntlDtTm = ValidateDateTime.ToCorrectDateTime(item.EmissionDate, item.EmissionHour).ToString(),
                                    RefLmtDtTm = ValidateDateTime.ToCorrectDateTime(item.NetDueDate).ToString(),
                                    Timestamp = DateTime.Now.ToUniversalTime().ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'"),
                                    AppOrigemId = appOrigem,
                                    InternalCompany = item.CompanyCode,
                                    Nif = item.TaxNum,
                                    PaymentBrand = ConstPaymentBrand, //Valor Default
                                    PrintType = ConstPrintType,
                                    Receipts = new List<Models.PaymentMPOS.PaymentReceipt>()
                                    {
                                        new Models.PaymentMPOS.PaymentReceipt()
                                        {
                                            Amount = item.TotalValue,
                                            IdDocument = ConstIdDocument,
                                            IdReceipt = item.ReferenceDocumentNumber,
                                            Policy = item.Contract,
                                            PrefixDoc = ConstPrefixDoc,
                                            ThirdParty = false
                                        }
                                    },
                                    ThirdParty = ConstThirdParty,
                                    TotalAmount = item.TotalValue,
                                    UserId = ValidateField.ValidateAgent(!string.IsNullOrEmpty(item.InsuranceAgent) ? item.InsuranceAgent : !string.IsNullOrEmpty(item.InsuranceBroker) ? item.InsuranceBroker : "")
                                };
                            }

                            Log.Debug($"{MethodBase.GetCurrentMethod()} Request: {JsonConvert.SerializeObject(refmbreference)}");

                            RefMBPaymentOutputDTO resultrefMbWay = await PostRefMBWayPaymentAsync(refmbreference);

                            //Customization Message
                            var tempMessage = applicationSettings.PaymentMethodOption.PaymentMethods.FirstOrDefault(opt => opt.IdPaymentMethod == CommonEnums.EnumPayments.MbReference).Message;

                            result = new PaymentOutput()
                            {
                                Code = resultrefMbWay.ErrorCode,
                                Status = resultrefMbWay.Status,
                                Message = string.IsNullOrEmpty(tempMessage) ? resultrefMbWay.ErrorMessage : tempMessage,
                                MerchantTransactionId = resultrefMbWay.MerchantTransactionId,
                                Amount = resultrefMbWay.Amount,
                                Entity = resultrefMbWay.Entity,
                                Reference = resultrefMbWay.Reference,
                                DueDate = refLmtDtTm
                            };
                        }

                        stopwatch.Stop();
                        Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds}ms");

                        break;

                    case CommonEnums.EnumPayments.ChipPin:
                        var paymentChip = paymentMethods?.Where(x => x.IdPaymentMethod == CommonEnums.EnumPayments.ChipPin).ToList();

                        result = new PaymentOutput()
                        {
                            Message = paymentChip?.FirstOrDefault().Message,
                            Code = StatusCodes.Status200OK.ToString()
                        };

                        stopwatch.Stop();
                        Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds}ms");

                        break;

                    case CommonEnums.EnumPayments.Agente:
                        var paymentAgent = paymentMethods?.Where(x => x.IdPaymentMethod == CommonEnums.EnumPayments.Agente).ToList();

                        if (paymentAgent.Any())
                        {
                            result = new PaymentOutput()
                            {
                                Message = paymentAgent?.FirstOrDefault()?.Message,
                                Code = StatusCodes.Status200OK.ToString()
                            };
                        }
                        else {
                            result = new PaymentOutput()
                            {
                                Message = "Forma de pagamento não disponível",
                                Code = StatusCodes.Status400BadRequest.ToString()
                            };
                        }

                        stopwatch.Stop();
                        Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds}ms");

                        break;

                    default:
                        break;
                }
                //Make Param
                return result;
            }
            catch (AggregateException e)
            {
                Log.Error(e, String.Empty);
                throw new ProcessErrorException(
                                                     StatusCodes.Status400BadRequest.ToString(),
                                                     "Erros", new List<ProcessErrorException.InnerError>
                                                     {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorType = ((INS.PT.WebAPI.Model.ProcessErrorException)e.InnerException).InnerErrors.FirstOrDefault().ErrorType,
                                       ErrorCode = ((INS.PT.WebAPI.Model.ProcessErrorException)e.InnerException).InnerErrors.FirstOrDefault().ErrorCode,
                                       ErrorMessage = ((INS.PT.WebAPI.Model.ProcessErrorException)e.InnerException).InnerErrors.FirstOrDefault().ErrorMessage
                                   }
                                                     });
            }
            catch (Exception e)
            {
                Log.Error(e, String.Empty);
                throw;
            }
        }

        public void ValidInputPayment(PaymentsInput parameters)
        {
            //Logging Default
            Log.Debug($"Request: {parameters}");
            var stopwatch = new Stopwatch();
            stopwatch.Start();

            if (parameters == null)
            {
                throw new ProcessErrorException(
                      StatusCodes.Status406NotAcceptable.ToString(),
                      "Erros", new List<ProcessErrorException.InnerError>
                      {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status406NotAcceptable.ToString(),
                                       ErrorMessage = "Errors"
                                   }
                      });
            }

            if (parameters?.IdPaymentMethod == null)
            {
                throw new ProcessErrorException(
                      StatusCodes.Status406NotAcceptable.ToString(),
                      "Erros", new List<ProcessErrorException.InnerError>
                      {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status406NotAcceptable.ToString(),
                                       ErrorMessage = "Errors"
                                   }
                      });
            }

            switch (parameters.IdPaymentMethod)
            {
                case CommonEnums.EnumPayments.MbWay:
                case CommonEnums.EnumPayments.MbReference:
                    if (string.IsNullOrEmpty(parameters.ReceiptNumber))
                    {
                        throw new ProcessErrorException(
                                                StatusCodes.Status406NotAcceptable.ToString(),
                                                "Erros", new List<ProcessErrorException.InnerError>
                                                {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status406NotAcceptable.ToString(),
                                       ErrorMessage = "Errors"
                                   }
                                                });
                    }

                    stopwatch.Stop();
                    Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds}ms");

                    break;
                default:
                    break;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.ServiceModel;
using System.Threading.Tasks;
using AutoMapper;
using Canonical.ServiceReference;
using INS.PT.WebAPI.Constants;
using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Life20;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Collections;
using INS.PT.WebAPI.Models.Input.v1;
using INS.PT.WebAPI.Models.Output;
using INS.PT.WebAPI.Models.Output.v1;
using INS.PT.WebAPI.v1;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using Serilog;

namespace INS.PT.WebAPI.Repository.v1
{
    /// <summary>
    /// Reference data repository.
    /// </summary>
    public class PaymentMethodsRepository : BaseRepository, IPaymentMethods
    {

        #region Route Constants
        private const string GetProcessDetailMethod = "v1/Life2Front/GetProcessDetail";
        #endregion


        private readonly IPoliciesService _canonicalService;
        private readonly IConfiguration _configuration;
        private readonly IHttpClientRepository httpClientRepository;
        private readonly IMapper mapper;
        private readonly ICollectionsRepository _collectionsRepository;
        private readonly IConfiguration configuration;


        public PaymentMethodsRepository(IConfiguration _configuration, IHttpClientRepository _httpClientRepository, IRepositoryInvoker _repositoryInvoker, ApplicationSettings _applicationSettings, IMapper _mapper, HttpRequest _request, ICollectionsRepository collectionsRepository)
       : base(_configuration, _applicationSettings, _repositoryInvoker, _request)
        {
            mapper = _mapper;
            httpClientRepository = _httpClientRepository;
            _canonicalService = CreateCanonicalClient();
            _collectionsRepository = collectionsRepository ?? throw new ArgumentNullException(nameof(collectionsRepository));
        }

        /// <summary>
        /// Posts the receipts detail wasp.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        public async Task<ReceiptDetailWaspOutput> PostReceiptsDetailWaspAsync(ReceiptDetailWaspInput requestObject)
        {
            return await _collectionsRepository.ReceiptsDetail(requestObject);
        }


        /// <summary>
        /// Commons the portifolio asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <param name="validateChannel">The validate channel.</param>
        /// <param name="requestValue">The request value.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException"></exception>
        /// <exception cref="List{ProcessErrorException.InnerError}"></exception>
        /// <exception cref="ProcessErrorException.InnerError"></exception>
        public async Task<PaymentMethodsOutput> CommonPortifolioAsync(PaymentMethodsInput parameters, StringValues validateChannel, HttpRequest requestValue)
        {
            //Logging Default
            Log.Debug($" CommonPortifolioAsync Request: {JsonConvert.SerializeObject(parameters)}");

            var stopwatch = new Stopwatch();
            stopwatch.Start();

            #region CommonPortfolio

            var keyHeaderSetting = applicationSettings.PaymentMethodOption.KeyHeaderPemissionOnAgent;
            var keyHeader = validateChannel.FirstOrDefault();

            //Call CommonPortfolio
            var resultDataPortfolio = await ReadCanonicalInformationAsync(parameters);
            List<PaymentMethod> paymentMethods = applicationSettings.PaymentMethodOption.PaymentMethods.Where(opt => opt.IsAvailable).ToList();

            List<PaymentMethod> resultList = new List<PaymentMethod>();
            PaymentMethodsOutput resultDynamics = null;

            if (resultDataPortfolio?.getPolicyDetailWASPResult?.outputMessage == "OK")
            {
                foreach (var item in paymentMethods)
                {
                    if (item.IdPaymentMethod == Constants.CommonEnums.EnumPayments.MbWay)
                    {
                        item.Phone = (resultDataPortfolio.getPolicyDetailWASPResult?.Detail?.HolderPerson).Contacts?.FirstOrDefault(opt => opt.Type == CommonEnumsContactType.Mobile)?.Value;
                    }
                    else if (item.IdPaymentMethod == Constants.CommonEnums.EnumPayments.Agente)
                    {
                        if (string.IsNullOrEmpty(keyHeader) || (keyHeader?.ToString().ToUpper().Trim() == keyHeaderSetting?.ToString().ToUpper().Trim()))
                        {
                            item.IsAvailable = false;
                        }
                        else
                        {
                            item.IsAvailable = !string.IsNullOrEmpty(resultDataPortfolio.getPolicyDetailWASPResult?.Detail?.CollectionAgent?.Code);
                        }
                    }

                    if (item.IsAvailable)
                    {
                        resultList.Add(item);
                    }
                }

                resultDynamics = new PaymentMethodsOutput
                {
                    IdQuote = parameters.IdQuote,
                    ResultList = resultList
                };
            }
            else
            {
                throw new ProcessErrorException(
                        StatusCodes.Status400BadRequest.ToString(),
                        resultDataPortfolio?.getPolicyDetailWASPResult?.outputMessage, new List<ProcessErrorException.InnerError>
                        {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode =  StatusCodes.Status400BadRequest.ToString(),
                                       ErrorMessage = resultDataPortfolio?.getPolicyDetailWASPResult?.outputMessage
                                   }
                        });
            }


            stopwatch.Stop();
            Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds}ms");

            return resultDynamics;

            #endregion
        }


        /// <summary>
        /// Life20s the specified parameters.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <param name="validateChannel">The validate channel.</param>
        /// <param name="requestValue">The request value.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException"></exception>
        /// <exception cref="List{ProcessErrorException.InnerError}"></exception>
        /// <exception cref="ProcessErrorException.InnerError"></exception>
        public async Task<PaymentMethodsOutput> Life20(PaymentMethodsInput parameters, StringValues validateChannel, HttpRequest requestValue)
        {
            //Logging Default
            Log.Debug($"Life20 Request: {requestValue}");

            var stopwatch = new Stopwatch();
            stopwatch.Start();

            #region Life20

            var keyHeaderSetting = applicationSettings.PaymentMethodOption.KeyHeaderPemissionOnAgent;
            var keyHeader = validateChannel.FirstOrDefault();

            GetProcessDetailRequest inputlife20 = new GetProcessDetailRequest()
            {
                Input = new GetProcessDetailInput()
                {
                    Process_id = Convert.ToInt32(parameters.IdQuote)
                }
            };

            GetProcessDetailResponse resultDataLife20 = await ReadCanonicalInformationlife20Async(inputlife20);
            List<PaymentMethod> paymentMethodsLife20 = applicationSettings.PaymentMethodOption.PaymentMethods.Where(opt => opt.IsAvailable).ToList();

            List<PaymentMethod> resultList = new List<PaymentMethod>();
            PaymentMethodsOutput resultLife20 = null;

            //receiptNumber

            if (resultDataLife20.Output.Error_message == "OK")
            {
                foreach (var item in paymentMethodsLife20)
                {
                    if (item.IdPaymentMethod == Constants.CommonEnums.EnumPayments.MbWay)
                    {
                        item.Phone = resultDataLife20.Output.Taker.Phone;
                    }
                    else if (item.IdPaymentMethod == Constants.CommonEnums.EnumPayments.Agente)
                    {
                        if (string.IsNullOrEmpty(keyHeader) || (keyHeader?.ToString() == "Life2.0"))
                        {
                            item.IsAvailable = false;
                        }
                        else
                        {
                            item.IsAvailable = !string.IsNullOrEmpty(resultDataLife20.Output?.Process?.Agent_id.ToString());
                        }
                    }

                    if (item.IsAvailable)
                    {
                        resultList.Add(item);
                    }
                }

                //undone mock data
                resultLife20 = new PaymentMethodsOutput
                {
                    IdQuote = parameters.IdQuote,
                    ResultList = resultList
                };

            }
            else
            {
                throw new ProcessErrorException(
                        StatusCodes.Status400BadRequest.ToString(),
                        resultDataLife20.Output.Error_message, new List<ProcessErrorException.InnerError>
                        {
                                       new ProcessErrorException.InnerError
                                       {
                                           ErrorCode =  StatusCodes.Status400BadRequest.ToString(),
                                           ErrorMessage = resultDataLife20.Output.Error_message
                                       }
                        });
            }

            stopwatch.Stop();
            Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds}ms");


            return resultLife20;
            #endregion
        }


        /// <summary>
        /// Creates the canonical client.
        /// </summary>
        /// <returns></returns>
        public PoliciesServiceClient CreateCanonicalClient()
        {
            //Logging Default
            Log.Debug($"CreateCanonicalClient Request: ");

            var stopwatch = new Stopwatch();
            stopwatch.Start();

            // read enpoint address
            var address = new EndpointAddress(applicationSettings.CanonicalService.CanonicalUrl);

            // commom binding
            var binding = new BasicHttpBinding
            {
                MaxBufferSize = int.MaxValue,
                ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max,
                MaxReceivedMessageSize = int.MaxValue,
                AllowCookies = true
            };

            // check if it is http or https
            if (string.Compare(address.Uri.Scheme, "https", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                binding.Security.Mode = BasicHttpSecurityMode.Transport;
            }


            stopwatch.Stop();
            Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds}ms");

            // return proxy
            return new PoliciesServiceClient(binding, address);
        }

        /// <summary>
        /// Reads the canonical informationlife20 asynchronous.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        public async Task<GetProcessDetailResponse> ReadCanonicalInformationlife20Async(GetProcessDetailRequest requestObject)
        {
            //Logging Default
            Log.Debug($" ReadCanonicalInformationlife20Async Request: {requestObject}");

           var stopwatch = new Stopwatch();
            stopwatch.Start();

            HttpRequestElement requestElement = new HttpRequestElement
            {
                ApiService = applicationSettings.BrokerServicesNameSpaces.Life2Front,
                ApiMethod = GetProcessDetailMethod,
                QueryString = request.QueryString,
                Method = CommonEnums.HttpRequestVerb.POST,
                RequestObject = requestObject
            };

            Task<GetProcessDetailResponse> output = repositoryInvoker
                .GenericInvokerAsync<GetProcessDetailResponse, GetProcessDetailResponse>(requestElement);

            stopwatch.Stop();
            Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds}ms");

            return await output;

        }


        /// <summary>
        /// Method to read list of payment methods.
        /// </summary>
        /// <param name="requestValue"></param>
        /// <param name="parameters">Parameters to retrive the data.</param>
        /// <returns>
        /// Object with results.
        /// </returns>
        public async Task<PaymentMethodsOutput> ReadDataAsync(HttpRequest requestValue, PaymentMethodsInput parameters)
        {
            //Logging Default
            Log.Debug($"ReadDataAsync Request: {parameters}");

            var stopwatch = new Stopwatch();
            stopwatch.Start();


            #region Geral Header
            StringValues validateChannel;
            requestValue?.Headers.TryGetValue("Channel", out validateChannel);

            var keyHeaderSetting = applicationSettings.PaymentMethodOption.KeyHeaderPemissionOnAgent;
            var keyHeader = validateChannel.FirstOrDefault();

            #endregion

            if (keyHeader == Constants.CommonEnums.EnumHeader.DynamicForms.ToString() || keyHeader == null)
            {
                stopwatch.Stop();
                Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds}ms");

                return await CommonPortifolioAsync(parameters, validateChannel, requestValue);
            }
            else
            {
                stopwatch.Stop();
                Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds}ms");

                return await Life20(parameters, validateChannel, requestValue);
            }
        }

        /// <summary>
        /// Reads the canonical information asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        public async Task<getPolicyDetailWASPResponse> ReadCanonicalInformationAsync(PaymentMethodsInput parameters)
        {
            //Logging Default
            Log.Debug($"Request: {parameters}");

            var stopwatch = new Stopwatch();
            stopwatch.Start();

            getPolicyDetailWASPResponse canonicalResponse = null;
            stopwatch.Start();

            try
            {
                // build request for canonical
                var canonicalRequest = new getPolicyDetailWASPRequest
                {
                    AxisValues = new AxisValues
                    {
                        Solution = applicationSettings.CanonicalService.BrokerSolution,
                        User = applicationSettings.CanonicalService.BrokerUser
                    },
                    inputData = new GetPolicyDetailWASPInputData()
                    {
                        PolicyNumber = parameters.IdQuote,
                        ClearCache = false,
                        GetMockup = false,
                        SolutionChannel = applicationSettings.CanonicalService.BrokerSolution
                    }
                };
                Log.Debug($"Call canonical service request: {JsonConvert.SerializeObject(canonicalRequest)}");

                // make call to service
                canonicalResponse = await _canonicalService.getPolicyDetailWASPAsync(canonicalRequest);

                stopwatch.Stop();
                Log.Debug($"Response Time: {stopwatch.ElapsedMilliseconds}ms");

                // Log results
                Log.Debug($"Call canonical service response: {JsonConvert.SerializeObject(canonicalResponse)}");
            }
            catch (Exception e)
            {
                Log.Error($"Error calling canonical service: {e}");
            }
            return canonicalResponse;
        }
    }
}

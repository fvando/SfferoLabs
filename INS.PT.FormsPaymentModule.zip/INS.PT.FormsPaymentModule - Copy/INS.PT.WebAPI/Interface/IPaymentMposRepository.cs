﻿using INS.PT.WebAPI.Models.Collections;
using INS.PT.WebAPI.Models.DTO;
using INS.PT.WebAPI.Models.FinancialMPOS;
using INS.PT.WebAPI.Models.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// IPaymentMposRepository
    /// </summary>
    public interface IPaymentMposRepository
    {
        /// <summary>
        /// References the mb payment asynchronous.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        Task<RefMBPaymentOutputDTO> RefMBPaymentAsync(RefMBPaymentInputDTO requestObject);
        /// <summary>
        /// Mbs the way payment asynchronous.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        Task<MBWayPaymentOutputDTO> MBWayPaymentAsync(MBWayPaymentInputDTO requestObject);
    }
}

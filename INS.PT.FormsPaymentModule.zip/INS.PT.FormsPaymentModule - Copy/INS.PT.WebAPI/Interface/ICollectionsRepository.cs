﻿using INS.PT.WebAPI.Mappings;
using INS.PT.WebAPI.Models.Collections;
using INS.PT.WebAPI.Models.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// ICollectionsRepository
    /// </summary>
    public interface ICollectionsRepository
    {
        /// <summary>
        /// Receiptses the detail.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        Task<ReceiptDetailWaspOutput> ReceiptsDetail(ReceiptDetailWaspInput requestObject);
        /// <summary>
        /// Chargeds the specified request object.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        Task<ChargedReceiptLineDetailResponseWaspOuptut> Charged(string requestObject);

        /// <summary>
        /// Validates the charge receipts.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        Task<ValidateReceiptLineDetailResponseWaspOutput> ValidateChargeReceipts(ValidateReceiptsWaspInput requestObject);

        //ZageasLifeGetProposalDTO
        //ZeAiaProposalDTO
        //ZageasLifeGetProposalResponse1DTO
        //ZeAiaProposalDTO
        //ZfscdCodigosErroLinhaDTO

        //LifeProposalOutput-->ZageasLifeGetProposalResponse1DTO
        //LifeProposalInput --> ZageasLifeGetProposalDTO
        //LifeProposalElement --> ZeAiaProposalDTO
        //LifeProposalError --> ZfscdCodigosErroLinhaDTO
        Task<LifeProposalOutput> GetLifeProposalAsync(LifeProposalInput requestObject);


    }
}

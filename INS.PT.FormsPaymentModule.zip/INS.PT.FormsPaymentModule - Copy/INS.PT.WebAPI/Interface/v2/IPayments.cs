﻿using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Models.DuckCreek;
using INS.PT.WebAPI.Models.Input.v2;
using INS.PT.WebAPI.Models.Output;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface.v2
{
    /// <summary>
    /// Interface register payments requests.
    /// </summary>
    public interface IPayments : IScopedRepository
    {
        /// <summary>
        /// Method to register payment request.
        /// </summary>
        /// <param name="parameters">Parameters register payment.</param>
        /// <returns>Object with results.</returns>
        Task<PaymentOutput> MakePaymentAsync(HttpRequest requestValue, PaymentsInput parameters);
        /// <summary>
        /// Valids the input payment.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        void ValidInputPayment(PaymentsInput parameters);
        /// <summary>
        /// Gets the entity payment.
        /// </summary>
        /// <param name="company">The company.</param>
        /// <returns></returns>
        string GetEntityPayment(string company);

        Task<PaymentOutput> SharePaymentAsync(HttpRequest requestValue, SharePaymentInfo requestPaymentInfo);

        Task<object> ReceiptsChangeNotifcation(string receiptNumber, ReceiptsChangeNotifcationInput invoiceInput);

        }
}

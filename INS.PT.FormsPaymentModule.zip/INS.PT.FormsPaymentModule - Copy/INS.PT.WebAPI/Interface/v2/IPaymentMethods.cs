﻿using Canonical.ServiceReference;
using INS.PT.WebAPI.Mappings;
using INS.PT.WebAPI.Models.Collections;
using INS.PT.WebAPI.Models.Input.v2;
using INS.PT.WebAPI.Models.Output.v2;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.v2
{
    /// <summary>
    /// Interface for list payment methods.
    /// </summary>
    public interface IPaymentMethods : IScopedRepository
    {
        /// <summary>
        /// Method to read list of payment methods.
        /// </summary>
        /// <param name="parameters">Parameters to retrive the data.</param>
        /// <returns>Object with results.</returns>
        Task<PaymentMethodsOutput> GetPaymentsAsync(HttpRequest requestValue, PaymentMethodsInput parameters);
        /// <summary>
        /// Creates the canonical client.
        /// </summary>
        /// <returns></returns>
        PoliciesServiceClient CreateCanonicalClient();

        /// <summary>
        /// Reads the canonical information asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        Task <getPolicyDetailWASPResponse> ReadCanonicalInformationAsync(PaymentMethodsInput parameters);

        /// <summary>
        /// Validates the charge receipts asynchronous.
        /// </summary>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        Task<ValidateReceiptLineDetailResponseWaspOutput> ValidateChargeReceiptsAsync(ValidateReceiptsWaspInput requestObject);

    }
}

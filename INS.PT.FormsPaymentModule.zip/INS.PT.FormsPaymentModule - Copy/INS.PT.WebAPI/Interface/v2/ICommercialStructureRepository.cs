﻿using INS.PT.WebAPI.Models.AgentsPortal.CommercialStructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface.v2
{
    /// <summary>
    /// ICommercialStructureRepository
    /// </summary>
    public interface ICommercialStructureRepository
    {
        /// <summary>
        /// Gets the agent classifications.
        /// </summary>
        /// <param name="idAgent">The identifier agent.</param>
        /// <returns></returns>
        Task<AgentClassificationWaspOutput> GetAgentClassifications(string idAgent);
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Model;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
 


namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// IGetDocRepository
    /// </summary>
    public interface IGetEntityPaymentRepository
    {
        OracleDynamicParameters ValidateParams(string parameters);
        string SubmitStoreProcedure(string OracleExec, string OracleParaCompany);
    }
}

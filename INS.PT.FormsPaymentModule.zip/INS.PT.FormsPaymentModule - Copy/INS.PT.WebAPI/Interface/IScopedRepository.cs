﻿namespace INS.PT.WebAPI
{
    /// <summary>
    /// Interface to be implemented by the interfaces that need to be loaded in startup
    /// </summary>
    public interface IScopedRepository
    {
    }
}

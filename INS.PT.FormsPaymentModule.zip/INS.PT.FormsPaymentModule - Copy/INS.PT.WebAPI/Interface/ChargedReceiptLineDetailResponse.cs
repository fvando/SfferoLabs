﻿using INS.PT.WebAPI.Models.Collections;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Interface
{
    public class ChargedReceiptLineDetailResponse
    {
        public List<ChargedReceiptDetail> PcReceipts { get; set; }
    }

    public class ChargedReceiptDetail : ZfscdPcRecibosLinha
    {
        public List<ChargedStatusDetail> Status { get; set; }
    }

    public class ChargedStatusDetail
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCodeTxt { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCode { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public bool Situation { get; set; } = true;
    }
}
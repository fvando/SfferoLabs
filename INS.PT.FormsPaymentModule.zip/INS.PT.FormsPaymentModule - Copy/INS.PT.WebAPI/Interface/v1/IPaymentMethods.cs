﻿using Canonical.ServiceReference;
using INS.PT.WebAPI.Models.Input.v1;
using INS.PT.WebAPI.Models.Output.v1;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.v1
{
    /// <summary>
    /// Interface for list payment methods.
    /// </summary>
    public interface IPaymentMethods : IScopedRepository
    {
        /// <summary>
        /// Method to read list of payment methods.
        /// </summary>
        /// <param name="parameters">Parameters to retrive the data.</param>
        /// <returns>Object with results.</returns>
        Task<PaymentMethodsOutput> ReadDataAsync(HttpRequest requestValue, PaymentMethodsInput parameters);
        /// <summary>
        /// Creates the canonical client.
        /// </summary>
        /// <returns></returns>
        PoliciesServiceClient CreateCanonicalClient();

        /// <summary>
        /// Reads the canonical information asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        Task <getPolicyDetailWASPResponse> ReadCanonicalInformationAsync(PaymentMethodsInput parameters);

    }
}

﻿using INS.PT.WebAPI.Models.Input.v1;
using INS.PT.WebAPI.Models.Output;
using INS.PT.WebAPI.Models.Output.v1;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface.v1
{
    /// <summary>
    /// Interface register payments requests.
    /// </summary>
    public interface IPayments : IScopedRepository
    {
        /// <summary>
        /// Method to register payment request.
        /// </summary>
        /// <param name="parameters">Parameters register payment.</param>
        /// <returns>Object with results.</returns>
        Task<PaymentOutput> MakePaymentAsync(PaymentsInput parameters);
        void ValidInputPayment(PaymentsInput parameters);
        string GetEntityPayment(string company);

        
    }
}

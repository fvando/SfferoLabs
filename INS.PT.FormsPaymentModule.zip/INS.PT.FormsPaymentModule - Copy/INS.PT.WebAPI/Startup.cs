﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.IO;
using System.Reflection;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using INS.PT.WebAPI.Middleware;
using System.Linq;
using Ins.PT.WebAPI;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Repository;
using INS.PT.WebAPI.Helpers;
using Microsoft.AspNetCore.Http;
using AutoMapper;
using Microsoft.OpenApi.Models;
using INS.PT.WebAPI.Filters;
using Microsoft.Extensions.Hosting;
using INS.PT.CommonLibrary.Redis.Models;
using INS.PT.CommonLibrary.Redis.Interfaces;
using INS.PT.CommonLibrary.Redis.Helpers;
using Serilog;


namespace INS.PT.WebAPI
{
    /// <summary>
    /// Startup
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// Startup
        /// </summary>
        /// <param name="configuration"></param>
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        /// <summary>
        /// ConfigureServices
        /// </summary>
        /// <param name="services"></param>
        public void ConfigureServices(IServiceCollection services)
        {
            // Check health services, Necessary core 2.2
            services.AddHealthChecks();

            // SeriLog configuration
            var configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile(Configuration["Logging:LogConfigFile"])
                .Build();

            // Start SeriLog
            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(configuration)
                .CreateLogger();



            services.AddMvc()
            .AddNewtonsoftJson(options => {
                options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
                options.SerializerSettings.ContractResolver = new Newtonsoft.Json.Serialization.DefaultContractResolver();
            })
             .AddXmlSerializerFormatters()
             .AddXmlDataContractSerializerFormatters()
             .AddJsonOptions(jsonOptions =>
             {
                 jsonOptions.JsonSerializerOptions.PropertyNamingPolicy = null;
                 jsonOptions.JsonSerializerOptions.IgnoreNullValues = true;
             });


            services.AddHttpContextAccessor();

            services.AddScoped(sp => sp.GetRequiredService<IHttpContextAccessor>().HttpContext.Request);
            services.AddScoped(sp => sp.GetRequiredService<IHttpContextAccessor>().HttpContext.Response);

            // App Settings
            ApplicationSettings applicationSettings = new ApplicationSettings();
            Configuration.Bind("ApplicationSettings", applicationSettings);
            services.AddSingleton(typeof(ApplicationSettings), (serviceProvider) => applicationSettings);

            // Redis Settings
            services.Configure<RedisSettings>(Configuration.GetSection("ApplicationSettings").GetSection("RedisSettings"));

            SetupMappings(services);

            services.AddScoped<IRepositoryInvoker, RepositoryInvoker>();
            services.AddScoped<ICollectionsRepository, CollectionsRepository>();
            services.AddScoped<IHttpClientRepository, HttpClientRepository>();
            services.AddScoped<IPaymentMposRepository, PaymentMposRepository>();
            services.AddSingleton<IDbconnectioncs>(new Dbconnectioncs(Configuration));
            services.AddScoped<IStatesRepository, StatesRepository>();
            services.AddScoped<IGetEntityPaymentRepository, GetEntityPaymentRepository>();
            services.AddScoped<INS.PT.WebAPI.Interface.v2.ICommercialStructureRepository, CommercialStructureRepository>();

            services.AddOptions();
            // Redis Singleton to access library that call Redis Server
            services.AddSingleton<IRedisManager, RedisManagerService>();

            SetupRepositories(services);

            // Get Application Settings
            ApplicationSettings.SetSettings(Configuration);
            services.AddMvc();

            // Get Application Settings
            services.Configure<ApplicationSettings>(Configuration.GetSection("ApplicationSettings"));

          

            services.AddSwaggerGen(swagger =>
            {
                swagger.SwaggerDoc(SwaggerConfiguration.DocNameV1,
                     new OpenApiInfo
                     {
                         Title = SwaggerConfiguration.DocInfoTitle,
                         Version = SwaggerConfiguration.DocInfoVersion,
                         Description = SwaggerConfiguration.DocInfoDescription
                     }
                );

                //use fully qualified object names
                swagger.CustomSchemaIds(x => x.FullName);

                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                swagger.IncludeXmlComments(xmlPath); //comments and sample
                swagger.DescribeAllEnumsAsStrings();

             
                swagger.SchemaFilter<ArraySchemaFilter>();
            });


            /* 3.1 
             The Accept header is ignored.
             The content is returned in JSON, unless otherwise configured.
                */
            services.AddControllers(options =>
            {
                options.RespectBrowserAcceptHeader = true; // Browsers and content negotiation - false by default
            })
            .AddNewtonsoftJson();

            // Auto Mapper Configurations
            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new Mappings.AutoMapperProfileConfiguration());
                mc.AddProfile(new Mappings.CollectionsProfile());
                mc.AddProfile(new Mappings.CommercialStructureProfile());
            });
            services.AddSingleton(mappingConfig.CreateMapper());
 
            services.AddHttpClient();
        }

        /// <summary>
        /// Setups the mappings.
        /// </summary>
        /// <param name="services">The services.</param>
        public static void SetupMappings(IServiceCollection services)
        {
            var currentAssembly = typeof(Startup).Assembly;

            // setup mappings for Dapper
            var allModels = AppDomain.CurrentDomain.GetAssemblies()
                .SelectMany(x => x.GetTypes());

            var dapperMappings = allModels
                .Where(x => typeof(IMapped).IsAssignableFrom(x)
                        && !x.IsInterface && !x.IsAbstract && x.Assembly == currentAssembly)
                .Select(x => Activator.CreateInstance(x) as IMapped);

            foreach (var model in dapperMappings)
            {
                model.CreateMapping();
            }

            // Auto Mapper Configurations
            var autoMapperMappings = allModels
                .Where(x => typeof(AutoMapper.Profile).IsAssignableFrom(x)
                        && !x.IsInterface && !x.IsAbstract && x.Assembly == currentAssembly);

            var mappingConfig = new AutoMapper.MapperConfiguration(mc =>
            {
                foreach (var profile in autoMapperMappings)
                {
                    mc.AddProfile(profile);
                }
            });

            services.AddSingleton(mappingConfig.CreateMapper());
        }

        /// <summary>
        /// Setups the repositories.
        /// </summary>
        /// <param name="services">The services.</param>
        public static void SetupRepositories(IServiceCollection services)
        {
            var assemblies = AppDomain.CurrentDomain.GetAssemblies();

            foreach (var repoInterface in
                assemblies.SelectMany(x => x.GetTypes())
                .Where(x => typeof(IScopedRepository).IsAssignableFrom(x)))
            {
                foreach (var repo in
                    assemblies.SelectMany(x => x.GetTypes())
                    .Where(x => repoInterface.IsAssignableFrom(x) && !x.IsInterface && !x.IsAbstract))
                {
                    services.AddScoped(repoInterface, repo);
                }
            }
        }

        /// <summary>
        /// Configure
        /// </summary>
        /// <param name="app">Application builder interface</param>
        /// <param name="env"></param>
        /// <param name="LoggerFactory"></param>
        /// <param name="configuration"></param>
        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public static void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory LoggerFactory, IConfiguration configuration)
        {

            //add health server
            app.UseHealthChecks(new Microsoft.AspNetCore.Http.PathString("/health"));

            // Enable middleware to serve generated Swagger as a JSON endpoint.
            app.UseSwagger();

            // Enable middleware to serve swagger-ui (HTML, JS, CSS, etc.), specifying the Swagger JSON endpoint.
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint(SwaggerConfiguration.EndpointUrl, SwaggerConfiguration.EndpointDescription);                
            });

            //Middleware correlationID 
            app.UseLogXCorrelationId();
            app.UseLogXRequestResponde();

            if (env.IsDevelopment())
            {
                // When the app runs in the Development environment:
                //   Use the Developer Exception Page to report app runtime errors.
                //   Use the Database Error Page to report database runtime errors.
                app.UseDeveloperExceptionPage();
         
            }
            else
            {
                // When the app doesn't run in the Development environment:
                //   Enable the Exception Handler Middleware to catch exceptions
                //     thrown in the following middlewares.
                //   Use the HTTP Strict Transport Security Protocol (HSTS)
                //     Middleware.
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }

            // Use HTTPS Redirection Middleware to redirect HTTP requests to HTTPS.
            app.UseHttpsRedirection();

   
            //migrate 2.2 to 3.1
            app.UseRouting();
            app.UseAuthorization();
            app.UseSwagger();

            // Use Cookie Policy Middleware to conform to EU General Data 
            // Protection Regulation (GDPR) regulations.
            app.UseCookiePolicy();

     
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint(SwaggerConfiguration.EndpointUrl, SwaggerConfiguration.EndpointDescription);
            });

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
 
        }
    }
}

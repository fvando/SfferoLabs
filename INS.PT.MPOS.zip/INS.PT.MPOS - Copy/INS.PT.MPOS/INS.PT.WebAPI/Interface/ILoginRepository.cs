﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Model.KpiSrv;
using static INS.PT.WebAPI.Model.Login;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// 
    /// </summary>
    public interface ILoginRepository
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="section"></param>
        /// <returns></returns>
        OutputLogin Submit(string section);
    }
}

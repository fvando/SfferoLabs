﻿// Copyright Ageas 2019 © - Integration Team

using System.Net.Http;
using System.Threading.Tasks;
using INS.PT.WebAPI.Data.v2;
using Microsoft.AspNetCore.Http;

namespace INS.PT.WebAPI.Interface.V2
{
    /// <summary>
    /// IHttpClientRepository
    /// </summary>
    public interface IHttpClientRepository
    {
        /// <summary>
        /// Processes the request asynchronous.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        Task<HttpResponseMessage> ProcessRequestAsync(HttpRequestElement request);

        /// <summary>
        /// Processes the request asynchronous.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="service">The service.</param>
        /// <param name="method">The method.</param>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        Task<HttpResponseMessage> ProcessRequestAsync(HttpRequest request, string service, string method, dynamic requestObject);

        /// <summary>
        /// Processes the request asynchronous.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="service">The service.</param>
        /// <param name="method">The method.</param>
        /// <param name="routeValue">The route value.</param>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        Task<HttpResponseMessage> ProcessRequestAsync(HttpRequest request, string service, string method, string routeValue, object requestObject = null);

        /// <summary>
        /// Processes the request asynchronous.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="service">The service.</param>
        /// <param name="method">The method.</param>
        /// <param name="routeValue">The route value.</param>
        /// <param name="directURL">The direct URL.</param>
        /// <param name="autenticationObj">The autentication object.</param>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        Task<HttpResponseMessage> ProcessRequestAsync(HttpRequest request, string service, string method, string routeValue, string directURL, string autenticationObj, object requestObject = null);

        /// <summary>
        /// Processes the request asynchronous.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <param name="service">The service.</param>
        /// <param name="method">The method.</param>
        /// <param name="routeValue">The route value.</param>
        /// <param name="namespaceValue">The namespace value.</param>
        /// <param name="requestObject">The request object.</param>
        /// <returns></returns>
        Task<HttpResponseMessage> ProcessRequestAsync(HttpRequest request, string service, string method, string routeValue, string namespaceValue, object requestObject = null);

        /// <summary>
        /// Processes the request element asynchronous.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        Task<HttpResponseMessage> ProcessRequestElementAsync(HttpRequestElement request);
    }
}

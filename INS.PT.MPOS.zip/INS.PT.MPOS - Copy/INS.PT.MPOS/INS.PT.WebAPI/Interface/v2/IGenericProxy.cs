﻿// Copyright Ageas 2019 © - Integration Team
 
namespace INS.PT.WebAPI.Interface.V2
{
    /// <summary>
    /// IGenericProxy
    /// </summary>
    public interface IGenericProxy
    {
    }
}

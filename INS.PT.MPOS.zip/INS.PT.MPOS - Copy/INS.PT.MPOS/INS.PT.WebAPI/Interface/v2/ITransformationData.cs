﻿// Copyright Ageas 2019 © - Integration Team

using ServiceSAPMPOS.v2;
using System.Threading.Tasks;


namespace INS.PT.WebAPI.Interface.V2
{
    /// <summary>
    /// ITransformationData
    /// </summary>
    public interface ITransformationData
    {
        /// <summary>
        /// Ins to kpi count asynchronous.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        Task<ZFscdMposCountV2Ws> InToKpiCountAsync(INS.PT.WebAPI.Model.Kpi.v2.InputKpi value);

        /// <summary>
        /// Ins to kpi asynchronous.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        Task<ZFscdMposKpisV2Ws> InToKpiAsync(INS.PT.WebAPI.Model.Kpi.v2.InputKpi value);

        /// <summary>
        /// Ins to search asynchronous.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        Task<ZFscdMposSearchV2Ws> InToSearchAsync(INS.PT.WebAPI.Model.SearchReceipt.v2.InputSearchReceipt value);

        /// <summary>
        /// Ins to receipt detail asynchronous.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        Task<ZFscdMposKpisReceiptV2Ws> InToReceiptDetailAsync(INS.PT.WebAPI.Model.ReceiptDetail.v2.InputReceiptDetail value);

        /// <summary>
        /// Ins to kpi detail asynchronous.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        Task<ServiceSAPMPOS.v2.ZFscdMposKpisDetailV2Ws> InToKpiDetailAsync(INS.PT.WebAPI.Model.SumClientReceipt.v2.InputSumClientReceipt value);

        /// <summary>
        /// Ins to kpis nfis asynchronous.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        Task<ServiceSAPMPOS.v2.ZFscdMposKpisNifsV2Ws> InToKpisNfisAsync(Model.ClientReceipts.v2.InputClientReceipts value);

        /// <summary>
        /// Ins to payment post asynchronous.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        Task<ServiceSAPMPOS.v2.ZFscdMposPostV2Ws> InToPaymentPostAsync(INS.PT.WebAPI.Model.PaymentPost.v2.InputPaymentPost value);

        /// <summary>
        /// Outs to kpi detail asynchronous.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.SumClientReceipt.v2.OutputSumClientReceipt> OutToKpiDetailAsync(ServiceSAPMPOS.v2.ZFscdMposKpisDetailV2WsResponse1 ResponseSAP);

        /// <summary>
        /// Outs to kpi asynchronous.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.Kpi.v2.OutPutKpi> OutToKpiAsync(ServiceSAPMPOS.v2.ZFscdMposKpisV2WsResponse1 ResponseSAP);

        /// <summary>
        /// Outs to search new asynchronous.
        /// </summary>
        /// <param name="InputSearchMatch">The input search match.</param>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.SearchReceipt.v2.OutPutSearchReceipt> OutToSearchNewAsync(string InputSearchMatch, ServiceSAPMPOS.v2.ZFscdMposSearchV2WsResponse1 ResponseSAP);

        /// <summary>
        /// Outs to receipt detail asynchronous.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.ReceiptDetail.v2.OutPutReceiptDetail> OutToReceiptDetailAsync(ServiceSAPMPOS.v2.ZFscdMposKpisReceiptV2WsResponse1 ResponseSAP);

        /// <summary>
        /// Outs to kpis nfis asynchronous.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        Task<Model.ClientReceipts.v2.OutPutClientReceipts> OutToKpisNfisAsync(ServiceSAPMPOS.v2.ZFscdMposKpisNifsV2WsResponse1 ResponseSAP);

        /// <summary>
        /// Outs to payment post asynchronous.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.PaymentPost.v2.OutPutPaymentPost> OutToPaymentPostAsync(ServiceSAPMPOS.v2.ZFscdMposPostV2WsResponse1 ResponseSAP);

    }
}

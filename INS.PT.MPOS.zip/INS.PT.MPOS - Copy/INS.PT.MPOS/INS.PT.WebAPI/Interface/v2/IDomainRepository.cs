﻿// Copyright Ageas 2019 © - Integration Team

using UserProfileManagementV2;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface.V2
{
    /// <summary>
    /// IDomainRepository
    /// </summary>
    public interface IDomainRepository
    {
        /// <summary>
        /// Gets the user details asyn.
        /// </summary>
        /// <param name="email">The email.</param>
        /// <returns></returns>
        Task<GetUserDetailsServiceWASPResponse> GetUserDetailsAsyn(string email);

    }
}

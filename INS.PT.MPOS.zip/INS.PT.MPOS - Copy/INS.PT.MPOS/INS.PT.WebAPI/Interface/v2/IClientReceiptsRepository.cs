﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Model.ClientReceipts;
using INS.PT.WebAPI.Model.ClientReceipts.v2;
using System.Threading.Tasks;


namespace INS.PT.WebAPI.Interface.V2
{
    /// <summary>
    /// IClientReceiptsRepository
    /// </summary>
    public interface IClientReceiptsRepository
    {
        /// <summary>
        /// Gets the client receipts asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        Task<OutPutClientReceipts> GetClientReceiptsAsync(InputClientReceipts parameters);
    }
}

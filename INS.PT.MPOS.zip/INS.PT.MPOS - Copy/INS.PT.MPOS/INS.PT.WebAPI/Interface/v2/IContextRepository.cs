﻿// Copyright Ageas 2019 © - Integration Team

using System.Threading.Tasks;
using INS.PT.WebAPI.Model.Context.v2;
using Microsoft.AspNetCore.Http;


namespace INS.PT.WebAPI.Interface.V2
{
    /// <summary>
    /// IContextRepository
    /// </summary>
    public interface IContextRepository
    {
        /// <summary>
        /// Gets the token validate asynchronous.
        /// </summary>
        /// <param name="requestValue">The request value.</param>
        /// <returns></returns>
        Task<bool> GetTokenValidateAsync(HttpRequest requestValue);
        /// <summary>
        /// Puts the lock user asynchronous.
        /// </summary>
        /// <param name="requestValue">The request value.</param>
        /// <param name="requestUserlock">The request userlock.</param>
        /// <returns></returns>
        Task<bool> PutLockUserAsync(HttpRequest requestValue, InputUserLock requestUserlock);

        /// <summary>
        /// Sends the email asynchronous.
        /// </summary>
        /// <param name="requestValue">The request value.</param>
        /// <param name="requestUserlock">The request userlock.</param>
        /// <returns></returns>
        Task<bool> SendEmailAsync(HttpRequest requestValue, InputUserLock requestUserlock);

        
    }
}

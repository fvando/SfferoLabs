﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Model.SumClientReceipt.v2;
using System.Threading.Tasks;


namespace INS.PT.WebAPI.Interface.V2
{
    /// <summary>
    /// ISumClientsReceiptsRepository
    /// </summary>
    public interface ISumClientsReceiptsRepository
    {
        /// <summary>
        /// Gets the kpi details asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        Task<OutputSumClientReceipt> GetKpiDetailsAsync(InputSumClientReceipt parameters);
    }
}

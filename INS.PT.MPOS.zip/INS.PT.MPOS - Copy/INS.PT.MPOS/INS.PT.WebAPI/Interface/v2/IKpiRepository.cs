﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Model.Kpi.v2;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface.V2
{
    /// <summary>
    /// IKpiRepository
    /// </summary>
    public interface IKpiRepository
    {
        /// <summary>
        /// Gets the kpi asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        Task<OutPutKpi> GetKpiAsync(InputKpi parameters);

        /// <summary>
        /// Gets the kpi all asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        Task<OutPutKpi> GetKpiAllAsync(InputKpi parameters);
    }
}

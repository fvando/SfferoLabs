﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Model.ReceiptDetail.v2;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface.V2
{
    /// <summary>
    /// IReceiptDetailsRepository
    /// </summary>
    public interface IReceiptDetailsRepository
    {
        /// <summary>
        /// Gets the clients receipts asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        Task<OutPutReceiptDetail> GetReceiptsDetailAsync(InputReceiptDetail parameters);
    }
}

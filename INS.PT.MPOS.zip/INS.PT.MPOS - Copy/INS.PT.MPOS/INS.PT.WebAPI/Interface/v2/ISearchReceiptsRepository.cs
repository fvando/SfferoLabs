﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Model.SearchReceipt.v2;
using System.Threading.Tasks;


namespace INS.PT.WebAPI.Interface.V2
{
    /// <summary>
    /// ISearchReceiptsRepository
    /// </summary>
    public interface ISearchReceiptsRepository
    {
        /// <summary>
        /// Gets the search receipts asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        Task<OutPutSearchReceipt> GetSearchReceiptsAsync(InputSearchReceipt parameters);
    }
}

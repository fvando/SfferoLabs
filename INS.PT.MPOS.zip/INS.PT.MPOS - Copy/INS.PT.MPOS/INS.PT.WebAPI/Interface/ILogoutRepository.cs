﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Model.KpiSrv;
using static INS.PT.WebAPI.Model.Login;
using static INS.PT.WebAPI.Model.Logout;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// 
    /// </summary>
    public interface ILogoutRepository
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="section"></param>
        /// <returns></returns>
        OutputLogout Submit(string section);
    }
}

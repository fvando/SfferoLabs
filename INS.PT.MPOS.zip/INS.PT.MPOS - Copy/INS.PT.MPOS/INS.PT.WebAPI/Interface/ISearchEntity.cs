﻿using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.Input;
using INS.PT.WebAPI.Models.Output;

namespace INS.PT.WebAPI
{
    /// <summary>
    /// Search entity repository interface.
    /// </summary>
    public interface ISearchEntity
    {
        /// <summary>
        /// Method to search an entity based on the search filters given in the parameters.
        /// </summary>
        /// <param name="parameters">Search filters to make the search.</param>
        /// <returns>Matched results.</returns>
        SearchEntityOutput SearchEntity(HeaderParameters headerParameters, SearchEntityInput parameters);
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Data.v1;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface.V1
{
    public interface IRepositoryInvoker
    {
        /// <summary>
        /// Generics the invoker asynchronous.
        /// </summary>
        /// <typeparam name="TWaspOutput">The type of the wasp output.</typeparam>
        /// <typeparam name="TDTOOutput">The type of the dto output.</typeparam>
        /// <param name="requestElement">The request element.</param>
        /// <returns></returns>
        Task<TWaspOutput> GenericInvokerAsync<TWaspOutput, TDTOOutput>(HttpRequestElement requestElement);
        /// <summary>
        /// Generics the invoker asynchronous.
        /// </summary>
        /// <typeparam name="TWaspInput">The type of the wasp input.</typeparam>
        /// <typeparam name="TWaspOutput">The type of the wasp output.</typeparam>
        /// <typeparam name="TDTOInput">The type of the dto input.</typeparam>
        /// <typeparam name="TDTOOutput">The type of the dto output.</typeparam>
        /// <param name="requestElement">The request element.</param>
        /// <returns></returns>
        Task<TWaspOutput> GenericInvokerAsync<TWaspInput, TWaspOutput, TDTOInput, TDTOOutput>(HttpRequestElement requestElement);

        /// <summary>
        /// Generics the invoker asynchronous.
        /// </summary>
        /// <typeparam name="TWaspInput">The type of the wasp input.</typeparam>
        /// <typeparam name="TWaspOutput">The type of the wasp output.</typeparam>
        /// <typeparam name="TDTOInput">The type of the dto input.</typeparam>
        /// <typeparam name="TDTOOutput">The type of the dto output.</typeparam>
        /// <param name="requestObject">The request object.</param>
        /// <param name="serviceNameSpace">The service name space.</param>
        /// <param name="methodName">Name of the method.</param>
        /// <param name="routeValue">The route value.</param>
        /// <returns></returns>
        Task<TWaspOutput> GenericInvokerAsync<TWaspInput, TWaspOutput, TDTOInput, TDTOOutput>(TWaspInput requestObject, string serviceNameSpace, string methodName, [Optional] string routeValue);

        /// <summary>
        /// Generics the get invoker asynchronous.
        /// </summary>
        /// <typeparam name="TWaspOutput">The type of the wasp output.</typeparam>
        /// <typeparam name="TDTOOutput">The type of the dto output.</typeparam>
        /// <param name="serviceNameSpace">The service name space.</param>
        /// <param name="methodName">Name of the method.</param>
        /// <param name="routeValue">The route value.</param>
        /// <returns></returns>
        Task<TWaspOutput> GenericInvokerAsync<TWaspOutput, TDTOOutput>(string serviceNameSpace, string methodName, [Optional] string routeValue);


      
    }
}

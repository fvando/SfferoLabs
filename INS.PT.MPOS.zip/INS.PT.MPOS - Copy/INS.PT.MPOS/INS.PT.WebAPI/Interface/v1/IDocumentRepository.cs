﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Model.v1;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface.V1
{
    /// <summary>
    /// IDocumentRepository
    /// </summary>
    public interface IDocumentRepository
    {
        /// <summary>
        /// Gets the PDF asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        Task<string> GetPDFAsync(DocInput parameters);
        /// <summary>
        /// Gets the document identifier asynchronous.
        /// </summary>
        /// <param name="inputData">The input data.</param>
        /// <returns></returns>
        Task<string> GetDocumentIdAsync(InputGetDoc inputData);
        /// <summary>
        /// Orchestrations the asynchronous.
        /// </summary>
        /// <param name="inputData">The input data.</param>
        /// <returns></returns>
        Task<OutputGetDoc> OrchestrationAsync(InputGetDoc inputData);

    }
}

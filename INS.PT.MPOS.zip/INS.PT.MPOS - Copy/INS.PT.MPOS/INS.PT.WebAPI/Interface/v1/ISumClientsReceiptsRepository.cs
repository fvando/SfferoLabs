﻿// Copyright Ageas 2019 © - Integration Team

using System.Threading.Tasks;


namespace INS.PT.WebAPI.Interface.V1
{
    /// <summary>
    /// ISumClientsReceiptsRepository
    /// </summary>
    public interface ISumClientsReceiptsRepository
    {
        /// <summary>
        /// Gets the kpi details asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.SumClientReceipt.v1.OutputSumClientReceipt> GetKpiDetailsAsync(INS.PT.WebAPI.Model.SumClientReceipt.v1.InputSumClientReceipt parameters);
    }
}

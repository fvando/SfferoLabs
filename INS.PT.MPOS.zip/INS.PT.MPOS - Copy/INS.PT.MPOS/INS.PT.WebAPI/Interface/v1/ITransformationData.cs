﻿// Copyright Ageas 2019 © - Integration Team

using ServiceSAPMPOS.v1;
using System.Threading.Tasks;


namespace INS.PT.WebAPI.Interface.V1
{
    /// <summary>
    /// ITransformationData
    /// </summary>
    public interface ITransformationData
    {
        /// <summary>
        /// Ins to kpi count asynchronous.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        Task<ZFscdMposCountV1Ws> InToKpiCountAsync(INS.PT.WebAPI.Model.Kpi.v1.InputKpi value);

        /// <summary>
        /// Ins to kpi asynchronous.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        Task<ZFscdMposKpisV1Ws> InToKpiAsync(INS.PT.WebAPI.Model.Kpi.v1.InputKpi value);

        /// <summary>
        /// Ins to search asynchronous.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        Task<ServiceSAPMPOS.v1.ZFscdMposSearchV1Ws> InToSearchAsync(INS.PT.WebAPI.Model.SearchReceipt.v1.InputSearchReceipt value);

        /// <summary>
        /// Ins to receipt detail asynchronous.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        Task<ServiceSAPMPOS.v1.ZFscdMposKpisReceiptV1Ws> InToReceiptDetailAsync(INS.PT.WebAPI.Model.ReceiptDetail.v1.InputReceiptDetail value);

        /// <summary>
        /// Ins to kpi detail asynchronous.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        Task<ServiceSAPMPOS.v1.ZFscdMposKpisDetailV1Ws> InToKpiDetailAsync(INS.PT.WebAPI.Model.SumClientReceipt.v1.InputSumClientReceipt value);

        /// <summary>
        /// Ins to kpis nfis asynchronous.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        Task<ServiceSAPMPOS.v1.ZFscdMposKpisNifsV1Ws> InToKpisNfisAsync(Model.ClientReceipts.v1.InputClientReceipts value);

        /// <summary>
        /// Ins to payment post asynchronous.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        Task<ServiceSAPMPOS.v1.ZFscdMposPostV1Ws> InToPaymentPostAsync(INS.PT.WebAPI.Model.PaymentPost.v1.InputPaymentPost value);

        /// <summary>
        /// Outs to kpi detail asynchronous.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.SumClientReceipt.v1.OutputSumClientReceipt> OutToKpiDetailAsync(ServiceSAPMPOS.v1.ZFscdMposKpisDetailV1WsResponse1 ResponseSAP);

        /// <summary>
        /// Outs to kpi asynchronous.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.Kpi.v1.OutPutKpi> OutToKpiAsync(ServiceSAPMPOS.v1.ZFscdMposKpisV1WsResponse1 ResponseSAP);

        /// <summary>
        /// Outs to search new asynchronous.
        /// </summary>
        /// <param name="InputSearchMatch">The input search match.</param>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.SearchReceipt.v1.OutPutSearchReceipt> OutToSearchNewAsync(string InputSearchMatch, ServiceSAPMPOS.v1.ZFscdMposSearchV1WsResponse1 ResponseSAP);

        /// <summary>
        /// Outs to receipt detail asynchronous.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.ReceiptDetail.v1.OutPutReceiptDetail> OutToReceiptDetailAsync(ServiceSAPMPOS.v1.ZFscdMposKpisReceiptV1WsResponse1 ResponseSAP);

        /// <summary>
        /// Outs to kpis nfis asynchronous.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        Task<Model.ClientReceipts.v1.OutPutClientReceipts> OutToKpisNfisAsync(ServiceSAPMPOS.v1.ZFscdMposKpisNifsV1WsResponse1 ResponseSAP);

        /// <summary>
        /// Outs to payment post asynchronous.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.PaymentPost.v1.OutPutPaymentPost> OutToPaymentPostAsync(ServiceSAPMPOS.v1.ZFscdMposPostV1WsResponse1 ResponseSAP);

    }
}

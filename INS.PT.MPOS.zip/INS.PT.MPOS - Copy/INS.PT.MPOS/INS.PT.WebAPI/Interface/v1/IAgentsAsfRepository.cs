﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.CommonLibrary.Redis.Models;
using INS.PT.WebAPI.Models.AgentsPortal.Agent.Elements;
using INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement;
using Microsoft.AspNetCore.Http;
using UserProfileManagementV2;
using System.Collections.Generic;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Model.v1.AgentsAsf;

namespace INS.PT.WebAPI.Interface.V1
{
    /// <summary>
    /// IAgentsAsfRepository
    /// </summary>
    public interface IAgentsAsfRepository
    {
        /// <summary>
        /// Gets the commercial structure asyn.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="code">The code.</param>
        /// <returns></returns>
        Task<List<CompanyCSElement>> GetCommercialStructureAsync(string type, string code);

        /// <summary>
        /// Gets the commercial structure by level.
        /// </summary>
        /// <param name="profileResultGetUserDetails">The profile result get user details.</param>
        /// <returns></returns>
        Task<List<CompanyCSElement>> GetCommercialStructureByLevelAsync(GetUserCommercialStructureWaspOutput profileResultGetUserDetails);

        /// <summary>
        /// Sets the context redis.
        /// </summary>
        /// <param name="token">The token.</param>
        /// <param name="commercialStructuriesbyLevel">The commercial structuriesby level.</param>
        /// <returns></returns>
        Task<RedisOutput<List<CompanyCSElement>>> SetContextRedisAsync(string token, List<CompanyCSElement> commercialStructuriesbyLevel);

        /// <summary>
        /// Sets the agent asf.
        /// </summary>
        /// <param name="commercialStructuriesbyLevel">The commercial structuriesby level.</param>
        /// <returns></returns>
        Task<OutputAgentsAsf> SetAgentAsfAsync(List<CompanyCSElement> commercialStructuriesbyLevel, GetUserCommercialStructureWaspOutput profileResultGetUserDetails);

        /// <summary>
        /// Orchestrations the asynchronous.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        Task<OutputAgentsAsf> OrchestrationAsync(HttpRequest request);
        
        /// <summary>
        /// Jsons the get users service wasp output asynchronous.
        /// </summary>
        /// <param name="email">The email.</param>
        /// <returns></returns>
        Task<GetUsersServiceWaspOutput> JsonGetUsersServiceWaspOutputAsync(string email);

        /// <summary>
        /// Jsons the toggle user lock service wasp asynchronous.
        /// </summary>
        /// <param name="email">The email.</param>
        /// <returns></returns>
        Task<WaspOutputData> JsonToggleUserLockServiceWASPAsync(string email);

        /// <summary>
        /// Clears the context redis asynchronous.
        /// </summary>
        /// <param name="token">The token.</param>
        /// <returns></returns>
        Task<bool> RemoveContextRedisAsync(string token);

        /// <summary>
        /// Gets the user commercial structure detail asynchronous.
        /// </summary>
        /// <param name="email">The email.</param>
        /// <returns></returns>
        Task<GetUserCommercialStructureWaspOutput> GetUserCommercialStructureDetailAsync(string email);

    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Model.Domain;
using INS.PT.WebAPI.Model.Domain.v1;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface.V1
{
    /// <summary>
    /// IStatesRepository
    /// </summary>
    public interface IStatesRepository
    {
        /// <summary>
        /// Gets the list entities asynchronous.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns></returns>
        Task<List<GlobalEntityMposInformationOutput>> GetListEntitiesAsync(GlobalEntityMposInformationInput entity);
    }
}

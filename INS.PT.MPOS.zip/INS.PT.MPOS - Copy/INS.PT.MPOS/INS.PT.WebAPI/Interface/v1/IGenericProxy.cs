﻿// Copyright Ageas 2019 © - Integration Team
 
namespace INS.PT.WebAPI.Interface.V1
{
    /// <summary>
    /// IGenericProxy
    /// </summary>
    public interface IGenericProxy
    {
    }
}

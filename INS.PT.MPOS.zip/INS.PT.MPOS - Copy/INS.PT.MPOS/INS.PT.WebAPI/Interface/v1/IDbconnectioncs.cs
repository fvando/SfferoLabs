﻿// Copyright Ageas 2019 © - Integration Team

using System.Data;

namespace INS.PT.WebAPI.V1
{
    /// <summary>
    /// Interface of a database connection.
    /// </summary>
    public interface IDbconnectioncs
    {
        /// <summary>
        /// Method to retrive a db connection.
        /// </summary>
        /// <returns>Connection.</returns>
        IDbConnection GetConnection();
    }
}

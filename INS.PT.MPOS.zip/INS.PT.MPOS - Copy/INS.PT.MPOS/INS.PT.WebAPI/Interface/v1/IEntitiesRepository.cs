﻿// Copyright Ageas 2019 © - Integration Team

using System.Collections.Generic;
using System.Threading.Tasks;
using INS.PT.WebAPI.Models.AgentsPortal.Agent.Elements;
using INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement;
using UserProfileManagementV2;

namespace INS.PT.WebAPI.Interface.V1
{
    /// <summary>
    /// IEntitiesRepository
    /// </summary>
    public interface IEntitiesRepository
    {
        /// <summary>
        /// Gets the commercial structure.
        /// </summary>
        /// <param name="type">The type.</param>
        /// <param name="code">The code.</param>
        /// <returns></returns>
        Task<List<CompanyCSElement>> GetCommercialStructure(string type, string code);

        /// <summary>
        /// Gets the users service wasp.
        /// </summary>
        /// <param name="email">The email.</param>
        /// <returns></returns>
        Task<GetUsersServiceWaspOutput> GetUsersServiceWASP(string email);

        /// <summary>
        /// Jsons the toggle user lock service wasp asynchronous.
        /// </summary>
        /// <param name="email">The email.</param>
        /// <returns></returns>
        Task<ToggleUserLockingOutputData> ToggleUserLockServiceWASPAsync(string email);

        /// <summary>
        /// Gets the commercial structure agents search by class.
        /// </summary>
        /// <param name="classCode">The class code.</param>
        /// <returns></returns>
        Task<List<CompanyCSElement>> GetCommercialStructureAgentsSearchByClass(string classCode);
    }
}

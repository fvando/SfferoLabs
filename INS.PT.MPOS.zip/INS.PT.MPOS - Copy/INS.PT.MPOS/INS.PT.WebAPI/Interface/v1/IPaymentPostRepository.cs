﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Model.PaymentPost.v1;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
 
namespace INS.PT.WebAPI.Interface.V1
{
    /// <summary>
    /// IPaymentPostRepository
    /// </summary>
    public interface IPaymentPostRepository
    {
        /// <summary>
        /// Gets the payment post asynchronous.
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        Task<OutPutPaymentPost> GetPaymentPostAsync(InputPaymentPost parameters);

        /// <summary>
        /// Gets the payment post asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        Task<OutPutPaymentPost> GetPaymentPostAsync(InputPaymentPost parameters, HttpRequest request);
    
        /// <summary>
        /// Validates the error and lock user asynchronous.
        /// </summary>
        /// <param name="result">The result.</param>
        /// <param name="request">The request.</param>
        /// <returns></returns>
        Task<bool> ValidateErrorAndLockUserAsync(OutPutPaymentPost result, HttpRequest request);

    }
}

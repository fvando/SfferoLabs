﻿// Copyright Ageas 2019 © - Integration Team

using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface.V1
{
    /// <summary>
    /// IKpiRepository
    /// </summary>
    public interface IKpiRepository
    {
        /// <summary>
        /// Gets the kpi asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.Kpi.v1.OutPutKpi> GetKpiAsync(INS.PT.WebAPI.Model.Kpi.v1.InputKpi parameters);

        /// <summary>
        /// Gets the kpi all asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.Kpi.v1.OutPutKpi> GetKpiAllAsync(INS.PT.WebAPI.Model.Kpi.v1.InputKpi parameters);
    }
}

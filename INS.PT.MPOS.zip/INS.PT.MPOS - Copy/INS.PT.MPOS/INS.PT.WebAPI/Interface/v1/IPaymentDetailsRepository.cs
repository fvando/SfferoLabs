﻿// Copyright Ageas 2019 © - Integration Team
 
namespace INS.PT.WebAPI.Interface.V1
{
    /// <summary>
    /// IPaymentDetailsRepository
    /// </summary>
    public interface IPaymentDetailsRepository
    {
    }
}

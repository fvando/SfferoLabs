﻿// Copyright Ageas 2019 © - Integration Team

using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface.V1
{
    /// <summary>
    /// IReceiptDetailsRepository
    /// </summary>
    public interface IReceiptDetailsRepository
    {
        /// <summary>
        /// Gets the clients receipts asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        Task<INS.PT.WebAPI.Model.ReceiptDetail.v1.OutPutReceiptDetail> GetReceiptsDetailAsync(INS.PT.WebAPI.Model.ReceiptDetail.v1.InputReceiptDetail parameters);
    }
}

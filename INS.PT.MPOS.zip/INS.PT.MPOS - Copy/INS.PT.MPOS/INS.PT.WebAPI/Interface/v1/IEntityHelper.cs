﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Models.AgentsPortal.Agent.Elements;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Interface.V1
{
    /// <summary>
    /// IEntityHelper
    /// </summary>
    public interface IEntityHelper
    {
        /// <summary>
        /// Gets the agents from commercial structure.
        /// </summary>
        /// <param name="commercialStructure">The commercial structure.</param>
        /// <returns></returns>
        Task<List<AgentCSElement>> GetAgentsFromCommercialStructureAsync(List<CompanyCSElement> commercialStructure);
    }
}

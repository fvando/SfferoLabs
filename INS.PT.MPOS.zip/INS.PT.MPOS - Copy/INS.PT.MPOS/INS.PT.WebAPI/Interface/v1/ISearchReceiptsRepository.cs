﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Model.SearchReceipt.v1;
using System.Threading.Tasks;


namespace INS.PT.WebAPI.Interface.V1
{
    /// <summary>
    /// ISearchReceiptsRepository
    /// </summary>
    public interface ISearchReceiptsRepository
    {
        /// <summary>
        /// Gets the search receipts asynchronous.
        /// </summary>
        /// <param name="parameters">The parameters.</param>
        /// <returns></returns>
        Task<OutPutSearchReceipt> GetSearchReceiptsAsync(InputSearchReceipt parameters);
    }
}

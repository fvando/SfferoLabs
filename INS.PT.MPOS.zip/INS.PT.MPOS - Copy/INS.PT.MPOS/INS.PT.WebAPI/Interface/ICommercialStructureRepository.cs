﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Model.ClientReceipts;
using static INS.PT.WebAPI.Model.KpiSrv;
using static INS.PT.WebAPI.Model.Login;
using static INS.PT.WebAPI.Model.SumClientsReceipts;

namespace INS.PT.WebAPI.Interface
{
  
    public interface ICommercialStructureRepository
    {
         
        Task<OutputClientReceipts> GetClientReceiptsAsync(InputClientReceipts parameters);
    }
}

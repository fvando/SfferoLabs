﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Model.KpiSrv;
using static INS.PT.WebAPI.Model.Login;
using static INS.PT.WebAPI.Model.RefMBPayment;
using static INS.PT.WebAPI.Model.SearchReceipts;
using static INS.PT.WebAPI.Model.SumClientsReceipts;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// 
    /// </summary>
    public interface IRefMBPaymentRepository
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="section"></param>
        /// <returns></returns>
        OutputRefMBPayment Submit(string section);
    }
}

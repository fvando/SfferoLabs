﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Model.KpiSrv;
using static INS.PT.WebAPI.Model.Login;
using static INS.PT.WebAPI.Model.MBWayPayment;
using static INS.PT.WebAPI.Model.PaymentDetails;
using static INS.PT.WebAPI.Model.RefMBPayment;
using static INS.PT.WebAPI.Model.RegisterChipPin;
using static INS.PT.WebAPI.Model.SearchReceipts;
using static INS.PT.WebAPI.Model.SumClientsReceipts;

namespace INS.PT.WebAPI.Interface
{
    /// <summary>
    /// 
    /// </summary>
    public interface IRegisterChipPinRepository
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="section"></param>
        /// <returns></returns>
        OutputRegisterChipPin Submit(string section);
    }
}

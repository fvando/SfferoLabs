﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using INS.PT.WebAPI.Constants;
using INS.PT.WebAPI.Models.ReferenceData;
using static INS.PT.WebAPI.Constants.AgentsPortalEnums;

namespace INS.PT.WebAPI.Interface
{
    public interface IReferenceDataRepository
    {
        Task<ReferenceDataWaspOutput> GetReferenceData(DomainsData domainsData, int pageSize, int pageNumber);
        Task<ReferenceDataWaspOutput> GetReferenceDataByElement(ReferenceDataRouteWaspInput parameters, int pageSize, int pageNumber);
    }
}

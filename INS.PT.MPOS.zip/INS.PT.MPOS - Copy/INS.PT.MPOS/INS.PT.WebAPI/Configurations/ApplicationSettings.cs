﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.CommonLibrary.Jwt.Models;
using INS.PT.WebAPI.Configurations.Elements;

namespace INS.PT.WebAPI.Configurations
{
    /// <summary>
    /// ApplicationSettings
    /// </summary>
    public class ApplicationSettings
    {
        /// <summary>
        /// Gets or sets the name of the application.
        /// </summary>
        /// <value>
        /// The name of the application.
        /// </value>
        public string ApplicationName { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [ignore JWT token].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [ignore JWT token]; otherwise, <c>false</c>.
        /// </value>
        public bool IgnoreJwtToken { get; set; }
        /// <summary>
        /// Gets or sets the content type json.
        /// </summary>
        /// <value>
        /// The content type json.
        /// </value>
        public string ContentTypeJson { get; set; }
        /// <summary>
        /// Gets or sets the portfolio solution chanel.
        /// </summary>
        /// <value>
        /// The portfolio solution chanel.
        /// </value>
        public string PortfolioSolutionChanel { get; set; }
        /// <summary>
        /// Gets or sets the broker settings.
        /// </summary>
        /// <value>
        /// The broker settings.
        /// </value>
        public BrokerSettings BrokerSettings { get; set; }
        /// <summary>
        /// Gets or sets the broker services name spaces.
        /// </summary>
        /// <value>
        /// The broker services name spaces.
        /// </value>
        public BrokerServicesNameSpaces BrokerServicesNameSpaces { get; set; }
        /// <summary>
        /// Gets or sets the document service environment.
        /// </summary>
        /// <value>
        /// The document service environment.
        /// </value>
        public string DocumentServiceEnvironment { get; set; }
        /// <summary>
        /// Gets or sets the document service company.
        /// </summary>
        /// <value>
        /// The document service company.
        /// </value>
        public string DocumentServiceCompany { get; set; }
        /// <summary>
        /// Gets or sets the JWT settings.
        /// </summary>
        /// <value>
        /// The JWT settings.
        /// </value>
        public JwtSettings JwtSettings { get; set; }
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

namespace INS.PT.WebAPI.Configurations.Elements
{
    public class ListDefaults
    {
        public int PageSize { get; set; }

        public int PageNumber { get; set; }
    }
}
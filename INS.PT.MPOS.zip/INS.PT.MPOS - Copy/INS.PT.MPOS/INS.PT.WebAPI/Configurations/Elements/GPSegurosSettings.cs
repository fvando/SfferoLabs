﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Configurations.Elements
{
    public partial class GpSegurosSettings
    {
        public string CompanyCode { get; set; }

        public string AppContext { get; set; }

        public string CodeChannel { get; set; }

        public string CodeNetwork { get; set; }

        public string CodeRole { get; set; }

        public string Username { get; set; }

        public string Password { get; set; }

        public string ServiceEnpointHandler { get; set; }
    }
}

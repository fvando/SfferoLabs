﻿// Copyright Ageas 2019 © - Integration Team

namespace INS.PT.WebAPI.Configurations.Elements
{
    /// <summary>
    /// BrokerSettings
    /// </summary>
    public class BrokerSettings
    {
        /// <summary>
        /// Gets or sets the solution.
        /// </summary>
        /// <value>
        /// The solution.
        /// </value>
        public string Solution { get; set; }
        /// <summary>
        /// Gets or sets the user.
        /// </summary>
        /// <value>
        /// The user.
        /// </value>
        public string User { get; set; }
        /// <summary>
        /// Gets or sets the temporary solution.
        /// </summary>
        /// <value>
        /// The temporary solution.
        /// </value>
        public string TempSolution { get; set; }
        /// <summary>
        /// Gets or sets the temporary user.
        /// </summary>
        /// <value>
        /// The temporary user.
        /// </value>
        public string TempUser { get; set; }
        /// <summary>
        /// Gets or sets the identifier company.
        /// </summary>
        /// <value>
        /// The identifier company.
        /// </value>
        public string IdCompany { get; set; }
        /// <summary>
        /// Gets or sets the identifier network.
        /// </summary>
        /// <value>
        /// The identifier network.
        /// </value>
        public string IdNetwork { get; set; }
        /// <summary>
        /// Gets or sets the endpoint.
        /// </summary>
        /// <value>
        /// The endpoint.
        /// </value>
        public string Endpoint { get; set; }
        /// <summary>
        /// Gets or sets the SOAP end point.
        /// </summary>
        /// <value>
        /// The SOAP end point.
        /// </value>
        public string SoapEndPoint { get; set; }
    }
}

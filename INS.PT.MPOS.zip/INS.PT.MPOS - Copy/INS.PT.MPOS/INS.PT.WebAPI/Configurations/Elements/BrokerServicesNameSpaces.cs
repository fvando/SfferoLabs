﻿// Copyright Ageas 2019 © - Integration Team

namespace INS.PT.WebAPI.Configurations.Elements
{
    /// <summary>
    /// BrokerServicesNameSpaces
    /// </summary>
    public class BrokerServicesNameSpaces
    {
        /// <summary>
        /// Gets or sets the agents portal.
        /// </summary>
        /// <value>
        /// The agents portal.
        /// </value>
        public string AgentsPortal { get; set; }
        /// <summary>
        /// Gets or sets the entity.
        /// </summary>
        /// <value>
        /// The entity.
        /// </value>
        public string Entity { get; set; }
        /// <summary>
        /// Gets or sets the reference data.
        /// </summary>
        /// <value>
        /// The reference data.
        /// </value>
        public string ReferenceData { get; set; }
        /// <summary>
        /// Gets or sets the agent.
        /// </summary>
        /// <value>
        /// The agent.
        /// </value>
        public string Agent { get; set; }
        /// <summary>
        /// Gets or sets the document.
        /// </summary>
        /// <value>
        /// The document.
        /// </value>
        public string Document { get; set; }
        /// <summary>
        /// Gets or sets the collections.
        /// </summary>
        /// <value>
        /// The collections.
        /// </value>
        public string Collections { get; set; }
    }
}

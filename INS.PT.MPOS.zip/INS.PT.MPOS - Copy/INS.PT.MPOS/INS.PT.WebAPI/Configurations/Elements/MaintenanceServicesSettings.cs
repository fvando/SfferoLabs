﻿// Copyright Ageas 2019 © - Integration Team

namespace INS.PT.WebAPI.Configurations.Elements
{
    /// <summary>
    /// BrokerSettings
    /// </summary>
    public class MaintenanceServicesSettings
    {
        public bool Flag { get; set; } = false;
    }
}

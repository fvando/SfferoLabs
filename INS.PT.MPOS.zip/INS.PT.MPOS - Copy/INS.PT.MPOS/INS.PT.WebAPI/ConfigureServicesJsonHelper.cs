﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace INS.PT.WebAPI
{
    public class ConfigureServicesJsonHelper
    {
        /// <summary>
        /// Jsons the options.
        /// </summary>
        /// <param name="options">The options.</param>
        internal static void JsonOptions(MvcJsonOptions options)
        {
            //Set date configurations
            //options.SerializerSettings.DateTimeZoneHandling = DateTimeZoneHandling.Utc;
            options.SerializerSettings.DateFormatString = "dd-MM-yyyy";
            options.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
        }
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.CommonLibrary.Redis.Interfaces;
using INS.PT.WebAPI.Configurations.Elements;
using INS.PT.WebAPI.Helpers;
using INS.PT.WebAPI.Helpers.v1;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.v1;
using INS.PT.WebAPI.Models.AgentsPortal.Agent.Elements;
using log4net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.ActionFilters
{
    /// <summary>
    /// ContextInjectionFilter : IActionFilter
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.Filters.IActionFilter" />
    public class ContextInjectionFilter : IActionFilter
    {
        private readonly string TemporarilyMaintenanceMessage = "Temporarily Under Maintenance";
        private readonly string UnauthorizedErrorMessage = "Unauthorized agent in the current token structure";
        private readonly string UnauthorizedWithExpiredTokenErrorMessage = "Unauthorized, Token Expired!";
        private readonly string InvalidTokenMessage = "Invalid Token";
        
        private MaintenanceServicesSettings MaintenanceServicesSettingsObject;

        private readonly IConfiguration configuration;
        private readonly IHttpContextAccessor httpContext;
        private readonly IRedisManager redisManager;
        private readonly ILog Log;
        private readonly List<string> nonContextActions = new List<string> { "v1/AsfAgents", "v1/Context/TokenValidate", "v1/Context/UserLock", "v1/PaymentPost" };

        /// <summary>
        /// Initializes a new instance of the <see cref="ContextInjectionFilter"/> class.
        /// </summary>
        /// <param name="_httpContext">The HTTP context.</param>
        /// <param name="_redisManager">The redis manager.</param>
        public ContextInjectionFilter(IHttpContextAccessor _httpContext, IRedisManager _redisManager, IConfiguration _configuration)
        {
            httpContext = _httpContext;
            redisManager = _redisManager;
            Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

            MaintenanceServicesSettingsObject = new MaintenanceServicesSettings();
            var tmpFlag = _configuration?.GetSection("MaintenanceServicesSettings")?.GetSection("flag")?.Value;
            MaintenanceServicesSettingsObject.Flag = bool.Parse((string.IsNullOrEmpty(tmpFlag) ||
                tmpFlag.Equals("false", StringComparison.InvariantCultureIgnoreCase)) ? "false" : "true");
        }

        /// <summary>
        /// Called after the action executes, before the action result.
        /// </summary>
        /// <param name="context">The <see cref="T:Microsoft.AspNetCore.Mvc.Filters.ActionExecutedContext" />.</param>
        public void OnActionExecuted(ActionExecutedContext context)
        {
            // Do Nothing
        }

        /// <summary>
        /// Called before the action executes, after model binding is complete.
        /// </summary>
        /// <param name="context">The <see cref="T:Microsoft.AspNetCore.Mvc.Filters.ActionExecutingContext" />.</param>
        public void OnActionExecuting(ActionExecutingContext context)
        {
            try
            {

                //Validate Flag to Maintance on Event
                if (MaintenanceServicesSettingsObject.Flag)
                {
                    context.Result = new UnauthorizedObjectResult(
                                new ProcessErrorExceptionHeader(
                                    StatusCodes.Status503ServiceUnavailable.ToString(CultureInfo.CurrentCulture), "Unauthorized",
                                    new List<ProcessErrorExceptionHeader.InnerError>{
                                    new ProcessErrorExceptionHeader.InnerError{
                                        ErrorType = "",
                                        ErrorCode = StatusCodes.Status503ServiceUnavailable.ToString(CultureInfo.CurrentCulture),
                                        ErrorMessage = TemporarilyMaintenanceMessage.ToString(CultureInfo.CurrentCulture)
                                    }
                                    }
                                )
                            );
                };

                if (nonContextActions.All(action => string.Compare(action, context.ActionDescriptor.AttributeRouteInfo.Template, StringComparison.InvariantCultureIgnoreCase) != 0))
                {
                    CommonLibrary.Redis.Models.RedisOutput<List<CompanyCSElement>> user = null;
                    var validHeader = httpContext.HttpContext.Request.Headers.TryGetValue("Authorization", out var token);

                    if (validHeader)
                    {
                        Task.Run(async () => { user = await ValidateUserAsync(context, token); }).Wait();

                        var inputObj = context.ActionArguments.Values.FirstOrDefault();
                        List<string> resultHelper = user.IsValid ? ValidateAgentIsInContext(user?.Value, inputObj): null;

                        var resultError = new UnauthorizedObjectResult(
                            new ProcessErrorExceptionHeader(
                                StatusCodes.Status401Unauthorized.ToString(CultureInfo.CurrentCulture), "Unauthorized",
                                new List<ProcessErrorExceptionHeader.InnerError>{
                                    new ProcessErrorExceptionHeader.InnerError{
                                        ErrorCode = StatusCodes.Status401Unauthorized.ToString(CultureInfo.CurrentCulture),
                                        ErrorMessage = UnauthorizedErrorMessage.ToString(CultureInfo.CurrentCulture)
                                    }
                                }
                            )
                        );

                        context.Result = resultHelper?.Count == 0 ? resultError : context.Result;
                    }
                }
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError);
            }
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors);
            }
            catch (Exception exc)
            {
                Log.Error(exc);
                throw;
            }
        }

        private static List<string> ValidateAgentIsInContext(List<CompanyCSElement> user, object inputObj)
        {
            var inputObjName = inputObj.ToString();

            switch (inputObjName)
            {
                case "INS.PT.WebAPI.Model.ClientReceipts.v1.InputClientReceipts":
                    return ListHelper.GetCodeAgentsList(((Model.ClientReceipts.v1.InputClientReceipts)inputObj).AgentContext.AgentId, user);

                case "INS.PT.WebAPI.Model.Kpi.v1.InputKpi":
                    return ListHelper.GetCodeAgentsList(((Model.Kpi.v1.InputKpi)inputObj).AgentContext.AgentId, user);

                case "INS.PT.WebAPI.Model.ReceiptDetail.v1.InputReceiptDetail":
                    return ListHelper.GetCodeAgentsList(((Model.ReceiptDetail.v1.InputReceiptDetail)inputObj).AgentContext.AgentId, user);

                case "INS.PT.WebAPI.Model.SearchReceipt.v1.InputSearchReceipt":
                    return ListHelper.GetCodeAgentsList(((Model.SearchReceipt.v1.InputSearchReceipt)inputObj).AgentContext.AgentId, user);

                case "INS.PT.WebAPI.Model.SumClientReceipt.v1.InputSumClientReceipt":
                    return ListHelper.GetCodeAgentsList(((Model.SumClientReceipt.v1.InputSumClientReceipt)inputObj).AgentContext.AgentId, user);

                case "INS.PT.WebAPI.Model.v1.InputGetDoc":
                    return ListHelper.GetCodeAgentsList(((Model.v1.InputGetDoc)inputObj).AgentContext.AgentId, user);

                case "INS.PT.WebAPI.Model.ClientReceipts.v2.InputClientReceipts":
                    return ListHelper.GetCodeAgentsList(((Model.ClientReceipts.v2.InputClientReceipts)inputObj).AgentContext.AgentId, user);

                case "INS.PT.WebAPI.Model.Kpi.v2.InputKpi":
                    return ListHelper.GetCodeAgentsList(((Model.Kpi.v2.InputKpi)inputObj).AgentContext.AgentId, user);

                case "INS.PT.WebAPI.Model.ReceiptDetail.v2.InputReceiptDetail":
                    return ListHelper.GetCodeAgentsList(((Model.ReceiptDetail.v2.InputReceiptDetail)inputObj).AgentContext.AgentId, user);

                case "INS.PT.WebAPI.Model.SearchReceipt.v2.InputSearchReceipt":
                    return ListHelper.GetCodeAgentsList(((Model.SearchReceipt.v2.InputSearchReceipt)inputObj).AgentContext.AgentId, user);

                case "INS.PT.WebAPI.Model.SumClientReceipt.v2.InputSumClientReceipt":
                    return ListHelper.GetCodeAgentsList(((Model.SumClientReceipt.v2.InputSumClientReceipt)inputObj).AgentContext.AgentId, user);

                case "INS.PT.WebAPI.Model.v2.InputGetDoc":
                    return ListHelper.GetCodeAgentsList(((Model.v2.InputGetDoc)inputObj).AgentContext.AgentId, user);

                default:
                    return new List<string>();
            }
        }

       /// <summary>
       /// 
       /// </summary>
       /// <param name="context"></param>
       /// <param name="token"></param>
       /// <returns></returns>
        private async Task<CommonLibrary.Redis.Models.RedisOutput<List<CompanyCSElement>>> ValidateUserAsync(ActionExecutingContext context, StringValues token)
        {
 
            var user = await redisManager.GetContextAsync<List<CompanyCSElement>>(token);

            if (user == null || !user.IsValid)
            {
                context.Result = new UnauthorizedObjectResult(new ProcessErrorExceptionHeader(
                StatusCodes.Status401Unauthorized.ToString(CultureInfo.CurrentCulture),
                UnauthorizedWithExpiredTokenErrorMessage, new List<ProcessErrorExceptionHeader.InnerError>{
                                        new ProcessErrorExceptionHeader.InnerError{
                                                ErrorCode = StatusCodes.Status401Unauthorized.ToString(CultureInfo.CurrentCulture),
                                                ErrorMessage = UnauthorizedWithExpiredTokenErrorMessage.ToString(CultureInfo.CurrentCulture)
                                        }
                }));
            }

            return user;
        }
    }
}

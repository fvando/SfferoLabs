﻿// Copyright Ageas 2019 © - Integration Team

using static INS.PT.WebAPI.Constants.CommonEnums;

namespace INS.PT.WebAPI.Data.v1
{
    /// <summary>
    /// HttpRequestElement
    /// </summary>
    public class HttpRequestElement
    {
        /// <summary>
        /// Gets or sets the API service.
        /// </summary>
        /// <value>
        /// The API service.
        /// </value>
        public string ApiService { get; set; }

        /// <summary>
        /// Gets or sets the API method.
        /// </summary>
        /// <value>
        /// The API method.
        /// </value>
        public string ApiMethod { get; set; }

        /// <summary>
        /// Gets or sets the route value.
        /// </summary>
        /// <value>
        /// The route value.
        /// </value>
        public string RouteValue { get; set; }
        public string IdCompany { get; set; }
        public string IdNetwork { get; set; }
        public string ContentType { get; set; }
        public string EndPoint { get; set; }

        public string SoapEndPoint { get; set; }

        public string Solution { get; set; }

        public string User { get; set; }

        /// <summary>
        /// Gets or sets the query string.
        /// </summary>
        /// <value>
        /// The query string.
        /// </value>
        public Microsoft.AspNetCore.Http.QueryString QueryString { get; set; }

        /// <summary>
        /// Gets or sets the method.
        /// </summary>
        /// <value>
        /// The method.
        /// </value>
        public HttpRequestVerb Method { get; set; }

        /// <summary>
        /// Gets or sets the options.
        /// </summary>
        /// <value>
        /// The options.
        /// </value>
        public OptionsElement Options { get; set; }

        /// <summary>
        /// Gets or sets the request object.
        /// </summary>
        /// <value>
        /// The request object.
        /// </value>
        public object RequestObject { get; set; }        
    }
}

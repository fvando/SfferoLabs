﻿// Copyright Ageas 2019 © - Integration Team

using Oracle.ManagedDataAccess.Client;
using System;
using Microsoft.Extensions.Configuration;
using System.Data;
using Newtonsoft.Json;
using log4net;
using System.Reflection;
using Microsoft.AspNetCore.Http;
using System.Globalization;
using INS.PT.WebAPI.Model.v2;
using System.Collections.Generic;
using INS.PT.WebAPI.V2;

namespace INS.PT.WebAPI.v2
{
    ///<inheritdoc /> 
    /// <summary>
    /// concrete class
    /// </summary>
    public class Dbconnectioncs : IDbconnectioncs, IDisposable
    {
        private  IDbConnection connection;
        private readonly IConfiguration configuration;

        /// <summary>
        /// Object contructor.
        /// </summary>
        /// <param name="configuration">Configuration to use.</param>
        public Dbconnectioncs(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources.
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            // cleanup
            if (connection != null && connection.State != ConnectionState.Closed)
            {
                connection.Close();
            }
        }

        /// <summary>
        /// GetConnection
        /// </summary>
        /// <returns>Connection to be used.</returns>
        public IDbConnection GetConnection()
        {
            //start log
            ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

            try
            {
                // open connection if not already open
                if (connection == null || connection.State == ConnectionState.Closed)
                {
                    string connectionString = configuration.GetSection("ConnectionStrings").GetSection("DBConnection").Value;
                    connection = new OracleConnection(connectionString);
                    connection.Open();
                }
            }
            catch (Exception ex)
            {
                Log.Debug($"Response: {StatusCodes.Status400BadRequest.ToString(CultureInfo.CurrentCulture)}");
                throw new ProcessErrorException(
                           StatusCodes.Status400BadRequest.ToString(CultureInfo.CurrentCulture),
                           ex.Message, new List<ProcessErrorException.InnerError>
                           {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = StatusCodes.Status400BadRequest.ToString(CultureInfo.CurrentCulture),
                                       ErrorMessage = ex.Message.ToString(CultureInfo.CurrentCulture)
                                   }
                           }
                           );
            }

            Log.Debug($"GetConnection result: { JsonConvert.SerializeObject(connection, Formatting.Indented)}");
            return connection;
        }
    }
}

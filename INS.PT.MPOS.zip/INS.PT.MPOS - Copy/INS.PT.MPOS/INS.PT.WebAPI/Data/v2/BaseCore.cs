﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Configurations;
using INS.PT.WebAPI.Model.v1;
using log4net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.v2
{
    /// <summary>
    /// BaseCore
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.ControllerBase" />
    public class BaseCore : ControllerBase
    {
        protected const string LogReturnOk = "Return: OK";

        protected ILog Log;
        protected readonly IHttpContextAccessor httpContext;

        /// <summary>
        /// Contructor of the BaseCore.
        /// </summary>
        /// <param name="httpContext">execution context being used.</param>
        public BaseCore(IHttpContextAccessor httpContext)
        {
            Log = LogManager.GetLogger(typeof(BaseCore));
            this.httpContext = httpContext;
        }

        #region tipical verb actions

        /// <summary>
        /// Gets the action asynchronous.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="method">The method.</param>
        /// <param name="notFound">The not found.</param>
        /// <param name="notFoundReturnObject">The not found return object.</param>
        /// <returns></returns>
        protected async Task<ActionResult<T>> GetActionAsync<T>(Func<HeaderParameters, Task<T>> method, Func<T, bool> notFound, object notFoundReturnObject)
        {
            try
            {
                // get header parameters
                var headerParameters = ValidateHeader();

                if (headerParameters == null)
                {
                    // no results return path
                    Log.Debug($"headerParameters : NotFound {notFoundReturnObject}");
                    return NotFound(notFoundReturnObject);
                }

                // get result from method
                var result = await method?.Invoke(headerParameters);

                if (object.Equals(result, default(T)))
                {
                    // no results return path
                    Log.Debug($"result : NotFound {notFoundReturnObject}");
                    return NotFound(notFoundReturnObject);
                }

                // check logic for no results
                var notFoundResult = notFound?.Invoke(result);
                if (!notFoundResult.HasValue || notFoundResult.Value)
                {
                    // no results return path
                    Log.Debug($"Return GET: NotFound {notFoundReturnObject}");
                    return NotFound(notFoundReturnObject);
                }

                // Ok result
                Log.Debug($"{LogReturnOk} {result}");

                return Ok(result);
            }
            catch (ProcessErrorException processError)
            {
                // error in logic layer return NotFound with Error
                return NotFound(processError);
            }
            catch (AggregateException validateErrors)
            {
                // validation error return BadRequest
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception e)
            {
                // unexpected exception
                Log.Error(e);
                throw;
            }
            finally
            {
                // log exit from method
                Log.Debug($"Finish");
            }
        }

        /// <summary>
        /// Method with tipical actions on a PUT verb.
        /// </summary>
        /// <typeparam name="T">return type of the PUT verb</typeparam>
        /// <param name="method">service method with logic to execute</param>
        /// <param name="notFound">logic to determine if controller should response a NotFound error.</param>
        /// <param name="notFoundReturnObject">object to return if response is NotFound.</param>
        /// <returns>result action of the controller with object of T type</returns>
        protected async Task<ActionResult<T>> PutActionAsync<T>(Func<HeaderParameters, Task<T>> method, Func<T, bool> notFound, object notFoundReturnObject)
        {
            try
            {
                // get header parameters
                var headerParameters = ValidateHeader();

                if (headerParameters == null)
                {
                    // no results return path
                    Log.Debug($"headerParameters : NotFound {notFoundReturnObject}");
                    return NotFound(notFoundReturnObject);
                }

                // execute update and get result from method
                var updatedObject = await method?.Invoke(headerParameters);

                if (object.Equals(updatedObject, default(T)))
                {
                    // no results return path
                    Log.Debug($"updatedObject : NotFound {notFoundReturnObject}");
                    return NotFound(notFoundReturnObject);
                }

                // check logic for no results
                var notFoundResult = notFound?.Invoke(updatedObject);

                if (!notFoundResult.HasValue || notFoundResult.Value)
                {
                    // no results return path
                    Log.Debug($"Return PUT: NotFound {notFoundReturnObject}");
                    return NotFound(notFoundReturnObject);
                }

                // Ok result
                Log.Debug($"{LogReturnOk} {updatedObject}");

                return Ok(updatedObject);
            }
            catch (ProcessErrorException processError)
            {
                // error in logic layer return NotFound with Error
                return NotFound(processError);
            }
            catch (AggregateException validateErrors)
            {
                // validation error return BadRequest
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception e)
            {
                // unexpected exception
                Log.Error(e);
                throw;
            }
            finally
            {
                // log exit from method
                Log.Debug($"Finish Call PUT");
            }
        }

        /// <summary>
        /// Method with tipical actions on a DELETE verb.
        /// </summary>
        /// <param name="method">service method with logic to execute</param>
        /// <returns>result action of the controller</returns>
        protected async Task<ActionResult> DeleteActionAsync(Func<HeaderParameters, Task<bool>> method)
        {
            try
            {
                // get header parameters
                var headerParameters = ValidateHeader();

                if (headerParameters == null)
                {
                    // no results return path
                    Log.Debug($"headerParameters : NotFound {headerParameters}");
                    return NotFound(headerParameters);
                }

                // execute method to delete information
                var result = await method?.Invoke(headerParameters);
                if (result)
                {
                    // information deleted return NoContent
                    Log.Debug($"Return DELETE: NoContent");
                    return NoContent();
                }
                else
                {
                    // can't delete return NotFound
                    Log.Debug($"Return DELETE: NotFound");
                    return NotFound();
                }
            }
            catch (ProcessErrorException processError)
            {
                // error in logic layer return NotFound with Error
                return NotFound(processError);
            }
            catch (AggregateException validateErrors)
            {
                // validation error return BadRequest
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception e)
            {
                // unexpected exception
                Log.Error(e);
                throw;
            }
            finally
            {
                // log exit from method
                Log.Debug($"Finish Call DELETE");
            }
        }
        #endregion

        /// <summary>
        /// Method to get the current URI of execution.
        /// </summary>
        /// <param name="appendPath">Parameter to appended to the result path.</param>
        /// <returns>Uri object with the current URI with the appendPath concatenated.</returns>
        protected Uri GetUri(string appendPath)
        {
            try
            {
                // check current context
                var request = httpContext?.HttpContext?.Request;

                if (request == null)
                {
                    return null;
                }

                var path = request.Path;

                // if no local path go to route
                if (string.IsNullOrEmpty(path.Value))
                {
                    path = new PathString("/");
                }

                if (appendPath != null)
                {
                    path += appendPath.StartsWith('/') ? appendPath : $"/{appendPath}";
                }

                // prepare builder for Uri
                var builder = new UriBuilder
                {
                    Scheme = request.Scheme,
                    Host = request.Host.Host,
                    Path = path,
                    Query = request.QueryString.ToUriComponent()
                };

                if (request.Host.Port.HasValue)
                {
                    builder.Port = request.Host.Port.Value;
                }

                return builder.Uri;

            }
            catch (Exception e)
            {
                // unexpected exception
                Log.Error(e);
                throw;
            }
            finally
            {
                // log exit from method
                Log.Debug($"Finish Call DELETE");
            }
        }

        /// <summary>
        /// Method to read header parameters and validate their value.
        /// </summary>
        /// <returns>HeaderParameers object with values.</returns>
        protected virtual HeaderParameters ValidateHeader()
        {

            try
            {
                var headerParameters = new HeaderParameters();
                var errors = new List<ValidationResult>();

                // read header parameters
                headerParameters.Source = ReadHeaderParameter(nameof(headerParameters.Source));

                // execute validation
                Validator.TryValidateObject(headerParameters, new ValidationContext(headerParameters), errors, true);

                if (errors.Any())
                {
                    throw new AggregateException(
                           errors.Select((e) => new ValidationException(e.ErrorMessage)));
                }

                return headerParameters;
            }
            catch (Exception e)
            {
                // unexpected exception
                Log.Error(e);
                throw;
            }
            finally
            {
                // log exit from method
                Log.Debug($"Finish Call DELETE");
            }
        }

        /// <summary>
        /// Reads the header parameter.
        /// </summary>
        /// <param name="parameterName">Name of the parameter.</param>
        /// <returns></returns>
        /// <autogeneratedoc />
        private string ReadHeaderParameter(string parameterName)
        {
            try
            {
                // try to read header value
                if (!string.IsNullOrEmpty(parameterName) && httpContext != null
                    && httpContext.HttpContext.Request.Headers.TryGetValue(parameterName, out var headerValues))
                {
                    return headerValues.First();
                }

                return null;

            }
            catch (Exception e)
            {
                // unexpected exception
                Log.Error(e);
                throw;
            }
            finally
            {
                // log exit from method
                Log.Debug($"Finish Call DELETE");
            }

        }
    }
}

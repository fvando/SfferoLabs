﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Xml.Linq;
using Dapper;
using Oracle.ManagedDataAccess.Client;

namespace INS.PT.WebAPI.v2
{
    /// <summary>
    /// OracleDynamicParameters
    /// </summary>
    /// <seealso cref="Dapper.SqlMapper.IDynamicParameters" />
    public class OracleDynamicParameters : SqlMapper.IDynamicParameters
    {
        private readonly DynamicParameters dynamicParameters = new DynamicParameters();
        private readonly ICollection<OracleParameter> OracleParameters = new List<OracleParameter>();
        public ICollection<OracleParameter> Parameters => OracleParameters;

        /// <summary>
        /// Creates a new package parameter.
        /// </summary>
        /// <param name="name">Parameter name.</param>
        /// <param name="oracleDbType">Database datatype.</param>
        /// <param name="direction">Parameter direction.</param>
        public void Add(string name, OracleDbType oracleDbType, ParameterDirection direction)
        {
            var oracleParameter = new OracleParameter(name, oracleDbType, direction);
            OracleParameters.Add(oracleParameter);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="oracleDbType"></param>
        /// <param name="direction"></param>
        /// <param name="value"></param>
        public void Add(string name, OracleDbType oracleDbType, ParameterDirection direction, object value)
        {
            Add(name, oracleDbType, direction, value, null);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="oracleDbType"></param>
        /// <param name="direction"></param>
        /// <param name="value"></param>
        /// <param name="size"></param>
        public void Add(string name, OracleDbType oracleDbType, ParameterDirection direction, object value, int? size)
        {
            OracleParameters.Add(size.HasValue ? new OracleParameter(name, oracleDbType, size.Value, value, direction) : new OracleParameter(name, oracleDbType, value, direction));
        }

        ///<inheritdoc /> 
        public void AddParameters(IDbCommand command, SqlMapper.Identity identity)
        {
            ((SqlMapper.IDynamicParameters)dynamicParameters).AddParameters(command, identity);

            if (command is OracleCommand oracleCommand)
            {
                oracleCommand.Parameters.AddRange(OracleParameters.ToArray());
            }
        }

        /// <summary>
        /// Reads the output value from a parameter.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <returns>decimal value of the parameter</returns>
        public decimal GetDecimal(string parameterName)
        {
            return GetDecimal(parameterName, default(decimal));
        }

        /// <summary>
        /// Reads the output value from a parameter.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <param name="defaultValue">default value if parameter is not found or is not the expected type</param>
        /// <returns>decimal value of the parameter or default value</returns>
        public decimal GetDecimal(string parameterName, decimal defaultValue)
        {
            var parameterValue = OracleParameters.FirstOrDefault(op => op.ParameterName == parameterName)?.Value;
            if (parameterValue is Oracle.ManagedDataAccess.Types.OracleDecimal dbValue)
            {
                return dbValue.IsNull ? defaultValue : dbValue.Value;
            }

            return defaultValue;
        }

        /// <summary>
        /// Reads the output value from a parameter.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <returns>int value of the parameter</returns>
        public int GetInt(string parameterName)
        {
            return GetInt(parameterName, default(int));
        }

        /// <summary>
        /// Reads the output value from a parameter.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <param name="defaultValue">default value if parameter is not found or is not the expected type</param>
        /// <returns>int value of the parameter or default value</returns>
        public int GetInt(string parameterName, int defaultValue)
        {
            var parameterValue = OracleParameters.FirstOrDefault(op => op.ParameterName == parameterName)?.Value;
            if (parameterValue is Oracle.ManagedDataAccess.Types.OracleDecimal dbValue)
            {
                return dbValue.IsNull ? defaultValue : decimal.ToInt32(dbValue.Value);
            }

            return defaultValue;
        }

        /// <summary>
        /// Reads the output value from a parameter.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <returns>string value of the parameter</returns>
        public string GetString(string parameterName)
        {
            return GetString(parameterName, default(string));
        }

        /// <summary>
        /// Reads the output value from a parameter.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <param name="defaultValue">default value if parameter is not found or is not the expected type</param>
        /// <returns>string value of the parameter or default value</returns>
        public string GetString(string parameterName, string defaultValue)
        {
            var parameterValue = OracleParameters.FirstOrDefault(op => op.ParameterName == parameterName)?.Value;
            if (parameterValue is Oracle.ManagedDataAccess.Types.OracleString dbValue)
            {
                return dbValue.IsNull ? null : dbValue.Value;
            }

            return defaultValue;
        }

        /// <summary>
        /// Reads the output value from a parameter.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <returns>Xdocument value of the parameter</returns>
        public XDocument GetXml(string parameterName)
        {
            return GetXml(parameterName, null);
        }

        /// <summary>
        /// Reads the output value from a parameter.
        /// </summary>
        /// <param name="parameterName">parameter name</param>
        /// <param name="defaultValue">default value if parameter is not found or is not the expected type</param>
        /// <returns>Xdocument value of the parameter or default value</returns>
        public XDocument GetXml(string parameterName, XDocument defaultValue)
        {
            var parameterValue = OracleParameters.FirstOrDefault(op => op.ParameterName == parameterName)?.Value;
            if (parameterValue is Oracle.ManagedDataAccess.Types.OracleXmlType dbValue)
            {
                return dbValue.IsNull ? null : XDocument.Parse(dbValue.Value);
            }
            if (parameterValue is Oracle.ManagedDataAccess.Types.OracleString dbStringValue)
            {
                return dbStringValue.IsNull ? null : XDocument.Parse(dbStringValue.Value);
            }

            return defaultValue;
        }

    }
}

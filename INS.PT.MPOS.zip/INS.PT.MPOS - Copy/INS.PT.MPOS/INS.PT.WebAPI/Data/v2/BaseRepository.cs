﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Helper;
using INS.PT.WebAPI.Interface.V2;
using log4net;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Reflection;
using System.ServiceModel;

namespace INS.PT.WebAPI.Data.v2
{
    /// <summary>
    /// BaseRepository
    /// </summary>
    public class BaseRepository
    {
        #region Properties
        protected readonly ILog log;
        protected readonly HttpRequest request;
        protected readonly IConfiguration configuration;
        protected readonly IRepositoryInvoker repositoryInvoker;
        #endregion

        protected readonly TimeSpan OpenTimeout;
        protected readonly TimeSpan CloseTimeout;
        protected readonly TimeSpan SendTimeout;
        protected readonly TimeSpan ReceiveTimeout;
        protected readonly TimeSpan RestTimeout;

        protected readonly BasicHttpBinding Binding;
        protected readonly IHttpContextAccessor httpContext;

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseRepository"/> class.
        /// </summary>
        /// <param name="_configuration">The configuration.</param>
        public BaseRepository(IConfiguration _configuration, IHttpContextAccessor _httpContext)
        {
            configuration = _configuration;
            log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

            // httpContext
            httpContext = _httpContext;

            _configuration = _httpContext.GetConfiguration();

            // read timeouts from config
            OpenTimeout = _configuration.ReadTimeSpanFromConfig("ServicesTimeouts:OpenTimeout");
            CloseTimeout = _configuration.ReadTimeSpanFromConfig("ServicesTimeouts:CloseTimeout");
            SendTimeout = _configuration.ReadTimeSpanFromConfig("ServicesTimeouts:SendTimeout");
            ReceiveTimeout = _configuration.ReadTimeSpanFromConfig("ServicesTimeouts:ReceiveTimeout");
            RestTimeout = _configuration.ReadTimeSpanFromConfig("ServicesTimeouts:RestTimeout");

            Binding = new BasicHttpBinding();
            Binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
            Binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;

            Binding.OpenTimeout = OpenTimeout;
            Binding.CloseTimeout = CloseTimeout;
            Binding.SendTimeout = SendTimeout;
            Binding.ReceiveTimeout = ReceiveTimeout;

            Binding.MaxReceivedMessageSize = int.MaxValue;
            Binding.MaxBufferPoolSize = int.MaxValue;
            Binding.MaxBufferSize = int.MaxValue;
            Binding.AllowCookies = true;
            Binding.TransferMode = TransferMode.Buffered;

        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseRepository"/> class.
        /// </summary>
        /// <param name="_configuration">The configuration.</param>
        /// <param name="_repositoryInvoker">The repository invoker.</param>
        public BaseRepository(IConfiguration _configuration, IHttpContextAccessor _httpContext, IRepositoryInvoker _repositoryInvoker) 
            : this(_configuration, _httpContext)
        {
            repositoryInvoker = _repositoryInvoker;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BaseRepository"/> class.
        /// </summary>
        /// <param name="_configuration">The configuration.</param>
        /// <param name="_repositoryInvoker">The repository invoker.</param>
        /// <param name="_request">The request.</param>
        public BaseRepository(IConfiguration _configuration, IHttpContextAccessor _httpContext, IRepositoryInvoker _repositoryInvoker, HttpRequest _request) 
            : this(_configuration, _httpContext, _repositoryInvoker)
        {
            request = _request; 
        }
 
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Data.v2;
using log4net;
using Newtonsoft.Json;
using System;
using System.Reflection;

namespace INS.PT.WebAPI.Helper.v2
{

    /// <summary>
    /// EntityDesc
    /// </summary>
    public static class EntityDesc
    {
      
        /// <summary>
        /// Gets the desc company.
        /// </summary>
        /// <param name="companyCode">The company code.</param>
        /// <returns></returns>
        public static EnumCompany GetDescCompany(string companyCode)
        {
            
            EnumCompany companyVal = EnumCompany.AgeasNaoVida;

            foreach (EnumCompany ev in Enum.GetValues(typeof(EnumCompany))) { 
                string strValue = ev.GetStringValue();

                if (string.Compare(strValue, companyCode, StringComparison.InvariantCultureIgnoreCase) == 0) {
                    companyVal = ev;
                }
            }
            return companyVal;
        }

        public static StatusAgent GetDescStatuAgent(string statusAgent)
        {
            //Logging Default
            var log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            log.Debug($"{MethodBase.GetCurrentMethod()?.ReflectedType?.FullName} Request: {statusAgent}");

            StatusAgent agentVal = StatusAgent.Blocked;

            foreach (StatusAgent ev in Enum.GetValues(typeof(StatusAgent)))
            {
                string strValue = ev.GetStringValue();

                if (string.Compare(strValue, statusAgent, StringComparison.InvariantCultureIgnoreCase) == 0)
                {
                    agentVal = ev;
                }
            }
            log.Debug($"{MethodBase.GetCurrentMethod()?.ReflectedType?.FullName} Response: {agentVal}");
            return agentVal;
        }



    }
}

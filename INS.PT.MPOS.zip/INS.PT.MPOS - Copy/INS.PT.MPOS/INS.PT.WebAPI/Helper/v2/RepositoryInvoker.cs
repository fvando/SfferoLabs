﻿// Copyright Ageas 2019 © - Integration Team

using AutoMapper;
using INS.PT.CommonLibrary.Exceptions;
using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Data.v2;
using INS.PT.WebAPI.Interface.V2;
using INS.PT.WebAPI.Model.v2;
using log4net;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Helpers.v2
{
    /// <summary>
    /// RepositoryInvoker
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.IRepositoryInvoker" />
    public class RepositoryInvoker : IRepositoryInvoker
    {
        #region Properties

        private readonly ILog log;
        private readonly IMapper mapper;
        private readonly HttpRequest request;
        private readonly IHttpClientRepository httpClientRepository;

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="RepositoryInvoker"/> class.
        /// </summary>
        /// <param name="_httpClientRepository">The HTTP client repository.</param>
        /// <param name="_mapper">The mapper.</param>
        /// <param name="_request">The request.</param>
        public RepositoryInvoker(IHttpClientRepository _httpClientRepository, IMapper _mapper, HttpRequest _request)
        {
            request = _request;
            mapper = _mapper;
            httpClientRepository = _httpClientRepository;

            log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        }

        /// <summary>
        /// Generics the invoker asynchronous.
        /// </summary>
        /// <typeparam name="TWaspInput">The type of the wasp input.</typeparam>
        /// <typeparam name="TWaspOutput">The type of the wasp output.</typeparam>
        /// <typeparam name="TDTOInput">The type of the dto input.</typeparam>
        /// <typeparam name="TDTOOutput">The type of the dto output.</typeparam>
        /// <param name="requestObject">The request object.</param>
        /// <param name="serviceNameSpace">The service name space.</param>
        /// <param name="methodName">Name of the method.</param>
        /// <param name="routeValue">The route value.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">
        /// </exception>
        /// <exception cref="ProcessErrorException.InnerError">
        /// </exception>
        public async Task<TWaspOutput> GenericInvokerAsync<TWaspInput, TWaspOutput, TDTOInput, TDTOOutput>(TWaspInput requestObject, 
            string serviceNameSpace, string methodName, [Optional] string routeValue)
        {
            TWaspOutput result = default(TWaspOutput);
            var inputObj = mapper.Map<TDTOInput>(requestObject);

            var responseMessage = await httpClientRepository.ProcessRequestAsync(request, serviceNameSpace, methodName, routeValue, inputObj);

            if (responseMessage.IsSuccessStatusCode)
            {
                var response = responseMessage.Content.ReadAsAsync<TDTOOutput>();
                result = mapper.Map<TWaspOutput>(await response);
            }
            else
            {
                log.Debug($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(responseMessage)}");

                if (responseMessage.StatusCode == System.Net.HttpStatusCode.BadRequest || responseMessage.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    object badRequestResponse = await responseMessage.Content.ReadAsAsync<object>();
                    throw new ProcessErrorException(
                            responseMessage.StatusCode.ToString(),
                            responseMessage.StatusCode.ToString(), new List<ProcessErrorException.InnerError>
                            {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = responseMessage.StatusCode.ToString(),
                                       ErrorMessage = JsonConvert.SerializeObject(badRequestResponse) 
                                   }
                            }
                            );
                }

               throw new ProcessErrorException(
                        responseMessage.StatusCode.ToString(),
                        responseMessage.StatusCode.ToString(), new List<ProcessErrorException.InnerError>
                        {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = responseMessage.StatusCode.ToString(),
                                       ErrorMessage = JsonConvert.SerializeObject(responseMessage.ToString()) 
                                   }
                        }
                        );


            }

            return result;
        }

        /// <summary>
        /// Generics the get invoker asynchronous.
        /// </summary>
        /// <typeparam name="TWaspOutput">The type of the wasp output.</typeparam>
        /// <typeparam name="TDTOOutput">The type of the dto output.</typeparam>
        /// <param name="serviceNameSpace">The service name space.</param>
        /// <param name="methodName">Name of the method.</param>
        /// <param name="routeValue">The route value.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">
        /// </exception>
        /// <exception cref="ProcessErrorException.InnerError">
        /// </exception>
        public async Task<TWaspOutput> GenericInvokerAsync<TWaspOutput, 
            TDTOOutput>(string serviceNameSpace, string methodName, [Optional] string routeValue)
        {
            TWaspOutput result = default(TWaspOutput);

            var responseMessage = await httpClientRepository.ProcessRequestAsync(request, serviceNameSpace, 
                methodName, routeValue);

            if (responseMessage.IsSuccessStatusCode)
            {
                var response = await responseMessage.Content.ReadAsAsync<TDTOOutput>();
                result = mapper.Map<TWaspOutput>(response);
            }
            else
            {
                log.Debug($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(responseMessage)}");

                if (responseMessage.StatusCode == System.Net.HttpStatusCode.BadRequest || responseMessage.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    object badRequestResponse = await responseMessage.Content.ReadAsAsync<object>();
                    throw new ProcessErrorException(
                            responseMessage.StatusCode.ToString(),
                            responseMessage.StatusCode.ToString(), new List<ProcessErrorException.InnerError>
                            {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = responseMessage.StatusCode.ToString(),
                                       ErrorMessage = JsonConvert.SerializeObject(badRequestResponse) 
                                   }
                            }
                            );
                }

                throw new ProcessErrorException(
                      responseMessage.StatusCode.ToString(),
                      responseMessage.StatusCode.ToString(), new List<ProcessErrorException.InnerError>
                      {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = responseMessage.StatusCode.ToString(),
                                       ErrorMessage = JsonConvert.SerializeObject(responseMessage.ToString()) 
                                   }
                      }
                      );
            }

            return result;
        }

        /// <summary>
        /// Generics the invoker asynchronous.
        /// </summary>
        /// <typeparam name="TWaspOutput">The type of the wasp output.</typeparam>
        /// <typeparam name="TDTOOutput">The type of the dto output.</typeparam>
        /// <param name="requestElement">The request element.</param>
        /// <returns></returns>
        public async Task<TWaspOutput> GenericInvokerAsync<TWaspOutput, TDTOOutput>(HttpRequestElement requestElement)
        {
            log.Debug($" GenericInvokerAsync Request : {JsonConvert.SerializeObject(requestElement)}");

            TWaspOutput result = default(TWaspOutput);

            var responseMessage = await httpClientRepository.ProcessRequestAsync(requestElement);

            if (responseMessage.IsSuccessStatusCode)
            {
                var response = await responseMessage.Content.ReadAsAsync<TDTOOutput>();
                result = mapper.Map<TWaspOutput>(response);

                log.Debug($" GenericInvokerAsync Response : {JsonConvert.SerializeObject(result)}");
            }
            else
            {
                log.Error($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(responseMessage)}");
                return await HandleUnsuccessfulHttpStatusResponseAsync(requestElement, result, responseMessage);
            }
            return result;
        }

        /// <summary>
        /// Generics the invoker asynchronous.
        /// </summary>
        /// <typeparam name="TWaspInput">The type of the wasp input.</typeparam>
        /// <typeparam name="TWaspOutput">The type of the wasp output.</typeparam>
        /// <typeparam name="TDTOInput">The type of the dto input.</typeparam>
        /// <typeparam name="TDTOOutput">The type of the dto output.</typeparam>
        /// <param name="requestElement">The request element.</param>
        /// <returns></returns>
        public async Task<TWaspOutput> GenericInvokerAsync<TWaspInput, TWaspOutput, TDTOInput, 
            TDTOOutput>(HttpRequestElement requestElement)
        {
            TWaspOutput result = default(TWaspOutput);
            var inputObj = mapper.Map<TDTOInput>(requestElement.RequestObject);

            var responseMessage = await httpClientRepository.ProcessRequestAsync(requestElement);

            if (responseMessage.IsSuccessStatusCode)
            {
                var response = responseMessage.Content.ReadAsAsync<TDTOOutput>();
                result = mapper.Map<TWaspOutput>(await response);
            }
            else
            {
                log.Debug($"{MethodBase.GetCurrentMethod()} Response: {JsonConvert.SerializeObject(responseMessage)}");

                return await HandleUnsuccessfulHttpStatusResponseAsync(requestElement, result, responseMessage);
            }

            return result;
        }

        /// <summary>
        /// Handles the unsuccessful HTTP status response.
        /// </summary>
        /// <typeparam name="TWaspOutput">The type of the wasp output.</typeparam>
        /// <param name="requestElement">The request element.</param>
        /// <param name="result">The result.</param>
        /// <param name="responseMessage">The response message.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">
        /// </exception>
        /// <exception cref="ProcessErrorException.InnerError">
        /// </exception>
        private async Task<TWaspOutput> HandleUnsuccessfulHttpStatusResponseAsync<TWaspOutput>(HttpRequestElement requestElement, TWaspOutput result, HttpResponseMessage responseMessage)
        {
           
            StandardMessage errorMessage = null;

            if (responseMessage.StatusCode == System.Net.HttpStatusCode.NotFound && (requestElement.Options != null && requestElement.Options.HandleList404Response))
            {
                try
                {
                    Task.Run(async () => { errorMessage = await responseMessage.Content.ReadAsAsync<StandardMessage>();}).Wait();
                    if (errorMessage == null)
                    {
                        Type primary = typeof(TWaspOutput);
                        return (TWaspOutput)Activator.CreateInstance(primary);
                    }
                    else
                    {
                        throw new ProcessErrorException(
                     errorMessage.ErrorMessage,
                     errorMessage.ErrorMessage, new List<ProcessErrorException.InnerError>
                     {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = responseMessage.StatusCode.ToString(),
                                       ErrorMessage = JsonConvert.SerializeObject(errorMessage)
                                   }
                     }
                     );
                    }
                }
                catch
                {
                    Type primary = typeof(TWaspOutput);
                    return (TWaspOutput)Activator.CreateInstance(primary);
                }
            }
            else
            {
                if (responseMessage.StatusCode == System.Net.HttpStatusCode.BadRequest)
                {
                    object badRequestResponse = await responseMessage.Content.ReadAsAsync<object>();
                    throw new ProcessErrorException(
                          responseMessage.StatusCode.ToString(),
                          responseMessage.StatusCode.ToString(), new List<ProcessErrorException.InnerError>
                          {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = responseMessage.StatusCode.ToString(),
                                       ErrorMessage = JsonConvert.SerializeObject(badRequestResponse),
                                   }
                          }
                          );
                }
            }
            throw new ProcessErrorException(
                     responseMessage.StatusCode.ToString(),
                     responseMessage.StatusCode.ToString(), new List<ProcessErrorException.InnerError>
                     {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = responseMessage.StatusCode.ToString(),
                                       ErrorMessage = JsonConvert.SerializeObject(responseMessage.ToString())
                                   }
                     }
                     );
        }
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Interface.V2;
using INS.PT.WebAPI.Model.v2;
using INS.PT.WebAPI.Model.Domain.v2;
using INS.PT.WebAPI.Model.Kpi.v2;
using INS.PT.WebAPI.Model.SearchReceipt.v2;
using INS.PT.WebAPI.Model.SumClientReceipt.v2;
using INS.PT.WebAPI.Utils;
using log4net;
using Newtonsoft.Json;
using ServiceSAPMPOS.v2;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using INS.PT.WebAPI.Data.v2;

namespace INS.PT.WebAPI.Helper.v2
{

    /// <summary>
    /// TransformationData
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.ITransformationData" />
    public class TransformationData : ITransformationData
    {
        private const int V = 9;
        private const string VPREFIX1 = "+351";
        private const string VPREFIX2 = "00351";
        private const string VPREFIX3 = "351";
        private readonly ILog Log;
        private List<Model.v2.Error> listObjectError = new List<Model.v2.Error>();
        private List<Model.v2.Error> listObjectDetailError = new List<Model.v2.Error>();
        private readonly IStatesRepository StatesRepository;
        private readonly string ConstDateFormatDateTimeNoSpace = "yyyyMMddhhmmss";

        public ILog Log1 => Log;

        /// <summary>
        /// Initializes a new instance of the <see cref="TransformationData"/> class.
        /// </summary>
        public TransformationData(IStatesRepository _statesRepository)
        {
            StatesRepository = _statesRepository;
            Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        }

        /// <summary>
        /// Inputs to kpi count asynchronous.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public async Task<ServiceSAPMPOS.v2.ZFscdMposCountV2Ws> InToKpiCountAsync(INS.PT.WebAPI.Model.Kpi.v2.InputKpi value)
        {
            ServiceSAPMPOS.v2.ZFscdMposCountV2Ws returnData = null;
            if (value != null)
            {
                returnData = new ServiceSAPMPOS.v2.ZFscdMposCountV2Ws
                {   //2019-03-08 08:10:00 => "yyyyMMddhhmmss"
                    BrokerContract = value.AgentContext.AgentId.ToString(CultureInfo.CurrentCulture),
                    LastLoginDate = ClearDate(value?.TimesTamp)
                };
            }
            return returnData;
        }

        /// <summary>
        /// Inputs to kpi.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public async Task<ServiceSAPMPOS.v2.ZFscdMposKpisV2Ws> InToKpiAsync(INS.PT.WebAPI.Model.Kpi.v2.InputKpi value)
        {
            ServiceSAPMPOS.v2.ZFscdMposKpisV2Ws returnData = null;
            if (value != null)
            {
                returnData = new ServiceSAPMPOS.v2.ZFscdMposKpisV2Ws
                {
                    BrokerContract = value.AgentContext.AgentId.ToString(CultureInfo.CurrentCulture),
                    LastLoginDate = ClearDate(value?.TimesTamp) 
                };
            }
            return returnData;
        }

        /// <summary>
        /// Inputs to search.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public async Task<ServiceSAPMPOS.v2.ZFscdMposSearchV2Ws> InToSearchAsync(Model.SearchReceipt.v2.InputSearchReceipt value)
        {
            if (value != null)
            {
                return new ServiceSAPMPOS.v2.ZFscdMposSearchV2Ws
                {
                    Context = !value.StatusType.HasValue ? "" : StringValueExtension.GetStringValue(value.StatusType),
                    BrokerContract = value.AgentContext.AgentId.ToString(CultureInfo.CurrentCulture),
                    Search = value.SearchValue,
                    ThirdParty = value.ThirdParties ? "X" : ""
                };
            }

            return null;
        }

        /// <summary>
        /// Inputs to receipt detail.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public async Task<ServiceSAPMPOS.v2.ZFscdMposKpisReceiptV2Ws> InToReceiptDetailAsync(INS.PT.WebAPI.Model.ReceiptDetail.v2.InputReceiptDetail value)
        {
            ServiceSAPMPOS.v2.ZFscdMposKpisReceiptV2Ws returnData = null;
            if (value != null)
            {
                returnData = new ServiceSAPMPOS.v2.ZFscdMposKpisReceiptV2Ws
                {
                    CompanyCode = value.CompanyId,
                    DocumentReferenceNumber = value.ReceiptId,
                    Policy = value.PolicyId,
                    BrokerContract = value.AgentContext.AgentId.ToString(CultureInfo.CurrentCulture)
                };
            }
            return returnData;
        }

        /// <summary>
        /// Inputs to kpi detail.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public async Task<ServiceSAPMPOS.v2.ZFscdMposKpisDetailV2Ws> InToKpiDetailAsync(INS.PT.WebAPI.Model.SumClientReceipt.v2.InputSumClientReceipt value)
        {
            ServiceSAPMPOS.v2.ZFscdMposKpisDetailV2Ws returnData = null;
            if (value != null)
            {
                returnData = new ServiceSAPMPOS.v2.ZFscdMposKpisDetailV2Ws
                {
                    Context = StringValueExtension.GetStringValue(value.Type),
                    BrokerContract = value.AgentContext.AgentId.ToString(CultureInfo.CurrentCulture)
                };
            }
            return returnData;
        }

        /// <summary>
        /// Inputs to kpis nfis.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public async Task<ServiceSAPMPOS.v2.ZFscdMposKpisNifsV2Ws> InToKpisNfisAsync(Model.ClientReceipts.v2.InputClientReceipts value)
        {
            ServiceSAPMPOS.v2.ZFscdMposKpisNifsV2Ws returnData = null;
            if (value != null)
            {
                returnData = new ServiceSAPMPOS.v2.ZFscdMposKpisNifsV2Ws
                {
                    TaxNumber = value.Nif,
                    Context = StringValueExtension.GetStringValue(value.Type),
                    BrokerContract = value.AgentContext.AgentId.ToString(CultureInfo.CurrentCulture)
                };
            }
            return returnData;
        }

        /// <summary>
        /// Inputs to charged.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public async Task<ServiceSAPMPOS.v2.ZFscdMposPostV2Ws> InToPaymentPostAsync(INS.PT.WebAPI.Model.PaymentPost.v2.InputPaymentPost value)
        {
            List<ZfscdReciboMposPostLinha> ListMposPostLinha = new List<ServiceSAPMPOS.v2.ZfscdReciboMposPostLinha>();

            ServiceSAPMPOS.v2.ZFscdMposPostV2Ws returnData = null;
            
            if (value != null)
            {
                if (value.Receipts.Collections.Count > 0)
                {
                    foreach (INS.PT.WebAPI.Model.PaymentPost.v2.CollectPaymentPost collect in value.Receipts.Collections)
                    {
                        ZfscdReciboMposPostLinha MposPostLinha = new ZfscdReciboMposPostLinha
                        {
                            DocumentPrefix = collect.DocumentPrefix,
                            Policy = collect.PolicyId,
                            DocumentReferenceNumber = collect.DocumentReferenceNumber,
                            Amount = collect.Amount,
                            ThirdParty = collect.ThirdParty.ToString()
                        };
                        ListMposPostLinha.Add(MposPostLinha);
                    }
                }

                returnData = new ServiceSAPMPOS.v2.ZFscdMposPostV2Ws
                {
                    BrokerContract = value.AgentContext.AgentId.ToString(CultureInfo.CurrentCulture),
                    PaymentPostSimulation = value.IsValidation.ToString(CultureInfo.CurrentCulture),
                    Proposal = value.Proposal.ToString(CultureInfo.CurrentCulture),
                    Receipts = new ZfscdReciboMposLinha
                    {
                        OriginalAplication = value.Receipts.OriginalAplication,
                        CompanyCode = value.Receipts.CompanyId,
                        MposTypeCode = value.Receipts.PaymentBrand,
                        NepMpos = value.Receipts.NepMpos,
                        NepSibs = value.Receipts.NepSibs,
                        SibsEntity = value.Receipts.SibsEntity,
                        SibsReference = value.Receipts.SibsReference,
                        PhoneId = value.Receipts.PhoneId,
                        TerminalId = value.Receipts.TerminalId,
                        PrinterMode = value.Receipts.PrinterMode,
                        Amount = value.Receipts.Amount,
                        Collect = ListMposPostLinha?.ToArray()
                    }
                };
            }

            //Aqui


            return returnData;
        }

        /// <summary>
        /// Outputs to kpi detail.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        public async Task<OutputSumClientReceipt> OutToKpiDetailAsync(ServiceSAPMPOS.v2.ZFscdMposKpisDetailV2WsResponse1 ResponseSAP)
        {
            List<Model.v2.ClientRef> receipts = new List<ClientRef>();
            GlobalEntityMposInformationInput Entities = new GlobalEntityMposInformationInput();

            //Lisar todos os entities, oriundo do método search
            if (ResponseSAP?.ZFscdMposKpisDetailV2WsResponse.KpisDetail.Length > 0)
            {
                Entities.EntitiesIds = new List<string>();
                foreach (var item in ResponseSAP?.ZFscdMposKpisDetailV2WsResponse.KpisDetail)
                {
                    if (!string.IsNullOrEmpty(item.Nif))
                    {
                        Entities.EntitiesIds.Add(item.Nif);
                    }
                }

            }

            //Chama o GlobalEntity
            List<GlobalEntityMposInformationOutput> listEntities = new List<GlobalEntityMposInformationOutput>();
            if (Entities.EntitiesIds != null)
            {
                listEntities = await StatesRepository.GetListEntitiesAsync(Entities);
            }
            //Chamar o método do globalentity e mesclar as informações do objeto

            if (ResponseSAP?.ZFscdMposKpisDetailV2WsResponse?.KpisDetail?.Length > 0)
            {
                receipts = new List<Model.v2.ClientRef>();
                foreach (ZfscdMposKpisClientLinha item in ResponseSAP?.ZFscdMposKpisDetailV2WsResponse?.KpisDetail)
                {
                    var objElement = new ClientRef
                    {
                        Amount = item.Amount,
                        Quantity = item.Quantity,
                        ThirdParty = false
                    };
                    var entitiesElement = listEntities.FirstOrDefault(x => x.VatNumber == item.Nif);
                    if (entitiesElement != null && !string.IsNullOrEmpty(entitiesElement.VatNumber))
                    {
                        entitiesElement = string.IsNullOrEmpty(entitiesElement.VatNumber) ? listEntities.FirstOrDefault(x => x.VatNumber == item.Nif) : entitiesElement;
                        objElement.Address = entitiesElement.Address;
                        objElement.Email = entitiesElement.EmailAddress;
                        objElement.Location = entitiesElement.Georeference;
                        objElement.Name = entitiesElement.Name;
                        objElement.Nif = entitiesElement.VatNumber;
                        objElement.Phone = entitiesElement.PhoneNumber;
                        objElement.PostalCode = entitiesElement.PostalCode;
                    }
                    else
                    {
                        objElement.Address = item.Address;
                        objElement.Email = item.Email;
                        objElement.Location = item.Location;
                        objElement.Name = item.Name;
                        objElement.Nif = item.Nif;
                        objElement.Phone = ClearPhoneNumber(item.Phone);
                        objElement.PostalCode = item.PostalCode;
                    }
                    receipts.Add(objElement);
                }

                if (ResponseSAP?.ZFscdMposKpisDetailV2WsResponse.Errors.Length > 0)
                {
                    listObjectError = new List<Model.v2.Error>
                {
                    new Model.v2.Error
                    {
                        ErrorCode = ResponseSAP?.ZFscdMposKpisDetailV2WsResponse.Errors[0].ErrorCode,
                        ErrorMessage = ResponseSAP?.ZFscdMposKpisDetailV2WsResponse.Errors[0].ErrorCodeTxt,
                    }
                    };
                }
            }
            INS.PT.WebAPI.Model.SumClientReceipt.v2.OutputSumClientReceipt returnData = new INS.PT.WebAPI.Model.SumClientReceipt.v2.OutputSumClientReceipt
            {
                ClientRefs = receipts?.ToList(),
                Errors = listObjectError?.ToList()
            };
            return returnData;
        }

        /// <summary>
        /// Outputs to kpi.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        public async Task<OutPutKpi> OutToKpiAsync(ServiceSAPMPOS.v2.ZFscdMposKpisV2WsResponse1 ResponseSAP)
        {
            List<Model.v2.KpiElement> ListKpi = new List<Model.v2.KpiElement>
            {
                ResponseSAP?.ZFscdMposKpisV2WsResponse.Summary.OpenItemRiskAmount > 0 ? new Model.v2.KpiElement
                {
                    //Recibos risco de anulação
                    Type = EnumContextType.Anulacao.ToString(),
                    Amount = ResponseSAP?.ZFscdMposKpisV2WsResponse?.Summary?.OpenItemRiskAmount,
                    Quantity = ResponseSAP?.ZFscdMposKpisV2WsResponse.Summary.OpenItemRiskTotal
                } : new Model.v2.KpiElement
                {
                    //Recibos risco de anulação
                    Type = EnumContextType.Anulacao.ToString(),
                    Amount = 0,
                    Quantity = 0
                },

                ResponseSAP?.ZFscdMposKpisV2WsResponse.Summary.OpenItemAmount > 0 ? new Model.v2.KpiElement
                {
                    //Recibos por cobrar
                    Type = EnumContextType.Cobrar.ToString(),
                    Amount = ResponseSAP?.ZFscdMposKpisV2WsResponse.Summary.OpenItemAmount,
                    Quantity = ResponseSAP?.ZFscdMposKpisV2WsResponse.Summary.OpenItemTotal
                } : new Model.v2.KpiElement
                {

                    Type = EnumContextType.Cobrar.ToString(),
                    Amount = 0,
                    Quantity = 0
                },
                ResponseSAP?.ZFscdMposKpisV2WsResponse.Summary.NotOpenItemAmount > 0 ? new Model.v2.KpiElement
                {
                    //Recibos cobrados
                    Type = EnumContextType.Cobrados.ToString(),
                    Amount = ResponseSAP?.ZFscdMposKpisV2WsResponse.Summary.NotOpenItemAmount,
                    Quantity = ResponseSAP?.ZFscdMposKpisV2WsResponse.Summary.NotOpenItemTotal
                } : new Model.v2.KpiElement
                {
                    //Recibos cobrados
                    Type = EnumContextType.Cobrados.ToString(),
                    Amount = 0,
                    Quantity = 0
                },


                ResponseSAP?.ZFscdMposKpisV2WsResponse.Summary.LastLoginTotal > 0 ? new Model.v2.KpiElement
                {
                    Type = EnumContextType.Novos.ToString(),
                    Amount = null,
                    Quantity = ResponseSAP?.ZFscdMposKpisV2WsResponse.Summary.LastLoginTotal
                } : new Model.v2.KpiElement
                {
                    Type = EnumContextType.Novos.ToString(),
                    Amount = null,
                    Quantity = 0
                }
            };

            if (ResponseSAP?.ZFscdMposKpisV2WsResponse.Errors.Length > 0)
            {
                listObjectError = new List<Model.v2.Error>();
                foreach (ZfscdCodigosErroLinha item in ResponseSAP.ZFscdMposKpisV2WsResponse.Errors)
                {
                    listObjectError.Add(new Model.v2.Error
                    {
                        ErrorCode = item.ErrorCode,
                        ErrorMessage = item.ErrorCodeTxt,
                    });
                }

            }

            INS.PT.WebAPI.Model.Kpi.v2.OutPutKpi returnData = null;
            returnData = new INS.PT.WebAPI.Model.Kpi.v2.OutPutKpi
            {
                KpiList = ListKpi?.ToList(),
                Errors = listObjectError?.ToList()
            };
            return returnData;
        }

        /// <summary>
        /// </summary>
        /// <param name="InputSearchMatch"></param>
        /// <param name="ResponseSAP"></param>
        /// <returns></returns>
        public async Task<OutPutSearchReceipt> OutToSearchNewAsync(string InputSearchMatch, ServiceSAPMPOS.v2.ZFscdMposSearchV2WsResponse1 ResponseSAP)
        {
            ClientRef ObjClientRef = null;
            List<Model.v2.Receipt> listReceipts = null;
            string branchName = null;
            List<Model.v2.Policy> listPolicies = null;
            List<Model.v2.Company> listCompany = null;
            GlobalEntityMposInformationInput Entities = new GlobalEntityMposInformationInput();

            //Erros
            if (ResponseSAP?.ZFscdMposSearchV2WsResponse.Errors.Length > 0)
            {
                Log.Error($" ZFscdMposSearchWsResponse Response : {JsonConvert.SerializeObject(ResponseSAP)}");

                listObjectError = new List<Error>();

                foreach (ZfscdCodigosErroLinha item in ResponseSAP?.ZFscdMposSearchV2WsResponse.Errors)
                {
                    listObjectError.Add(new Model.v2.Error
                    {
                        ErrorCode = item.ErrorCode,
                        ErrorMessage = item.ErrorCodeTxt,
                    });
                }
            }

            if (ResponseSAP?.ZFscdMposSearchV2WsResponse.Companies.Length > 0)
            {
                Log.Debug($" ZFscdMposSearchWsResponse Response : {JsonConvert.SerializeObject(ResponseSAP)}");

                listCompany = new List<Company>();
                //receipts
                foreach (ServiceSAPMPOS.v2.ZfscdMposKpisDetailLinha kpiDetailCompanies in ResponseSAP?.ZFscdMposSearchV2WsResponse.Companies)
                {
                    if (kpiDetailCompanies.Policies.Length > 0)
                    {
                        listPolicies = new List<Policy>();
                        Boolean SearchMatchOutputPolice = false;
                        foreach (ServiceSAPMPOS.v2.ZfscdMposKpisPolicyLinha policies in kpiDetailCompanies.Policies)
                        {

                            if (policies.Receipts.Length > 0)
                            {
                                listReceipts = new List<Receipt>();
                                Boolean SearchMatchOutputReceipt = false;
                                foreach (ServiceSAPMPOS.v2.ZfscdMposKpisReceiptLinha receipt in policies.Receipts)
                                {
                                    if ((InputSearchMatch == receipt.Policy) || (InputSearchMatch == receipt.DocumentReferenceNumber))
                                    {
                                        SearchMatchOutputReceipt = true;
                                    }

                                    var expiryDate = ValidateDateTime.ToCorrectDateTime(receipt.BillingPeriodTo, "");
                                    var issueDate = ValidateDateTime.ToCorrectDateTime(receipt.EmissionDate, receipt.EmissionHour);

                                    var limitHourDate = ValidateDateTime.ToCorrectDateTime(receipt.SibsDueDate, receipt.SibsDueHour);

                                    listReceipts.Add(
                                        new Model.v2.Receipt
                                        {
                                            CompanyId = receipt.CompanyCode,
                                            CompanyDes = EntityDesc.GetDescCompany(receipt.CompanyCode),
                                            PolicyId = receipt.Policy,
                                            ReceiptId = receipt.DocumentReferenceNumber,
                                            Amount = receipt.TotalValue,
                                            BillableType = receipt.PaymentStatus,
                                            Branch = receipt.InsuranceTypeName,
                                            ExpiryDate = expiryDate,
                                            IssueDate = issueDate,
                                            Pdf = receipt.DocumentId,
                                            ReceiptStatus = receipt.ReceiptStatus,
                                            AppOrigemId = receipt.SourceAplication,
                                            Status = receipt.ReceiptStatus,//receipt.FlagStatus,
                                            SearchMatch = SearchMatchOutputReceipt,
                                            Data_Limite = limitHourDate

                                        }
                                     );
                                    branchName = receipt.InsuranceTypeName;
                                }
                            }

                            //Incluir Police 
                            if (InputSearchMatch == policies.Policy)
                            {
                                SearchMatchOutputPolice = true;
                            }

                            listPolicies.Add(new Model.v2.Policy
                            {
                                Amount = policies.Amount,
                                Branch = branchName,
                                InsuredObject = policies.InsuredObject,
                                InsuredType = policies.InsuredType,
                                NoReceipts = policies.Total,
                                PolicyId = policies.Policy,
                                SearchMatch = SearchMatchOutputPolice,
                                Receipts = listReceipts?.ToList()
                            });

                        }
                    }

                    listCompany.Add(new Company
                    {
                        Amount = kpiDetailCompanies.Amount,
                        CompanyId = kpiDetailCompanies.CompanyCode,
                        CompanyDes = EntityDesc.GetDescCompany(kpiDetailCompanies.CompanyCode),
                        Policies = listPolicies?.ToList()
                    });
                }

            }

            //ClientRef
            if (ResponseSAP.ZFscdMposSearchV2WsResponse.ClientReference != null)
            {
                Entities.EntitiesIds = new List<string>();

                if (!string.IsNullOrEmpty(ResponseSAP.ZFscdMposSearchV2WsResponse.ClientReference.Nif))
                {
                    Entities.EntitiesIds.Add(ResponseSAP.ZFscdMposSearchV2WsResponse.ClientReference.Nif);
                }

                List<GlobalEntityMposInformationOutput> listEntities = new List<GlobalEntityMposInformationOutput>();
                
                if (Entities.EntitiesIds.Count > 0)
                {
                    listEntities = await StatesRepository.GetListEntitiesAsync(Entities);
                }

                ObjClientRef = new ClientRef();

                ObjClientRef.Amount = ResponseSAP.ZFscdMposSearchV2WsResponse.ClientReference.Amount;
                ObjClientRef.Quantity = ResponseSAP.ZFscdMposSearchV2WsResponse.ClientReference.Quantity;
                ObjClientRef.ThirdParty = ResponseSAP.ZFscdMposSearchV2WsResponse.ClientReference.ThirdParty == "X" ? true : false;

                var entitiesElement = listEntities?.FirstOrDefault(x => x.VatNumber == ResponseSAP.ZFscdMposSearchV2WsResponse.ClientReference.Nif);

                if (entitiesElement != null && !string.IsNullOrEmpty(entitiesElement.VatNumber))
                {
                    Log.Debug($"Global Entity - GetListEntitiesAsync Response : {JsonConvert.SerializeObject(entitiesElement)}");

                    if (string.IsNullOrEmpty(entitiesElement.VatNumber))
                    {
                        entitiesElement = listEntities.FirstOrDefault(x => x.VatNumber == ResponseSAP.ZFscdMposSearchV2WsResponse.ClientReference.Nif);
                    }

                    ObjClientRef.Address = entitiesElement.Address;
                    ObjClientRef.Email = entitiesElement.EmailAddress;
                    ObjClientRef.Location = entitiesElement.Georeference;
                    ObjClientRef.Name = entitiesElement.Name;
                    ObjClientRef.Nif = entitiesElement.VatNumber;
                    ObjClientRef.Phone = entitiesElement.PhoneNumber;
                    ObjClientRef.PostalCode = entitiesElement.PostalCode;
                }
                else
                {
                    Log.Debug($"SAP - GetListEntitiesAsync Response : {JsonConvert.SerializeObject(ResponseSAP)}");

                    ObjClientRef.Address = ResponseSAP.ZFscdMposSearchV2WsResponse.ClientReference.Address;
                    ObjClientRef.Email = ResponseSAP.ZFscdMposSearchV2WsResponse.ClientReference.Email;
                    ObjClientRef.Location = ResponseSAP.ZFscdMposSearchV2WsResponse.ClientReference.Location;
                    ObjClientRef.Name = ResponseSAP.ZFscdMposSearchV2WsResponse.ClientReference.Name;
                    ObjClientRef.Nif = ResponseSAP.ZFscdMposSearchV2WsResponse.ClientReference.Nif;
                    ObjClientRef.Phone = ClearPhoneNumber(ResponseSAP.ZFscdMposSearchV2WsResponse.ClientReference.Phone);
                    ObjClientRef.PostalCode = ResponseSAP.ZFscdMposSearchV2WsResponse.ClientReference.PostalCode;
                }
            }

            //Object
            INS.PT.WebAPI.Model.SearchReceipt.v2.OutPutSearchReceipt returnData = null;
            returnData = new INS.PT.WebAPI.Model.SearchReceipt.v2.OutPutSearchReceipt
            {
                ClientRef = ObjClientRef ?? null,
                Companies = listCompany?.ToList(),
                Errors = listObjectError?.ToList()
            };

            return returnData;
        }

        /// <summary>
        /// Outputs to receipt detail.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        public async Task<INS.PT.WebAPI.Model.ReceiptDetail.v2.OutPutReceiptDetail> OutToReceiptDetailAsync(ServiceSAPMPOS.v2.ZFscdMposKpisReceiptV2WsResponse1 ResponseSAP)
        {

            if ((ResponseSAP != null) && (ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.Errors.Length > 0))
            {
                listObjectError = new List<Error>();
                foreach (ZfscdCodigosErroLinha item in ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.Errors)
                {
                    listObjectError.Add(
                        new Model.v2.Error
                        {
                            ErrorCode = item.ErrorCode,
                            ErrorMessage = item.ErrorCodeTxt,
                        }
                   );
                }
            }

            INS.PT.WebAPI.Model.ReceiptDetail.v2.OutPutReceiptDetail returnData = null;
            if ((ResponseSAP?.ZFscdMposKpisReceiptV2WsResponse?.KpisDetailReceipt != null))
            {
                if (!string.IsNullOrEmpty(ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.CompanyCode))
                {

                    returnData = new INS.PT.WebAPI.Model.ReceiptDetail.v2.OutPutReceiptDetail
                    {
                        CompanyId = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.CompanyCode,
                        CompanyDes = EntityDesc.GetDescCompany(ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.CompanyCode),
                        PolicyId = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.Policy,
                        ReceiptId = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.DocumentReferenceNumber,
                        ClientName = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.Name,
                        Situation = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.SituationCodeDescription,
                        Fractionation = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.BillingFrequency,
                        Type = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.ReceiptTypeDesc,
                        BillingLocation = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.CollectionLocal,

                        Entity = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.Entity,
                        Reference = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.Reference,
                        ReferenceTotal = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.TotalValue,

                        PaymentStatus = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.PaymentStatus,
                        LifeCharges = 0,

                        CommercialPremium = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.PremiumAmount,
                        Costs = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.CostValue,
                        BonusMalus = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.BonusValue,
                        Taxes = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.TaxValue,
                        Additional = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.ExtraValue,

                        Total = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.TotalValue,

                        CapitalAndReceipt = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.Capital,

                        Fundraising = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.AgentCommissionValue,
                        Collections = ResponseSAP.ZFscdMposKpisReceiptV2WsResponse.KpisDetailReceipt.BrokerCommissionValue,

                        Errors = listObjectError?.ToList()
                    };
                }
            }

            return returnData;
        }

        /// <summary>
        /// Outputs to kpis nfis.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        public async Task<Model.ClientReceipts.v2.OutPutClientReceipts> OutToKpisNfisAsync(ServiceSAPMPOS.v2.ZFscdMposKpisNifsV2WsResponse1 ResponseSAP)
        {
            //erro
            string branchName = null;

            Model.ClientReceipts.v2.OutPutClientReceipts returnData = null;
            List<Model.v2.Receipt> listReceipts = null;
            List<Model.v2.Policy> listPolicies = null;
            List<Model.v2.Company> listcompany = new List<Company>();

            if (ResponseSAP != null)
            {
                if (ResponseSAP.ZFscdMposKpisNifsV2WsResponse.Errors.Length > 0)
                {
                    listObjectError = new List<Model.v2.Error>();
                    foreach (ZfscdCodigosErroLinha item in ResponseSAP.ZFscdMposKpisNifsV2WsResponse.Errors)
                    {
                        listObjectError.Add(
                            new Model.v2.Error
                            {
                                ErrorCode = item.ErrorCode,
                                ErrorMessage = item.ErrorCodeTxt,
                            }
                            );
                    }
                }

                //Detail
                if (ResponseSAP.ZFscdMposKpisNifsV2WsResponse.KpisDetail.Length > 0)
                {
                    //Company
                    foreach (ZfscdMposKpisDetailLinha kpiDetail in ResponseSAP.ZFscdMposKpisNifsV2WsResponse.KpisDetail)
                    {
                        listPolicies = new List<Policy>();
                        foreach (ZfscdMposKpisPolicyLinha policies in kpiDetail.Policies)
                        {
                            listReceipts = new List<Receipt>();
                            foreach (ZfscdMposKpisReceiptLinha receipt in policies.Receipts)
                            {
                                var expiryDate = ValidateDateTime.ToCorrectDateTime(receipt.BillingPeriodTo, "");
                                var issueDate = ValidateDateTime.ToCorrectDateTime(receipt.EmissionDate, receipt.EmissionHour);

                                var limitHourDate = ValidateDateTime.ToCorrectDateTime(receipt.SibsDueDate, receipt.SibsDueHour);

                                listReceipts.Add(
                                    new Model.v2.Receipt
                                    {
                                        CompanyId = receipt.CompanyCode,
                                        CompanyDes = EntityDesc.GetDescCompany(receipt.CompanyCode),
                                        PolicyId = receipt.Policy,
                                        ReceiptId = receipt.DocumentReferenceNumber,
                                        Amount = receipt.TotalValue,
                                        BillableType = receipt.PaymentStatus,
                                        Branch = receipt.InsuranceTypeName,
                                        ExpiryDate = expiryDate,
                                        IssueDate = issueDate,
                                        Pdf = receipt.DocumentId,
                                        ReceiptStatus = receipt.ReceiptStatus,
                                        AppOrigemId = receipt.SourceAplication,
                                        Status = receipt.ReceiptStatus,
                                        SearchMatch = false,
                                        Type = receipt.ReceiptStatus,
                                        Data_Limite = limitHourDate
                                    }
                                );

                                branchName = receipt.InsuranceTypeName;
                            }
                            //        //Apolices
                            listPolicies.Add(new Model.v2.Policy
                            {
                                Amount = policies.Amount,
                                Branch = branchName,
                                InsuredObject = policies.InsuredObject,
                                InsuredType = policies.InsuredType,
                                NoReceipts = policies.Total,
                                PolicyId = policies.Policy,
                                SearchMatch = false,
                                Receipts = listReceipts?.ToList()
                            });
                        }

                        listcompany.Add(new Model.v2.Company
                        {
                            Amount = kpiDetail.Amount,
                            CompanyId = kpiDetail.CompanyCode,
                            CompanyDes = EntityDesc.GetDescCompany(kpiDetail.CompanyCode),
                            Policies = listPolicies?.ToList()
                        });

                    }
                }
                returnData = new Model.ClientReceipts.v2.OutPutClientReceipts
                {
                    Companies = listcompany?.ToList(),
                    Errors = listObjectError?.ToList()
                };
            }
            return returnData;
        }

        /// <summary>
        /// Outs to charged asynchronous.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        public async Task<INS.PT.WebAPI.Model.PaymentPost.v2.OutPutPaymentPost> OutToPaymentPostAsync(ServiceSAPMPOS.v2.ZFscdMposPostV2WsResponse1 ResponseSAP)
        {

            List<INS.PT.WebAPI.Model.PaymentPost.v2.ReceiptCollectPos> listReceipts = null;
            INS.PT.WebAPI.Model.PaymentPost.v2.OutPutPaymentPost returnData = null;
            INS.PT.WebAPI.Model.PaymentPost.v2.ReceiptPosLn ReceiptPosLn = null;

            if (ResponseSAP != null)
            {
                if (ResponseSAP.ZFscdMposPostV2WsResponse.Errors.Length > 0)
                {
                    listObjectError = new List<Error>();
                    foreach (ZfscdCodigosErroLinha item in ResponseSAP.ZFscdMposPostV2WsResponse.Errors)
                    {
                        listObjectError.Add(new Model.v2.Error
                        {
                            ErrorCode = item.ErrorCode,
                            ErrorMessage = item.ErrorCodeTxt,
                        });
                    }
                }
                if (ResponseSAP.ZFscdMposPostV2WsResponse.Receipts.Errors.Length > 0)
                {
                    listObjectDetailError = new List<Error>();
                    foreach (ZfscdCodigosErroLinha item in ResponseSAP.ZFscdMposPostV2WsResponse.Receipts.Errors)
                    {
                        listObjectDetailError.Add(new Model.v2.Error
                        {
                            ErrorCode = item.ErrorCode,
                            ErrorMessage = item.ErrorCodeTxt,
                        });
                    }
                }

                if (ResponseSAP.ZFscdMposPostV2WsResponse.Receipts.Collect.Length > 0)
                {
                    listReceipts = new List<INS.PT.WebAPI.Model.PaymentPost.v2.ReceiptCollectPos >();
                    foreach (ZfscdReciboMposPostLinha item in ResponseSAP.ZFscdMposPostV2WsResponse.Receipts.Collect)
                    {
                        listReceipts.Add(new INS.PT.WebAPI.Model.PaymentPost.v2.ReceiptCollectPos
                        {
                            DocumentPrefix = item.DocumentPrefix,
                            Policy = item.Policy,
                            DocumentReferenceNumber = item.DocumentReferenceNumber,
                            Amount = item.Amount,
                            ThirdParty = item.ThirdParty
                        });
                    }

                }

                if ((ResponseSAP.ZFscdMposPostV2WsResponse.Receipts != null))
                {
                    if (!string.IsNullOrEmpty(ResponseSAP.ZFscdMposPostV2WsResponse.Receipts.CompanyCode))
                    {

                        ReceiptPosLn = new INS.PT.WebAPI.Model.PaymentPost.v2.ReceiptPosLn
                        {
                            OriginalAplication = ResponseSAP.ZFscdMposPostV2WsResponse.Receipts.OriginalAplication,
                            CompanyCode = EntityDesc.GetDescCompany(ResponseSAP.ZFscdMposPostV2WsResponse.Receipts.CompanyCode),
                            MposTypeCode = ResponseSAP.ZFscdMposPostV2WsResponse.Receipts.MposTypeCode,
                            NepMpos = ResponseSAP.ZFscdMposPostV2WsResponse.Receipts.NepMpos,
                            NepSibs = ResponseSAP.ZFscdMposPostV2WsResponse.Receipts.NepSibs,
                            SibsEntity = ResponseSAP.ZFscdMposPostV2WsResponse.Receipts.SibsEntity,
                            SibsReference = ResponseSAP.ZFscdMposPostV2WsResponse.Receipts.SibsReference,
                            PhoneId = ResponseSAP.ZFscdMposPostV2WsResponse.Receipts.PhoneId,
                            TerminalId = ResponseSAP.ZFscdMposPostV2WsResponse.Receipts.TerminalId,
                            PrinterMode = ResponseSAP.ZFscdMposPostV2WsResponse.Receipts.PrinterMode,
                            Amount = ResponseSAP.ZFscdMposPostV2WsResponse.Receipts.Amount,
                            collections = listReceipts?.ToList(),
                            errors = listObjectDetailError?.ToList()
                        };

                        returnData = new INS.PT.WebAPI.Model.PaymentPost.v2.OutPutPaymentPost
                        {
                            Receipt = ReceiptPosLn,
                            Errors = listObjectError?.ToList()
                        };
                    }
                    else
                    {
                        returnData = new INS.PT.WebAPI.Model.PaymentPost.v2.OutPutPaymentPost
                        {
                            Receipt = null,
                            Errors = listObjectError?.ToList()
                        };
                    }
                }
            }

            return returnData;
        }

        public static string ClearPhoneNumber(string phoneNumber)
        {
            string PhoneNumber = string.Empty;

            // check for the phones that are not with 9 digits
            if (phoneNumber?.Length > 0 && (phoneNumber?.Length != V || !phoneNumber.StartsWith('9')))
            {
                if (phoneNumber.StartsWith(VPREFIX1, StringComparison.InvariantCultureIgnoreCase)
                    || phoneNumber.StartsWith("00351", StringComparison.InvariantCultureIgnoreCase)
                    || phoneNumber.StartsWith("351", StringComparison.InvariantCultureIgnoreCase))
                {
                    // PT phone number but just leave the 9 right digits
                    PhoneNumber = phoneNumber.Substring(phoneNumber.Length - V);
                }
                else
                {   // invalid phone number, just clear
                    PhoneNumber = string.Empty;
                }
            }
            return PhoneNumber;
        }

        public static string ClearDate(string dateString)
        {
            //2019-03-08 08:10:00 => "yyyyMMddhhmmss"
            return dateString.Replace(" ", "").Replace("-", "").Replace(":", "");
        }

    }
}



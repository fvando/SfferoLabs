﻿using ins.pt.WebAPI;
using INS.PT.WebAPI.Configurations;
using INS.PT.WebAPI.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Helper
{
    public class GenericProxy<TContract> : IGenericProxy, IDisposable where TContract : class
    {
        private TContract _channel;
        private ChannelFactory<TContract> _channelFactory;        

        public GenericProxy(ApplicationSettings configuration)
        {            
            var binding = new BasicHttpsBinding(BasicHttpsSecurityMode.Transport);
            binding.MaxReceivedMessageSize = int.MaxValue;
            EndpointAddress address = new EndpointAddress(configuration.BrokerSettings.SoapEndPoint);
            _channelFactory = new ChannelFactory<TContract>(binding, address);
        }

        public GenericProxy(Binding binding, EndpointAddress remoteAddress)
        {
            _channelFactory = new ChannelFactory<TContract>(binding, remoteAddress);
        }

        public void Execute(Action<TContract> action)
        {
            action.Invoke(Channel);
        }

        public TResult Execute<TResult>(Func<TContract, TResult> function)
        {
            return function.Invoke(Channel);
        }

        private TContract Channel
        {
            get
            {
                if (_channel == null)
                {
                    _channel = _channelFactory.CreateChannel();
                }

                return _channel;
            }
        }

        public void Dispose()
        {
            try
            {
                if (_channel != null)
                {
                    var currentChannel = _channel as IClientChannel;
                    if (currentChannel.State == CommunicationState.Faulted)
                    {
                        currentChannel.Abort();
                    }
                    else
                    {
                        currentChannel.Close();
                    }
                }
            }
            finally
            {
                _channel = null;
                GC.SuppressFinalize(this);
            }
        }        
    }
}

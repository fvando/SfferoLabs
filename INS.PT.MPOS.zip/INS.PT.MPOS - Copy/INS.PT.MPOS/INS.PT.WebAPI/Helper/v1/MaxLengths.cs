﻿// Copyright Ageas 2019 © - Integration Team

namespace INS.PT.WebAPI.Models.v1
{
    /// <summary>
    /// MaxLengths
    /// </summary>
    internal static class MaxLengths
    {
        /// <summary>
        /// The agend identifier maximum length
        /// </summary>
        public const int AgendIdMaxLength = 5;
        /// <summary>
        /// The policy identifier maximum length
        /// </summary>
        public const int PolicyIdMaxLength = 20;
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Interface.V1;
using INS.PT.WebAPI.Models.AgentsPortal.Agent.Elements;
using log4net;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using System.Linq;
using INS.PT.WebAPI.Model.v1;

namespace INS.PT.WebAPI.Helper.v1
{
    /// <summary>
    /// EntityHelper
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.IEntityHelper" />
    public class EntityHelper : IEntityHelper
    {
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog Log;
        /// <summary>
        /// Initializes a new instance of the <see cref="EntityHelper"/> class.
        /// </summary>
        public EntityHelper()
        {
            Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        }

        /// <summary>
        /// Gets the agents from commercial structure.
        /// </summary>
        /// <param name="commercialStructure">The commercial structure.</param>
        /// <returns></returns>
        public async Task<List<AgentCSElement>> GetAgentsFromCommercialStructureAsync(List<CompanyCSElement> commercialStructure)
        {
            //Logging Default
            Log.Debug($"{MethodBase.GetCurrentMethod()?.ReflectedType?.ReflectedType?.FullName} Request: {commercialStructure?.ToList()}");

            List<AgentCSElement> agentList = new List<AgentCSElement>();
            try
            {
                if (commercialStructure != null)
                {
                    foreach (CompanyCSElement company in commercialStructure)
                    {
                        agentList.AddRange(from NetWorkCSElement network in company?.Networks
                                           from ZoneCSElement zone in network?.Zones
                                           from BranchCSElement branch in zone?.Branches
                                           from InspectorCSElement inspector in branch?.Inspectors
                                           from AgentCSElement agent in inspector?.Agents
                                           where agent?.Status == "Activo"
                                           select agent);
                    }
                }

                Log.Debug($"{MethodBase.GetCurrentMethod()?.ReflectedType?.ReflectedType?.FullName} Response: {agentList?.ToList()}");
                return agentList;
            }
            catch (ProcessErrorException processError)
            {
                Log.Error($"{MethodBase.GetCurrentMethod()?.ReflectedType?.ReflectedType?.FullName}: {processError}");
                throw;
            }
            catch (AggregateException validateErrors)
            {
                Log.Error($"{MethodBase.GetCurrentMethod()?.ReflectedType?.ReflectedType?.FullName}: {validateErrors}");
                throw;
            }
            catch (Exception e)
            {
                Log.Error($"{MethodBase.GetCurrentMethod()?.ReflectedType?.ReflectedType?.FullName}: {e}");
                throw;
            }
            finally
            {
                Log.Debug($"{MethodBase.GetCurrentMethod()?.ReflectedType?.ReflectedType?.FullName}: {"Finish"}");
            }
        }
    }
}

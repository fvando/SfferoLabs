﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Interface.V1;
using INS.PT.WebAPI.Model.v1;
using INS.PT.WebAPI.Model.Domain.v1;
using INS.PT.WebAPI.Model.Kpi.v1;
using INS.PT.WebAPI.Model.SearchReceipt.v1;
using INS.PT.WebAPI.Model.SumClientReceipt.v1;
using INS.PT.WebAPI.Utils;
using log4net;
using Newtonsoft.Json;
using ServiceSAPMPOS.v1;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using INS.PT.WebAPI.Data.v1;

namespace INS.PT.WebAPI.Helper.v1
{

    /// <summary>
    /// TransformationData
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Interface.ITransformationData" />
    public class TransformationData : ITransformationData
    {
        private const int V = 9;
        private const string VPREFIX1 = "+351";
        private const string VPREFIX2 = "00351";
        private const string VPREFIX3 = "351";
        private readonly ILog Log;
        private List<Model.v1.Error> listObjectError = new List<Model.v1.Error>();
        private List<Model.v1.Error> listObjectDetailError = new List<Model.v1.Error>();
        private readonly IStatesRepository StatesRepository;
        private readonly string ConstDateFormatDateTimeNoSpace = "yyyyMMddhhmmss";

        public ILog Log1 => Log;

        /// <summary>
        /// Initializes a new instance of the <see cref="TransformationData"/> class.
        /// </summary>
        public TransformationData(IStatesRepository _statesRepository)
        {
            StatesRepository = _statesRepository;
            Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        }

        /// <summary>
        /// Inputs to kpi count asynchronous.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public async Task<ServiceSAPMPOS.v1.ZFscdMposCountV1Ws> InToKpiCountAsync(INS.PT.WebAPI.Model.Kpi.v1.InputKpi value)
        {
            ServiceSAPMPOS.v1.ZFscdMposCountV1Ws returnData = null;
            if (value != null)
            {
                returnData = new ServiceSAPMPOS.v1.ZFscdMposCountV1Ws
                {   //2019-03-08 08:10:00 => "yyyyMMddhhmmss"
                    BrokerContract = value.AgentContext.AgentId.ToString(CultureInfo.CurrentCulture),
                    LastLoginDate = ClearDate(value?.TimesTamp)
                };
            }
            return returnData;
        }

        /// <summary>
        /// Inputs to kpi.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public async Task<ServiceSAPMPOS.v1.ZFscdMposKpisV1Ws> InToKpiAsync(INS.PT.WebAPI.Model.Kpi.v1.InputKpi value)
        {
            ServiceSAPMPOS.v1.ZFscdMposKpisV1Ws returnData = null;
            if (value != null)
            {
                returnData = new ServiceSAPMPOS.v1.ZFscdMposKpisV1Ws
                {
                    BrokerContract = value.AgentContext.AgentId.ToString(CultureInfo.CurrentCulture),
                    LastLoginDate = ClearDate(value?.TimesTamp) 
                };
            }
            return returnData;
        }

        /// <summary>
        /// Inputs to search.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public async Task<ServiceSAPMPOS.v1.ZFscdMposSearchV1Ws> InToSearchAsync(Model.SearchReceipt.v1.InputSearchReceipt value)
        {
            if (value != null)
            {
                return new ServiceSAPMPOS.v1.ZFscdMposSearchV1Ws
                {
                    Context = !value.StatusType.HasValue ? "" : StringValueExtension.GetStringValue(value.StatusType),
                    BrokerContract = value.AgentContext.AgentId.ToString(CultureInfo.CurrentCulture),
                    Search = value.SearchValue,
                    ThirdParty = value.ThirdParties ? "X" : ""
                };
            }

            return null;
        }

        /// <summary>
        /// Inputs to receipt detail.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public async Task<ServiceSAPMPOS.v1.ZFscdMposKpisReceiptV1Ws> InToReceiptDetailAsync(INS.PT.WebAPI.Model.ReceiptDetail.v1.InputReceiptDetail value)
        {
            ServiceSAPMPOS.v1.ZFscdMposKpisReceiptV1Ws returnData = null;
            if (value != null)
            {
                returnData = new ServiceSAPMPOS.v1.ZFscdMposKpisReceiptV1Ws
                {
                    CompanyCode = value.CompanyId,
                    DocumentReferenceNumber = value.ReceiptId,
                    Policy = value.PolicyId,
                    BrokerContract = value.AgentContext.AgentId.ToString(CultureInfo.CurrentCulture)
                };
            }
            return returnData;
        }

        /// <summary>
        /// Inputs to kpi detail.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public async Task<ServiceSAPMPOS.v1.ZFscdMposKpisDetailV1Ws> InToKpiDetailAsync(INS.PT.WebAPI.Model.SumClientReceipt.v1.InputSumClientReceipt value)
        {
            ServiceSAPMPOS.v1.ZFscdMposKpisDetailV1Ws returnData = null;
            if (value != null)
            {
                returnData = new ServiceSAPMPOS.v1.ZFscdMposKpisDetailV1Ws
                {
                    Context = StringValueExtension.GetStringValue(value.Type),
                    BrokerContract = value.AgentContext.AgentId.ToString(CultureInfo.CurrentCulture)
                };
            }
            return returnData;
        }

        /// <summary>
        /// Inputs to kpis nfis.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public async Task<ServiceSAPMPOS.v1.ZFscdMposKpisNifsV1Ws> InToKpisNfisAsync(Model.ClientReceipts.v1.InputClientReceipts value)
        {
            ServiceSAPMPOS.v1.ZFscdMposKpisNifsV1Ws returnData = null;
            if (value != null)
            {
                returnData = new ServiceSAPMPOS.v1.ZFscdMposKpisNifsV1Ws
                {
                    TaxNumber = value.Nif,
                    Context = StringValueExtension.GetStringValue(value.Type),
                    BrokerContract = value.AgentContext.AgentId.ToString(CultureInfo.CurrentCulture)
                };
            }
            return returnData;
        }

        /// <summary>
        /// Inputs to charged.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public async Task<ServiceSAPMPOS.v1.ZFscdMposPostV1Ws> InToPaymentPostAsync(INS.PT.WebAPI.Model.PaymentPost.v1.InputPaymentPost value)
        {
            List<ZfscdReciboMposPostLinha> ListMposPostLinha = new List<ServiceSAPMPOS.v1.ZfscdReciboMposPostLinha>();

            ServiceSAPMPOS.v1.ZFscdMposPostV1Ws returnData = null;
            
            if (value != null)
            {
                if (value.Receipts.Collections.Count > 0)
                {
                    foreach (INS.PT.WebAPI.Model.PaymentPost.v1.CollectPaymentPost collect in value.Receipts.Collections)
                    {
                        ZfscdReciboMposPostLinha MposPostLinha = new ZfscdReciboMposPostLinha
                        {
                            DocumentPrefix = collect.DocumentPrefix,
                            Policy = collect.PolicyId,
                            DocumentReferenceNumber = collect.DocumentReferenceNumber,
                            Amount = collect.Amount,
                            ThirdParty = collect.ThirdParty.ToString()
                        };
                        ListMposPostLinha.Add(MposPostLinha);
                    }
                }

                returnData = new ServiceSAPMPOS.v1.ZFscdMposPostV1Ws
                {
                    BrokerContract = value.AgentContext.AgentId.ToString(CultureInfo.CurrentCulture),
                    PaymentPostSimulation = value.IsValidation.ToString(CultureInfo.CurrentCulture),
                    Proposal = value.Proposal.ToString(CultureInfo.CurrentCulture),
                    Receipts = new ZfscdReciboMposLinha
                    {
                        OriginalAplication = value.Receipts.OriginalAplication,
                        CompanyCode = value.Receipts.CompanyId,
                        MposTypeCode = value.Receipts.PaymentBrand,
                        NepMpos = value.Receipts.NepMpos,
                        NepSibs = value.Receipts.NepSibs,
                        SibsEntity = value.Receipts.SibsEntity,
                        SibsReference = value.Receipts.SibsReference,
                        PhoneId = value.Receipts.PhoneId,
                        TerminalId = value.Receipts.TerminalId,
                        PrinterMode = value.Receipts.PrinterMode,
                        Amount = value.Receipts.Amount,
                        Collect = ListMposPostLinha?.ToArray(),
                        Prefix = value.Receipts.Prefix
                    }
                };
            }

            //Aqui


            return returnData;
        }

        /// <summary>
        /// Outputs to kpi detail.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        public async Task<OutputSumClientReceipt> OutToKpiDetailAsync(ServiceSAPMPOS.v1.ZFscdMposKpisDetailV1WsResponse1 ResponseSAP)
        {
            List<Model.v1.ClientRef> receipts = new List<ClientRef>();
            GlobalEntityMposInformationInput Entities = new GlobalEntityMposInformationInput();

            //Lisar todos os entities, oriundo do método search
            if (ResponseSAP?.ZFscdMposKpisDetailV1WsResponse.KpisDetail.Length > 0)
            {
                Entities.EntitiesIds = new List<string>();
                foreach (var item in ResponseSAP?.ZFscdMposKpisDetailV1WsResponse.KpisDetail)
                {
                    if (!string.IsNullOrEmpty(item.Nif))
                    {
                        Entities.EntitiesIds.Add(item.Nif);
                    }
                }

            }

            //Chama o GlobalEntity
            List<GlobalEntityMposInformationOutput> listEntities = new List<GlobalEntityMposInformationOutput>();
            if (Entities.EntitiesIds != null)
            {
                listEntities = await StatesRepository.GetListEntitiesAsync(Entities);
            }
            //Chamar o método do globalentity e mesclar as informações do objeto

            if (ResponseSAP?.ZFscdMposKpisDetailV1WsResponse?.KpisDetail?.Length > 0)
            {
                receipts = new List<Model.v1.ClientRef>();
                foreach (ZfscdMposKpisClientLinha item in ResponseSAP?.ZFscdMposKpisDetailV1WsResponse?.KpisDetail)
                {
                    var objElement = new ClientRef
                    {
                        Amount = item.Amount,
                        Quantity = item.Quantity,
                        ThirdParty = false
                    };
                    var entitiesElement = listEntities.FirstOrDefault(x => x.VatNumber == item.Nif);
                    if (entitiesElement != null && !string.IsNullOrEmpty(entitiesElement.VatNumber))
                    {
                        entitiesElement = string.IsNullOrEmpty(entitiesElement.VatNumber) ? listEntities.FirstOrDefault(x => x.VatNumber == item.Nif) : entitiesElement;
                        objElement.Address = entitiesElement.Address;
                        objElement.Email = entitiesElement.EmailAddress;
                        objElement.Location = entitiesElement.Georeference;
                        objElement.Name = entitiesElement.Name;
                        objElement.Nif = entitiesElement.VatNumber;
                        objElement.Phone = entitiesElement.PhoneNumber;
                        objElement.PostalCode = entitiesElement.PostalCode;
                    }
                    else
                    {
                        objElement.Address = item.Address;
                        objElement.Email = item.Email;
                        objElement.Location = item.Location;
                        objElement.Name = item.Name;
                        objElement.Nif = item.Nif;
                        objElement.Phone = ClearPhoneNumber(item.Phone);
                        objElement.PostalCode = item.PostalCode;
                    }
                    receipts.Add(objElement);
                }

                if (ResponseSAP?.ZFscdMposKpisDetailV1WsResponse.Errors.Length > 0)
                {
                    listObjectError = new List<Model.v1.Error>
                {
                    new Model.v1.Error
                    {
                        ErrorCode = ResponseSAP?.ZFscdMposKpisDetailV1WsResponse.Errors[0].ErrorCode,
                        ErrorMessage = ResponseSAP?.ZFscdMposKpisDetailV1WsResponse.Errors[0].ErrorCodeTxt,
                    }
                    };
                }
            }
            INS.PT.WebAPI.Model.SumClientReceipt.v1.OutputSumClientReceipt returnData = new INS.PT.WebAPI.Model.SumClientReceipt.v1.OutputSumClientReceipt
            {
                ClientRefs = receipts?.ToList(),
                Errors = listObjectError?.ToList()
            };
            return returnData;
        }

        /// <summary>
        /// Outputs to kpi.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        public async Task<OutPutKpi> OutToKpiAsync(ServiceSAPMPOS.v1.ZFscdMposKpisV1WsResponse1 ResponseSAP)
        {
            List<Model.v1.KpiElement> ListKpi = new List<Model.v1.KpiElement>
            {
                ResponseSAP?.ZFscdMposKpisV1WsResponse.Summary.OpenItemRiskAmount > 0 ? new Model.v1.KpiElement
                {
                    //Recibos risco de anulação
                    Type = EnumContextType.Anulacao.ToString(),
                    Amount = ResponseSAP?.ZFscdMposKpisV1WsResponse?.Summary?.OpenItemRiskAmount,
                    Quantity = ResponseSAP?.ZFscdMposKpisV1WsResponse.Summary.OpenItemRiskTotal
                } : new Model.v1.KpiElement
                {
                    //Recibos risco de anulação
                    Type = EnumContextType.Anulacao.ToString(),
                    Amount = 0,
                    Quantity = 0
                },

                ResponseSAP?.ZFscdMposKpisV1WsResponse.Summary.OpenItemAmount > 0 ? new Model.v1.KpiElement
                {
                    //Recibos por cobrar
                    Type = EnumContextType.Cobrar.ToString(),
                    Amount = ResponseSAP?.ZFscdMposKpisV1WsResponse.Summary.OpenItemAmount,
                    Quantity = ResponseSAP?.ZFscdMposKpisV1WsResponse.Summary.OpenItemTotal
                } : new Model.v1.KpiElement
                {

                    Type = EnumContextType.Cobrar.ToString(),
                    Amount = 0,
                    Quantity = 0
                },
                ResponseSAP?.ZFscdMposKpisV1WsResponse.Summary.NotOpenItemAmount > 0 ? new Model.v1.KpiElement
                {
                    //Recibos cobrados
                    Type = EnumContextType.Cobrados.ToString(),
                    Amount = ResponseSAP?.ZFscdMposKpisV1WsResponse.Summary.NotOpenItemAmount,
                    Quantity = ResponseSAP?.ZFscdMposKpisV1WsResponse.Summary.NotOpenItemTotal
                } : new Model.v1.KpiElement
                {
                    //Recibos cobrados
                    Type = EnumContextType.Cobrados.ToString(),
                    Amount = 0,
                    Quantity = 0
                },


                ResponseSAP?.ZFscdMposKpisV1WsResponse.Summary.LastLoginTotal > 0 ? new Model.v1.KpiElement
                {
                    Type = EnumContextType.Novos.ToString(),
                    Amount = null,
                    Quantity = ResponseSAP?.ZFscdMposKpisV1WsResponse.Summary.LastLoginTotal
                } : new Model.v1.KpiElement
                {
                    Type = EnumContextType.Novos.ToString(),
                    Amount = null,
                    Quantity = 0
                }
            };

            if (ResponseSAP?.ZFscdMposKpisV1WsResponse.Errors.Length > 0)
            {
                listObjectError = new List<Model.v1.Error>();
                foreach (ZfscdCodigosErroLinha item in ResponseSAP.ZFscdMposKpisV1WsResponse.Errors)
                {
                    listObjectError.Add(new Model.v1.Error
                    {
                        ErrorCode = item.ErrorCode,
                        ErrorMessage = item.ErrorCodeTxt,
                    });
                }

            }

            INS.PT.WebAPI.Model.Kpi.v1.OutPutKpi returnData = null;
            returnData = new INS.PT.WebAPI.Model.Kpi.v1.OutPutKpi
            {
                KpiList = ListKpi?.ToList(),
                Errors = listObjectError?.ToList()
            };
            return returnData;
        }

        /// <summary>
        /// </summary>
        /// <param name="InputSearchMatch"></param>
        /// <param name="ResponseSAP"></param>
        /// <returns></returns>
        public async Task<OutPutSearchReceipt> OutToSearchNewAsync(string InputSearchMatch, ServiceSAPMPOS.v1.ZFscdMposSearchV1WsResponse1 ResponseSAP)
        {
            ClientRef ObjClientRef = null;
            List<Model.v1.Receipt> listReceipts = null;
            string branchName = null;
            List<Model.v1.Policy> listPolicies = null;
            List<Model.v1.Company> listCompany = null;
            GlobalEntityMposInformationInput Entities = new GlobalEntityMposInformationInput();

            //Erros
            if (ResponseSAP?.ZFscdMposSearchV1WsResponse.Errors.Length > 0)
            {
                Log.Error($" ZFscdMposSearchWsResponse Response : {JsonConvert.SerializeObject(ResponseSAP)}");

                listObjectError = new List<Error>();

                foreach (ZfscdCodigosErroLinha item in ResponseSAP?.ZFscdMposSearchV1WsResponse.Errors)
                {
                    listObjectError.Add(new Model.v1.Error
                    {
                        ErrorCode = item.ErrorCode,
                        ErrorMessage = item.ErrorCodeTxt,
                    });
                }
            }

            if (ResponseSAP?.ZFscdMposSearchV1WsResponse.Companies.Length > 0)
            {
                Log.Debug($" ZFscdMposSearchWsResponse Response : {JsonConvert.SerializeObject(ResponseSAP)}");

                listCompany = new List<Company>();
                //receipts
                foreach (ServiceSAPMPOS.v1.ZfscdMposKpisDetailLinV1 kpiDetailCompanies in ResponseSAP?.ZFscdMposSearchV1WsResponse.Companies)
                {
                    if (kpiDetailCompanies.Policies.Length > 0)
                    {
                        listPolicies = new List<Policy>();
                        Boolean SearchMatchOutputPolice = false;
                        foreach (ServiceSAPMPOS.v1.ZfscdMposKpisPolicyLinV1 policies in kpiDetailCompanies.Policies)
                        {

                            if (policies.Receipts.Length > 0)
                            {
                                listReceipts = new List<Receipt>();
                                Boolean SearchMatchOutputReceipt = false;
                                foreach (ServiceSAPMPOS.v1.ZfscdMposKpisReceiptLinV1 receipt in policies.Receipts)
                                {
                                    if ((InputSearchMatch == receipt.Policy) || (InputSearchMatch == receipt.DocumentReferenceNumber))
                                    {
                                        SearchMatchOutputReceipt = true;
                                    }

                                    var expiryDate = ValidateDateTime.ToCorrectDateTime(receipt.BillingPeriodTo, "");
                                    var issueDate = ValidateDateTime.ToCorrectDateTime(receipt.EmissionDate, receipt.EmissionHour);

                                    listReceipts.Add(
                                        new Model.v1.Receipt
                                        {
                                            CompanyId = receipt.CompanyCode,
                                            CompanyDes = EntityDesc.GetDescCompany(receipt.CompanyCode),
                                            PolicyId = receipt.Policy,
                                            ReceiptId = receipt.DocumentReferenceNumber,
                                            Amount = receipt.TotalValue,
                                            BillableType = receipt.PaymentStatus,
                                            Branch = receipt.InsuranceTypeName,
                                            ExpiryDate = expiryDate,
                                            IssueDate = issueDate,
                                            Pdf = receipt.DocumentId,
                                            ReceiptStatus = receipt.ReceiptStatus,
                                            AppOrigemId = receipt.SourceAplication,
                                            Status = !string.IsNullOrEmpty(receipt.ReceiptStatus),//receipt.FlagStatus,
                                            SearchMatch = SearchMatchOutputReceipt
                                        }
                                     );
                                    branchName = receipt.InsuranceTypeName;
                                }
                            }

                            //Incluir Police 
                            if (InputSearchMatch == policies.Policy)
                            {
                                SearchMatchOutputPolice = true;
                            }

                            listPolicies.Add(new Model.v1.Policy
                            {
                                Amount = policies.Amount,
                                Branch = branchName,
                                InsuredObject = policies.InsuredObject,
                                InsuredType = policies.InsuredType,
                                NoReceipts = policies.Total,
                                PolicyId = policies.Policy,
                                SearchMatch = SearchMatchOutputPolice,
                                Receipts = listReceipts?.ToList()
                            });

                        }
                    }

                    listCompany.Add(new Company
                    {
                        Amount = kpiDetailCompanies.Amount,
                        CompanyId = kpiDetailCompanies.CompanyCode,
                        CompanyDes = EntityDesc.GetDescCompany(kpiDetailCompanies.CompanyCode),
                        Policies = listPolicies?.ToList()
                    });
                }

            }

            //ClientRef
            if (ResponseSAP.ZFscdMposSearchV1WsResponse.ClientReference != null)
            {
                Entities.EntitiesIds = new List<string>();

                if (!string.IsNullOrEmpty(ResponseSAP.ZFscdMposSearchV1WsResponse.ClientReference.Nif))
                {
                    Entities.EntitiesIds.Add(ResponseSAP.ZFscdMposSearchV1WsResponse.ClientReference.Nif);
                }

                List<GlobalEntityMposInformationOutput> listEntities = new List<GlobalEntityMposInformationOutput>();
                
                if (Entities.EntitiesIds.Count > 0)
                {
                    listEntities = await StatesRepository.GetListEntitiesAsync(Entities);
                }

                ObjClientRef = new ClientRef();

                ObjClientRef.Amount = ResponseSAP.ZFscdMposSearchV1WsResponse.ClientReference.Amount;
                ObjClientRef.Quantity = ResponseSAP.ZFscdMposSearchV1WsResponse.ClientReference.Quantity;
                ObjClientRef.ThirdParty = ResponseSAP.ZFscdMposSearchV1WsResponse.ClientReference.ThirdParty == "X" ? true : false;

                var entitiesElement = listEntities?.FirstOrDefault(x => x.VatNumber == ResponseSAP.ZFscdMposSearchV1WsResponse.ClientReference.Nif);

                if (entitiesElement != null && !string.IsNullOrEmpty(entitiesElement.VatNumber))
                {
                    Log.Debug($"Global Entity - GetListEntitiesAsync Response : {JsonConvert.SerializeObject(entitiesElement)}");

                    if (string.IsNullOrEmpty(entitiesElement.VatNumber))
                    {
                        entitiesElement = listEntities.FirstOrDefault(x => x.VatNumber == ResponseSAP.ZFscdMposSearchV1WsResponse.ClientReference.Nif);
                    }

                    ObjClientRef.Address = entitiesElement.Address;
                    ObjClientRef.Email = entitiesElement.EmailAddress;
                    ObjClientRef.Location = entitiesElement.Georeference;
                    ObjClientRef.Name = entitiesElement.Name;
                    ObjClientRef.Nif = entitiesElement.VatNumber;
                    ObjClientRef.Phone = entitiesElement.PhoneNumber;
                    ObjClientRef.PostalCode = entitiesElement.PostalCode;
                }
                else
                {
                    Log.Debug($"SAP - GetListEntitiesAsync Response : {JsonConvert.SerializeObject(ResponseSAP)}");

                    ObjClientRef.Address = ResponseSAP.ZFscdMposSearchV1WsResponse.ClientReference.Address;
                    ObjClientRef.Email = ResponseSAP.ZFscdMposSearchV1WsResponse.ClientReference.Email;
                    ObjClientRef.Location = ResponseSAP.ZFscdMposSearchV1WsResponse.ClientReference.Location;
                    ObjClientRef.Name = ResponseSAP.ZFscdMposSearchV1WsResponse.ClientReference.Name;
                    ObjClientRef.Nif = ResponseSAP.ZFscdMposSearchV1WsResponse.ClientReference.Nif;
                    ObjClientRef.Phone = ClearPhoneNumber(ResponseSAP.ZFscdMposSearchV1WsResponse.ClientReference.Phone);
                    ObjClientRef.PostalCode = ResponseSAP.ZFscdMposSearchV1WsResponse.ClientReference.PostalCode;
                }
            }

            //Object
            INS.PT.WebAPI.Model.SearchReceipt.v1.OutPutSearchReceipt returnData = null;
            returnData = new INS.PT.WebAPI.Model.SearchReceipt.v1.OutPutSearchReceipt
            {
                ClientRef = ObjClientRef ?? null,
                Companies = listCompany?.ToList(),
                Errors = listObjectError?.ToList()
            };

            return returnData;
        }

        /// <summary>
        /// Outputs to receipt detail.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        public async Task<INS.PT.WebAPI.Model.ReceiptDetail.v1.OutPutReceiptDetail> OutToReceiptDetailAsync(ServiceSAPMPOS.v1.ZFscdMposKpisReceiptV1WsResponse1 ResponseSAP)
        {

            if ((ResponseSAP != null) && (ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.Errors.Length > 0))
            {
                listObjectError = new List<Error>();
                foreach (ZfscdCodigosErroLinha item in ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.Errors)
                {
                    listObjectError.Add(
                        new Model.v1.Error
                        {
                            ErrorCode = item.ErrorCode,
                            ErrorMessage = item.ErrorCodeTxt,
                        }
                   );
                }
            }

            INS.PT.WebAPI.Model.ReceiptDetail.v1.OutPutReceiptDetail returnData = null;
            if ((ResponseSAP?.ZFscdMposKpisReceiptV1WsResponse?.KpisDetailReceipt != null))
            {
                if (!string.IsNullOrEmpty(ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.CompanyCode))
                {

                    returnData = new INS.PT.WebAPI.Model.ReceiptDetail.v1.OutPutReceiptDetail
                    {
                        CompanyId = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.CompanyCode,
                        CompanyDes = EntityDesc.GetDescCompany(ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.CompanyCode),
                        PolicyId = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.Policy,
                        ReceiptId = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.DocumentReferenceNumber,
                        ClientName = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.Name,
                        Situation = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.SituationCodeDescription,
                        Fractionation = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.BillingFrequency,
                        Type = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.ReceiptTypeDesc,
                        BillingLocation = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.CollectionLocal,

                        Entity = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.Entity,
                        Reference = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.Reference,
                        ReferenceTotal = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.TotalValue,

                        PaymentStatus = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.PaymentStatus,
                        LifeCharges = 0,

                        CommercialPremium = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.PremiumAmount,
                        Costs = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.CostValue,
                        BonusMalus = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.BonusValue,
                        Taxes = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.TaxValue,
                        Additional = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.ExtraValue,

                        Total = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.TotalValue,

                        CapitalAndReceipt = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.Capital,

                        Fundraising = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.AgentCommissionValue,
                        Collections = ResponseSAP.ZFscdMposKpisReceiptV1WsResponse.KpisDetailReceipt.BrokerCommissionValue,

                        Errors = listObjectError?.ToList()
                    };
                }
            }

            return returnData;
        }

        /// <summary>
        /// Outputs to kpis nfis.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        public async Task<Model.ClientReceipts.v1.OutPutClientReceipts> OutToKpisNfisAsync(ServiceSAPMPOS.v1.ZFscdMposKpisNifsV1WsResponse1 ResponseSAP)
        {
            //erro
            string branchName = null;

            Model.ClientReceipts.v1.OutPutClientReceipts returnData = null;
            List<Model.v1.Receipt> listReceipts = null;
            List<Model.v1.Policy> listPolicies = null;
            List<Model.v1.Company> listcompany = new List<Company>();

            if (ResponseSAP != null)
            {
                if (ResponseSAP.ZFscdMposKpisNifsV1WsResponse.Errors.Length > 0)
                {
                    listObjectError = new List<Model.v1.Error>();
                    foreach (ZfscdCodigosErroLinha item in ResponseSAP.ZFscdMposKpisNifsV1WsResponse.Errors)
                    {
                        listObjectError.Add(
                            new Model.v1.Error
                            {
                                ErrorCode = item.ErrorCode,
                                ErrorMessage = item.ErrorCodeTxt,
                            }
                            );
                    }
                }

                //Detail
                if (ResponseSAP.ZFscdMposKpisNifsV1WsResponse.KpisDetail.Length > 0)
                {
                    //Company
                    foreach (ZfscdMposKpisDetailLinV1 kpiDetail in ResponseSAP.ZFscdMposKpisNifsV1WsResponse.KpisDetail)
                    {
                        listPolicies = new List<Policy>();
                        foreach (ZfscdMposKpisPolicyLinV1 policies in kpiDetail.Policies)
                        {
                            listReceipts = new List<Receipt>();
                            foreach (ZfscdMposKpisReceiptLinV1 receipt in policies.Receipts)
                            {
                                var expiryDate = ValidateDateTime.ToCorrectDateTime(receipt.BillingPeriodTo, "");
                                var issueDate = ValidateDateTime.ToCorrectDateTime(receipt.EmissionDate, receipt.EmissionHour);

                                listReceipts.Add(
                                    new Model.v1.Receipt
                                    {
                                        CompanyId = receipt.CompanyCode,
                                        CompanyDes = EntityDesc.GetDescCompany(receipt.CompanyCode),
                                        PolicyId = receipt.Policy,
                                        ReceiptId = receipt.DocumentReferenceNumber,
                                        Amount = receipt.TotalValue,
                                        BillableType = receipt.PaymentStatus,
                                        Branch = receipt.InsuranceTypeName,
                                        ExpiryDate = expiryDate,
                                        IssueDate = issueDate,
                                        Pdf = receipt.DocumentId,
                                        ReceiptStatus = receipt.ReceiptStatus,
                                        AppOrigemId = receipt.SourceAplication,
                                        Status = !string.IsNullOrEmpty(receipt.ReceiptStatus),
                                        SearchMatch = false,
                                        Type = receipt.ReceiptStatus
                                    }
                                );

                                branchName = receipt.InsuranceTypeName;
                            }
                            //        //Apolices
                            listPolicies.Add(new Model.v1.Policy
                            {
                                Amount = policies.Amount,
                                Branch = branchName,
                                InsuredObject = policies.InsuredObject,
                                InsuredType = policies.InsuredType,
                                NoReceipts = policies.Total,
                                PolicyId = policies.Policy,
                                SearchMatch = false,
                                Receipts = listReceipts?.ToList()
                            });
                        }

                        listcompany.Add(new Model.v1.Company
                        {
                            Amount = kpiDetail.Amount,
                            CompanyId = kpiDetail.CompanyCode,
                            CompanyDes = EntityDesc.GetDescCompany(kpiDetail.CompanyCode),
                            Policies = listPolicies?.ToList()
                        });

                    }
                }
                returnData = new Model.ClientReceipts.v1.OutPutClientReceipts
                {
                    Companies = listcompany?.ToList(),
                    Errors = listObjectError?.ToList()
                };
            }
            return returnData;
        }

        /// <summary>
        /// Outs to charged asynchronous.
        /// </summary>
        /// <param name="ResponseSAP">The response sap.</param>
        /// <returns></returns>
        public async Task<INS.PT.WebAPI.Model.PaymentPost.v1.OutPutPaymentPost> OutToPaymentPostAsync(ServiceSAPMPOS.v1.ZFscdMposPostV1WsResponse1 ResponseSAP)
        {

            List<INS.PT.WebAPI.Model.PaymentPost.v1.ReceiptCollectPos> listReceipts = null;
            INS.PT.WebAPI.Model.PaymentPost.v1.OutPutPaymentPost returnData = null;
            INS.PT.WebAPI.Model.PaymentPost.v1.ReceiptPosLn ReceiptPosLn = null;

            if (ResponseSAP != null)
            {
                if (ResponseSAP?.ZFscdMposPostV1WsResponse?.Errors?.Length > 0)
                {
                    listObjectError = new List<Error>();
                    foreach (ZfscdCodigosErroLinha item in ResponseSAP.ZFscdMposPostV1WsResponse.Errors)
                    {
                        listObjectError.Add(new Model.v1.Error
                        {
                            ErrorCode = item.ErrorCode,
                            ErrorMessage = item.ErrorCodeTxt,
                        });
                    }
                }
                if (ResponseSAP?.ZFscdMposPostV1WsResponse?.Receipts?.Errors?.Length > 0)
                {
                    listObjectDetailError = new List<Error>();
                    foreach (ZfscdCodigosErroLinha item in ResponseSAP.ZFscdMposPostV1WsResponse.Receipts.Errors)
                    {
                        listObjectDetailError.Add(new Model.v1.Error
                        {
                            ErrorCode = item.ErrorCode,
                            ErrorMessage = item.ErrorCodeTxt,
                        });
                    }
                }

                if (ResponseSAP?.ZFscdMposPostV1WsResponse?.Receipts?.Collect?.Length > 0)
                {
                    listReceipts = new List<INS.PT.WebAPI.Model.PaymentPost.v1.ReceiptCollectPos >();
                    foreach (ZfscdReciboMposPostLinha item in ResponseSAP.ZFscdMposPostV1WsResponse.Receipts.Collect)
                    {
                        listReceipts.Add(new INS.PT.WebAPI.Model.PaymentPost.v1.ReceiptCollectPos
                        {
                            DocumentPrefix = item.DocumentPrefix,
                            Policy = item.Policy,
                            DocumentReferenceNumber = item.DocumentReferenceNumber,
                            Amount = item.Amount,
                            ThirdParty = item.ThirdParty
                        });
                    }

                }

                if ((ResponseSAP?.ZFscdMposPostV1WsResponse?.Receipts != null))
                {
                    if (!string.IsNullOrEmpty(ResponseSAP.ZFscdMposPostV1WsResponse.Receipts.CompanyCode))
                    {

                        ReceiptPosLn = new INS.PT.WebAPI.Model.PaymentPost.v1.ReceiptPosLn
                        {
                            OriginalAplication = ResponseSAP.ZFscdMposPostV1WsResponse.Receipts.OriginalAplication,
                            CompanyCode = EntityDesc.GetDescCompany(ResponseSAP.ZFscdMposPostV1WsResponse.Receipts.CompanyCode),
                            MposTypeCode = ResponseSAP.ZFscdMposPostV1WsResponse.Receipts.MposTypeCode,
                            NepMpos = ResponseSAP.ZFscdMposPostV1WsResponse.Receipts.NepMpos,
                            NepSibs = ResponseSAP.ZFscdMposPostV1WsResponse.Receipts.NepSibs,
                            SibsEntity = ResponseSAP.ZFscdMposPostV1WsResponse.Receipts.SibsEntity,
                            SibsReference = ResponseSAP.ZFscdMposPostV1WsResponse.Receipts.SibsReference,
                            PhoneId = ResponseSAP.ZFscdMposPostV1WsResponse.Receipts.PhoneId,
                            TerminalId = ResponseSAP.ZFscdMposPostV1WsResponse.Receipts.TerminalId,
                            PrinterMode = ResponseSAP.ZFscdMposPostV1WsResponse.Receipts.PrinterMode,
                            Amount = ResponseSAP.ZFscdMposPostV1WsResponse.Receipts.Amount,
                            collections = listReceipts?.ToList(),
                            Prefix = ResponseSAP.ZFscdMposPostV1WsResponse.Receipts.Prefix,
                            errors = listObjectDetailError?.ToList()
                        };

                        returnData = new INS.PT.WebAPI.Model.PaymentPost.v1.OutPutPaymentPost
                        {
                            Receipt = ReceiptPosLn,
                            Errors = listObjectError?.ToList()
                        };
                    }
                    else
                    {
                        returnData = new INS.PT.WebAPI.Model.PaymentPost.v1.OutPutPaymentPost
                        {
                            Receipt = null,
                            Errors = listObjectError?.ToList()
                        };
                    }
                }
            }

            return returnData;
        }

        public static string ClearPhoneNumber(string phoneNumber)
        {
            string PhoneNumber = string.Empty;

            // check for the phones that are not with 9 digits
            if (phoneNumber?.Length > 0 && (phoneNumber?.Length != V || !phoneNumber.StartsWith('9')))
            {
                if (phoneNumber.StartsWith(VPREFIX1, StringComparison.InvariantCultureIgnoreCase)
                    || phoneNumber.StartsWith("00351", StringComparison.InvariantCultureIgnoreCase)
                    || phoneNumber.StartsWith("351", StringComparison.InvariantCultureIgnoreCase))
                {
                    // PT phone number but just leave the 9 right digits
                    PhoneNumber = phoneNumber.Substring(phoneNumber.Length - V);
                }
                else
                {   // invalid phone number, just clear
                    PhoneNumber = string.Empty;
                }
            }
            return PhoneNumber;
        }

        public static string ClearDate(string dateString)
        {
            //2019-03-08 08:10:00 => "yyyyMMddhhmmss"
            return dateString.Replace(" ", "").Replace("-", "").Replace(":", "");
        }

    }
}



﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Models.AgentsPortal.Agent.Elements;
using System.Collections.Generic;
using System.Linq;

namespace INS.PT.WebAPI.Helpers.v1
{
    /// <summary>
    /// ListHelper
    /// </summary>
    public class ListHelper
    {
        /// <summary>
        /// Gets the agents from commercial structure.
        /// </summary>
        /// <param name="commercialStructure">The commercial structure.</param>
        /// <returns></returns>
        public static List<AgentCSElement> GetAgentsFromCommercialStructure(List<CompanyCSElement> commercialStructure)
        {
            List<AgentCSElement> agentList = (from structure in commercialStructure
                                              from network in structure.Networks
                                              from zone in network.Zones
                                              from branch in zone.Branches
                                              from inspector in branch.Inspectors
                                              select inspector.Agents)
                                              .SelectMany(res => res)
                                              .ToList();
            return agentList;
        }

        /// <summary>
        /// Gets the code agents list.
        /// </summary>
        /// <param name="agentCode">The agent code.</param>
        /// <param name="commercialStructure">The commercial structure.</param>
        /// <returns></returns>
        public static List<string> GetCodeAgentsList(string agentCode, List<CompanyCSElement> commercialStructure)
        {
            var agentList = (from structure in commercialStructure
                             from network in structure.Networks
                             from zone in network.Zones
                             from branch in zone.Branches
                             from inspector in branch.Inspectors
                             select new
                             {
                                 Agents = inspector.Agents.Where(a => a.Code == agentCode)
                             })
                             .SelectMany(a => a.Agents)
                             .Select(x => x.Code)
                             .ToList();

            return agentList;
        }

        /// <summary>
        /// Gets the asf agents list.
        /// </summary>
        /// <param name="inspectorCode">The inspector code.</param>
        /// <param name="asfCode">The asf code.</param>
        /// <param name="commercialStructure">The commercial structure.</param>
        /// <returns></returns>
        public static List<string> GetASFAgentsList(string inspectorCode, string asfCode, 
            List<CompanyCSElement> commercialStructure)
        {
            var agentList = (from structure in commercialStructure
                             from network in structure.Networks
                             from zone in network.Zones
                             from branch in zone.Branches
                             from inspector in branch.Inspectors
                             where inspector.Code == inspectorCode
                             select new
                             {
                                 Agents = inspector.Agents.Where(a => a.AsfNumber == asfCode)
                             })
                             .SelectMany(a => a.Agents)
                             .Select(x => x.Code)
                             .ToList();

            return agentList;
        }
    }
}

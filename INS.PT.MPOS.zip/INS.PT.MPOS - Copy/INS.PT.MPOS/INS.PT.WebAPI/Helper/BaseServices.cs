﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.ServiceModel;

namespace INS.PT.WebAPI.Helper
{
    public class BaseServices
    {
        protected readonly IHttpContextAccessor _httpContext;
        protected readonly IConfiguration _configuration;

        protected readonly TimeSpan OpenTimeout;
        protected readonly TimeSpan CloseTimeout;
        protected readonly TimeSpan SendTimeout;
        protected readonly TimeSpan ReceiveTimeout;
        protected readonly TimeSpan RestTimeout;

        protected readonly BasicHttpBinding Binding;


        /// <summary>
        /// Initializes a new instance of the <see cref="BaseServices"/> class.
        /// </summary>
        /// <param name="httpContext">The HTTP context.</param>
        public BaseServices(IHttpContextAccessor httpContext)
        {
            // httpContext
            _httpContext = httpContext;

            _configuration = _httpContext.GetConfiguration();

            // read timeouts from config
            OpenTimeout = _configuration.ReadTimeSpanFromConfig("ServicesTimeouts:OpenTimeout");
            CloseTimeout = _configuration.ReadTimeSpanFromConfig("ServicesTimeouts:CloseTimeout");
            SendTimeout = _configuration.ReadTimeSpanFromConfig("ServicesTimeouts:SendTimeout");
            ReceiveTimeout = _configuration.ReadTimeSpanFromConfig("ServicesTimeouts:ReceiveTimeout");
            RestTimeout = _configuration.ReadTimeSpanFromConfig("ServicesTimeouts:RestTimeout");

            Binding = new BasicHttpBinding();
            Binding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Basic;
            Binding.Security.Mode = BasicHttpSecurityMode.TransportCredentialOnly;

            Binding.OpenTimeout = OpenTimeout;
            Binding.CloseTimeout = CloseTimeout;
            Binding.SendTimeout = SendTimeout;
            Binding.ReceiveTimeout = ReceiveTimeout;

            Binding.MaxReceivedMessageSize = int.MaxValue;
            Binding.MaxBufferPoolSize = int.MaxValue;
            Binding.MaxBufferSize = int.MaxValue;
            Binding.AllowCookies = true;
            Binding.TransferMode = TransferMode.Buffered;
        }
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using AutoMapper;
using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.AgentsPortal.Agent;
using INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity;
using INS.PT.WebAPI.Models.AgentsPortal.HighAvailability;
using INS.PT.WebAPI.Models.Common;
using INS.PT.WebAPI.Models.DTO.HighAvailability;
using INS.PT.WebAPI.Models.DTO.ReferenceData;
using INS.PT.WebAPI.Models.ReferenceData;
using INS.PT.WebAPI.Models.ReferenceData.Elements;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Constants.AgentsPortalEnums;

namespace INS.PT.WebAPI.Mappings
{
    public class AgentsPortalProfile : Profile
    {
        public AgentsPortalProfile()
        {
            CreateMap<Error, ErrorsDTO>().ReverseMap();
            CreateMap<Pagination, PagingDTO>().ReverseMap();

            CreateMap<SearchReceiptWaspInput, SearchReceiptInputDTO>().ReverseMap();
            CreateMap<HReceiptElement, ReceiptsCommentsDTO>().ReverseMap();
            CreateMap<Order<ReceiptsData>, OrderReferenceDataReceiptsDTO>().ReverseMap();
            CreateMap<SearchReceiptWaspOutput, ResultsDTO<ReceiptsCommentsDTO>>().ReverseMap();

            CreateMap<SearchEntitiesWaspInput, SearchEntitiesInputDTO>().ReverseMap();
            CreateMap<HEntitiesElement, EntityDTO>().ReverseMap();
            CreateMap<Order<EntitiesData>, OrderReferenceDataEntitiesDTO>().ReverseMap();
            CreateMap<SearchEntitiesWaspOutput, ResultsDTO<EntityDTO>>().ReverseMap();

            CreateMap<SearchClaimWaspInput, SearchClaimInputDTO>().ReverseMap();
            CreateMap<HClaimElement, ClaimsDTO>().ReverseMap();
            CreateMap<Order<ClaimsData>, OrderReferenceDataClaimDTO>().ReverseMap();
            CreateMap<SearchClaimWaspOutput, ResultsDTO<ClaimsDTO>>().ReverseMap();

            CreateMap<IndicatorsWaspOutput, IndicatorsDTO>().ReverseMap();

            CreateMap<SearchPolicyWaspInput, SearchPolicyInputDTO>().ReverseMap();
            CreateMap<HPolicyElement, PoliciesDTO>().ReverseMap();
            CreateMap<Order<PoliciesData>, OrderReferenceDataPolicyDTO>().ReverseMap();
            CreateMap<SearchPolicyWaspOutput, ResultsDTO<PoliciesDTO>>().ReverseMap();

            CreateMap<ReferenceDataWaspOutput, ReferenceDataOutputDTO>().ReverseMap();
            CreateMap<ReferenceData, ReferenceDataDTO>()
                .ForMember(dest => dest.ExtraProperties, opt => opt.MapFrom(src => src.ExtraProperties))
                .ReverseMap();

            CreateMap<SearchRequestWaspInput, SearchRequestInputDTO>().ReverseMap();
            CreateMap<HRequestElement, RequestsDTO>().ReverseMap();
            CreateMap<Order<RequestsData>, OrderReferenceDataRequestDTO>().ReverseMap();
            CreateMap<SearchRequestWaspOutput, ResultsDTO<RequestsDTO>>().ReverseMap();

            CreateMap<SearchWalletMovementWaspInput, SearchWalletMovementInputDTO>().ReverseMap();
            CreateMap<HWalletMovementElement, WalletMovementsDTO>().ReverseMap();
            CreateMap<Order<WalletMovementsData>, OrderReferenceDataWalletMovementDTO>().ReverseMap();
            CreateMap<SearchWalletMovementWaspOutput, ResultsDTO<WalletMovementsDTO>>().ReverseMap();

            CreateMap<HComercialStructureElement, ComercialStructureDTO>().ReverseMap();
            CreateMap<Order<ComercialStructureData>, OrderReferenceDataComercialStructureDTO>().ReverseMap();
            CreateMap<SearchComercialStructureWaspOutput, ResultsDTO<ComercialStructureDTO>>().ReverseMap();

            CreateMap<HInsuredObjectElement, InsuredObjectDTO>().ReverseMap();
            CreateMap<Order<InsuredObjectsData>, OrderReferenceDataInsuredObjectDTO>().ReverseMap();
            CreateMap<SearchInsuredObjectWaspOutput, ResultsDTO<InsuredObjectDTO>>().ReverseMap();

     
            #region Agent Details

            CreateMap<EntityElement, AgentOutput>()
                .ForMember(dest => dest.IdEntity, opt => opt.MapFrom(src => src.IdEntity))
                .ForMember(dest => dest.VatNumber, opt => opt.MapFrom(src => src.VatNumber))
                .ForMember(dest => dest.IdentificationNumber, opt => opt.MapFrom(src => ReadIdDocument(src.Documents)))
                .ForMember(dest => dest.SocialSecurityNumber, opt => opt.MapFrom(src => ReadNSSDocument(src.Documents)))
                //.ForMember(dest => dest.ASFNumber, opt => opt.MapFrom(src => src.IdEntity))
                .ForMember(dest => dest.Birthdate, opt => opt.MapFrom(src => src.Type.Individual.Birthdate))
                .ForMember(dest => dest.NationalityDescription, opt => opt.MapFrom(src => ReadPrincipalNationality(src.Type.Individual.Nationalities)))
                .ForMember(dest => dest.Contacts, opt => opt.MapFrom(src => src.Contacts))
                .ForMember(dest => dest.Addresses, opt => opt.MapFrom(src => src.Addresses))
                .ReverseMap();

            #endregion
        }

        private static string ReadIdDocument(IEnumerable<DocumentElement> documents)
        {
            return documents.FirstOrDefault(doc => doc.DocumentTypeCode == "id")?.DocumentNumber;
        }

        private static string ReadNSSDocument(IEnumerable<DocumentElement> documents)
        {
            return documents.FirstOrDefault(doc => doc.DocumentTypeCode == "NSS")?.DocumentNumber;
        }

        private static string ReadPrincipalNationality(IEnumerable<NationalityElement> nationalities)
        {
            return nationalities.FirstOrDefault(nat => nat.IsPrincipal == true)?.NationalityDescription;
        }

    }
}

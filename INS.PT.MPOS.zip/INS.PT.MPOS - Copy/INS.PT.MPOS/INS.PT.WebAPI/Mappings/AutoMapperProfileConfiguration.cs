﻿// Copyright Ageas 2019 © - Integration Team

using AutoMapper;


namespace INS.PT.WebAPI
{
    /// <summary>
    /// AutoMapperProfileConfiguration
    /// </summary>
    public class AutoMapperProfileConfiguration : Profile
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AutoMapperProfileConfiguration"/> class.
        /// </summary>
        public AutoMapperProfileConfiguration() : this("MyProfile")
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AutoMapperProfileConfiguration"/> class.
        /// </summary>
        /// <param name="profileName">Name of the profile.</param>
        protected AutoMapperProfileConfiguration(string profileName)
        : base(profileName)
        {
           
        }
    }
}

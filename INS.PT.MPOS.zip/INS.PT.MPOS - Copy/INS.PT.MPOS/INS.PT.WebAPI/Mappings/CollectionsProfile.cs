﻿// Copyright Ageas 2019 © - Integration Team

using AutoMapper;
using INS.PT.WebAPI.Models.AgentsPortal.Collections.Elements;
using INS.PT.WebAPI.Models.AgentsPortal.Collections.ProvisionWebAccounts;
using INS.PT.WebAPI.Models.Collections.Elements;
using INS.PT.WebAPI.Models.Collections.ProvisionalWebAccounts;
using INS.PT.WebAPI.Models.Collections.WebReceiptListing;
using INS.PT.WebAPI.Models.DTO.Collections.Elements;
using INS.PT.WebAPI.Models.DTO.Collections.ProvisionalWebAccounts;
using INS.PT.WebAPI.Models.DTO.Collections.ProvisionWebAccounts;
using INS.PT.WebAPI.Models.DTO.Collections.WebReceiptListing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Mappings
{
    public class CollectionsProfile : Profile
    {
        public CollectionsProfile()
        {
            CreateMap<List<ErrorElement>, List<ZfscdCodigosErroLinhaCobDTO>>().ReverseMap();
            CreateMap<List<ErrorElement>, List<ZfscdCodigosErroLinhaValDTO>>().ReverseMap();
            CreateMap<List<ErrorElement>, List<ZfscdErrosReceiptsNumLineDTO>>().ReverseMap();
            CreateMap<List<ErrorElement>, List<ZfscdCodigosErroLinhaQueryDTO>>().ReverseMap();

            CreateMap<ReceiptElement, ZfscdPcRecibosLinhaDTO>().ReverseMap();
            CreateMap<DetailReceiptElement, ZfscdRecibosWorkLinhaDTO>().ReverseMap();
            CreateMap<DetailReceiptLineElement, ZfscdPcDetailLinhaDTO> ().ReverseMap();
            CreateMap<HeaderReceiptLineElement, ZfscdPcHeaderLinhaDTO> ().ReverseMap();

            CreateMap<ValidateChargeReceiptsWaspInput, ZFscdPcValidarWsInputDTO>().ReverseMap();
            CreateMap<ChargedReceiptsWaspInput, ZFscdPcCobrarWsInputDTO>().ReverseMap();

            CreateMap<ChargedReceiptsWaspOuptut, ZFscdPcCobrarWsDTO>().ReverseMap();
            CreateMap<ValidateChargeReceiptsWaspOutput, ZFscdPcValidarDTO>().ReverseMap();

            CreateMap<ReceiptDetailWaspInput, ZFscdRecibosListarWsInputDTO>().ReverseMap();
            CreateMap<ReceiptDetailWaspOutput, ZFscdRecibosListarWsDTO>().ReverseMap();

            CreateMap<QueryReceiptsWaspInput, ZFscdPcConsultarWsInputDTO>().ReverseMap();
            CreateMap<QueryReceiptsWaspOutput, ZFscdPcConsultarWsResponseDTO>().ReverseMap();
        }
    }
}

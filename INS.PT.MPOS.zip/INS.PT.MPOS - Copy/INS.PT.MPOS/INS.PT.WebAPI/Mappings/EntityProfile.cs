﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.Collections.Generic;
using System.Reflection;
using System.ServiceModel;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.v1;
using INS.PT.WebAPI.Models.AgentsPortal.Agent.Elements;
using INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity;
using INS.PT.WebAPI.Models.DTO.Agent;
using INS.PT.WebAPI.Models.DTO.Entity;
using log4net;

namespace INS.PT.WebAPI.Mappings
{
    /// <summary>
    /// EntityProfile
    /// </summary>
    /// <seealso cref="AutoMapper.Profile" />
    public class EntityProfile : AutoMapper.Profile
    {
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog log;

        /// <summary>
        /// Initializes a new instance of the <see cref="EntityProfile"/> class.
        /// </summary>
        /// <param name="profileName">Name of the profile.</param>
        public EntityProfile(string profileName) : base(profileName)
        {
            log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="EntityProfile"/> class.
        /// </summary>
        /// <exception cref="ProcessErrorException">Fault</exception>
        /// <exception cref="ProcessErrorException.InnerError"></exception>
        public EntityProfile()
        {
            try
            {
                CreateMap<JobElement, JobDto>().ReverseMap();
                CreateMap<CategoryElement, CategoryDto>().ReverseMap();
                CreateMap<DriverLicenceElement, DriverLicenceDto>().ReverseMap();
                CreateMap<NationalityElement, NationalityDto>().ReverseMap();
                CreateMap<HonoraryTitleElement, HonoraryTitleDto>().ReverseMap();
                CreateMap<ContactElement, ContactDto>().ReverseMap();
                CreateMap<OrganizationContactElement, OrganizationContactDto>().ReverseMap();
                CreateMap<PersonElement, PersonDto>().ReverseMap();
                CreateMap<PersonDetailElement, PersonDto>().ReverseMap();
                CreateMap<OrganizationElement, OrganizationDto>().ReverseMap();
                CreateMap<PoBoxElement, PoBoxDto>().ReverseMap();
                CreateMap<PoAddressElement, PoAddressDto>().ReverseMap();
                CreateMap<AddressTipologyElement, AddressTipologyDto>().ReverseMap();
                CreateMap<PhoneElement, PhoneDto>().ReverseMap();
                CreateMap<EmailElement, EmailDto>().ReverseMap();
                CreateMap<ContactListsElement, ContactListsDto>().ReverseMap();
                CreateMap<BankAccountElement, BankAccountDto>().ReverseMap();
                CreateMap<DocumentElement, DocumentDto>().ReverseMap();
                CreateMap<CaeElement, CaeDto>().ReverseMap();
                CreateMap<ExternalReferenceElement, ExternalReferenceDto>().ReverseMap();
                CreateMap<CrsFatcaElement, CrsFatcaDto>().ReverseMap();
                CreateMap<AffinityRelationElement, AffinityRelationDto>().ReverseMap();
                CreateMap<AmlElement, AmlDto>().ReverseMap();
                CreateMap<ProfileElement, ProfileDto>().ReverseMap();
                CreateMap<EntityTypeElement, EntityTypeDto>().ReverseMap();
                CreateMap<EntityDetailTypeElement, EntityTypeDto>().ReverseMap();
                CreateMap<EntityAddressElement, AddressDto>().ReverseMap();
                CreateMap<EntityElement, Models.DTO.Entity.EntityDto>().ReverseMap().ConvertUsing<EntityConverter>();
                CreateMap<EntityDetailElement, Models.DTO.Entity.EntityDto>().ReverseMap();

                // Agent
                CreateMap<AgentCSElement, AgentDto>().ReverseMap();
                CreateMap<InspectorCSElement, InspectorDto>().ReverseMap();
                CreateMap<BranchCSElement, BranchDto>().ReverseMap();
                CreateMap<ZoneCSElement, ZoneDto>().ReverseMap();
                CreateMap<NetWorkCSElement, NetWorkDto>().ReverseMap();
                CreateMap<CompanyCSElement, CompanyDto>().ReverseMap();

                CreateMap<List<AddressDto>, List<AddressCSElement>>().ConvertUsing<AddressConverter>();
                CreateMap<DocumentCSElement, DocumentDto>().ReverseMap();
                CreateMap<EmailCSElement, EmailDto>().ReverseMap();
                CreateMap<PhoneCSElement, PhoneDto>().ReverseMap();
                CreateMap<NationalityCSElement, NationalityDto>().ReverseMap();
                CreateMap<Models.DTO.Entity.EntityDto, AgentCSElement>().ConvertUsing<AgentConverter>();

            }
            catch (FaultException e)
            {
                log.Error(e);
                throw new ProcessErrorException(
                               "Fault",
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = e.Code.ToString(),
                                       ErrorMessage = e.Message,
                                       ErrorType = ""
                                   }
                               }
                               );
            }
            catch (Exception ex)
            {
                log.Debug($"Object Response Mapping: { ex.Message }");
                throw;
            }
        }
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using AutoMapper;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.ClientReceipts;
using INS.PT.WebAPI.Model.ClientReceipts.v1;
using INS.PT.WebAPI.Model.v1;
using log4net;
using ServiceSAPMPOS.v1;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.ServiceModel;

namespace INS.PT.WebAPI.Mappings
{

    /// <summary>
    /// UserProfileManagementProfile
    /// </summary>
    /// <seealso cref="AutoMapper.Profile" />
    public class ClientReceiptsKpisNifs : Profile
    {
        /// <summary>
        /// The log
        /// </summary>
        private readonly ILog log;

        /// <summary>
        /// Initializes a new instance of the <see cref="ClientReceiptsKpisNifs"/> class.
        /// </summary>
        /// <param name="profileName">Name of the profile.</param>
        public ClientReceiptsKpisNifs(string profileName) : base(profileName)
        {
            log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ClientReceiptsKpisNifs"/> class.
        /// </summary>
        /// <exception cref="ProcessErrorException">Fault</exception>
        /// <exception cref="ProcessErrorException.InnerError"></exception>
        public ClientReceiptsKpisNifs()
        {
            try
            {
                //ClientReceipt
                //DTO - Origem
                CreateMap<Model.v1.Company, ZfscdMposKpisDetailLinV1>().ReverseMap();
                CreateMap<Model.v1.Receipt, ZfscdMposKpisReceiptLinV1>().ReverseMap();
                CreateMap<Model.v1.Policy, ZfscdMposKpisPolicyLinV1>().ReverseMap();
                CreateMap<Model.v1.Error, ZfscdCodigosErroLinha>().ReverseMap();
                CreateMap<OutPutClientReceipts, ZFscdMposKpisNifsV1WsResponse1>().ReverseMap();

            }
            catch (FaultException e)
            {
                log.Error(e);
                throw new ProcessErrorException(
                               "Fault",
                               e.Message, new List<ProcessErrorException.InnerError>
                               {
                                   new ProcessErrorException.InnerError
                                   {
                                       ErrorCode = e.Code.ToString(),
                                       ErrorMessage = e.Message,
                                       ErrorType = ""
                                   }
                               }
                               );
            }
            catch (Exception ex)
            {
                log.Debug($"Object Response Mapping: { ex.Message }");
                throw;
            }

        }

    }
}

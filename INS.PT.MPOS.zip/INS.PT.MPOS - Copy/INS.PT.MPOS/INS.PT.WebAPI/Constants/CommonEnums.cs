﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Utils;
using System;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Constants
{
    /// <summary>
    /// CommonEnums
    /// </summary>
    [Serializable]
    public class CommonEnums
    {
    
        [Serializable]
        public enum Level
        {
            [EnumMember]
            [Description("Company")]
            [AmbientValue("Company")]
            Company = 1,

            [EnumMember]
            [Description("Network")]
            [AmbientValue("Network")]
            Network = 2,

            [EnumMember]
            [Description("Zone")]
            [AmbientValue("Zone")]
            Zone = 3,

            [EnumMember]
            [Description("Branch")]
            [AmbientValue("Branch")]
            Branch = 4,

            [EnumMember]
            [Description("Inspector")]
            [AmbientValue("Inspector")]
            Inspector = 5,

            [EnumMember]
            [Description("ASF")]
            [AmbientValue("ASF")]
            ASF = 6,

            [EnumMember]
            [Description("Agent")]
            [AmbientValue("Agent")]
            Agent = 7,

            [EnumMember]
            [Description("Aggregator")]
            [AmbientValue("Aggregator")]
            Aggregator = 20
        }

        [Serializable]
        public enum HttpRequestVerb
        {
            [EnumMember]
            GET,
            [EnumMember]
            POST,
            [EnumMember]
            PUT,
            [EnumMember]
            DELETE,
            [EnumMember]
            UPDATE
        }

        [Serializable]
        public enum OrderData
        {
            [EnumMember]
            [Description("Ascending")]
            [AmbientValue("Ascending")]
            [StringValue("Ascending")]
            Ascending,
            [EnumMember]
            [Description("Descending")]
            [AmbientValue("Descending")]
            [StringValue("Descending")]
            Descending
        }
    }
}

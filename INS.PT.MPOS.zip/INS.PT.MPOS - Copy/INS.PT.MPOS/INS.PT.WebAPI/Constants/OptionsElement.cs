﻿// Copyright Ageas 2019 © - Integration Team

namespace INS.PT.WebAPI.Data
{
    /// <summary>
    /// OptionsElement
    /// </summary>
    public class OptionsElement
    {
        public bool HandleList404Response { get; set; }
    }
}

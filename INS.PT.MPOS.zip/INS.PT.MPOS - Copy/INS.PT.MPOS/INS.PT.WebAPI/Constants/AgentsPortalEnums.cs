﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Helper.v1;
using System;
using System.ComponentModel;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Constants
{
    /// <summary>
    /// AgentsPortalEnums
    /// </summary>
    [Serializable]
    public static class AgentsPortalEnums
    {
        /// <summary>
        /// ReferenceTypePerson
        /// </summary>

        [Serializable]
        public enum ReferenceTypePerson
        {
            [StringValue("N")]
            Network = 1,
            [StringValue("Z")]
            Zone = 2,
            [StringValue("B")]
            Branch = 3,
            [StringValue("I")]
            Inspector = 4,
            [StringValue("A")]
            Agent = 5,
            [StringValue("C")]
            Company = 6
        }

        /// <summary>
        /// Gets the reference type person.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        
        public static ReferenceTypePerson GetReferenceTypePerson(string value)
        {
            return (ReferenceTypePerson)Enum.Parse(typeof(ReferenceTypePerson), value);
        }


        /// <summary>
        /// ComercialStructureData
        /// </summary>
        [Serializable]
        public enum ComercialStructureData
        {
            [EnumMember]
            [Description("ComercialStructureId")]
            [AmbientValue("ComercialStructureId")]
            ComercialStructureId,
            [EnumMember]
            [Description("Company")]
            [AmbientValue("Company")]
            Company,
            [EnumMember]
            [Description("NetworkCode")]
            [AmbientValue("NetworkCode")]
            NetworkCode,
            [EnumMember]
            [Description("NetworkName")]
            [AmbientValue("NetworkName")]
            NetworkName,
            [EnumMember]
            [Description("ZoneCode")]
            [AmbientValue("ZoneCode")]
            ZoneCode,
            [EnumMember]
            [Description("ZoneName")]
            [AmbientValue("ZoneName")]
            ZoneName,
            [EnumMember]
            [Description("BranchCode")]
            [AmbientValue("BranchCode")]
            BranchCode,
            [EnumMember]
            [Description("BranchName")]
            [AmbientValue("BranchName")]
            BranchName,
            [EnumMember]
            [Description("InspectorCode")]
            [AmbientValue("InspectorCode")]
            InspectorCode,
            [EnumMember]
            [Description("InspectorEntityId")]
            [AmbientValue("InspectorEntityId")]
            InspectorEntityId,
            [EnumMember]
            [Description("AgentCode")]
            [AmbientValue("AgentCode")]
            AgentCode,
            [EnumMember]
            [Description("AgentEntityId")]
            [AmbientValue("AgentEntityId")]
            AgentEntityId,
            [EnumMember]
            [Description("ASFNumber")]
            [AmbientValue("ASFNumber")]
            ASFNumber
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model
{
    /// <summary>
    /// 
    /// </summary>
    public class DocumentInput
    {
        /// <summary>
        /// Entity identity.
        /// </summary>
        /// <example>10592272</example>
        [Required]
        public long DocumentId { get; set; }
    }
}

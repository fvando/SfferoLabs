﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model
{
    /// <summary>
    /// 
    /// </summary>
    public class PaymentReceipt
    {
        /// <summary>
        /// prefixDoc
        /// </summary>
        [Required]
            public string PrefixDoc { get; set; } 

        /// <summary>
        /// company
        /// </summary>
        [Required]
            public string CompanyId { get; set; }  

        /// <summary>
        /// policy
        /// </summary>
        [Required]
        public string PolicyId { get; set; }  


        /// <summary>
        /// idReceipt
        /// </summary>
        [Required]
        public string ReceiptId { get; set; }  


        /// <summary>
        /// amount
        /// </summary>
        [Required]
        public decimal Amount { get; set; }  

        /// <summary>
        /// thirdParty
        /// </summary>
        [Required]
        public Boolean ThirdParty { get; set; }  
    }
}

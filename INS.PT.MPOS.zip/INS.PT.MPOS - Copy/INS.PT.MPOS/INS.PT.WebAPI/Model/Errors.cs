﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model
{
    /// <summary>
    /// AgentObj
    /// </summary>
    public class Errors
    {
        /// <example></example>
        public string ErrorCode { get; set; }

        /// <example></example>
        public string ErrorCodeTxt { get; set; }
    
    }
}

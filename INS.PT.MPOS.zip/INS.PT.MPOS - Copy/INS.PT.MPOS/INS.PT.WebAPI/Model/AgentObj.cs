﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model
{
    /// <summary>
    /// AgentObj
    /// </summary>
    public class AgentObj
    {
        /// <summary>
        /// ID do agente 
        /// </summary>
        ///<example>123456</example>
        [Required]
        public string AgentId { get; set; }  

        /// <summary>
        /// name
        /// </summary>
        ///<example>João Luis</example>
        [Required]
        public string Name { get; set; }  
    }
}

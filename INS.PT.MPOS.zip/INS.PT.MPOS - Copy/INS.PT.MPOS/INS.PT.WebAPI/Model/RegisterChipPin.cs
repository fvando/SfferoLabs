﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model
{
    /// <summary>
    /// 
    /// </summary>
    public class RegisterChipPin
    {
        /// <summary>
        /// InputPaymentDetails
        /// </summary>
        public class InputRegisterChipPin
        {
            /// <summary>
            /// appTx_id
            /// </summary>
            ///<example>B7nww9pMzNrHAEz8swjW4n3Nx0755RRn</example>
            public string appTx_id { get; set; } = "B7nww9pMzNrHAEz8swjW4n3Nx0755RRn";


            /// <summary>
            /// appTx_dateTime
            /// </summary>
            ///<example>2019-04-12T10:32:27.001+01:00</example>
            public string appTx_dateTime { get; set; } = "2019-04-12T10:32:27.001+01:00";

            /// <summary>
            /// appTx_details_amount
            /// </summary>
            ///<example>9.00</example>
            public double appTx_details_amount { get; set; } = 9.00;

            /// <summary>
            /// error
            /// </summary>
            ///<example>0</example>
            public string error { get; set; } = "0";

            /// <summary>
            /// errorCode
            /// </summary>
            ///<example></example>
            public string errorCode { get; set; } = "";

            /// <summary>
            /// financial_entryMode
            /// </summary>
            ///<example>CARD_CHIP_CONTACT</example>
            public string financial_entryMode { get; set; } = "CARD_CHIP_CONTACT";

            /// <summary>
            /// financial_handwrittenSignatureRequired
            /// </summary>
            ///<example>false</example>
            public Boolean financial_handwrittenSignatureRequired { get; set; } = false;

            /// <summary>
            /// financial_receiptData_acquirerText
            /// </summary>
            ///<example>false</example>
            public string financial_receiptData_acquirerText { get; set; } = "6";

            /// <summary>
            /// financial_receiptData_cardData_appId
            /// </summary>
            ///<example>501649FF20</example>
            public string financial_receiptData_cardData_appId { get; set; } = "501649FF20";

            /// <summary>
            /// financial_receiptData_cardData_appLabel
            /// </summary>
            ///<example>MULTIBANCO      </example>
            public string financial_receiptData_cardData_appLabel { get; set; } = "MULTIBANCO";

            /// <summary>
            /// financial_receiptData_cardData_cardholderName
            /// </summary>
            ///<example>JOSE MELLO DARGENT</example>
            public string financial_receiptData_cardData_cardholderName { get; set; } = "JOSE MELLO DARGENT";

            /// <summary>
            /// financial_receiptData_cardData_maskedPAN
            /// </summary>
            ///<example>****9249/66</example>
            public string financial_receiptData_cardData_maskedPAN { get; set; } = "****9249/66";

            /// <summary>
            /// financial_receiptData_clientFee
            /// </summary>
            ///<example></example>
            public string financial_receiptData_clientFee { get; set; }

            /// <summary>
            /// financial_receiptData_clientFeeCurrency
            /// </summary>
            ///<example></example>
            public string financial_receiptData_clientFeeCurrency { get; set; }


            /// <summary>
            /// financial_receiptData_discountFee
            /// </summary>
            ///<example></example>
            public string financial_receiptData_discountFee { get; set; }

            /// <summary>
            /// financial_receiptData_financialProductDescLong
            /// </summary>
            ///<example>MB</example>
            public string financial_receiptData_financialProductDescLong { get; set; } = "MB";

            /// <summary>
            /// financial_receiptData_financialProductDescMedium
            /// </summary>
            ///<example>MB</example>
            public string financial_receiptData_financialProductDescMedium { get; set; } = "MB";



            /// <summary>
            /// financial_receiptData_financialProductDescShort
            /// </summary>
            ///<example>MB</example>
            public string financial_receiptData_financialProductDescShort { get; set; } = "MB";


            /// <summary>
            /// financial_receiptData_issuerName
            /// </summary>
            ///<example>MB</example>
            public string financial_receiptData_issuerName { get; set; } = "NOVO BANCO";

            /// <summary>
            /// recipientTx_dateTime
            /// </summary>
            ///<example>2019-04-12T10:32:45.001+01:00</example>
            public string recipientTx_dateTime { get; set; } = "2019-04-12T10:32:45.001+01:00";


            /// <summary>
            /// recipientTx_details
            /// </summary>
            ///<example></example>
            public string recipientTx_details { get; set; }


            /// <summary>
            /// recipientTx_id
            /// </summary>
            ///<example>2004500000006</example>
            public string recipientTx_id { get; set; } = "2004500000006";

            /// <summary>
            /// tx_dateTime
            /// </summary>
            ///<example>2019-04-12T10:32:45.001+01:00</example>
            public string tx_dateTime { get; set; } = "2019-04-12T10:32:45.001+01:00";

            /// <summary>
            /// tx_details
            /// </summary>
            ///<example></example>
            public string tx_details { get; set; }


            /// <summary>
            /// tx_id
            /// </summary>
            ///<example>jyTkzzMWN0a55zzSmT5</example>
            public string tx_id { get; set; } = "jyTkzzMWN0a55zzSmT5";


            /// <summary>
            /// reconciliation
            /// </summary>
            ///<example></example>
            public string reconciliation { get; set; }

            /// <summary>
            /// reconciliationId
            /// </summary>
            ///<example></example>
            public string reconciliationId { get; set; } = "0";

            /// <summary>
            /// status
            /// </summary>
            ///<example></example>
            public string status { get; set; } = "Success";


            /// <summary>
            /// statusControle
            /// </summary>
            ///<example></example>
            public string sstatusControletatus { get; set; } = "0";


        }

        /// <summary>
        /// OutputLogin
        /// </summary>
        public class OutputRegisterChipPin
        {

            /// <summary>
            /// appTx_id
            /// </summary>
            ///<example>B7nww9pMzNrHAEz8swjW4n3Nx0755RRn</example>
            public string appTx_id { get; set; } = "B7nww9pMzNrHAEz8swjW4n3Nx0755RRn";

            /// <summary>
            /// status
            /// </summary>
            ///<example></example>
            public string status { get; set; } = "OK";


            /// <summary>
            /// errorMessage
            /// </summary>
            ///<example>2</example>
            [Required]
            public string errorMessage { get; set; } = "2";

            /// <summary>
            /// internalCompany
            /// </summary>
            ///<example>Não foi possível gerar o ‘appTx_id</example>
            [Required]
            public string internalCompany { get; set; } = "Não foi possível gerar o ‘appTx_id";

      

        }

    }
}

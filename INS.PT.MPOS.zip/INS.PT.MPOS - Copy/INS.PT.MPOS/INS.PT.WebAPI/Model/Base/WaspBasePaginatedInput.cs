﻿using INS.PT.WebAPI.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.Base
{
    public class WaspBasePaginatedInput : WaspBaseInput
    {
        
        public Pagination Paging { get; set; }
    }
}

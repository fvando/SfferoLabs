﻿

// Copyright Ageas 2019 © - Integration Team

namespace INS.PT.WebAPI.Models.Base.v2
{
    /// <summary>
    /// WaspBaseOutput
    /// </summary>
    public class WaspBaseOutput
    {
        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        public string Status { get; set; }
        /// <summary>
        /// Gets or sets the output message.
        /// </summary>
        /// <value>
        /// The output message.
        /// </value>
        public string OutputMessage { get; set; }
    }
}

﻿

// Copyright Ageas 2019 © - Integration Team

namespace INS.PT.WebAPI.Model.v2
{
    /// <summary>
    /// AgentContext
    /// </summary>
    public class AgentContextApp : AgentContextBase
    {
    
    }
}

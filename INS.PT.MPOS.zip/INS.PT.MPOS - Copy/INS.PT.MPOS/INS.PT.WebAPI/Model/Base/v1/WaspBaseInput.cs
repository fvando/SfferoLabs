﻿

// Copyright Ageas 2019 © - Integration Team

using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace INS.PT.WebAPI.Models.Base.v1
{
    /// <summary>
    /// WaspBaseInput
    /// </summary>
    public class WaspBaseInput
    {
        [System.Text.Json.Serialization.JsonIgnore]
        public string Level { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        public string CodeLevel { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        public List<string> CodeLevels { get; set; }

        ///// <summary>
        ///// 
        ///// </summary>
        //public bool clearCacheField { get; set; }

        ///// <summary>
        ///// 
        ///// </summary>
        //public string transactionIdField { get; set; }
        ///// <summary>
        ///// 
        ///// </summary>
        //public string validationKeyField { get; set; }
    }
}
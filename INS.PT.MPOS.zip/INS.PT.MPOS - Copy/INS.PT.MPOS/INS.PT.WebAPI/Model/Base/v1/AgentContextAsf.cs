﻿

// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Models;
using INS.PT.WebAPI.Models.v1;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// AgentContext
    /// </summary>
    public class AgentContextAsf
    {
        /// <summary>
        /// Agents'ID 
        /// </summary>
        ///<example>66037</example>
        [MaxLength(MaxLengths.AgendIdMaxLength)]
        [Required]
        public string AgentId { get; set; }

        /// <summary>
        /// Exclusive
        /// </summary>
        ///<example>false</example>
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public bool Exclusive { get; set; }

        /// <summary>
        /// Name
        /// </summary>
        ///<example></example>
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        /// <summary>
        /// NumAsfAgent
        /// Agent with an ASF name
        /// </summary>
        ///<example></example>
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string AsfNumber { get; set; }

    }
}

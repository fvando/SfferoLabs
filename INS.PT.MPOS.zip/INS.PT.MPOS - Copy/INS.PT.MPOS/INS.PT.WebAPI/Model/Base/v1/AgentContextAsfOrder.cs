﻿

// Copyright Ageas 2019 © - Integration Team


namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// AgentContext
    /// </summary>
    public class AgentContextAsfOrder
    {
        /// <summary>
        /// Agents'ID 
        /// </summary>
        ///<example>66037</example>
        public int AgentId { get; set; }

        /// <summary>
        /// Exclusive
        /// </summary>
        ///<example>false</example>
        public bool Exclusive { get; set; }

        /// <summary>
        /// Name
        /// </summary>
        ///<example></example>
        public string Name { get; set; }

        /// <summary>
        /// NumAsfAgent
        /// Agent with an ASF name
        /// </summary>
        ///<example></example>
        public string AsfNumber { get; set; }
      


    
    }
}

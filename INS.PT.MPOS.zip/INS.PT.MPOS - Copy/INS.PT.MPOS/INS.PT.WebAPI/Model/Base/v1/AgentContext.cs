﻿

// Copyright Ageas 2019 © - Integration Team

namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// AgentContext
    /// </summary>
    public class AgentContextApp : AgentContextBase
    {
    
    }
}

﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// AgentContext
    /// </summary>
    public class AgentsAsf
    {
        /// <summary>
        /// InputLogin
        /// </summary>
        public class InputAgentsAsf
        {
           
        }

        /// <summary>
        /// OutputLogin
        /// </summary>
        public class OutputAgentsAsf
        {
            /// <summary>
            /// Gets or sets the agent context.
            /// </summary>
            /// <value>
            /// The agent context.
            /// </value>
            public AgentContextAsf AgentContext { get; set; }
            /// <summary>
            /// Gets or sets the agent list.
            /// </summary>
            /// <value>
            /// The agent list.
            /// </value>
            public List<AgentContextAsf> AgentList { get; set; }

            /// <summary>
            /// Gets or sets the errors.
            /// </summary>
            /// <value>
            /// The errors.
            /// </value>
            [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            public List<Error> Errors { get; set; } 
        }
    }
}

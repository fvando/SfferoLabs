﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Model.v1
{
    [Serializable]
    public class ProcessErrorExceptionCore
    {
        [Serializable]
        public class InnerErrorCore
        {
            public string ErrorType { get; set; }

            public string ErrorCode { get; set; }

            public string ErrorMessage { get; set; }

        }

        private string ErrorType { get; set; }

        private string ErrorCode { get; set; }

        private string ErrorMessage { get; set; }

        [JsonProperty(PropertyName = "Errors")]
        public IEnumerable<InnerErrorCore> Errors { get; set; }
    }
}




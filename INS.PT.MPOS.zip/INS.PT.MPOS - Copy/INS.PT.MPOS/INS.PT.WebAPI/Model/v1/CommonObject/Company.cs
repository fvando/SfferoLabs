﻿

// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Data.v1;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// Company
    /// </summary>
    public class Company
    {

        /// <summary>
        /// company
        /// </summary>
        ///<example>010</example>
        [Required]
        //[JsonConverter(typeof(StringEnumConverter))]
        public string CompanyId { get; set; }

        /// <summary>
        /// company
        /// </summary>
        ///<example></example>
        [Required]
        [JsonConverter(typeof(StringEnumConverter))]
        public EnumCompany CompanyDes { get; set; }

        /// <summary>
        /// policies
        /// </summary>
        ///<example></example>
        [Required]
        public List<Policy> Policies { get; set; }

        /// <summary>
        /// Amount
        /// </summary>
        ///<example>0.0</example>
        [Required]
        public decimal Amount { get; set; } 

    }
}

﻿

// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Data.v1;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// Receipt
    /// </summary>
    public class Receipt
    { 
        /// <summary>
        /// company
        /// </summary>
        ///<example></example>
        [Required]
        //[JsonConverter(typeof(StringEnumConverter))]
        public string CompanyId { get; set; }

        /// <summary>
        /// company
        /// </summary>
        ///<example></example>
        [Required]
        [JsonConverter(typeof(StringEnumConverter))]
        public EnumCompany CompanyDes { get; set; }


        /// <summary>
        /// policy
        /// </summary>
        ///<example></example>
        [Required]
       // [MaxLength(MaxLengths.PolicyIdMaxLength)]
        public string PolicyId { get; set; }
 
        /// <summary>
        /// Receipt
        /// </summary>
        ///<example></example>
        [Required]
        public string ReceiptId { get; set; }

        /// <summary>
        /// issueDate
        /// </summary>
        ///<example></example>
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        [Required]
        //Note
        //This ojbect is date, but I have been writing in string only to test.
        public DateTime? IssueDate { get; set; }

        /// <summary>
        /// expiryDate
        /// </summary>
        ///<example></example>
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date)]
        [Required]
        //Note
        //This ojbect is date, but I have been writing in string only to test.
        public DateTime? ExpiryDate { get; set; } 

        /// <summary>
        /// amount
        /// </summary>
        ///<example></example>
        [Required]
        public Decimal Amount { get; set; }

        /// <summary>
        /// branch
        /// </summary>
        ///<example></example>
        [Required]
        public string Branch { get; set; } 

        /// <summary>
        /// status
        /// </summary>
        ///<example></example>
        
        public Boolean Status { get; set; }

        /// <summary>
        /// pdf
        /// </summary>
        ///<example></example>
        public string Pdf { get; set; } 

        /// <summary>
        /// searchMatch
        /// </summary>
        ///<example></example>
        public Boolean SearchMatch { get; set; } 

        /// <summary>
        /// appOrigemId
        /// </summary>
        ///<example></example>
        public string AppOrigemId { get; set; }

        /// <summary>
        /// billableType
        /// </summary>
        ///<example></example>
        public string BillableType { get; set; }

        /// <summary>
        /// Type
        /// </summary>
        ///<example></example>
        public string Type { get; set; }

        /// <summary>
        /// ReceiptStatus
        /// </summary>
        ///<example></example>
        public string ReceiptStatus { get; set; }

        ///// <summary>
        ///// Data_Limite
        ///// </summary>
        /////<example></example>
        //[DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
        //[DataType(DataType.Date)]
        //[Required]
        //public DateTime? Data_Limite { get; set; }

    }
}

﻿

// Copyright Ageas 2019 © - Integration Team

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// Policy
    /// </summary>
    public class Policy
    {
        /// <summary>
        /// policy
        /// </summary>
        ///<example>000</example>
        [Required]
       // [MaxLength(MaxLengths.PolicyIdMaxLength)]
        public string PolicyId { get; set; }

        /// <summary>
        /// branch
        /// </summary>
        ///<example></example>
        [Required]
        public string Branch { get; set; } 

        /// <summary>
        /// noReceipts
        /// </summary>
        ///<example></example>
        [Required]
        public Decimal NoReceipts { get; set; }

        /// <summary>
        /// amount
        /// </summary>
        ///<example></example>
        [Required]
        public Decimal Amount { get; set; } 

        /// <summary>
        /// searchMatch
        /// </summary>
        ///<example></example>
        public Boolean SearchMatch { get; set; }

        /// <summary>
        /// receipts
        /// </summary>
        ///<example></example>
        public List<Receipt> Receipts { get; set; }


        /// <summary>
        /// insuredType
        /// </summary>
        ///<example></example>
        public string InsuredType { get; set; } 

        /// <summary>
        /// insuredObject
        /// </summary>
        ///<example></example>
        [Required]
        public string InsuredObject { get; set; }
        
        
    }
}

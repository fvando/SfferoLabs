﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// ClientRef
    /// </summary>
    public class ClientRef
    {
        /// <summary>
        /// name
        /// </summary>
        ///<example></example>
        [Required]
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }  

        /// <summary>
        /// nif
        /// </summary>
        ///<example></example>
        [Required]
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Nif { get; set; }

        /// <summary>
        /// amount
        /// </summary>
        ///<example></example>
        [Required]
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public Decimal Amount { get; set; }  

        /// <summary>
        /// quantity
        /// </summary>
        ///<example></example>
        [Required]
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public Decimal Quantity { get; set; } 

        /// <summary>
        /// address
        /// </summary>
        ///<example></example>
        [Required]
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Address { get; set; } 

        /// <summary>
        /// postalCode
        /// </summary>
        ///<example></example>
        [Required]
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCode { get; set; } 

        /// <summary>
        /// location
        /// </summary>
        ///<example></example>
        [Required]
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Location { get; set; }  


        /// <summary>
        /// phone
        /// </summary>
        ///<example></example>
        [Required]
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Phone { get; set; }  


        /// <summary>
        /// email
        /// </summary>
        ///<example></example>
        [Required]
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; } 

        /// <summary>
        /// thirdParty
        /// </summary>
        ///<example></example>
        [Required]
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public Boolean ThirdParty { get; set; } 

    }
}

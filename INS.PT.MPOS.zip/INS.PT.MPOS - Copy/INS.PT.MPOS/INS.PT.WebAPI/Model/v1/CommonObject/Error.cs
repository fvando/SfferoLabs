﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// AgentObj
    /// </summary>
    public class Error
    {
        /// <example></example>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorType { get; set; } = string.Empty;

        /// <example></example>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCode { get; set; } = string.Empty;

        /// <example></example>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorMessage { get; set; } = string.Empty;

    }
}

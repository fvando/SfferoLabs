﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace INS.PT.WebAPI.Model.v1
{
    [Serializable]
    public class ProcessErrorException : Exception
     {
        [Serializable]
        public class InnerError
        {
            
            public string ErrorType { get; set; }
 
            public string ErrorCode { get; set; }

            public string ErrorMessage { get; set; }
             
        }

        
        private string ErrorType { get; set; }


        private string ErrorCode { get; set; }


        private string ErrorMessage { get; set; }

        [JsonProperty(PropertyName = "errors")]
        public IEnumerable<InnerError> InnerErrors { get; set; }

        public ProcessErrorException()
        {
        }

       
        public ProcessErrorException(string message) : this(message, (Exception)null)
        {
        }

      
        public ProcessErrorException(string code, string message) : this(message, (Exception)null)
        {
            ErrorCode = code;
        }

        
        public ProcessErrorException(string message, Exception innerException) : base(message, innerException)
        {
            ErrorMessage = message;
        }

       
        protected ProcessErrorException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }

    
        public ProcessErrorException(string errorCode, string errorMessage, IEnumerable<InnerError> innerErrors) : this(errorCode, errorMessage)
        {
            InnerErrors = innerErrors ?? throw new ArgumentNullException(nameof(innerErrors));
        }
 

 
        public override string Message => ToString();

      
        public override string ToString()
        {
            return $"Execution returned error {ErrorCode} with message: {ErrorMessage}";
        }

   
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
            {
                throw new ArgumentNullException(nameof(info));
            }

            info.AddValue("errors", InnerErrors);
        }
    }
}




﻿

// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Model.v1;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Model.ClientReceipts.v1
{
    /// <summary>
    /// OutPutClientReceipts
    /// </summary>
    public class OutPutClientReceipts
        {
            /// <summary>
            /// companies
            /// </summary>
            //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            public List<Company> Companies { get; set; }

            /// <summary>
            /// error
            /// </summary>
            [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            public List<Error> Errors { get; set; }

        }
    
}

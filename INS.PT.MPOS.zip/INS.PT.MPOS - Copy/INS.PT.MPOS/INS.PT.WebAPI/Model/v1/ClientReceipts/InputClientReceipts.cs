﻿

// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Data;
using INS.PT.WebAPI.Data.v1;
using INS.PT.WebAPI.Model.v1;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace INS.PT.WebAPI.Model.ClientReceipts.v1
{
    /// <summary>
    /// InputClientReceipts
    /// </summary>
    public class InputClientReceipts
        {
            ///// <summary>
            ///// Nome de usuário
            ///// </summary>
            public AgentContextApp AgentContext { get; set; }

            /// <summary>
            /// 1 Cobrar - Recibos de prémio e estorno de um mediador Por cobrar
            /// 2 Anulacao - Recibos de prémio e estorno de um mediador Risco de anulação
            /// 3 Cobrados - Recibos de prémio e estorno de um mediador Cobrados no último mês
            /// </summary>
            ///<example>Anulacao</example>
            [Required]
            public EnumContextType Type { get; set; }

            /// <summary>
            /// nif
            /// </summary>
            ///<example>PT204151856</example>
            //[Required]
            public string Nif { get; set; }

            ///// <summary>
            ///// paymentTypes
            ///// </summary>
            ///<example></example>
            [JsonIgnore]
            public List<string> PaymentTypes { get; set; }

        }
    }
 

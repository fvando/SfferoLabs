﻿using INS.PT.WebAPI.Data;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// 
    /// </summary>
    public class ClientReceipts 
    {
        /// <summary>
        /// InputLogin
        /// </summary>
        //public class InputClientReceipts 
        //{
        //    ///// <summary>
        //    ///// Nome de usuário
        //    ///// </summary>
        //    public AgentContextApp AgentContext { get; set; }

        //    /// <summary>
        //    /// 1 Anulacao - Recibos de prémio e estorno de um mediador Risco de anulação
        //    /// 2 Cobrar - Recibos de prémio e estorno de um mediador Por cobrar
        //    /// 3 Cobrados - Recibos de prémio e estorno de um mediador Cobrados no último mês
        //    /// </summary>
        //    ///<example>Anulacao</example>
        //    [Required]
        //    public EnumContextType Type { get; set; }  

        //    /// <summary>
        //    /// nif
        //    /// </summary>
        //    ///<example>PT204151856</example>
        //    [Required]
        //    public string Nif { get; set; }

        //    ///// <summary>
        //    ///// paymentTypes
        //    ///// </summary>
        //    ///<example></example>
        //    [JsonIgnore]
        //    public List<string> PaymentTypes { get; set; }

        //}

        /// <summary>
        /// OutputLogin
        /// </summary>
        //public class OutputClientReceipts
        //{
        //    /// <summary>
        //    /// companies
        //    /// </summary>
        //    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        //    public List<Company> Companies { get; set; }

        //    /// <summary>
        //    /// error
        //    /// </summary>
        //    [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        //    public List<Error> Errors { get; set; }

        //}

    }
}

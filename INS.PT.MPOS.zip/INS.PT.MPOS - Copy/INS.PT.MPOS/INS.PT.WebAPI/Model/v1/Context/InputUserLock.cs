﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Model.Context.v1
{
    /// <summary>
    /// InputUserLock
    /// </summary>
    public class InputUserLock
    {
        /// <summary>
        /// Gets or sets the subject.
        /// </summary>
        /// <value>
        /// The subject.
        /// </value>
        ///<example>ApiMpos</example>
        [JsonProperty(PropertyName = "subject")]
        [JsonRequired]
        public string Subject { get; set; } = "ApiMpos";

        /// <summary>
        /// Gets or sets the body.
        /// </summary>
        /// <value>
        /// The body.
        /// </value>
        ///<example>Utilizador bloqueado por ação duvidosa</example>
        [JsonProperty(PropertyName = "body")]
        [JsonRequired]
        public string Body { get; set; } = "Utilizador bloqueado por ação duvidosa";

    }
}

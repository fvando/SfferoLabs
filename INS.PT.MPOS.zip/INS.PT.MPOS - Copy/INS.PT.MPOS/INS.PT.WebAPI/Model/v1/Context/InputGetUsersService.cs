﻿

// Copyright Ageas 2019 © - Integration Team



using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace INS.PT.WebAPI.Model.Context.v1
{
    /// <summary>
    /// InputGetUsersService
    /// </summary>
    public class InputGetUsersService
    {
        /// <summary>
        /// Gets or sets a value indicating whether [clear cache].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [clear cache]; otherwise, <c>false</c>.
        /// </value>
        [Newtonsoft.Json.JsonIgnore]
        public bool ClearCache { get; set; }

        /// <summary>
        /// Gets the xpto.
        /// </summary>
        /// <value>
        /// The xpto.
        /// </value>
        [JsonProperty("ClearCache")]
        public string Xpto { get => ClearCache.ToString(); }

        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>
        /// The email.
        /// </value>
        [JsonProperty(PropertyName = "Email")]
        public string Email { get; set; } = "";

        /// <summary>
        /// Gets or sets the number of records.
        /// </summary>
        /// <value>
        /// The number of records.
        /// </value>
        [JsonProperty(PropertyName = "NumberOfRecords")]
        public int NumberOfRecords { get; set; } = 1;

        /// <summary>
        /// Gets or sets the page number.
        /// </summary>
        /// <value>
        /// The page number.
        /// </value>
        [JsonProperty(PropertyName = "PageNumber")]
        public int PageNumber { get; set; } = 1;
    }
}

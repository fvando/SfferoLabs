﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model
{
    /// <summary>
    /// 
    /// </summary>
    public class KpiSrv
    {
        /// <summary>
        /// InputLogin
        /// </summary>
     


        /// <summary>
        /// InputLogin
        /// </summary>
        public class InputKpiCount
        {
            /// <summary>
            /// agentContext
            /// Object containing agent context
            /// </summary>
            ///<example></example>
            public AgentContextBase AgentContext { get; set; }

            /// <summary>
            /// timestamp
            /// </summary>
            ///<example>2019-03-08 08:10:00</example>
            [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
            [DataType(DataType.Date)]
            [JsonRequired]
            public DateTime TimesTamp { get; set; }

        }


        /// <summary>
        /// OutputLogin
        /// </summary>
        public class OutputKpi
        {
            /// <summary>
            /// kpiList
            /// List of KPI
            /// </summary>
            [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            public List<KPI> KpiList { get; set; }

            /// <summary>
            /// error
            /// </summary>
            [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            public List<Error> Errors { get; set; }

        }

        /// <summary>
        /// OutputLogin
        /// </summary>
        public class OutputKpiCount
        {
            /// <summary>
            /// List of KPI
            /// </summary>
            //[Required]
            [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            public int KpiTotal { get; set; }

            /// <summary>
            /// error
            /// </summary>
            [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            public List<Error> Errors { get; set; }

        }
    }
}

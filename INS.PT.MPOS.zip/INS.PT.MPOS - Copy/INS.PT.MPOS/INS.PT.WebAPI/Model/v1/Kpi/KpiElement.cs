﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// AgentContext
    /// </summary>
    public class KpiElement
    {
        /// <summary>
        /// type
        /// </summary>
        ///<example></example>
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Type { get; set; }

        /// <summary>
        /// quantity
        /// </summary>
        ///<example></example>
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public decimal? Quantity { get; set; }

        /// <summary>
        /// amount
        /// </summary>
        ///<example></example>
        //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public decimal? Amount { get; set; } 
    }
}

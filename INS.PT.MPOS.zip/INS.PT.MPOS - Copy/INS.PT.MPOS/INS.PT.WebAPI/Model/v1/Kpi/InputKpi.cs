﻿

// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Model.v1;
using System;
using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Model.Kpi.v1
{
    /// <summary>
    /// InputKpi
    /// </summary>
    public class InputKpi
    {
        /// <summary>
        /// Gets or sets the agent context.
        /// </summary>
        /// <value>
        /// The agent context.
        /// </value>
        [Required]
        public AgentContextBase AgentContext { get; set; }

        
        ///<example>2019-03-08 08:10:00</example>
        [Required]
        public string TimesTamp { get; set; }

    }
}

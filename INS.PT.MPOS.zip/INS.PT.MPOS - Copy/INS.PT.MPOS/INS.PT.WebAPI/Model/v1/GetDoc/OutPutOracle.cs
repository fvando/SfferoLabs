﻿

// Copyright Ageas 2019 © - Integration Team

namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// OutPutOracle
    /// </summary>
    public class OutPutOracle
    {
        /// <summary>
        /// Gets or sets the document identifier.
        /// </summary>
        /// <value>
        /// The document identifier.
        /// </value>
        public string DOC_ID { get; set; }

        /// <summary>
        /// Gets or sets the job identifier.
        /// </summary>
        /// <value>
        /// The job identifier.
        /// </value>
        public string JOB_ID { get; set; }

        /// <summary>
        /// Gets or sets the tipo document identifier.
        /// </summary>
        /// <value>
        /// The tipo document identifier.
        /// </value>
        public string TIPO_DOC_ID { get; set; }

        /// <summary>
        /// Gets or sets the descricao.
        /// </summary>
        /// <value>
        /// The descricao.
        /// </value>
        public string DESCRICAO { get; set; }

        /// <summary>
        /// Gets or sets the tipo papel.
        /// </summary>
        /// <value>
        /// The tipo papel.
        /// </value>
        public string TIPO_PAPEL { get; set; }

        /// <summary>
        /// Gets or sets the bandeja.
        /// </summary>
        /// <value>
        /// The bandeja.
        /// </value>
        public string BANDEJA { get; set; }

        /// <summary>
        /// Gets or sets the proc dev.
        /// </summary>
        /// <value>
        /// The proc dev.
        /// </value>
        public string PROC_DEV { get; set; }

        /// <summary>
        /// Gets or sets the sn 2 via.
        /// </summary>
        /// <value>
        /// The sn 2 via.
        /// </value>
        public string SN_2VIA { get; set; }

        /// <summary>
        /// Gets or sets the apolice.
        /// </summary>
        /// <value>
        /// The apolice.
        /// </value>
        public string APOLICE { get; set; }

        /// <summary>
        /// Gets or sets the adesao.
        /// </summary>
        /// <value>
        /// The adesao.
        /// </value>
        public string ADESAO { get; set; }

        /// <summary>
        /// Gets or sets the processo identifier.
        /// </summary>
        /// <value>
        /// The processo identifier.
        /// </value>
        public string PROCESSO_ID { get; set; }

        /// <summary>
        /// Gets or sets the processo desc.
        /// </summary>
        /// <value>
        /// The processo desc.
        /// </value>
        public string PROCESSO_DESC { get; set; }

        /// <summary>
        /// Gets or sets the cdramo.
        /// </summary>
        /// <value>
        /// The cdramo.
        /// </value>
        public string CDRAMO { get; set; }

        /// <summary>
        /// Gets or sets the dsramo.
        /// </summary>
        /// <value>
        /// The dsramo.
        /// </value>
        public string DSRAMO { get; set; }

        /// <summary>
        /// Gets or sets the tipo destinatario identifier.
        /// </summary>
        /// <value>
        /// The tipo destinatario identifier.
        /// </value>
        public string TIPO_DESTINATARIO_ID { get; set; }

        /// <summary>
        /// Gets or sets the tipo destinatario desc.
        /// </summary>
        /// <value>
        /// The tipo destinatario desc.
        /// </value>
        public string TIPO_DESTINATARIO_DESC { get; set; }

        /// <summary>
        /// Gets or sets the destinatario dni.
        /// </summary>
        /// <value>
        /// The destinatario dni.
        /// </value>
        public string DESTINATARIO_DNI { get; set; }

        /// <summary>
        /// Gets or sets the destinatario nome.
        /// </summary>
        /// <value>
        /// The destinatario nome.
        /// </value>
        public string DESTINATARIO_NOME { get; set; }

        /// <summary>
        /// Gets or sets the destinatario morada.
        /// </summary>
        /// <value>
        /// The destinatario morada.
        /// </value>
        public string DESTINATARIO_MORADA { get; set; }

        /// <summary>
        /// Gets or sets the destinatario local.
        /// </summary>
        /// <value>
        /// The destinatario local.
        /// </value>
        public string DESTINATARIO_LOCAL { get; set; }

        /// <summary>
        /// Gets or sets the destinatario postal.
        /// </summary>
        /// <value>
        /// The destinatario postal.
        /// </value>
        public string DESTINATARIO_POSTAL { get; set; }

        /// <summary>
        /// Gets or sets the ordem job.
        /// </summary>
        /// <value>
        /// The ordem job.
        /// </value>
        public string ORDEM_JOB { get; set; }

        /// <summary>
        /// Gets or sets the ordem document.
        /// </summary>
        /// <value>
        /// The ordem document.
        /// </value>
        public string ORDEM_DOC { get; set; }

        /// <summary>
        /// Gets or sets the agrega envelope.
        /// </summary>
        /// <value>
        /// The agrega envelope.
        /// </value>
        public string AGREGA_ENVELOPE { get; set; }

        /// <summary>
        /// Gets or sets the estado.
        /// </summary>
        /// <value>
        /// The estado.
        /// </value>
        public string ESTADO { get; set; }

        /// <summary>
        /// Gets or sets the data criacao.
        /// </summary>
        /// <value>
        /// The data criacao.
        /// </value>
        public string DATA_CRIACAO { get; set; }

        /// <summary>
        /// Gets or sets the data impressao.
        /// </summary>
        /// <value>
        /// The data impressao.
        /// </value>
        public string DATA_IMPRESSAO { get; set; }

        /// <summary>
        /// Gets or sets the atributos.
        /// </summary>
        /// <value>
        /// The atributos.
        /// </value>
        public string ATRIBUTOS { get; set; }

        /// <summary>
        /// Gets or sets the document XML.
        /// </summary>
        /// <value>
        /// The document XML.
        /// </value>
        public string DOC_XML { get; set; }

        /// <summary>
        /// Gets or sets the number copias.
        /// </summary>
        /// <value>
        /// The number copias.
        /// </value>
        public string NUM_COPIAS { get; set; }

        /// <summary>
        /// Gets or sets the data alteracao.
        /// </summary>
        /// <value>
        /// The data alteracao.
        /// </value>
        public string DATA_ALTERACAO { get; set; }

        /// <summary>
        /// Gets or sets the motivo alteracao.
        /// </summary>
        /// <value>
        /// The motivo alteracao.
        /// </value>
        public string MOTIVO_ALTERACAO { get; set; }

        /// <summary>
        /// Gets or sets the companhia.
        /// </summary>
        /// <value>
        /// The companhia.
        /// </value>
        public string COMPANHIA { get; set; }
    }
 }

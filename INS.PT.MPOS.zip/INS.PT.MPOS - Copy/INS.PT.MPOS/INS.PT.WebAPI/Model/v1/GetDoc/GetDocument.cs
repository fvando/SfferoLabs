﻿

// Copyright Ageas 2019 © - Integration Team

using ins.pt.WebAPI.Interface;
using ins.pt.WebAPI.Interface.V1;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// GetDocument
    /// </summary>
    public class GetDocument
    {
        /// <summary>
        /// Gets or sets the inputdata.
        /// </summary>
        /// <value>
        /// The inputdata.
        /// </value>
        public InputGetDoc Inputdata { get; set; }

        /// <summary>
        /// Gets or sets the out put data.
        /// </summary>
        /// <value>
        /// The out put data.
        /// </value>
        public OutDataCursor OutPutData { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public class OutPutGetDocument : IOutErrors<OutDataCursor>
        {
            /// <summary>
            /// Gets or sets the data.
            /// </summary>
            /// <value>
            /// The data.
            /// </value>
            public List<OutDataCursor> Data { get; set; }
            /// <summary>
            /// Gets or sets the errors.
            /// </summary>
            /// <value>
            /// The errors.
            /// </value>
            //[JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            public List<Error> Errors { get; set; }
        }


    }
}

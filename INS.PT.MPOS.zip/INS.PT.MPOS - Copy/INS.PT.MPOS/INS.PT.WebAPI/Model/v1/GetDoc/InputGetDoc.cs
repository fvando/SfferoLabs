﻿

// Copyright Ageas 2019 © - Integration Team

using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// InputGetDoc
    /// </summary>
    public class InputGetDoc
    {

        ///// <summary>
        ///// Nome de usuário
        ///// </summary>
        public AgentContextApp AgentContext { get; set; }

        /// <summary>
        /// documentId
        /// </summary>
        ///<example>112587628</example>
        public string DocumentId { get; set; }

        ///// <summary>
        ///// company
        ///// </summary>
        ///<example>0020</example>
        [Required]
        public string CompanyId { get; set; }

        /// <summary>
        /// policy
        /// </summary>
        ///<example>004511451548</example>
        [Required]
        public string PolicyId { get; set; }
        /// <summary>
        /// receipt
        /// </summary>
        ///<example>52168387</example>
        [Required]
        public string ReceiptId { get; set; }
 
    }

}

﻿

// Copyright Ageas 2019 © - Integration Team


namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// OutDataCursor
    /// </summary>
    public class OutDataCursor
    {
        /// <summary>
        /// Gets or sets the document identifier.
        /// </summary>
        /// <value>
        /// The document identifier.
        /// </value>
        public string DOC_ID { get; set; }
        /// <summary>
        /// Gets or sets the estado.
        /// </summary>
        /// <value>
        /// The estado.
        /// </value>
        public string ESTADO { get; set; }
    }
}

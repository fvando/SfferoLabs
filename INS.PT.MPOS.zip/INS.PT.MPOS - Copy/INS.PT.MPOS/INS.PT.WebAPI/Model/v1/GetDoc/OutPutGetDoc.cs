﻿

// Copyright Ageas 2019 © - Integration Team

using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// OutputGetDoc
    /// </summary>
    public class OutputGetDoc
    {
        /// <summary>
        /// Gets or sets the document identifier.
        /// </summary>
        /// <value>
        /// The document identifier.
        /// </value>
        [Required]
        public string DocId { get; set; }


        /// <summary>
        /// pdf
        /// </summary>
        ///<example>JVBERi(...)VFT0YNCg==</example>
        [Required]
        public string Pdf { get; set; }

    }
}

﻿

// Copyright Ageas 2019 © - Integration Team

using System.ComponentModel.DataAnnotations;

namespace INS.PT.WebAPI.Model.v1
{
    /// <summary>
    /// DocInput
    /// </summary>
    public class DocInput
    {
        /// <summary>
        /// Gets or sets the document identifier.
        /// </summary>
        /// <value>
        /// The document identifier.
        /// </value>
        [Required]
        public long DocumentId { get; set; }
    }
}

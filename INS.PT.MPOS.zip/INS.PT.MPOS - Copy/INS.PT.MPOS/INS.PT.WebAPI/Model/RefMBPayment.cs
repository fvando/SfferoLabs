﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model
{
    /// <summary>
    /// 
    /// </summary>
    public class RefMBPayment
    {
        /// <summary>
        /// InputRefMBPayment
        /// </summary>
        public class InputRefMBPayment
        {

            /// <summary>
            /// paymentBrand
            /// </summary>
            ///<example>2</example>
            [Required]
            public string paymentBrand { get; set; } = "2";

            /// <summary>
            /// internalCompany
            /// </summary>
            ///<example>1234</example>
            [Required]
            public string internalCompany { get; set; } = "1234";

            /// <summary>
            /// appOrigemId
            /// </summary>
            ///<example>APP1</example>
            [Required]
            public string appOrigemId { get; set; } = "APP1";


            /// <summary>
            /// nif
            /// </summary>
            ///<example>123456789</example>
            [Required]
            public string nif { get; set; } = "123456789";


            /// <summary>
            /// totalAmount
            /// </summary>
            ///<example>900.00</example>
            [Required]
            public double totalAmount { get; set; } = 900.00;


            /// <summary>
            /// userId
            /// </summary>
            ///<example>joao.ferreira</example>
            [Required]
            public string userId { get; set; } = "joao.ferreira";



            /// <summary>
            /// ptmntEntty
            /// </summary>
            ///<example>25002</example>
            [Required]
            public string ptmntEntty { get; set; } = "25002";



            /// <summary>
            /// refIntlDtTm
            /// </summary>
            ///<example>2019-03-15T12:28:32.001+01:00</example>
            [Required]
            public string refIntlDtTm { get; set; } = "2019-03-15T12:28:32.001+01:00";



            /// <summary>
            /// refLmtDtTm
            /// </summary>
            ///<example>APP1</example>
            [Required]
            public string refLmtDtTm { get; set; } = "2019-04-15T13:28:32.001+01:00";




            /// <summary>
            /// bulkPrint
            /// </summary>
            ///<example>false</example>
            [Required]
            public bool bulkPrint { get; set; } = false;



            /// <summary>
            /// sendEmail
            /// </summary>
            ///<example>false</example>
            [Required]
            public bool sendEmail { get; set; } = false;

            /// <summary>
            /// localPrint
            /// </summary>
            ///<example>false</example>
            [Required]
            public bool localPrint { get; set; } = false;

            /// <summary>
            /// receipts
            /// </summary>
            [Required]
            public PaymentReceipt[] receipts { get; set; }


            /// <summary>
            /// exclusive
            /// </summary>
            ///<example>false</example>
            [Required]
            public bool exclusive { get; set; } = false;


        }

        /// <summary>
        /// OutputLogin
        /// </summary>
        public class OutputRefMBPayment
        {

            /// <summary>
            /// merchantTransactionId
            /// </summary>
            ///<example>1234</example>
            public string merchantTransactionId { get; set; } = "1234";
            
            /// <summary>
            /// status
            /// </summary>
            ///<example>OK</example>
            [Required]
            public string status { get; set; } = "OK";


            /// <summary>
            /// errorMessage
            /// </summary>
            ///<example>Não foi possível gerar o ‘merchantTransactionid’</example>
            [Required]
            public string errorMessage { get; set; } = "Não foi possível gerar o ‘merchantTransactionid’";


            /// <summary>
            /// amount
            /// </summary>
            ///<example>900.00</example>
            [Required]
            public double amount { get; set; } = 900.00;


            /// <summary>
            /// reference
            /// </summary>
            ///<example>240026924</example>
            [Required]
            public string reference { get; set; } = "240026924";


            /// <summary>
            /// entity
            /// </summary>
            ///<example>25002</example>
            [Required]
            public string entity { get; set; } = "25002";

        }

    }
}

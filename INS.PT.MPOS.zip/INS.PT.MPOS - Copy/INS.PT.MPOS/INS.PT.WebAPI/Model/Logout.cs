﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model
{
    /// <summary>
    /// 
    /// </summary>
    public class Logout
    {
        /// <summary>
        /// InputLogin
        /// </summary>
        public class InputLogout
        {
            /// <summary>
            /// agentContext
            /// </summary>
            [Required]
            public AgentContextApp agentContext { get; set; } = new AgentContextApp(); 

        }

        /// <summary>
        /// OutputLogin
        /// </summary>
        public class OutputLogout
        {
            /// <summary>
            /// error
            /// </summary>
            [Required]
            public Error error { get; set; } = new Error();

        }

    }
}

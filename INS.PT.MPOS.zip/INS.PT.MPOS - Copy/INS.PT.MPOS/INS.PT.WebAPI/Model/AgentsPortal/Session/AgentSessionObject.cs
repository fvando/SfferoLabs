﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using INS.PT.WebAPI.Models.AgentsPortal.Agent.Elements;
using INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity;
using INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement.Elements;
using INS.PT.WebAPI.Models.DTO.Agent;

namespace INS.PT.WebAPI.Models.Session
{
    public class AgentSessionObject
    {
        public List<AgentCSElement> Agents { get; set; }
        public List<CompanyDto> CommercialStruture { get; set; }
        public UserElement UserProfile { get; set; }
    }
}



// Copyright Ageas 2019 � - Integration Team

using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;
using static INS.PT.WebAPI.Constants.AgentsPortalEnums;

namespace INS.PT.WebAPI.Models.AgentsPortal.Agent
{

    /// <summary>
    /// InputCommercialStructureAgent
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class AgentInput
    {
        /// <summary>
        /// Gets or sets the p cdagente.
        /// </summary>
        /// <value>Gets or sets the p cdagente.</value>
        [ExcludeFromCodeCoverage]
        [JsonProperty(PropertyName = "Code")]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the p tipo.
        /// </summary>
        /// <value>Gets or sets the p tipo.</value>
        [ExcludeFromCodeCoverage]
        [JsonProperty(PropertyName = "Type")]
        public ReferenceTypePerson Type { get; set; } = ReferenceTypePerson.Agent;
    }
}

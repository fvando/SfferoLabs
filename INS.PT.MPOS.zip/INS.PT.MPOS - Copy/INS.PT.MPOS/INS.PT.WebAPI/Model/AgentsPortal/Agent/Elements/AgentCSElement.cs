

// Copyright Ageas 2019 � - Integration Team

using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Agent.Elements
{

    /// <summary>
    /// AgentCS
    /// </summary>
    
    [Serializable]
    public class AgentCSElement
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>Gets or sets the identifier.</value>
        
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>Gets or sets the code.</value>
        
        [JsonProperty(PropertyName = "code")]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        [JsonProperty(PropertyName = "status")]

        public string Status { get; set; }

        [JsonProperty(PropertyName = "statusinitialdate")]

        public DateTime? StatusInitialDate { get; set; }

        [JsonProperty(PropertyName = "statusenddate")]
        public DateTime? StatusEndDate { get; set; }

        /// <summary>
        /// Agents name.
        /// </summary>
        /// <value>Agents name.</value>

        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the asf number.
        /// </summary>
        /// <value>Gets or sets the asf number.</value>
        
        [JsonProperty(PropertyName = "asfNumber")]
        public string AsfNumber { get; set; }

        /// <summary>
        /// Gets or sets the asf product code.
        /// </summary>
        /// <value>Gets or sets the asf product code.</value>
        
        [JsonProperty(PropertyName = "asfProductCode")]
        public string AsfProductCode { get; set; }

        /// <summary>
        /// Gets or sets the asf product code description.
        /// </summary>
        /// <value>Gets or sets the asf product code description.</value>
        
        [JsonProperty(PropertyName = "asfProductCodeDescription")]
        public string AsfProductCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets the identifier address.
        /// </summary>
        /// <value>Gets or sets the identifier address.</value>
        
        [JsonProperty(PropertyName = "idAddress")]
        public string IdAddress { get; set; }

        /// <summary>
        /// Birthdate.
        /// </summary>
        /// <value>Birthdate.</value>
        
        [JsonProperty(PropertyName = "birthdate")]
        public DateTime? Birthdate { get; set; }

        /// <summary>
        /// List of phones.
        /// </summary>
        /// <value>List of phones.</value>
        
        [JsonProperty(PropertyName = "phones")]
        public List<PhoneCSElement> Phones { get; set; }

        /// <summary>
        /// List of addresses.
        /// </summary>
        /// <value>List of addresses.</value>
        
        [JsonProperty(PropertyName = "addresses")]
        public List<AddressCSElement> Addresses { get; set; }

        /// <summary>
        /// Gets or sets the email.
        /// </summary>
        /// <value>Gets or sets the identifier address.</value>
        
        [JsonProperty(PropertyName = "emails")]
        public List<EmailCSElement> Emails { get; set; }

        /// <summary>
        /// List of nationalities.
        /// </summary>
        /// <value>List of nationalities.</value>
        
        [JsonProperty(PropertyName = "nationalities")]
        public List<NationalityCSElement> Nationalities { get; set; }

        /// <summary>
        /// Gets or sets the Document List.
        /// </summary>
        /// <value>Gets or sets the identifier documents.</value>
        
        [JsonProperty(PropertyName = "documents")]
        public List<DocumentCSElement> Documents { get; set; }
    }
}

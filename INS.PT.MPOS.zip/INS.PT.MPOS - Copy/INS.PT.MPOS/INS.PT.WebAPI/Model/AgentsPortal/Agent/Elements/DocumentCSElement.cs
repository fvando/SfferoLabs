﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Agent.Elements
{
    /// <summary>
    /// 
    /// </summary>
    
    public class DocumentCSElement
    {
        /// <summary>
        /// Document type code.
        /// </summary>
        /// <value>Document type code.</value>
        
        [JsonProperty(PropertyName = "documentTypeCode")]
        public string DocumentTypeCode { get; set; }

        /// <summary>
        /// Document type description.
        /// </summary>
        /// <value>Document type description.</value>
        
        [JsonProperty(PropertyName = "documentTypeDescription")]
        public string DocumentTypeDescription { get; set; }

        /// <summary>
        /// Document number.
        /// </summary>
        /// <value>Document number.</value>
        
        [JsonProperty(PropertyName = "documentNumber")]
        public string DocumentNumber { get; set; }
    }
}

﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Agent.Elements
{
    /// <summary>
    /// AddressCSElement
    /// </summary>

    public class AddressCSElement
    {
        /// <summary>
        /// Full address.
        /// </summary>
        /// <value>Full address.</value>
                
        [JsonProperty(PropertyName = "fullAddress")]
        public string FullAddress { get; set; }

        /// <summary>
        /// Locality.
        /// </summary>
        /// <value>Locality.</value>
        
        [JsonProperty(PropertyName = "locality")]
        public string Locality { get; set; }

        /// <summary>
        /// Postal code.
        /// </summary>
        /// <value>Postal code.</value>
        
        [JsonProperty(PropertyName = "postalCode")]
        public string PostalCode { get; set; }

        /// <summary>
        /// Postal code description.
        /// </summary>
        /// <value>Postal code description.</value>
        
        [JsonProperty(PropertyName = "postalCodeDescription")]
        public string PostalCodeDescription { get; set; }

        /// <summary>
        /// Country description.
        /// </summary>
        /// <value>Country description.</value>
        
        [JsonProperty(PropertyName = "countryDescription")]
        public string CountryDescription { get; set; }
    }
}

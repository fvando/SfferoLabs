﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Agent.Elements
{
    /// <summary>
    /// Nationality object.
    /// </summary>
    
    public class NationalityCSElement
    {
        /// <summary>
        /// Description.
        /// </summary>
        /// <value>Description.</value>
        
        [JsonProperty(PropertyName = "nationalityDescription")]
        public string Nationality { get; set; }
    }
}

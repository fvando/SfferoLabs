

// Copyright Ageas 2019 � - Integration Team

using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity;

namespace INS.PT.WebAPI.Models.AgentsPortal.Agent
{
    /// <summary>
    /// OutputEntityAgent
    /// </summary>

    public class AgentOutput
    {
        /// <summary>
        /// Entity id.
        /// </summary>
        /// <value>Entity id.</value>

        [JsonProperty(PropertyName = "idEntity")]
        public string IdEntity { get; set; }

        /// <summary>
        /// Vat number.
        /// </summary>
        /// <value>Vat number.</value>

        [JsonProperty(PropertyName = "vatNumber")]
        public string VatNumber { get; set; }

        /// <summary>
        /// Gets or sets the p cdagente.
        /// </summary>
        /// <value>Gets or sets the p cdagente.</value>

        [JsonProperty(PropertyName = "Code")]
        public string Code { get; set; }

        /// <summary>
        /// Document of Identification
        /// </summary>
        /// <value>Document of Identification.</value>

        [JsonProperty(PropertyName = "identificationNumber")]
        public string IdentificationNumber { get; set; }

        /// <summary>
        /// Document of Social Security 
        /// </summary>
        /// <value>Document of Social Security.</value>

        [JsonProperty(PropertyName = "socialSecurityNumber")]
        public string SocialSecurityNumber { get; set; }

        /// <summary>
        /// ASFNumber
        /// </summary>
        /// <value>ASFNumber</value>

        [JsonProperty(PropertyName = "asfNumber")]
        public string ASFNumber { get; set; }

        /// <summary>
        /// Birthdate.
        /// </summary>
        /// <value>Birthdate.</value>

        [JsonProperty(PropertyName = "birthdate")]
        public DateTime? Birthdate { get; set; }

        /// <summary>
        /// Description.
        /// </summary>
        /// <value>Description.</value>

        [JsonProperty(PropertyName = "nationalityDescription")]
        public string NationalityDescription { get; set; }

        /// <summary>
        /// Lists of all contacts types.
        /// </summary>
        /// <value>Lists of all contacts types.</value>

        [JsonProperty(PropertyName = "contacts")]
        public ContactListsElement Contacts { get; set; }

        /// <summary>
        /// List of addresses.
        /// </summary>
        /// <value>List of addresses.</value>

        [JsonProperty(PropertyName = "addresses")]
        public List<EntityAddressElement> Addresses { get; set; }
    }
}

﻿using INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement.Elements;
using INS.PT.WebAPI.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement
{
    /// <summary>
    /// GetLevelsWaspOutput
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Models.Base.WaspBaseOutput" />
    
    public class GetLevelsWaspOutput : WaspBaseOutput
    {
        
        public LevelElement[] LevelsList { get; set; }
    }
}

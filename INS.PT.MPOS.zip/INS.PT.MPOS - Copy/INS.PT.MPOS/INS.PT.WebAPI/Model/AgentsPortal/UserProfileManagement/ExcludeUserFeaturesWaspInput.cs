﻿using INS.PT.WebAPI.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement
{
    /// <summary>
    /// ExcludeUserFeaturesWaspInput
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Models.Base.WaspBaseInput" />
    
    public class ExcludeUserFeaturesWaspInput : WaspBaseInput
    {
        
        public int[] IDFeature { get; set; }
        
        public int IDUser { get; set; }
        
        public bool IDUserSpecified { get; set; }
        
        public string UserCode { get; set; }
    }
}

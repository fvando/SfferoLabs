﻿

// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement.Elements;
using INS.PT.WebAPI.Models.Base;
using INS.PT.WebAPI.Models.Base.v1;

namespace INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement
{

    /// <summary>
    /// GetProfileDetailsWaspOutput
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Models.Base.WaspBaseOutput" />
    public class GetProfileDetailsWaspOutput : WaspBaseOutput
    {
        /// <summary>
        /// Gets or sets the profile.
        /// </summary>
        /// <value>
        /// The profile.
        /// </value>
        public ProfileElement Profile { get; set; }
    }
}

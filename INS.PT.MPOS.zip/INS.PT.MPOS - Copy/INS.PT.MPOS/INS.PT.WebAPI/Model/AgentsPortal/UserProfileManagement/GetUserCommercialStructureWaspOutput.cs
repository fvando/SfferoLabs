﻿

// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement.Elements;
using INS.PT.WebAPI.Models.Base;
using INS.PT.WebAPI.Models.Base.v1;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement
{
    /// <summary>
    /// GetUserDetailWaspOutput
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Models.Base.WaspBaseOutput" />
    public class GetUserCommercialStructureWaspOutput : WaspBaseOutput
    {
        /// <summary>
        /// Gets or sets the user.
        /// </summary>
        /// <value>
        /// The user.
        /// </value>
        public List<UserElement> UserList { get; set; }
    }
}

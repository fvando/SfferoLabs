﻿using INS.PT.WebAPI.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement
{
    /// <summary>
    /// ExcludeUserWaspInput
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Models.Base.WaspBaseInput" />
    
    public class ExcludeUserWaspInput : WaspBaseInput
    {
        
        public string Email { get; set; }
        
        public string UserCode { get; set; }
        
        public int UserID { get; set; }
        
        public bool UserIDSpecified { get; set; }
    }
}

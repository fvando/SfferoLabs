﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;
using System;

namespace INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement.Elements
{
    /// <summary>
    /// NavCategoryElement
    /// </summary>
    public class NavCategoryElement
    {
        /// <summary>
        /// DateCreated
        /// </summary>
        /// <value>DateCreated</value>
        [JsonProperty(PropertyName = "dateCreated")]
        public DateTime DateCreated { get; set; }
        /// <summary>
        /// DateCreatedSpecified
        /// </summary>
        /// <value>DateCreatedSpecified</value>
        [JsonProperty(PropertyName = "dateCreatedSpecified")]
        public bool DateCreatedSpecified { get; set; }
        /// <summary>
        /// Id
        /// </summary>
        /// <value>Id</value>
        [JsonProperty(PropertyName = "id")]
        public int Id { get; set; }
        /// <summary>
        /// IdSpecified
        /// </summary>
        /// <value>IdSpecified</value>
        [JsonProperty(PropertyName = "idSpecified")]
        public bool IdSpecified { get; set; }
        /// <summary>
        /// Menu
        /// </summary>
        /// <value>Menu</value>
        [JsonProperty(PropertyName = "menu")]
        public string Menu { get; set; }
        /// <summary>
        /// Stage0
        /// </summary>
        /// <value>Stage0</value>
        [JsonProperty(PropertyName = "stage0")]
        public string Stage0 { get; set; }
        /// <summary>
        /// Stage1
        /// </summary>
        /// <value>Stage1</value>
        [JsonProperty(PropertyName = "stage1")]
        public string Stage1 { get; set; }
        /// <summary>
        /// Stage2
        /// </summary>
        /// <value>Stage2</value>
        [JsonProperty(PropertyName = "stage2")]
        public string Stage2 { get; set; }
    }
}

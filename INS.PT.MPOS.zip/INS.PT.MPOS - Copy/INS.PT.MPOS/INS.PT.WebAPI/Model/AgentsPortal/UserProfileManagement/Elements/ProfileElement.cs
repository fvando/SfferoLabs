﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;
using System;

namespace INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement.Elements
{
    /// <summary>
    /// ProfileElement
    /// </summary>
    public class ProfileElement
    {
        /// <summary>
        /// Active
        /// </summary>
        /// <value>Active</value>
        [JsonProperty(PropertyName = "active")]
        public bool Active { get; set; }
        /// <summary>
        /// ActiveSpecified
        /// </summary>
        /// <value>ActiveSpecified</value>
        [JsonProperty(PropertyName = "activeSpecified")]
        public bool ActiveSpecified { get; set; }
        /// <summary>
        /// DateCreated
        /// </summary>
        /// <value>DateCreated</value>
        [JsonProperty(PropertyName = "dateCreated")]
        public DateTime DateCreated { get; set; }
        /// <summary>
        /// DateCreatedSpecified
        /// </summary>
        /// <value>DateCreatedSpecified</value>
        [JsonProperty(PropertyName = "dateCreatedSpecified")]
        public bool DateCreatedSpecified { get; set; }
        /// <summary>
        /// Description
        /// </summary>
        /// <value>Description</value>
        [JsonProperty(PropertyName = "description")]
        public string Description { get; set; }
        /// <summary>
        /// Features
        /// </summary>
        /// <value>Features</value>
        [JsonProperty(PropertyName = "features")]
        public FeatureElement[] Features { get; set; }
        /// <summary>
        /// Id
        /// </summary>
        /// <value>Id</value>
        [JsonProperty(PropertyName = "id")]
        public int Id { get; set; }
        /// <summary>
        /// IdSpecified
        /// </summary>
        /// <value>IdSpecified</value>
        [JsonProperty(PropertyName = "idSpecified")]
        public bool IdSpecified { get; set; }
        /// <summary>
        /// Name
        /// </summary>
        /// <value>Name</value>
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }
        
        /// <summary>
        /// UserCode
        /// </summary>
        /// <value>UserCode</value>
        [JsonProperty(PropertyName = "userCode")]
        public string UserCode { get; set; }
    }
}

﻿

// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement.Elements;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Model.AgentsPortal.UserProfileManagement.Elements
{
    public class CommercialStructureElement
    {
        [JsonProperty(PropertyName = "active")]
        public bool Active { get; set; }

        [JsonProperty(PropertyName = "createddate")]
        public System.DateTime CreatedDate { get; set; }

        [JsonProperty(PropertyName = "createdDateFieldSpecified")]
        public bool CreatedDateFieldSpecified { get; set; }

        [JsonProperty(PropertyName = "entityCode")]
        public string EntityCode { get; set; }

        [JsonProperty(PropertyName = "entityId")]
        public int EntityId { get; set; }

        [JsonProperty(PropertyName = "entityIdFieldSpecified")]
        public bool EntityIdFieldSpecified { get; set; }

        [JsonProperty(PropertyName = "id")]
        public int Id { get; set; }

        [JsonProperty(PropertyName = "idFieldSpecified")]
        public bool IdFieldSpecified { get; set; }

        [JsonProperty(PropertyName = "level")]
        public LevelElement Level { get; set; }

        [JsonProperty(PropertyName = "profile")]
        public ProfileElement Profile { get; set; }

        [JsonProperty(PropertyName = "userCode")]
        public string UserCode { get; set; }

        [JsonProperty(PropertyName = "grupoAgregador")]
        public string GrupoAgregador { get; set; }


        [JsonProperty(PropertyName = "tipoAgregador")]
        public string TipoAgregador { get; set; }

    }
}

﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;
using System;

namespace INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement.Elements
{
    /// <summary>
    /// FeatureElement
    /// </summary>
    public class FeatureElement
    {
        /// <summary>
        /// Active
        /// </summary>
        /// <value>Active</value>
        [JsonProperty(PropertyName = "active")]
        public bool Active { get; set; }
        /// <summary>
        /// ActiveSpecified
        /// </summary>
        /// <value>ActiveSpecified</value>
        [JsonProperty(PropertyName = "activeSpecified")]
        public bool ActiveSpecified { get; set; }
        /// <summary>
        /// Characteristics
        /// </summary>
        /// <value>Characteristics</value>
        [JsonProperty(PropertyName = "characteristics")]
        public CharacteristicElement[] Characteristics { get; set; }
        /// <summary>
        /// Code
        /// </summary>
        /// <value>Code</value>
        [JsonProperty(PropertyName = "code")]
        public string Code { get; set; }
        /// <summary>
        /// DateCreated
        /// </summary>
        /// <value>DateCreated</value>
        [JsonProperty(PropertyName = "dateCreated")]
        public DateTime DateCreated { get; set; }
        /// <summary>
        /// DateCreatedSpecified
        /// </summary>
        /// <value>DateCreatedSpecified</value>
        [JsonProperty(PropertyName = "dateCreatedSpecified")]
        public bool DateCreatedSpecified { get; set; }
        /// <summary>
        /// Description
        /// </summary>
        /// <value>Description</value>
        [JsonProperty(PropertyName = "description")]
        public string Description { get; set; }
        /// <summary>
        /// Id
        /// </summary>
        /// <value>Id</value>
        [JsonProperty(PropertyName = "id")]
        public int Id { get; set; }
        /// <summary>
        /// IdSpecified
        /// </summary>
        /// <value>IdSpecified</value>
        [JsonProperty(PropertyName = "idSpecified")]
        public bool IdSpecified { get; set; }
        /// <summary>
        /// NavCategory
        /// </summary>
        /// <value>NavCategory</value>
        [JsonProperty(PropertyName = "navCategory")]
        public NavCategoryElement NavCategory { get; set; }
    }
}

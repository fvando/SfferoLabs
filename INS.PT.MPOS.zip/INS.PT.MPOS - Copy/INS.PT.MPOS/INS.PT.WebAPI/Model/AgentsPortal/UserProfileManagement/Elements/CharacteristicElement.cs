﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement.Elements
{
    /// <summary>
    /// CharacteristicElement
    /// </summary>
    public class CharacteristicElement
    {
        /// <summary>
        /// code
        /// </summary>
        /// <value>code</value>
        [JsonProperty(PropertyName = "Code")]
        public string Code { get; set; }
        /// <summary>
        /// Description
        /// </summary>
        /// <value>Description</value>
        [JsonProperty(PropertyName = "description")]
        public string Description { get; set; }
        /// <summary>
        /// Id
        /// </summary>
        /// <value>Id</value>
        [JsonProperty(PropertyName = "id")]
        public int? Id { get; set; }
        /// <summary>
        /// IdSpecified
        /// </summary>
        /// <value>IdSpecified</value>
        [JsonProperty(PropertyName = "idSpecified")]
        public bool IdSpecified { get; set; }
    }
}

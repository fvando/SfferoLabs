﻿

// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Model.AgentsPortal.UserProfileManagement.Elements;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement.Elements
{
    /// <summary>
    /// UserElement
    /// </summary>
   
    public class UserElement
    {
        /// <summary>
        /// Gets or sets the collaborators.
        /// </summary>
        /// <value>
        /// The collaborators.
        /// </value>
        [JsonProperty(PropertyName = "collaborators")]
        public List<UserElement> Collaborators { get; set; }
        
        /// <summary>
        /// Gets or sets the commercial structures.
        /// </summary>
        /// <value>
        /// The commercial structures.
        /// </value>
        [JsonProperty(PropertyName = "CommercialStructures")]
        public List<CommercialStructureElement> CommercialStructures { get; set; }
        
        /// <summary>
        /// CreatedDate
        /// </summary>
        /// <value>CreatedDate</value>
        [JsonProperty(PropertyName = "createdDate")]
        public DateTime CreatedDate { get; set; }
        
        /// <summary>
        /// CreatedDateSpecified
        /// </summary>
        /// <value>CreatedDateSpecified</value>
        [JsonProperty(PropertyName = "createdDateSpecified")]
        public bool CreatedDateSpecified { get; set; }
        
        /// <summary>
        /// Email
        /// </summary>
        /// <value>Email</value>
        [JsonProperty(PropertyName = "email")]
        public string Email { get; set; }
        
        /// <summary>
        /// EntityCode
        /// </summary>
        /// <value>EntityCode</value>
        [JsonProperty(PropertyName = "entityCode")]
        public string EntityCode { get; set; }
        
        /// <summary>
        /// EntityCodeSpecified
        /// </summary>
        /// <value>EntityCodeSpecified</value>
        [JsonProperty(PropertyName = "entityCodeSpecified")]
        public bool EntityCodeSpecified { get; set; }
        
        /// <summary>
        /// Id
        /// </summary>
        /// <value>Id</value>
        [JsonProperty(PropertyName = "id")]
        public int Id { get; set; }
        
        /// <summary>
        /// IdSpecified
        /// </summary>
        /// <value>IdSpecified</value>
        public bool IdSpecified { get; set; }
        
        /// <summary>
        /// Level
        /// </summary>
        /// <value>Level</value>
        [JsonProperty(PropertyName = "level")]
        public LevelElement Level { get; set; }
        
        /// <summary>
        /// MaxCollaborators
        /// </summary>
        /// <value>MaxCollaborators</value>
        [JsonProperty(PropertyName = "maxCollaborators")]
        public int MaxCollaborators { get; set; }
        
        /// <summary>
        /// MaxCollaboratorsSpecified
        /// </summary>
        /// <value>MaxCollaboratorsSpecified</value>
        [JsonProperty(PropertyName = "maxCollaboratorsSpecified")]
        public bool MaxCollaboratorsSpecified { get; set; }
        
        /// <summary>
        /// Name
        /// </summary>
        /// <value>Name</value>
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }
        
        /// <summary>
        /// PhoneNumber
        /// </summary>
        /// <value>PhoneNumber</value>
        [JsonProperty(PropertyName = "phoneNumber")]
        public string PhoneNumber { get; set; }
        
        /// <summary>
        /// PhoneNumberSpecified
        /// </summary>
        /// <value>PhoneNumberSpecified</value>
        [JsonProperty(PropertyName = "phoneNumberSpecified")]
        public bool PhoneNumberSpecified { get; set; }
        
        /// <summary>
        /// Profile
        /// </summary>
        /// <value>Profile</value>        
        [JsonProperty(PropertyName = "profile")]
        public ProfileElement Profile { get; set; }
        
        /// <summary>
        /// State
        /// </summary>
        /// <value>State</value>        
        [JsonProperty(PropertyName = "state")]
        public StateElement State { get; set; }
        
        /// <summary>
        /// UserCode
        /// </summary>
        /// <value>UserCode</value>        
        [JsonProperty(PropertyName = "userCode")]
        public string UserCode { get; set; }

        [JsonProperty(PropertyName = "grupoAgregador")]
        public string GrupoAgregador { get; set; }


        [JsonProperty(PropertyName = "tipoAgregador")]
        public string TipoAgregador { get; set; }
    }
}

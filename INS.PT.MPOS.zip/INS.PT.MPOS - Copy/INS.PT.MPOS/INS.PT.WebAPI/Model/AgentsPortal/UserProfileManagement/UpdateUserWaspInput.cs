﻿using INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement.Elements;
using INS.PT.WebAPI.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement
{
    /// <summary>
    /// UpdateUserWaspInput
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Models.Base.WaspBaseInput" />
    
    public class UpdateUserWaspInput : WaspBaseInput
    {
        
        public UserElement User { get; set; }
    }
}

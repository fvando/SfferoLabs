﻿using INS.PT.WebAPI.Models.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement
{
    /// <summary>
    /// GetUsersWaspInput
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Models.Base.WaspBaseInput" />
    
    public class GetUsersWaspInput : WaspBaseInput
    {
        
        public int? CodEntidade { get; set; }
        
        public bool CodEntidadeSpecified { get; set; }
        
        public int? Level { get; set; }
        
        public bool LevelSpecified { get; set; }
        
        public string Name { get; set; }
        
        public int? NumberOfRecords { get; set; }
        
        public bool NumberOfRecordsSpecified { get; set; }
        
        public int? PageNumber { get; set; }
        
        public bool PageNumberSpecified { get; set; }
        
        public int? Profile { get; set; }
        
        public bool ProfileSpecified { get; set; }
        
        public string State { get; set; }
    }
}

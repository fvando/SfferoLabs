﻿using INS.PT.WebAPI.Models.AgentsPortal.Agent.Elements;
using INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity;
using INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement.Elements;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.Security
{
    public class AgentContext
    {
        public List<AgentCSElement> Agents { get; set; }
        public List<CompanyCSElement> CommercialStructure { get; set; }
        public UserElement UserProfile { get; set; }
        public EntityElement Entity { get; set; }
    }
}
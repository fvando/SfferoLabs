﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using INS.PT.WebAPI.Models.AgentsPortal.Agent.Elements;
using INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity;
using INS.PT.WebAPI.Models.AgentsPortal.UserProfileManagement.Elements;
using INS.PT.WebAPI.Models.Base;
using INS.PT.WebAPI.Models.DTO.Agent;

namespace INS.PT.WebAPI.Models.Security
{
    public class AgentContextWaspOutput : WaspBaseOutput
    {
        public List<AgentCSElement> Agents { get; set; }
        public List<CompanyCSElement> CommercialStructure { get; set; }
        public UserElement UserProfile { get; set; }
        public EntityElement Entity { get; set; }
    }
}

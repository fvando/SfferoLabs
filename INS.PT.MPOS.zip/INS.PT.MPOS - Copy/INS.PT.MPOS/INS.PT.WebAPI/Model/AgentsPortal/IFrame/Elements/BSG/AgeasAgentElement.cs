﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.IFrame.Elements.BSG
{
    public class AgeasAgentElement
    {
        public string AgentName { get; set; }
        public string AgentCode { get; set; }
        public string OriginalCode { get; set; }
        public string OriginalLevel { get; set; }
        public bool IsPartner { get; set; }
        public string Partner { get; set; }
    }
}

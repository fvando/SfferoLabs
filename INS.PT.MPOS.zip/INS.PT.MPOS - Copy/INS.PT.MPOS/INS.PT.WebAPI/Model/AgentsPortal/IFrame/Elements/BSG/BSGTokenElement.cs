﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.IFrame.Elements.BSG
{
    public class BSGTokenElement
    {
        public string ApplicationContext { get; set; }
        public AgeasAgentElement AgeasAgent { get; set; }
        public UserInfoElement UserInfo { get; set; }
        public bool IsAGE { get; set; }
        public string PartnerProducer { get; set; }
        public string NotificationEmail { get; set; }
        public CurrentCustomerElement CurrentCustomer { get; set; }
        public PolicyInfoElement PolicyInfo { get; set; }
        public QuoteInfoElement QuoteInfo { get; set; }
        public object UrlRedirectOnExit { get; set; }
    }
}

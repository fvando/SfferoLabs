﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.IFrame.Elements.BSG
{
    public class UserInfoElement
    {
        public string UserName { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Constants.AgentsPortalEnums;

namespace INS.PT.WebAPI.Models.AgentsPortal.IFrame
{
    public class UserLoginBSGWaspInput
    {
        public BSGAplicationContext Context { get; set; }
        public string Mediator { get; set; }
        public string ClaimNumber { get; set; }
        public string PolicyNumber { get; set; }
        public string Nif { get; set; }
        public string RequestNumber { get; set; }
        public string QuoteInfoId { get; set; }

    }
}

﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.IFrame
{
    public class UserLoginBSGWaspOutput
    {        
        public string Token { get; set; }

        public string AuthenticationURL { get; set; }
    }
}

using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using INS.PT.WebAPI.Models.Common;
using INS.PT.WebAPI.Models.Collections.Elements;

namespace INS.PT.WebAPI.Models.Collections.ProvisionalWebAccounts
{
    /// <summary>
    /// Maps with DTO - ZFscdPcValidarWsOutputDTO
    /// </summary>
    
    public class ValidateChargeReceiptsWaspOutput
    {
        /// <summary>
        /// Gets or sets the errors.
        /// </summary>
        /// <value>Gets or sets the errors.</value>
        
        [JsonProperty(PropertyName = "errors")]
        public List<ErrorElement> Errors { get; set; }

        
        [JsonProperty(PropertyName = "success")]
        public bool Success { get; set; }
    }
}

using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using INS.PT.WebAPI.Models.Collections.Elements;

namespace INS.PT.WebAPI.Models.Collections.ProvisionalWebAccounts
{
    /// <summary>
    /// Maps with DTO - ZFscdPcCobrarWsOutputDTO
    /// </summary>
    
    public class ChargedReceiptsWaspOuptut
    {
        /// <summary>
        /// Gets or Sets Errors
        /// </summary>
        
        [JsonProperty(PropertyName = "errors")]
        public List<ErrorElement> Errors { get; set; }

        
        [JsonProperty(PropertyName = "success")]
        public bool Success { get; set; }
    }
}

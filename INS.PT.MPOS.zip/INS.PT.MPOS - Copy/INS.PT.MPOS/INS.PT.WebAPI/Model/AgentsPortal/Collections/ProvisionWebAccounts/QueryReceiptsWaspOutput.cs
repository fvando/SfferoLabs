﻿using INS.PT.WebAPI.Models.AgentsPortal.Collections.Elements;
using INS.PT.WebAPI.Models.Collections.Elements;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.Collections.ProvisionWebAccounts
{
    /// <summary>
    /// Maps with DTO - ZFscdPcConsultarWsResponseDTO
    /// </summary>
    public class QueryReceiptsWaspOutput
    {
        /// <summary>
        /// Gets or Sets Errors
        /// </summary>
        [JsonProperty(PropertyName = "errors")]
        public List<ErrorElement> Errors { get; set; }
        /// <summary>
        /// Gets or Sets PcDetail
        /// </summary>
        [JsonProperty(PropertyName = "detail")]
        public List<DetailReceiptLineElement> PcDetail { get; set; }
        /// <summary>
        /// Gets or Sets PcHeader
        /// </summary>
        [JsonProperty(PropertyName = "header")]
        public HeaderReceiptLineElement PcHeader { get; set; }
        /// <summary>
        /// Gets or Sets Success
        /// </summary>
        [JsonProperty(PropertyName = "success")]
        public bool Success { get; set; }
    }
}

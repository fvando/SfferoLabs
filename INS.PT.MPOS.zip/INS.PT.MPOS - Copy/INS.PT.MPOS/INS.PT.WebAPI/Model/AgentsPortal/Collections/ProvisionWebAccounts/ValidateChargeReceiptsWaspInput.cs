using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using INS.PT.WebAPI.Models.DTO.Collections.Elements;
using INS.PT.WebAPI.Models.Collections.Elements;

namespace INS.PT.WebAPI.Models.Collections.ProvisionalWebAccounts
{
    /// <summary>
    /// Maps with DTO - ZFscdPcValidarWsInputDTO
    /// </summary>
    
    public class ValidateChargeReceiptsWaspInput
    {
        /// <summary>
        /// Gets or sets the broker contract.
        /// </summary>
        /// <value>Gets or sets the broker contract.</value>
        
        [JsonProperty(PropertyName = "brokerContract")]
        public string BrokerContract { get; set; }

        /// <summary>
        /// Gets or sets the pc receipts.
        /// </summary>
        /// <value>Gets or sets the pc receipts.</value>
        
        [JsonProperty(PropertyName = "receipts")]
        public List<ReceiptElement> PcReceipts { get; set; }
    }
}

using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.Collections.Elements
{

    /// <summary>
    /// Maps with: ZfscdRecibosWorkLinhaDTO
    /// </summary>
    
    public class DetailReceiptElement
    {
        /// <summary>
        /// Gets or sets the company code.
        /// </summary>
        /// <value>Gets or sets the company code.</value>
        
        [JsonProperty(PropertyName = "companyCode")]
        public string CompanyCode { get; set; }

        /// <summary>
        /// Gets or sets the sap document number.
        /// </summary>
        /// <value>Gets or sets the sap document number.</value>
        
        [JsonProperty(PropertyName = "sapDocumentNumber")]
        public string SapDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets the type of the document.
        /// </summary>
        /// <value>Gets or sets the type of the document.</value>
        
        [JsonProperty(PropertyName = "documentType")]
        public string DocumentType { get; set; }

        /// <summary>
        /// Gets or sets the contract.
        /// </summary>
        /// <value>Gets or sets the contract.</value>
        
        [JsonProperty(PropertyName = "contract")]
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets the reference document number.
        /// </summary>
        /// <value>Gets or sets the reference document number.</value>
        
        [JsonProperty(PropertyName = "referenceDocumentNumber")]
        public string ReferenceDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets the insurance partner.
        /// </summary>
        /// <value>Gets or sets the insurance partner.</value>
        
        [JsonProperty(PropertyName = "insurancePartner")]
        public string InsurancePartner { get; set; }

        /// <summary>
        /// Gets or sets the full name.
        /// </summary>
        /// <value>Gets or sets the full name.</value>
        
        [JsonProperty(PropertyName = "fullName")]
        public string FullName { get; set; }

        /// <summary>
        /// Gets or sets the insurance payer.
        /// </summary>
        /// <value>Gets or sets the insurance payer.</value>
        
        [JsonProperty(PropertyName = "insurancePayer")]
        public string InsurancePayer { get; set; }

        /// <summary>
        /// Gets or sets the insurance agent.
        /// </summary>
        /// <value>Gets or sets the insurance agent.</value>
        
        [JsonProperty(PropertyName = "insuranceAgent")]
        public string InsuranceAgent { get; set; }

        /// <summary>
        /// Gets or sets the insurance broker.
        /// </summary>
        /// <value>Gets or sets the insurance broker.</value>
        
        [JsonProperty(PropertyName = "insuranceBroker")]
        public string InsuranceBroker { get; set; }

        /// <summary>
        /// Gets or sets the insurance inspector.
        /// </summary>
        /// <value>Gets or sets the insurance inspector.</value>
        
        [JsonProperty(PropertyName = "insuranceInspector")]
        public string InsuranceInspector { get; set; }

        /// <summary>
        /// Gets or sets the insurance other.
        /// </summary>
        /// <value>Gets or sets the insurance other.</value>
        
        [JsonProperty(PropertyName = "insuranceOther")]
        public string InsuranceOther { get; set; }

        /// <summary>
        /// signal = 'P'      Prémio  signal = 'E'      Estorno  status = 'P'      Em aberto  status = 'A'      Anulado  status = 'B'      Circuito bancário(em aberto)  status = 'C'      Cobrado  status = 'X'      Estornado(eventualmente a retirar da listagem?)
        /// </summary>
        /// <value>signal = 'P'      Prémio  signal = 'E'      Estorno  status = 'P'      Em aberto  status = 'A'      Anulado  status = 'B'      Circuito bancário(em aberto)  status = 'C'      Cobrado  status = 'X'      Estornado(eventualmente a retirar da listagem?)</value>
        
        [JsonProperty(PropertyName = "signal")]
        public string Signal { get; set; }

        /// <summary>
        /// type   = 'N'      Prémios Novos  type   = 'C'      Prémios Continuados  type   = 'A'      Alterações de Prémios
        /// </summary>
        /// <value>type   = 'N'      Prémios Novos  type   = 'C'      Prémios Continuados  type   = 'A'      Alterações de Prémios</value>
        
        [JsonProperty(PropertyName = "type")]
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets the posting date.
        /// </summary>
        /// <value>Gets or sets the posting date.</value>
        
        [JsonProperty(PropertyName = "postingDate")]
        public string PostingDate { get; set; }

        /// <summary>
        /// Gets or sets the net due date.
        /// </summary>
        /// <value>Gets or sets the net due date.</value>
        
        [JsonProperty(PropertyName = "netDueDate")]
        public string NetDueDate { get; set; }

        /// <summary>
        /// Gets or sets the billing period from.
        /// </summary>
        /// <value>Gets or sets the billing period from.</value>
        
        [JsonProperty(PropertyName = "billingPeriodFrom")]
        public string BillingPeriodFrom { get; set; }

        /// <summary>
        /// Gets or sets the billing period to.
        /// </summary>
        /// <value>Gets or sets the billing period to.</value>
        
        [JsonProperty(PropertyName = "billingPeriodTo")]
        public string BillingPeriodTo { get; set; }

        /// <summary>
        /// Gets or sets the payment order.
        /// </summary>
        /// <value>Gets or sets the payment order.</value>
        
        [JsonProperty(PropertyName = "paymentOrder")]
        public string PaymentOrder { get; set; }

        /// <summary>
        /// Gets or sets the clearing reason.
        /// </summary>
        /// <value>Gets or sets the clearing reason.</value>
        
        [JsonProperty(PropertyName = "clearingReason")]
        public string ClearingReason { get; set; }

        /// <summary>
        /// Gets or sets the clearing status.
        /// </summary>
        /// <value>Gets or sets the clearing status.</value>
        
        [JsonProperty(PropertyName = "clearingStatus")]
        public string ClearingStatus { get; set; }

        /// <summary>
        /// Gets or sets the clearing document.
        /// </summary>
        /// <value>Gets or sets the clearing document.</value>
        
        [JsonProperty(PropertyName = "clearingDocument")]
        public string ClearingDocument { get; set; }

        /// <summary>
        /// Gets or sets the clearing post date.
        /// </summary>
        /// <value>Gets or sets the clearing post date.</value>
        
        [JsonProperty(PropertyName = "clearingPostDate")]
        public string ClearingPostDate { get; set; }

        /// <summary>
        /// Gets or sets the status document.
        /// </summary>
        /// <value>Gets or sets the status document.</value>
        
        [JsonProperty(PropertyName = "statusDoc")]
        public string StatusDoc { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>Gets or sets the status.</value>
        
        [JsonProperty(PropertyName = "status")]
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the status date.
        /// </summary>
        /// <value>Gets or sets the status date.</value>
        
        [JsonProperty(PropertyName = "statusDate")]
        public string StatusDate { get; set; }

        /// <summary>
        /// Gets or sets the print date.
        /// </summary>
        /// <value>Gets or sets the print date.</value>
        
        [JsonProperty(PropertyName = "printDate")]
        public string PrintDate { get; set; }

        /// <summary>
        /// Gets or sets the type of the insurance.
        /// </summary>
        /// <value>Gets or sets the type of the insurance.</value>
        
        [JsonProperty(PropertyName = "insuranceType")]
        public string InsuranceType { get; set; }

        /// <summary>
        /// Gets or sets the type of the payment split.
        /// </summary>
        /// <value>Gets or sets the type of the payment split.</value>
        
        [JsonProperty(PropertyName = "paymentSplitType")]
        public string PaymentSplitType { get; set; }

        /// <summary>
        /// Gets or sets the payment method.
        /// </summary>
        /// <value>Gets or sets the payment method.</value>
        
        [JsonProperty(PropertyName = "paymentMethod")]
        public string PaymentMethod { get; set; }

        /// <summary>
        /// Gets or sets the billing channel.
        /// </summary>
        /// <value>Gets or sets the billing channel.</value>
        
        [JsonProperty(PropertyName = "billingChannel")]
        public string BillingChannel { get; set; }

        /// <summary>
        /// Gets or sets the return reason.
        /// </summary>
        /// <value>Gets or sets the return reason.</value>
        
        [JsonProperty(PropertyName = "returnReason")]
        public string ReturnReason { get; set; }

        /// <summary>
        /// Gets or sets the currency.
        /// </summary>
        /// <value>Gets or sets the currency.</value>
        
        [JsonProperty(PropertyName = "currency")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets the premium value.
        /// </summary>
        /// <value>Gets or sets the premium value.</value>
        
        [JsonProperty(PropertyName = "premiumValue")]
        public string PremiumValue { get; set; }

        /// <summary>
        /// Gets or sets the charges value.
        /// </summary>
        /// <value>Gets or sets the charges value.</value>
        
        [JsonProperty(PropertyName = "chargesValue")]
        public string ChargesValue { get; set; }

        /// <summary>
        /// Gets or sets the bonus value.
        /// </summary>
        /// <value>Gets or sets the bonus value.</value>
        
        [JsonProperty(PropertyName = "bonusValue")]
        public string BonusValue { get; set; }

        /// <summary>
        /// Gets or sets the atas value.
        /// </summary>
        /// <value>Gets or sets the atas value.</value>
        
        [JsonProperty(PropertyName = "atasValue")]
        public string AtasValue { get; set; }

        /// <summary>
        /// Gets or sets the inem value.
        /// </summary>
        /// <value>Gets or sets the inem value.</value>
        
        [JsonProperty(PropertyName = "inemValue")]
        public string InemValue { get; set; }

        /// <summary>
        /// Gets or sets the fga value.
        /// </summary>
        /// <value>Gets or sets the fga value.</value>
        
        [JsonProperty(PropertyName = "fgaValue")]
        public string FgaValue { get; set; }

        /// <summary>
        /// Gets or sets the green letter value.
        /// </summary>
        /// <value>Gets or sets the green letter value.</value>
        
        [JsonProperty(PropertyName = "greenLetterValue")]
        public string GreenLetterValue { get; set; }

        /// <summary>
        /// Gets or sets the anpc value.
        /// </summary>
        /// <value>Gets or sets the anpc value.</value>
        
        [JsonProperty(PropertyName = "anpcValue")]
        public string AnpcValue { get; set; }

        /// <summary>
        /// Gets or sets the seal value.
        /// </summary>
        /// <value>Gets or sets the seal value.</value>
        
        [JsonProperty(PropertyName = "sealValue")]
        public string SealValue { get; set; }

        /// <summary>
        /// Gets or sets the policy value.
        /// </summary>
        /// <value>Gets or sets the policy value.</value>
        
        [JsonProperty(PropertyName = "policyValue")]
        public string PolicyValue { get; set; }

        /// <summary>
        /// Gets or sets the fat value.
        /// </summary>
        /// <value>Gets or sets the fat value.</value>
        
        [JsonProperty(PropertyName = "fatValue")]
        public string FatValue { get; set; }

        /// <summary>
        /// Gets or sets the PRP value.
        /// </summary>
        /// <value>Gets or sets the PRP value.</value>
        
        [JsonProperty(PropertyName = "prpValue")]
        public string PrpValue { get; set; }

        /// <summary>
        /// Gets or sets the fractioning value.
        /// </summary>
        /// <value>Gets or sets the fractioning value.</value>
        
        [JsonProperty(PropertyName = "fractioningValue")]
        public string FractioningValue { get; set; }

        /// <summary>
        /// Gets or sets the total value.
        /// </summary>
        /// <value>Gets or sets the total value.</value>
        
        [JsonProperty(PropertyName = "totalValue")]
        public string TotalValue { get; set; }

        /// <summary>
        /// Gets or sets the commission promotion value.
        /// </summary>
        /// <value>Gets or sets the commission promotion value.</value>
        
        [JsonProperty(PropertyName = "commissionPromotionValue")]
        public string CommissionPromotionValue { get; set; }

        /// <summary>
        /// Gets or sets the commission charge value.
        /// </summary>
        /// <value>Gets or sets the commission charge value.</value>
        
        [JsonProperty(PropertyName = "commissionChargeValue")]
        public string CommissionChargeValue { get; set; }

        /// <summary>
        /// Gets or sets the commission inspection value.
        /// </summary>
        /// <value>Gets or sets the commission inspection value.</value>
        
        [JsonProperty(PropertyName = "commissionInspectionValue")]
        public string CommissionInspectionValue { get; set; }

        /// <summary>
        /// Gets or sets the commission agent value.
        /// </summary>
        /// <value>Gets or sets the commission agent value.</value>
        
        [JsonProperty(PropertyName = "commissionAgentValue")]
        public string CommissionAgentValue { get; set; }

        /// <summary>
        /// Gets or sets the commission other value.
        /// </summary>
        /// <value>Gets or sets the commission other value.</value>
        
        [JsonProperty(PropertyName = "commissionOtherValue")]
        public string CommissionOtherValue { get; set; }

        /// <summary>
        /// Gets or sets the total commission.
        /// </summary>
        /// <value>Gets or sets the total commission.</value>
        
        [JsonProperty(PropertyName = "totalCommission")]
        public string TotalCommission { get; set; }

        /// <summary>
        /// Gets or sets the sibs entity.
        /// </summary>
        /// <value>Gets or sets the sibs entity.</value>
        
        [JsonProperty(PropertyName = "sibsEntity")]
        public string SibsEntity { get; set; }

        /// <summary>
        /// Gets or sets the sibs reference.
        /// </summary>
        /// <value>Gets or sets the sibs reference.</value>
        
        [JsonProperty(PropertyName = "sibsReference")]
        public string SibsReference { get; set; }

        /// <summary>
        /// Gets or sets the bank details identifier.
        /// </summary>
        /// <value>Gets or sets the bank details identifier.</value>
        
        [JsonProperty(PropertyName = "bankDetailsId")]
        public string BankDetailsId { get; set; }

        /// <summary>
        /// Gets or sets the bank designation.
        /// </summary>
        /// <value>Gets or sets the bank designation.</value>
        
        [JsonProperty(PropertyName = "bankDesignation")]
        public string BankDesignation { get; set; }

        /// <summary>
        /// Gets or sets the broker report identification.
        /// </summary>
        /// <value>Gets or sets the broker report identification.</value>
        
        [JsonProperty(PropertyName = "brokerReportIdentification")]
        public string BrokerReportIdentification { get; set; }

        /// <summary>
        /// Gets or sets the original aplication.
        /// </summary>
        /// <value>Gets or sets the original aplication.</value>
        
        [JsonProperty(PropertyName = "originalAplication")]
        public string OriginalAplication { get; set; }

        /// <summary>
        /// Gets or sets the premium category.
        /// </summary>
        /// <value>Gets or sets the premium category.</value>
        
        [JsonProperty(PropertyName = "premiumCategory")]
        public string PremiumCategory { get; set; }

        /// <summary>
        /// Gets or sets the commission category.
        /// </summary>
        /// <value>Gets or sets the commission category.</value>
        
        [JsonProperty(PropertyName = "commissionCategory")]
        public string CommissionCategory { get; set; }

        /// <summary>
        /// Gets or sets the claim category.
        /// </summary>
        /// <value>Gets or sets the claim category.</value>
        
        [JsonProperty(PropertyName = "claimCategory")]
        public string ClaimCategory { get; set; }

        /// <summary>
        /// Gets or sets the cost category.
        /// </summary>
        /// <value>Gets or sets the cost category.</value>
        
        [JsonProperty(PropertyName = "costCategory")]
        public string CostCategory { get; set; }

        /// <summary>
        /// Gets or sets the type of the contract.
        /// </summary>
        /// <value>Gets or sets the type of the contract.</value>
        
        [JsonProperty(PropertyName = "contractType")]
        public string ContractType { get; set; }

        /// <summary>
        /// Gets or sets the situation.
        /// </summary>
        /// <value>Gets or sets the situation.</value>
        
        [JsonProperty(PropertyName = "situation")]
        public string Situation { get; set; }

        /// <summary>
        /// Gets or sets the situation date.
        /// </summary>
        /// <value>Gets or sets the situation date.</value>
        
        [JsonProperty(PropertyName = "situationDate")]
        public string SituationDate { get; set; }
    }
}

using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.Collections.Elements
{
    /// <summary>
    /// Maps with:
    /// - ZfscdCodigosErroLinhaCobDTO
    /// - ZfscdCodigosErroLinhaValDTO
    /// - ZfscdErrosReceiptsNumLineDTO
    /// </summary>
    
  public class ErrorElement {
    /// <summary>
    /// Gets or Sets ErroRCODE
    /// </summary>
    
    [JsonProperty(PropertyName = "Code")]
    public string ErroRCODE { get; set; }

    /// <summary>
    /// Gets or Sets ErroRCODETXT
    /// </summary>
    
    [JsonProperty(PropertyName = "Description")]
    public string ErroRCODETXT { get; set; }
}
}

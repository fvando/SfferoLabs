using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.Collections.Elements
{
    /// <summary>
    /// Maps with: ZfscdPcRecibosLinhaDTO
    /// </summary>
    
    public class ReceiptElement
    {
        /// <summary>
        /// Gets or Sets Broker
        /// </summary>
        
        [JsonProperty(PropertyName = "broker")]
        public string Broker { get; set; }

        /// <summary>
        /// Gets or Sets BrokerContract
        /// </summary>
        
        [JsonProperty(PropertyName = "brokerContract")]
        public string BrokerContract { get; set; }

        /// <summary>
        /// Gets or Sets CompanyCode
        /// </summary>
        
        [JsonProperty(PropertyName = "companyCode")]
        public string CompanyCode { get; set; }

        /// <summary>
        /// Gets or Sets DocumentType
        /// </summary>
        
        [JsonProperty(PropertyName = "documentType")]
        public string DocumentType { get; set; }

        /// <summary>
        /// Gets or Sets ReferenceDocumentNumber
        /// </summary>
        
        [JsonProperty(PropertyName = "referenceDocumentNumber")]
        public string ReferenceDocumentNumber { get; set; }

        /// <summary>
        /// Gets or Sets SapDocumentNumber
        /// </summary>
        
        [JsonProperty(PropertyName = "sapDocumentNumber")]
        public string SapDocumentNumber { get; set; }

        /// <summary>
        /// Gets or Sets DocumentNumber
        /// </summary>
        
        [JsonProperty(PropertyName = "documentNumber")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or Sets Partner
        /// </summary>
        
        [JsonProperty(PropertyName = "partner")]
        public string Partner { get; set; }

        /// <summary>
        /// Gets or Sets InsuranceObject
        /// </summary>
        
        [JsonProperty(PropertyName = "insuranceObject")]
        public string InsuranceObject { get; set; }

        /// <summary>
        /// Gets or Sets Amount
        /// </summary>
        
        [JsonProperty(PropertyName = "amount")]
        public double? Amount { get; set; }

        /// <summary>
        /// Gets or Sets Currency
        /// </summary>
        
        [JsonProperty(PropertyName = "currency")]
        public string Currency { get; set; }

    }
}

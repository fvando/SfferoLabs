using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.Collections.Elements
{
    /// <summary>
    /// Maps with: ZFscdPcCobrarWsDTO
    /// </summary>
    
    public class ChargeElement
    {
        /// <summary>
        /// Gets or Sets BrokerContract
        /// </summary>
        
        [JsonProperty(PropertyName = "brokerContract")]
        public string BrokerContract { get; set; }

        /// <summary>
        /// Gets or Sets PcReceipts
        /// </summary>
        
        [JsonProperty(PropertyName = "receipts")]
        public List<ReceiptElement> PcReceipts { get; set; }
    }
}

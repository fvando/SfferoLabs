﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.Collections.Elements
{
    /// <summary>
    /// Maps with DTO - ZfscdPcDetailLinhaDTO
    /// </summary>
    public class DetailReceiptLineElement
    {
        /// <summary>
        /// Gets or Sets BrokerReport
        /// </summary>
        [JsonProperty(PropertyName = "brokerReport")]
        public string BrokerReport { get; set; }
        /// <summary>
        /// Gets or Sets ReportItem
        /// </summary>
        [JsonProperty(PropertyName = "reportItem")]
        public string ReportItem { get; set; }
        /// <summary>
        /// Gets or Sets ReportItemCategory
        /// </summary>
        [JsonProperty(PropertyName = "reportItemCategory")]
        public string ReportItemCategory { get; set; }
        /// <summary>
        /// Gets or Sets ReportItemSubcategory
        /// </summary>
        [JsonProperty(PropertyName = "reportItemSubcategory")]
        public string ReportItemSubcategory { get; set; }
        /// <summary>
        /// Gets or Sets ReportSubitemNumber
        /// </summary>
        [JsonProperty(PropertyName = "reportSubitemNumber")]
        public string ReportSubitemNumber { get; set; }
        /// <summary>
        /// Gets or Sets Selections
        /// </summary>
        [JsonProperty(PropertyName = "selections")]
        public string Selections { get; set; }
        /// <summary>
        /// Gets or Sets MultipleGroupsSelected
        /// </summary>
        [JsonProperty(PropertyName = "multipleGroupsSelected")]
        public string MultipleGroupsSelected { get; set; }
        /// <summary>
        /// Gets or Sets CoinsShareFlag
        /// </summary>
        [JsonProperty(PropertyName = "coinsShareFlag")]
        public string CoinsShareFlag { get; set; }
        /// <summary>
        /// Gets or Sets PostingStatus
        /// </summary>
        [JsonProperty(PropertyName = "postingStatus")]
        public string PostingStatus { get; set; }
        /// <summary>
        /// Gets or Sets ConfirmationStatus
        /// </summary>
        [JsonProperty(PropertyName = "confirmationStatus")]
        public string ConfirmationStatus { get; set; }
        /// <summary>
        /// Gets or Sets Broker
        /// </summary>
        [JsonProperty(PropertyName = "broker")]
        public string Broker { get; set; }
        /// <summary>
        /// Gets or Sets BrokerContract
        /// </summary>
        [JsonProperty(PropertyName = "brokerContract")]
        public string BrokerContract { get; set; }
        /// <summary>
        /// Gets or Sets DocumentType
        /// </summary>
        [JsonProperty(PropertyName = "documentType")]
        public string DocumentType { get; set; }
        /// <summary>
        /// Gets or Sets DocumentNumber
        /// </summary>
        [JsonProperty(PropertyName = "documentNumber")]
        public string DocumentNumber { get; set; }
        /// <summary>
        /// Gets or Sets ReferenceDocumentNumber
        /// </summary>
        [JsonProperty(PropertyName = "referenceDocumentNumber")]
        public string ReferenceDocumentNumber { get; set; }
        /// <summary>
        /// Gets or Sets SapDocumentNumber
        /// </summary>
        [JsonProperty(PropertyName = "sapDocumentNumber")]
        public string SapDocumentNumber { get; set; }
        /// <summary>
        /// Gets or Sets Partner
        /// </summary>
        [JsonProperty(PropertyName = "partner")]
        public string Partner { get; set; }
        /// <summary>
        /// Gets or Sets InsuranceObject
        /// </summary>
        [JsonProperty(PropertyName = "insuranceObject")]
        public string InsuranceObject { get; set; }
        /// <summary>
        /// Gets or Sets InsuranceObjectCategory
        /// </summary>
        [JsonProperty(PropertyName = "insuranceObjectCategory")]
        public string InsuranceObjectCategory { get; set; }
        /// <summary>
        /// Gets or Sets ContractAccount
        /// </summary>
        [JsonProperty(PropertyName = "contractAccount")]
        public string ContractAccount { get; set; }
        /// <summary>
        /// Gets or Sets Amount
        /// </summary>
        [JsonProperty(PropertyName = "amount")]
        public decimal Amount { get; set; }
        /// <summary>
        /// Gets or Sets Currency
        /// </summary>
        [JsonProperty(PropertyName = "currency")]
        public string Currency { get; set; }
    }
}

﻿using INS.PT.WebAPI.Models.Collections.Elements;
using INS.PT.WebAPI.Models.DTO.Collections.Elements;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.Collections.WebReceiptListing
{

    /// <summary>
    /// Maps with DTO - zFscdRecibosListarWsResponseDTO
    /// </summary>
    
    public class ReceiptDetailWaspOutput
    {
        /// <summary>
        /// Gets or sets the errors.
        /// </summary>
        /// <value>Gets or sets the errors.</value>
        
        [JsonProperty(PropertyName = "errors")]
        public List<ErrorElement> Errors { get; set; }

        /// <summary>
        /// Gets or sets the receipts numbers.
        /// </summary>
        /// <value>Gets or sets the receipts numbers.</value>
        
        [JsonProperty(PropertyName = "receiptsNumbers")]
        public List<DetailReceiptElement> ReceiptsNumbers { get; set; }
    }
}

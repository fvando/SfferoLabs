﻿

// Copyright Ageas 2019 © - Integration Team

using static INS.PT.WebAPI.Constants.AgentsPortalEnums;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity
{
    /// <summary>
    /// 
    /// </summary>
    public class EntityContextInput
    {
        /// <summary>
        /// Gets or sets the level.
        /// </summary>
        /// <value>
        /// The level.
        /// </value>
        public ReferenceTypePerson Level { get; set; }
        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>
        /// The code.
        /// </value>
        public string Code { get; set; }
        /// <summary>
        /// Gets or sets the indicator.
        /// </summary>
        /// <value>
        /// The indicator.
        /// </value>
        public string Indicator { get; set; }
    }
}

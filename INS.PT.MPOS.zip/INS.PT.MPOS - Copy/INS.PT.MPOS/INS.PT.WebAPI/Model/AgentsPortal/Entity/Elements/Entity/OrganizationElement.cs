

// Copyright Ageas 2019 � - Integration Team

using System.Collections.Generic;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// Organization object.
    /// </summary>
    
    public class OrganizationElement
    {
        /// <summary>
        /// Total employees.
        /// </summary>
        /// <value>Total employees.</value>
        
        [JsonProperty(PropertyName = "totalEmployees")]
        public double? TotalEmployees { get; set; }

        /// <summary>
        /// Is Total employees Editable.
        /// </summary>
        /// <value>IsTotalEmployeesEditable.</value>
        
        [JsonProperty(PropertyName = "isTotalEmployeesEditable")]
        public bool IsTotalEmployeesEditable { get { return true; } }

        /// <summary>
        /// Wages amount.
        /// </summary>
        /// <value>Wages amount.</value>
        
        [JsonProperty(PropertyName = "wagesAmount")]
        public double? WagesAmount { get; set; }

        /// <summary>
        /// Is Wages Amount Editable.
        /// </summary>
        /// <value>IsWagesAmountEditable.</value>
        
        [JsonProperty(PropertyName = "isWagesAmountEditable")]
        public bool IsWagesAmountEditable { get { return true; } }

        /// <summary>
        /// List of contact for the entity.
        /// </summary>
        /// <value>List of contact for the entity.</value>
        
        [JsonProperty(PropertyName = "organizationContactPoints")]
        public List<OrganizationContactElement> OrganizationContactPoints { get; set; }
    }
}

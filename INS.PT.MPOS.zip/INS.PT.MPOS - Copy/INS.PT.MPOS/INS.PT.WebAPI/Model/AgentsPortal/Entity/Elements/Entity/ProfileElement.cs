

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class ProfileElement
    {
        /// <summary>
        /// Agent id.
        /// </summary>
        /// <value>Agent id.</value>
        
        [JsonProperty(PropertyName = "agentIdentifier")]
        public string AgentIdentifier { get; set; }
    }
}

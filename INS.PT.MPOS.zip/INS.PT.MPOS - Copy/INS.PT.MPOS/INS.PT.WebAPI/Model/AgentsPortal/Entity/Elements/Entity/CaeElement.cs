

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class CaeElement
    {
        /// <summary>
        /// CAE.
        /// </summary>
        /// <value>CAE.</value>
        
        [JsonProperty(PropertyName = "cae")]
        public string _Cae { get; set; }

        /// <summary>
        /// Is Cae Editable?
        /// </summary>
        /// <value>IsCaeEditable.</value>
        
        [JsonProperty(PropertyName = "isCaeEditable")]
        public bool IsCaeEditable { get; }

        /// <summary>
        /// Description.
        /// </summary>
        /// <value>Description.</value>
        
        [JsonProperty(PropertyName = "caeDescription")]
        public string CaeDescription { get; set; }

        /// <summary>
        /// Is Cae Description Editable?
        /// </summary>
        /// <value>IsCaeDescriptionEditable.</value>
        
        [JsonProperty(PropertyName = "isCaeDescriptionEditable")]
        public bool IsCaeDescriptionEditable { get; }
    }
}

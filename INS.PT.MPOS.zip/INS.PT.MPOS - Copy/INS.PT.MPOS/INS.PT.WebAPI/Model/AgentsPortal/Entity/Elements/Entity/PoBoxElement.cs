

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// PoBox object.
    /// </summary>
    
    public class PoBoxElement
    {
        /// <summary>
        /// Po box number.
        /// </summary>
        /// <value>Po box number.</value>
        
        [JsonProperty(PropertyName = "number")]
        public string Number { get; set; }

        /// <summary>
        /// Post office name.
        /// </summary>
        /// <value>Post office name.</value>
        
        [JsonProperty(PropertyName = "postOfficeName")]
        public string PostOfficeName { get; set; }
    }
}

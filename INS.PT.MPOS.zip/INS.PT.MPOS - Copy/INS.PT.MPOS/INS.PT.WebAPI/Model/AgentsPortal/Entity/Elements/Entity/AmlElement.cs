

// Copyright Ageas 2019 � - Integration Team

using System;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class AmlElement
    {
        /// <summary>
        /// Condition type.
        /// </summary>
        /// <value>Condition type.</value>
        
        [JsonProperty(PropertyName = "conditionType")]
        public string ConditionType { get; set; }

        /// <summary>
        /// Condition description.
        /// </summary>
        /// <value>Condition description.</value>
        
        [JsonProperty(PropertyName = "conditionDescription")]
        public string ConditionDescription { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        /// <value>Start date.</value>
        
        [JsonProperty(PropertyName = "startDate")]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        /// <value>End date.</value>
        
        [JsonProperty(PropertyName = "endDate")]
        public DateTime? EndDate { get; set; }
    }
}

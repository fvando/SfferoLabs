

// Copyright Ageas 2019 � - Integration Team

using System.Collections.Generic;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// Person object.
    /// </summary>
    
    public class PersonDetailElement
    {
        /// <summary>
        /// Gender.
        /// </summary>
        /// <value>Gender.</value>
        
        [JsonProperty(PropertyName = "gender")]
        public string Gender { get; set; }

        /// <summary>
        /// Is Gender Field Editable?
        /// </summary>
        /// <value>IsGenderEditable.</value>
        
        [JsonProperty(PropertyName = "isGenderEditable")]
        public bool IsGenderEditable { get; }

        /// <summary>
        /// Marital status.
        /// </summary>
        /// <value>Marital status.</value>
        
        [JsonProperty(PropertyName = "maritalStatus")]
        public string MaritalStatus { get; set; }

        /// <summary>
        /// Is Gender Marital Status Editable?
        /// </summary>
        /// <value>IsMaritalStatusEditable.</value>
        
        [JsonProperty(PropertyName = "isMaritalStatusEditable")]
        public bool IsMaritalStatusEditable { get { return true; } }

        /// <summary>
        /// Flag if person is self employed.
        /// </summary>
        /// <value>Flag if person is self employed.</value>
        
        [JsonProperty(PropertyName = "isSelfEmployee")]
        public bool? IsSelfEmployee { get; set; }

        /// <summary>
        /// Is Self Employee Editable?
        /// </summary>
        /// <value>IsSelfEmployeeEditable.</value>
        
        [JsonProperty(PropertyName = "isSelfEmployeeEditable")]
        public bool IsSelfEmployeeEditable { get; }

        /// <summary>
        /// List of nationalities.
        /// </summary>
        /// <value>List of nationalities.</value>
        
        [JsonProperty(PropertyName = "nationalities")]
        public List<NationalityElement> Nationalities { get; set; }

        /// <summary>
        /// List of driver licences.
        /// </summary>
        /// <value>List of driver licences.</value>
        [JsonProperty(PropertyName = "driverLicences")]
        public List<DriverLicenceElement> DriverLicences { get; set; }
    }
}

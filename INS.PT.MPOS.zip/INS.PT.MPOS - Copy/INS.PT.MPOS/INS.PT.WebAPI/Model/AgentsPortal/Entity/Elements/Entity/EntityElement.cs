

// Copyright Ageas 2019 � - Integration Team

using System.Collections.Generic;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// Entity object.
    /// </summary>
    
    public class EntityElement
    {
        /// <summary>
        /// Entity id.
        /// </summary>
        /// <value>Entity id.</value>
        
        [JsonProperty(PropertyName = "idEntity")]
        public string IdEntity { get; set; }

        /// <summary>
        /// Vat number.
        /// </summary>
        /// <value>Vat number.</value>
        
        [JsonProperty(PropertyName = "vatNumber")]
        public string VatNumber { get; set; }

        /// <summary>
        /// Gets or Sets Type
        /// </summary>
        
        [JsonProperty(PropertyName = "type")]
        public EntityTypeElement Type { get; set; }

        /// <summary>
        /// List of addresses.
        /// </summary>
        /// <value>List of addresses.</value>
        
        [JsonProperty(PropertyName = "addresses")]
        public List<EntityAddressElement> Addresses { get; set; }

        /// <summary>
        /// Lists of all contacts types.
        /// </summary>
        /// <value>Lists of all contacts types.</value>
        
        [JsonProperty(PropertyName = "contacts")]
        public ContactListsElement Contacts { get; set; }

        /// <summary>
        /// List of documents.
        /// </summary>
        /// <value>List of documents.</value>
        
        [JsonProperty(PropertyName = "documents")]
        public List<DocumentElement> Documents { get; set; }
    }
}

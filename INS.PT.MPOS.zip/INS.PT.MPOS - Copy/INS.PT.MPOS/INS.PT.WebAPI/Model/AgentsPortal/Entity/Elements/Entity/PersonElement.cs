

// Copyright Ageas 2019 � - Integration Team

using System;
using System.Collections.Generic;
using INS.PT.WebAPI.Utils;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// Person object.
    /// </summary>
    
    public class PersonElement
    {
        /// <summary>
        /// Name.
        /// </summary>
        /// <value>Name.</value>
        
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        /// <summary>
        /// Birthdate.
        /// </summary>
        /// <value>Birthdate.</value>
        
        [JsonProperty(PropertyName = "birthdate")]
        public DateTime? Birthdate { get; set; }

        /// <summary>
        /// Place of birth.
        /// </summary>
        /// <value>Place of birth.</value>
        
        [JsonProperty(PropertyName = "age")]
        public int? Age {
            get { return Birthdate.GetAge(); }
        }

        /// <summary>
        /// List of titles.
        /// </summary>
        /// <value>List of titles.</value>
        
        [JsonProperty(PropertyName = "honoraryTitles")]
        public List<HonoraryTitleElement> HonoraryTitles { get; set; }

        /// <summary>
        /// List of nationalities.
        /// </summary>
        /// <value>List of nationalities.</value>
        
        [JsonProperty(PropertyName = "nationalities")]
        public List<NationalityElement> Nationalities { get; set; }
    }
}



// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// BankAccount object.
    /// </summary>
    
    public class BankAccountElement
    {
        /// <summary>
        /// Sequence for bank account number.
        /// </summary>
        /// <value>Sequence for bank account number.</value>
        
        [JsonProperty(PropertyName = "sequenceBankAccountNumber")]
        public int? SequenceBankAccountNumber { get; set; }

        /// <summary>
        /// Bank account number.
        /// </summary>
        /// <value>Bank account number.</value>
        
        [JsonProperty(PropertyName = "bankAccountNumber")]
        public string BankAccountNumber { get; set; }

        /// <summary>
        /// Iban.
        /// </summary>
        /// <value>Iban.</value>
        
        [JsonProperty(PropertyName = "iban")]
        public string Iban { get; set; }
    }
}

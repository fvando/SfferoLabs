

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// Nationality object.
    /// </summary>
    
    public class NationalityElement
    {
        /// <summary>
        /// Description.
        /// </summary>
        /// <value>Description.</value>
        
        [JsonProperty(PropertyName = "nationalityDescription")]
        public string NationalityDescription { get; set; }

        /// <summary>
        /// Is Nationality Field Editable?
        /// </summary>
        /// <value>IsNationalityEditable.</value>
        
        [JsonProperty(PropertyName = "isNationalityEditable")]
        public bool IsNationalityEditable{ get; }

        /// <summary>
        /// Flag for the main nationality.
        /// </summary>
        /// <value>Flag for the main nationality.</value>

        [JsonProperty(PropertyName = "isPrincipal")]
        public bool? IsPrincipal { get; set; }
    }
}

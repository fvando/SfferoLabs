

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// Driver&#39;s licence object.
    /// </summary>
    
    public class DriverLicenceElement
    {
        /// <summary>
        /// Licence number.
        /// </summary>
        /// <value>Licence number.</value>
        
        [JsonProperty(PropertyName = "driverLicenceNumber")]
        public string DriverLicenceNumber { get; set; }

        /// <summary>
        /// Is Driver Licence Number Editable?
        /// </summary>
        /// <value>IsDriverLicenceNumberEditable.</value>
        
        [JsonProperty(PropertyName = "isDriverLicenceNumberEditable")]
        public bool IsDriverLicenceNumberEditable { get; }
    }
}

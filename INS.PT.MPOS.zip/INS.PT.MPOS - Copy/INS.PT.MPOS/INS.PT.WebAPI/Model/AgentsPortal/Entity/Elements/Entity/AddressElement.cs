

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class EntityAddressElement
    {
        /// <summary>
        /// Sequence.
        /// </summary>
        /// <value>Sequence.</value>
        
        [JsonProperty(PropertyName = "sequence")]
        public string Sequence { get; set; }

        /// <summary>
        /// Address type.
        /// </summary>
        /// <value>Address type.</value>
        
        [JsonProperty(PropertyName = "addressType")]
        public string AddressType { get; set; }

        /// <summary>
        /// Address type description.
        /// </summary>
        /// <value>Address type description.</value>
        
        [JsonProperty(PropertyName = "addressTypeDescription")]
        public string AddressTypeDescription { get; set; }

        /// <summary>
        /// Format type.
        /// </summary>
        /// <value>Format type.</value>
        
        [JsonProperty(PropertyName = "formatType")]
        public string FormatType { get; set; }

        /// <summary>
        /// Tipology.
        /// </summary>
        /// <value>Tipology.</value>
        
        [JsonProperty(PropertyName = "tipology")]
        public AddressTipologyElement Tipology { get; set; }

        /// <summary>
        /// Postal code.
        /// </summary>
        /// <value>Postal code.</value>
        
        [JsonProperty(PropertyName = "postalCode")]
        public string PostalCode { get; set; }

        /// <summary>
        /// Postal code description.
        /// </summary>
        /// <value>Postal code description.</value>
        
        [JsonProperty(PropertyName = "postalCodeDescription")]
        public string PostalCodeDescription { get; set; }

        /// <summary>
        /// Country code.
        /// </summary>
        /// <value>Country code.</value>
        
        [JsonProperty(PropertyName = "countryCode")]
        public string CountryCode { get; set; }

        /// <summary>
        /// Country description.
        /// </summary>
        /// <value>Country description.</value>
        
        [JsonProperty(PropertyName = "countryDescription")]
        public string CountryDescription { get; set; }
    }
}

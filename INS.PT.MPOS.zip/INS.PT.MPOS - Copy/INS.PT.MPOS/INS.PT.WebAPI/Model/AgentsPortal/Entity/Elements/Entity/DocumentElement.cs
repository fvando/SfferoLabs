

// Copyright Ageas 2019 � - Integration Team

using System;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class DocumentElement
    {
        /// <summary>
        /// Document type code.
        /// </summary>
        /// <value>Document type code.</value>
        
        [JsonProperty(PropertyName = "documentTypeCode")]
        public string DocumentTypeCode { get; set; }

        /// <summary>
        /// Document type description.
        /// </summary>
        /// <value>Document type description.</value>
        
        [JsonProperty(PropertyName = "documentTypeDescription")]
        public string DocumentTypeDescription { get; set; }

        /// <summary>
        /// Document number.
        /// </summary>
        /// <value>Document number.</value>
        
        [JsonProperty(PropertyName = "documentNumber")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Issue date.
        /// </summary>
        /// <value>Issue date.</value>
        
        [JsonProperty(PropertyName = "issueDate")]
        public DateTime? IssueDate { get; set; }

        /// <summary>
        /// Expiration date.
        /// </summary>
        /// <value>Expiration date.</value>
        
        [JsonProperty(PropertyName = "expirationDate")]
        public DateTime? ExpirationDate { get; set; }

        /// <summary>
        /// Document country code.
        /// </summary>
        /// <value>Document country code.</value>
        
        [JsonProperty(PropertyName = "documentCountryCode")]
        public string DocumentCountryCode { get; set; }

        /// <summary>
        /// Document country description.
        /// </summary>
        /// <value>Document country description.</value>
        
        [JsonProperty(PropertyName = "documentCountryDescription")]
        public string DocumentCountryDescription { get; set; }
    }
}

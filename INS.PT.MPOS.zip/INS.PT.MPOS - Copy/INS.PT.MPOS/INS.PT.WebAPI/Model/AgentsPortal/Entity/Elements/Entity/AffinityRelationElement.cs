

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class AffinityRelationElement
    {
        /// <summary>
        /// Relation id.
        /// </summary>
        /// <value>Relation id.</value>
        
        [JsonProperty(PropertyName = "relationIdentifier")]
        public int? RelationIdentifier { get; set; }

        /// <summary>
        /// Related entity id.
        /// </summary>
        /// <value>Related entity id.</value>
        
        [JsonProperty(PropertyName = "relatedEntityIdentifier")]
        public string RelatedEntityIdentifier { get; set; }

        /// <summary>
        /// Relation code.
        /// </summary>
        /// <value>Relation code.</value>
        
        [JsonProperty(PropertyName = "relationCode")]
        public string RelationCode { get; set; }

        /// <summary>
        /// Relation description.
        /// </summary>
        /// <value>Relation description.</value>
        
        [JsonProperty(PropertyName = "relationDescription")]
        public string RelationDescription { get; set; }
    }
}

﻿using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.ClientContext
{
    
    public class EntityContextElement
    {
        /// <summary>
        /// Name.
        /// </summary>
        /// <value>Name.</value>
        
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        /// <summary>
        /// Vat number.
        /// </summary>
        /// <value>Vat number.</value>
        
        [JsonProperty(PropertyName = "vatNumber")]
        public string VatNumber { get; set; }

        /// <summary>
        /// Policies Life Expiring Next 2 Months.
        /// </summary>
        /// <value>Number of Policies Life Expiring Next 2 Months.</value>
        
        [JsonProperty(PropertyName = "policiesLifeExpiringNextMonths")]
        public PoliciesLifeExpiringNextMonthsElement PoliciesLifeExpiringNextMonths { get; set; }

        /// <summary>
        /// Total Claims.
        /// </summary>
        /// <value>Number of Open Total Claims.</value>
        
        [JsonProperty(PropertyName = "claimsTotal")]
        public ClaimsTotalElement ClaimsTotal { get; set; }

        /// <summary>
        /// Unclosed Receipts.
        /// </summary>
        /// <value>Number of Unclosed Receipts.</value>
        
        [JsonProperty(PropertyName = "receiptsUnclosed")]
        public ReceiptsUnclosedElement ReceiptsUnclosed { get; set; }
    }
}

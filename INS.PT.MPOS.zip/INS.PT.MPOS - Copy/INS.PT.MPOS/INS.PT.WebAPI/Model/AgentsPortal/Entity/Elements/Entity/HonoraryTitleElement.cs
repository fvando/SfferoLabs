

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// Honorary title object.
    /// </summary>
    
    public class HonoraryTitleElement
    {
        /// <summary>
        /// Code.
        /// </summary>
        /// <value>Code.</value>
        
        [JsonProperty(PropertyName = "titleCode")]
        public string TitleCode { get; set; }
    }
}

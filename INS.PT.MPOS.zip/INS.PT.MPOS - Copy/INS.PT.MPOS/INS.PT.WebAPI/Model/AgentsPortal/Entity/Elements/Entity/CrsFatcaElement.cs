

// Copyright Ageas 2019 � - Integration Team

using System;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class CrsFatcaElement
    {
        /// <summary>
        /// Flag indicating if is a fatca.
        /// </summary>
        /// <value>Flag indicating if is a fatca.</value>
        
        [JsonProperty(PropertyName = "isFatca")]
        public bool? IsFatca { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        /// <value>Start date.</value>
        
        [JsonProperty(PropertyName = "startDate")]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        /// <value>End date.</value>
        
        [JsonProperty(PropertyName = "endDate")]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Crs status.
        /// </summary>
        /// <value>Crs status.</value>
        
        [JsonProperty(PropertyName = "crsStatus")]
        public string CrsStatus { get; set; }

        /// <summary>
        /// Reporter bank.
        /// </summary>
        /// <value>Reporter bank.</value>
        
        [JsonProperty(PropertyName = "reporterBank")]
        public string ReporterBank { get; set; }

        /// <summary>
        /// Reporter AGEAS.
        /// </summary>
        /// <value>Reporter AGEAS.</value>
        
        [JsonProperty(PropertyName = "reporterAGEAS")]
        public string ReporterAgeas { get; set; }

        /// <summary>
        /// Report year.
        /// </summary>
        /// <value>Report year.</value>
        
        [JsonProperty(PropertyName = "reportYear")]
        public string ReportYear { get; set; }

        /// <summary>
        /// Fiscal address.
        /// </summary>
        /// <value>Fiscal address.</value>
        
        [JsonProperty(PropertyName = "fiscalAddress")]
        public string FiscalAddress { get; set; }

        /// <summary>
        /// Fiscal country.
        /// </summary>
        /// <value>Fiscal country.</value>
        
        [JsonProperty(PropertyName = "fiscalCountry")]
        public string FiscalCountry { get; set; }

        /// <summary>
        /// Foreign vat.
        /// </summary>
        /// <value>Foreign vat.</value>
        
        [JsonProperty(PropertyName = "foreignVat")]
        public string ForeignVat { get; set; }

        /// <summary>
        /// Inexistence foreign vat motive.
        /// </summary>
        /// <value>Inexistence foreign vat motive.</value>
        
        [JsonProperty(PropertyName = "inexistenceForeignVatMotive")]
        public string InexistenceForeignVatMotive { get; set; }

        /// <summary>
        /// Data source.
        /// </summary>
        /// <value>Data source.</value>
        
        [JsonProperty(PropertyName = "dataSource")]
        public string DataSource { get; set; }

        /// <summary>
        /// Record timestamp.
        /// </summary>
        /// <value>Record timestamp.</value>
        
        [JsonProperty(PropertyName = "recordTimestamp")]
        public DateTime? RecordTimestamp { get; set; }
    }
}

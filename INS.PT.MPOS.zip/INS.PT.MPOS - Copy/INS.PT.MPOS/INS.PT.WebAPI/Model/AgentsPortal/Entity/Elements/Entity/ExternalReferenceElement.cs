

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class ExternalReferenceElement
    {
        /// <summary>
        /// External reference code.
        /// </summary>
        /// <value>External reference code.</value>
        
        [JsonProperty(PropertyName = "externalReferenceCode")]
        public string ExternalReferenceCode { get; set; }

        /// <summary>
        /// External reference description.
        /// </summary>
        /// <value>External reference description.</value>
        
        [JsonProperty(PropertyName = "externalReferenceDescription")]
        public string ExternalReferenceDescription { get; set; }
    }
}

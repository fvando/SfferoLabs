

// Copyright Ageas 2019 � - Integration Team

using System.Collections.Generic;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// Entity object.
    /// </summary>
    
    public class EntityDetailElement
    {
        /// <summary>
        /// Entity id.
        /// </summary>
        /// <value>Entity id.</value>
        
        [JsonProperty(PropertyName = "idEntity")]
        public string IdEntity { get; set; }

        /// <summary>
        /// Gets or Sets Type
        /// </summary>
        
        [JsonProperty(PropertyName = "type")]
        public EntityDetailTypeElement Type { get; set; }

        /// <summary>
        /// Lists of all contacts types.
        /// </summary>
        /// <value>Lists of all contacts types.</value>
        
        [JsonProperty(PropertyName = "contacts")]
        public ContactListsElement Contacts { get; set; }

        /// <summary>
        /// List od CAEs.
        /// </summary>
        /// <value>List od CAEs.</value>
        
        [JsonProperty(PropertyName = "caes")]
        public List<CaeElement> Caes { get; set; }

        /// <summary>
        /// List of External References.
        /// </summary>
        /// <value>List of External References.</value>
        
        [JsonProperty(PropertyName = "externalReferences")]
        public List<ExternalReferenceElement> ExternalReferences { get; set; }

        /// <summary>
        /// List of affinity relations.
        /// </summary>
        /// <value>List of affinity relations.</value>
        
        [JsonProperty(PropertyName = "affinityRelations")]
        public List<AffinityRelationElement> AffinityRelations { get; set; }
    }
}



// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class EntityTypeElement
    {
        /// <summary>
        /// Individual person.
        /// </summary>
        /// <value>Individual person.</value>
        
        [JsonProperty(PropertyName = "individual")]
        public PersonElement Individual { get; set; }

        /// <summary>
        /// Company.
        /// </summary>
        /// <value>Company.</value>
        
        [JsonProperty(PropertyName = "company")]
        public OrganizationElement Company { get; set; }
    }
}

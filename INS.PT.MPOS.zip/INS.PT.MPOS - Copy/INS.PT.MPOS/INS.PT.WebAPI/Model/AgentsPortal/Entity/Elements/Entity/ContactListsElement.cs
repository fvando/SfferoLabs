

// Copyright Ageas 2019 � - Integration Team

using System.Collections.Generic;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class ContactListsElement
    {
        /// <summary>
        /// List of phones.
        /// </summary>
        /// <value>List of phones.</value>
        
        [JsonProperty(PropertyName = "phones")]
        public List<PhoneElement> Phones { get; set; }

        /// <summary>
        /// List of emails.
        /// </summary>
        /// <value>List of emails.</value>
        
        [JsonProperty(PropertyName = "emails")]
        public List<EmailElement> Emails { get; set; }
    }
}

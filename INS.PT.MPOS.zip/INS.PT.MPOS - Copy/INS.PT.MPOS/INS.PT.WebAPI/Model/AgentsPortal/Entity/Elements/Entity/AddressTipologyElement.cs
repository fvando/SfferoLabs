

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity.Elements.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class AddressTipologyElement
    {
        /// <summary>
        /// Postal address.
        /// </summary>
        /// <value>Postal address.</value>
        
        [JsonProperty(PropertyName = "postalAddress")]
        public PoAddressElement PostalAddress { get; set; }
    }
}

﻿

// Copyright Ageas 2019 © - Integration Team

namespace INS.PT.WebAPI.Models.AgentsPortal.Entity
{
    /// <summary>
    /// 
    /// </summary>
    public class EntityInput
    {
        /// <summary>
        /// Gets or sets the identifier entity.
        /// </summary>
        /// <value>
        /// The identifier entity.
        /// </value>
        public string IdEntity { get; set; }
    }
}

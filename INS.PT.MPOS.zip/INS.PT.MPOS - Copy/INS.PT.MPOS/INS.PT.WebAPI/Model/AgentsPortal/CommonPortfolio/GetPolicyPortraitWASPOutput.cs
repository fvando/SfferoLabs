﻿using INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio
{    
    public class GetPolicyPortraitWASPOutput 
    {
        public string PolicyNumber { get; set; }

        public PolicyElement PolicyData { get; set; }

        public PaymentElement PaymentData { get; set; }

        public BasePortraitElement Portrait { get; set; }
    }
}

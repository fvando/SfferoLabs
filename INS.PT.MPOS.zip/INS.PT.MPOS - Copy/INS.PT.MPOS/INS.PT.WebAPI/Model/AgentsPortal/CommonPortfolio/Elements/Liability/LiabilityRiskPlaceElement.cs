﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Liability
{
    public class LiabilityRiskPlaceElement : AddressElement
    {
        public string countyCode{get; set;}

        public string countyDescription{get; set;}
    }
}

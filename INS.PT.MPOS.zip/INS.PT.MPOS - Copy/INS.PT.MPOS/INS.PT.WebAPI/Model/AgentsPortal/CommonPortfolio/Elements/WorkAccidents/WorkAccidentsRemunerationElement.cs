﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.WorkAccidents
{
    public class WorkAccidentsRemunerationElement
    {
        public System.Nullable<int> quantityYear{get; set;}

        //public bool quantityYearFieldSpecified;

        public string typeCode{get; set;}

        public string typeDescription{get; set;}

        public string units{get; set;}

        public System.Nullable<decimal> value{get; set;}

        //public bool valueFieldSpecified;
    }
}
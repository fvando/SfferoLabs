﻿using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.WorkAccidents
{
    public class WorkAccidentsRiskUnitElement
    {
        public string activity { get; set; }

        public List<WorkAccidentsAgriculturalElement> agricultural { get; set; }

        public string baseTax { get; set; }

        public string cAE { get; set; }

        public CogenUarElement cogenUarIdentification { get; set; }

        public List<WorkAccidentsCoverageElement> coverages { get; set; }

        public string finalTax { get; set; }

        public System.Nullable<int> insuredPeople { get; set; }


        public List<WorkAccidentsInsuredElement> insuredPerson { get; set; }

        public System.Nullable<System.DateTime> lastSalaryUpdateDate { get; set; }


        public string premiumModality { get; set; }

        public List<WorkAccidentsPropertyElement> property { get; set; }

        public List<AddressElement> riskPlace { get; set; }

        public System.Nullable<decimal> totalSalary { get; set; }

        public bool totalSalaryFieldSpecified { get; set; }

        public System.Nullable<bool> withNames { get; set; }

    }
}
﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.WorkAccidents
{
    public class WorkAccidentsAgriculturalElement
    {
        public string mechanizedWorkMen{get; set;}

        public string mechanizedWorkWomen{get; set;}

        public string nonMechanizedWorkMen{get; set;}

        public string nonMechanizedWorkWomen{get; set;}

        public string predictedAnnualSalary{get; set;}
    }
}
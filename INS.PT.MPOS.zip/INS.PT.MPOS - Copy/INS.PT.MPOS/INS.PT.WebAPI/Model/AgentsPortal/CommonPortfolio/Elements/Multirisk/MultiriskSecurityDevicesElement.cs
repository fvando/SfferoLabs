﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Multirisk
{
    public class MultiriskSecurityDevicesElement
    {
        public string burglaringRisk { get; set; }

        public System.Nullable<float> burglaringRiskPercentage { get; set; }

        //public bool burglaringRiskPercentageFieldSpecified;
    }
}
﻿using INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements
{
    public class InterestedElement : PersonElement
    {
        public string Description{get; set;}

        public string InterestLimit{get; set;}

        public string LoanNumber{get; set;}
    }
}
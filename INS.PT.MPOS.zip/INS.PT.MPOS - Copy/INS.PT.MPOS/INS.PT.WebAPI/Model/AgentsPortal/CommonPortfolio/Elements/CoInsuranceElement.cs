﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements
{
    public class CoInsuranceElement
    {
        public string MasterPolicyNumber{get; set;}

        public List<CoInsuranceParticipation> Participations{get; set;}
    }
}

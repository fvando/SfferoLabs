﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Multirisk
{
    public class BaseMultiriskInsuredObjectCoverageElement
    {
        public string code { get; set; }
        public string description { get; set; }
        public string excessCode { get; set; }
        public string excessDescription { get; set; }
        public string insuredCapital { get; set; }
        public System.Nullable<decimal> insuredCapitalValue { get; set; }

        //public bool insuredCapitalValueFieldSpecified;
    }
}
﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Multirisk
{
    public class MultiriskCapitalAutoUpdateElement
    {
        public string capitalAutoUpdate{get; set;}

        public string capitalAutoUpdatePercentage{get; set;}
    }
}
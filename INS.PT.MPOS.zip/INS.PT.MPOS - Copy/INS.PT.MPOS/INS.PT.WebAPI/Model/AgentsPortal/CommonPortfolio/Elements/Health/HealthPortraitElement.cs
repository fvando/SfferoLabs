﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Health
{
    public class HealthPortraitElement  : BasePortraitElement
    {
        public string cogenPolicyNumber{get; set;}

        public List<HealthOptionElement> options{get; set;}
    }
}

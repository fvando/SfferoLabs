﻿using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Liability
{
    public class LiabilityCoverageElement
    {
        private List<LiabilityClauseElement> clauses{get; set;}

        public string code{get; set;}

        public string description{get; set;}

        public string excessCode{get; set;}

        public string excessDescription{get; set;}

        public string insuredCapital{get; set;}

        public System.Nullable<decimal> insuredCapitalValue{get; set;}

        //public bool insuredCapitalValueFieldSpecified;

    }
}
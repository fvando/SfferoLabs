﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.PersonalAccidents
{
    public class PersonalAccidentsBeneficiariesElement : PersonElement
    {
        public string clauseText { get; set; }

        public string code { get; set; }

        public string description { get; set; }

        public System.Nullable<float> percentage { get; set; }

        //public bool percentageFieldSpecified;
    }
}
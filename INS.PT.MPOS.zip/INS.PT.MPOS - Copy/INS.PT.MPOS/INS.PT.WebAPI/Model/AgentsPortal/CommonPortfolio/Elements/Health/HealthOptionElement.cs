﻿using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Health
{
    public class HealthOptionElement
    {
        public List<HealthCoPaymentElement> coPayments { get; set; }

        public string code { get; set; }

        public PlanCounters counters { get; set; }

        public List<HealthCoverageElementBase> coverages { get; set; }

        public string description { get; set; }

        public string function { get; set; }

        public List<HealthInsuredElement> insuredPerson { get; set; }

        public string planCodeFacets { get; set; }
    }
}
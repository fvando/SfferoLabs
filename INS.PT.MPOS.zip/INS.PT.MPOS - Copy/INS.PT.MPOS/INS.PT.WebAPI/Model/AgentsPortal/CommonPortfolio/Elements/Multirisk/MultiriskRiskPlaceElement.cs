﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Multirisk
{
    public class MultiriskRiskPlaceElement
    {
        public AddressElement address{get; set;}

        public System.Nullable<decimal> insuredCapital{get; set;}

        //public bool insuredCapitalFieldSpecified;
    }
}
﻿using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Health
{
    public class HealthInsuredElement : PersonElement
    {
        public CogenUarElement cogenUarIdentification { get; set; }

        public List<HealthCoverageElementBase> coverages { get; set; }

        public System.Nullable<System.DateTime> deadlineDate { get; set; }

        //public bool deadlineDateFieldSpecified;

        public string employeeNumber { get; set; }

        public System.Nullable<System.DateTime> endDate { get; set; }

        //public bool endDateFieldSpecified;

        public System.Nullable<bool> graceExemptionPeriod { get; set; }

        //public bool graceExemptionPeriodFieldSpecified;

        public string iBAN { get; set; }

        public string medisCardNumber { get; set; }

        public string participantNumber { get; set; }

        public string participantType { get; set; }

        public System.Nullable<bool> primaryParticipant { get; set; }

        //public bool primaryParticipantFieldSpecified;

        public string relationshipCode { get; set; }

        public string relationshipDescription { get; set; }

        public System.Nullable<bool> secondaryParticipant { get; set; }

        //public bool secondaryParticipantFieldSpecified;

        public System.Nullable<System.DateTime> startDate { get; set; }

        //public bool startDateFieldSpecified;

        public string status { get; set; }
    }
}
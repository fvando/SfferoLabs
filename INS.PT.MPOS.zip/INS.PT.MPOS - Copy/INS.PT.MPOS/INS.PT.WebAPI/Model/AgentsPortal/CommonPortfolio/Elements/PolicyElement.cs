﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements
{
    public class PolicyElement
    {
        public AgentElement Agent { get; set; }
        //public CommonEnumsBackend Backend { get; set; }
        public string BranchCode { get; set; }
        public string BranchDescription { get; set; }
        public string Campaign { get; set; }
        public DateTime? CancelDate { get; set; }
        public string CancelReasonCode { get; set; }
        public string CancelReasonDescription { get; set; }
        public decimal? CommercialPremium { get; set; }
        public string CompanyCode { get; set; }
        public bool? DigitalSignature { get; set; }
        public float? DiscountsAggravations { get; set; }
        public DateTime? EndDate { get; set; }
        public string GeneralConditionsCode { get; set; }
        public HolderElement HolderPerson { get; set; }
        public string Instalment { get; set; }
        public decimal? InstalmentPremium { get; set; }
        public bool? IssuedByAgeas { get; set; }
        public string NetworkCode { get; set; }
        public string ProductCode { get; set; }
        public string ProductDescription { get; set; }
        public string Protocol { get; set; }
        public DateTime? RenewalDate { get; set; }
        public DateTime? StartDate { get; set; }
        public string Status { get; set; }
        public string StatusCode { get; set; }
        public DateTime? StatusDate { get; set; }
        public decimal? TotalPremium { get; set; }
        public string TransactionType { get; set; }
        public TicketingElement Ticketing { get; set; }
    }
}

﻿using INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Liability;
using INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.WorkAccidents;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements
{
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(WorkAccidentsPropertyElement))]
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(LiabilityRiskPlaceElement))]
    public class AddressElement
    {
        public string FullAddress { get; set; }

        public string Line1 { get; set; }

        public string Line2 { get; set; }

        public string Location { get; set; }

        public string ZipCode { get; set; }
    }
}
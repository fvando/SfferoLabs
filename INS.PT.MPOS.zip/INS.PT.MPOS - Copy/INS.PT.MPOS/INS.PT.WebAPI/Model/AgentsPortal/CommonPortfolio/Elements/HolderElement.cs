﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements
{
    public class HolderElement : PersonElement
    {
    }
}
﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Liability
{
    public class LiabilityAnimalElement
    {
        public System.Nullable<System.DateTime> birthDate { get; set; }
        //public bool birthDateFieldSpecified;
        public string breed { get; set; }
        public string chipNumber { get; set; }
        public System.Nullable<bool> dangerousBreedIndicator { get; set; }
        //public bool dangerousBreedIndicatorFieldSpecified;
        public string gender { get; set; }
        public string municipalCouncilLicense { get; set; }
        public string name { get; set; }
        public string nameOwner { get; set; }
        public System.Nullable<bool> ownerIndicator { get; set; }
        //public bool ownerIndicatorFieldSpecified;
        public System.Nullable<bool> ownerRelationshipIndicator { get; set; }
        //public bool ownerRelationshipIndicatorFieldSpecified;
        public System.Nullable<bool> progenitorDangerousBreedIndicator { get; set; }
        //public bool progenitorDangerousBreedIndicatorFieldSpecified;
        public string species { get; set; }
    }
}
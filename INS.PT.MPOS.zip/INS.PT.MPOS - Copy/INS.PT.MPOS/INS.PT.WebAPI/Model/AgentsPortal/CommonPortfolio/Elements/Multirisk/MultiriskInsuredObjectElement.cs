﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Multirisk
{
    public class MultiriskInsuredObjectElement
    {
        public MultiriskInsuredObjectAdditionalDataElement additionalData { get; set; }
        public System.Nullable<int> buildingYear { get; set; }
        //public bool buildingYearFieldSpecified;
        public MultiriskCapitalAutoUpdateElement capitalAutoUpdateData { get; set; }
        public CogenUarElement cogenUarIdentification { get; set; }
        public string companyActivityCode { get; set; }
        public string companyActivityDescription { get; set; }
        public string constructionType { get; set; }
        public List<MultiriskInsuredObjectCoverageElement> coverages { get; set; }
        public System.Nullable<int> disoccupationDaysNumber { get; set; }
        //public bool disoccupationDaysNumberFieldSpecified;
        public string floorType { get; set; }
        public string housingType { get; set; }
        public System.Nullable<decimal> insuredCapital { get; set; }
        //public bool insuredCapitalFieldSpecified;
        public string insuredObject { get; set; }
        public List<InterestedElement> interested { get; set; }
        public string interventionPerformedType { get; set; }
        public string isolatedPlace { get; set; }
        public System.Nullable<int> numberOfFractions { get; set; }
        //public bool numberOfFractionsFieldSpecified;
        public string package { get; set; }
        public string propertyNumber { get; set; }
        public string proximityGrove { get; set; }
        public string proximityWater { get; set; }
        public string qualityConstructionDescription { get; set; }
        public System.Nullable<int> rebuildingYear { get; set; }
        //public bool rebuildingYearFieldSpecified;
        public string riskClassification { get; set; }
        public MultiriskRiskPlaceElement riskPlace { get; set; }
        public List<MultiriskRiskPlaceElement> riskPlaces { get; set; }
        public string riskType { get; set; }
        public System.Nullable<int> roomsNumber { get; set; }
        //public bool roomsNumberFieldSpecified;
        public MultiriskSecurityDevicesElement securityDevices { get; set; }
        public System.Nullable<double> totalArea { get; set; }
        //public bool totalAreaFieldSpecified;
        public string typologyDivisions { get; set; }
        public string typologyGarage { get; set; }
        public System.Nullable<System.DateTime> unitRiskEndDate { get; set; }
        //public bool unitRiskEndDateFieldSpecified;
        public System.Nullable<System.DateTime> unitRiskStartDate { get; set; }
        //public bool unitRiskStartDateFieldSpecified;
        public string useDescription { get; set; }
    }
}

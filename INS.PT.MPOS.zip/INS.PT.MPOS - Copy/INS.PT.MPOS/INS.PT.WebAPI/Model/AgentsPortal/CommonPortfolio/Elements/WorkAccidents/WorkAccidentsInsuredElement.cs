﻿using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.WorkAccidents
{
    public class WorkAccidentsInsuredElement : PersonElement
    {
        public System.Nullable<int> age { get; set; }

        //public bool ageFieldSpecified;

        public string job { get; set; }

        public string jobCategory { get; set; }

        public List<WorkAccidentsRemunerationElement> remuneration { get; set; }

        public string status { get; set; }

        public System.Nullable<decimal> totalAnnualSalary { get; set; }

        //public bool totalAnnualSalaryFieldSpecified;
    }
}
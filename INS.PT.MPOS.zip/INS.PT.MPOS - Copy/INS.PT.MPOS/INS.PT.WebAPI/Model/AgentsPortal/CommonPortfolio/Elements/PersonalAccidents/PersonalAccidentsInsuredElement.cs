﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.PersonalAccidents
{
    public class PersonalAccidentsInsuredElement : PersonElement
    {
        public System.Nullable<System.DateTime> endDate{get; set;}

        //public bool endDateFieldSpecified;

        public string job{get; set;}

        public string participantNumber{get; set;}

        public string participantStatus{get; set;}

        public string primaryInsNumber{get; set;}

        public string secondaryInsNumber{get; set;}

        public System.Nullable<System.DateTime> startDate{get; set;}

        //public bool startDateFieldSpecified;
    }
}
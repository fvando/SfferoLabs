﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.PersonalAccidents
{
    public class PersonalAccidentsVehicleElement
    {
        public System.Nullable<int> capacity { get; set; }

        //public bool capacityFieldSpecified;

        public string make { get; set; }

        public string registration { get; set; }

        public string vehicleType { get; set; }
    }
}
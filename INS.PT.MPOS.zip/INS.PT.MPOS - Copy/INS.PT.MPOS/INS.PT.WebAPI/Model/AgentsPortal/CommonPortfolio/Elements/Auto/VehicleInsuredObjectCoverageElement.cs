﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements
{
    public class VehicleInsuredObjectCoverageElement
    {
        public string BonusMalus { get; set; }

        public decimal? BonusMalusPercentage { get; set; }

        public string Code { get; set; }

        public string Days { get; set; }

        public string Description { get; set; }

        public string ExcessCode { get; set; }

        public string ExcessDescription { get; set; }

        public string InsuredCapital { get; set; }

        public decimal? InsuredCapitalValue { get; set; }

        public string Scope { get; set; }
    }
}
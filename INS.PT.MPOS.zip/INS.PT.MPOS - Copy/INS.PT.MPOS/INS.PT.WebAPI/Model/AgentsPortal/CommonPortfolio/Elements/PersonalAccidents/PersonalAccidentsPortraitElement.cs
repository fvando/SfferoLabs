﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.PersonalAccidents
{
    public class PersonalAccidentsPortraitElement : BasePortraitElement
    {
        public CoInsuranceElement coInsurance{get; set;}

        public List<PersonalAccidentsRiskElement> riskUnits{get; set;}
    }
}


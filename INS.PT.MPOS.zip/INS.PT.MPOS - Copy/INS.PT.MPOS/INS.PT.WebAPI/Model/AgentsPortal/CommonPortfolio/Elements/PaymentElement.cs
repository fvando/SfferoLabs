﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements
{
    public class PaymentElement
    {
        public string BankDescription { get; set; }

        public string BicSwift { get; set; }

        public string DebitAuthorizationNumber { get; set; }

        public string EntityCreditor { get; set; }

        public string IBAN { get; set; }

        public string Method { get; set; }

        public string MethodCode { get; set; }

        public string NIB { get; set; }
    }
}

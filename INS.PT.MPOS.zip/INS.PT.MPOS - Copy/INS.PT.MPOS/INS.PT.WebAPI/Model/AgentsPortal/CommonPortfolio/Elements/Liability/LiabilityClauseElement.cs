﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Liability
{
    public class LiabilityClauseElement
    {
        public string description{get; set;}

        public string id{get; set;}
    }
}
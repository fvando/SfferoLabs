﻿using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.PersonalAccidents
{
    public class PersonalAccidentsTravelElement
    {
        public List<PersonalAccidentsCountryDestinationElement> countryDestination { get; set; }

        public System.Nullable<System.DateTime> endTripDate { get; set; }

        //public bool endTripDateFieldSpecified;

        public System.Nullable<System.DateTime> initialTripDate { get; set; }

        //public bool initialTripDateFieldSpecified;

        public System.Nullable<int> travelDays { get; set; }

        //public bool travelDaysFieldSpecified;

        public string travelDescription { get; set; }

        public List<PersonalAccidentsTravelTransportElement> travelTransport { get; set; }
    }
}
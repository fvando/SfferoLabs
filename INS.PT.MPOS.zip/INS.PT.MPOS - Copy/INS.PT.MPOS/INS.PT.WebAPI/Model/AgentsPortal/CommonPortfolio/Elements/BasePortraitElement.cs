﻿using INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Health;
using INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Liability;
using INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Multirisk;
using INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.PersonalAccidents;
using INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.WorkAccidents;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements
{
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(VehiclePortraitElement))]
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(MultiriskPortraitElement))]
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(LiabilityPortraitElement))]
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(WorkAccidentsPortraitElement))]
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(PersonalAccidentsPortraitElement))]
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(HealthPortraitElement))]
    //[System.Runtime.Serialization.KnownTypeAttribute(typeof(ProtectionPaymentsPortraitElement))]    
    public class BasePortraitElement
    {
    }
}
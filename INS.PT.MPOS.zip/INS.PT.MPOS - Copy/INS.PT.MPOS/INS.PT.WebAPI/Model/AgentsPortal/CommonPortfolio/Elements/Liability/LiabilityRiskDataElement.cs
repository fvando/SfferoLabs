﻿using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Liability
{
    public class LiabilityRiskDataElement
    {
        public string activityCode { get; set; }
        public string activityDescription { get; set; }
        public List<LiabilityAnimalElement> animalData { get; set; }
        public string calculationBaseCode { get; set; }
        public object calculationBaseDescription { get; set; }
        public System.Nullable<decimal> calculationBaseReferenceValue { get; set; }
        //public bool calculationBaseReferenceValueFieldSpecified;
        public System.Nullable<decimal> calculationBaseValue { get; set; }
        //public bool calculationBaseValueFieldSpecified;
        public List<LiabilityClauseElement> clauses { get; set; }
        public List<LiabilityCoverageElement> coverages { get; set; }
        public string genericDescription { get; set; }
        public string moduleCode { get; set; }
        public string moduleDescription { get; set; }
        public LiabilityRiskPlaceElement riskPlace { get; set; }
    }
}
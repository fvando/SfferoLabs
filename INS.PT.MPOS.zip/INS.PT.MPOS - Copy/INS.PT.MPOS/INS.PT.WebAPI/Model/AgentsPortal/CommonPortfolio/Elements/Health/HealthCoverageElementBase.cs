﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Health
{
    public class HealthCoverageElementBase
    {
        public string coPayment { get; set; }

        public string code { get; set; }

        public string description { get; set; }

        public string excessCode { get; set; }

        public string excessDescription { get; set; }

        public string inNetworkPercentage { get; set; }

        public string insuredCapital { get; set; }

        public System.Nullable<decimal> insuredCapitalValue { get; set; }

        //public bool insuredCapitalValueFieldSpecified;

        public string outNetworkPercentage { get; set; }
    }
}
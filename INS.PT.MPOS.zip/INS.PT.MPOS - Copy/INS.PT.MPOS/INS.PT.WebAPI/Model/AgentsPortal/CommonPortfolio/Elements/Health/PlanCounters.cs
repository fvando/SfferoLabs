﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Health
{
    public class PlanCounters
    {
        public int numberOfAdherents { get; set; }

        //public bool numberOfAdherentsFieldSpecified;

        public int numberOfDescendants { get; set; }

        //public bool numberOfDescendantsFieldSpecified;

        public int numberOfMainMembers { get; set; }

        //public bool numberOfMainMembersFieldSpecified;

        public int numberOfMembers { get; set; }

        //public bool numberOfMembersFieldSpecified;

        public int numberOfSpouses { get; set; }

        //public bool numberOfSpousesFieldSpecified;
    }
}
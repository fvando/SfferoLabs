﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.WorkAccidents
{
    public class WorkAccidentsPropertyElement : AddressElement
    {
        public string cultivationArea { get; set; }

        public string name { get; set; }
    }
}
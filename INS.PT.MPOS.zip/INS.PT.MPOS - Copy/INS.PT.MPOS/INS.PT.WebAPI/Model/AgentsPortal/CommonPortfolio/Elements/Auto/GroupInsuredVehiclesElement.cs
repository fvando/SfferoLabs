﻿using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements
{
    public class GroupInsuredVehiclesElement
    {
        public List<VehicleInsuredObjectCoverageElement> Coverages { get; set; }

        public List<InsuredVehicleElement> InsuredVehicles { get; set; }
    }
}
﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Multirisk
{
    public class MultiriskInsuredObjectAdditionalDataElement
    {
        public string aggravatedEmpty { get; set; }
        public System.Nullable<float> aggravatedEmptyPercentage { get; set; }
        //public bool aggravatedEmptyPercentageFieldSpecified;
        public string aggravatedRiskObject { get; set; }
        public System.Nullable<float> aggravatedRiskObjectPercentage { get; set; }
        //public bool aggravatedRiskObjectPercentageFieldSpecified;
        public string sismicExcess { get; set; }
        //public string sismicRiskCompensation { get; set; }
    }
}
﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.PersonalAccidents
{
    public class PersonalAccidentsCountryDestinationElement
    {

        public string code{get; set;}

        public string description{get; set;}

    }
}
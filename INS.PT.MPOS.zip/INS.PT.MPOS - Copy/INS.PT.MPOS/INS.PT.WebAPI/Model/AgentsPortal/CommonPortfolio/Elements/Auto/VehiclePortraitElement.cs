﻿using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements
{
    public class VehiclePortraitElement : BasePortraitElement
    {
        public List<GroupInsuredVehiclesElement> GroupVehicles { get; set; }
    }
}
﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Health
{
    public class HealthCoPaymentElement
    {
        public string coPaymentMember { get; set; }

        public int coverageId { get; set; }

        //public bool coverageIdFieldSpecified;

        public string excessMember { get; set; }

        public string subCoverageCode { get; set; }

        public string subCoverageDesc { get; set; }

        public int subCoverageId { get; set; }

        //public bool subCoverageIdFieldSpecified;
    }
}
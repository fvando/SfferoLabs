﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements
{
    public class CoInsuranceParticipation
    {
        public System.Nullable<float> billingCommissionPercentage { get; set; }
        //public bool billingCommissionPercentageFieldSpecified;
        public System.Nullable<float> commissionPercentage { get; set; }
        //public bool commissionPercentageFieldSpecified;
        public string congenerCode { get; set; }
        public System.Nullable<float> participationPercentage { get; set; }
        //public bool participationPercentageFieldSpecified;
        public System.Nullable<float> raisingCommissionPercentage { get; set; }
        //public bool raisingCommissionPercentageFieldSpecified;
    }
}
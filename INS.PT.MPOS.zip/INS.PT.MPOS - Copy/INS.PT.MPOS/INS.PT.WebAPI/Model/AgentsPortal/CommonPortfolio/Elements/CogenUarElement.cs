﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements
{
    public class CogenUarElement
    {
        public string UarCode{get; set;}

        public string UarNumber{get; set;}

        public string UarObjectNumber{get; set;}

        public string UarSequence{get; set;}
    }
}
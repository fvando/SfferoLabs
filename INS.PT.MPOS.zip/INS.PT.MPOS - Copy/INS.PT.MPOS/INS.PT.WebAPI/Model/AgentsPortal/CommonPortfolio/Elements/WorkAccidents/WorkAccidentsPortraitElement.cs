﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.WorkAccidents
{
    public class WorkAccidentsPortraitElement : BasePortraitElement
    {
        public List<WorkAccidentsRiskUnitElement> riskUnits{get; set;}
    }
}

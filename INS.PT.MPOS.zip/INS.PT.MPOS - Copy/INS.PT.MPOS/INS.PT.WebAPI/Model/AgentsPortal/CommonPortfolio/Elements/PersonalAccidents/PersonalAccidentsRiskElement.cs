﻿using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.PersonalAccidents
{
    public class PersonalAccidentsRiskElement
    {
        public bool beneficiariesLegalHeirs { get; set; }

        //public bool beneficiariesLegalHeirsFieldSpecified;

        public CogenUarElement cogenUarIdentification { get; set; }

        public List<PersonalAccidentsInsuredPersonsCoverageElement> coverages { get; set; }

        public PersonalAccidentsInsuredElement insuredPerson { get; set; }

        public PersonalAccidentsVehicleElement insuredVehicle { get; set; }

        public List<PersonalAccidentsBeneficiariesElement> otherBeneficiaries { get; set; }

        public string pack { get; set; }

        public string policyCapital { get; set; }

        public string pricingClass { get; set; }

        public string riskClass { get; set; }

        public string scope { get; set; }

        public PersonalAccidentsTravelElement travelInformation { get; set; }
    }
}
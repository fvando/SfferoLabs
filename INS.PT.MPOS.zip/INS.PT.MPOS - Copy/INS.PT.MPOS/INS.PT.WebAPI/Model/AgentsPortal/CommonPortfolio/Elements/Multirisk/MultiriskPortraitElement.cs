﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Multirisk
{
    public class MultiriskPortraitElement : BasePortraitElement
    {
        public CoInsuranceElement coInsurance { get; set; }

        public List<MultiriskInsuredObjectElement> insuredObjects { get; set; }

        public string Pack { get; set; }

        public decimal? totalInsuredCapital { get; set; }

        public bool totalInsuredCapitalFieldSpecified { get; set; }
    }
}

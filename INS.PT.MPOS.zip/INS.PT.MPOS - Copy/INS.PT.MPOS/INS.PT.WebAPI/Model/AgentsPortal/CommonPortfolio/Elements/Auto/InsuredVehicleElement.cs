﻿using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements
{
    public class InsuredVehicleElement
    {
        public System.Nullable<decimal> ActualValue { get; set; }
        public string BonusMalus { get; set; }
        public System.Nullable<float> BonusMalusPercentage { get; set; }
        public System.Nullable<int> Capacity { get; set; }
        public string Category { get; set; }
        public string ChassisNumber { get; set; }

        public CogenUarElement CogenUarIdentification { get; set; }
        public List<VehicleInsuredObjectCoverageElement> Coverages { get; set; }
        public System.Nullable<int> CylinderCapacity { get; set; }
        public System.Nullable<System.DateTime> DateExcluded { get; set; }
        public System.Nullable<System.DateTime> DateIncluded { get; set; }
        public System.Nullable<int> DoorsNumber { get; set; }
        public DriverElement DriverPerson { get; set; }
        public System.Collections.Generic.List<VehicleInsuredObjectExtrasElement> Extras { get; set; }
        public System.Nullable<decimal> ExtrasValue { get; set; }
        public string Fuel { get; set; }
        public string GearBox { get; set; }
        public System.Nullable<int> GrossWeight { get; set; }
        public string Group { get; set; }
        public System.Nullable<int> HorsePower { get; set; }
        public string InsuranceType { get; set; }
        public System.Collections.Generic.List<InterestedElement> Interesteds { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public string Pack { get; set; }
        public string PackCode { get; set; }
        public string Registration { get; set; }
        public System.Nullable<System.DateTime> RegistrationDate { get; set; }
        public System.Nullable<bool> RiskMaterials { get; set; }
        public string SegurNet { get; set; }
        public System.Nullable<bool> SideCar { get; set; }
        public string Tariff { get; set; }
        public string TerritorialExtension { get; set; }
        public string TylaCode { get; set; }
        public string VehicleStatus { get; set; }
        public string VehicleType { get; set; }
        public string VehicleUse { get; set; }
        public string Version { get; set; }
    }
}
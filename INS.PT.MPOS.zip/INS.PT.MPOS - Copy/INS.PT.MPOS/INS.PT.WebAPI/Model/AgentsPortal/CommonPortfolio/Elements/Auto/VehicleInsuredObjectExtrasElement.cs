﻿namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements
{
    public class VehicleInsuredObjectExtrasElement
    {
        private string Code{get; set;}

        private string Description{get; set;}

        private System.Nullable<decimal> Value{get; set;}
    }
}
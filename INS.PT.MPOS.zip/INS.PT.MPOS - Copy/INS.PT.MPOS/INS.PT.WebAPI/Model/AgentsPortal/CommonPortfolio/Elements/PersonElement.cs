﻿using INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Health;
using INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.PersonalAccidents;
using INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.WorkAccidents;
using System;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements
{
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(HolderElement))]
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(InterestedElement))]
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(DriverElement))]
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(WorkAccidentsInsuredElement))]
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(PersonalAccidentsInsuredElement))]
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(PersonalAccidentsBeneficiariesElement))]
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(HealthInsuredElement))]    
    [System.Runtime.Serialization.KnownTypeAttribute(typeof(AgentElement))]
    public class PersonElement
    {
        public AddressElement Address { get; set; }

        public DateTime ? BirthDateField { get; set; }

        public string ClientReference { get; set; }

        public string FiscalNumber { get; set; }

        public string Gender { get; set; }

        public string Name { get; set; }
    }
}
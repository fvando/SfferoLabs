﻿using System.Collections.Generic;

namespace INS.PT.WebAPI.Models.AgentsPortal.CommonPortfolio.Elements.Multirisk
{
    public class MultiriskInsuredObjectCoverageElement
    {
        public List<BaseMultiriskInsuredObjectCoverageElement> Warranties { get; set; }
    }
}
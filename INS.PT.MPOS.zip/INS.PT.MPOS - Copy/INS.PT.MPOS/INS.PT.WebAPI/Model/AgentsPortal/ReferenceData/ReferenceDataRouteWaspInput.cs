﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Constants.AgentsPortalEnums;

namespace INS.PT.WebAPI.Models.ReferenceData
{
    public class ReferenceDataRouteWaspInput
    {
        public DomainsData IdDomain { get; set; }

        public string IdElement { get; set; }
    }
}

﻿using INS.PT.WebAPI.Models.Base;
using INS.PT.WebAPI.Models.Common;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Constants.AgentsPortalEnums;

namespace INS.PT.WebAPI.Models.AgentsPortal.HighAvailability
{
    /// <summary>
    /// SearchRequestWaspInput
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Models.Base.WaspBasePaginatedInput" />
    
    public class SearchRequestWaspInput : WaspBasePaginatedInput
    {
        /// <summary>
        /// NIF
        /// </summary>
        /// <value>NIF</value>
        
        [JsonProperty(PropertyName = "nif")]
        public string Nif { get; set; }
        /// <summary>
        /// Request Number
        /// </summary>
        /// <value>Request Number</value>
        
        [JsonProperty(PropertyName = "requestNumber")]
        public string RequestNumber { get; set; }
        /// <summary>
        /// Creation Date
        /// </summary>
        /// <value>Creation Date</value>
        
        [JsonProperty(PropertyName = "creationDate")]
        public DateTime? CreationDate { get; set; }
        /// <summary>
        /// Policy Number
        /// </summary>
        /// <value>Policy Number</value>
        
        [JsonProperty(PropertyName = "policyNumber")]
        public string PolicyNumber { get; set; }
        /// <summary>
        /// Claim Number
        /// </summary>
        /// <value>Claim Number</value>
        
        [JsonProperty(PropertyName = "claimNumber")]
        public string ClaimNumber { get; set; }
        /// <summary>
        /// Receipt Number
        /// </summary>
        /// <value>Receipt Number</value>
        
        [JsonProperty(PropertyName = "receiptNumber")]
        public string ReceiptNumber { get; set; }
        /// <summary>
        /// Agent
        /// </summary>
        /// <value>Agent</value>
        
        [JsonProperty(PropertyName = "agent")]
        public string Agent { get; set; }
        /// <summary>
        /// Code Level
        /// </summary>
        /// <value>Code Level</value>
        
        [JsonProperty(PropertyName = "codeLevel")]
        public string CodeLevel { get; set; }
        /// <summary>
        /// Level
        /// </summary>
        /// <value>Level</value>
        
        [JsonProperty(PropertyName = "level")]
        public ReferenceDataIndicatorsLevel Level { get; set; }
        /// <summary>
        /// Order
        /// </summary>
        /// <value>Order</value>
        
        [JsonProperty(PropertyName = "order")]
        public Order<RequestsData> Order { get; set; }
    }
}

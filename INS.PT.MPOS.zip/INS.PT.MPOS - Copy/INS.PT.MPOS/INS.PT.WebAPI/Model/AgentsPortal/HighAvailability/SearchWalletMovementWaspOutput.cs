﻿using INS.PT.WebAPI.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.HighAvailability
{
    /// <summary>
    /// SearchWalletMovementWaspOutput
    /// </summary>
    /// <seealso cref="WaspBasePaginatedOutput" />
    
    public class SearchWalletMovementWaspOutput : WaspBasePaginatedOutput
    {
        
        public List<HWalletMovementElement> Data { get; set; }
    }
}

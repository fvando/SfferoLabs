using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using INS.PT.WebAPI.Models.Base;
using INS.PT.WebAPI.Models.Common;
using static INS.PT.WebAPI.Constants.AgentsPortalEnums;

namespace INS.PT.WebAPI.Models.AgentsPortal.HighAvailability
{
    /// <summary>
    /// SearchWalletMovementWaspInput
    /// </summary>
    
    public class SearchWalletMovementWaspInput : WaspBasePaginatedInput
    {
        /// <summary>
        /// Code Movement
        /// </summary>
        /// <value>Code Movement</value>
        
        [JsonProperty(PropertyName = "codeMovement")]
        public string CodeMovement { get; set; }

        /// <summary>
        /// Company
        /// </summary>
        /// <value>Company</value>
        
        [JsonProperty(PropertyName = "company")]
        public string Company { get; set; }

        /// <summary>
        /// Event Identify
        /// </summary>
        /// <value>Event Identify</value>
        
        [JsonProperty(PropertyName = "eventIdentify")]
        public string EventIdentify { get; set; }

        /// <summary>
        /// Date Movement Initial
        /// </summary>
        /// <value>Date Movement Initial</value>
        
        [JsonProperty(PropertyName = "movementStartDate")]
        public DateTime? MovementDateIni { get; set; }

        /// <summary>
        /// Date Movement End
        /// </summary>
        /// <value>Date Movement End</value>
        
        [JsonProperty(PropertyName = "movementEndDate")]
        public DateTime? MovementDateEnd { get; set; }

        /// <summary>
        /// Nif
        /// </summary>
        /// <value>Nif</value>
        
        [JsonProperty(PropertyName = "nif")]
        public string Nif { get; set; }

        /// <summary>
        /// SituationId
        /// </summary>
        /// <value>SituationId</value>
        
        [JsonProperty(PropertyName = "situationId")]
        public string SituationId { get; set; }

        /// <summary>
        /// codeLevel
        /// </summary>
        /// <value>codeLevel</value>
        
        [JsonProperty(PropertyName = "codeLevel")]
        public string CodeLevel { get; set; }

        /// <summary>
        /// Level
        /// </summary>
        /// <value>Level</value>
        
        [JsonProperty(PropertyName = "level")]
        public ReferenceDataIndicatorsLevel Level { get; set; }

        /// <summary>
        /// Order
        /// </summary>
        /// <value>Order</value>
        
        [JsonProperty(PropertyName = "order")]
        public Order<WalletMovementsData> Order { get; set; }
    }
}

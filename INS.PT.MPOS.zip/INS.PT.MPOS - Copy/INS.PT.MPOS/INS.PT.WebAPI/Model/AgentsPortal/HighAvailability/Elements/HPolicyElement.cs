using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.HighAvailability
{
    /// <summary>
    /// 
    /// </summary>
    
    public class HPolicyElement
    {
        /// <summary>
        /// Policy Number
        /// </summary>
        /// <value>Policy Number</value>
        
        [JsonProperty(PropertyName = "policyNumber")]
        public string PolicyNumber { get; set; }

        /// <summary>
        /// Company
        /// </summary>
        /// <value>Company</value>
        
        [JsonProperty(PropertyName = "company")]
        public string Company { get; set; }

        /// <summary>
        /// Source
        /// </summary>
        /// <value>Source</value>
        
        [JsonProperty(PropertyName = "source")]
        public string Source { get; set; }

        /// <summary>
        /// Nif
        /// </summary>
        /// <value>Nif</value>
        
        [JsonProperty(PropertyName = "nif")]
        public string Nif { get; set; }

        /// <summary>
        /// Situation Id
        /// </summary>
        /// <value>Situation Id</value>
        
        [JsonProperty(PropertyName = "situationId")]
        public string SituationId { get; set; }

        /// <summary>
        /// Gets or Sets SituationDescription
        /// </summary>
        
        [JsonProperty(PropertyName = "situationDescription")]
        public string SituationDescription { get; set; }

        /// <summary>
        /// Date of Situaction
        /// </summary>
        /// <value>Date of Situaction</value>
        
        [JsonProperty(PropertyName = "situationDate")]
        public DateTime? SituationDate { get; set; }

        /// <summary>
        /// Date of Emission
        /// </summary>
        /// <value>Date of Emission</value>
        
        [JsonProperty(PropertyName = "emissionDate")]
        public DateTime? EmissionDate { get; set; }

        /// <summary>
        /// Date of Maturity
        /// </summary>
        /// <value>Date of Maturity</value>
        
        [JsonProperty(PropertyName = "maturityDate")]
        public DateTime? MaturityDate { get; set; }

        /// <summary>
        /// Payment Date
        /// </summary>
        /// <value>Payment Date</value>
        
        [JsonProperty(PropertyName = "paymentDate")]
        public DateTime? PaymentDate { get; set; }

        /// <summary>
        /// Date Start
        /// </summary>
        /// <value>Date Start</value>
        
        [JsonProperty(PropertyName = "startDate")]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// Gets or Sets MethodsPaymentId
        /// </summary>
        
        [JsonProperty(PropertyName = "methodsPaymentId")]
        public string MethodsPaymentId { get; set; }

        /// <summary>
        /// Methods of Payment Description
        /// </summary>
        /// <value>Methods of Payment Description</value>
        
        [JsonProperty(PropertyName = "methodsPaymentDescription")]
        public string MethodsPaymentDescription { get; set; }

        /// <summary>
        /// Lob Id
        /// </summary>
        /// <value>Lob Id</value>
        
        [JsonProperty(PropertyName = "lobId")]
        public string LobId { get; set; }

        /// <summary>
        /// Lob Description
        /// </summary>
        /// <value>Lob Description</value>
        
        [JsonProperty(PropertyName = "lobDescription")]
        public string LobDescription { get; set; }

        /// <summary>
        /// Product Id
        /// </summary>
        /// <value>Product Id</value>
        
        [JsonProperty(PropertyName = "productId")]
        public string ProductId { get; set; }

        /// <summary>
        /// Product Description
        /// </summary>
        /// <value>Product Description</value>
        
        [JsonProperty(PropertyName = "productDescription")]
        public string ProductDescription { get; set; }

        /// <summary>
        /// Commercial Premium
        /// </summary>
        /// <value>Commercial Premium</value>
        
        [JsonProperty(PropertyName = "commercialPremium")]
        public double CommercialPremium { get; set; }

        /// <summary>
        /// Premium Issued
        /// </summary>
        /// <value>Premium Issued</value>
        
        [JsonProperty(PropertyName = "premiumIssued")]
        public double PremiumIssued { get; set; }

        /// <summary>
        /// Premium Charged
        /// </summary>
        /// <value>Premium Charged</value>
        
        [JsonProperty(PropertyName = "premiumCharged")]
        public double PremiumCharged { get; set; }

        /// <summary>
        /// Fractionation Id
        /// </summary>
        /// <value>Fractionation Id</value>
        
        [JsonProperty(PropertyName = "fractionationId")]
        public string FractionationId { get; set; }

        /// <summary>
        /// Fractionation Description
        /// </summary>
        /// <value>Fractionation Description</value>
        
        [JsonProperty(PropertyName = "fractionationDescription")]
        public string FractionationDescription { get; set; }

        /// <summary>
        /// Duration Id
        /// </summary>
        /// <value>Duration Id</value>
        
        [JsonProperty(PropertyName = "durationId")]
        public string DurationId { get; set; }

        /// <summary>
        /// Duration Description
        /// </summary>
        /// <value>Duration Description</value>
        
        [JsonProperty(PropertyName = "durationDescription")]
        public string DurationDescription { get; set; }

        /// <summary>
        /// Identification of Agent
        /// </summary>
        /// <value>Identification of Agent</value>
        
        [JsonProperty(PropertyName = "agentId")]
        public string AgentId { get; set; }

        /// <summary>
        /// Issue By Ageas
        /// </summary>
        /// <value>Issue By Ageas</value>
        
        [JsonProperty(PropertyName = "issueByCentralizedOffice")]
        public bool IssueByCentralizedOffice { get; set; }

        /// <summary>
        /// Digital Signature Pending
        /// </summary>
        /// <value>Digital Signature Pending</value>
        
        [JsonProperty(PropertyName = "digitalSignaturePending")]
        public bool DigitalSignaturePending { get; set; }
    }
}

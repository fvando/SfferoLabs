using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.HighAvailability
{
    /// <summary>
    /// 
    /// </summary>
    
    public class HWalletMovementElement
    {
        /// <summary>
        /// Code Movement
        /// </summary>
        /// <value>Code Movement</value>
        
        [JsonProperty(PropertyName = "codeMovement")]
        public string CodeMovement { get; set; }

        /// <summary>
        /// Company
        /// </summary>
        /// <value>Company</value>
        
        [JsonProperty(PropertyName = "company")]
        public string Company { get; set; }

        /// <summary>
        /// Nif
        /// </summary>
        /// <value>Nif</value>
        
        [JsonProperty(PropertyName = "nif")]
        public string Nif { get; set; }

        /// <summary>
        /// Policy Number
        /// </summary>
        /// <value>Policy Number</value>
        
        [JsonProperty(PropertyName = "policyNumber")]
        public string PolicyNumber { get; set; }

        /// <summary>
        /// Type Id
        /// </summary>
        /// <value>Type Id</value>
        
        [JsonProperty(PropertyName = "typeId")]
        public string TypeId { get; set; }

        /// <summary>
        /// Type Description
        /// </summary>
        /// <value>Type Description</value>
        
        [JsonProperty(PropertyName = "typeDescription")]
        public string TypeDescription { get; set; }

        /// <summary>
        /// Event Identify
        /// </summary>
        /// <value>Event Identify</value>
        
        [JsonProperty(PropertyName = "eventIdentify")]
        public string EventIdentify { get; set; }

        /// <summary>
        /// Gets or Sets MovementDate
        /// </summary>
        
        [JsonProperty(PropertyName = "movementDate")]
        public DateTime? MovementDate { get; set; }

        /// <summary>
        /// Agent ID
        /// </summary>
        /// <value>Agent ID</value>
        
        [JsonProperty(PropertyName = "agentId")]
        public string AgentId { get; set; }

        /// <summary>
        /// Situation Id
        /// </summary>
        /// <value>Situation Id</value>
        
        [JsonProperty(PropertyName = "situationId")]
        public string SituationId { get; set; }

        /// <summary>
        /// Situation Description
        /// </summary>
        /// <value>Situation Description</value>
        
        [JsonProperty(PropertyName = "situationDescription")]
        public string SituationDescription { get; set; }

    }
}

using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.AgentsPortal.HighAvailability
{
    /// <summary>
    /// 
    /// </summary>
    
    public class HRequestElement
    {
        /// <summary>
        /// Internal Number
        /// </summary>
        /// <value>Internal Number</value>
        
        [JsonProperty(PropertyName = "internalNumber")]
        public string InternalNumber { get; set; }

        /// <summary>
        /// External Number
        /// </summary>
        /// <value>External Number</value>
        
        [JsonProperty(PropertyName = "externalNumber")]
        public string ExternalNumber { get; set; }

        /// <summary>
        /// Area
        /// </summary>
        /// <value>Area</value>
        
        [JsonProperty(PropertyName = "area")]
        public string Area { get; set; }

        /// <summary>
        /// SubArea
        /// </summary>
        /// <value>SubArea</value>
        
        [JsonProperty(PropertyName = "subArea")]
        public string SubArea { get; set; }

        /// <summary>
        /// Task
        /// </summary>
        /// <value>Task</value>
        
        [JsonProperty(PropertyName = "task")]
        public string Task { get; set; }

        /// <summary>
        /// SubTask
        /// </summary>
        /// <value>SubTask</value>
        
        [JsonProperty(PropertyName = "subTask")]
        public string SubTask { get; set; }

        /// <summary>
        /// Operation
        /// </summary>
        /// <value>Operation</value>
        
        [JsonProperty(PropertyName = "operation")]
        public string Operation { get; set; }

        /// <summary>
        /// Type
        /// </summary>
        /// <value>Type</value>
        
        [JsonProperty(PropertyName = "type")]
        public string Type { get; set; }

        /// <summary>
        /// Nif
        /// </summary>
        /// <value>Nif</value>
        
        [JsonProperty(PropertyName = "nif")]
        public string Nif { get; set; }

        /// <summary>
        /// Entity Name
        /// </summary>
        /// <value>Entity Name</value>
        
        [JsonProperty(PropertyName = "entityName")]
        public string EntityName { get; set; }

        /// <summary>
        /// Policy Number
        /// </summary>
        /// <value>Policy Number</value>
        
        [JsonProperty(PropertyName = "policyNumber")]
        public string PolicyNumber { get; set; }

        /// <summary>
        /// Claim Number
        /// </summary>
        /// <value>Claim Number</value>
        
        [JsonProperty(PropertyName = "claimNumber")]
        public string ClaimNumber { get; set; }

        /// <summary>
        /// Status Id
        /// </summary>
        /// <value>Status Id</value>
        
        [JsonProperty(PropertyName = "statusId")]
        public string StatusId { get; set; }

        /// <summary>
        /// Status Description
        /// </summary>
        /// <value>Status Description</value>
        
        [JsonProperty(PropertyName = "statusDescription")]
        public string StatusDescription { get; set; }

        /// <summary>
        /// Gets or Sets AgentId
        /// </summary>
        
        [JsonProperty(PropertyName = "agentId")]
        public string AgentId { get; set; }

        /// <summary>
        /// Creation User
        /// </summary>
        /// <value>Creation User</value>
        
        [JsonProperty(PropertyName = "creationUser")]
        public string CreationUser { get; set; }

        /// <summary>
        /// Creation Date
        /// </summary>
        /// <value>Creation Date</value>
        
        [JsonProperty(PropertyName = "creationDate")]
        public DateTime? CreationDate { get; set; }

        /// <summary>
        /// Close Date
        /// </summary>
        /// <value>Close Date</value>
        
        [JsonProperty(PropertyName = "closeDate")]
        public DateTime? CloseDate { get; set; }
    }
}

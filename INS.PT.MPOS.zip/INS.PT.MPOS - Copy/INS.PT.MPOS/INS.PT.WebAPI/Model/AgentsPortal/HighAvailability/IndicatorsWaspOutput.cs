using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using INS.PT.WebAPI.Models.Base;

namespace INS.PT.WebAPI.Models.AgentsPortal.HighAvailability
{
    /// <summary>
    /// 
    /// </summary>
    
    public class IndicatorsWaspOutput : WaspBaseOutput
    {
        /// <summary>
        /// Id
        /// </summary>
        /// <value>Id</value>
        [JsonProperty(PropertyName = "id")]
        public int? Id { get; set; }

        /// <summary>
        /// Label
        /// </summary>
        /// <value>Label</value>        
        [JsonProperty(PropertyName = "label")]
        public string Label { get; set; }

        /// <summary>
        /// Value
        /// </summary>
        /// <value>Value</value>
       [JsonProperty(PropertyName = "value")]
        public int? Value { get; set; }

        /// <summary>
        /// Amount
        /// </summary>
        /// <value>Amount</value>
        [JsonProperty(PropertyName = "amount")]
        public double? Amount { get; set; }

        /// <summary>
        /// Description
        /// </summary>
        /// <value>Description</value>
        [JsonProperty(PropertyName = "description")]
        public string Description { get; set; }

        /// <summary>
        /// Range
        /// </summary>
        /// <value>Range</value>
        [JsonProperty(PropertyName = "range")]
        public string Range { get; set; }

        /// <summary>
        /// Optional
        /// </summary>
        /// <value>Optional</value>
        [JsonProperty(PropertyName = "optional")]
        public bool? Optional { get; set; }
    }
}

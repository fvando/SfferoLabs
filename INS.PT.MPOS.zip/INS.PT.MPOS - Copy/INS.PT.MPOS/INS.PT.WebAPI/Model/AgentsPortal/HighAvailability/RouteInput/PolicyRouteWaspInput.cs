﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.HighAvailability
{
    public class PolicyRouteWaspInput
    {
        public string PolicyNumber { get; set; }
    }
}

using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using INS.PT.WebAPI.Models.Base;
using INS.PT.WebAPI.Models.Common;

namespace INS.PT.WebAPI.Models.AgentsPortal.HighAvailability
{
    /// <summary>
    /// 
    /// </summary>
    
    public class SearchReceiptWaspOutput : WaspBasePaginatedOutput
    {
        
        public List<HReceiptElement> Data { get; set; }
    }
}

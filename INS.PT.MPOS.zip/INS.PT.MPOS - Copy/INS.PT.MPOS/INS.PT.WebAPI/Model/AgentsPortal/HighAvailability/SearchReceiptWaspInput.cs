using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using INS.PT.WebAPI.Models.Base;
using INS.PT.WebAPI.Models.Common;
using static INS.PT.WebAPI.Constants.AgentsPortalEnums;
using INS.PT.WebAPI.Utils;

namespace INS.PT.WebAPI.Models.AgentsPortal.HighAvailability
{
    /// <summary>
    /// 
    /// </summary>
    
    public class SearchReceiptWaspInput : WaspBasePaginatedInput
    {
        /// <summary>
        /// NIF
        /// </summary>
        /// <value>NIF</value>
        
        [JsonProperty(PropertyName = "nif")]
        public string Nif { get; set; }

        /// <summary>
        /// Company
        /// </summary>
        /// <value>Company</value>
        
        [JsonProperty(PropertyName = "company")]
        public string Company { get; set; }

        /// <summary>
        /// Type Nature ID
        /// </summary>
        /// <value>Type Nature ID</value>
        
        [JsonProperty(PropertyName = "typeNatureId")]
        public string TypeNatureId { get; set; }

        /// <summary>
        /// Emission Date Ini
        /// </summary>
        /// <value>Emission Date Ini</value>
        
        [JsonProperty(PropertyName = "emissionStartDate")]
        public DateTime? EmissionDateIni { get; set; }

        /// <summary>
        /// Emission Date End
        /// </summary>
        /// <value>Emission Date End</value>
        
        [JsonProperty(PropertyName = "emissionEndDate")]
        public DateTime? EmissionDateEnd { get; set; }

        /// <summary>
        /// Date Start Ini
        /// </summary>
        /// <value>Date Start Ini</value>
        
        [JsonProperty(PropertyName = "initialStartDate")]
        public DateTime? StartDateIni { get; set; }

        /// <summary>
        /// Date Start End
        /// </summary>
        /// <value>Date Start End</value>
        
        [JsonProperty(PropertyName = "endStartDate")]
        public DateTime? StartDateEnd { get; set; }

        /// <summary>
        /// PaymentDueDate Ini
        /// </summary>
        /// <value>PaymentDueDate Ini</value>
        
        [JsonProperty(PropertyName = "paymentDueStartDate")]
        public DateTime? PaymentDueDateIni { get; set; }

        /// <summary>
        /// PaymentDueDate End
        /// </summary>
        /// <value>PaymentDueDate End</value>
        
        [JsonProperty(PropertyName = "paymentDueEndDate")]
        public DateTime? PaymentDueDateEnd { get; set; }

        /// <summary>
        /// Situation Id
        /// </summary>
        /// <value>Situation Id</value>
        
        [JsonProperty(PropertyName = "situationId")]
        public string SituationId { get; set; }

        /// <summary>
        /// Date Situation Ini
        /// </summary>
        /// <value>Date Situation Ini</value>
        
        [JsonProperty(PropertyName = "situationStartDate")]
        public DateTime? SituationDateIni { get; set; }

        /// <summary>
        /// Date Situation End
        /// </summary>
        /// <value>Date Situation End</value>
        
        [JsonProperty(PropertyName = "situationEndDate")]
        public DateTime? SituationDateEnd { get; set; }

        /// <summary>
        /// MethodsPayment ID
        /// </summary>
        /// <value>MethodsPayment ID</value>
        
        [JsonProperty(PropertyName = "methodsPaymentId")]
        public string MethodsPaymentId { get; set; }

        /// <summary>
        /// AgentMediator id
        /// </summary>
        /// <value>AgentMediator id</value>
        
        [JsonProperty(PropertyName = "agentMediator")]
        public string AgentMediator { get; set; }

        /// <summary>
        /// Collector Agent
        /// </summary>
        /// <value>Collector Agent</value>
        
        [JsonProperty(PropertyName = "agentCollectorId")]
        public string AgentCollectorId { get; set; }

        /// <summary>
        /// codeLevel
        /// </summary>
        /// <value>codeLevel</value>
        
        [JsonProperty(PropertyName = "codeLevel")]
        public string CodeLevel { get; set; }

        /// <summary>
        /// Level
        /// </summary>
        /// <value>Level</value>
        
        [JsonProperty(PropertyName = "level")]
        public ReferenceDataIndicatorsLevel Level { get; set; }

        /// <summary>
        /// Policy number
        /// </summary>
        /// <value>Policy number</value>
        
        [JsonProperty(PropertyName = "policyNumber")]
        public string PolicyNumber { get; set; }

        /// <summary>
        /// Generic Search
        /// </summary>
        /// <value>Generic Search</value>
        
        [JsonProperty(PropertyName = "genericSearch")]
        public string GenericSearch { get; set; }

        /// <summary>
        /// Id Product
        /// </summary>
        /// <value>Id Product</value>
        
        [JsonProperty(PropertyName = "order")]
        public Order<ReceiptsData> Order { get; set; }
    }
}

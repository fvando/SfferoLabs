﻿using INS.PT.WebAPI.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.AgentsPortal.HighAvailability
{
    /// <summary>
    /// SearchRequestWaspOutput
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Models.Common.WaspBasePaginatedOutput" />
    
    public class SearchRequestWaspOutput : WaspBasePaginatedOutput
    {
        
        public List<HRequestElement> Data { get; set; }
    }
}

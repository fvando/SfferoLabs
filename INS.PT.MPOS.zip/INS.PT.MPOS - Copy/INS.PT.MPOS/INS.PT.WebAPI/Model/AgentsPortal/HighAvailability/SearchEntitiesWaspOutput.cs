using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using INS.PT.WebAPI.Models.Base;
using INS.PT.WebAPI.Models.Common;

namespace INS.PT.WebAPI.Models.AgentsPortal.HighAvailability
{
    /// <summary>
    /// 
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.Models.Common.WaspBasePaginatedOutput" />
    
    public class SearchEntitiesWaspOutput : WaspBasePaginatedOutput
    {
        
        public List<HEntitiesElement> Data { get; set; }
    }
}

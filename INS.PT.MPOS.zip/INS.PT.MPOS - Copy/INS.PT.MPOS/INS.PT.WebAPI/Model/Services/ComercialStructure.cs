﻿using System;
using System.Collections.Generic;

namespace INS.PT.AgentsPortal.RefreshData.Models.EF
{
    public partial class ComercialStructure
    {
        public string ComercialStructureId { get; set; }
        public string Company { get; set; }
        public string NetworkCode { get; set; }
        public string NetworkName { get; set; }
        public string ZoneCode { get; set; }
        public string ZoneName { get; set; }
        public string BranchCode { get; set; }
        public string BranchName { get; set; }
        public string InspectorCode { get; set; }
        public string InspectorEntityId { get; set; }
        public string AgentCode { get; set; }
        public string AgentEntityId { get; set; }
        public string Asfnumber { get; set; }
        public DateTime AuditCreationDate { get; set; }
        public DateTime? AuditUpdatedDate { get; set; }
    }
}

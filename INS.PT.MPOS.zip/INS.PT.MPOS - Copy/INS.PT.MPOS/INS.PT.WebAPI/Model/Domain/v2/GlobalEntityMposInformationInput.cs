﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Model.Domain.v2
{
    /// <summary>
    /// GlobalEntityMposInformationInput
    /// </summary>
    public class GlobalEntityMposInformationInput
    {
        /// <summary>
        /// Gets or sets the entities ids.
        /// </summary>
        /// <value>
        /// The entities ids.
        /// </value>
        [JsonProperty(PropertyName = "entitiesIds")]
        public List<string> EntitiesIds  { get; set; }

    }
}

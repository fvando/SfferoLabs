﻿// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Model.Domain.v2
{
    /// <summary>
    /// GlobalEntityMposInformationOutputDTO
    /// </summary>
    public class GlobalEntityMposInformationOutputDto
    {

        /// <summary>
        /// Gets or sets the identifier entity.
        /// </summary>
        /// <value>
        /// The identifier entity.
        /// </value>
        [JsonProperty(PropertyName = "idEntity")]
        public string IdEntity { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>
        /// The name.
        /// </value>
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the vat number.
        /// </summary>
        /// <value>
        /// The vat number.
        /// </value>
        [JsonProperty(PropertyName = "vatNumber")]
        public string VatNumber { get; set; }

        /// <summary>
        /// Gets or sets the address.
        /// </summary>
        /// <value>
        /// The address.
        /// </value>
        [JsonProperty(PropertyName = "address")]
        public string Address { get; set; }

        /// <summary>
        /// Gets or sets the postal code.
        /// </summary>
        /// <value>
        /// The postal code.
        /// </value>
        [JsonProperty(PropertyName = "postalCode")]
        public string PostalCode { get; set; }

        /// <summary>
        /// Gets or sets the georeference.
        /// </summary>
        /// <value>
        /// The georeference.
        /// </value>
        [JsonProperty(PropertyName = "georeference")]
        public string Georeference { get; set; }

        /// <summary>
        /// Gets or sets the phone number.
        /// </summary>
        /// <value>
        /// The phone number.
        /// </value>
        [JsonProperty(PropertyName = "phoneNumber")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets the email address.
        /// </summary>
        /// <value>
        /// The email address.
        /// </value>
        [JsonProperty(PropertyName = "emailAddress")]
        public string EmailAddress { get; set; }
    }
}

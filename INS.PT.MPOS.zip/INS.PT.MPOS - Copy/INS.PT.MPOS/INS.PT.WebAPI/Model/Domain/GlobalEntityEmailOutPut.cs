﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;
using System;

namespace INS.PT.WebAPI.Model.Domain
{
    /// <summary>
    /// GlobalEntityEmailOutPut
    /// </summary>
    public class GlobalEntityEmailOutPut
    {
        /// <summary>
        /// Gets or sets the email identifier.
        /// </summary>
        /// <value>
        /// The email identifier.
        /// </value>
        [JsonProperty(PropertyName = "emailIdentifier")]
        public string EmailIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the email type code.
        /// </summary>
        /// <value>
        /// The email type code.
        /// </value>
        [JsonProperty(PropertyName = "emailTypeCode")]
        public string EmailTypeCode { get; set; }

        /// <summary>
        /// Gets or sets the email type description.
        /// </summary>
        /// <value>
        /// The email type description.
        /// </value>
        [JsonProperty(PropertyName = "emailTypeDescription")]
        public string EmailTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets the email address.
        /// </summary>
        /// <value>
        /// The email address.
        /// </value>
        [JsonProperty(PropertyName = "emailAddress")]
        public string EmailAddress { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is preferred.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is preferred; otherwise, <c>false</c>.
        /// </value>
        [JsonProperty(PropertyName = "isPreferred")]
        public Boolean IsPreferred { get; set; }

}
}

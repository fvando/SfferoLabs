﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Model.Domain
{
    /// <summary>
    /// GlobalEntityMposInformationElemet
    /// </summary>
    public class GlobalEntityMposInformationElemet
    {
        /// <summary>
        /// Gets or sets the entity identifier.
        /// </summary>
        /// <value>
        /// The entity identifier.
        /// </value>
        [JsonProperty(PropertyName = "entityId")]
        public string EntityId { get; set; }

    }
}

﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;
using System;

namespace INS.PT.WebAPI.Model.Domain.DomainDTO
{
    /// <summary>
    /// GlobalEntityPhonesOutPutDTO
    /// </summary>
    public class GlobalEntityPhonesOutPutDto
    {
        /// <summary>
        /// Gets or sets the phone identifier.
        /// </summary>
        /// <value>
        /// The phone identifier.
        /// </value>
        [JsonProperty(PropertyName = "phoneIdentifier")]
        public string PhoneIdentifier { get; set; }

        /// <summary>
        /// Gets or sets the phone type code.
        /// </summary>
        /// <value>
        /// The phone type code.
        /// </value>
        [JsonProperty(PropertyName = "phoneTypeCode")]
        public string PhoneTypeCode { get; set; }

        /// <summary>
        /// Gets or sets the phone type description.
        /// </summary>
        /// <value>
        /// The phone type description.
        /// </value>
        [JsonProperty(PropertyName = "phoneTypeDescription")]
        public string PhoneTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets the phone number.
        /// </summary>
        /// <value>
        /// The phone number.
        /// </value>
        [JsonProperty(PropertyName = "phoneNumber")]
        public string phoneNumber { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is preferred.
        /// </summary>
        /// <value>
        ///   <c>true</c> if this instance is preferred; otherwise, <c>false</c>.
        /// </value>
        [JsonProperty(PropertyName = "isPreferred")]
        public Boolean IsPreferred { get; set; }
  }
}

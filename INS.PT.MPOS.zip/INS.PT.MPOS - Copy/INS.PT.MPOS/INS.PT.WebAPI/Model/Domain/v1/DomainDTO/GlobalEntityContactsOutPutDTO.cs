﻿

// Copyright Ageas 2019 © - Integration Team

using Newtonsoft.Json;
using System.Collections.Generic;

namespace INS.PT.WebAPI.Model.Domain.DomainDTO
{
    /// <summary>
    /// GlobalEntityContactsOutPutDTO
    /// </summary>
    public class GlobalEntityContactsOutPutDto
    {
        /// <summary>
        /// Gets or sets the emails.
        /// </summary>
        /// <value>
        /// The emails.
        /// </value>
        [JsonProperty(PropertyName = "emails")]
        public List<GlobalEntityEmailOutPut> Emails { get; set; }

        /// <summary>
        /// Gets or sets the phones.
        /// </summary>
        /// <value>
        /// The phones.
        /// </value>
        [JsonProperty(PropertyName = "phones")]
        public List<GlobalEntityPhonesOutPut> Phones { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model
{
    /// <summary>
    /// 
    /// </summary>
    public class GetTerminal
    {
        /// <summary>
        /// InputLogin
        /// </summary>
        public class InputGetTerminal
        {
            /// <summary>
            /// userID
            /// </summary>
            ///<example>123456</example>
            [Required]
            public string userID { get; set; } = "123456";
            
        }

        /// <summary>
        /// OutputLogin
        /// </summary>
        public class OutputGetTerminal
        {

            /// <summary>
            /// terminalId
            /// </summary>
            ///<example>33439</example>
            [Required]
            public string terminalId { get; set; } = "33439";

            /// <summary>
            /// merchantId
            /// </summary>
            ///<example>345735</example>
            [Required]
            public string merchantId { get; set; } = "345735";

            /// <summary>
            /// merchantAuthId
            /// </summary>
            ///<example>tert7H4TNTa6CpLkzfSCwEpaV1Nq9QkyZ/afYygEAco=</example>
            [Required]
            public string merchantAuthId { get; set; } = "tert7H4TNTa6CpLkzfSCwEpaV1Nq9QkyZ/afYygEAco=";

            /// <summary>
            /// merchantAuthKey
            /// </summary>
            ///<example>kg45fgtUHTcJkAEX+02Wq1wvCUe1qXDB5QnKbkguXjE=</example>
            [Required]
            public string merchantAuthKey { get; set; } = "kg45fgtUHTcJkAEX+02Wq1wvCUe1qXDB5QnKbkguXjE=";

            /// <summary>
            /// error
            /// </summary>
            [Required]
            public Error error { get; set; } = new Error();

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model
{
    /// <summary>
    /// 
    /// </summary>
    public class Login
    {
        /// <summary>
        /// InputLogin
        /// </summary>
        public class InputLogin
        {
            ///// <summary>
            ///// Nome de usuário
            ///// </summary>
            /////<example>joao.ferreira</example>
            //[Required]
            //public string username {get;set;}

            ///// <summary>
            ///// Nome de usuário
            ///// </summary>
            /////<example>#A1b2c3</example>
            //[Required]
            //public string password { get; set; }

        }

        /// <summary>
        /// OutputLogin
        /// </summary>
        public class OutputLogin
        {
            /// <summary>
            /// Nome de usuário
            /// </summary>
            ///<example>joao.ferreira</example>
            [Required]
            public AgentContextApp AgentContext { get; set; }


            /// <summary>
            /// error
            /// </summary>
            [Required]
            public Error Error { get; set; } 

        }

    }
}

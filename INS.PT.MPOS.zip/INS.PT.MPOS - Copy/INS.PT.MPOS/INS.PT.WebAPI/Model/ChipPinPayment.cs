﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model
{
    /// <summary>
    /// 
    /// </summary>
    public class ChipPinPayment
    {
        /// <summary>
        /// InputRefMBPayment
        /// </summary>
        public class InputChipPinPayment
        {

            /// <summary>
            /// paymentBrand
            /// </summary>
            ///<example>2</example>
            public string paymentBrand { get; set; }  

            /// <summary>
            /// internalCompany
            /// </summary>
            ///<example>1234</example>
            public string internalCompany { get; set; } 

            /// <summary>
            /// appOrigemId
            /// </summary>
            ///<example>APP1</example>
            public string appOrigemId { get; set; } 


            /// <summary>
            /// nif
            /// </summary>
            ///<example>123456789</example>
            public string nif { get; set; } 


            /// <summary>
            /// totalAmount
            /// </summary>
            ///<example>900.00</example>
            public double totalAmount { get; set; }  


            /// <summary>
            /// userId
            /// </summary>
            ///<example>joao.ferreira</example>
            public string userId { get; set; }  


            /// <summary>
            /// idTerminal
            /// </summary>
            ///<example>41887</example>
            public string idTerminal { get; set; } 

            /// <summary>
            /// bulkPrint
            /// </summary>
            ///<example>false</example>
            public Boolean bulkPrint { get; set; } 


            /// <summary>
            /// sendEmail
            /// </summary>
            ///<example>false</example>
            public bool sendEmail { get; set; } 

            /// <summary>
            /// localPrint
            /// </summary>
            ///<example>false</example>
            public bool localPrint { get; set; }  

            /// <summary>
            /// receipts
            /// </summary>
            public PaymentReceipt[] receipts { get; set; }


            /// <summary>
            /// exclusive
            /// </summary>
            ///<example>false</example>
            public bool exclusive { get; set; }  


        }

        /// <summary>
        /// OutputLogin
        /// </summary>
        public class OutputChipPinPayment
        {

            /// <summary>
            /// merchantTransactionId
            /// </summary>
            ///<example>1234</example>
            public string merchantTransactionId { get; set; } = "1234";


            /// <summary>
            /// status
            /// </summary>
            ///<example>OK</example>
            [Required]
            public string status { get; set; } = "OK";


            /// <summary>
            /// errorMessage
            /// </summary>
            ///<example>Não foi possível gerar o ‘merchantTransactionid’</example>
            [Required]
            public string errorMessage { get; set; } = "Não foi possível gerar o ‘merchantTransactionid’";

        }

    }
}

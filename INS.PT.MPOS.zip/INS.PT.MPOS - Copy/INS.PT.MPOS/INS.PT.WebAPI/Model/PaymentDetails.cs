﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model
{
    /// <summary>
    /// 
    /// </summary>
    public class PaymentDetails
    {
        /// <summary>
        /// InputPaymentDetails
        /// </summary>
        public class InputPaymentDetails
        {
            /// <summary>
            /// merchantTransactionId
            /// </summary>
            ///<example>1234</example>
            public string MerchantTransactionId { get; set; } 

     
        }

        /// <summary>
        /// OutputLogin
        /// </summary>
        public class OutputPaymentDetails
        {

            /// <summary>
            /// paymentBrand
            /// </summary>
            ///<example>2</example>
            [Required]
            public string PaymentBrand { get; set; }  

            /// <summary>
            /// internalCompany
            /// </summary>
            ///<example>1234</example>
            [Required]
            public string InternalCompany { get; set; } 

            /// <summary>
            /// appOrigemId
            /// </summary>
            ///<example>APP1</example>
            [Required]
            public string AppOrigemId { get; set; } 


            /// <summary>
            /// idPolicy
            /// </summary>
            ///<example>91983915437683432156</example>
            [Required]
            public string PolicyId { get; set; }  


            /// <summary>
            /// totalAmount
            /// </summary>
            ///<example>900.00</example>
            [Required]
            public Decimal TotalAmount { get; set; }  

            /// <summary>
            /// userId
            /// </summary>
            ///<example>joao.ferreira</example>
            [Required]
            public string UserId { get; set; }  


            /// <summary>
            /// idTerminal
            /// </summary>
            ///<example>41887</example>
            [Required]
            public string TerminalId { get; set; }  


            /// <summary>
            /// phoneNumber
            /// </summary>
            ///<example>963631513</example>
            [Required]
            public string PhoneNumber { get; set; }  


            /// <summary>
            /// pmtRef
            /// </summary>
            ///<example>076814518</example>
            [Required]
            public string PmtRef { get; set; } 


            /// <summary>
            /// ptmntEntty
            /// </summary>
            ///<example>25002</example>
            [Required]
            public string PtmntEntty { get; set; } 



            /// <summary>
            /// refIntlDtTm
            /// </summary>
            ///<example>2019-03-15T12:28:32.001+01:00</example>
            [Required]
            public string RefIntlDtTm { get; set; }  


            /// <summary>
            /// refLmtDtTm
            /// </summary>
            ///<example>2019-04-15T13:28:32.001+01:00</example>
            [Required]
            public string RefLmtDtTm { get; set; }  


            /// <summary>
            /// bulkPrint
            /// </summary>
            ///<example>false</example>
            [Required]
            public Boolean BulkPrint { get; set; } 


            /// <summary>
            /// sendEmail
            /// </summary>
            ///<example>false</example>
            [Required]
            public bool SendEmail { get; set; }  

            /// <summary>
            /// localPrint
            /// </summary>
            ///<example>false</example>
            [Required]
            public bool LocalPrint { get; set; }  


            /// <summary>
            /// statusControle
            /// </summary>
            ///<example>0</example>
            [Required]
            public string StatusControle { get; set; }  

            /// <summary>
            /// paymentStatus
            /// </summary>
            ///<example>0</example>
            [Required]
            public string PaymentStatus { get; set; }  

            /// <summary>
            /// processedStatus
            /// </summary>
            ///<example>O</example>
            [Required]
            public string ProcessedStatus { get; set; }


            /// <summary>
            /// timestamp
            /// </summary>
            ///<example>2019-04-12 11:06:17</example>
            [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = true)]
            [DataType(DataType.Date)]
            [Required]
            public DateTime? Timestamp { get; set; } 

        }

    }
}

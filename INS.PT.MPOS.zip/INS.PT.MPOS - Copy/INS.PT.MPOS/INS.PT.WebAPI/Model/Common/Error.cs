﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.Common
{
    public class Error
    {
        /// <summary>Error Code</summary>
        [JsonProperty("code", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string Code { get; set; }

        /// <summary>Error Descritpion</summary>
        [JsonProperty("descritpion", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string Descritpion { get; set; }
    }
}

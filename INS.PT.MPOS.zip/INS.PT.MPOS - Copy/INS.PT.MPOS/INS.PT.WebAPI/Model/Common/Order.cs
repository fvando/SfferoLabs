﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using static INS.PT.WebAPI.Constants.AgentsPortalEnums;

namespace INS.PT.WebAPI.Models.Common
{
    public class Order<T>
    {
        /// <summary>
        /// Sort Field
        /// </summary>
        /// <value>Sort Field</value>
        [JsonProperty(PropertyName = "sortField")]
        public T SortField { get; set; }

        /// <summary>
        /// Sort Order
        /// </summary>
        /// <value>Sort Order</value>
        [JsonProperty(PropertyName = "sortOrder")]
        public OrderData SortOrder { get; set; }
    }
}

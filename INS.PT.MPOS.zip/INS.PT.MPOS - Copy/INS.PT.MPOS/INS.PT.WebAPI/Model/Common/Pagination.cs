﻿using Microsoft.IdentityModel.Protocols;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.Common
{
    public class Pagination
    {
        /// <summary>
        /// Page size
        /// </summary>
        /// <value>Page size</value>        
        [JsonProperty(PropertyName = "pageSize")]
        public int? PageSize { get; set; } = 10;

        /// <summary>
        /// Page number
        /// </summary>
        /// <value>Page number</value>
        [JsonProperty(PropertyName = "pageNumber")]        
        public int? PageNumber { get; set; } = 1;

        /// <summary>
        /// Total of items
        /// </summary>
        /// <value>Total of items</value>
        [JsonProperty(PropertyName = "totalItemCount")]
        public int? TotalItemCount { get; set; }
    }
}

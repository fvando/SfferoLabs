﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Model
{
    /// <summary>
    /// 
    /// </summary>
    public class PolicyDetailReceipt
    {
        /// <summary>
        /// policy
        /// </summary>
        ///<example>000</example>
        [Required]
        public string PolicyId { get; set; } 

        /// <summary>
        /// branch
        /// </summary>
        ///<example></example>
       [JsonIgnore]
        public string Branch { get; set; } 

        /// <summary>
        /// amount
        /// </summary>
        ///<example></example>
        [Required]
        public Decimal Amount { get; set; } 

      
        /// <summary>
        /// receipts
        /// </summary>
        ///<example></example>
        public List<Receipt> Receipts { get; set; }


        /// <summary>
        /// insuredType
        /// </summary>
        ///<example></example>
        public string InsuredType { get; set; } 

        /// <summary>
        /// insuredObject
        /// </summary>
        ///<example></example>
        [Required]
        public string InsuredObject { get; set; }
        
        /// <summary>
        /// insuredObject
        /// </summary>
        ///<example></example>
        public decimal Total { get; set; }
    }
}

using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.ReferenceData
{

    /// <summary>
    /// 
    /// </summary>
    
    public class ReferenceDataOutputDTO
    {
        /// <summary>
        /// Total record count for all pages.
        /// </summary>
        /// <value>Total record count for all pages.</value>
        
        [JsonProperty(PropertyName = "totalResults")]
        public int? TotalResults { get; set; }

        /// <summary>
        /// List of values.
        /// </summary>
        /// <value>List of values.</value>
        
        [JsonProperty(PropertyName = "resultList")]
        public List<ReferenceDataDTO> ResultList { get; set; }

        /// <summary>
        /// Number of records in page if results are paged.
        /// </summary>
        /// <value>Number of records in page if results are paged.</value>
        
        [JsonProperty(PropertyName = "pageSize")]
        public int? PageSize { get; set; }

        /// <summary>
        /// Page number returned if results are paged.
        /// </summary>
        /// <value>Page number returned if results are paged.</value>
        
        [JsonProperty(PropertyName = "pageNumber")]
        public int? PageNumber { get; set; }
    }
}

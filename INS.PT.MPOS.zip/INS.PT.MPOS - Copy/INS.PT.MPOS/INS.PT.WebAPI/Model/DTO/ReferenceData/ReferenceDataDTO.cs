using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.ReferenceData
{

    /// <summary>
    /// 
    /// </summary>
    
    public class ReferenceDataDTO
    {
        /// <summary>
        /// Code.
        /// </summary>
        /// <value>Code.</value>
        
        [JsonProperty(PropertyName = "idElement")]
        public string IdElement { get; set; }

        /// <summary>
        /// Description of the code.
        /// </summary>
        /// <value>Description of the code.</value>
        
        [JsonProperty(PropertyName = "description")]
        public string Description { get; set; }

        /// <summary>
        /// Field to sort list results.
        /// </summary>
        /// <value>Field to sort list results.</value>
        
        [JsonProperty(PropertyName = "order")]
        public int? Order { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        /// <value>Start date.</value>
        
        [JsonProperty(PropertyName = "startDate")]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        /// <value>End date.</value>
        
        [JsonProperty(PropertyName = "endDate")]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Extra properties for generic data.
        /// </summary>
        /// <value>Extra properties for generic data.</value>
        
        [JsonProperty(PropertyName = "extraProperties")]
        public Object ExtraProperties { get; set; }
    }
}

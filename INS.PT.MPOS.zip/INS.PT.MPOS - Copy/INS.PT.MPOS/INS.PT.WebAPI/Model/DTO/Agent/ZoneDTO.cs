

// Copyright Ageas 2019 � - Integration Team

using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Agent
{

    /// <summary>
    /// ZoneCS
    /// </summary>
    
    public class ZoneDto
    {
        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>Gets or sets the code.</value>
        
        [JsonProperty(PropertyName = "code")]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>Gets or sets the name.</value>
        
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the address.
        /// </summary>
        /// <value>Gets or sets the address.</value>
        
        [JsonProperty(PropertyName = "address")]
        public string Address { get; set; }

        /// <summary>
        /// Gets or sets the postal code1.
        /// </summary>
        /// <value>Gets or sets the postal code1.</value>
        
        [JsonProperty(PropertyName = "postalCode")]
        public string PostalCode { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>Gets or sets the status.</value>
        
        [JsonProperty(PropertyName = "status")]
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the status initial date.
        /// </summary>
        /// <value>Gets or sets the status initial date.</value>
        
        [JsonProperty(PropertyName = "statusInitialDate")]
        public DateTime? StatusInitialDate { get; set; }

        /// <summary>
        /// Gets or sets the status end date.
        /// </summary>
        /// <value>Gets or sets the status end date.</value>
        
        [JsonProperty(PropertyName = "statusEndDate")]
        public DateTime? StatusEndDate { get; set; }

        /// <summary>
        /// Gets or sets the responsible identifier.
        /// </summary>
        /// <value>Gets or sets the responsible identifier.</value>
        
        [JsonProperty(PropertyName = "responsibleId")]
        public string ResponsibleId { get; set; }

        /// <summary>
        /// Gets or sets the branches.
        /// </summary>
        /// <value>Gets or sets the branches.</value>
        
        [JsonProperty(PropertyName = "branches")]
        public List<BranchDto> Branches { get; set; }
    }
}



// Copyright Ageas 2019 � - Integration Team

using System;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Agent
{

    /// <summary>
    /// AgentCS
    /// </summary>
    
    public class AgentDto
    {
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>Gets or sets the identifier.</value>
        
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets the code.
        /// </summary>
        /// <value>Gets or sets the code.</value>
        
        [JsonProperty(PropertyName = "code")]
        public string Code { get; set; }

        /// <summary>
        /// Gets or sets the status.
        /// </summary>
        /// <value>Gets or sets the status.</value>
        
        [JsonProperty(PropertyName = "status")]
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the status initial date.
        /// </summary>
        /// <value>Gets or sets the status initial date.</value>
        
        [JsonProperty(PropertyName = "statusInitialDate")]
        public DateTime? StatusInitialDate { get; set; }

        /// <summary>
        /// Gets or sets the status end date1.
        /// </summary>
        /// <value>Gets or sets the status end date1.</value>
        
        [JsonProperty(PropertyName = "statusEndDate")]
        public DateTime? StatusEndDate { get; set; }

        /// <summary>
        /// Gets or sets the work area.
        /// </summary>
        /// <value>Gets or sets the work area.</value>
        
        [JsonProperty(PropertyName = "workArea")]
        public string WorkArea { get; set; }

        /// <summary>
        /// Gets or sets the agent work area.
        /// </summary>
        /// <value>Gets or sets the agent work area.</value>
        
        [JsonProperty(PropertyName = "agentWorkArea")]
        public string AgentWorkArea { get; set; }

        /// <summary>
        /// Gets or sets the asf number.
        /// </summary>
        /// <value>Gets or sets the asf number.</value>
        
        [JsonProperty(PropertyName = "asfNumber")]
        public string AsfNumber { get; set; }

        /// <summary>
        /// Gets or sets the asf product code.
        /// </summary>
        /// <value>Gets or sets the asf product code.</value>
        
        [JsonProperty(PropertyName = "asfProductCode")]
        public string AsfProductCode { get; set; }

        /// <summary>
        /// Gets or sets the asf product code description.
        /// </summary>
        /// <value>Gets or sets the asf product code description.</value>
        
        [JsonProperty(PropertyName = "asfProductCodeDescription")]
        public string AsfProductCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets the identifier address.
        /// </summary>
        /// <value>Gets or sets the identifier address.</value>
        
        [JsonProperty(PropertyName = "idAddress")]
        public string IdAddress { get; set; }

        /// <summary>
        /// Agents name.
        /// </summary>
        /// <value>Agents name.</value>
        
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }
    }
}

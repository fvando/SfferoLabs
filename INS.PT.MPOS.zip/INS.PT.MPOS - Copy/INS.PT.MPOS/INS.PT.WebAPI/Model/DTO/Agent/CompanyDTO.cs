

// Copyright Ageas 2019 � - Integration Team

using System.Collections.Generic;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Agent
{

    /// <summary>
    /// CompanyCS
    /// </summary>
    
    public class CompanyDto
    {
        /// <summary>
        /// Gets or sets the company.
        /// </summary>
        /// <value>Gets or sets the company.</value>
        
        [JsonProperty(PropertyName = "company")]
        public string Company { get; set; }

        /// <summary>
        /// Gets or sets the networks.
        /// </summary>
        /// <value>Gets or sets the networks.</value>
        
        [JsonProperty(PropertyName = "networks")]
        public List<NetWorkDto> Networks { get; set; }
    }
}

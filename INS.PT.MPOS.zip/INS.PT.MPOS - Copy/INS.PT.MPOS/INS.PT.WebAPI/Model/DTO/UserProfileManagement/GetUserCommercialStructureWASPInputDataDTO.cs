﻿namespace INS.PT.WebAPI.Repository
{
    public class GetUserCommercialStructureWASPInputDataDTO
    {
        public bool ClearCache { get; set; }
        public string Email { get; set; }
        public string EntityCode { get; set; }
        public string LevelCode { get; set; }
        public int? ProfileId { get; set; }
        public bool ProfileIdSpecified { get; set; }
    }
}
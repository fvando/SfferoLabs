﻿namespace INS.PT.WebAPI.Repository.V1
{
    public class GetUserDetailWASPInputDTO
    {
        public bool ClearCache { get; set; }
        public string Email { get; set; }
        public string EntityCode { get; set; }
        public string LevelID { get; set; }
    }
}
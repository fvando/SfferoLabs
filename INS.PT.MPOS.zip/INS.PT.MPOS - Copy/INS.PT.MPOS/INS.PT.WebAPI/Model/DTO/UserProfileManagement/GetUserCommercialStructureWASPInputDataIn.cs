﻿using Newtonsoft.Json;

namespace INS.PT.WebAPI.Repository
{
    public class GetUserCommercialStructureWASPInputDataIn
    {
        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Include)]
        public bool ClearCache { get; set; }
        public string Email { get; set; }
        public string EntityCode { get; set; }
        public string LevelCode { get; set; }
        public int? ProfileId { get; set; }

        [JsonProperty(DefaultValueHandling = DefaultValueHandling.Include)]
        public bool ProfileIdSpecified { get; set; }
    }
}
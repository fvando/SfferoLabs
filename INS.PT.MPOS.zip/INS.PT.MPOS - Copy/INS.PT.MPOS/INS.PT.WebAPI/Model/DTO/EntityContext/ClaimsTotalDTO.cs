﻿using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.EntityContext
{
    
    public class ClaimsTotalDTO
    {
        /// <summary>
        /// Value.
        /// </summary>
        /// <value>Value.</value>
        
        [JsonProperty(PropertyName = "value")]
        public int Value { get; set; }

        /// <summary>
        /// Description.
        /// </summary>
        /// <value>Description.</value>
        
        [JsonProperty(PropertyName = "description")]
        public string Description { get; set; }
    }
}

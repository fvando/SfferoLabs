using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using INS.PT.WebAPI.Models.DTO.Collections.Elements;

namespace INS.PT.WebAPI.Models.DTO.Collections.ProvisionalWebAccounts
{

    /// <summary>
    /// 
    /// </summary>
    
    public class ZFscdPcCobrarWsResponseDTO
    {
        /// <summary>
        /// Gets or Sets Errors
        /// </summary>
        
        [JsonProperty(PropertyName = "errors")]
        public ZFscdPcCobrarWsDTO ZFscdPcCobrarWsResponse { get; set; }
    }
}

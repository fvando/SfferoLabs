﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections.ProvisionWebAccounts
{
    /// <summary>
    /// ZFscdPcConsultarWsInputDTO
    /// </summary>
    public class ZFscdPcConsultarWsInputDTO
    {
        /// <summary>
        /// Gets or Sets BrokerContract
        /// </summary>
        [JsonProperty(PropertyName = "brokerContract")]
        public string BrokerContract { get; set; }
        /// <summary>
        /// Gets or Sets BrokerReport
        /// </summary>
        [JsonProperty(PropertyName = "brokerReport")]
        public string BrokerReport { get; set; }
    }
}

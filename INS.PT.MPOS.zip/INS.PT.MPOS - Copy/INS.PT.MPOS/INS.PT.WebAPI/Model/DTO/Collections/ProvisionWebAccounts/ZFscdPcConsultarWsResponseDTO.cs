﻿using INS.PT.WebAPI.Models.DTO.Collections.Elements;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections.ProvisionWebAccounts
{
    /// <summary>
    /// ZFscdPcConsultarWsResponseDTO
    /// </summary>
    public class ZFscdPcConsultarWsResponseDTO
    {
        /// <summary>
        /// Gets or Sets Errors
        /// </summary>
        [JsonProperty(PropertyName = "errors")]
        public List<ZfscdCodigosErroLinhaQueryDTO> Errors { get; set; }
        /// <summary>
        /// Gets or Sets PcDetail
        /// </summary>
        [JsonProperty(PropertyName = "detail")]
        public List<ZfscdPcDetailLinhaDTO> PcDetail { get; set; }
        /// <summary>
        /// Gets or Sets PcHeader
        /// </summary>
        [JsonProperty(PropertyName = "header")]
        public ZfscdPcHeaderLinhaDTO PcHeader { get; set; }
    }
}

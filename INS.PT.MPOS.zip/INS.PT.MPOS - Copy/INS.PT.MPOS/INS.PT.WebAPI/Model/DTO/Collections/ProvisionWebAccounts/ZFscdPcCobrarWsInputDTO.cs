using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using INS.PT.WebAPI.Models.DTO.Collections.Elements;

namespace INS.PT.WebAPI.Models.DTO.Collections.ProvisionalWebAccounts
{

    /// <summary>
    /// 
    /// </summary>
    
    public class ZFscdPcCobrarWsInputDTO
    {
        /// <summary>
        /// Gets or Sets BrokerContract
        /// </summary>
        
        [JsonProperty(PropertyName = "brokerContract")]
        public string BrokerContract { get; set; }

        /// <summary>
        /// Gets or Sets PcReceipts
        /// </summary>
        
        [JsonProperty(PropertyName = "pcReceipts")]
        public List<ZfscdPcRecibosLinhaDTO> PcReceipts { get; set; }

    }
}

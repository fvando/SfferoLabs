﻿using INS.PT.WebAPI.Models.DTO.Collections.Elements;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections.WebReceiptListing
{

    /// <summary>
    /// 
    /// </summary>
    
    public class ZFscdRecibosListarWsResponseDTO
    {
        /// <summary>
        /// The z FSCD recibos listar ws response
        /// </summary>
        /// <value>The z FSCD recibos listar ws response</value>
        
        [JsonProperty(PropertyName = "zFscdRecibosListarWsResponse")]
        public ZFscdRecibosListarWsDTO ZFscdRecibosListarWsResponse { get; set; }        
    }
}

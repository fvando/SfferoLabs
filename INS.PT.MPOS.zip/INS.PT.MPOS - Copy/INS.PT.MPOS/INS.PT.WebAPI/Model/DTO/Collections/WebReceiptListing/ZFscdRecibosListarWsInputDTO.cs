using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;


namespace INS.PT.WebAPI.Models.DTO.Collections.WebReceiptListing
{
    
    public class ZFscdRecibosListarWsInputDTO
    {
        /// <summary>
        /// Gets or sets the broker.
        /// </summary>
        /// <value>Gets or sets the broker.</value>
        
        [JsonProperty(PropertyName = "broker")]
        public string Broker { get; set; }

        /// <summary>
        /// Gets or sets the company code.
        /// </summary>
        /// <value>Gets or sets the company code.</value>
        
        [JsonProperty(PropertyName = "companyCode")]
        public string CompanyCode { get; set; }

        /// <summary>
        /// Gets or sets the end date.
        /// </summary>
        /// <value>Gets or sets the end date.</value>
        
        [JsonProperty(PropertyName = "endDate")]
        public string EndDate { get; set; }

        /// <summary>
        /// Gets or sets the policy.
        /// </summary>
        /// <value>Gets or sets the policy.</value>
        
        [JsonProperty(PropertyName = "policy")]
        public string Policy { get; set; }

        /// <summary>
        /// Gets or sets the reference document number.
        /// </summary>
        /// <value>Gets or sets the reference document number.</value>
        
        [JsonProperty(PropertyName = "referenceDocumentNumber")]
        public string ReferenceDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets the start date.
        /// </summary>
        /// <value>Gets or sets the start date.</value>
        
        [JsonProperty(PropertyName = "startDate")]
        public string StartDate { get; set; }

        /// <summary>
        /// status = 'P'      Em aberto  status = 'A'      Anulado  status = 'B'      Circuito bancário(em aberto)  status = 'C'      Cobrado  status = 'X'      Estornado(eventualmente a retirar da listagem?)
        /// </summary>
        /// <value>status = 'P'      Em aberto  status = 'A'      Anulado  status = 'B'      Circuito bancário(em aberto)  status = 'C'      Cobrado  status = 'X'      Estornado(eventualmente a retirar da listagem?)</value>
        
        [JsonProperty(PropertyName = "status")]
        public string Status { get; set; }

        /// <summary>
        /// Gets or sets the tax number.
        /// </summary>
        /// <value>Gets or sets the tax number.</value>
        
        [JsonProperty(PropertyName = "taxNumber")]
        public string TaxNumber { get; set; }
    }
}

using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Collections.Elements
{

  /// <summary>
  /// 
  /// </summary>
  
  public class ZfscdCodigosErroLinhaCobDTO
    {
    /// <summary>
    /// Gets or Sets ErroRCODE
    /// </summary>
    
    [JsonProperty(PropertyName = "erroR_CODE")]
    public string ErroRCODE { get; set; }

    /// <summary>
    /// Gets or Sets ErroRCODETXT
    /// </summary>
    
    [JsonProperty(PropertyName = "erroR_CODE_TXT")]
    public string ErroRCODETXT { get; set; }
}
}

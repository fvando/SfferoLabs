﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections.Elements
{
    /// <summary>
    /// ZfscdCodigosErroLinhaQueryDTO
    /// </summary>
    public class ZfscdCodigosErroLinhaQueryDTO
    {
        /// <summary>
        /// Gets or Sets ErrorCode
        /// </summary>
        [JsonProperty(PropertyName = "errorCode")]
        public string ErrorCode { get; set; }
        /// <summary>
        /// Gets or Sets ErrorCodeTxt
        /// </summary>
        [JsonProperty(PropertyName = "errorCodeTxt")]
        public string ErrorCodeTxt { get; set; }
    }
}

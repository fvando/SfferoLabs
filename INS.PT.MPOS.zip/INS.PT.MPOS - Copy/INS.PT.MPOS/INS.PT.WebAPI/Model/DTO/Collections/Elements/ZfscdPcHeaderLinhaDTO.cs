﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.Collections.Elements
{
    /// <summary>
    /// ZfscdPcHeaderLinhaDTO
    /// </summary>
    public class ZfscdPcHeaderLinhaDTO
    {
        /// <summary>
        /// Gets or Sets BrokerReport
        /// </summary>
        [JsonProperty(PropertyName = "brokerReport")]
        public string BrokerReport { get; set; }
        /// <summary>
        /// Gets or Sets SearchTerm
        /// </summary>
        [JsonProperty(PropertyName = "searchTerm")]
        public string SearchTerm { get; set; }
        /// <summary>
        /// Gets or Sets Status
        /// </summary>
        [JsonProperty(PropertyName = "status")]
        public string Status { get; set; }
        /// <summary>
        /// Gets or Sets Broker
        /// </summary>
        [JsonProperty(PropertyName = "broker")]
        public string Broker { get; set; }
        /// <summary>
        /// Gets or Sets BrokerContract
        /// </summary>
        [JsonProperty(PropertyName = "brokerContract")]
        public string BrokerContract { get; set; }
        /// <summary>
        /// Gets or Sets PeriodFrom
        /// </summary>
        [JsonProperty(PropertyName = "periodFrom")]
        public string PeriodFrom { get; set; }
        /// <summary>
        /// Gets or Sets PeriodTo
        /// </summary>
        [JsonProperty(PropertyName = "periodTo")]
        public string PeriodTo { get; set; }
        /// <summary>
        /// Gets or Sets ReportType
        /// </summary>
        [JsonProperty(PropertyName = "reportType")]
        public string ReportType { get; set; }
        /// <summary>
        /// Gets or Sets InitReason
        /// </summary>
        [JsonProperty(PropertyName = "initReason")]
        public string InitReason { get; set; }
        /// <summary>
        /// Gets or Sets BrokerReportOrigin
        /// </summary>
        [JsonProperty(PropertyName = "brokerReportOrigin")]
        public string BrokerReportOrigin { get; set; }
        /// <summary>
        /// Gets or Sets InitDate
        /// </summary>
        [JsonProperty(PropertyName = "initDate")]
        public string InitDate { get; set; }
        /// <summary>
        /// Gets or Sets CompanyCode
        /// </summary>
        [JsonProperty(PropertyName = "companyCode")]
        public string CompanyCode { get; set; }
        /// <summary>
        /// Gets or Sets PostingDate
        /// </summary>
        [JsonProperty(PropertyName = "postingDate")]
        public string PostingDate { get; set; }
        /// <summary>
        /// Gets or Sets DocumentDate
        /// </summary>
        [JsonProperty(PropertyName = "documentDate")]
        public string DocumentDate { get; set; }
        /// <summary>
        /// Gets or Sets ValutDate
        /// </summary>
        [JsonProperty(PropertyName = "valutDate")]
        public string ValutDate { get; set; }
        /// <summary>
        /// Gets or Sets Version
        /// </summary>
        [JsonProperty(PropertyName = "version")]
        public string Version { get; set; }
        /// <summary>
        /// Gets or Sets CreateName
        /// </summary>
        [JsonProperty(PropertyName = "createName")]
        public string CreateName { get; set; }
        /// <summary>
        /// Gets or Sets CreateDate
        /// </summary>
        [JsonProperty(PropertyName = "createDate")]
        public string CreateDate { get; set; }
        /// <summary>
        /// Gets or Sets CreateTime
        /// </summary>
        [JsonProperty(PropertyName = "createTime")]
        public string CreateTime { get; set; }
        /// <summary>
        /// Gets or Sets ChangeName
        /// </summary>
        [JsonProperty(PropertyName = "changeName")]
        public string ChangeName { get; set; }
        /// <summary>
        /// Gets or Sets ChangeDate
        /// </summary>
        [JsonProperty(PropertyName = "changeDate")]
        public string ChangeDate { get; set; }
        /// <summary>
        /// Gets or Sets ChangeTime
        /// </summary>
        [JsonProperty(PropertyName = "changeTime")]
        public string ChangeTime { get; set; }
        /// <summary>
        /// Gets or Sets Currency
        /// </summary>
        [JsonProperty(PropertyName = "currency")]
        public string Currency { get; set; }
        /// <summary>
        /// Gets or Sets ControlSum
        /// </summary>
        [JsonProperty(PropertyName = "controlSum")]
        public decimal ControlSum { get; set; }
        /// <summary>
        /// Gets or Sets PostingSum
        /// </summary>
        [JsonProperty(PropertyName = "postingSum")]
        public decimal PostingSum { get; set; }
        /// <summary>
        /// Gets or Sets ControlNumber
        /// </summary>
        [JsonProperty(PropertyName = "controlNumber")]
        public string ControlNumber { get; set; }
        /// <summary>
        /// Gets or Sets PostingNumber
        /// </summary>
        [JsonProperty(PropertyName = "postingNumber")]
        public string PostingNumber { get; set; }
    }
}

using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Collections.Elements
{

    /// <summary>
    /// 
    /// </summary>
    
    public class ZFscdPcCobrarWsDTO
    {
        /// <summary>
        /// Gets or Sets Errors
        /// </summary>
        
        [JsonProperty(PropertyName = "errors")]
        public List<ZfscdCodigosErroLinhaCobDTO> Errors { get; set; }
    }
}

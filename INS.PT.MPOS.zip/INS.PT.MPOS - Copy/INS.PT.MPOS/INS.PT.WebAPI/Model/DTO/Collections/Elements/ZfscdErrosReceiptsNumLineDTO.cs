using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Collections.Elements
{

    /// <summary>
    /// 
    /// </summary>
    
    public class ZfscdErrosReceiptsNumLineDTO
    {
        /// <summary>
        /// Gets or sets the error code.
        /// </summary>
        /// <value>Gets or sets the error code.</value>
        
        [JsonProperty(PropertyName = "errorCode")]
        public string ErrorCode { get; set; }

        /// <summary>
        /// Gets or sets the error code text.
        /// </summary>
        /// <value>Gets or sets the error code text.</value>
        
        [JsonProperty(PropertyName = "errorCodeTxt")]
        public string ErrorCodeTxt { get; set; }
    }
}

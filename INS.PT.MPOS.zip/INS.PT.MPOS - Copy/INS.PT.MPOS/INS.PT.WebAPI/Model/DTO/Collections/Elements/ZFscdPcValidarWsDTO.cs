using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;
using INS.PT.WebAPI.Models.DTO.Collections.Elements;

namespace INS.PT.WebAPI.Models.DTO.Collections.Elements
{

    
    public class ZFscdPcValidarDTO
    {
        /// <summary>
        /// Gets or sets the errors.
        /// </summary>
        /// <value>Gets or sets the errors.</value>
        
        [JsonProperty(PropertyName = "errors")]
        public List<ZfscdCodigosErroLinhaValDTO> Errors { get; set; }
    }
}

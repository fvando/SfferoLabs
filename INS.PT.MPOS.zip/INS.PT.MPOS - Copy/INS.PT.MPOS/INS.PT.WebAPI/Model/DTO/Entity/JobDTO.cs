

// Copyright Ageas 2019 � - Integration Team

using System;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// Job object.
    /// </summary>
    
    public class JobDto
    {
        /// <summary>
        /// Code.
        /// </summary>
        /// <value>Code.</value>
        
        [JsonProperty(PropertyName = "professionalCode")]
        public string ProfessionalCode { get; set; }

        /// <summary>
        /// Description.
        /// </summary>
        /// <value>Description.</value>
        
        [JsonProperty(PropertyName = "professionalDescription")]
        public string ProfessionalDescription { get; set; }

        /// <summary>
        /// Flag to identify the main job.
        /// </summary>
        /// <value>Flag to identify the main job.</value>
        
        [JsonProperty(PropertyName = "isPrincipal")]
        public bool? IsPrincipal { get; set; }

        /// <summary>
        /// Status code.
        /// </summary>
        /// <value>Status code.</value>
        
        [JsonProperty(PropertyName = "laborStatusCode")]
        public string LaborStatusCode { get; set; }

        /// <summary>
        /// Status.
        /// </summary>
        /// <value>Status.</value>
        
        [JsonProperty(PropertyName = "laborStatusDescription")]
        public string LaborStatusDescription { get; set; }

        /// <summary>
        /// Employer.
        /// </summary>
        /// <value>Employer.</value>
        
        [JsonProperty(PropertyName = "employerEntity")]
        public string EmployerEntity { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        /// <value>Start date.</value>
        
        [JsonProperty(PropertyName = "startDate")]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        /// <value>End date.</value>
        
        [JsonProperty(PropertyName = "endDate")]
        public DateTime? EndDate { get; set; }
    }
}

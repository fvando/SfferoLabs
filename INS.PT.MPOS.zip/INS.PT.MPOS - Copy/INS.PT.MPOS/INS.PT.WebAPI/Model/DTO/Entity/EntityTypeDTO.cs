

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class EntityTypeDto
    {
        /// <summary>
        /// Individual person.
        /// </summary>
        /// <value>Individual person.</value>
        
        [JsonProperty(PropertyName = "individual")]
        public PersonDto Individual { get; set; }

        /// <summary>
        /// Company.
        /// </summary>
        /// <value>Company.</value>
        
        [JsonProperty(PropertyName = "company")]
        public OrganizationDto Company { get; set; }
    }
}

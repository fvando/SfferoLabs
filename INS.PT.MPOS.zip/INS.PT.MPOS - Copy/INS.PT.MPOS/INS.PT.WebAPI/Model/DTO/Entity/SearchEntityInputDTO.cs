

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// Search entity parameters object.
    /// </summary>
    
    public class SearchEntityInputDTO
    {
        /// <summary>
        /// Vat number to be searched.
        /// </summary>
        /// <value>Vat number to be searched.</value>
        
        [JsonProperty(PropertyName = "vatNumber")]
        public string VatNumber { get; set; }

        /// <summary>
        /// Bank account number.
        /// </summary>
        /// <value>Bank account number.</value>
        
        [JsonProperty(PropertyName = "bankAccount")]
        public string BankAccount { get; set; }

        /// <summary>
        /// Person name.
        /// </summary>
        /// <value>Person name.</value>
        
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        /// <summary>
        /// Gender.
        /// </summary>
        /// <value>Gender.</value>
        
        [JsonProperty(PropertyName = "gender")]
        public string Gender { get; set; }

        /// <summary>
        /// Phone number.
        /// </summary>
        /// <value>Phone number.</value>
        
        [JsonProperty(PropertyName = "phoneNumber")]
        public string PhoneNumber { get; set; }
    }
}

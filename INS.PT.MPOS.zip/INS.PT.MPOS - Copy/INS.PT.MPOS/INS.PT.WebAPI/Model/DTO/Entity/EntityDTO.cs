

// Copyright Ageas 2019 � - Integration Team

using System.Collections.Generic;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// Entity object.
    /// </summary>
    
    public class EntityDto
    {
        /// <summary>
        /// Entity id.
        /// </summary>
        /// <value>Entity id.</value>
        
        [JsonProperty(PropertyName = "idEntity")]
        public string IdEntity { get; set; }

        /// <summary>
        /// Vat number.
        /// </summary>
        /// <value>Vat number.</value>
        
        [JsonProperty(PropertyName = "vatNumber")]
        public string VatNumber { get; set; }

        /// <summary>
        /// Flag that indicates Vat is foreign.
        /// </summary>
        /// <value>Flag that indicates Vat is foreign.</value>
        
        [JsonProperty(PropertyName = "isForeignVat")]
        public bool? IsForeignVat { get; set; }

        /// <summary>
        /// Country code.
        /// </summary>
        /// <value>Country code.</value>
        
        [JsonProperty(PropertyName = "countryCode")]
        public string CountryCode { get; set; }

        /// <summary>
        /// Country name.
        /// </summary>
        /// <value>Country name.</value>
        
        [JsonProperty(PropertyName = "countryDescription")]
        public string CountryDescription { get; set; }

        /// <summary>
        /// Gets or Sets Type
        /// </summary>
        
        [JsonProperty(PropertyName = "type")]
        public EntityTypeDto Type { get; set; }

        /// <summary>
        /// List of addresses.
        /// </summary>
        /// <value>List of addresses.</value>
        
        [JsonProperty(PropertyName = "addresses")]
        public List<AddressDto> Addresses { get; set; }

        /// <summary>
        /// Lists of all contacts types.
        /// </summary>
        /// <value>Lists of all contacts types.</value>
        
        [JsonProperty(PropertyName = "contacts")]
        public ContactListsDto Contacts { get; set; }

        /// <summary>
        /// List of bank accounts.
        /// </summary>
        /// <value>List of bank accounts.</value>
        
        [JsonProperty(PropertyName = "bankAccounts")]
        public List<BankAccountDto> BankAccounts { get; set; }

        /// <summary>
        /// List of documents.
        /// </summary>
        /// <value>List of documents.</value>
        
        [JsonProperty(PropertyName = "documents")]
        public List<DocumentDto> Documents { get; set; }

        /// <summary>
        /// List od CAEs.
        /// </summary>
        /// <value>List od CAEs.</value>
        
        [JsonProperty(PropertyName = "caes")]
        public List<CaeDto> Caes { get; set; }

        /// <summary>
        /// List of External References.
        /// </summary>
        /// <value>List of External References.</value>
        
        [JsonProperty(PropertyName = "externalReferences")]
        public List<ExternalReferenceDto> ExternalReferences { get; set; }

        /// <summary>
        /// List of Crs/Fatcas
        /// </summary>
        /// <value>List of Crs/Fatcas</value>
        
        [JsonProperty(PropertyName = "crsFatcas")]
        public List<CrsFatcaDto> CrsFatcas { get; set; }

        /// <summary>
        /// List of affinity relations.
        /// </summary>
        /// <value>List of affinity relations.</value>
        
        [JsonProperty(PropertyName = "affinityRelations")]
        public List<AffinityRelationDto> AffinityRelations { get; set; }

        /// <summary>
        /// List of AMLs.
        /// </summary>
        /// <value>List of AMLs.</value>
        
        [JsonProperty(PropertyName = "amls")]
        public List<AmlDto> Amls { get; set; }

        /// <summary>
        /// List of profiles.
        /// </summary>
        /// <value>List of profiles.</value>
        
        [JsonProperty(PropertyName = "profiles")]
        public List<ProfileDto> Profiles { get; set; }
    }
}

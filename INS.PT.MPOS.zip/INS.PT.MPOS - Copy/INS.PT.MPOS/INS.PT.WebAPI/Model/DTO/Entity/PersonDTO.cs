

// Copyright Ageas 2019 � - Integration Team

using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// Person object.
    /// </summary>
    
    public class PersonDto
    {
        /// <summary>
        /// Name.
        /// </summary>
        /// <value>Name.</value>
        
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        /// <summary>
        /// Birthdate.
        /// </summary>
        /// <value>Birthdate.</value>
        
        [JsonProperty(PropertyName = "birthdate")]
        public DateTime? Birthdate { get; set; }

        /// <summary>
        /// Gender.
        /// </summary>
        /// <value>Gender.</value>
        
        [JsonProperty(PropertyName = "gender")]
        public string Gender { get; set; }

        /// <summary>
        /// Marital status.
        /// </summary>
        /// <value>Marital status.</value>
        
        [JsonProperty(PropertyName = "maritalStatus")]
        public string MaritalStatus { get; set; }

        /// <summary>
        /// Flag indicating if is deceased.
        /// </summary>
        /// <value>Flag indicating if is deceased.</value>
        
        [JsonProperty(PropertyName = "isDeceased")]
        public bool? IsDeceased { get; set; }

        /// <summary>
        /// Date of death.
        /// </summary>
        /// <value>Date of death.</value>
        
        [JsonProperty(PropertyName = "deceasedDate")]
        public DateTime? DeceasedDate { get; set; }

        /// <summary>
        /// Flag if person is self employed.
        /// </summary>
        /// <value>Flag if person is self employed.</value>
        
        [JsonProperty(PropertyName = "isSelfEmployee")]
        public bool? IsSelfEmployee { get; set; }

        /// <summary>
        /// Place of birth.
        /// </summary>
        /// <value>Place of birth.</value>
        
        [JsonProperty(PropertyName = "placeOfBirth")]
        public string PlaceOfBirth { get; set; }

        /// <summary>
        /// List of nationalities.
        /// </summary>
        /// <value>List of nationalities.</value>
        
        [JsonProperty(PropertyName = "nationalities")]
        public List<NationalityDto> Nationalities { get; set; }

        /// <summary>
        /// List of titles.
        /// </summary>
        /// <value>List of titles.</value>
        
        [JsonProperty(PropertyName = "honoraryTitles")]
        public List<HonoraryTitleDto> HonoraryTitles { get; set; }

        /// <summary>
        /// List of jobs.
        /// </summary>
        /// <value>List of jobs.</value>
        
        [JsonProperty(PropertyName = "jobs")]
        public List<JobDto> Jobs { get; set; }

        /// <summary>
        /// List of driver licences.
        /// </summary>
        /// <value>List of driver licences.</value>
        
        [JsonProperty(PropertyName = "driverLicences")]
        public List<DriverLicenceDto> DriverLicences { get; set; }
    }
}

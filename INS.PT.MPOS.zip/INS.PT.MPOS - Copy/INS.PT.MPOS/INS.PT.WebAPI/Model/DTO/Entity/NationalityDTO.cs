

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// Nationality object.
    /// </summary>
    
    public class NationalityDto
    {
        /// <summary>
        /// Code.
        /// </summary>
        /// <value>Code.</value>
        
        [JsonProperty(PropertyName = "nationalityCode")]
        public string NationalityCode { get; set; }

        /// <summary>
        /// Description.
        /// </summary>
        /// <value>Description.</value>
        
        [JsonProperty(PropertyName = "nationalityDescription")]
        public string NationalityDescription { get; set; }

        /// <summary>
        /// Flag for the main nationality.
        /// </summary>
        /// <value>Flag for the main nationality.</value>
        
        [JsonProperty(PropertyName = "isPrincipal")]
        public bool? IsPrincipal { get; set; }
    }
}

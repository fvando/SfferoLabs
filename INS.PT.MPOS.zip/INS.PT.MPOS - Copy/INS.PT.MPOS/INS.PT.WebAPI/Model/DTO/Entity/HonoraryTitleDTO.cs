

// Copyright Ageas 2019 � - Integration Team

using System;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// Honorary title object.
    /// </summary>
    
    public class HonoraryTitleDto
    {
        /// <summary>
        /// Code.
        /// </summary>
        /// <value>Code.</value>
        
        [JsonProperty(PropertyName = "titleCode")]
        public string TitleCode { get; set; }

        /// <summary>
        /// Description.
        /// </summary>
        /// <value>Description.</value>
        
        [JsonProperty(PropertyName = "titleDescription")]
        public string TitleDescription { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        /// <value>Start date.</value>
        
        [JsonProperty(PropertyName = "startDate")]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        /// <value>End date.</value>
        
        [JsonProperty(PropertyName = "endDate")]
        public DateTime? EndDate { get; set; }
    }
}

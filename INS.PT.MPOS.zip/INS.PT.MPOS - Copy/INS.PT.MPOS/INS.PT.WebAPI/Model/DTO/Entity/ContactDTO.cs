

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class ContactDto
    {
        /// <summary>
        /// Contact type code.
        /// </summary>
        /// <value>Contact type code.</value>
        
        [JsonProperty(PropertyName = "contactTypeCode")]
        public string ContactTypeCode { get; set; }

        /// <summary>
        /// Contact type description.
        /// </summary>
        /// <value>Contact type description.</value>
        
        [JsonProperty(PropertyName = "contactTypeDescription")]
        public string ContactTypeDescription { get; set; }

        /// <summary>
        /// Contact value.
        /// </summary>
        /// <value>Contact value.</value>
        
        [JsonProperty(PropertyName = "value")]
        public string Value { get; set; }
    }
}



// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// Phone object.
    /// </summary>
    
    public class PhoneDto
    {
        /// <summary>
        /// Identifier.
        /// </summary>
        /// <value>Identifier.</value>
        
        [JsonProperty(PropertyName = "phoneIdentifier")]
        public string PhoneIdentifier { get; set; }

        /// <summary>
        /// Phone type code.
        /// </summary>
        /// <value>Phone type code.</value>
        
        [JsonProperty(PropertyName = "phoneTypeCode")]
        public string PhoneTypeCode { get; set; }

        /// <summary>
        /// Phone type description.
        /// </summary>
        /// <value>Phone type description.</value>
        
        [JsonProperty(PropertyName = "phoneTypeDescription")]
        public string PhoneTypeDescription { get; set; }

        /// <summary>
        /// Number.
        /// </summary>
        /// <value>Number.</value>
        
        [JsonProperty(PropertyName = "phoneNumber")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Flag to the preferred phone.
        /// </summary>
        /// <value>Flag to the preferred phone.</value>
        
        [JsonProperty(PropertyName = "isPreferred")]
        public bool? IsPreferred { get; set; }
    }
}



// Copyright Ageas 2019 � - Integration Team

using System.Collections.Generic;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class OrganizationContactDto
    {
        /// <summary>
        /// Position.
        /// </summary>
        /// <value>Position.</value>
        
        [JsonProperty(PropertyName = "position")]
        public string Position { get; set; }

        /// <summary>
        /// Contact name.
        /// </summary>
        /// <value>Contact name.</value>
        
        [JsonProperty(PropertyName = "contactName")]
        public string ContactName { get; set; }

        /// <summary>
        /// List of contects.
        /// </summary>
        /// <value>List of contects.</value>
        
        [JsonProperty(PropertyName = "contacts")]
        public List<ContactDto> Contacts { get; set; }
    }
}

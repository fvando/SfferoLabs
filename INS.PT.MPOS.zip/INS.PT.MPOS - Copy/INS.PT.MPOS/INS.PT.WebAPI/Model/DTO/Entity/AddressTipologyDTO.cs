

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class AddressTipologyDto
    {
        /// <summary>
        /// Postal address.
        /// </summary>
        /// <value>Postal address.</value>
        
        [JsonProperty(PropertyName = "postalAddress")]
        public PoAddressDto PostalAddress { get; set; }

        /// <summary>
        /// Postal Box.
        /// </summary>
        /// <value>Postal Box.</value>
        
        [JsonProperty(PropertyName = "postalBox")]
        public PoBoxDto PostalBox { get; set; }
    }
}

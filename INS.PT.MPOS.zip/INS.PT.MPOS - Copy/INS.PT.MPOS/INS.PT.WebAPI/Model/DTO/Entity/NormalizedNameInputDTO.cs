

// Copyright Ageas 2019 � - Integration Team

using System;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// Input parameters to normalize a name.
    /// </summary>
    
    public class NormalizedNameInputDTO
    {
        /// <summary>
        /// Name.
        /// </summary>
        /// <value>Name.</value>
        
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        /// <summary>
        /// Birthdate.
        /// </summary>
        /// <value>Birthdate.</value>
        
        [JsonProperty(PropertyName = "birthdate")]
        public DateTime? Birthdate { get; set; }

        /// <summary>
        /// Gender.
        /// </summary>
        /// <value>Gender.</value>
        
        [JsonProperty(PropertyName = "gender")]
        public string Gender { get; set; }
    }
}

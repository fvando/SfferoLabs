

// Copyright Ageas 2019 � - Integration Team

using System.Collections.Generic;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// Driver&#39;s licence object.
    /// </summary>
    
    public class DriverLicenceDto
    {
        /// <summary>
        /// Licence number.
        /// </summary>
        /// <value>Licence number.</value>
        
        [JsonProperty(PropertyName = "driverLicenceNumber")]
        public string DriverLicenceNumber { get; set; }

        /// <summary>
        /// Country code.
        /// </summary>
        /// <value>Country code.</value>
        
        [JsonProperty(PropertyName = "countryCode")]
        public string CountryCode { get; set; }

        /// <summary>
        /// Country description.
        /// </summary>
        /// <value>Country description.</value>
        
        [JsonProperty(PropertyName = "countryDescription")]
        public string CountryDescription { get; set; }

        /// <summary>
        /// List of driver licence categories.
        /// </summary>
        /// <value>List of driver licence categories.</value>
        
        [JsonProperty(PropertyName = "categories")]
        public List<CategoryDto> Categories { get; set; }
    }
}

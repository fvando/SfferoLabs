

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class ProfileDto
    {
        /// <summary>
        /// Agent id.
        /// </summary>
        /// <value>Agent id.</value>
        
        [JsonProperty(PropertyName = "agentIdentifier")]
        public string AgentIdentifier { get; set; }
    }
}

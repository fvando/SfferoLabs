

// Copyright Ageas 2019 � - Integration Team

using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// Organization object.
    /// </summary>
    
    public class OrganizationDto
    {
        /// <summary>
        /// Name.
        /// </summary>
        /// <value>Name.</value>
        
        [JsonProperty(PropertyName = "companyName")]
        public string CompanyName { get; set; }

        /// <summary>
        /// Date company has founded.
        /// </summary>
        /// <value>Date company has founded.</value>
        
        [JsonProperty(PropertyName = "foundingDate")]
        public DateTime? FoundingDate { get; set; }

        /// <summary>
        /// Constitution country code.
        /// </summary>
        /// <value>Constitution country code.</value>
        
        [JsonProperty(PropertyName = "constitutionCountryCode")]
        public string ConstitutionCountryCode { get; set; }

        /// <summary>
        /// Constitution country.
        /// </summary>
        /// <value>Constitution country.</value>
        
        [JsonProperty(PropertyName = "constitutionCountryDescription")]
        public string ConstitutionCountryDescription { get; set; }

        /// <summary>
        /// Total employees.
        /// </summary>
        /// <value>Total employees.</value>
        
        [JsonProperty(PropertyName = "totalEmployees")]
        public double? TotalEmployees { get; set; }

        /// <summary>
        /// Gross annual revenue.
        /// </summary>
        /// <value>Gross annual revenue.</value>
        
        [JsonProperty(PropertyName = "grossAnnualRevenue")]
        public double? GrossAnnualRevenue { get; set; }

        /// <summary>
        /// Wages amount.
        /// </summary>
        /// <value>Wages amount.</value>
        
        [JsonProperty(PropertyName = "wagesAmount")]
        public double? WagesAmount { get; set; }

        /// <summary>
        /// Equity capital.
        /// </summary>
        /// <value>Equity capital.</value>
        
        [JsonProperty(PropertyName = "equityCapital")]
        public double? EquityCapital { get; set; }

        /// <summary>
        /// Company type code.
        /// </summary>
        /// <value>Company type code.</value>
        
        [JsonProperty(PropertyName = "companyTypeCode")]
        public string CompanyTypeCode { get; set; }

        /// <summary>
        /// Company type.
        /// </summary>
        /// <value>Company type.</value>
        
        [JsonProperty(PropertyName = "companyTypeDescription")]
        public string CompanyTypeDescription { get; set; }

        /// <summary>
        /// Legal form.
        /// </summary>
        /// <value>Legal form.</value>
        
        [JsonProperty(PropertyName = "legalForm")]
        public string LegalForm { get; set; }

        /// <summary>
        /// Website.
        /// </summary>
        /// <value>Website.</value>
        
        [JsonProperty(PropertyName = "website")]
        public string Website { get; set; }

        /// <summary>
        /// List of contact for the entity.
        /// </summary>
        /// <value>List of contact for the entity.</value>
        
        [JsonProperty(PropertyName = "organizationContactPoints")]
        public List<OrganizationContactDto> OrganizationContactPoints { get; set; }
    }
}

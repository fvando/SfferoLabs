

// Copyright Ageas 2019 � - Integration Team

using System;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// Class that represents a entity on is simpler form.
    /// </summary>
    
    public class SimpleEntityDto
    {
        /// <summary>
        /// Company id.
        /// </summary>
        /// <value>Company id.</value>
        
        [JsonProperty(PropertyName = "idCompany")]
        public string IdCompany { get; set; }

        /// <summary>
        /// Network id.
        /// </summary>
        /// <value>Network id.</value>
        
        [JsonProperty(PropertyName = "idNetwork")]
        public string IdNetwork { get; set; }

        /// <summary>
        /// Entity id.
        /// </summary>
        /// <value>Entity id.</value>
        
        [JsonProperty(PropertyName = "idEntity")]
        public string IdEntity { get; set; }

        /// <summary>
        /// Name.
        /// </summary>
        /// <value>Name.</value>
        
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        /// <summary>
        /// Vat number.
        /// </summary>
        /// <value>Vat number.</value>
        
        [JsonProperty(PropertyName = "vatNumber")]
        public string VatNumber { get; set; }

        /// <summary>
        /// Birthdate.
        /// </summary>
        /// <value>Birthdate.</value>
        
        [JsonProperty(PropertyName = "birthdate")]
        public DateTime? Birthdate { get; set; }

        /// <summary>
        /// Address.
        /// </summary>
        /// <value>Address.</value>
        
        [JsonProperty(PropertyName = "address")]
        public AddressDto Address { get; set; }

        /// <summary>
        /// Entity type.
        /// </summary>
        /// <value>Entity type.</value>
        
        [JsonProperty(PropertyName = "entityType")]
        public string EntityType { get; set; }

        /// <summary>
        /// Entity phone.
        /// </summary>
        /// <value>Entity phone.</value>
        
        [JsonProperty(PropertyName = "entityPhone")]
        public string EntityPhone { get; set; }
    }
}

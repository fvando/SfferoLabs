

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// Normalized result.
    /// </summary>
    
    public class NormalizedNameOutputDTO
    {
        /// <summary>
        /// Normalized first name.
        /// </summary>
        /// <value>Normalized first name.</value>
        
        [JsonProperty(PropertyName = "firstName")]
        public string FirstName { get; set; }

        /// <summary>
        /// Normalized middle name.
        /// </summary>
        /// <value>Normalized middle name.</value>
        
        [JsonProperty(PropertyName = "middleName")]
        public string MiddleName { get; set; }

        /// <summary>
        /// Normalized last name.
        /// </summary>
        /// <value>Normalized last name.</value>
        
        [JsonProperty(PropertyName = "lastName")]
        public string LastName { get; set; }

        /// <summary>
        /// Normalized full name.
        /// </summary>
        /// <value>Normalized full name.</value>
        
        [JsonProperty(PropertyName = "fullName")]
        public string FullName { get; set; }

        /// <summary>
        /// Flag indicating if input got normalized.
        /// </summary>
        /// <value>Flag indicating if input got normalized.</value>
        
        [JsonProperty(PropertyName = "isNormalized")]
        public bool? IsNormalized { get; set; }

        /// <summary>
        /// Error code if any is returned.
        /// </summary>
        /// <value>Error code if any is returned.</value>
        
        [JsonProperty(PropertyName = "errorCode")]
        public int? ErrorCode { get; set; }

        /// <summary>
        /// Error message of normalization process.
        /// </summary>
        /// <value>Error message of normalization process.</value>
        
        [JsonProperty(PropertyName = "errorMessage")]
        public string ErrorMessage { get; set; }
    }
}



// Copyright Ageas 2019 � - Integration Team

using System;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class CaeDto
    {
        /// <summary>
        /// Cae order.
        /// </summary>
        /// <value>Cae order.</value>
        
        [JsonProperty(PropertyName = "caeOrderNumber")]
        public int? CaeOrderNumber { get; set; }

        /// <summary>
        /// Flag for the principal CAE.
        /// </summary>
        /// <value>Flag for the principal CAE.</value>
        
        [JsonProperty(PropertyName = "isPrincipal")]
        public bool? IsPrincipal { get; set; }

        /// <summary>
        /// CAE.
        /// </summary>
        /// <value>CAE.</value>
        
        [JsonProperty(PropertyName = "cae")]
        public string _Cae { get; set; }

        /// <summary>
        /// Description.
        /// </summary>
        /// <value>Description.</value>
        
        [JsonProperty(PropertyName = "caeDescription")]
        public string CaeDescription { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        /// <value>Start date.</value>
        
        [JsonProperty(PropertyName = "startDate")]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        /// <value>End date.</value>
        
        [JsonProperty(PropertyName = "endDate")]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Sector of activity.
        /// </summary>
        /// <value>Sector of activity.</value>
        
        [JsonProperty(PropertyName = "sectorOfActivity")]
        public string SectorOfActivity { get; set; }

        /// <summary>
        /// Country code.
        /// </summary>
        /// <value>Country code.</value>
        
        [JsonProperty(PropertyName = "countryCode")]
        public string CountryCode { get; set; }

        /// <summary>
        /// Country description.
        /// </summary>
        /// <value>Country description.</value>
        
        [JsonProperty(PropertyName = "countryDescription")]
        public string CountryDescription { get; set; }
    }
}

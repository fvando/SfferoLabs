

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// PoAddress object.
    /// </summary>
    
    public class PoAddressDto
    {
        /// <summary>
        /// Road type.
        /// </summary>
        /// <value>Road type.</value>
        
        [JsonProperty(PropertyName = "roadType")]
        public string RoadType { get; set; }

        /// <summary>
        /// Road name.
        /// </summary>
        /// <value>Road name.</value>
        
        [JsonProperty(PropertyName = "roadName")]
        public string RoadName { get; set; }

        /// <summary>
        /// House number.
        /// </summary>
        /// <value>House number.</value>
        
        [JsonProperty(PropertyName = "houseNumber")]
        public string HouseNumber { get; set; }

        /// <summary>
        /// Floor number.
        /// </summary>
        /// <value>Floor number.</value>
        
        [JsonProperty(PropertyName = "floorNumber")]
        public string FloorNumber { get; set; }

        /// <summary>
        /// Door number.
        /// </summary>
        /// <value>Door number.</value>
        
        [JsonProperty(PropertyName = "doorNumber")]
        public string DoorNumber { get; set; }

        /// <summary>
        /// Add to address.
        /// </summary>
        /// <value>Add to address.</value>
        
        [JsonProperty(PropertyName = "addToAddress")]
        public string AddToAddress { get; set; }

        /// <summary>
        /// Full address.
        /// </summary>
        /// <value>Full address.</value>
        
        [JsonProperty(PropertyName = "fullAddress")]
        public string FullAddress { get; set; }

        /// <summary>
        /// Locality.
        /// </summary>
        /// <value>Locality.</value>
        
        [JsonProperty(PropertyName = "locality")]
        public string Locality { get; set; }
    }
}

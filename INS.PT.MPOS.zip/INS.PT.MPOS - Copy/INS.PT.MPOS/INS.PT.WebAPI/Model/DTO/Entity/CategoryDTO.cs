

// Copyright Ageas 2019 � - Integration Team

using System;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class CategoryDto
    {
        /// <summary>
        /// Category code.
        /// </summary>
        /// <value>Category code.</value>
        
        [JsonProperty(PropertyName = "code")]
        public string Code { get; set; }

        /// <summary>
        /// Start date.
        /// </summary>
        /// <value>Start date.</value>
        
        [JsonProperty(PropertyName = "startDate")]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End date.
        /// </summary>
        /// <value>End date.</value>
        
        [JsonProperty(PropertyName = "endDate")]
        public DateTime? EndDate { get; set; }
    }
}

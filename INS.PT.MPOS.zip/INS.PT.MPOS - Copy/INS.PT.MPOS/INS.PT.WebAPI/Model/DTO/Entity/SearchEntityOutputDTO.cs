

// Copyright Ageas 2019 � - Integration Team

using System.Collections.Generic;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// Result object with entities found.
    /// </summary>
    
    public class SearchEntityOutputDTO
    {
        /// <summary>
        /// List of entities found.
        /// </summary>
        /// <value>List of entities found.</value>
        
        [JsonProperty(PropertyName = "matchedEntities")]
        public List<SimpleEntityDTO> MatchedEntities { get; set; }
    }
}

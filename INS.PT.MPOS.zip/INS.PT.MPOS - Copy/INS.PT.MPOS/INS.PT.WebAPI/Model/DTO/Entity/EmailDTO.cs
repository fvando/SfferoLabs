

// Copyright Ageas 2019 � - Integration Team

using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// Email object.
    /// </summary>
    
    public class EmailDto
    {
        /// <summary>
        /// Identifier.
        /// </summary>
        /// <value>Identifier.</value>
        
        [JsonProperty(PropertyName = "emailIdentifier")]
        public int? EmailIdentifier { get; set; }

        /// <summary>
        /// Email type code.
        /// </summary>
        /// <value>Email type code.</value>
        
        [JsonProperty(PropertyName = "emailTypeCode")]
        public string EmailTypeCode { get; set; }

        /// <summary>
        /// Email type description.
        /// </summary>
        /// <value>Email type description.</value>
        
        [JsonProperty(PropertyName = "emailTypeDescription")]
        public string EmailTypeDescription { get; set; }

        /// <summary>
        /// Address.
        /// </summary>
        /// <value>Address.</value>
        
        [JsonProperty(PropertyName = "emailAddress")]
        public string EmailAddress { get; set; }

        /// <summary>
        /// Flag to the preferred email.
        /// </summary>
        /// <value>Flag to the preferred email.</value>
        
        [JsonProperty(PropertyName = "isPreferred")]
        public bool? IsPreferred { get; set; }
    }
}

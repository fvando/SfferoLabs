

// Copyright Ageas 2019 � - Integration Team

using System.Collections.Generic;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.Entity
{
    /// <summary>
    /// 
    /// </summary>
    
    public class ContactListsDto
    {
        /// <summary>
        /// List of phones.
        /// </summary>
        /// <value>List of phones.</value>
        
        [JsonProperty(PropertyName = "phones")]
        public List<PhoneDto> Phones { get; set; }

        /// <summary>
        /// List of emails.
        /// </summary>
        /// <value>List of emails.</value>
        
        [JsonProperty(PropertyName = "emails")]
        public List<EmailDto> Emails { get; set; }
    }
}

using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.HighAvailability
{

    /// <summary>
    /// 
    /// </summary>
    
    public class EntityDTO
    { /// <summary>
      /// EntityId
      /// </summary>
      /// <value>EntityId</value>
        
        [JsonProperty(PropertyName = "entityId")]
        public string EntityId { get; set; }

        /// <summary>
        /// Nif
        /// </summary>
        /// <value>Nif</value>
        
        [JsonProperty(PropertyName = "nif")]
        public string Nif { get; set; }

        /// <summary>
        /// Client Name
        /// </summary>
        /// <value>Client Name</value>
        
        [JsonProperty(PropertyName = "clientName")]
        public string ClientName { get; set; }

        /// <summary>
        /// Client Surname
        /// </summary>
        /// <value>Client Surname</value>
        
        [JsonProperty(PropertyName = "clientSurname")]
        public string ClientSurname { get; set; }

        /// <summary>
        /// BirthDate
        /// </summary>
        /// <value>BirthDate</value>
        
        [JsonProperty(PropertyName = "birthDate")]
        public DateTime? BirthDate { get; set; }

        /// <summary>
        /// Phone
        /// </summary>
        /// <value>Phone</value>
        
        [JsonProperty(PropertyName = "phone")]
        public string Phone { get; set; }

        /// <summary>
        /// Email
        /// </summary>
        /// <value>Email</value>
        
        [JsonProperty(PropertyName = "email")]
        public string Email { get; set; }

        /// <summary>
        /// Postal Code
        /// </summary>
        /// <value>Postal Code</value>
        
        [JsonProperty(PropertyName = "postalCode")]
        public string PostalCode { get; set; }

        /// <summary>
        /// Gets or Sets StatusId
        /// </summary>
        
        [JsonProperty(PropertyName = "statusId")]
        public string StatusId { get; set; }

        /// <summary>
        /// Status Description
        /// </summary>
        /// <value>Status Description</value>
        
        [JsonProperty(PropertyName = "statusDescription")]
        public string StatusDescription { get; set; }

        /// <summary>
        /// descendantsNumber
        /// </summary>
        /// <value>descendantsNumber</value>
        
        [JsonProperty(PropertyName = "descendantsNumber")]
        public int? DescendantsNumber { get; set; }

        /// <summary>
        /// Gets or Sets GenderId
        /// </summary>
        
        [JsonProperty(PropertyName = "genderId")]
        public string GenderId { get; set; }

        /// <summary>
        /// Gender
        /// </summary>
        /// <value>Gender</value>
        
        [JsonProperty(PropertyName = "genderDescription")]
        public string GenderDescription { get; set; }

        /// <summary>
        /// Cae
        /// </summary>
        /// <value>Cae</value>
        
        [JsonProperty(PropertyName = "cae")]
        public string Cae { get; set; }

        /// <summary>
        /// Year of Incorporation Company
        /// </summary>
        /// <value>Year of Incorporation Company</value>
        
        [JsonProperty(PropertyName = "companyEstablishmentDate")]
        public DateTime? CompanyEstablishmentDate { get; set; }
    }
}

using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.HighAvailability
{

    /// <summary>
    /// 
    /// </summary>
    
    public class ClaimsDTO
    {
        /// <summary>
        /// Claim Number
        /// </summary>
        /// <value>Claim Number</value>
        
        [JsonProperty(PropertyName = "claimNumber")]
        public string ClaimNumber { get; set; }

        /// <summary>
        /// Policy Number
        /// </summary>
        /// <value>Policy Number</value>
        
        [JsonProperty(PropertyName = "policyNumber")]
        public string PolicyNumber { get; set; }

        /// <summary>
        /// Nif
        /// </summary>
        /// <value>Nif</value>
        
        [JsonProperty(PropertyName = "nif")]
        public string Nif { get; set; }

        /// <summary>
        /// Date of Occurrence
        /// </summary>
        /// <value>Date of Occurrence</value>
        
        [JsonProperty(PropertyName = "occurrenceDate")]
        public DateTime? OccurrenceDate { get; set; }

        /// <summary>
        /// Opening date
        /// </summary>
        /// <value>Opening date</value>
        
        [JsonProperty(PropertyName = "openDate")]
        public DateTime? OpenDate { get; set; }

        /// <summary>
        /// Closing date
        /// </summary>
        /// <value>Closing date</value>
        
        [JsonProperty(PropertyName = "closeDate")]
        public DateTime? CloseDate { get; set; }

        /// <summary>
        /// Situation Id
        /// </summary>
        /// <value>Situation Id</value>
        
        [JsonProperty(PropertyName = "situationId")]
        public string SituationId { get; set; }

        /// <summary>
        /// Gets or Sets SituationDescription
        /// </summary>
        
        [JsonProperty(PropertyName = "situationDescription")]
        public string SituationDescription { get; set; }

        /// <summary>
        /// Date Of Situation
        /// </summary>
        /// <value>Date Of Situation</value>
        
        [JsonProperty(PropertyName = "situationDate")]
        public DateTime? SituationDate { get; set; }

        /// <summary>
        /// Payments Total
        /// </summary>
        /// <value>Payments Total</value>
        
        [JsonProperty(PropertyName = "paymentsTotal")]
        public double? PaymentsTotal { get; set; }

        /// <summary>
        /// Reserve
        /// </summary>
        /// <value>Reserve</value>
        
        [JsonProperty(PropertyName = "reserve")]
        public double? Reserve { get; set; }

        /// <summary>
        /// Gets or Sets AuditCreationDate
        /// </summary>
        
        [JsonProperty(PropertyName = "auditCreationDate")]
        public DateTime? AuditCreationDate { get; set; }

        /// <summary>
        /// Update Date
        /// </summary>
        /// <value>Update Date</value>
        
        [JsonProperty(PropertyName = "auditUpdatedDate")]
        public DateTime? AuditUpdatedDate { get; set; }

    }
}

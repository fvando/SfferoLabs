using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.HighAvailability {

  /// <summary>
  /// 
  /// </summary>
  
  public class ReceiptsCommentsDTO
    {

    /// <summary>
    /// Receipt Number
    /// </summary>
    /// <value>Receipt Number</value>
    
    [JsonProperty(PropertyName = "receiptNumber")]
    public string ReceiptNumber { get; set; }

    /// <summary>
    /// Policy Number
    /// </summary>
    /// <value>Policy Number</value>
    
    [JsonProperty(PropertyName = "policyNumber")]
    public string PolicyNumber { get; set; }

    /// <summary>
    /// Nif
    /// </summary>
    /// <value>Nif</value>
    
    [JsonProperty(PropertyName = "nif")]
    public string Nif { get; set; }

    /// <summary>
    /// Company
    /// </summary>
    /// <value>Company</value>
    
    [JsonProperty(PropertyName = "company")]
    public string Company { get; set; }

    /// <summary>
    /// Amount Received
    /// </summary>
    /// <value>Amount Received</value>
    
    [JsonProperty(PropertyName = "amountReceipt")]
    public double? AmountReceipt { get; set; }

    /// <summary>
    /// Commission
    /// </summary>
    /// <value>Commission</value>
    
    [JsonProperty(PropertyName = "commission")]
    public double? Commission { get; set; }

    /// <summary>
    /// Tax
    /// </summary>
    /// <value>Tax</value>
    
    [JsonProperty(PropertyName = "tax")]
    public double? Tax { get; set; }

    /// <summary>
    /// Type Nature ID
    /// </summary>
    /// <value>Type Nature ID</value>
    
    [JsonProperty(PropertyName = "typeNatureId")]
    public string TypeNatureId { get; set; }

    /// <summary>
    /// Type Nature Description
    /// </summary>
    /// <value>Type Nature Description</value>
    
    [JsonProperty(PropertyName = "typeNatureDescription")]
    public string TypeNatureDescription { get; set; }

    /// <summary>
    /// Emission Date
    /// </summary>
    /// <value>Emission Date</value>
    
    [JsonProperty(PropertyName = "emissionDate")]
    public DateTime? EmissionDate { get; set; }

    /// <summary>
    /// Date Start
    /// </summary>
    /// <value>Date Start</value>
    
    [JsonProperty(PropertyName = "startDate")]
    public DateTime? StartDate { get; set; }

    /// <summary>
    /// Date of Maturity
    /// </summary>
    /// <value>Date of Maturity</value>
    
    [JsonProperty(PropertyName = "maturityDate")]
    public DateTime? MaturityDate { get; set; }

    /// <summary>
    /// Payment DueDate
    /// </summary>
    /// <value>Payment DueDate</value>
    
    [JsonProperty(PropertyName = "paymentDueDate")]
    public DateTime? PaymentDueDate { get; set; }

    /// <summary>
    /// Accountability Id
    /// </summary>
    /// <value>Accountability Id</value>
    
    [JsonProperty(PropertyName = "accountabilityId")]
    public string AccountabilityId { get; set; }

    /// <summary>
    /// Accountability Description
    /// </summary>
    /// <value>Accountability Description</value>
    
    [JsonProperty(PropertyName = "accountabilityDescription")]
    public string AccountabilityDescription { get; set; }

    /// <summary>
    /// Gets or Sets SituationId
    /// </summary>
    
    [JsonProperty(PropertyName = "situationId")]
    public string SituationId { get; set; }

    /// <summary>
    /// Situation Description
    /// </summary>
    /// <value>Situation Description</value>
    
    [JsonProperty(PropertyName = "situationDescription")]
    public string SituationDescription { get; set; }

    /// <summary>
    /// Date of Situation
    /// </summary>
    /// <value>Date of Situation</value>
    
    [JsonProperty(PropertyName = "situationDate")]
    public DateTime? SituationDate { get; set; }

    /// <summary>
    /// Methods of Payment ID
    /// </summary>
    /// <value>Methods of Payment ID</value>
    
    [JsonProperty(PropertyName = "methodsPaymentId")]
    public string MethodsPaymentId { get; set; }

    /// <summary>
    /// Methods of Payment Desctiption
    /// </summary>
    /// <value>Methods of Payment Desctiption</value>
    
    [JsonProperty(PropertyName = "methodsPaymentDescription")]
    public string MethodsPaymentDescription { get; set; }

    /// <summary>
    /// Agent Mediator
    /// </summary>
    /// <value>Agent Mediator</value>
    
    [JsonProperty(PropertyName = "agentMediatorId")]
    public string AgentMediatorId { get; set; }

    /// <summary>
    /// Agent Collector
    /// </summary>
    /// <value>Agent Collector</value>
    
    [JsonProperty(PropertyName = "agentCollectorId")]
    public string AgentCollectorId { get; set; }

    /// <summary>
    /// Channel ID
    /// </summary>
    /// <value>Channel ID</value>
    
    [JsonProperty(PropertyName = "channelId")]
    public string ChannelId { get; set; }

    /// <summary>
    /// Gets or Sets ChannelDescription
    /// </summary>
    
    [JsonProperty(PropertyName = "channelDescription")]
    public string ChannelDescription { get; set; }

    /// <summary>
    /// Bank Circuit
    /// </summary>
    /// <value>Bank Circuit</value>
    
    [JsonProperty(PropertyName = "bankCircuit")]
    public bool? BankCircuit { get; set; }

    /// <summary>
    /// Creation Date
    /// </summary>
    /// <value>Creation Date</value>
    
    [JsonProperty(PropertyName = "creationDate")]
    public DateTime? CreationDate { get; set; }

    /// <summary>
    /// Updated Date
    /// </summary>
    /// <value>Updated Date</value>
    
    [JsonProperty(PropertyName = "updatedDate")]
    public DateTime? UpdatedDate { get; set; }

}
}

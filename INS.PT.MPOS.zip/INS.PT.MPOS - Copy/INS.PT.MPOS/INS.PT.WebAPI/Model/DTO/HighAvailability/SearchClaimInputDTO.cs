using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.HighAvailability {

  /// <summary>
  /// 
  /// </summary>
  
  public class SearchClaimInputDTO {
    /// <summary>
    /// Date of Occurrence Initial
    /// </summary>
    /// <value>Date of Occurrence Initial</value>
    
    [JsonProperty(PropertyName = "occurrenceDateIni")]
    public DateTime? OccurrenceDateIni { get; set; }

    /// <summary>
    /// Date of Occurrence End
    /// </summary>
    /// <value>Date of Occurrence End</value>
    
    [JsonProperty(PropertyName = "occurrenceDateEnd")]
    public DateTime? OccurrenceDateEnd { get; set; }

    /// <summary>
    /// Date Open Initial
    /// </summary>
    /// <value>Date Open Initial</value>
    
    [JsonProperty(PropertyName = "openDateIni")]
    public DateTime? OpenDateIni { get; set; }

    /// <summary>
    /// Date Open End
    /// </summary>
    /// <value>Date Open End</value>
    
    [JsonProperty(PropertyName = "openDateEnd")]
    public DateTime? OpenDateEnd { get; set; }

    /// <summary>
    /// Date Close Initial
    /// </summary>
    /// <value>Date Close Initial</value>
    
    [JsonProperty(PropertyName = "closeDateIni")]
    public DateTime? CloseDateIni { get; set; }

    /// <summary>
    /// Date Close End
    /// </summary>
    /// <value>Date Close End</value>
    
    [JsonProperty(PropertyName = "closeDateEnd")]
    public DateTime? CloseDateEnd { get; set; }

    /// <summary>
    /// Situation ID
    /// </summary>
    /// <value>Situation ID</value>
    
    [JsonProperty(PropertyName = "situationID")]
    public string SituationID { get; set; }

    /// <summary>
    /// Situation Description
    /// </summary>
    /// <value>Situation Description</value>
    
    [JsonProperty(PropertyName = "situationDescription")]
    public string SituationDescription { get; set; }

    /// <summary>
    /// Date Situation Ini
    /// </summary>
    /// <value>Date Situation Ini</value>
    
    [JsonProperty(PropertyName = "situationDateIni")]
    public DateTime? SituationDateIni { get; set; }

    /// <summary>
    /// Date Situation End
    /// </summary>
    /// <value>Date Situation End</value>
    
    [JsonProperty(PropertyName = "situationDateEnd")]
    public DateTime? SituationDateEnd { get; set; }

    /// <summary>
    /// Lob Id
    /// </summary>
    /// <value>Lob Id</value>
    
    [JsonProperty(PropertyName = "lobId")]
    public string LobId { get; set; }

    /// <summary>
    /// Product Id
    /// </summary>
    /// <value>Product Id</value>
    
    [JsonProperty(PropertyName = "productId")]
    public string ProductId { get; set; }

    /// <summary>
    /// codeLevel
    /// </summary>
    /// <value>codeLevel</value>
    
    [JsonProperty(PropertyName = "codeLevel")]
    public string CodeLevel { get; set; }

    /// <summary>
    /// Level
    /// </summary>
    /// <value>Level</value>
    
    [JsonProperty(PropertyName = "level")]
    public string Level { get; set; }
   
    /// <summary>
    /// Order
    /// </summary>
    /// <value>Order</value>
    
    [JsonProperty(PropertyName = "order")]
    public OrderReferenceDataClaimDTO Order { get; set; }

    /// <summary>
    /// Paging
    /// </summary>
    /// <value>Paging</value>
    
    [JsonProperty(PropertyName = "paging")]
    public PagingDTO Paging { get; set; }

}
}

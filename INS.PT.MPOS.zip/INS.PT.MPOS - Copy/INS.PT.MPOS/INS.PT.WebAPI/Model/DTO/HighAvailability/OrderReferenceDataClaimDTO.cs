using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.HighAvailability {

  /// <summary>
  /// 
  /// </summary>
  
  public class OrderReferenceDataClaimDTO {
    /// <summary>
    /// Sort Field
    /// </summary>
    /// <value>Sort Field</value>
    
    [JsonProperty(PropertyName = "sortField")]
    public string SortField { get; set; }

    /// <summary>
    /// Sort Order
    /// </summary>
    /// <value>Sort Order</value>
    
    [JsonProperty(PropertyName = "sortOrder")]
    public string SortOrder { get; set; }

}
}

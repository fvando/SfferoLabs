﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.HighAvailability
{
    public class ResultsDTO<T>
    {
        /// <summary>Return data</summary>
        [JsonProperty("data")]
        public ICollection<T> Data { get; set; }

        /// <summary>Paging</summary>
        [JsonProperty("paging")]
        public PagingDTO Paging { get; set; }

        /// <summary>Errors</summary>
        [JsonProperty("errors")]
        public List<ErrorsDTO> Errors { get; set; }

    }
}

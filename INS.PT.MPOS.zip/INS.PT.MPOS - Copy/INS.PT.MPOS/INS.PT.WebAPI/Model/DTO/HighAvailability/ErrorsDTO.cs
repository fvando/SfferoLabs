﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.HighAvailability
{
    public class ErrorsDTO
    {
        /// <summary>Error Code</summary>
        /// <example>XXX</example>
        [JsonProperty("code", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string Code { get; set; }

        /// <summary>Error Descritpion</summary>
        /// <example>XXXX</example>
        [JsonProperty("descritpion", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string Descritpion { get; set; }
    }
}

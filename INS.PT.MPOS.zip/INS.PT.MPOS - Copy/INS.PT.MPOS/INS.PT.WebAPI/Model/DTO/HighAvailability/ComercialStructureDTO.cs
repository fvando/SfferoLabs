using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.HighAvailability {

    /// <summary>
    /// ComercialStructureDTO
    /// </summary>

    public class ComercialStructureDTO
    {
        /// <summary>
        /// Identifation ComercialStructure
        /// </summary>
        /// <value>Identifation ComercialStructure</value>
        
        [JsonProperty(PropertyName = "comercialStructureId")]
        public string ComercialStructureId { get; set; }

        /// <summary>
        /// Gets or Sets Company
        /// </summary>
        
        [JsonProperty(PropertyName = "company")]
        public string Company { get; set; }

        /// <summary>
        /// Gets or Sets NetworkCode
        /// </summary>
        
        [JsonProperty(PropertyName = "networkCode")]
        public string NetworkCode { get; set; }

        /// <summary>
        /// Gets or Sets NetworkName
        /// </summary>
        
        [JsonProperty(PropertyName = "networkName")]
        public string NetworkName { get; set; }

        /// <summary>
        /// Gets or Sets ZoneCode
        /// </summary>
        
        [JsonProperty(PropertyName = "zoneCode")]
        public string ZoneCode { get; set; }

        /// <summary>
        /// Gets or Sets ZoneName
        /// </summary>
        
        [JsonProperty(PropertyName = "zoneName")]
        public string ZoneName { get; set; }

        /// <summary>
        /// Branch Code
        /// </summary>
        /// <value>Branch Code</value>
        
        [JsonProperty(PropertyName = "branchCode")]
        public string BranchCode { get; set; }

        /// <summary>
        /// Branch Name
        /// </summary>
        /// <value>Branch Name</value>
        
        [JsonProperty(PropertyName = "branchName")]
        public string BranchName { get; set; }

        /// <summary>
        /// Inspector Code
        /// </summary>
        /// <value>Inspector Code</value>
        
        [JsonProperty(PropertyName = "inspectorCode")]
        public string InspectorCode { get; set; }

        /// <summary>
        /// Inspector EntityId
        /// </summary>
        /// <value>Inspector EntityId</value>
        
        [JsonProperty(PropertyName = "inspectorEntityId")]
        public string InspectorEntityId { get; set; }

        /// <summary>
        /// Agent Code
        /// </summary>
        /// <value>Agent Code</value>
        
        [JsonProperty(PropertyName = "agentCode")]
        public string AgentCode { get; set; }

        /// <summary>
        /// AgentEntityId
        /// </summary>
        /// <value>AgentEntityId</value>
        
        [JsonProperty(PropertyName = "agentEntityId")]
        public string AgentEntityId { get; set; }

        /// <summary>
        /// ASFNumber
        /// </summary>
        /// <value>ASFNumber</value>
        
        [JsonProperty(PropertyName = "asfNumber")]
        public string ASFNumber { get; set; }
    }
}

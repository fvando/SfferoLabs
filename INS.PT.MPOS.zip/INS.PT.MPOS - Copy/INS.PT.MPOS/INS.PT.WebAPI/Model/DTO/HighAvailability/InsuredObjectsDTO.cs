using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.HighAvailability {

    /// <summary>
    /// InsuredObjectDTO
    /// </summary>

    public class InsuredObjectDTO
    {
        /// <summary>
        /// Gets or Sets InsuredObjectId
        /// </summary>
        
        [JsonProperty(PropertyName = "insuredObjectId")]
        public int InsuredObjectId { get; set; }

        /// <summary>
        /// Policy Number
        /// </summary>
        /// <value>Policy Number</value>
        
        [JsonProperty(PropertyName = "policyNumber")]
        public string PolicyNumber { get; set; }

        /// <summary>
        /// Gets or Sets InsuredObjectDescription
        /// </summary>
        
        [JsonProperty(PropertyName = "insuredObjectDescription")]
        public string InsuredObjectDescription { get; set; }
    }
}

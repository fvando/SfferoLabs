using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.HighAvailability
{

    /// <summary>
    /// 
    /// </summary>
    
    public class SearchWalletMovementInputDTO
    {
        /// <summary>
        /// Movement
        /// </summary>
        /// <value>Movement</value>
        
        [JsonProperty(PropertyName = "codeMovement")]
        public string CodeMovement { get; set; }

        /// <summary>
        /// Company
        /// </summary>
        /// <value>Company</value>
        
        [JsonProperty(PropertyName = "company")]
        public string Company { get; set; }

        /// <summary>
        /// Event Identify
        /// </summary>
        /// <value>Event Identify</value>
        
        [JsonProperty(PropertyName = "eventIdentify")]
        public string EventIdentify { get; set; }

    /// <summary>
    /// Date Movement Initial
    /// </summary>
    /// <value>Date Movement Initial</value>
    
    [JsonProperty(PropertyName = "movementDateIni")]
    public DateTime? MovementDateIni { get; set; }

    /// <summary>
    /// Date Movement End
    /// </summary>
    /// <value>Date Movement End</value>
    
    [JsonProperty(PropertyName = "movementDateEnd")]
    public DateTime? MovementDateEnd { get; set; }

        /// <summary>
        /// Nif
        /// </summary>
        /// <value>Nif</value>
        
        [JsonProperty(PropertyName = "nif")]
        public string Nif { get; set; }

        /// <summary>
        /// SituationId
        /// </summary>
        /// <value>SituationId</value>
        
        [JsonProperty(PropertyName = "situationId")]
        public string SituationId { get; set; }

        /// <summary>
        /// CodeLevel
        /// </summary>
        /// <value>CodeLevel</value>
        
        [JsonProperty(PropertyName = "codeLevel")]
        public string CodeLevel { get; set; }

        /// <summary>
        /// Level
        /// </summary>
        /// <value>Level</value>
        
        [JsonProperty(PropertyName = "level")]
        public string Level { get; set; }

        /// <summary>
        /// Order
        /// </summary>
        /// <value>Order</value>
        
        [JsonProperty(PropertyName = "order")]
        public OrderReferenceDataWalletMovementDTO Order { get; set; }

        /// <summary>
        /// Paging
        /// </summary>
        /// <value>Paging</value>
        
        [JsonProperty(PropertyName = "paging")]
        public PagingDTO Paging { get; set; }
    }
}

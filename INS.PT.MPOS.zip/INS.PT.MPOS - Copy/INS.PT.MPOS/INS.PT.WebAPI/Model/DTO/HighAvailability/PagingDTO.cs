using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.HighAvailability
{

    /// <summary>
    /// 
    /// </summary>
    
    public class PagingDTO
    {
        /// <summary>
        /// Page size
        /// </summary>
        /// <value>Page size</value>
        
        [JsonProperty(PropertyName = "pageSize")]
        public int? PageSize { get; set; } = 10;

        /// <summary>
        /// Page number
        /// </summary>
        /// <value>Page number</value>
        
        [JsonProperty(PropertyName = "pageNumber")]
        public int? PageNumber { get; set; } = 1;

        /// <summary>
        /// Total of items
        /// </summary>
        /// <value>Total of items</value>
        
        [JsonProperty(PropertyName = "totalItemCount")]
        public int? TotalItemCount { get; set; }
    }
}

using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.HighAvailability
{

    /// <summary>
    /// 
    /// </summary>
    
    public class IndicatorsInputDTO
    {
        /// <summary>
        /// CodeLevel
        /// </summary>
        /// <value>CodeLevel</value>
        
        [JsonProperty(PropertyName = "codeLevel")]
        public string CodeLevel { get; set; }

        /// <summary>
        /// Level
        /// </summary>
        /// <value>Level</value>
        
        [JsonProperty(PropertyName = "level")]
        public string Level { get; set; }

    }
}

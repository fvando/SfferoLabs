﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Models.DTO.HighAvailability
{
    /// <summary>
    /// OrderReferenceDataComercialStructureDTO
    /// </summary>
    public class OrderReferenceDataComercialStructureDTO
    {
        /// <summary>
        /// Sort Field
        /// </summary>
        /// <value>Sort Field</value>
        [JsonProperty(PropertyName = "sortField")]
        public string SortField { get; set; }

        /// <summary>
        /// Sort Order
        /// </summary>
        /// <value>Sort Order</value>
        [JsonProperty(PropertyName = "sortOrder")]
        public string SortOrder { get; set; }
    }
}

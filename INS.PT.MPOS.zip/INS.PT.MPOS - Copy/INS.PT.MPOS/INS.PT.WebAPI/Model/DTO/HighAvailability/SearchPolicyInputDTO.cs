using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.HighAvailability
{
    /// <summary>
    /// 
    /// </summary>
    
    public class SearchPolicyInputDTO{
    /// <summary>
    /// Date Situation Initial
    /// </summary>
    /// <value>Date Situation Initial</value>
    
    [JsonProperty(PropertyName = "situationDateIni")]
    public DateTime? SituationDateIni { get; set; }

    /// <summary>
    /// Date Situation End
    /// </summary>
    /// <value>Date Situation End</value>
    
    [JsonProperty(PropertyName = "situationDateEnd")]
    public DateTime? SituationDateEnd { get; set; }

    /// <summary>
    /// Identification of Agent
    /// </summary>
    /// <value>Identification of Agent</value>
    
    [JsonProperty(PropertyName = "agentID")]
    public string AgentID { get; set; }

    /// <summary>
    /// codeLevel
    /// </summary>
    /// <value>codeLevel</value>
    
    [JsonProperty(PropertyName = "codeLevel")]
    public string CodeLevel { get; set; }

    /// <summary>
    /// Level
    /// </summary>
    /// <value>Level</value>
    
    [JsonProperty(PropertyName = "level")]
    public string Level { get; set; }

    /// <summary>
    /// Company
    /// </summary>
    /// <value>Company</value>
    
    [JsonProperty(PropertyName = "company")]
    public string Company { get; set; }

    /// <summary>
    /// Situation ID
    /// </summary>
    /// <value>Situation ID</value>
    
    [JsonProperty(PropertyName = "situationId")]
    public string SituationId { get; set; }

    /// <summary>
    /// Maturity Date Ini
    /// </summary>
    /// <value>Maturity Date Ini</value>
    
    [JsonProperty(PropertyName = "maturityDateIni")]
    public DateTime? MaturityDateIni { get; set; }

    /// <summary>
    /// Maturity Date End
    /// </summary>
    /// <value>Maturity Date End</value>
    
    [JsonProperty(PropertyName = "maturityDateEnd")]
    public DateTime? MaturityDateEnd { get; set; }

    /// <summary>
    /// PaymentDate Ini
    /// </summary>
    /// <value>PaymentDate Ini</value>
    
    [JsonProperty(PropertyName = "paymentDateIni")]
    public DateTime? PaymentDateIni { get; set; }

    /// <summary>
    /// PaymentDate End
    /// </summary>
    /// <value>PaymentDate End</value>
    
    [JsonProperty(PropertyName = "paymentDateEnd")]
    public DateTime? PaymentDateEnd { get; set; }

    /// <summary>
    /// Start Date Ini
    /// </summary>
    /// <value>Start Date Ini</value>
    
    [JsonProperty(PropertyName = "startDateIni")]
    public DateTime? StartDateIni { get; set; }

    /// <summary>
    /// Start Date End
    /// </summary>
    /// <value>Start Date End</value>
    
    [JsonProperty(PropertyName = "startDateEnd")]
    public DateTime? StartDateEnd { get; set; }

    /// <summary>
    /// MethodsPayment ID
    /// </summary>
    /// <value>MethodsPayment ID</value>
    
    [JsonProperty(PropertyName = "methodsPaymentId")]
    public string MethodsPaymentId { get; set; }

    /// <summary>
    /// Product Id
    /// </summary>
    /// <value>Product Id</value>
    
    [JsonProperty(PropertyName = "productId")]
    public string ProductId { get; set; }

    /// <summary>
    /// Lob Id
    /// </summary>
    /// <value>Lob Id</value>
    
    [JsonProperty(PropertyName = "lobId")]
    public string LobId { get; set; }

    /// <summary>
    /// Claim Number
    /// </summary>
    /// <value>Claim Number</value>
    
    [JsonProperty(PropertyName = "claimNumber")]
    public string ClaimNumber { get; set; }

        /// <summary>
        /// Order
        /// </summary>
        /// <value>Order</value>
        
        [JsonProperty(PropertyName = "order")]
        public OrderReferenceDataPolicyDTO Order { get; set; }

        /// <summary>
        /// Paging
        /// </summary>
        /// <value>Paging</value>
        
        [JsonProperty(PropertyName = "paging")]
        public PagingDTO Paging { get; set; }
    }
}

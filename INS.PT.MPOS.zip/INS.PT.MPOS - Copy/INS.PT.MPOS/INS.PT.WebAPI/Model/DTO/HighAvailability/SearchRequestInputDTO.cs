using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.HighAvailability
{

    /// <summary>
    /// 
    /// </summary>
    
    public class SearchRequestInputDTO
    {
        /// <summary>
        /// NIF
        /// </summary>
        /// <value>NIF</value>
        
        [JsonProperty(PropertyName = "nif")]
        public string Nif { get; set; }

        /// <summary>
        /// Internal Number
        /// </summary>
        /// <value>Internal Number</value>
        
        [JsonProperty(PropertyName = "internalNumber")]
        public string InternalNumber { get; set; }

        /// <summary>
        /// External Number
        /// </summary>
        /// <value>External Number</value>
        
        [JsonProperty(PropertyName = "externalNumber")]
        public string ExternalNumber { get; set; }

        /// <summary>
        /// Creation Date Initial
        /// </summary>
        /// <value>Creation Date Initial</value>
        
        [JsonProperty(PropertyName = "creationStartDate")]
        public DateTime? CreationDateIni { get; set; }

        /// <summary>
        /// Creation Date End
        /// </summary>
        /// <value>Creation Date End</value>
        
        [JsonProperty(PropertyName = "creationEndDate")]
        public DateTime? CreationDateEnd { get; set; }

        /// <summary>
        /// Policy Number
        /// </summary>
        /// <value>Policy Number</value>
        
        [JsonProperty(PropertyName = "policyNumber")]
        public string PolicyNumber { get; set; }

        /// <summary>
        /// Claim Number
        /// </summary>
        /// <value>Claim Number</value>
        
        [JsonProperty(PropertyName = "claimNumber")]
        public string ClaimNumber { get; set; }

        /// <summary>
        /// Agent Id
        /// </summary>
        /// <value>Agent Id</value>
        
        [JsonProperty(PropertyName = "agentId")]
        public string AgentId { get; set; }

        /// <summary>
        /// Task
        /// </summary>
        /// <value>Task</value>
        
        [JsonProperty(PropertyName = "task")]
        public string Task { get; set; }

        /// <summary>
        /// StatusId Id
        /// </summary>
        /// <value>StatusId Id</value>
        
        [JsonProperty(PropertyName = "statusId")]
        public string StatusId { get; set; }

        /// <summary>
        /// codeLevel
        /// </summary>
        /// <value>codeLevel</value>
        
        [JsonProperty(PropertyName = "codeLevel")]
        public string CodeLevel { get; set; }

        /// <summary>
        /// Level
        /// </summary>
        /// <value>Level</value>
        
        [JsonProperty(PropertyName = "level")]
        public string Level { get; set; }

        /// <summary>
        /// Order
        /// </summary>
        /// <value>Order</value>
        
        [JsonProperty(PropertyName = "order")]
        public OrderReferenceDataRequestDTO Order { get; set; }

        /// <summary>
        /// Paging
        /// </summary>
        /// <value>Paging</value>
        
        [JsonProperty(PropertyName = "paging")]
        public PagingDTO Paging { get; set; }
    }
}

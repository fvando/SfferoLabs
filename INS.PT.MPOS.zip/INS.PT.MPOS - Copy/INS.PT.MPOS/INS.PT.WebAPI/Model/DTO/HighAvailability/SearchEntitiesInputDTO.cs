using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace INS.PT.WebAPI.Models.DTO.HighAvailability {

    
    public class SearchEntitiesInputDTO
    {
        /// <summary>
        /// BirthDate Initial
        /// </summary>
        /// <value>BirthDate Initial</value>
        
        [JsonProperty(PropertyName = "birthDateIni")]
        public DateTime? BirthDateIni { get; set; }

        /// <summary>
        /// BirthDate End
        /// </summary>
        /// <value>BirthDate End</value>
        
        [JsonProperty(PropertyName = "birthDateEnd")]
        public DateTime? BirthDateEnd { get; set; }

        /// <summary>
        /// codeLevel
        /// </summary>
        /// <value>codeLevel</value>
        
        [JsonProperty(PropertyName = "codeLevel")]
        public string CodeLevel { get; set; }

        /// <summary>
        /// Level
        /// </summary>
        /// <value>Level</value>
        
        [JsonProperty(PropertyName = "level")]
        public string Level { get; set; }

        /// <summary>
        /// Email
        /// </summary>
        /// <value>Email</value>
        
        [JsonProperty(PropertyName = "email")]
        public string Email { get; set; }

        /// <summary>
        /// Phone Number
        /// </summary>
        /// <value>Phone Number</value>
        
        [JsonProperty(PropertyName = "phone")]
        public string Phone { get; set; }

        /// <summary>
        /// Status Id
        /// </summary>
        /// <value>Status Id</value>
        
        [JsonProperty(PropertyName = "statusId")]
        public string StatusId { get; set; }

        /// <summary>
        /// Descendants Number
        /// </summary>
        /// <value>Descendants Number</value>
        
        [JsonProperty(PropertyName = "DescendantsNumber")]
        public int DescendantsNumber { get; set; }

        /// <summary>
        /// Gender
        /// </summary>
        /// <value>Gender</value>
        
        [JsonProperty(PropertyName = "genderId")]
        public string GenderId { get; set; }

        /// <summary>
        /// Cae
        /// </summary>
        /// <value>Cae</value>
        
        [JsonProperty(PropertyName = "cae")]
        public string Cae { get; set; }

        /// <summary>
        /// Year of Incorporation Company Ini
        /// </summary>
        /// <value>Year of Incorporation Company Ini</value>
        
        [JsonProperty(PropertyName = "companyEstablishmentDateIni")]
        public DateTime? CompanyEstablishmentDateIni { get; set; }

        /// <summary>
        /// Year of Incorporation Company End
        /// </summary>
        /// <value>Year of Incorporation Company End</value>
        
        [JsonProperty(PropertyName = "companyEstablishmentDateEnd")]
        public DateTime? CompanyEstablishmentDateEnd { get; set; }

        /// <summary>
        /// Products
        /// </summary>
        /// <value>Products</value>
        
        [JsonProperty(PropertyName = "products")]
        public bool Products { get; set; }

        /// <summary>
        /// Premium Initial
        /// </summary>
        /// <value>Premium Initial</value>
        
        [JsonProperty(PropertyName = "premiumIni")]
        public double PremiumIni { get; set; }

        /// <summary>
        /// Premium End
        /// </summary>
        /// <value>Premium End</value>
        
        [JsonProperty(PropertyName = "premiumEnd")]
        public double PremiumEnd { get; set; }

        /// <summary>
        /// Receipts Issued
        /// </summary>
        /// <value>Receipts Issued</value>
        
        [JsonProperty(PropertyName = "receiptsIssued")]
        public bool ReceiptsIssued { get; set; }

        /// <summary>
        /// Entities with annulled policies
        /// </summary>
        /// <value>Entities with annulled policies</value>
        
        [JsonProperty(PropertyName = "annulledPolicies")]
        public bool AnnulledPolicies { get; set; }

        /// <summary>
        /// Entities with one policy
        /// </summary>
        /// <value>Entities with one policy</value>
        
        [JsonProperty(PropertyName = "MonoPolicy")]
        public bool MonoPolicy { get; set; }

        /// <summary>
        /// Entities without Email
        /// </summary>
        /// <value>Entities without Email</value>
        
        [JsonProperty(PropertyName = "withoutMail")]
        public bool WithoutMail { get; set; }

        /// <summary>
        /// Entities without Phone
        /// </summary>
        /// <value>Entities without Phone</value>
        
        [JsonProperty(PropertyName = "withoutPhone")]
        public bool WithoutPhone { get; set; }

        /// <summary>
        /// Entities without Digital Signature
        /// </summary>
        /// <value>Entities without Digital Signature</value>
        
        [JsonProperty(PropertyName = "withoutDigitalSignature")]
        public bool WithoutDigitalSignature { get; set; }

        /// <summary>
        /// Order
        /// </summary>
        /// <value>Order</value>
        
        [JsonProperty(PropertyName = "order")]
        public OrderReferenceDataEntitiesDTO Order { get; set; }

        /// <summary>
        /// Paging
        /// </summary>
        /// <value>Paging</value>
        
        [JsonProperty(PropertyName = "paging")]
        public PagingDTO Paging { get; set; }
        
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Models.Common;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Exceptions
{
    public class BusinessException : BaseException
    {
        public BusinessException()
        {

        }

        public BusinessException(HttpStatusCode statusCode, string errorDescription)
        {
            var error = new Error
            {
                Code = ((int)statusCode).ToString(CultureInfo.CurrentCulture),
                Descritpion = errorDescription
            };
            Errors.Add(error);
            StatusCode = statusCode;
        }

        public BusinessException(HttpStatusCode statusCode, string errorDescription, Exception exc)
        {
            var error = new Error
            {
                Code = ((int)statusCode).ToString(CultureInfo.CurrentCulture),
                Descritpion = errorDescription
            };
            Errors.Add(error);
            StatusCode = statusCode;
        }
    }
}

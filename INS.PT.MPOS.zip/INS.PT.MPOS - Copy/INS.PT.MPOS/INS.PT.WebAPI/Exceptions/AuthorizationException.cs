﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Models.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace INS.PT.WebAPI.Exceptions
{
    public class AuthorizationException : BaseException
    {
        public AuthorizationException()
        {

        }
        public AuthorizationException(HttpStatusCode statusCode, string errorDescription)
        {
            var error = new Error();
            error.Code = ((int)statusCode).ToString();
            error.Descritpion = errorDescription;
            Errors.Add(error);
            StatusCode = statusCode;
        }
    }
}

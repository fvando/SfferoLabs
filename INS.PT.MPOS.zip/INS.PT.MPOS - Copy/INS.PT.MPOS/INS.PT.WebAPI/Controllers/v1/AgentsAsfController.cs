﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.Threading.Tasks;
using INS.PT.CommonLibrary.Redis.Interfaces;
using INS.PT.WebAPI.Interface.V1;
using INS.PT.WebAPI.Model.v1;
using INS.PT.WebAPI.v1;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using static INS.PT.WebAPI.Model.v1.AgentsAsf;

namespace INS.PT.WebAPI.Controllers.V1
{
    [Route("v1/AsfAgents")]
    [ApiController]
    public class AgentsAsfController : BaseCore
    {
        private readonly IAgentsAsfRepository agentsAsfRepository;
        private readonly IEntitiesRepository entityRepository;
        private readonly IRedisManager redisManager;


        /// <summary>
        /// Initializes a new instance of the <see cref="AgentsAsfController"/> class.
        /// </summary>
        /// <param name="_agentsAsfRepository">The agents asf repository.</param>
        /// <param name="_entityRepository">The entity repository.</param>
        /// <param name="_httpContext">The HTTP context.</param>
        /// <param name="_redisManager">The redis manager.</param>
        public AgentsAsfController(IAgentsAsfRepository _agentsAsfRepository, IEntitiesRepository _entityRepository,
            IHttpContextAccessor _httpContext, IRedisManager _redisManager) : base(_httpContext)
        {
            agentsAsfRepository = _agentsAsfRepository;
            entityRepository = _entityRepository;
            redisManager = _redisManager;
        }

        /// <summary>
        /// Gets this instance.
        /// </summary>
        /// <returns></returns>

        [Authorize]
        [HttpGet(Name = "AsfAgents")]
        [Produces("application/json")]
        [Consumes("application/json")]
        [ProducesResponseType(typeof(OutputAgentsAsf), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<OutputAgentsAsf>> Get()
        {
            //Ini AsfAgents
            try
            {
                //Orchestration
                OutputAgentsAsf output = await agentsAsfRepository.OrchestrationAsync(Request);

                return Ok(output);
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError);
                return NotFound(processError);
            }
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception e)
            {
                Log.Error(e);
                throw;
            }
            finally
            {
                Log.Debug($"Finish AsfAgents");
            }

        }
    }
}

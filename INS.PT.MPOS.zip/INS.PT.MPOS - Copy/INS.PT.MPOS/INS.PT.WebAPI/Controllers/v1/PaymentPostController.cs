﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface.V1;
using INS.PT.WebAPI.Model.PaymentPost.v1;
using INS.PT.WebAPI.Model.v1;
using INS.PT.WebAPI.v1;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


namespace INS.PT.WebAPI.Controllers.V1
{
    /// <summary>
    /// PaymentPostController : BaseCore
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.v1.BaseCore" />
    [Route("v1/PaymentPost")]
    [ApiController]
    public class PaymentPostController : BaseCore 
    {
      
        private readonly IPaymentPostRepository _PaymentPostRepository;
        private readonly IContextRepository _contextRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentPostController"/> class.
        /// </summary>
        /// <param name="paymentPostRepository">The payment post repository.</param>
        /// <param name="httpContext">The HTTP context.</param>
        /// <param name="contextRepository">The context repository.</param>
        public PaymentPostController(IPaymentPostRepository paymentPostRepository, 
            IHttpContextAccessor httpContext, IContextRepository contextRepository) : base(httpContext)
        {
            _PaymentPostRepository = paymentPostRepository;
            _contextRepository = contextRepository;
        }

        /// <summary>
        /// Posts the specified valueout. ZFscdMposPostWsRequest
        /// </summary>
        /// <param name="valueout">The valueout.</param>
        /// <returns></returns>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=MPOS_tst_examples#PaymentPost
        /// </remarks>
        /// <exception cref="ProcessErrorException">Not Found</exception>
        /// <exception cref="ProcessErrorException.InnerError"></exception>
        //[Authorize]
        [HttpPost(Name = "PaymentPost")]
        [Produces("application/json")]
        [Consumes("application/json")]
        [ProducesResponseType(typeof(OutPutPaymentPost), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]

        public async Task<ActionResult<OutPutPaymentPost>> Post([FromBody] Model.PaymentPost.v1.InputPaymentPost valueout)
        {
            try
            {
                var _response = await _PaymentPostRepository.GetPaymentPostAsync(valueout, Request);
                return Ok(_response);
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError);
                return BadRequest(processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception ex)
            {
                //creates a 500
                Log.Error(ex);
                throw;
            }
            finally
            {
                Log.Debug($"Finish");
            }


        }

    }
}

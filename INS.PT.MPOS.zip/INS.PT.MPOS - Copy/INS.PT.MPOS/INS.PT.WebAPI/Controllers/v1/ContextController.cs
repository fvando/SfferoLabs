﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.Reflection;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface.V1;
using INS.PT.WebAPI.Model.v1;
using log4net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using INS.PT.WebAPI.Model.Context.v1;
using INS.PT.WebAPI.v1;

namespace INS.PT.WebAPI.Controllers.V1
{
    /// <summary>
    /// ContextController : BaseCore
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.v1.BaseCore" />
    [Route("v1/Context/[action]")]
    [ApiController]
    public class ContextController : BaseCore
    {
        private readonly ILog _log;
        private readonly IContextRepository _contextRepository;


        /// <summary>
        /// Initializes a new instance of the <see cref="ContextController"/> class.
        /// </summary>
        /// <param name="httpContext">The HTTP context.</param>
        /// <param name="contextRepository">The context repository.</param>
        public ContextController(IHttpContextAccessor httpContext, 
            IContextRepository contextRepository) : base(httpContext)
        {
            _log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            _contextRepository = contextRepository;
        }

      
        [Authorize]
        [HttpGet(Name = "TokenValidate")]
        [Produces("application/json")]
        [Consumes("application/json")]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<bool>> TokenValidate()
        {
            try
            {
                //Orchestration
                bool output = await _contextRepository.GetTokenValidateAsync(Request);
                return Ok(output);
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError);
                return NotFound(processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception ex)
            {
                //creates a 500
                Log.Error(ex);
                throw;
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }


        [Authorize]
        [HttpPut(Name = "UserLock")]
        [Produces("application/json")]
        [Consumes("application/json")]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<bool>> UserLock([FromBody] InputUserLock requestValue)
        {
            try
            {
                bool output = await _contextRepository.PutLockUserAsync(Request, requestValue);
                return Ok(output);
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError);
                return NotFound(processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception ex)
            {
                //creates a 500
                Log.Error(ex);
                throw;
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }
    }
}

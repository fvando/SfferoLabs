﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface.V1;
using INS.PT.WebAPI.Model.v1;
using INS.PT.WebAPI.Model.Kpi.v1;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using INS.PT.WebAPI.v1;
using Microsoft.AspNetCore.Authorization;

namespace INS.PT.WebAPI.Controllers.V1
{
    /// <summary>
    /// KpiController : BaseCore
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.v1.BaseCore" />
    [Route("v1/KPI")]
    [ApiController]
    public class KpiController : BaseCore
    {
        /// <summary>
        /// The kpi repository
        /// </summary>
        private readonly IKpiRepository _kpiRepository;
        private readonly IContextRepository _contextRepository;


        /// <summary>
        /// Initializes a new instance of the <see cref="KpiController"/> class.
        /// </summary>
        /// <param name="kpiRepository">The kpi repository.</param>
        /// <param name="httpContext">The HTTP context.</param>
        /// <param name="contextRepository">The context repository.</param>
        public KpiController(IKpiRepository kpiRepository, IHttpContextAccessor httpContext, 
            IContextRepository contextRepository) : base(httpContext)
        {
            _kpiRepository = kpiRepository;
            _contextRepository = contextRepository;
        }

        /// <summary>
        /// Posts the specified value.
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=MPOS_tst_examples#Kpi
        /// </remarks>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">Not Found</exception>
        /// <exception cref="ProcessErrorException.InnerError"></exception>
        [Authorize]
        [HttpPost(Name = "KPI")]
        [Produces("application/json")]
        [Consumes("application/json")]
        [ProducesResponseType(typeof(OutPutKpi), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<OutPutKpi>> Post([FromBody] Model.Kpi.v1.InputKpi value)
        {
            try
            {
                Model.Kpi.v1.OutPutKpi _response = null;
                bool output = await _contextRepository.GetTokenValidateAsync(Request);
                if (output)
                {
                    _response = await _kpiRepository.GetKpiAsync(value);
                }
                return Ok(_response);
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError);
                return NotFound(processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception ex)
            {
                //creates a 500
                Log.Error(ex);
                throw;
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }

    }
}

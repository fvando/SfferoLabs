﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface.V1;
using INS.PT.WebAPI.Model;
using INS.PT.WebAPI.Model.ReceiptDetail;
using INS.PT.WebAPI.Model.ReceiptDetail.v1;
using INS.PT.WebAPI.Model.v1;
using INS.PT.WebAPI.v1;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


namespace INS.PT.WebAPI.Controllers.V1
{

    /// <summary>
    /// ReceiptDetailsController : BaseCore
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.v1.BaseCore" />
    [Route("v1/ReceiptDetails")]
    [ApiController]
    public class ReceiptDetailsController : BaseCore 
    {
 
        private readonly IReceiptDetailsRepository _receiptDetailsRepository;
        private readonly IContextRepository _contextRepository;


        /// <summary>
        /// Initializes a new instance of the <see cref="ReceiptDetailsController"/> class.
        /// </summary>
        /// <param name="receiptDetailsRepository">The receipt details repository.</param>
        /// <param name="httpContext">The HTTP context.</param>
        /// <param name="contextRepository">The context repository.</param>
        public ReceiptDetailsController(IReceiptDetailsRepository receiptDetailsRepository, 
            IHttpContextAccessor httpContext, IContextRepository contextRepository) : base(httpContext)
        {
            _receiptDetailsRepository = receiptDetailsRepository;
            _contextRepository = contextRepository;
        }

        /// <summary>Posts the specified valueout. ZFscdMposKpisReceiptWsRequest </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=MPOS_tst_examples#receiptDetails
        /// </remarks>
        /// <param name="valueout">The valueout.</param>
        /// <returns></returns>
        [Authorize]
        [HttpPost(Name = "ReceiptDetails")]
        [Produces("application/json")]
        [Consumes("application/json")]
        [ProducesResponseType(typeof(OutPutReceiptDetail), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]

        public async Task<ActionResult<OutPutReceiptDetail>> Post([FromBody] Model.ReceiptDetail.v1.InputReceiptDetail valueout)
        {
            try
            {
                Model.ReceiptDetail.v1.OutPutReceiptDetail _response = null;
                bool output = await _contextRepository.GetTokenValidateAsync(Request);
                if (output)
                {
                    _response = await _receiptDetailsRepository.GetReceiptsDetailAsync(valueout);
                }
                return Ok(_response);
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError);
                return NotFound(processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception ex)
            {
                //creates a 500
                Log.Error(ex);
                throw;
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface.V1;
using INS.PT.WebAPI.Model.v1;
using INS.PT.WebAPI.Model.SearchReceipt.v1;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using INS.PT.WebAPI.v1;

namespace INS.PT.WebAPI.Controllers.V1
{
    /// <summary>
    /// SearchReceiptsController : BaseCore 
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.v1.BaseCore" />
    [Route("v1/SearchReceipts")]
    [ApiController]
    public class SearchReceiptsController : BaseCore 
    {
        /// <summary>
        /// The search receipts repository
        /// </summary>
        private readonly ISearchReceiptsRepository _searchReceiptsRepository;
        private readonly IContextRepository _contextRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="SearchReceiptsController"/> class.
        /// </summary>
        /// <param name="searchReceiptsRepository">The search receipts repository.</param>
        /// <param name="httpContext">The HTTP context.</param>
        /// <param name="contextRepository">The context repository.</param>
        public SearchReceiptsController(ISearchReceiptsRepository searchReceiptsRepository, 
            IHttpContextAccessor httpContext, IContextRepository contextRepository) : base(httpContext)
        {
            _searchReceiptsRepository = searchReceiptsRepository;
            _contextRepository = contextRepository;
        }

        /// <summary>
        /// Posts the specified valueout. ZFscdMposSearchWsRequest
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=MPOS_tst_examples#searchReceipts
        /// </remarks>
        /// <param name="valueout">The valueout.</param>
        /// <returns></returns>
        [Authorize]
        [HttpPost(Name = "SearchReceipts")]
        [Produces("application/json")]
        [Consumes("application/json")]
        [ProducesResponseType(typeof(OutPutSearchReceipt), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<OutPutSearchReceipt>> Post([FromBody] InputSearchReceipt valueout)
        {
            try
            {
                Model.SearchReceipt.v1.OutPutSearchReceipt _response = null;
                bool output = await _contextRepository.GetTokenValidateAsync(Request);
                if (output)
                {
                    _response = await _searchReceiptsRepository.GetSearchReceiptsAsync(valueout);
                }
                return Ok(_response);
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError);
                return NotFound(processError);
            }
            //Represent one or more errors that occur during application execution.
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception ex)
            {
                //creates a 500
                Log.Error(ex);
                throw;
            }
            finally
            {
                Log.Debug($"Finish");
            }


        }

    }
}

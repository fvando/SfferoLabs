﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface.V1;
using INS.PT.WebAPI.Model.v1;
using INS.PT.WebAPI.Model.SumClientReceipt.v1;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using INS.PT.WebAPI.v1;

namespace INS.PT.WebAPI.Controllers.V1
{
    /// <summary>
    /// SumClientsReceiptsController : BaseCore 
    /// </summary>
    /// <seealso cref="INS.PT.WebAPI.v1.BaseCore" />
    [Route("v1/SumClientsReceipts")]
    [ApiController]
    public class SumClientsReceiptsController : BaseCore 
    {
      
        /// <summary>
        /// The sum clients receipts repository
        /// </summary>
        private readonly ISumClientsReceiptsRepository _SumClientsReceiptsRepository;
        private readonly IContextRepository _contextRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="SumClientsReceiptsController"/> class.
        /// </summary>
        /// <param name="sumClientsReceiptsRepository">The sum clients receipts repository.</param>
        /// <param name="httpContext">The HTTP context.</param>
        /// <param name="contextRepository">The context repository.</param>
        public SumClientsReceiptsController(ISumClientsReceiptsRepository sumClientsReceiptsRepository, 
            IHttpContextAccessor httpContext, IContextRepository contextRepository) : base(httpContext)
        {
            _SumClientsReceiptsRepository = sumClientsReceiptsRepository;
            _contextRepository = contextRepository;
        }

        /// <summary>
        /// Posts the specified valueout. ZFscdMposKpisDetailWsRequest
        /// </summary>
        /// <remarks>
        /// Sample request:
        /// https://wiki.ageas.pt/index.php?title=MPOS_tst_examples#sumClientsReceipts
        /// </remarks>
        /// <param name="valueout">The valueout.</param>
        /// <returns></returns>
        [Authorize]
        [HttpPost(Name = "SumClientsReceipts")]
        [Produces("application/json")]
        [Consumes("application/json")]
        [ProducesResponseType(typeof(OutputSumClientReceipt), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]

        public async Task<ActionResult<OutputSumClientReceipt>> Post([FromBody] Model.SumClientReceipt.v1.InputSumClientReceipt valueout)
        {
            try
            {
                Model.SumClientReceipt.v1.OutputSumClientReceipt _response = null;
                bool output = await _contextRepository.GetTokenValidateAsync(Request);
                if (output)
                {
                    _response = await _SumClientsReceiptsRepository.GetKpiDetailsAsync(valueout);
                }
                return Ok(_response);
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError);
                return NotFound(processError);
            }
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception ex)
            {
                //creates a 500
                Log.Error(ex);
                throw;
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }
    }
}

﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface.V1;
using INS.PT.WebAPI.Model.v1;
using INS.PT.WebAPI.v1;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace INS.PT.WebAPI.Controllers.V1
{
    /// <summary>
    /// GetDocController
    /// </summary>
    [Route("v1/GetDoc")]
    [ApiController]
    public class GetDocController : BaseCore
    {
        /// <summary>
        /// The get document repository
        /// </summary>
        private readonly IGetDocRepository getDocRepository;
        /// <summary>
        /// The document repository
        /// </summary>
        private readonly IDocumentRepository documentRepository;


        /// <summary>
        /// Initializes a new instance of the <see cref="GetDocController"/> class.
        /// </summary>
        /// <param name="_documentRepository">The document repository.</param>
        /// <param name="_getDocRepository">The get document repository.</param>
        /// <param name="httpContext">The HTTP context.</param>
        public GetDocController(IDocumentRepository _documentRepository, IGetDocRepository _getDocRepository, IHttpContextAccessor httpContext) : base(httpContext)
        {
            getDocRepository = _getDocRepository;
            documentRepository = _documentRepository;
        }


        /// <summary>
        /// Posts the specified input data.
        /// </summary>
        /// <param name="InputData">The input data.</param>
        /// <returns></returns>
        /// <exception cref="ProcessErrorException">
        /// Not Found
        /// or
        /// Not Found
        /// or
        /// Not Found
        /// </exception>
        /// <exception cref="ProcessErrorException.InnerError">
        /// </exception>
        [Authorize]
        [HttpPost(Name = "GetDoc")]
        [Produces("application/json")]
        [Consumes("application/json")]
        [ProducesResponseType(typeof(OutputGetDoc), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status401Unauthorized)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProcessErrorExceptionCore), StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<OutputGetDoc>> Post([FromBody]InputGetDoc InputData)
        {
            try
            {
                 OutputGetDoc output = await documentRepository.OrchestrationAsync(InputData);
                 return Ok(output);
            }
            catch (ProcessErrorException processError)
            {
                Log.Error(processError);
                return NotFound(processError);
            }
            catch (AggregateException validateErrors)
            {
                Log.Error(validateErrors);
                return BadRequest(validateErrors);
            }
            catch (Exception e)
            {
                Log.Error(e);
                throw;
            }
            finally
            {
                Log.Debug($"Finish");
            }
        }
    }
}

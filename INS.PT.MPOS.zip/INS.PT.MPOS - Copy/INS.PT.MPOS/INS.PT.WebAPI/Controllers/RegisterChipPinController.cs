﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface;
using Microsoft.AspNetCore.Mvc;
using static INS.PT.WebAPI.Model.KpiSrv;
using static INS.PT.WebAPI.Model.Login;
using static INS.PT.WebAPI.Model.Logout;
using static INS.PT.WebAPI.Model.MBWayPayment;
using static INS.PT.WebAPI.Model.PaymentDetails;
using static INS.PT.WebAPI.Model.RefMBPayment;
using static INS.PT.WebAPI.Model.RegisterChipPin;
using static INS.PT.WebAPI.Model.SearchReceipts;
using static INS.PT.WebAPI.Model.SumClientsReceipts;

namespace INS.PT.WebAPI.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("v1/registerChipPin")]
    [ApiController]
    public class RegisterChipPinController : ControllerBase
    {
        /// <summary>
        /// The register chip pin repository
        /// </summary>
        private readonly IRegisterChipPinRepository _registerChipPinRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="RegisterChipPinController"/> class.
        /// </summary>
        /// <param name="registerChipPinRepository">The register chip pin repository.</param>
        public RegisterChipPinController(IRegisterChipPinRepository registerChipPinRepository)
        {
            _registerChipPinRepository = registerChipPinRepository;
        }

        /// <summary>
        /// [MOCK] - Posts the specified valueout.
        /// </summary>
        /// <param name="valueout">The valueout.</param>
        /// <returns></returns>
        [HttpPost(Name = "registerChipPin")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(OutputRegisterChipPin), 200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(400)]
        public async Task<OutputRegisterChipPin> Post([FromBody] InputRegisterChipPin valueout)
        {
            return _registerChipPinRepository.Submit("MPOS");
        }

    }
}

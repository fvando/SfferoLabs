﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface;
using Microsoft.AspNetCore.Mvc;
using static INS.PT.WebAPI.Model.ChipPinPayment;
using static INS.PT.WebAPI.Model.KpiSrv;
using static INS.PT.WebAPI.Model.Login;
using static INS.PT.WebAPI.Model.Logout;
using static INS.PT.WebAPI.Model.MBWayPayment;
using static INS.PT.WebAPI.Model.RefMBPayment;
using static INS.PT.WebAPI.Model.SearchReceipts;
using static INS.PT.WebAPI.Model.SumClientsReceipts;

namespace INS.PT.WebAPI.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("v1/chipPinPayment")]
    [ApiController]
    public class ChipPinPaymentController : ControllerBase
    {
        /// <summary>
        /// The chip pin payment repository
        /// </summary>
        private readonly IChipPinPaymentRepository _chipPinPaymentRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="ChipPinPaymentController"/> class.
        /// </summary>
        /// <param name="chipPinPaymentRepository">The chip pin payment repository.</param>
        public ChipPinPaymentController(IChipPinPaymentRepository chipPinPaymentRepository)
        {
            _chipPinPaymentRepository = chipPinPaymentRepository;
        }

        /// <summary>
        /// [MOCK] - Posts the specified valueout.
        /// </summary>
        /// <param name="valueout">The valueout.</param>
        /// <returns></returns>
        [HttpPost(Name = "chipPinPayment")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]

        [ProducesResponseType(typeof(OutputChipPinPayment), 200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(400)]
        public async Task<OutputChipPinPayment> Post([FromBody] InputChipPinPayment valueout)
        {
            return _chipPinPaymentRepository.Submit("MPOS");
        }

    }
}

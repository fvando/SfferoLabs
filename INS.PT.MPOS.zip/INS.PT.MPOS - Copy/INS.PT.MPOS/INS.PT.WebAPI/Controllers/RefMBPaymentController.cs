﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface;
using Microsoft.AspNetCore.Mvc;
using static INS.PT.WebAPI.Model.KpiSrv;
using static INS.PT.WebAPI.Model.Login;
using static INS.PT.WebAPI.Model.Logout;
using static INS.PT.WebAPI.Model.RefMBPayment;
using static INS.PT.WebAPI.Model.SearchReceipts;
using static INS.PT.WebAPI.Model.SumClientsReceipts;

namespace INS.PT.WebAPI.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("v1/refMBPayment")]
    [ApiController]
    public class RefMBPaymentController : ControllerBase
    {
        /// <summary>
        /// The reference mb payment repository
        /// </summary>
        private readonly IRefMBPaymentRepository _refMBPaymentRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="RefMBPaymentController"/> class.
        /// </summary>
        /// <param name="refMBPaymentRepository">The reference mb payment repository.</param>
        public RefMBPaymentController(IRefMBPaymentRepository refMBPaymentRepository)
        {
            _refMBPaymentRepository = refMBPaymentRepository;
        }

        /// <summary>
        /// [MOCK] - Posts the specified valueout.
        /// </summary>
        /// <param name="valueout">The valueout.</param>
        /// <returns></returns>
        [HttpPost(Name = "refMBPayment")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(OutputRefMBPayment), 200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(400)]
        public async Task<OutputRefMBPayment> Post([FromBody] InputRefMBPayment valueout)
        {
            return _refMBPaymentRepository.Submit("MPOS");
        }

    }
}

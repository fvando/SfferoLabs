﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface;
using Microsoft.AspNetCore.Mvc;
using static INS.PT.WebAPI.Model.KpiSrv;
using static INS.PT.WebAPI.Model.Login;
using static INS.PT.WebAPI.Model.Logout;

namespace INS.PT.WebAPI.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("v1/logout")]
    [ApiController]
    public class LogoutController : ControllerBase
    {
        /// <summary>
        /// The login repository
        /// </summary>
        private readonly ILogoutRepository _logoutRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="LogoutController"/> class.
        /// </summary>
        /// <param name="logoutRepository">The logout repository.</param>
        public LogoutController( ILogoutRepository logoutRepository)
        {
            _logoutRepository = logoutRepository;
        }

        /// <summary>
        /// [MOCK] - Postouts the specified valueout.
        /// </summary>
        /// <param name="valueout">The valueout.</param>
        /// <returns></returns>
        [HttpPost(Name = "logout")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(OutputLogout), 200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(400)]
        public OutputLogout Postout([FromBody] InputLogout valueout)
        {
            return _logoutRepository.Submit("MPOS");
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface;
using Microsoft.AspNetCore.Mvc;
using static INS.PT.WebAPI.Model.KpiSrv;
using static INS.PT.WebAPI.Model.Login;
using static INS.PT.WebAPI.Model.Logout;
using static INS.PT.WebAPI.Model.PaymentDetails;
using static INS.PT.WebAPI.Model.SearchReceipts;
using static INS.PT.WebAPI.Model.SumClientsReceipts;

namespace INS.PT.WebAPI.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("v1/paymentDetails")]
    [ApiController]
    public class PaymentDetailsController : ControllerBase
    {
        /// <summary>
        /// The payment details repository
        /// </summary>
        private readonly IPaymentDetailsRepository _paymentDetailsRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="PaymentDetailsController"/> class.
        /// </summary>
        /// <param name="paymentDetailsRepository">The payment details repository.</param>
        public PaymentDetailsController(IPaymentDetailsRepository paymentDetailsRepository)
        {
            _paymentDetailsRepository = paymentDetailsRepository;
        }

        /// <summary>
        /// [MOCK] - Posts the specified valueout.
        /// </summary>
        /// <param name="valueout">The valueout.</param>
        /// <returns></returns>
        [HttpPost(Name = "paymentDetails")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(OutputMBWayPayment), 200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(400)]
        public OutputPaymentDetails Post([FromBody] InputPaymentDetails valueout)
        {
            return _paymentDetailsRepository.Submit("MPOS");
        }

    }
}

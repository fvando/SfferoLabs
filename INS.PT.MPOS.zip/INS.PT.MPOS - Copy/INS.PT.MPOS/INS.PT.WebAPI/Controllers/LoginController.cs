﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static INS.PT.WebAPI.Model.KpiSrv;
using static INS.PT.WebAPI.Model.Login;
using static INS.PT.WebAPI.Model.Logout;

namespace INS.PT.WebAPI.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Authorize]
    [Route("v1/login")]
    [ApiController]
 
    public class LoginController : ControllerBase
    {
        /// <summary>
        /// The login repository
        /// </summary>
        private readonly ILoginRepository _loginRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoginController"/> class.
        /// </summary>
        /// <param name="loginRepository">The login repository.</param>
        public LoginController(ILoginRepository loginRepository)
        {
            _loginRepository = loginRepository;
        }


        /// <summary>
        /// [MOCK] - Posts the in.
        /// </summary>
        /// <param name="valuein">The valuein.</param>
        /// <returns></returns>
       
        [HttpPost(Name = "login")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(OutputLogin), 200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(400)]
        public OutputLogin PostIn([FromBody] InputLogin valuein)
        {
            return _loginRepository.Submit("MPOS");
        }
    }
}

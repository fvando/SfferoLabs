﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using INS.PT.WebAPI.Interface;
using Microsoft.AspNetCore.Mvc;
using static INS.PT.WebAPI.Model.GetDoc;
using static INS.PT.WebAPI.Model.GetTerminal;
using static INS.PT.WebAPI.Model.KpiSrv;
using static INS.PT.WebAPI.Model.Login;
using static INS.PT.WebAPI.Model.Logout;
using static INS.PT.WebAPI.Model.SumClientsReceipts;

namespace INS.PT.WebAPI.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("v1/getTerminal")]
    [ApiController]
    public class GetTerminalController : ControllerBase
    {
        /// <summary>
        /// The get terminal repository
        /// </summary>
        private readonly IGetTerminalRepository _getTerminalRepository;

        /// <summary>
        /// Initializes a new instance of the <see cref="GetTerminalController"/> class.
        /// </summary>
        /// <param name="getTerminalRepository">The get terminal repository.</param>
        public GetTerminalController(IGetTerminalRepository getTerminalRepository)
        {
            _getTerminalRepository = getTerminalRepository;
        }

        /// <summary>
        /// [MOCK] - Posts the specified valueout.
        /// </summary>
        /// <param name="valueout">The valueout.</param>
        /// <returns></returns>
        [HttpPost(Name = "getTerminal")]
        [Produces("application/json", "application/xml")]
        [Consumes("application/json", "application/xml")]
        [ProducesResponseType(typeof(OutputGetTerminal), 200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(400)]
        public OutputGetTerminal Post([FromBody] InputGetTerminal valueout)
        {
            return _getTerminalRepository.Submit("MPOS");
        }

    }
}

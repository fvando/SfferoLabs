﻿// Copyright Ageas 2019 © - Integration Team

using System;

namespace INS.PT.WebAPI.Attributes
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Enum | AttributeTargets.Interface | AttributeTargets.Delegate)]
    public class SwaggerReferenceDataAttribute : Attribute
    {
        public string ImplementationNotes { get; set; }

        public SwaggerReferenceDataAttribute()
        {
            this.ImplementationNotes = "Hello!";
        }
    }

}

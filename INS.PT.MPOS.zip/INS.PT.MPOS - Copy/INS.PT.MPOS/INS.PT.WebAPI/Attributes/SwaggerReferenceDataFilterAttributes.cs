﻿// Copyright Ageas 2019 © - Integration Team

using INS.PT.WebAPI.Attributes;
using Microsoft.AspNetCore.Http;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Linq;
using INS.PT.WebAPI.Interface;
using INS.PT.WebAPI.Repository;

namespace INS.PT.WebAPI.Configurations
{
    public class SwaggerReferenceDataAttributes : IOperationFilter
    {
        private readonly IReferenceDataRepository repository;

        public SwaggerReferenceDataAttributes(IHttpContextAccessor httpContext)
        {
            // validate arguments
            if (httpContext == null)
            {
                throw new ArgumentNullException(nameof(httpContext));
            }

            var context = httpContext.HttpContext;
            // get repository to read data
            repository = (ReferenceDataRepository)context?.RequestServices.GetService(typeof(IReferenceDataRepository));
        }

        public void Apply(Operation operation, OperationFilterContext context)
        {            
            context.ApiDescription.TryGetMethodInfo(out System.Reflection.MethodInfo methodInfo);
            //bool isAuthorized = filterDescriptors.Select(filterInfo => filterInfo.Filter).Any(filter => filter is SwaggerReferenceDataAttribute);
            var ext = methodInfo.GetCustomAttributes(typeof(SwaggerReferenceDataAttribute), true);

            if (ext?.FirstOrDefault() != null)
            {
                operation.Description = "List Detail:"; //repository.GetReferenceData()
            }
            
        }
    }
}

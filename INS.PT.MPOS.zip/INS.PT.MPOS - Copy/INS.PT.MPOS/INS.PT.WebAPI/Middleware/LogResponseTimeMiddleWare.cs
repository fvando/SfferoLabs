﻿// Copyright Ageas 2019 © - Integration Team

using Microsoft.AspNetCore.Http;
using System.Diagnostics;
using System.Threading.Tasks;
using log4net;
using System;

namespace INS.PT.WebAPI.Middleware
{
    /// <summary>
    /// LogResponseTimeMiddleWare
    /// </summary>
    public class LogResponseTimeMiddleWare
    {
        private readonly RequestDelegate _next;
        private readonly ILog Log;

        /// <summary>
        /// LogResponseTimeMiddleWare
        /// </summary>
        /// <param name="next"></param>
        public LogResponseTimeMiddleWare(RequestDelegate next) : this(next, LogManager.GetLogger(typeof(LogResponseTimeMiddleWare)))
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="next"></param>
        /// <param name="log"></param>
        public LogResponseTimeMiddleWare(RequestDelegate next, ILog log)
        {
            _next = next;
            Log = log ?? throw new ArgumentNullException(nameof(log));
        }

        /// <summary>
        /// Invoke
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public async Task InvokeAsync(HttpContext context)
        {
            Log.Debug($"InvokeAsync Request: ");

            var stopwatch = new Stopwatch();
            stopwatch.Start();

            // execute the rest of the pipeline
            await _next(context);

            stopwatch.Stop(); //stop measuring
            var result = stopwatch.ElapsedMilliseconds;

            // write log 
            Log.Debug($"InvokeAsync Response time: {result}ms");
        }
    }
}

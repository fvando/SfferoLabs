﻿// Copyright Ageas 2019 © - Integration Team

using Microsoft.AspNetCore.Builder;

namespace INS.PT.WebAPI.Middleware
{
    /// <summary>
    /// LogResponseTimeMiddleWareExtension
    /// </summary>
    public static class LogResponseTimeMiddleWareExtension
    {
        /// <summary>
        /// UseLogResponseTime
        /// </summary>
        /// <param name="app"></param>
        /// <returns></returns>
        public static IApplicationBuilder UseLogResponseTime(this IApplicationBuilder app)
        {
            app.UseMiddleware<LogResponseTimeMiddleWare>();
            return app;
        }
    }
}

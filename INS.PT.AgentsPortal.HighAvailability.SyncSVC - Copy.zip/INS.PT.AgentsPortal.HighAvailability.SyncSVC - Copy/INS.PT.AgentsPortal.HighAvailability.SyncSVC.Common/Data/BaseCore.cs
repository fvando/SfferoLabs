﻿using log4net;
using System.Diagnostics;

namespace INS.PT.AgentsPortal.HighAvailability.Common.Data
{
    public class BaseCore
    {
        protected ILog _log = LogManager.GetLogger(typeof(BaseCore));

        protected Stopwatch _stopwatch = new Stopwatch();
    }
}

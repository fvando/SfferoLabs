﻿using Microsoft.Extensions.Configuration;

namespace INS.PT.AgentsPortal.HighAvailability.Common.Models.Configuration
{
    public static class ApplicationSettings
    {
        public static string ApplicationName { get; set; }

        // Log4net
        public static string LogConfigFile { get; set; }


        #region Constants
        public static string ConstantsCompany { get; set; }
        public static string ConstantsDomains { get; set; }
        #endregion

        public static string ServiceSettingsServiceName { get; set; }
        public static string ServiceSettingsDisplayName { get; set; }
        public static string ServiceSettingsDescription { get; set; }

        //Broker
        public static string BrokerSettingsBsEndpoint { get; set; }
        public static string BrokerInternalEndpoint { get; set; }
        public static string BrokerSoapEndPoint { get; set; }
        public static string BrokerSettingsBsSolution { get; private set; }
        public static string BrokerSettingsBsUser { get; private set; }
        public static string BrokerWebService { get; private set; }
        public static string BrokerWebMethod { get; private set; }


        //Broker SAS
        public static string BrokerSASBsSolution { get; private set; }
        public static string BrokerSASBsUser { get; private set; }
        public static string BrokerSASWebService { get; private set; }
        public static string BrokerSASWebMethod { get; private set; }

        // Methods
        public static string MethodsServiceBusMsg { get; set; }

        #region URL
        public static bool ProxySettingsUseProxy { get; set; }
        public static string ProxySettingsProxyHost { get; set; }
        public static int ProxySettingsProxyPort { get; set; }
        public static string ProxySettingsProxyByPassList { get; set; }
        public static string SQLServerConnectionString { get; set; }
        #endregion

        public static void SetSettings(IConfiguration config)
        {
            SetCommonSettings(config);
        }

        public static void SetCommonSettings(IConfiguration config)
        {
            ConstantsCompany = config["Constants:Company"];
            ConstantsDomains = config["Constants:Domains"];

            //Broker settings SAS
            BrokerSASBsSolution = config["BrokerSAS:BsSolution"];
            BrokerSASBsUser = config["BrokerSAS:BsUser"];

            // Broker 
            BrokerSettingsBsSolution = config["BrokerSettings:BsSolution"];
            BrokerSettingsBsUser = config["BrokerSettings:BsUser"];

            BrokerSettingsBsEndpoint = config["BrokerSettings:BsEndpoint"];
            BrokerInternalEndpoint = config["BrokerSettings:BsInternalEndpoint"];
            BrokerSoapEndPoint = config["BrokerSettings:SoapEndPoint"];

            BrokerWebService = config["BrokerSettings:bsWebService"];
            BrokerWebMethod = config["BrokerSettings:bsWebMethod"];

            BrokerSASWebService = config["BrokerSAS:bsWebService"];
            BrokerSASWebMethod = config["BrokerSAS:bsWebMethod"];

            // Proxy
            ProxySettingsUseProxy = bool.Parse(config["ProxySettings:UseProxy"]);
            ProxySettingsProxyHost = config["ProxySettings:ProxyHost"];
            ProxySettingsProxyPort = int.Parse(config["ProxySettings:ProxyPort"]);
            ProxySettingsProxyByPassList = config["ProxySettings:ProxyByPassList"];

            #region Service

            ServiceSettingsServiceName = config["ServiceSettings:ServiceName"];
            ServiceSettingsDisplayName = config["ServiceSettings:DisplayName"];
            ServiceSettingsDescription = config["ServiceSettings:Description"];

            #endregion
        }
    }
}

﻿using Newtonsoft.Json;

namespace INS.PT.AgentsPortal.HighAvailability.Common.Models.Requests
{
    public class AxisValues
    {
        /// <summary>Solution</summary>
        /// <example>DUCKCREEK</example>
        [JsonProperty("solution")]
        public string Solution { get; set; }

        /// <summary>User</summary>
        /// <example>\BS\DUCKCREEKD</example>
        [JsonProperty("user")]
        public string User { get; set; }
    }
}

﻿using System.IO;
using System.Xml;
using System.Xml.Serialization;
using Newtonsoft.Json;

namespace INS.PT.AgentsPortal.HighAvailability.Common.Helpers
{
    public static class Extensions
    {
        public static string SerializeJsonToXml(this string json, string rootName)
        {
            using (StringWriter commonCollectionXmlInput = new StringWriter())
            {
                XmlDocument xmlDoc = JsonConvert.DeserializeXmlNode(json, rootName);

                var serializer = new XmlSerializer(xmlDoc.GetType());

                serializer.Serialize(commonCollectionXmlInput, xmlDoc);

                return commonCollectionXmlInput.ToString();
            }
        }
    }
}

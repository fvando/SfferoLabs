﻿using Flurl;
using Flurl.Http;
using log4net;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace INS.PT.AgentsPortal.HighAvailability.Common.BrokerCalls
{
    public class BrokerClient : IBrokerClient
    {
        private readonly ILog log;
        private readonly IConfiguration configurations;

        private string _httpVerb;

        public class GenericResponseString
        {
            public string Response { get; set; }
            public bool Success { get; set; }
        }

        /// <summary>
        /// Contructor.
        /// </summary>
        /// <param name="configurations">Configurations to try to load settings.</param>
        public BrokerClient(IConfiguration configurations)
        {
            const string BrokerSettingsSection = "BrokerSettings";

            log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            AdicionalHeaders = new Dictionary<string, string>();
            ContentType = "application/json";
            HttpVerb = "GET";

            this.configurations = configurations ?? throw new ArgumentNullException(nameof(configurations));

            LoadConfigSettings(BrokerSettingsSection);
        }

        /// <summary>
        /// Reads the broker endpoint and mandatory headers from the configuration section specified.
        /// </summary>
        /// <param name="brokerSettingsSection">section name to read</param>
        public void LoadConfigSettings(string brokerSettingsSection)
        {
            BsEndpoint = configurations[$"{brokerSettingsSection}:{nameof(BsEndpoint)}"];
            BsSolution = configurations[$"{brokerSettingsSection}:{nameof(BsSolution)}"];
            BsUser = configurations[$"{brokerSettingsSection}:{nameof(BsUser)}"];
            BsWebService = configurations[$"{brokerSettingsSection}:{nameof(BsWebService)}"];
            BsWebmethod = configurations[$"{brokerSettingsSection}:{nameof(BsWebmethod)}"];
        }

        /// <summary>
        /// Broker endpoint to be used for the request.
        /// </summary>
        public string BsEndpoint { get; set; }

        /// <summary>
        /// Http verb to be used.
        /// </summary>
        /// <example>GET</example>
        public string HttpVerb { get => _httpVerb.ToUpper(System.Globalization.CultureInfo.InvariantCulture); set => _httpVerb = value; }

        private HttpMethod Verb
        {
            get
            {
                return new HttpMethod(HttpVerb);
            }
        }

        #region Headers
        /// <summary>
        /// Content type header. Defauls to "application/json".
        /// </summary>
        /// <example>application/json</example>
        public string ContentType { get; set; }

        /// <summary>
        /// Solution header to be used.
        /// </summary>
        /// <example>DUCKCREEK</example>
        public string BsSolution { get; set; }

        /// <summary>
        /// User header to be used.
        /// </summary>
        /// <example>\BS\DUCKCREEKD</example>
        public string BsUser { get; set; }

        /// <summary>
        /// Web service header to be used.
        /// </summary>
        /// <example>ageas-api-ReferenceData</example>
        public string BsWebService { get; set; }

        /// <summary>
        /// Web method header to be used.
        /// </summary>
        /// <example>v1/ReferenceData/Mappings</example>
        public string BsWebmethod { get; set; }

        /// <summary>
        /// Property to define aditional headers to be added to the request.
        /// </summary>
        public Dictionary<string, string> AdicionalHeaders { get; set; }
        #endregion


        /// <summary>
        /// Makes a request and read is response.
        /// </summary>
        /// <typeparam name="T">result type of the call to ba made</typeparam>
        /// <param name="additionalRoute">route to add to the broker endpoint</param>
        /// <param name="additionalParameters">aditional query parameters to be added</param>
        /// <param name="requestObject">request body if nedded.</param>
        /// <returns>result object that comes from response body</returns>
        public async Task<T> RequestAsync<T>(string additionalRoute, IDictionary<string, string> additionalParameters, object requestObject)
        {
            return await RequestAsync<T>(additionalRoute, additionalParameters, requestObject, 0, null, true, default(T));
        }

        public async Task<T> RequestAsync<T>(string additionalRoute, IDictionary<string, string> additionalParameters, object requestObject, uint retries, Func<FlurlHttpException, T> errorAction) where T : new()
        {
            return await RequestAsync<T>(additionalRoute, additionalParameters, requestObject, retries, errorAction, true, new T());
        }

        public async Task<T> RequestAsync<T>(string additionalRoute, IDictionary<string, string> additionalParameters, object requestObject, uint retries, Func<FlurlHttpException, T> errorAction, bool validateWebServiceAndWebMethod) where T : new()
        {
            return await RequestAsync<T>(additionalRoute, additionalParameters, requestObject, retries, errorAction, validateWebServiceAndWebMethod, new T());
        }

        /// <summary>
        /// Makes a request and read is response.
        /// </summary>
        /// <typeparam name="T">result type of the call to ba made</typeparam>
        /// <param name="additionalRoute">route to add to the broker endpoint</param>
        /// <param name="additionalParameters">aditional query parameters to be added</param>
        /// <param name="requestObject">request body if nedded.</param>
        /// <param name="retries">number of retries to execute.</param>
        /// <returns>result object that comes from response body</returns>
        public async Task<T> RequestAsync<T>(string additionalRoute, IDictionary<string, string> additionalParameters, object requestObject, uint retries, Func<FlurlHttpException, T> errorAction, bool validateWebServiceAndWebMethod, T defaultValue)
        {
            // default result
            var result = defaultValue;

            // check if can make the call
            if (!OkToMakeCall(validateWebServiceAndWebMethod))
            {
                return result;
            }

            // prepare call
            var guid = Guid.NewGuid();
            var stopwatch = new System.Diagnostics.Stopwatch();

            var requestUrl = BsEndpoint
                .AppendPathSegment(additionalRoute);


            // add any query parameters to the request
            if (additionalParameters != null)
            {
                foreach (var param in additionalParameters.Keys)
                {
                    requestUrl.SetQueryParam(param, additionalParameters[param]);
                }
            }

            // add commom headers
            var request = requestUrl.WithHeader("Content-Type", ContentType)
                .WithHeader(nameof(BsSolution), BsSolution)
                .WithHeader(nameof(BsUser), BsUser)
                .WithHeader(nameof(BsWebService), BsWebService)
                .WithHeader(nameof(BsWebmethod), BsWebmethod);

            // add aditional headers
            foreach (var addHeader in AdicionalHeaders)
            {
                request = request.WithHeader(addHeader.Key, addHeader.Value);
            }

            // log call to be made
            log.Info($"Request broker client ({guid}) = {JsonConvert.SerializeObject(request)}");


            stopwatch.Start();
            try
            {
                HttpResponseMessage response;

                if (Verb == HttpMethod.Get)
                {
                    response = await request.GetAsync();
                }
                else if (Verb == HttpMethod.Put)
                {
                    response = await request.PutJsonAsync(requestObject);
                }
                else if (Verb == HttpMethod.Post)
                {
                    response = await request.PostJsonAsync(requestObject);
                }
                else if (Verb == HttpMethod.Delete)
                {
                    response = await request.DeleteAsync();
                }
                else
                {
                    response = await request.SendJsonAsync(Verb, requestObject);
                }

                stopwatch.Stop();
                log.Info($"Broker request ({guid}) took {stopwatch.ElapsedMilliseconds}ms with IsSuccessStatusCode=" +
                    $"{response.IsSuccessStatusCode}; StatusCode={response.StatusCode}; ReasonPhrase={response.ReasonPhrase}");
                stopwatch.Restart();

                if (response.IsSuccessStatusCode)
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.NoContent) // DuckCreek PushNotification
                    {
                        result = (T)Convert.ChangeType(true, typeof(T));
                    }
                    else
                    {
                        if (result is GenericResponseString)
                        {
                            string resp = response.Content.ReadAsStringAsync().Result;

                            GenericResponseString genericResponse = new GenericResponseString
                            {
                                Response = resp,
                                Success = true
                            };

                            result = (T)Convert.ChangeType(genericResponse, typeof(T));
                        }
                        else
                        {
                            result = await response.Content.ReadAsAsync<T>();
                        }
                    }
                }
                // if there's retries to make
                else if (retries > 0)
                {
                    log.Info($"Broker call ({guid}) will retry {retries} times");

                    // make a delay for each retry
                    await Task.Delay(100);

                    // make a recursive call
                    return await RequestAsync(additionalRoute, additionalParameters, requestObject, --retries, errorAction, validateWebServiceAndWebMethod, defaultValue);
                }

                stopwatch.Stop();
                log.Info($"Broker call ({guid}) took {stopwatch.ElapsedMilliseconds}ms with response: {JsonConvert.SerializeObject(result)}");
            }
            catch (FlurlHttpException ex)
            {
                if (ex.Call.Response.StatusCode == System.Net.HttpStatusCode.UnprocessableEntity)
                {
                    result = await ex.Call.Response.Content.ReadAsAsync<T>();
                }

                errorAction?.Invoke(ex);
            }
            catch (Exception e)
            {
                log.Error($"Unsuccessful call! Status ({guid}) with exception:{e}");

                result = default(T);
            }

            return result;
        }

        /// <summary>
        /// validates if broker client is ready to make call.
        /// </summary>
        /// <returns>true if all mandatory headers and configurations are set</returns>
        public bool OkToMakeCall()
        {
            return OkToMakeCall(true);
        }

        /// <summary>
        /// validates if broker client is ready to make call.
        /// NOTE: DuckCreek Receipt change notification does not need WebService and WebMethod in header (no validation required).
        /// </summary>
        /// <param name="validateWebServiceAndWebMethod"></param>
        /// <returns></returns>
        public bool OkToMakeCall(bool validateWebServiceAndWebMethod)
        {
            var result = !string.IsNullOrEmpty(BsEndpoint)
                && !string.IsNullOrEmpty(HttpVerb)
                && !string.IsNullOrEmpty(BsSolution);

            if (validateWebServiceAndWebMethod)
            {
                result = result
                    && !string.IsNullOrEmpty(BsUser)
                    && !string.IsNullOrEmpty(BsWebService);
            }
            else
            {
                result = result && !string.IsNullOrEmpty(BsUser);
            }

            if (validateWebServiceAndWebMethod)
            {
                result = result && !string.IsNullOrEmpty(BsWebmethod);
            }

            return result;
        }
    }
}

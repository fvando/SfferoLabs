// Copyright Ageas 2020 © - Integration Team

using INS.PT.AgentsPortal.HighAvailability.Common.BrokerCalls;
using INS.PT.AgentsPortal.HighAvailability.Common.Data;
using INS.PT.AgentsPortal.HighAvailability.Common.Models.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace INS.PT.AgentsPortal.HighAvailability.SyncSVC.Services
{
    class Listener : BaseCore
    {
        private readonly IBrokerClient _brokerClient;       
        static CancellationTokenSource _tokenSource;

        public Listener(IBrokerClient brokerClient)
        {
            _brokerClient = brokerClient;
        }

       
        public async Task MainAsync(string[] args)
        {
            try
            {
                _log.Debug($"Start Call Service to sync");

                try
                {
                    if (ApplicationSettings.ProxySettingsUseProxy)
                    {
                        WebProxy proxy = new WebProxy($"{ApplicationSettings.ProxySettingsProxyHost}:{ApplicationSettings.ProxySettingsProxyPort}");
                        List<string> bypasslist = new List<string> {
                            ApplicationSettings.ProxySettingsProxyByPassList
                        };
                        proxy.BypassList = bypasslist.ToArray();
                        WebRequest.DefaultWebProxy = proxy;
                    }
                }
                catch (Exception ex)
                {
                    _log.Error($"Error Instantitie WebProxy : " + ex);
                    throw;
                }

                _log.Debug($"Call ProcessHamedSync");                               
                bool result_HamedProcess = await ProcessHamedSync(args);
                _log.Debug($"END ProcessHamedSync with sucess:" + result_HamedProcess);

                _log.Debug($"Call ProcessSASSync");
                bool result_SASProcess = await ProcessSASSync(args);
                _log.Debug($"END ProcessSASSync with sucess:" + result_SASProcess);
            }
            catch (Exception ex)
            {
                _tokenSource.Cancel();

                _log.Error(ex);
                throw;
            }
        }

        private async Task<bool> ProcessHamedSync(string[] args)
        {
            _stopwatch.Restart();
            _stopwatch.Start();

            _log.Debug($"Start ProcessHamedSync");
            bool resultprocess = false;
            DateTime datenow = DateTime.Now.AddDays(-2); //data de ontem porque o serviço de sas devolve os dados de ontem

            //se recebeu uma data anterior a data atual (args), chama com esta data
            if (args.Length > 0)
            {
                DateTime.TryParse(args[0], out datenow);
            }

            foreach (string domain in ApplicationSettings.ConstantsDomains.ToString().Split(","))
            {
                object json = JsonConvert.DeserializeObject("{\"updateDate\": \"" + datenow.ToString("yyyy-MM-dd") + "T00:00:00.998Z\",\"domain\": \"" + domain + "\"}");
                try
                {
                    // Process the message
                    _log.Debug($"Start ProcessHamedSync Request: {json}");
                    _log.Debug($"Start ProcessHamedSync: {domain}");

                    _brokerClient.BsEndpoint = ApplicationSettings.BrokerSettingsBsEndpoint;
                    _brokerClient.BsUser = ApplicationSettings.BrokerSettingsBsUser;
                    _brokerClient.BsSolution = ApplicationSettings.BrokerSettingsBsSolution;
                    _brokerClient.BsWebService = ApplicationSettings.BrokerWebService;
                    _brokerClient.BsWebmethod = ApplicationSettings.BrokerWebMethod;
                    _brokerClient.HttpVerb = "POST";

                    var response = await _brokerClient.RequestAsync<bool?>(string.Empty, null, json, 0, (ex) =>
                    {
                        var data = (JObject)JsonConvert.DeserializeObject(ex.Call.Response.Content.ReadAsStringAsync().Result);
                        return false;
                    });

                    if (response != null)
                    {
                        resultprocess = true;
                    }
                    else
                        resultprocess = false;

                    _log.Debug($"End ProcessHamedSync Request: {domain}");
                    _log.Debug($"ProcessHamedSync Response: {JsonConvert.SerializeObject(resultprocess)}");

                }
                catch (Exception ex)
                {
                    _log.Error($"ProcessHamedSync Exception: {domain} , {ex}");
                    //throw;
                }
            }

            _stopwatch.Stop();
            _log.Debug($"End ProcessHamedSync : {_stopwatch.Elapsed.TotalMilliseconds}ms");

            return resultprocess;
        }

        private async Task<bool> ProcessSASSync(string[] args)
        {
            _stopwatch.Restart();
            _stopwatch.Start();

            _log.Debug($"Start ProcessSASSync");
            bool resultprocess = false;
            //DateTime datenow = DateTime.Now;
            DateTime datenow = DateTime.Now.AddDays(-2); //data de ontem porque o serviço de sas devolve os dados de ontem


            //se recebeu uma data anterior a data atual (args), chama com esta data
            if (args.Length > 0)
            {
                DateTime.TryParse(args[0], out datenow);
            }

            object json = JsonConvert.DeserializeObject("{\"updateDate\": \"" + datenow.ToString("yyyy-MM-dd") + "T00:00:00.998Z\",\"domain\": \"Entities\"}");
            try
            {
                // Process the message
                _log.Debug($"Start ProcessSASSync Request: {json}");
                _log.Debug($"Start ProcessSASSync");

                _brokerClient.BsEndpoint = ApplicationSettings.BrokerSettingsBsEndpoint;
                _brokerClient.BsUser = ApplicationSettings.BrokerSASBsUser;
                _brokerClient.BsSolution = ApplicationSettings.BrokerSASBsSolution;
                _brokerClient.BsWebService = ApplicationSettings.BrokerSASWebService;
                _brokerClient.BsWebmethod = ApplicationSettings.BrokerSASWebMethod;
                _brokerClient.HttpVerb = "POST";

                var response = await _brokerClient.RequestAsync<bool?>(string.Empty, null, json, 0, (ex) =>
                {
                    var data = (JObject)JsonConvert.DeserializeObject(ex.Call.Response.Content.ReadAsStringAsync().Result);
                    return false;
                });

                if (response != null)
                {
                    resultprocess = true;
                }
                else
                    resultprocess = false;

                _log.Debug($"End ProcessSASSync Request");
                _log.Debug($"ProcessSASSync Response: {JsonConvert.SerializeObject(resultprocess)}");

            }
            catch (Exception ex)
            {
                _log.Error($"ProcessSASSync Exception: {ex}");
                //throw;
            }

            _stopwatch.Stop();
            _log.Debug($"End ProcessSASSync : {_stopwatch.Elapsed.TotalMilliseconds}ms");

            return resultprocess;
        }
    }
}

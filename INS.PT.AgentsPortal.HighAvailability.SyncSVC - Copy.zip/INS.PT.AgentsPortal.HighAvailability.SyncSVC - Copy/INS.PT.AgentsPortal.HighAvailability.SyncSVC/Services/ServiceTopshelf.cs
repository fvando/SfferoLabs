// Copyright Ageas 2019 © - Integration Team

using System;
using System.IO;
using System.Reflection;
using INS.PT.AgentsPortal.HighAvailability.Common.BrokerCalls;
using INS.PT.AgentsPortal.HighAvailability.Common.Data;
using INS.PT.AgentsPortal.HighAvailability.Common.Models.Configuration;
using log4net;

namespace INS.PT.AgentsPortal.HighAvailability.SyncSVC.Services
{
    class ServiceTopshelf : BaseCore
    {
        private readonly IBrokerClient _brokerClient;
        public ServiceTopshelf(IBrokerClient brokerClient, string[] args)
        {
            _brokerClient = brokerClient;

            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
            var assemblyFolder = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            var configFile = Path.Combine(assemblyFolder, ApplicationSettings.LogConfigFile);

            log4net.Config.XmlConfigurator.Configure(logRepository, new FileInfo(configFile));

            // Start log
            _log = LogManager.GetLogger(typeof(ServiceTopshelf));

            _log.Debug($"Start ServiceTopshelf Constructor - Inicialize LOG");
            Console.WriteLine($"Start ServiceTopshelf Constructor - Inicialize LOG");

            #region Entities

            Listener listEntities = new Listener(_brokerClient);
            
            listEntities.MainAsync(args).GetAwaiter().GetResult();
            
            #endregion
        }

        /// <summary>Start Listener</summary>
        public void Start()
        {
            _log.Debug("ServiceTopshelf - Started");
        }
        /// <summary>Stop Listener</summary>
        public void Stop()
        {
            _log.Debug("ServiceTopshelf - Stopped");
        }
    }
}

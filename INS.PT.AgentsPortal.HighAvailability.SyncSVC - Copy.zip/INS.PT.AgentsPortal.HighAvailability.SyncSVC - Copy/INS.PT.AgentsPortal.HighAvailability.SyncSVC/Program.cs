﻿// Copyright Ageas 2019 © - Integration Team

using System;
using System.IO;
using System.Reflection;
using INS.PT.AgentsPortal.HighAvailability.Common.BrokerCalls;
using INS.PT.AgentsPortal.HighAvailability.Common.Models.Configuration;
using INS.PT.AgentsPortal.HighAvailability.SyncSVC.Services;
using log4net;
using Microsoft.Extensions.Configuration;
using Topshelf;

namespace INS.PT.AgentsPortal.HighAvailability.SyncSVC
{
    class Program
    {
        static ILog Log;

        static void Main(string[] args)
        {
            //Config App
            IConfiguration config = new ConfigurationBuilder()
                 .AddJsonFile("appsettings.json", true, true)
                 .AddJsonFile($"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")}.json", true, true)
                 .Build();

            BrokerClient brokerClient = new BrokerClient(config);

            //ApplicationSettings.ServiceBusConfig = config.GetSection("ServiceBus").Get<Common.Models.Configuration.ServiceBus>();

            // Configure Log4Net
            var logRepository = LogManager.GetRepository(Assembly.GetEntryAssembly());
            ApplicationSettings.LogConfigFile = config["Logging:LogConfigFile"];
            log4net.Config.XmlConfigurator.Configure(logRepository, new FileInfo(ApplicationSettings.LogConfigFile));

            // Set Global Variables
            ApplicationSettings.SetSettings(config);

            //Start log
            Log = LogManager.GetLogger(typeof(Program));
            

            Listener listEntities = new Listener(brokerClient);
            listEntities.MainAsync(args).GetAwaiter().GetResult();


            //HostFactory.Run(windowsService =>
            //{
            //    Log.Info($"Start INS.PT.AgentsPortal.HighAvailability.SyncSVC Service");
             
            //    windowsService.Service<ServiceTopshelf>(s =>
            //    {
            //        s.ConstructUsing(service => new ServiceTopshelf(brokerClient, args));                    
            //        s.WhenStarted(service => service.Start());
            //        s.WhenStopped(service => service.Stop());
            //    });

            //    windowsService.RunAsLocalSystem();
            //    windowsService.StartAutomatically();

            //    windowsService.SetDescription(ApplicationSettings.ServiceSettingsDescription);
            //    windowsService.SetDisplayName(ApplicationSettings.ServiceSettingsDisplayName);
            //    windowsService.SetServiceName(ApplicationSettings.ServiceSettingsServiceName);
            //});
        }
    }
}
